package com.adapt;

import static org.junit.Assert.assertNotNull;

import com.adapt.util.DomainPackage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DomainPackage(packages = { "com.adapt.file.entity", "com.adapt.api.domain",
    "com.adapt.api.config.domain" })
public class DomainTest {

  private static final Logger LOGGER = LoggerFactory.getLogger(DomainTest.class);

  @Test
  public void testDomainClasses_withDummyValues_shouldRunSuccessfully() {

    DomainPackage domainPackage = this.getClass().getAnnotation(DomainPackage.class);
    String[] packages = domainPackage.packages();

    for (String packageName : packages) {
      Class[] classes;
      try {
        classes = getClasses(packageName);
        assertNotNull(classes);
        for (Class<?> clazz : classes) {
          Object obj = null;
          try {
            obj = testConstructor(clazz, obj);

            testFirstGetterAndSetter(obj);
          } catch (InstantiationException | IllegalAccessException | InvocationTargetException e1) {
            LOGGER.debug(e1.getMessage(), e1);
          }
        }
      } catch (ClassNotFoundException | IOException e) {
        LOGGER.debug(e.getMessage(), e);
      }
    }

  }

  private void testFirstGetterAndSetter(Object obj)
      throws IllegalAccessException, InvocationTargetException {
    if (obj != null) {
      Method[] methods = obj.getClass().getMethods();
      for (Method method : methods) {
        if (method.getName().startsWith("get")) {
          method.invoke(obj);
        }
        invokeSetMethod(obj, method);
      }
    }
  }

  private void invokeSetMethod(Object obj, Method method)
      throws IllegalAccessException, InvocationTargetException {
    if (method.getName().startsWith("set") && method.getParameterCount() == 1) {
      Class paramClass = method.getParameters()[0].getType();
      if (paramClass.equals(String.class)) {
        method.invoke(obj, "test");
      } else if (paramClass.equals(Double.class)) {
        method.invoke(obj, 1.00);
      } else if (paramClass.equals(Boolean.class)) {
        method.invoke(obj, true);
      } else if (paramClass.equals(Long.class)) {
        method.invoke(obj, 55L);
      } else if (paramClass.equals(Integer.class)) {
        method.invoke(obj, 1);
      } else if (paramClass.equals(Date.class)) {
        method.invoke(obj, new Date());
      } else if (paramClass.equals(java.sql.Date.class)) {
        method.invoke(obj, new java.sql.Date(new Date().getTime()));
      } else if (paramClass.equals(LocalDate.class)) {
        method.invoke(obj, LocalDate.now());
      } else if (paramClass.equals(LocalDateTime.class)) {
        method.invoke(obj, LocalDateTime.now());
      } else if (paramClass.equals(List.class)) {
        method.invoke(obj, Collections.emptyList());
      } else if (paramClass.equals(Object.class)) {
        method.invoke(obj, new Object());
      }
    }
  }

  @Test
  public void testDomainClasses_withDummyValues_shouldRunSuccessfully_setter() {

    DomainPackage domainPackage = this.getClass().getAnnotation(DomainPackage.class);
    String[] packages = domainPackage.packages();

    for (String packageName : packages) {
      Class[] classes;
      try {
        classes = getClasses(packageName);
        for (Class<?> clazz : classes) {
          Object obj = null;
          try {
            obj = testConstructor(clazz, obj);

            testFirstSetterAndGetter(obj);
          } catch (InstantiationException | IllegalAccessException | InvocationTargetException e1) {
            LOGGER.debug(e1.getMessage(), e1);
          }
        }
      } catch (ClassNotFoundException | IOException e) {
        LOGGER.debug(e.getMessage(), e);
      }
    }

  }

  private void testFirstSetterAndGetter(Object obj)
      throws IllegalAccessException, InvocationTargetException {
    if (obj != null) {
      Method[] methods = obj.getClass().getMethods();
      for (Method method : methods) {

        invokeSetMethod(obj, method);

      }
      for (Method method : methods) {
        if (method.getName().startsWith("get")) {
          method.invoke(obj);
        }
      }
    }
  }

  private Object testConstructor(Class<?> clazz, Object obj)
      throws InstantiationException, IllegalAccessException, InvocationTargetException {
    Constructor<?>[] constructors = clazz.getConstructors();
    for (Constructor<?> constructor : constructors) {
      if (constructor.getParameterCount() == 0) {
        obj = clazz.newInstance();
      } else {
        Class<?>[] parameterTypes = constructor.getParameterTypes();
        Object[] parameterArgs = new Object[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
          Class<?> paramClass = parameterTypes[i];
          if (paramClass.equals(String.class)) {
            parameterArgs[i] = "test";
          } else if (paramClass.equals(Double.class)) {
            parameterArgs[i] = 1.00;
          } else if (paramClass.equals(Boolean.class)) {
            parameterArgs[i] = Boolean.TRUE;
          } else if (paramClass.equals(Long.class)) {
            parameterArgs[i] = 55L;
          } else if (paramClass.equals(Integer.class)) {
            parameterArgs[i] = 1;
          } else if (paramClass.equals(Date.class)) {
            parameterArgs[i] = new Date();
          } else if (paramClass.equals(java.sql.Date.class)) {
            parameterArgs[i] = new java.sql.Date(new Date().getTime());
          } else if (paramClass.equals(LocalDate.class)) {
            parameterArgs[i] = LocalDate.now();
          } else if (paramClass.equals(LocalDateTime.class)) {
            parameterArgs[i] = LocalDateTime.now();
          } else if (paramClass.equals(Object.class)) {
            parameterArgs[i] = new Object();
          }
        }
        obj = constructor.newInstance(parameterArgs);
      }
    }
    return obj;
  }

  @Test
  public void testDomainClasses_withoutDate_shouldRunSuccessfully() {

    DomainPackage domainPackage = this.getClass().getAnnotation(DomainPackage.class);
    String[] packages = domainPackage.packages();

    for (String packageName : packages) {
      Class[] classes;
      try {
        classes = getClasses(packageName);
        for (Class<?> clazz : classes) {
          Object obj = null;
          try {
            Constructor<?>[] constructors = clazz.getConstructors();
            for (Constructor<?> constructor : constructors) {
              if (constructor.getParameterCount() == 0) {
                obj = clazz.newInstance();
                assertNotNull(obj);
              } else {
                Class<?>[] parameterTypes = constructor.getParameterTypes();
                Object[] parameterArgs = new Object[parameterTypes.length];

                for (int i = 0; i < parameterTypes.length; i++) {
                  Class<?> paramClass = parameterTypes[i];
                  if (paramClass.equals(String.class)) {
                    parameterArgs[i] = "test";
                  } else if (paramClass.equals(Double.class)) {
                    parameterArgs[i] = 1.00;
                  } else if (paramClass.equals(Boolean.class)) {
                    parameterArgs[i] = Boolean.TRUE;
                  } else if (paramClass.equals(Long.class)) {
                    parameterArgs[i] = 55L;
                  } else if (paramClass.equals(Integer.class)) {
                    parameterArgs[i] = 1;
                  } else if (paramClass.equals(Date.class)) {
                    parameterArgs[i] = null;
                  } else if (paramClass.equals(java.sql.Date.class)) {
                    parameterArgs[i] = null;
                  } else if (paramClass.equals(LocalDate.class)) {
                    parameterArgs[i] = LocalDate.now();
                  } else if (paramClass.equals(LocalDateTime.class)) {
                    parameterArgs[i] = LocalDateTime.now();
                  } else if (paramClass.equals(Boolean.class)) {
                    parameterArgs[i] = true;
                  } else if (paramClass.equals(Object.class)) {
                    parameterArgs[i] = new Object();

                  }
                }
                obj = constructor.newInstance(parameterArgs);
              }
            }

            if (obj != null) {
              Method[] methods = obj.getClass().getMethods();
              for (Method method : methods) {
                if (method.getName().startsWith("get")) {
                  method.invoke(obj);
                }
                if (method.getName().startsWith("set") && method.getParameterCount() == 1) {
                  Class paramClass = method.getParameters()[0].getType();
                  if (paramClass.equals(String.class)) {
                    method.invoke(obj, "test");
                  } else if (paramClass.equals(Double.class)) {
                    method.invoke(obj, 1.00);
                  } else if (paramClass.equals(Boolean.class)) {
                    method.invoke(obj, true);
                  } else if (paramClass.equals(Long.class)) {
                    method.invoke(obj, 55L);
                  } else if (paramClass.equals(Integer.class)) {
                    method.invoke(obj, 1);
                  } else if (paramClass.equals(Date.class) || paramClass.equals(java.sql.Date.class)
                      || paramClass.equals(LocalDate.class)) {
                    Object o = null;
                    method.invoke(obj, o);
                  } else if (paramClass.equals(LocalDateTime.class)) {
                    method.invoke(obj, LocalDateTime.now());
                  } else if (paramClass.equals(List.class)) {
                    method.invoke(obj, Collections.emptyList());
                  } else if (paramClass.equals(Object.class)) {
                    method.invoke(obj, new Object());
                  }
                }
                if (method.getName().startsWith("toString")) {
                  method.invoke(obj);
                }
              }
            }
          } catch (InstantiationException | IllegalAccessException | InvocationTargetException e1) {
            LOGGER.debug(e1.getMessage(), e1);
          }
        }
      } catch (ClassNotFoundException | IOException e) {
        LOGGER.debug(e.getMessage(), e);
      }
    }

  }

  private static Class[] getClasses(String packageName) throws ClassNotFoundException, IOException {

    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    assert classLoader != null;
    String path = packageName.replace('.', '/');
    Enumeration<URL> resources = classLoader.getResources(path);
    List<File> dirs = new ArrayList<>();
    while (resources.hasMoreElements()) {
      URL resource = resources.nextElement();
      dirs.add(new File(resource.getFile()));
    }
    List<Class<?>> classes = new ArrayList<>();
    for (File directory : dirs) {
      classes.addAll(findClasses(directory, packageName));
    }
    return classes.toArray(new Class[classes.size()]);

  }

  private static List<Class<?>> findClasses(File directory, String packageName)
      throws ClassNotFoundException {

    List<Class<?>> classes = new ArrayList<>();
    if (!directory.exists()) {
      return classes;
    }
    File[] files = directory.listFiles();
    if (files != null && files.length > 0) {
      for (File file : files) {
        if (file.isDirectory()) {
          assert !file.getName().contains(".");
          classes.addAll(findClasses(file, packageName + "." + file.getName()));
        } else if (file.getName().endsWith(".class")) {
          classes.add(Class.forName(
              packageName + '.' + file.getName().substring(0, file.getName().length() - 6)));
        }
      }
    }
    return classes;
  }

}
