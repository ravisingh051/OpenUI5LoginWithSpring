package com.adapt.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.adapt.file.entity.MessageType;
import com.alight.adapt.datasets.acaftedata.v1.ProcessorAcaFteDataset;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { MessageTypeConfigHelper.class })
@TestPropertySource(properties = { "censusDatasets.url=1", "censusDatasets.url=1",
    "wellnessProgramDatasets.url=1", "dependentVerificationDataset=1", "acaFteDatasets.url=1",
    "acaFteHoursDatasets.url=1", "acaIndividualEinDatasets.url=1", "employerMandateDatasets.url=1",
    "retireeLengthOfServiceDatase=1", "acaOther1Datasets.url=1", "acaOther3Datasets.url=1",
    "pensionPaymentsDatasets.url=1", "addressSyncDatasets.url=1", "udfDatasets.url=1",
    "eoiDecisionsDatasets.url=1", "electionDatasets.url=1", "coreTransactionDatasets.url=1" })
public class MessageTypeConfigHelperTest {

  @Test
  public void testMessageTypeConfiguration() throws Exception {

    MessageTypeConfig messageTypeConfig = MessageTypeConfigHelper
        .getMessageTypeConfiguration(MessageType.INBOUND_ACA_FTE_DATASET);

    assertNotNull(messageTypeConfig.getEndPoint());
    assertEquals(MessageType.INBOUND_ACA_FTE_DATASET, messageTypeConfig.getMessageType());
    assertEquals(messageTypeConfig.getDatasetTransformerClazz(), ProcessorAcaFteDataset.class);
  }

  @Test
  public void testMessageTypeConfigurationBuilderToString() throws Exception {

    assertNotNull(MessageTypeConfig.builder().toString());

  }

}
