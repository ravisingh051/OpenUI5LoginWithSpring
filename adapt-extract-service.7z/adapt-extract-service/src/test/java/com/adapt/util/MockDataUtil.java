package com.adapt.util;

import com.adapt.api.config.ExtractionHelper;
import com.adapt.api.config.domain.JobFileWithMultiEmployerEntity;
import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.config.Constant;
import com.adapt.file.entity.Attribute;
import com.adapt.file.entity.Attributes;
import com.adapt.file.entity.EmployerInfo;
import com.adapt.file.entity.FileModel;
import com.adapt.file.entity.FileOutBoundModel;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.entity.MessageFormat;
import com.adapt.file.entity.MessageFormatType;
import com.adapt.file.entity.MessageType;
import com.adapt.file.entity.Section;
import com.adapt.file.entity.Section.SectionType;
import com.adapt.file.entity.SectionAttributeEntity;
import com.alight.adapt.dataextraction.transaction.v1.models.CoveredDependentInfo;
import com.alight.adapt.dataextraction.transaction.v1.models.DependentInfo;
import com.alight.adapt.dataextraction.transaction.v1.models.EmployeeElectionInfo;
import com.alight.adapt.dataextraction.transaction.v1.models.TransactionDataset;
import com.alight.adapt.dataextraction.transaction.v1.models.TransactionEmployeeInfo;
import com.alight.adapt.dataextraction.transaction.v1.models.TransactionPersonInfo;
import com.alight.adapt.datasets.AbstractDataset;
import com.alight.adapt.datasets.RuleFailure;
import com.alight.adapt.datasets.acaftedata.v1.ProcessorAcaFteDataset;
import com.alight.adapt.header.AdaptHeader;
import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class MockDataUtil {

  /**
   * Builds the job file entity.
   *
   * @return the job file entity
   */
  public static JobFileEntity buildJobFileEntity() {
    JobFileEntity jobFileEntity = new JobFileEntity();

    jobFileEntity.setErrorThreshHold(5);
    jobFileEntity.setEscapeCharacter("%");
    jobFileEntity.setExpectedDate(new Date(Calendar.getInstance().getTimeInMillis()));
    jobFileEntity.setFieldDelimiter("|");
    jobFileEntity.setFileFormatName("FILE_DELIMITED");
    // jobFileEntity.setFileId(55);
    jobFileEntity.setFileTransmissionName("test.txt");
    jobFileEntity.setFileType(MessageType.INBOUND_CENSUS.getValue());
    // jobFileEntity.setFileVersion(1);
    jobFileEntity.setJobId(12);
    jobFileEntity.setFileMinRecordCountAllowed(5);
    jobFileEntity.setPriority(5);
    jobFileEntity.setRowDelimiter("rowDelimiter");
    jobFileEntity.setSegmentDelimiter("segmentDelimiter");
    jobFileEntity.setEmployerIdAndClientIds("3007::02871");
    jobFileEntity.setFullOrChange(1);
    jobFileEntity.setResultsMode(0);
    jobFileEntity.setFileMaxRecordCountAllowed(50);
    jobFileEntity.setFileProcessingErrorThresholdFormat("NONE");
    jobFileEntity.setCloneNumberList("");
    List<SectionAttributeEntity> sectionAttributeEntities = new ArrayList<>();
    jobFileEntity.setSectionAttributeEntities(sectionAttributeEntities);
    SectionAttributeEntity sectionAttributeEntity = new SectionAttributeEntity();
    sectionAttributeEntities.add(sectionAttributeEntity);
    sectionAttributeEntity.setAttributeDataType("java.lang.String");
    sectionAttributeEntity.setIsAttributeMandatory(true);
    sectionAttributeEntity.setOrder(2);
    sectionAttributeEntity.setSectionDelimiter("sectionDelimiter");
    sectionAttributeEntity.setSectionType("HEADER");
    sectionAttributeEntity.setStandardizedName("firstName");
    sectionAttributeEntities.add(sectionAttributeEntity);
    return jobFileEntity;
  }

  /**
   * Builds the job file entity.
   *
   * @return the job file entity
   */
  public static JobFilePriorityEntity buildJobFilePriorityEntity() {
    JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();

    jobFilePriorityEntity.setErrorThreshHold(5);
    jobFilePriorityEntity.setEscapeCharacter("%");
    jobFilePriorityEntity.setExpectedDate(new Date(Calendar.getInstance().getTimeInMillis()));
    jobFilePriorityEntity.setFieldDelimiter("|");
    jobFilePriorityEntity.setFileFormatName("FILE_DELIMITED");
    // jobFileEntity.setFileId(55);
    jobFilePriorityEntity.setFileTransmissionName("test.txt");
    jobFilePriorityEntity.setFileType(MessageType.INBOUND_CENSUS.getValue());
    // jobFileEntity.setFileVersion(1);
    jobFilePriorityEntity.setJobId(12);
    jobFilePriorityEntity.setFileMinRecordCountAllowed(5);
    jobFilePriorityEntity.setPriority(5);
    jobFilePriorityEntity.setRowDelimiter("rowDelimiter");
    jobFilePriorityEntity.setSegmentDelimiter("segmentDelimiter");
    jobFilePriorityEntity.setEmployerIdAndClientIdAndTestCfgs("3007::02871::testcfg");
    jobFilePriorityEntity.setFullOrChange(1);
    jobFilePriorityEntity.setResultsMode(0);
    jobFilePriorityEntity.setFileMaxRecordCountAllowed(50);
    jobFilePriorityEntity.setFileProcessingErrorThresholdFormat("NONE");
    jobFilePriorityEntity.setCloneNumberList("");
    jobFilePriorityEntity.setExtractionEmployerIds("3007");
    jobFilePriorityEntity.setPlanSubtypes("1001");
    jobFilePriorityEntity.setPlanYear(2020);

    List<SectionAttributeEntity> sectionAttributeEntities = new ArrayList<>();
    jobFilePriorityEntity.setSectionAttributeEntities(sectionAttributeEntities);
    SectionAttributeEntity sectionAttributeEntity = new SectionAttributeEntity();
    sectionAttributeEntities.add(sectionAttributeEntity);
    sectionAttributeEntity.setAttributeDataType("java.lang.String");
    sectionAttributeEntity.setIsAttributeMandatory(true);
    sectionAttributeEntity.setOrder(2);
    sectionAttributeEntity.setSectionDelimiter("sectionDelimiter");
    sectionAttributeEntity.setSectionType("HEADER");
    sectionAttributeEntity.setStandardizedName("firstName");
    sectionAttributeEntities.add(sectionAttributeEntity);
    jobFilePriorityEntity.setDirection("Inbound");
    return jobFilePriorityEntity;
  }

  /**
   * Builds the delimited job model.
   *
   * @return the job model
   */
  public static JobModel buildDelimitedJobModel() {
    JobModel jobModel = new JobModel();
    jobModel.setExpectedDate(LocalDate.now());
    FileModel fileModel = new FileModel();
    fileModel.setErrorThreshold(5);
    fileModel.setFileIdentifier(5);
    fileModel.setFileTransmissionName("test.txt");
    fileModel.setFileType(MessageType.INBOUND_CENSUS);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.NONE);
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter("|");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_DELIMITED);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("dontknow");
    fileModel.setMessageFormat(messageFormat);
    fileModel.setFileMinRecordCountAllowed(5);
    fileModel.setFileMaxRecordCountAllowed(50);
    List<Section> sections = new ArrayList<>();
    // detail
    Section section = new Section();
    sections.add(section);
    List<Attribute> attributList = new ArrayList<Attribute>();
    Attribute attributeFirstName = new Attribute();
    attributList.add(attributeFirstName);
    attributeFirstName.setDatatype("java.lang.String");
    attributeFirstName.setOrder(6);
    attributeFirstName.setRequired(true);
    attributeFirstName.setStandardizedName("firstName");

    Attributes attributes = new Attributes();
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.DETAIL);
    // header
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    Attribute attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined1");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.HEADER);
    // footer
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined2");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.TRAILER);

    fileModel.setSections(sections);
    jobModel.setFileModel(fileModel);
    jobModel.setJobId(1);
    jobModel.setPriority(5);
    jobModel.setEmployerId(1);
    jobModel.setCloneNumberList(Arrays.asList(1, 2));
    jobModel.setSourceType(Constant.SOURCE_TYPE_FILE_DEL);
    jobModel.setTargetType(Constant.SOURCE_TYPE_API);
    return jobModel;
  }

  /**
   * Builds the delimited job model.
   *
   * @return the job model
   */
  public static JobModel buildDelimitedJobModelWithCommaDelimiter() {
    JobModel jobModel = new JobModel();
    jobModel.setExpectedDate(LocalDate.now());
    FileModel fileModel = new FileModel();
    fileModel.setErrorThreshold(5);
    fileModel.setFileIdentifier(5);
    fileModel.setFileTransmissionName("test.txt");
    fileModel.setFileType(MessageType.INBOUND_CENSUS);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.NONE);
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter(",");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_DELIMITED);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("dontknow");
    fileModel.setMessageFormat(messageFormat);
    fileModel.setFileMinRecordCountAllowed(5);
    fileModel.setFileMaxRecordCountAllowed(50);
    List<Section> sections = new ArrayList<>();
    // detail
    Section section = new Section();
    sections.add(section);
    List<Attribute> attributList = new ArrayList<Attribute>();
    Attribute attributeFirstName = new Attribute();
    attributList.add(attributeFirstName);
    attributeFirstName.setDatatype("java.lang.String");
    attributeFirstName.setOrder(6);
    attributeFirstName.setRequired(true);
    attributeFirstName.setStandardizedName("firstName");
    Attribute attributeAddress = new Attribute();
    attributList.add(attributeAddress);
    attributeAddress.setDatatype("java.lang.String");
    attributeAddress.setOrder(13);
    attributeAddress.setRequired(true);
    attributeAddress.setStandardizedName("addressLine1");

    Attributes attributes = new Attributes();
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.DETAIL);
    // header
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    Attribute attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined1");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.HEADER);
    // footer
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined2");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.TRAILER);

    fileModel.setSections(sections);
    jobModel.setFileModel(fileModel);
    jobModel.setJobId(1);
    jobModel.setPriority(5);
    jobModel.setEmployerId(1);
    jobModel.setCloneNumberList(Arrays.asList(1, 2));
    return jobModel;
  }

  /**
   * BuildDelimitedJobModelWithEscapeDelimiter method.
   * 
   * @return JobModel
   */
  public static JobModel buildDelimitedJobModelWithEscapeDelimiter() {
    JobModel jobModel = new JobModel();
    jobModel.setExpectedDate(LocalDate.now());
    FileModel fileModel = new FileModel();
    fileModel.setErrorThreshold(5);
    fileModel.setFileIdentifier(5);
    fileModel.setFileTransmissionName("test.txt");
    fileModel.setFileType(MessageType.INBOUND_CENSUS);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.NONE);
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter("~");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_DELIMITED);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("dontknow");
    fileModel.setMessageFormat(messageFormat);
    fileModel.setFileMinRecordCountAllowed(5);
    fileModel.setFileMaxRecordCountAllowed(50);
    List<Section> sections = new ArrayList<>();
    Section section = new Section();
    sections.add(section);
    List<Attribute> attributList = new ArrayList<Attribute>();
    Attribute attributeFirstName = new Attribute();
    attributList.add(attributeFirstName);
    attributeFirstName.setDatatype("java.lang.String");
    attributeFirstName.setOrder(6);
    attributeFirstName.setRequired(true);
    attributeFirstName.setStandardizedName("firstName");
    Attribute attributeAddress = new Attribute();
    attributList.add(attributeAddress);
    attributeAddress.setDatatype("java.lang.String");
    attributeAddress.setOrder(13);
    attributeAddress.setRequired(true);
    attributeAddress.setStandardizedName("addressLine1");

    Attributes attributes = new Attributes();
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.DETAIL);
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    Attribute attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined1");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.HEADER);
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined2");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.TRAILER);
    fileModel.setSections(sections);
    jobModel.setFileModel(fileModel);
    jobModel.setJobId(1);
    jobModel.setPriority(5);
    jobModel.setEmployerId(1);
    jobModel.setCloneNumberList(Arrays.asList(1, 2));
    return jobModel;
  }

  /**
   * BuildDelimitedJobModelWithDollarDelimiter method.
   * 
   * @return
   */
  public static JobModel buildDelimitedJobModelWithDollarDelimiter() {
    JobModel jobModel = new JobModel();
    jobModel.setExpectedDate(LocalDate.now());
    FileModel fileModel = new FileModel();
    fileModel.setErrorThreshold(5);
    fileModel.setFileIdentifier(5);
    fileModel.setFileTransmissionName("test.txt");
    fileModel.setFileType(MessageType.INBOUND_CENSUS);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.NONE);
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter("$");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_DELIMITED);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("dontknow");
    fileModel.setMessageFormat(messageFormat);
    fileModel.setFileMinRecordCountAllowed(5);
    fileModel.setFileMaxRecordCountAllowed(50);
    List<Section> sections = new ArrayList<>();
    Section section = new Section();
    sections.add(section);
    List<Attribute> attributList = new ArrayList<Attribute>();
    Attribute attributeFirstName = new Attribute();
    attributList.add(attributeFirstName);
    attributeFirstName.setDatatype("java.lang.String");
    attributeFirstName.setOrder(6);
    attributeFirstName.setRequired(true);
    attributeFirstName.setStandardizedName("firstName");
    Attribute attributeAddress = new Attribute();
    attributList.add(attributeAddress);
    attributeAddress.setDatatype("java.lang.String");
    attributeAddress.setOrder(13);
    attributeAddress.setRequired(true);
    attributeAddress.setStandardizedName("addressLine1");
    Attributes attributes = new Attributes();
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.DETAIL);
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    Attribute attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined1");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.HEADER);
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined2");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.TRAILER);
    fileModel.setSections(sections);
    jobModel.setFileModel(fileModel);
    jobModel.setJobId(1);
    jobModel.setPriority(5);
    jobModel.setEmployerId(1);
    jobModel.setCloneNumberList(Arrays.asList(1, 2));
    return jobModel;
  }

  /**
   * Builds the delimited job model withoutEmployer.
   *
   * @return the job model
   */
  public static JobModel buildDelimitedJobModelNoEmployer() {
    JobModel jobModel = buildDelimitedJobModel();
    jobModel.setEmployerId(null);
    return jobModel;
  }

  /**
   * Builds the fixed width job model.
   *
   * @return the job model
   */
  public static JobModel buildFixedWidthJobModel() {
    JobModel jobModel = new JobModel();
    jobModel.setExpectedDate(LocalDate.now());
    FileModel fileModel = new FileModel();
    fileModel.setErrorThreshold(5);
    // fileModel.setFileId(5);
    fileModel.setFileTransmissionName("test.txt");
    fileModel.setFileType(MessageType.INBOUND_CENSUS);
    // fileModel.setFileVersion(2);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter("|");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_FIXED_WIDTH);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("dontknow");
    fileModel.setMessageFormat(messageFormat);
    fileModel.setFileMinRecordCountAllowed(5);
    fileModel.setFileMaxRecordCountAllowed(50);
    List<Section> sections = new ArrayList<>();
    // detail
    Section section = new Section();
    sections.add(section);
    List<Attribute> attributList = new ArrayList<Attribute>();
    Attribute attributeFirstName = new Attribute();
    attributList.add(attributeFirstName);
    attributeFirstName.setDatatype("java.lang.String");
    attributeFirstName.setOrder(6);
    attributeFirstName.setRequired(true);
    attributeFirstName.setStandardizedName("firstName");
    attributeFirstName.setAttributeStartPosition(110);
    attributeFirstName.setAttributeEndPosition(159);
    Attributes attributes = new Attributes();
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.DETAIL);
    // header
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    Attribute attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setStandardizedName("customDefined1");
    attributeRecordType.setAttributeStartPosition(1);
    attributeRecordType.setAttributeEndPosition(2);
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.HEADER);
    // footer
    section = new Section();
    sections.add(section);
    attributes = new Attributes();
    attributList = new ArrayList<Attribute>();
    attributeRecordType = new Attribute();
    attributList.add(attributeRecordType);
    attributeRecordType.setDatatype("java.lang.String");
    attributeRecordType.setOrder(1);
    attributeRecordType.setRequired(true);
    attributeRecordType.setAttributeStartPosition(1);
    attributeRecordType.setAttributeEndPosition(2);
    attributeRecordType.setStandardizedName("customDefined2");
    attributes.setAttributeList(attributList);
    section.setAttributes(attributes);
    section.setSectionDelimiter("dontknow");
    section.setSectionType(SectionType.TRAILER);

    fileModel.setSections(sections);
    jobModel.setFileModel(fileModel);
    jobModel.setJobId(1);
    jobModel.setPriority(5);
    jobModel.setEmployerId(1);
    jobModel.setSourceType(Constant.SOURCE_TYPE_FILE_FIX);
    jobModel.setTargetType(Constant.SOURCE_TYPE_API);
    return jobModel;
  }

  /**
   * Builds the census attributes map.
   *
   * @return the map
   */
  public static Map<String, Object> buildCensusDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("addressLine1", "Address Line 1");
    map.put("addressLine2", "Address Line 2");
    map.put("addressLine3", "    Address Line 3   ");
    map.put("alternateAddress1", "    Alternate Address 1");
    map.put("alternateAddress2", "Alternate Address 2   ");
    map.put("addressChangeDate", LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    return map;
  }

  /**
   * Builds the DependentVerification attributes map.
   *
   * @return the map
   */
  public static Map<String, Object> buildDependentVerificationDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    // map.put("employerId", "33"); employerId is set from job details object
    map.put("employeeId", 55);
    map.put("dependentId", 1);
    map.put("verificationFlag", "Verification Flag");
    map.put("verificationReasonCode", "Verification Reason Code");
    map.put("statusMssage", "Verification Status");
    map.put("verificationStatus", 0);
    map.put("verificationComment", "Verification Status");
    map.put("verificationType", 55);
    map.put("verificationUpdateDate", "Verification Update Date");
    map.put("verificationTerminationDate", "verification Termination Date");
    return map;
  }

  /**
   * Builds the ACA FTE attributes map.
   *
   * @return the map
   */
  public static Map<String, Object> buildAcaFteDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("employeeId", "1");
    map.put("reportingYear", "2018");
    map.put("fteMonth", "Aug");
    map.put("fteStatus", "Approved");
    return map;
  }

  /**
   * Builds the Failed map.
   *
   * @return the map
   */
  public static Map<String, Object> buildFailedMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("failedDataType", "test");

    return map;
  }

  /**
   * Builds the ACA FTE Hours attributes map.
   *
   * @return the map
   */
  public static Map<String, Object> buildAcaFteHoursDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("employeeId", "1");
    map.put("reportingYear", "2018");
    map.put("hoursType", "Aug");
    map.put("payFrequency", "Approved");
    return map;
  }

  /**
   * Builds the ACA Individual Ein attributes map.
   *
   * @return the map
   */
  public static Map<String, Object> buildAcaIndividualEinDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("employeeId", "1");
    map.put("reportingYear", "2018");
    map.put("einMonth", "Aug");
    map.put("einForMonth", "Approved");
    return map;
  }

  /**
   * Builds the job file entity db data.
   *
   * @return the list
   */
  public static List<Object[]> buildJobFileEntityDbData() {
    List<Object> dbDataList = new ArrayList<>();
    dbDataList.add(12);
    dbDataList.add(new Date(Calendar.getInstance().getTimeInMillis()));
    dbDataList.add(5);
    dbDataList.add(null);
    dbDataList.add("test.txt");
    dbDataList.add(MessageType.INBOUND_CENSUS.getValue());
    dbDataList.add(MessageFormatType.FILE_DELIMITED.getValue());
    dbDataList.add("\n");
    dbDataList.add("|");
    dbDataList.add("\n");
    dbDataList.add("dontknow");
    dbDataList.add(5);
    dbDataList.add("3007::02871");
    dbDataList.add(1);
    dbDataList.add(1);
    dbDataList.add(1);
    dbDataList.add(0);
    dbDataList.add("testCfgConfig");
    dbDataList.add(10);
    dbDataList.add("PERCENTAGE");
    dbDataList.add(1);
    dbDataList.add(1);
    dbDataList.add(1);
    dbDataList.add("");
    Object[] objects = dbDataList.toArray(new Object[dbDataList.size()]);
    return Collections.singletonList(objects);
  }

  /**
   * Builds the section attribute entity db data.
   *
   * @return the list
   */
  public static List<Object[]> buildSectionAttributeEntityDbData() {
    List<Object> dbDataList = new ArrayList<>();
    dbDataList.add("TEST_STANDARDIZED_NAME");
    dbDataList.add("java.lang.String");
    dbDataList.add(1);
    dbDataList.add("DETAIL");
    dbDataList.add((short) 1);
    dbDataList.add(Boolean.TRUE);
    dbDataList.add(null);
    dbDataList.add(Boolean.TRUE);
    dbDataList.add(10);
    dbDataList.add(1);
    dbDataList.add(10);
    Object[] objects = dbDataList.toArray(new Object[dbDataList.size()]);

    return Collections.singletonList(objects);
  }

  /**
   * Gets the error handler header map.
   *
   * @return the error handler header map
   */
  public static Map<String, Object> getErrorHandlerHeaderMap() {
    Map<String, Object> properties = new HashMap<>();
    properties.put(Constant.JOB_ID_HEADER, "1");
    properties.put(Constant.FILE_IDENTIFIER, "1");
    properties.put(Constant.SEQUENCE_NUMBER_HEADER, "1");
    properties.put(Constant.SEQUENCE_SIZE_HEADER, "4");
    properties.put(Constant.ORIGINAL_FILE_NAME_HEADER, "test.txt");
    return properties;
  }

  /**
   * Builds the source instance info db data.
   *
   * @return the list
   */
  public static List<Object[]> buildSourceInstanceInfoDbData() {
    List<Object> dbDataList = new ArrayList<>();
    dbDataList.add("P");
    dbDataList.add("L4DWITDB6247");
    dbDataList.add("[eed_erassigned_id]");

    Object[] objects = dbDataList.toArray(new Object[dbDataList.size()]);

    return Collections.singletonList(objects);
  }

  /**
   * Builds the enrichment api info db data.
   *
   * @return the list
   */
  public static List<Object[]> buildEnrichmentApiInfoDbData() {
    List<Object> dbDataList = new ArrayList<>();
    dbDataList.add("Person");
    dbDataList.add("/CbaAdaptDataService/api/v1/cba/AdaptPersons");

    Object[] objects = dbDataList.toArray(new Object[dbDataList.size()]);

    return Collections.singletonList(objects);
  }

  /**
   * BuildEmployerMandateDatasetMap Method.
   *
   * @return Map of String,Object
   */
  public static Map<String, Object> buildEmployerMandateDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("hoursStartDate", "2018-01-01");
    map.put("hoursEndDate", "2018-01-31");
    map.put("periodCreditableHours", 100.0);
    return map;
  }

  /**
   * BuildRetireeLengthOfServiceDatasetMap Method.
   *
   * @return Map of String,Object
   */
  public static Map<String, Object> buildRetireeLengthOfServiceDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("firstName", "Shivang");
    map.put("lastName", "Modi");
    map.put("healthServiceCredit1", 100.0);
    return map;
  }

  /**
   * BuildAcaOther1DatasetMap Method.
   *
   * @return Map of String,Object
   */
  public static Map<String, Object> buildAcaOther1DatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("employeeName", "Shivang");
    map.put("addressLine1", "Memnagar");
    map.put("city", "Ahmedabad");
    map.put("country", "India");
    return map;
  }

  /**
   * BuildAcaOther3DatasetMap Method.
   *
   * @return Map of String,Object
   */
  public static Map<String, Object> buildAcaOther3DatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("coverageMonth", "10");
    map.put("coverageYear", "2018");
    map.put("nameOfCoveredIndividual", "Shivang");
    return map;
  }

  /**
   * Builds the pension payments dataset map.
   *
   * @return the map
   */
  public static Map<String, Object> buildPensionPaymentsDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("firstName", "Shivang");
    map.put("lastName", "Modi");
    map.put("paymentInstructionDate", "2018-01-01");
    return map;
  }

  /**
   * Builds the address sync dataset map.
   *
   * @return the map
   */
  public static Map<String, Object> buildAddressSyncDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    map.put("city", "Ahmedabad");
    map.put("addressLine1", "Drive In Road");
    map.put("addressLine2", "Memnagar");
    return map;
  }

  /**
   * BuildUdfDatasetMap Method.
   * 
   * @return map of String,Object
   */
  public static Map<String, Object> buildUdfDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    return map;
  }

  /**
   * BuildWellnessProgramDatasetMap Method.
   * 
   * @return map of String,Object
   */
  public static Map<String, Object> buildWellnessProgramDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    return map;
  }

  /**
   * BuildEoiDecisionsDatasetMap Method.
   * 
   * @return map of String,Object
   */
  public static Map<String, Object> buildEoiDecisionsDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    return map;
  }

  /**
   * BuildElectionDatasetMap Method.
   * 
   * @return map of String,Object
   */
  public static Map<String, Object> buildElectionDatasetMap() {
    Map<String, Object> map = new HashMap<>();
    map.put("socialSecurityNumber", "123456789");
    return map;
  }

  /**
   * BuildAceAbstractAllDataSet Method.
   * 
   * @return List of AbstractDataset
   */
  public static List<AbstractDataset> buildAceAbstractAllDataSet() {
    List<AbstractDataset> abstractDatasetList = new ArrayList<AbstractDataset>();

    ProcessorAcaFteDataset acaFteSucess = new ProcessorAcaFteDataset();
    acaFteSucess.setSocialSecurityNumber("123456789");
    acaFteSucess.setEmployeeId("1");

    abstractDatasetList.add(acaFteSucess);
    List<RuleFailure> ruleFailureList = new ArrayList<RuleFailure>(0);
    RuleFailure ruleFailure = new RuleFailure();
    ruleFailure.setError(true);
    ruleFailure.setErrorDescription("ERROR");
    ruleFailureList.add(ruleFailure);

    ProcessorAcaFteDataset acaFteError = new ProcessorAcaFteDataset();
    acaFteError.setRuleFailures(ruleFailureList);
    abstractDatasetList.add(acaFteError);

    return abstractDatasetList;
  }

  /**
   * Builds the ace abstract failed data set.
   *
   * @return the list
   */
  public static List<AbstractDataset> buildAceAbstractFailedDataSet() {

    List<RuleFailure> ruleFailureList = new ArrayList<RuleFailure>(0);
    RuleFailure ruleFailure = new RuleFailure();
    ruleFailure.setError(true);
    ruleFailure.setErrorDescription("ERROR");
    ruleFailureList.add(ruleFailure);

    ProcessorAcaFteDataset acaFteError = new ProcessorAcaFteDataset();
    acaFteError.setRuleFailures(ruleFailureList);

    List<AbstractDataset> abstractDatasetList = new ArrayList<AbstractDataset>();
    abstractDatasetList.add(acaFteError);

    return abstractDatasetList;
  }

  /**
   * Builds the job model multi employer.
   *
   * @return the job model multi employer
   */
  public static JobModelMultiEmployer buildJobModelMultiEmployer() {
    JobModelMultiEmployer jobModelMultiEmployer = new JobModelMultiEmployer();
    jobModelMultiEmployer.setJobId(2010);
    jobModelMultiEmployer.setFullOrChange(false);
    jobModelMultiEmployer.setPriority(5);
    jobModelMultiEmployer.setFileOutBoundModel(new FileOutBoundModel());
    jobModelMultiEmployer.getFileOutBoundModel().setFileIdentifier(12);
    jobModelMultiEmployer.getFileOutBoundModel().setFileType(MessageType.OUTBOUND_CORE_T);
    jobModelMultiEmployer.getFileOutBoundModel().setMasterFileTemplateId(1);
    jobModelMultiEmployer.getFileOutBoundModel().setMasterFileTemplateVersion(1);
    jobModelMultiEmployer.getFileOutBoundModel()
        .setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.PERCENTAGE);
    List<EmployerInfo> employerInfoList = new ArrayList<EmployerInfo>();
    {
      EmployerInfo employerInfo = new EmployerInfo();
      employerInfo.setClientId("3007client1");
      employerInfo.setEmployerId(3007);
      employerInfo.setTestCfg("testConfig");
      employerInfoList.add(employerInfo);
    }
    {
      EmployerInfo employerInfo = new EmployerInfo();
      employerInfo.setClientId("3007client2");
      employerInfo.setEmployerId(3002);
      employerInfo.setTestCfg("testConfig");
      employerInfoList.add(employerInfo);
    }
    jobModelMultiEmployer.setEmployerInfoList(employerInfoList);
    jobModelMultiEmployer.setExtractionParameters(new HashMap<>());
    jobModelMultiEmployer.getExtractionParameters().put(ExtractionHelper.EMPLOYER_IDS,
        Arrays.asList("3002"));
    jobModelMultiEmployer.getExtractionParameters().put(ExtractionHelper.PLAN_YEAR, 2020);
    jobModelMultiEmployer.getExtractionParameters().put(ExtractionHelper.PLAN_SUBTYPES,
        Arrays.asList("Health - Medical", "Health - Dental", "Health - Vision"));
    return jobModelMultiEmployer;
  }

  /**
   * Builds the core transaction extraction details.
   *
   * @return the core transaction extraction details
   */
  public static TransactionExtractionDetails buildCoreTransactionExtractionDetails() {
    TransactionExtractionDetails coreTransactionExtractionDetails = new TransactionExtractionDetails();
    coreTransactionExtractionDetails.setExtractionCount(1500L);
    coreTransactionExtractionDetails.setPlanSubtypes("1001");
    coreTransactionExtractionDetails.setPlanYear(2020);
    return coreTransactionExtractionDetails;
  }

  /**
   * Builds the job file with multi employer entity.
   *
   * @return the job file with multi employer entity
   */
  public static JobFileWithMultiEmployerEntity buildJobFileWithMultiEmployerEntity() {
    JobFileWithMultiEmployerEntity jobFileWithMultiEmployerEntity = new JobFileWithMultiEmployerEntity();
    jobFileWithMultiEmployerEntity.setErrorThreshHold(5);
    jobFileWithMultiEmployerEntity.setEscapeCharacter("%");
    jobFileWithMultiEmployerEntity
        .setExpectedDate(new Date(Calendar.getInstance().getTimeInMillis()));
    jobFileWithMultiEmployerEntity.setFieldDelimiter("|");
    jobFileWithMultiEmployerEntity.setFileFormatName("FILE_DELIMITED");
    jobFileWithMultiEmployerEntity.setFileId(55);
    jobFileWithMultiEmployerEntity.setFileTransmissionName("test.txt");
    jobFileWithMultiEmployerEntity.setFileType(MessageType.INBOUND_CENSUS.getValue());
    jobFileWithMultiEmployerEntity.setFileVersion(1);
    jobFileWithMultiEmployerEntity.setJobId(12);
    jobFileWithMultiEmployerEntity.setFileMinRecordCountAllowed(5);
    jobFileWithMultiEmployerEntity.setPriority(5);
    jobFileWithMultiEmployerEntity.setRowDelimiter("rowDelimiter");
    jobFileWithMultiEmployerEntity.setSegmentDelimiter("segmentDelimiter");
    jobFileWithMultiEmployerEntity
        .setEmployerIdAndClientIdsAnsTestCfg("3007::02871::testcfg,4207::45834::testcfg2");
    jobFileWithMultiEmployerEntity.setExtractionEmployerIds("3007");
    jobFileWithMultiEmployerEntity.setCarriers("carriers");
    jobFileWithMultiEmployerEntity.setPlanSubtypes("planSubtypes");
    jobFileWithMultiEmployerEntity.setPlanStartDate("2018-11-06");
    jobFileWithMultiEmployerEntity.setPlanEndDate("2018-12-12");
    jobFileWithMultiEmployerEntity.setFullOrChange(1);
    jobFileWithMultiEmployerEntity.setResultsMode(0);
    jobFileWithMultiEmployerEntity.setFileMaxRecordCountAllowed(50);
    jobFileWithMultiEmployerEntity.setFileProcessingErrorThresholdFormat("NONE");
    return jobFileWithMultiEmployerEntity;
  }

  /**
   * Builds the job file with multi employer entity db data.
   *
   * @return the list
   */
  public static List<Object[]> buildJobFileWithMultiEmployerEntityDbData() {
    List<Object> dbDataList = new ArrayList<>();
    dbDataList.add(1412);
    dbDataList.add(new Date(Calendar.getInstance().getTimeInMillis()));
    dbDataList.add(0);
    dbDataList.add(0);
    dbDataList.add("outfile4.txt");
    dbDataList.add("OUTBOUND_CORE_T");
    dbDataList.add("FILE_DELIMITED");
    dbDataList.add("\n");
    dbDataList.add("|");
    dbDataList.add(null);
    dbDataList.add(null);
    dbDataList.add(5);
    dbDataList.add("1059::15596::qawq,25::12374::qawq,4055::12661::qawq");
    dbDataList.add(2);
    dbDataList.add(1);
    dbDataList.add(1);
    dbDataList.add(0);
    dbDataList.add(0);
    dbDataList.add("NONE");
    dbDataList.add(759);
    dbDataList.add(278);
    dbDataList.add(1);
    dbDataList.add("Accident Insurance,Health - Medical,Health - Rx,Supplemental AD&D");
    dbDataList.add("2018 - 10 - 02");
    dbDataList.add("2018 - 10 - 26");
    dbDataList.add("25, 4055");
    dbDataList.add("Health Equity");
    Object[] objects = dbDataList.toArray(new Object[dbDataList.size()]);
    return Collections.singletonList(objects);
  }

  /**
   * Gets the drools business rules decision table result set.
   *
   * @return the drools business rules decision table result set
   */
  public static List<Object[]> getDroolsBusinessRulesDecisionTableResultSet() {
    Object[] objects = new Object[] { 1, 1, "this is rule string", false, 1 };
    List<Object[]> list = new ArrayList<>();
    list.add(objects);
    return list;
  }

  /**
   * Generate transaction dataset.
   *
   * @return the transaction dataset
   */
  public static TransactionDataset generateTransactionDataset() {
    TransactionDataset transactionDataset = new TransactionDataset();
    TransactionEmployeeInfo transactionEmployeeInfo = new TransactionEmployeeInfo();
    transactionDataset.setEmployee(transactionEmployeeInfo);
    transactionEmployeeInfo.setTransactionPersonInfo(new TransactionPersonInfo());
    transactionEmployeeInfo.setInternalEmployeeId(1);

    transactionDataset.getEmployee().setInternalEmployeeId(1);
    transactionDataset.getEmployee().setInternalEmployeeId(1);
    transactionDataset.getEmployee().setSourceInstance("QAP2");
    transactionEmployeeInfo.getTransactionPersonInfo().setAddressLine1("addressLine1");
    transactionEmployeeInfo.getTransactionPersonInfo().setFirstName("John");
    transactionEmployeeInfo.getTransactionPersonInfo().setLastName("Doe");
    transactionEmployeeInfo.getTransactionPersonInfo()
        .setSocialSecurityNumber("socialSecurityNumber");
    transactionEmployeeInfo.getTransactionPersonInfo().setPersonId(1);

    transactionEmployeeInfo.setOriginalHireDate("02-18-2019");

    DependentInfo dependentInfoLindsey = new DependentInfo();
    dependentInfoLindsey.setDependentId(1);
    dependentInfoLindsey.setDependentStatus("dependentStatus-Lindsey");
    dependentInfoLindsey.setTransactionPersonInfo(new TransactionPersonInfo());
    dependentInfoLindsey.getTransactionPersonInfo().setFirstName("Lindsey");
    dependentInfoLindsey.getTransactionPersonInfo().setLastName("Doe");

    DependentInfo dependentInfoNeel = new DependentInfo();
    dependentInfoNeel.setDependentId(2);
    dependentInfoNeel.setDependentStatus("dependentStatus-Neel");
    dependentInfoNeel.setTransactionPersonInfo(new TransactionPersonInfo());
    dependentInfoNeel.getTransactionPersonInfo().setFirstName("Neel");
    dependentInfoNeel.getTransactionPersonInfo().setLastName("Doe");

    DependentInfo dependentInfoUnknown = new DependentInfo();
    dependentInfoUnknown.setDependentId(3);
    dependentInfoUnknown.setDependentStatus("dependentStatus-Unknown");
    dependentInfoUnknown.setTransactionPersonInfo(new TransactionPersonInfo());
    dependentInfoUnknown.getTransactionPersonInfo().setFirstName("Unknown");
    dependentInfoUnknown.getTransactionPersonInfo().setLastName("Doe");

    EmployeeElectionInfo workerElectionInfo1 = new EmployeeElectionInfo();
    workerElectionInfo1.setElectionEeId(1);
    workerElectionInfo1.setEmployeeElectionId(1);
    workerElectionInfo1.setBenefitPlanName("Plan1");
    workerElectionInfo1.setBenefitPlanCode("benefitPlanCode1");
    workerElectionInfo1.setBenefitPlanTier("benefitPlanTier1");
    workerElectionInfo1.setPcpNumber("pcpNumber1");

    EmployeeElectionInfo workerElectionInfo2 = new EmployeeElectionInfo();
    workerElectionInfo2.setElectionEeId(2);
    workerElectionInfo2.setEmployeeElectionId(2);
    workerElectionInfo2.setBenefitPlanName("Plan2");
    workerElectionInfo2.setBenefitPlanCode("benefitPlanCode2");
    workerElectionInfo2.setBenefitPlanTier("benefitPlanTier2");
    workerElectionInfo2.setPcpNumber("pcpNumber2");

    CoveredDependentInfo coveredDependentInfoLindseyElection1 = new CoveredDependentInfo();
    coveredDependentInfoLindseyElection1.setCoveredDependentId(1);
    coveredDependentInfoLindseyElection1
        .setCoveredDependentEmployeeId(workerElectionInfo1.getElectionEeId());
    coveredDependentInfoLindseyElection1
        .setCoveredDependentEmployerId(workerElectionInfo1.getElectionEmployerId());
    coveredDependentInfoLindseyElection1.setTransactionPersonInfo(new TransactionPersonInfo());
    coveredDependentInfoLindseyElection1.getTransactionPersonInfo().setFirstName("Lindsey");
    coveredDependentInfoLindseyElection1.getTransactionPersonInfo().setLastName("Doe");
    coveredDependentInfoLindseyElection1.getTransactionPersonInfo().setPersonId(2);
    coveredDependentInfoLindseyElection1
        .setCoveredDependentDependentId(dependentInfoLindsey.getDependentId());
    coveredDependentInfoLindseyElection1
        .setCoveredDependentElectionId(workerElectionInfo1.getElectionEeId());
    coveredDependentInfoLindseyElection1.setCoveredDependentRelationshipCode(
        "coveredDependentRelationshipCode-coveredDependentInfoLindseyElection1");
    coveredDependentInfoLindseyElection1
        .setCoveredDependentPcpName("coveredDependentPcpName-coveredDependentInfoLindseyElection1");

    CoveredDependentInfo coveredDependentInfoLindseyElection2 = new CoveredDependentInfo();
    coveredDependentInfoLindseyElection2.setCoveredDependentId(2);
    coveredDependentInfoLindseyElection2.setTransactionPersonInfo(new TransactionPersonInfo());
    coveredDependentInfoLindseyElection2.getTransactionPersonInfo().setFirstName("Lindsey");
    coveredDependentInfoLindseyElection2.getTransactionPersonInfo().setLastName("Doe");
    coveredDependentInfoLindseyElection2.getTransactionPersonInfo().setPersonId(3);
    coveredDependentInfoLindseyElection2
        .setCoveredDependentDependentId(dependentInfoLindsey.getDependentId());
    coveredDependentInfoLindseyElection2
        .setCoveredDependentElectionId(workerElectionInfo2.getElectionEeId());
    coveredDependentInfoLindseyElection2.setCoveredDependentRelationshipCode(
        "coveredDependentRelationshipCode-coveredDependentInfoLindseyElection2");
    coveredDependentInfoLindseyElection1
        .setCoveredDependentPcpName("coveredDependentPcpName-coveredDependentInfoLindseyElection2");

    CoveredDependentInfo coveredDependentInfoNeelElection1 = new CoveredDependentInfo();
    coveredDependentInfoNeelElection1.setCoveredDependentId(3);
    coveredDependentInfoNeelElection1
        .setCoveredDependentEmployeeId(workerElectionInfo1.getElectionEeId());
    coveredDependentInfoNeelElection1
        .setCoveredDependentEmployerId(workerElectionInfo1.getElectionEmployerId());
    coveredDependentInfoNeelElection1.setTransactionPersonInfo(new TransactionPersonInfo());
    coveredDependentInfoNeelElection1.getTransactionPersonInfo().setFirstName("Neel");
    coveredDependentInfoNeelElection1.getTransactionPersonInfo().setLastName("Doe");
    coveredDependentInfoNeelElection1.getTransactionPersonInfo().setPersonId(4);
    coveredDependentInfoNeelElection1
        .setCoveredDependentDependentId(dependentInfoNeel.getDependentId());
    coveredDependentInfoNeelElection1
        .setCoveredDependentElectionId(workerElectionInfo1.getElectionEeId());
    coveredDependentInfoLindseyElection1.setCoveredDependentRelationshipCode(
        "coveredDependentRelationshipCode-coveredDependentInfoNeelElection1");
    coveredDependentInfoLindseyElection1
        .setCoveredDependentPcpName("coveredDependentPcpName-coveredDependentInfoNeelElection1");

    List<CoveredDependentInfo> coveredDependents = new ArrayList<>();
    transactionDataset.setCoveredDependents(coveredDependents);
    coveredDependents.add(coveredDependentInfoNeelElection1);

    coveredDependents.add(coveredDependentInfoLindseyElection1);

    coveredDependents.add(coveredDependentInfoLindseyElection2);

    List<EmployeeElectionInfo> workerElectionInfos = new ArrayList<>();
    transactionDataset.setElections(workerElectionInfos);
    workerElectionInfos.add(workerElectionInfo1);

    workerElectionInfos.add(workerElectionInfo2);

    List<DependentInfo> dependentInfos = new ArrayList<>();
    transactionDataset.setDependents(dependentInfos);
    dependentInfos.add(dependentInfoNeel);

    dependentInfos.add(dependentInfoLindsey);

    dependentInfos.add(dependentInfoUnknown);

    return transactionDataset;
  }

  /**
   * Generate adapt header.
   *
   * @return the adapt header
   */
  public static AdaptHeader generateAdaptHeader() {
    return new AdaptHeader.Builder().setFileIdentifier(867).setChunkNumber(1).setChunkSize(1)
        .setCorrelationId("123123123").build();
  }

}
