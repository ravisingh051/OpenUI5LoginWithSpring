package com.adapt.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.adapt.file.entity.DroolsBusinessRulesDecisionTableEntity;
import com.adapt.util.MockDataUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RuleRepositoryImpl.class })
public class RuleRepositoryImplTest {
  @Autowired
  private RuleRepositoryImpl ruleRepository;

  @MockBean(name = "idisEntityManager")
  private EntityManager entityManager;

  @Test
  public void test_getRules() {
    StoredProcedureQuery storedProcedureQuery = mock(StoredProcedureQuery.class);
    when(entityManager.createStoredProcedureQuery(anyString())).thenReturn(storedProcedureQuery);
    when(storedProcedureQuery.getResultList())
        .thenReturn(MockDataUtil.getDroolsBusinessRulesDecisionTableResultSet());
    List<DroolsBusinessRulesDecisionTableEntity> rules = ruleRepository.getRules(1,
        DroolsBusinessRuleGroupName.BUSINESS_CRITERIA);
    Object[] result = MockDataUtil.getDroolsBusinessRulesDecisionTableResultSet().stream()
        .findFirst().get();
    DroolsBusinessRulesDecisionTableEntity droolsBusinessRulesDecisionTableEntity = rules.stream()
        .findFirst().get();
    assertEquals(result[0], droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleId());
    assertEquals(result[1], droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleVersion());
    assertEquals(result[2],
        droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleDrlFileContent());
    assertEquals(result[3], droolsBusinessRulesDecisionTableEntity.getCurrent());
    assertEquals(result[4], droolsBusinessRulesDecisionTableEntity.getRuleExecutionSequence());
  }
}