package com.adapt.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.adapt.api.config.domain.JobFileWithMultiEmployerEntity;
import com.adapt.config.Constant;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.MessageFormatType;
import com.adapt.file.entity.MessageType;
import com.adapt.file.entity.SectionAttributeEntity;
import com.adapt.util.MockDataUtil;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobRepositoryImpl.class })
public class JobRepositoryTest {

  @MockBean(name = "idisEntityManager")
  private EntityManager entityManager;

  @Autowired
  private JobRepository jobRepository;

  @Test
  public void testFindJobsByExpectedDate_noJobScheduled_shouldReturnBlankList() {

    StoredProcedureQuery jobFileEntityStoredProcedureQuery = mock(StoredProcedureQuery.class);

    when(entityManager.createStoredProcedureQuery(anyString()))
        .thenReturn(jobFileEntityStoredProcedureQuery);
    when(jobFileEntityStoredProcedureQuery.getResultList()).thenReturn(Collections.emptyList());

    Collection<JobFileEntity> jobFileEntities = jobRepository
        .findJobsByExpectedDate(LocalDate.now());

    assertNotNull(jobFileEntities);
    assertEquals(0, jobFileEntities.size());
  }

  @Test
  public void testFindJobsByExpectedDate_oneJobScheduled_shouldRunSuccessfully() {
    StoredProcedureQuery jobFileEntityStoredProcedureQuery = mock(StoredProcedureQuery.class);
    StoredProcedureQuery sectionAttributeEntityStoredProcedureQuery = mock(
        StoredProcedureQuery.class);

    when(entityManager.createStoredProcedureQuery(Constant.USP_GET_EXPECTED_JOBS_BY_DATE))
        .thenReturn(jobFileEntityStoredProcedureQuery);
    when(jobFileEntityStoredProcedureQuery.getResultList())
        .thenReturn(MockDataUtil.buildJobFileEntityDbData());

    when(entityManager.createStoredProcedureQuery(Constant.USP_GET_FILE_ATTRIBUTE_DETAILS))
        .thenReturn(sectionAttributeEntityStoredProcedureQuery);
    when(sectionAttributeEntityStoredProcedureQuery.getResultList())
        .thenReturn(MockDataUtil.buildSectionAttributeEntityDbData());

    Collection<JobFileEntity> findJobsByExpectedDate = jobRepository
        .findJobsByExpectedDate(LocalDate.now());

    assertNotNull(findJobsByExpectedDate);
    assertEquals(1, findJobsByExpectedDate.size());

    Iterator<JobFileEntity> iterator = findJobsByExpectedDate.iterator();
    JobFileEntity jobFileEntity = iterator.next();

    assertTrue(12 == jobFileEntity.getJobId());
    // assertTrue(55 == jobFileEntity.getFileId());
    // assertTrue(1 == jobFileEntity.getFileVersion());
    assertEquals(LocalDate.now().format(DateTimeFormatter.ISO_DATE), LocalDate
        .parse(String.valueOf(jobFileEntity.getExpectedDate())).format(DateTimeFormatter.ISO_DATE));
    assertTrue(5 == jobFileEntity.getErrorThreshHold());
    assertTrue(null == jobFileEntity.getFileMinRecordCountAllowed());
    assertEquals("test.txt", jobFileEntity.getFileTransmissionName());
    assertEquals(MessageType.INBOUND_CENSUS.getValue(), jobFileEntity.getFileType());
    assertEquals(MessageFormatType.FILE_DELIMITED.getValue(), jobFileEntity.getFileFormatName());
    assertEquals("\n", jobFileEntity.getRowDelimiter());
    assertEquals("|", jobFileEntity.getFieldDelimiter());
    assertEquals("\n", jobFileEntity.getEscapeCharacter());
    assertEquals("dontknow", jobFileEntity.getSegmentDelimiter());
    assertTrue(5 == jobFileEntity.getPriority());
    assertTrue("3007::02871" == jobFileEntity.getEmployerIdAndClientIds());
    assertTrue(1 == jobFileEntity.getFullOrChange());
    assertTrue(0 == jobFileEntity.getResultsMode());

    SectionAttributeEntity sectionAttributeEntity = jobFileEntity.getSectionAttributeEntities()
        .get(0);
    jobFileEntity.setSectionAttributeEntities(null);
    assertTrue(
        "TEST_STANDARDIZED_NAME".equalsIgnoreCase(sectionAttributeEntity.getStandardizedName()));
    assertTrue("java.lang.String".equalsIgnoreCase(sectionAttributeEntity.getAttributeDataType()));
    assertTrue(1 == sectionAttributeEntity.getOrder());
    assertTrue("DETAIL".equalsIgnoreCase(sectionAttributeEntity.getSectionType()));
    assertTrue(null == sectionAttributeEntity.getSectionDelimiter());
    assertTrue(sectionAttributeEntity.getIsAttributeMandatory());
    assertTrue(10 == sectionAttributeEntity.getAttributeSize());
    assertTrue(1 == sectionAttributeEntity.getAttributeStartPosition());
    assertTrue(10 == sectionAttributeEntity.getAttributeEndPosition());
    assertTrue("PERCENTAGE".equals(jobFileEntity.getFileProcessingErrorThresholdFormat()));

  }

  @Test
  public void testGetJobFileWithMultiEmployerEntity_shouldRunSuccessfully() {
    StoredProcedureQuery jobFileWithMultiEmployerEntitySpq = mock(StoredProcedureQuery.class);

    when(entityManager
        .createStoredProcedureQuery(Constant.USP_GET_EXPECTED_JOBS_BY_DATE_AND_PRIORITY))
            .thenReturn(jobFileWithMultiEmployerEntitySpq);
    when(jobFileWithMultiEmployerEntitySpq.getResultList())
        .thenReturn(MockDataUtil.buildJobFileWithMultiEmployerEntityDbData());

    JobFileWithMultiEmployerEntity jobFileWithMultiEmployerEntity = jobRepository
        .getJobFileWithMultiEmployerEntity(LocalDate.now());
    assertNotNull(jobFileWithMultiEmployerEntity);
  }

}
