package com.adapt.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.adapt.file.entity.EnrichmentApiInfo;
import com.adapt.util.MockDataUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { SecondaryDataRepositoryImpl.class })
public class SecondaryDataRepositoryImplTest {

  @MockBean(name = "idisEntityManager")
  private EntityManager entityManager;

  @Autowired
  private SecondaryDataRepository secondaryDataRepository;

  @Test
  public void testGetSecondaryDataInfoEntity() {
    StoredProcedureQuery sourceInstanceInfoStoredProcedureQuery = mock(StoredProcedureQuery.class);
    List<Object[]> buildEnrichmentApiInfoDbData = MockDataUtil.buildEnrichmentApiInfoDbData();
    when(entityManager
        .createStoredProcedureQuery(SecondaryDataRepositoryImpl.SP_USP_GET_FILE_ENRICHMENT_INFO))
            .thenReturn(sourceInstanceInfoStoredProcedureQuery);
    when(sourceInstanceInfoStoredProcedureQuery.getResultList())
        .thenReturn(buildEnrichmentApiInfoDbData);

    List<EnrichmentApiInfo> secondaryDataInfoEntityList = secondaryDataRepository
        .getSecondaryDataInfoEntity(1);

    assertFalse(secondaryDataInfoEntityList.isEmpty());

    assertEquals(buildEnrichmentApiInfoDbData.get(0)[0],
        secondaryDataInfoEntityList.get(0).getEnrichmentApiPojoName());
    assertEquals(buildEnrichmentApiInfoDbData.get(0)[1],
        secondaryDataInfoEntityList.get(0).getEnrichmentApiMappedObjEndpoint());
  }

}
