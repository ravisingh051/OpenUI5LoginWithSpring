package com.adapt.file.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.event.DatasetCountExceedOccurred;
import com.adapt.event.DatasetCountSubceedOccurred;
import com.adapt.event.EventTypeEnum;
import com.adapt.event.InboundFileOccurred;
import com.adapt.event.JobCompletedOccurredEvent;
import com.adapt.file.service.EventNotificationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NotificationEventService.class, EventNotificationService.class })
public class NotificationEventServiceTest {

  @Autowired
  private NotificationEventService notificationEventService;

  @MockBean
  private EventNotificationService eventNotificationService;

  @Test
  public void test_sendInboundFileOccurred() {
    InboundFileOccurred inboundFileOccurred = new InboundFileOccurred();
    inboundFileOccurred.setFileId(1);
    inboundFileOccurred.setFileVersion(1);
    inboundFileOccurred.setJobId(1);
    inboundFileOccurred.setEventType(EventTypeEnum.INBOUND_FILE_OCCURRED.name());
    Mockito.doNothing().when(eventNotificationService)
        .sendInboundFileOccuredNotification(inboundFileOccurred);
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(inboundFileOccurred);

    Message<?> sendInboundFileOccured =
        notificationEventService.sendInboundFileOccured(builder.build());
    assertNotNull(sendInboundFileOccured);
  }

  @Test
  public void test_sendCountExceedOccurred() {

    DatasetCountExceedOccurred datasetCountExceedOccurred = new DatasetCountExceedOccurred();
    datasetCountExceedOccurred.setFileId(1);
    datasetCountExceedOccurred.setFileVersion(1);
    datasetCountExceedOccurred.setJobId(1);
    datasetCountExceedOccurred.setEventType(EventTypeEnum.DATASET_COUNT_EXCEEDED_OCCURRED.name());
    Mockito.doNothing().when(eventNotificationService)
        .sendCountExceededOccurredNotification(datasetCountExceedOccurred);
    MessageBuilder<?> builder =
        new DefaultMessageBuilderFactory().withPayload(datasetCountExceedOccurred);

    Message<?> sendCountExceededOccurredNotification =
        notificationEventService.sendCountExceededOccurredNotification(builder.build());
    assertNotNull(sendCountExceededOccurredNotification);
  }

  @Test
  public void test_sendCountSubceedOccurred() {

    DatasetCountSubceedOccurred datasetCountSubceedOccurred = new DatasetCountSubceedOccurred();
    datasetCountSubceedOccurred.setFileId(1);
    datasetCountSubceedOccurred.setFileVersion(1);
    datasetCountSubceedOccurred.setJobId(1);
    datasetCountSubceedOccurred.setEventType(EventTypeEnum.DATASET_COUNT_SUBCEEDED_OCCURRED.name());
    Mockito.doNothing().when(eventNotificationService)
        .sendCountSubceededOccurredNotification(datasetCountSubceedOccurred);
    MessageBuilder<?> builder =
        new DefaultMessageBuilderFactory().withPayload(datasetCountSubceedOccurred);

    Message<?> sendDatasetCountSubceededOccurred =
        notificationEventService.sendDatasetCountSubceededOccurred(builder.build());
    assertNotNull(sendDatasetCountSubceededOccurred);

  }

  @Test
  public void test_sendJobCompletedOccurred() {

    JobCompletedOccurredEvent jobCompletedOccurredEvent = new JobCompletedOccurredEvent();
    jobCompletedOccurredEvent.setFileId(1);
    jobCompletedOccurredEvent.setFileVersion(1);
    jobCompletedOccurredEvent.setJobId(1);
    jobCompletedOccurredEvent.setEventType(EventTypeEnum.DATASET_COUNT_SUBCEEDED_OCCURRED.name());
    Mockito.doNothing().when(eventNotificationService)
        .sendJobCompletedEvent(jobCompletedOccurredEvent);
    MessageBuilder<?> builder =
        new DefaultMessageBuilderFactory().withPayload(jobCompletedOccurredEvent);

    Message<?> sendJobCompletedOccurredEvent =
        notificationEventService.sendJobCompletedOccurred(builder.build());
    assertNotNull(sendJobCompletedOccurredEvent);

  }

}
