package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.config.MessageTypeConfigHelper;
import com.adapt.exception.AttributeMapToDatasetTransformerException;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.MessageType;
import com.adapt.util.MockDataUtil;
import com.alight.adapt.datasets.census.v1.ProcessorCensusDataset;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { AttributeMapToDatasetTransformer.class, MessageTypeConfigHelper.class })
public class AttributeMapToDatasetTransformerTest {

  @Autowired
  AttributeMapToDatasetTransformer attributeMapToDatasetTransformer;

  @Test
  public void testAttributeMapToPojoMapping_shouldRunSuccessfully() throws Exception {

    Map<String, Object> map = MockDataUtil.buildCensusDatasetMap();
    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_MODEL_HEADER, MockDataUtil.buildDelimitedJobModel());

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(map)
        .copyHeaders(headerMap);
    ProcessorCensusDataset censusDataset = (ProcessorCensusDataset) attributeMapToDatasetTransformer
        .doTransform(builder.build());
    Assert.assertEquals("Address Line 1", censusDataset.getAddressLine1());
    Assert.assertEquals("Address Line 2", censusDataset.getAddressLine2());
    Assert.assertEquals("Address Line 3", censusDataset.getAddressLine3());
    Assert.assertEquals("Alternate Address 1", censusDataset.getAlternateAddress1());
    Assert.assertEquals("Alternate Address 2", censusDataset.getAlternateAddress2());
    Assert.assertEquals(LocalDate.now().format(DateTimeFormatter.ISO_DATE),
        censusDataset.getAddressChangeDate());
  }

  @Test
  public void testAttributeMapToPojoMapping_shouldRunFail() throws Exception {

    Map<String, Object> map = MockDataUtil.buildFailedMap();
    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_MODEL_HEADER, MockDataUtil.buildDelimitedJobModel());
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(map)
        .copyHeaders(headerMap);
    ProcessorCensusDataset censusDataset = (ProcessorCensusDataset) attributeMapToDatasetTransformer
        .doTransform(builder.build());

    Assert.assertEquals((Object) 1, censusDataset.getRuleFailures().size());

  }

  @Test
  public void testAttributeMapToPojoMapping_shouldRunSuccessfullyWithoutEmployer()
      throws Exception {

    Map<String, Object> map = MockDataUtil.buildCensusDatasetMap();
    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_MODEL_HEADER, MockDataUtil.buildDelimitedJobModelNoEmployer());
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(map)
        .copyHeaders(headerMap);
    ProcessorCensusDataset censusDataset = (ProcessorCensusDataset) attributeMapToDatasetTransformer
        .doTransform(builder.build());
    Assert.assertEquals("Address Line 1", censusDataset.getAddressLine1());
    Assert.assertEquals("Address Line 2", censusDataset.getAddressLine2());
    Assert.assertEquals("Address Line 3", censusDataset.getAddressLine3());
    Assert.assertEquals("Alternate Address 1", censusDataset.getAlternateAddress1());
    Assert.assertEquals("Alternate Address 2", censusDataset.getAlternateAddress2());
    Assert.assertEquals(LocalDate.now().format(DateTimeFormatter.ISO_DATE),
        censusDataset.getAddressChangeDate());
  }

  @Test(expected = AttributeMapToDatasetTransformerException.class)
  public void testAttributeMapToPojoMapping_shouldRunFail_WithoutClass() throws Exception {

    Map<String, Object> map = MockDataUtil.buildCensusDatasetMap();
    Map<String, Object> headerMap = new HashMap<String, Object>();
    JobModel jobModel = MockDataUtil.buildDelimitedJobModelNoEmployer();
    jobModel.getFileModel().setFileType(MessageType.INBOUND_EXTERNAL_DATAVALUE_DATASET);
    headerMap.put(Constant.JOB_MODEL_HEADER, jobModel);
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(map)
        .copyHeaders(headerMap);
    attributeMapToDatasetTransformer.doTransform(builder.build());

  }

}