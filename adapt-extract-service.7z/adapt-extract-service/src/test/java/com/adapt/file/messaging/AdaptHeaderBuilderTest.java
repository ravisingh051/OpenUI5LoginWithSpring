package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.util.MockDataUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { AdaptHeaderBuilder.class })
public class AdaptHeaderBuilderTest {

  @Autowired
  private AdaptHeaderBuilder adaptHeaderBuilder;

  @Test
  public void testBuildMethod() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 1);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = adaptHeaderBuilder.build(builder.build());
    String adaptHeader = (String) temp.getHeaders().get(Constant.ADAPT_HEADER);
    Assert.assertNotNull(adaptHeader);

  }

  @Test
  public void testBuildMethodAllHeaders() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 1);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    builder.setHeader(Constant.FULL_OR_CHANGE_FILE_HEADER, false);
    builder.setHeader(Constant.ORIGINAL_FILE_NAME_HEADER, "");
    builder.setHeader(Constant.FILE_FOOTER_HEADER, "");
    builder.setHeader(Constant.FILE_HEADER_HEADER, "");

    builder.setHeader(Constant.FILE_IDENTIFIER, 1);
    builder.setHeader(Constant.FILE_ID, 1);

    builder.setHeader(Constant.FILE_VERSION, 1);

    builder.setHeader(Constant.FILE_TYPE_HEADER, "");

    builder.setHeader(Constant.FILE_RECORD_COUNT, 1);
    builder.setHeader(Constant.MASTER_FILE_TEMPLATE_ID_HEADER, 1);
    builder.setHeader(Constant.MASTER_FILE_TEMPLATE_VERSION_HEADER, 1);

    builder.setHeader(Constant.JOB_ID_HEADER, 1);

    builder.setHeader("correlationId", "1");
    builder.setHeader("priority", 1);

    builder.setHeader(Constant.SECONDARY_DATA_INFO_HEADER, "");
    builder.setHeader(Constant.ERROR_THRESHOLD_HEADER, 10);
    builder.setHeader(Constant.FILE_PROCESSING_ERROR_THRESHOLD_FORMAT_HEADER, "");
    builder.setHeader(Constant.RESULTS_MODE_HEADER, false);

    builder.setHeader(Constant.EMPLOYER_ID_HEADER, 1);

    builder.setHeader(Constant.TEST_CFG_HEADER, "");

    builder.setHeader(Constant.CLIENT_ID_HEADER, 1);

    Message<?> temp = adaptHeaderBuilder.build(builder.build());
    String adaptHeader = (String) temp.getHeaders().get(Constant.ADAPT_HEADER);
    Assert.assertNotNull(adaptHeader);

  }

}
