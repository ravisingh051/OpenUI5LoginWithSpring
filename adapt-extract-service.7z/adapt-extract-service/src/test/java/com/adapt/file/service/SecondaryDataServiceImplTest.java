package com.adapt.file.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import com.adapt.file.entity.EnrichmentApiInfo;
import com.adapt.file.entity.SecondaryDataInfo;
import com.adapt.repository.SecondaryDataRepository;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { SecondaryDataServiceImpl.class })
public class SecondaryDataServiceImplTest {

  @Autowired
  private SecondaryDataServiceImpl secondaryDataServiceImpl;

  @MockBean
  private SecondaryDataRepository secondaryDataRepository;

  @Test
  public void test_getSecondaryDataInfo() {
    List<EnrichmentApiInfo> enrichmentApiInfoList = new ArrayList<>();
    EnrichmentApiInfo enrichmentApiInfo = new EnrichmentApiInfo();
    enrichmentApiInfo.setEnrichmentApiMappedObjEndpoint("enrichmentApiMappedObjEndpoint");
    enrichmentApiInfo.setEnrichmentApiPojoName("enrichmentApiPojoName");
    enrichmentApiInfoList.add(enrichmentApiInfo);
    when(secondaryDataRepository.getSecondaryDataInfoEntity(1)).thenReturn(enrichmentApiInfoList);
    List<SecondaryDataInfo> secondaryDataInfo = secondaryDataServiceImpl.getSecondaryDataInfo(1);
    assertNotNull(secondaryDataInfo);
    assertEquals(enrichmentApiInfo.getEnrichmentApiMappedObjEndpoint(),
        secondaryDataInfo.get(0).getSecondaryDataEndpoint());
    assertEquals(enrichmentApiInfo.getEnrichmentApiPojoName(),
        secondaryDataInfo.get(0).getSecondaryDataPojoName());
  }
}
