package com.adapt.file.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.service.FileAttributePreparer;
import com.adapt.util.MockDataUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { FixWidthStringToMapTransformer.class, FileAttributePreparer.class })
public class FixWidthStringToMapTransformerTest {

  @Autowired
  private FixWidthStringToMapTransformer fixWidthStringToMapTransformer;

  @Test
  public void testTransformDetail_oneDetailSection_shouldRunSuccessfully() throws Exception {
    String str = "02 100000                                                  Martinez                                          Susan                                                                                                     FM        333 Sierra Woods Drive                                                                                                                                Sierra Madre                                                                                        CA                                                91024              USA                                                       6263554130                            SMartinez@chla.usc.edu                                                                              002609495  1962043019920713                                                  A                                     NF H        0015256569                                                                  BEN                                               BEN ELIG                                                                                                                                              N            19920713  20171008PS                                                                                                                                            20171008Reg Nurse III 12Hr - 000158                       000000400000000062865                                                 201607102017071020180710434000M074                                        5 East 1                                20030316103117                                            Santner, Susan L                                  000316493                                                                                                                                                             20080115-1320000000000000000-4801100000000000000ssantner@chla.usc.edu             1                                   19920713N1705US     Graham,Bridget                                    bgraham@chla.usc.edu                               \r\n";
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(str);
    JobModel jobModel = MockDataUtil.buildFixedWidthJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = fixWidthStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    Assert.assertEquals("Susan", attributes.get("firstName").toString().trim());
  }

  @Test
  public void testTransformWithHeaderAndPayload() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02 100000                                                  Martinez                                          Susan                                                                                                     FM        333 Sierra Woods Drive                                                                                                                                Sierra Madre                                                                                        CA                                                91024              USA                                                       6263554130                            SMartinez@chla.usc.edu                                                                              002609495  1962043019920713                                                  A                                     NF H        0015256569                                                                  BEN                                               BEN ELIG                                                                                                                                              N            19920713  20171008PS                                                                                                                                            20171008Reg Nurse III 12Hr - 000158                       000000400000000062865                                                 201607102017071020180710434000M074                                        5 East 1                                20030316103117                                            Santner, Susan L                                  000316493                                                                                                                                                             20080115-1320000000000000000-4801100000000000000ssantner@chla.usc.edu             1                                   19920713N1705US     Graham,Bridget                                    bgraham@chla.usc.edu                               \\r\\n");
    JobModel jobModel = MockDataUtil.buildFixedWidthJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, new HashMap<>());
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);

    Message<?> temp = fixWidthStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    Assert.assertEquals("Susan", attributes.get("firstName").toString().trim());
  }

  @Test
  public void testTransformWithHeaderNull() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02 100000                                                  Martinez                                          Susan                                                                                                     FM        333 Sierra Woods Drive                                                                                                                                Sierra Madre                                                                                        CA                                                91024              USA                                                       6263554130                            SMartinez@chla.usc.edu                                                                              002609495  1962043019920713                                                  A                                     NF H        0015256569                                                                  BEN                                               BEN ELIG                                                                                                                                              N            19920713  20171008PS                                                                                                                                            20171008Reg Nurse III 12Hr - 000158                       000000400000000062865                                                 201607102017071020180710434000M074                                        5 East 1                                20030316103117                                            Santner, Susan L                                  000316493                                                                                                                                                             20080115-1320000000000000000-4801100000000000000ssantner@chla.usc.edu             1                                   19920713N1705US     Graham,Bridget                                    bgraham@chla.usc.edu                               \\r\\n");
    JobModel jobModel = MockDataUtil.buildFixedWidthJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, null);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);

    Message<?> temp = fixWidthStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformWithHeaderAndTrailerNull() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02 100000                                                  Martinez                                          Susan                                                                                                     FM        333 Sierra Woods Drive                                                                                                                                Sierra Madre                                                                                        CA                                                91024              USA                                                       6263554130                            SMartinez@chla.usc.edu                                                                              002609495  1962043019920713                                                  A                                     NF H        0015256569                                                                  BEN                                               BEN ELIG                                                                                                                                              N            19920713  20171008PS                                                                                                                                            20171008Reg Nurse III 12Hr - 000158                       000000400000000062865                                                 201607102017071020180710434000M074                                        5 East 1                                20030316103117                                            Santner, Susan L                                  000316493                                                                                                                                                             20080115-1320000000000000000-4801100000000000000ssantner@chla.usc.edu             1                                   19920713N1705US     Graham,Bridget                                    bgraham@chla.usc.edu                               \\r\\n");
    JobModel jobModel = MockDataUtil.buildFixedWidthJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, null);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_MAP_HEADER, null);

    Message<?> temp = fixWidthStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformWithHeaderAndTrailer() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02 100000                                                  Martinez                                          Susan                                                                                                     FM        333 Sierra Woods Drive                                                                                                                                Sierra Madre                                                                                        CA                                                91024              USA                                                       6263554130                            SMartinez@chla.usc.edu                                                                              002609495  1962043019920713                                                  A                                     NF H        0015256569                                                                  BEN                                               BEN ELIG                                                                                                                                              N            19920713  20171008PS                                                                                                                                            20171008Reg Nurse III 12Hr - 000158                       000000400000000062865                                                 201607102017071020180710434000M074                                        5 East 1                                20030316103117                                            Santner, Susan L                                  000316493                                                                                                                                                             20080115-1320000000000000000-4801100000000000000ssantner@chla.usc.edu             1                                   19920713N1705US     Graham,Bridget                                    bgraham@chla.usc.edu                               \\r\\n");
    JobModel jobModel = MockDataUtil.buildFixedWidthJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, new HashMap<>());
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_MAP_HEADER, new HashMap<>());

    Message<?> temp = fixWidthStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

}