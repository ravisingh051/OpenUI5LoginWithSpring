package com.adapt.file.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.service.FileAttributePreparer;
import com.adapt.util.MockDataUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DelimitedStringToMapTransformer.class, FileAttributePreparer.class })
public class DelimitedStringToMapTransformerTest {

  @Autowired
  private DelimitedStringToMapTransformer delimitedStringToMapTransformer;

  @Test
  public void testTransformHeaderWithEmptyPayload() throws Exception {
    // MessageBuilder<?> builder =
    // new
    // DefaultMessageBuilderFactory().withPayload("01|000001|02/19/2018|F|3006|");
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 1);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformDetail() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02| |3006|101791106||Lantz|Jon|Dow||F|Unknown||3301 Kntario Ave|||Kelando|5546215|FL|32806||United States||||||test@gmail.com|2306988547|19931325|20150825|Hourly");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("Lantz", attributes.get("firstName"));
  }

  @Test
  public void testTransformDetailWithCommaDelimiter() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02, ,3006,101791106,,Lantz,Jon,Dow,,F,Unknown,,\"3301, Kntario Ave\",,,Kelando,5546215,FL,32806,,United States,,,,,,test@gmail.com,2306988547,19931325,20150825,Hourly");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModelWithCommaDelimiter();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("Lantz", attributes.get("firstName"));
    assertEquals("3301, Kntario Ave", attributes.get("addressLine1"));
  }

  @Test
  public void testTransformDetailWithEscapeDelimiter() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02~ ~3006~101791106~~Lantz~Jon~Dow~~F~Unknown~~\"3301~ Kntario Ave\"~~~Kelando~5546215~FL~32806~~United States~~~~~~test@gmail.com~2306988547~19931325~20150825~Hourly");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModelWithEscapeDelimiter();
    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);
    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("Lantz", attributes.get("firstName"));
    assertEquals("3301~ Kntario Ave", attributes.get("addressLine1"));
  }

  @Test
  public void testTransformDetailWithDollarDelimiter() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "02$ $3006$101791106$$Lantz$Jon$Dow$$F$Unknown$$\"3301$ Kntario Ave\"$$$Kelando$5546215$FL$32806$$United States$$$$$$test@gmail.com$2306988547$19931325$20150825$Hourly");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModelWithDollarDelimiter();
    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);
    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("Lantz", attributes.get("firstName"));
    assertEquals("3301$ Kntario Ave", attributes.get("addressLine1"));
  }

  @Test
  public void testTransformDetailFirstInputAsEmpty() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(
        "| |3006|101791106||Lantz|Jon|Dow||F|Unknown||3301 Kntario Ave|||Kelando|5546215|FL|32806||United States||||||test@gmail.com|2306988547|19931325|20150825|Hourly");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("Lantz", attributes.get("firstName"));
  }

  @Test
  public void testTransformDetailWithSpecialChar() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory()
        .withPayload("45" + "\t" + "25906284" + "\t" + "6163343" + "\t" + "A" + "\t" + "VRS" + "\t"
            + "This is First Name!!!" + "\t" + "2018-08-28 14:38:40.490" + "\t" + "\t" + "\t"
            + "2018-07-09 00:00:00.000" + "\t" + "1");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();
    jobModel.getFileModel().getMessageFormat().setFieldDelimiter("\t");
    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_NUMBER, 2);
    builder.setHeader(IntegrationMessageHeaderAccessor.SEQUENCE_SIZE, 3);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals("This is First Name!!!", attributes.get("firstName"));

  }

  @Test
  public void testTransformWithHeaderAndPayload() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, new HashMap<>());
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformWithHeaderNull() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, null);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformWithHeaderAndTrailerNull() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, null);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_MAP_HEADER, null);

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

  @Test
  public void testTransformWithHeaderAndTrailer() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, new HashMap<>());
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_MAP_HEADER, new HashMap<>());

    Message<?> temp = delimitedStringToMapTransformer.doTransform(builder.build());
    Map<String, Object> attributes = (Map<String, Object>) temp.getPayload();
    assertEquals(null, attributes.get("recordType"));

  }

}