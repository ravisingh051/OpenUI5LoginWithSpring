package com.adapt.file;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.adapt.exception.UnsuccessfulFileRenameException;
import com.adapt.file.messaging.FileLocker;
import java.io.File;
import java.io.IOException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.ArgumentMatchers;

public class FileLockerTest {

  private FileLocker locker = new FileLocker();

  @Rule
  public TemporaryFolder folder = new TemporaryFolder();

  @Test
  public void testFileIsRenamed() throws IOException {
    File f = folder.newFile(String.valueOf(System.currentTimeMillis()));
    File outPut = (File) locker.lock(f);
    assertNotNull(outPut);
    assertEquals(f.getName() + FileLocker.FILE_RECEIVED_EXTENSIONS, outPut.getName());

  }

  @Test(expected = UnsuccessfulFileRenameException.class)
  public void testDoRename_unableToRenameFile_shouldFailWithUnsuccessfulFileRenameException()
      throws IOException {
    File f = mock(File.class);

    when(f.renameTo(ArgumentMatchers.any(File.class))).thenReturn(false);
    locker.lock(f);
  }

}
