package com.adapt.file;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.SecondaryDataInfo;
import com.adapt.file.messaging.SecondaryDataConfiguration;
import com.adapt.file.service.SecondaryDataService;
import com.adapt.util.MockDataUtil;
import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { SecondaryDataConfiguration.class })
public class SecondaryDataConfigurationTest {

  @MockBean
  private SecondaryDataService secondaryDataService;

  @Autowired
  private SecondaryDataConfiguration enrichConfiguration;

  @Test
  public void testEnrichConfiguration() {
    SecondaryDataInfo enrichmentApiDetail = new SecondaryDataInfo();
    enrichmentApiDetail.setSecondaryDataEndpoint("/CbaAdaptDataService/api/v1/cba/AdaptPersons");
    enrichmentApiDetail.setSecondaryDataPojoName("Person");
    JobModel buildDelimitedJobModel = MockDataUtil.buildDelimitedJobModel();
    when(secondaryDataService
        .getSecondaryDataInfo(buildDelimitedJobModel.getFileModel().getFileIdentifier()))
            .thenReturn(Arrays.asList(enrichmentApiDetail));

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");

    builder.setHeader(Constant.JOB_MODEL_HEADER, MockDataUtil.buildDelimitedJobModel());
    Message<?> enrichConfigurationMessage = enrichConfiguration
        .secondaryDataConfiguration(builder.build());
    assertTrue(!""
        .equals(enrichConfigurationMessage.getHeaders().get(Constant.SECONDARY_DATA_INFO_HEADER)));
  }

}
