package com.adapt.file.messaging;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.scheduling.PollSkipAdvice;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BlackoutWindowPollSkipAdvice.class })
public class BlackoutWindowPollSkipAdviceTest {

  @Autowired
  private BlackoutWindowPollSkipAdvice blackoutWindowPollSkipAdvice;

  @Test
  public void testBlackoutWindowSkipPollAdvice_dummyTest_shouldRunSuccessfully() {
    PollSkipAdvice blackoutWindowSkipPollAdvice = blackoutWindowPollSkipAdvice
        .blackoutWindowSkipPollAdvice();

    assertNotNull(blackoutWindowSkipPollAdvice);
  }

}
