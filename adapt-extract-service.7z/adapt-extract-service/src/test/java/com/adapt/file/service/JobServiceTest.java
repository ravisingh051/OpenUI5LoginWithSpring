package com.adapt.file.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import com.adapt.file.entity.JobDetails;
import com.adapt.file.entity.JobDetailsDto;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.repository.JobDetailsCrudRepository;
import com.adapt.repository.JobRepository;
import com.adapt.util.MockDataUtil;
import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import com.alight.idis.jobs.JobStatus;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobServiceImpl.class })
public class JobServiceTest {

  @MockBean
  private JobRepository jobRepository;

  @MockBean
  private JobDetailsCrudRepository jobCrudRepository;

  @Autowired
  private JobService jobService;

  @Test
  public void testFindJobByExpectedDate() {

    JobFileEntity jobFileEntity = new JobFileEntity();
    List<JobFileEntity> jobFileEntities = new ArrayList<>();
    jobFileEntities.add(jobFileEntity);
    Mockito.when(jobRepository.findJobsByExpectedDate(Mockito.any(LocalDate.class)))
        .thenReturn(jobFileEntities);
    jobService.findJobsByExpectedDate(LocalDate.now());

  }

  @Test
  public void testUpdateJobStatus() {
    JobDetailsDto jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(1);
    jobDetailsDto.setJobStatus(JobStatus.IN_PROGRESS);
    jobDetailsDto.setTotalErrorCount(0);
    jobDetailsDto.setTotalProcessedCount(0);
    jobDetailsDto.setTotalRecordsInFile(0);
    jobDetailsDto.setTotalWarningCount(0);

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.SCHEDULED.getValue());
    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(jobDetails);
    jobService.updateJobStatus(jobDetailsDto);
    assertNotNull(jobDetailsDto);
  }

  @Test
  public void testUpdateJobStatus_JobIdNull() {
    JobDetailsDto jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(null);
    jobDetailsDto.setJobStatus(JobStatus.IN_PROGRESS);

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.SCHEDULED.getValue());
    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(jobDetails);
    jobService.updateJobStatus(jobDetailsDto);
    assertNotNull(jobDetailsDto);
  }

  @Test
  public void testUpdateJobStatus_JobStatusNull_Invalid() {
    JobDetailsDto jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(1);
    jobDetailsDto.setJobStatus(null);

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.SCHEDULED.getValue());
    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(jobDetails);
    jobService.updateJobStatus(jobDetailsDto);

    jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(1);
    jobDetailsDto.setJobStatus(JobStatus.SCHEDULED);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.SCHEDULED.getValue());
    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(jobDetails);
    jobService.updateJobStatus(jobDetailsDto);
    assertNotNull(jobDetailsDto);
  }

  @Test
  public void testUpdateJobStatus_DB_JobStatusNull() {
    JobDetailsDto jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(1);
    jobDetailsDto.setJobStatus(JobStatus.IN_PROGRESS);

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(null);
    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(jobDetails);
    jobService.updateJobStatus(jobDetailsDto);
    assertNotNull(jobDetailsDto);
  }

  @Test
  public void testUpdateJobStatus_DB_JobNotFound() {
    JobDetailsDto jobDetailsDto = new JobDetailsDto();
    jobDetailsDto.setJobId(1);
    jobDetailsDto.setJobStatus(JobStatus.IN_PROGRESS);

    when(jobCrudRepository.findOne(jobDetailsDto.getJobId())).thenReturn(null);
    jobService.updateJobStatus(jobDetailsDto);
    assertNotNull(jobDetailsDto);
  }

  @Test
  public void testIsValidJobToProcess_ThresholdFormat_NONE() {

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.getValue());
    jobDetails.setTotalRecordsInFile(100);
    jobDetails.setTotalErrorRecords(5);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    boolean isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.NONE, 0);
    assertTrue(isValidJobToProcess);
  }

  @Test
  public void testIsValidJobToProcess_JOB_FAILED() {

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.FAILED.toString());
    jobDetails.setTotalRecordsInFile(100);
    jobDetails.setTotalErrorRecords(5);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    boolean isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.NONE, 0);
    assertFalse(isValidJobToProcess);
  }

  @Test
  public void testIsValidJobToProcess_ThresholdFormat_COUNT() {

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(100);
    jobDetails.setTotalErrorRecords(5);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    boolean isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.COUNT, 10);
    assertTrue(isValidJobToProcess);

    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.COUNT, 4);
    assertFalse(isValidJobToProcess);
  }

  @Test
  public void testIsValidJobToProcess_ThresholdFormat_PERCENTAGE() {

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(100);
    jobDetails.setTotalErrorRecords(50);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    boolean isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 60);
    assertTrue(isValidJobToProcess);

    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 49);
    assertFalse(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(100);
    jobDetails.setTotalErrorRecords(0);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 60);
    assertTrue(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(9);
    jobDetails.setTotalErrorRecords(1);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 20);
    assertTrue(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(4);
    jobDetails.setTotalErrorRecords(1);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 20);
    assertFalse(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(4);
    jobDetails.setTotalErrorRecords(3);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 20);
    assertFalse(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(4);
    jobDetails.setTotalErrorRecords(0);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 20);
    assertTrue(isValidJobToProcess);

    jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(4);
    jobDetails.setTotalErrorRecords(1);

    when(jobCrudRepository.findOne(1)).thenReturn(jobDetails);
    isValidJobToProcess = jobService.isValidJobToProcess(1,
        FileProcessingErrorThresholdFormat.PERCENTAGE, 20);
    assertFalse(isValidJobToProcess);
  }

  @Test
  public void test_jobFilePriorityEntityToJobModelMultiEmployerTransformer() {
    LocalDate now = LocalDate.now();
    JobModelMultiEmployer jobFileWithMultiEmployerEntity = jobService
        .jobFilePriorityEntityToJobModelMultiEmployerTransformer(now,
            MockDataUtil.buildJobFilePriorityEntity());
    assertNotNull(jobFileWithMultiEmployerEntity);
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getJobId(),
        jobFileWithMultiEmployerEntity.getJobId());
    assertEquals(now, jobFileWithMultiEmployerEntity.getExpectedDate());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getPriority(),
        jobFileWithMultiEmployerEntity.getPriority());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getDataSourceType(),
        jobFileWithMultiEmployerEntity.getSourceType());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getDataTargetType(),
        jobFileWithMultiEmployerEntity.getTargetType());
  }

  @Test
  public void test_jobFilePriorityEntityToJobModelMultiEmployerTransformer_outbound() {
    JobFilePriorityEntity jobFilePriorityEntity = MockDataUtil.buildJobFilePriorityEntity();
    jobFilePriorityEntity.setDirection("Outbound");
    JobModelMultiEmployer jobFileWithMultiEmployerEntity = jobService
        .jobFilePriorityEntityToJobModelMultiEmployerTransformer(LocalDate.now(),
            jobFilePriorityEntity);
    assertNotNull(jobFileWithMultiEmployerEntity);
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getJobId(),
        jobFileWithMultiEmployerEntity.getJobId());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getPriority(),
        jobFileWithMultiEmployerEntity.getPriority());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getDataSourceType(),
        jobFileWithMultiEmployerEntity.getSourceType());
    assertEquals(MockDataUtil.buildJobFilePriorityEntity().getDataTargetType(),
        jobFileWithMultiEmployerEntity.getTargetType());
  }

  @Test
  public void getJobDetailUpdateErrorCount() {

    JobDetails jobDetails = new JobDetails();
    jobDetails.setJobId(1);
    jobDetails.setJobStatus(JobStatus.IN_PROGRESS.toString());
    jobDetails.setTotalRecordsInFile(4);
    jobDetails.setTotalErrorRecords(1);
    jobDetails.setTotalRecordsProcessedAdapt(1);
    jobDetails.setTotalWarningRecords(1);
    jobDetails.setTotalIgnoredRecords(1);
    jobService.updateJobErrorCount(jobDetails);
    assertNotNull(jobDetails);

  }

  @Test
  public void getJobFilePriortyEntitytoJobModel() {

    JobFilePriorityEntity jobFilePriorityEntity = MockDataUtil.buildJobFilePriorityEntity();
    JobModel jobModel = jobService.jobFilePriorityEntityToJobModel(jobFilePriorityEntity);
    assertNotNull(jobModel);
  }

  @Test
  public void getJobFilePriortyEntitytoJobModel_direction_outBound() {

    JobFilePriorityEntity jobFilePriorityEntity = MockDataUtil.buildJobFilePriorityEntity();
    jobFilePriorityEntity.setDirection("1");
    JobModel jobModel = jobService.jobFilePriorityEntityToJobModel(jobFilePriorityEntity);
    assertNotNull(jobModel);
  }

  @Test
  public void updatejobIntialCountTest() {

    jobService.updateJobIntialCountDetails(1, 0, 0, 0, 0, 1);
    assertNotNull(jobService);

  }

  @Test
  public void updatejobIntialCountTestWithoutJob() {

    jobService.updateJobIntialCountDetails(null, 0, 0, 0, 0, 1);
    assertNotNull(jobService);

  }

}
