package com.adapt.file.messaging;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.alight.adapt.header.AdaptHeader;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.MessagingException;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpServerErrorException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { ErrorHandlingTransformer.class })
public class ErrorHandlingTransformerTest {

  @Autowired
  private ErrorHandlingTransformer errorHandlingTransformer;

  @Test
  public void test_handleFailedInvocation() throws Exception {

    MessagingException messagingException = Mockito.mock(MessagingException.class);

    Map<String, Object> properties = new HashMap<>();
    properties.put(Constant.JOB_ID_HEADER, 1);
    properties.put(Constant.FILE_IDENTIFIER, 1);
    MessageHeaders messageHeaders = new MessageHeaders(properties);

    @SuppressWarnings("rawtypes")
    Message message = Mockito.mock(Message.class);
    Mockito.when(message.getPayload()).thenReturn(messagingException);

    Message failedMessage = Mockito.mock(Message.class);
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);
    Mockito.when(failedMessage.getHeaders()).thenReturn(messageHeaders);

    HttpServerErrorException httpServerErrorException =
        new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    Mockito.when(messagingException.getCause()).thenReturn(httpServerErrorException);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);

  }

  @Test
  public void test_handleFailedWithoutJobDetailsInvocation() throws Exception {

    // properties.put(Constant.JOB_ID_HEADER, "1");
    // properties.put(Constant.RESPONSE, false);
    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();
    JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();

    jobFilePriorityEntity.setJobId(1);
    jobFilePriorityEntity.setFileIdentifier(1);
    jobPriorityGetPayload.setJobFilePriorityEntity(jobFilePriorityEntity);

    @SuppressWarnings("rawtypes")
    Message failedMessage = Mockito.mock(Message.class);

    @SuppressWarnings("rawtypes")
    Message message = Mockito.mock(Message.class);

    MessagingException messagingException = Mockito.mock(MessagingException.class);
    Mockito.when(message.getPayload()).thenReturn(messagingException);
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);
    Mockito.when(failedMessage.getPayload()).thenReturn(jobPriorityGetPayload);

    Map<String, Object> properties = new HashMap<>();
    MessageHeaders messageHeaders = new MessageHeaders(properties);
    Mockito.when(failedMessage.getHeaders()).thenReturn(messageHeaders);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);

  }

  @Test
  public void test_handleFailedWithoutJobDetailsInvocationWithJobId() throws Exception {

    // properties.put(Constant.JOB_ID_HEADER, "1");
    // properties.put(Constant.RESPONSE, false);
    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();
    JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();

    jobFilePriorityEntity.setFileIdentifier(1);
    jobPriorityGetPayload.setJobFilePriorityEntity(jobFilePriorityEntity);

    @SuppressWarnings("rawtypes")
    Message failedMessage = Mockito.mock(Message.class);

    @SuppressWarnings("rawtypes")
    Message message = Mockito.mock(Message.class);

    MessagingException messagingException = Mockito.mock(MessagingException.class);
    Mockito.when(message.getPayload()).thenReturn(messagingException);
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);
    Mockito.when(failedMessage.getPayload()).thenReturn(jobPriorityGetPayload);

    Map<String, Object> properties = new HashMap<>();
    MessageHeaders messageHeaders = new MessageHeaders(properties);
    Mockito.when(failedMessage.getHeaders()).thenReturn(messageHeaders);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);

  }

  @Test
  public void test_handleFailedWithoutJobDetailsInvocationWithNoFilePriority() throws Exception {

    MessagingException messagingException = Mockito.mock(MessagingException.class);

    Map<String, Object> properties = new HashMap<>();
    // properties.put(Constant.JOB_ID_HEADER, "1");
    // properties.put(Constant.RESPONSE, false);
    MessageHeaders messageHeaders = new MessageHeaders(properties);
    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();

    @SuppressWarnings("rawtypes")
    Message failedMessage = Mockito.mock(Message.class);

    @SuppressWarnings("rawtypes")
    Message message = Mockito.mock(Message.class);
    Mockito.when(message.getPayload()).thenReturn(messagingException);
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);
    Mockito.when(failedMessage.getPayload()).thenReturn(jobPriorityGetPayload);

    Mockito.when(failedMessage.getHeaders()).thenReturn(messageHeaders);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNull(doTransform);

  }

  @Test
  public void test_handleFailedWithoutJobDetailsInvocation_object_payload() throws Exception {

    MessagingException messagingException = Mockito.mock(MessagingException.class);

    Map<String, Object> properties = new HashMap<>();
    // properties.put(Constant.JOB_ID_HEADER, "1");
    // properties.put(Constant.RESPONSE, false);
    MessageHeaders messageHeaders = new MessageHeaders(properties);

    @SuppressWarnings("rawtypes")
    Message failedMessage = Mockito.mock(Message.class);

    @SuppressWarnings("rawtypes")
    Message message = Mockito.mock(Message.class);
    Mockito.when(message.getPayload()).thenReturn(messagingException);
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);
    Mockito.when(failedMessage.getPayload()).thenReturn(new Object());

    Mockito.when(failedMessage.getHeaders()).thenReturn(messageHeaders);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNull(doTransform);

  }

  @Test
  public void test_doTransformWithAdaptHeader() throws Exception {

    AdaptHeader adaptHeader = new AdaptHeader.Builder().setJobId(1).build();

    MessageBuilder<?> builder = MessageBuilder.withPayload(1);
    builder.setHeader(Constant.ADAPT_HEADER, new ObjectMapper().writeValueAsString(adaptHeader));
    Message failedMessage = builder.build();

    MessagingException messagingException = Mockito.mock(MessagingException.class);
    MessageBuilder<?> builder2 = MessageBuilder.withPayload(messagingException);
    Message<?> message = builder2.build();

    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);

  }

  @Test
  public void test_doTransformWithoutAdaptHeader() throws Exception {
    MessagingException messagingException = Mockito.mock(MessagingException.class);

    MessageBuilder<?> builder = MessageBuilder.withPayload(1);

    builder.setHeader(Constant.ADAPT_HEADER, null);
    builder.setHeader(Constant.JOB_ID_HEADER, 1);
    builder.setHeader(Constant.FILE_IDENTIFIER, 1);
    builder.setHeader(Constant.FILE_ID, 1);
    builder.setHeader(Constant.FILE_VERSION, 1);
    Message failedMessage = builder.build();
    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);

    MessageBuilder<?> builder2 = MessageBuilder.withPayload(messagingException);

    Message<?> message = builder2.build();

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);
  }

  @Test
  public void test_doTransformWithAdaptHeaderWithDetails() throws Exception {

    AdaptHeader adaptHeader = new AdaptHeader.Builder().setFileId(1).setFileIdentifier(456)
        .setFileVersion(1).setJobId(1).build();

    MessageBuilder<?> builder = MessageBuilder.withPayload(1);
    builder.setHeader(Constant.ADAPT_HEADER, new ObjectMapper().writeValueAsString(adaptHeader));
    Message failedMessage = builder.build();

    MessagingException messagingException = Mockito.mock(MessagingException.class);
    MessageBuilder<?> builder2 = MessageBuilder.withPayload(messagingException);
    Message<?> message = builder2.build();

    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNotNull(doTransform);

  }

  @Test
  public void test_doTransformWithAdaptHeaderNoProcesssing() throws Exception {

    MessagingException messagingException = Mockito.mock(MessagingException.class);

    MessageBuilder<?> builder = MessageBuilder.withPayload(1);

    AdaptHeader adaptHeader = new AdaptHeader.Builder().build();
    builder.setHeader(Constant.ADAPT_HEADER, new ObjectMapper().writeValueAsString(adaptHeader));
    Message failedMessage = builder.build();

    MessageBuilder<?> builder2 = MessageBuilder.withPayload(messagingException);
    Message<?> message = builder2.build();

    Mockito.when(messagingException.getFailedMessage()).thenReturn(failedMessage);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNull(doTransform);

  }

  @Test
  public void test_doTransformWithOutFailedMessage() throws Exception {

    MessagingException messagingException = Mockito.mock(MessagingException.class);

    MessageBuilder<?> builder2 = MessageBuilder.withPayload(messagingException);
    Message<?> message = builder2.build();

    Mockito.when(messagingException.getFailedMessage()).thenReturn(null);

    Object doTransform = errorHandlingTransformer.doTransform(message);
    assertNull(doTransform);

  }

  @Test
  public void test_doTransformWithOutMessage() throws Exception {

    Object doTransform = errorHandlingTransformer.doTransform(null);
    assertNull(doTransform);

  }

}
