package com.adapt.file.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.file.messaging.MessageSizeSplitter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { MessageSizeSplitter.class })
@TestPropertySource(properties = { "splitSize=2" })
public class MessageSizeSplitterTest {

  private MessageSizeSplitter messageSizeSplitter = new MessageSizeSplitter();

  private static final String bytes1020String = "1020"
      + "56789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678910123456789101234567891012345678";

  // json add "" and [] for this message
  private static final String bytes2044String = "2044" + bytes1020String + bytes1020String;

  @Test
  public void splitMessageTest() {
    List<Object> payload = new ArrayList<>();
    payload.add(bytes2044String);
    payload.add(bytes1020String);
    payload.add(bytes1020String);
    payload.add(bytes1020String);

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    List<String> splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    assertEquals(4, splitMessage.size());
  }

  @Test
  public void splitMessagePayLoadNonCollectionTest() {

    Object payload = new Object();

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    Object splitMessage = messageSizeSplitter.splitMessage(builder.build());
    assertEquals(payload, splitMessage);
  }

  @Test
  public void splitMessagePayLoadEmptyTest() {

    List<Object> payload = new ArrayList<>();

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    List<String> splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    assertEquals(0, splitMessage.size());

  }

  @Test
  public void splitMessage_SamePayloadSizeAsMaxTest() {

    List<Object> payload = new ArrayList<>();
    payload.add(bytes2044String);
    payload.add(bytes2044String);

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    List<String> splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    assertEquals(2, splitMessage.size());

  }

  @Test
  public void splitMessage_SamePayloadSizeAsMaxAndLessSizeTest() {

    List<Object> payload = new ArrayList<>();
    payload.add(bytes2044String);
    payload.add(bytes1020String);

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    List<String> splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    assertEquals(2, splitMessage.size());

    payload = new ArrayList<>();
    payload.add(bytes1020String);
    payload.add(bytes2044String);

    builder = new DefaultMessageBuilderFactory().withPayload(payload);

    splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    assertEquals(2, splitMessage.size());

  }

  @Test
  public void splitMessageRecordIsBiggerThanMaxTest() {
    List<Object> payload = new ArrayList<>();
    payload.add(bytes2044String + bytes1020String);
    payload.add(bytes1020String);
    payload.add(bytes1020String);
    Map<String, Object> header = new HashMap<>();
    payload.add(header);
    Map<String, Object> footer = new HashMap<>();
    payload.add(footer);

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(payload);

    List<String> splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    // check remove header and footer
    assertEquals(4, splitMessage.size());



    payload = new ArrayList<>();
    payload.add(bytes1020String);
    payload.add(bytes2044String + bytes1020String);
    payload.add(bytes1020String);
    header = new HashMap<>();
    payload.add(header);
    footer = new HashMap<>();
    payload.add(footer);

    builder = new DefaultMessageBuilderFactory().withPayload(payload);

    splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    // check remove header and footer
    assertEquals(4, splitMessage.size());


    payload = new ArrayList<>();
    payload.add(bytes1020String);
    payload.add(bytes1020String);
    payload.add(bytes2044String + bytes1020String);
    header = new HashMap<>();
    payload.add(header);
    footer = new HashMap<>();
    payload.add(footer);

    builder = new DefaultMessageBuilderFactory().withPayload(payload);

    splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    // check remove header and footer
    assertEquals(4, splitMessage.size());

    payload = new ArrayList<>();
    payload.add(bytes2044String + bytes1020String);
    header = new HashMap<>();
    payload.add(header);
    footer = new HashMap<>();
    payload.add(footer);

    builder = new DefaultMessageBuilderFactory().withPayload(payload);

    splitMessage = (List<String>) messageSizeSplitter.splitMessage(builder.build());
    // check remove header and footer
    assertEquals(2, splitMessage.size());

  }

}
