package com.adapt.file.service;

import static org.junit.Assert.assertNotNull;

import com.adapt.config.CacheScheduler;
import com.adapt.file.entity.JobFileEntity;
import java.util.ArrayList;
import java.util.Collection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CacheScheduler.class, JobServiceImpl.class,
    SecondaryDataServiceImpl.class })
public class CacheSchedulerTest {

  @Autowired
  private CacheScheduler cacheScheduler;

  @MockBean
  private JobService jobService;

  @MockBean
  private SecondaryDataService secondaryDataService;

  @Test
  public void test_getCurrentDayJobDetails() {
    JobFileEntity jfe = new JobFileEntity();
    jfe.setFileIdentifier(1);

    Collection<JobFileEntity> jobFileEntities = new ArrayList<>(1);
    jobFileEntities.add(jfe);

    Mockito.when(jobService.findJobsByExpectedDate(Mockito.any())).thenReturn(jobFileEntities);
    Mockito.when(secondaryDataService.getSecondaryDataInfo(Mockito.anyInt()))
        .thenReturn(new ArrayList<>());
    cacheScheduler.getCurrentDayJobDetails();
    assertNotNull(cacheScheduler);
  }

  @Test
  public void test_removeCache() {
    Mockito.doNothing().when(secondaryDataService).removeSecondaryDataFromCache();
    cacheScheduler.removeCache();
    assertNotNull(cacheScheduler);
  }
}
