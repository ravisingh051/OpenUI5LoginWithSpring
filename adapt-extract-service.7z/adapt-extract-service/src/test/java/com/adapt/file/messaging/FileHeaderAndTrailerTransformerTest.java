package com.adapt.file.messaging;

import static org.assertj.core.api.Assertions.assertThat;

import com.adapt.config.Constant;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { FileHeaderAndTrailerTransformer.class })
public class FileHeaderAndTrailerTransformerTest {

  @Autowired
  FileHeaderAndTrailerTransformer fileHeaderAndTrailerTransformer;

  @Rule
  public TemporaryFolder temporaryFolder = new TemporaryFolder();

  @Test
  public void testTransformHeader_headerAndTrailerPresent() throws Exception {

    File output = temporaryFolder.newFolder("reports").toPath().resolve("output.txt").toFile();

    try (BufferedWriter writer = new BufferedWriter(
        new OutputStreamWriter(new FileOutputStream(output), "UTF-8"))) {
      writer.write("abc" + "\r\n" + "def" + "\r\n" + "ghi" + "\r\n");
    }

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(output);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    Message<?> temp = fileHeaderAndTrailerTransformer.doTransform(builder.build());

    File updatedFile = (File) temp.getPayload();
    assertThat(updatedFile).hasContent("def" + "\r\n");

  }

  @Test
  public void testTransformHeader_headerAndTrailerNotPresent() throws Exception {

    File output = temporaryFolder.newFolder("reports").toPath().resolve("output.txt").toFile();

    try (BufferedWriter writer = new BufferedWriter(
        new OutputStreamWriter(new FileOutputStream(output), "UTF-8"))) {
      writer.write("abc" + "\r\n" + "def" + "\r\n" + "ghi" + "\r\n");
    }

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(output);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, false);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);
    Message<?> temp = fileHeaderAndTrailerTransformer.doTransform(builder.build());

    File updatedFile = (File) temp.getPayload();
    assertThat(updatedFile).hasContent("abc" + "\r\n" + "def" + "\r\n" + "ghi" + "\r\n");

  }

  @Test
  public void testTransformHeader_headerAndTrailerNotPresentWithoutLastLine() throws Exception {

    File output = temporaryFolder.newFolder("reports").toPath().resolve("output.txt").toFile();

    try (BufferedWriter writer = new BufferedWriter(
        new OutputStreamWriter(new FileOutputStream(output), "UTF-8"))) {
      writer.write("abc");
    }

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(output);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, false);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);
    Message<?> temp = fileHeaderAndTrailerTransformer.doTransform(builder.build());

    File updatedFile = (File) temp.getPayload();
    assertThat(updatedFile).hasContent("abc");

  }

}
