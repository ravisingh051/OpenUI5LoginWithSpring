package com.adapt.file.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.repository.JobPrioritizationAuditRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CleanAuditDetailsService.class })
@TestPropertySource(properties = { "source.instance.identifier=1" })
public class CleanAuditDetailsServiceTest {

  @Autowired
  private CleanAuditDetailsService cleanAuditDetailsService;

  @MockBean
  private JobPrioritizationAuditRepository jobPrioritizationAuditRepository;

  @Test
  public void test_cleanup1() throws Exception {

    Boolean completed = cleanAuditDetailsService.isCleanupCompleted();
    cleanAuditDetailsService.run(null);
    completed = cleanAuditDetailsService.isCleanupCompleted();
    assertEquals(true, completed);

  }

}
