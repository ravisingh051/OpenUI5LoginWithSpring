package com.adapt.file.messaging;

import static org.junit.Assert.assertFalse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BlackoutWindowPollSkipStrategy.class })
public class BlackoutWindowPollSkipStrategyTest {

  @Autowired
  private BlackoutWindowPollSkipStrategy blackoutWindowPollSkipStrategy;

  @Test
  public void testSkipPoll_dummyTest_shouldRunSuccessfully() {
    boolean skipPoll = blackoutWindowPollSkipStrategy.skipPoll();
    assertFalse(skipPoll);
  }

}
