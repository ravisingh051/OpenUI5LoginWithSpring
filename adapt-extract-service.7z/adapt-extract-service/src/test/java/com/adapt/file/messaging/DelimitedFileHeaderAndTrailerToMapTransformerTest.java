package com.adapt.file.messaging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.service.FileAttributePreparer;
import com.adapt.util.MockDataUtil;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DelimitedFileHeaderAndTrailerToMapTransformer.class,
    FileAttributePreparer.class })
public class DelimitedFileHeaderAndTrailerToMapTransformerTest {

  @Autowired
  private DelimitedFileHeaderAndTrailerToMapTransformer delimitedFileHeaderAndTrailerToMapTransformer;

  @Test
  public void testTransform() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_HEADER, "01|000001|20150908|F|3007|");
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_HEADER, "99|000000|");

    Message<?> temp = delimitedFileHeaderAndTrailerToMapTransformer.doTransform(builder.build());
    Map<String, Object> headerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_HEADER_MAP_HEADER);
    Map<String, Object> footerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_FOOTER_MAP_HEADER);
    assertNotNull(headerAttributes);
    assertEquals("01", headerAttributes.get("customDefined1"));
    assertEquals("99", footerAttributes.get("customDefined2"));
  }

  @Test
  public void testTransformNoHeaderAndFooter() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, false);
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, false);

    Message<?> temp = delimitedFileHeaderAndTrailerToMapTransformer.doTransform(builder.build());
    Map<String, Object> headerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_HEADER_MAP_HEADER);
    Map<String, Object> footerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_FOOTER_MAP_HEADER);
    assertEquals(null, headerAttributes);
    assertEquals(null, footerAttributes);
  }

  @Test
  public void testTransformWithHeaderEmpty() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_HEADER, "");
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_HEADER, "99|000000|");

    Message<?> temp = delimitedFileHeaderAndTrailerToMapTransformer.doTransform(builder.build());
    Map<String, Object> headerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_HEADER_MAP_HEADER);
    Map<String, Object> footerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_FOOTER_MAP_HEADER);
    assertNotNull(headerAttributes);
    assertTrue(headerAttributes.isEmpty());
    assertEquals("99", footerAttributes.get("customDefined2"));

  }

  @Test
  public void testTransformWithHeaderAndTrailerEmpty() throws Exception {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");
    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();

    builder.setHeader("JOB_MODEL", jobModel);
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_HEADER_HEADER, "");
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, true);
    builder.setHeader(Constant.FILE_FOOTER_HEADER, "");

    Message<?> temp = delimitedFileHeaderAndTrailerToMapTransformer.doTransform(builder.build());
    Map<String, Object> headerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_HEADER_MAP_HEADER);
    Map<String, Object> footerAttributes = (Map<String, Object>) temp.getHeaders()
        .get(Constant.FILE_FOOTER_MAP_HEADER);
    assertNotNull(headerAttributes);
    assertTrue(headerAttributes.isEmpty());
    assertTrue(footerAttributes.isEmpty());
  }

}