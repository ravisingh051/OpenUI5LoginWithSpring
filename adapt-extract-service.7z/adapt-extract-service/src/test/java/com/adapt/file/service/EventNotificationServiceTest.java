package com.adapt.file.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.adapt.event.AdaptDatatypeTransformationExceptionOccuredEvent;
import com.adapt.event.DatasetCountExceedOccurred;
import com.adapt.event.DatasetCountSubceedOccurred;
import com.adapt.event.InboundFileOccurred;
import com.adapt.event.JobCompletedOccurredEvent;
import com.adapt.event.JobFailedOccurredEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.AsyncRestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { EventNotificationServiceImpl.class })
public class EventNotificationServiceTest {

  @Autowired
  private EventNotificationService eventNotificationService;

  @MockBean
  private AsyncRestTemplate asyncRestTemplate;

  @SuppressWarnings("unchecked")
  @Test
  public void sendInboundFileOccuredNotification() {
    InboundFileOccurred event = new InboundFileOccurred();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);
    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendInboundFileOccuredNotification(event);
    assertNotNull(event);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void sendCountExceededOccuredNotification() {
    DatasetCountExceedOccurred event = new DatasetCountExceedOccurred();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);

    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendCountExceededOccurredNotification(event);
    assertNotNull(event);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void sendCountSubceededOccuredNotification() {
    DatasetCountSubceedOccurred event = new DatasetCountSubceedOccurred();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);

    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendCountSubceededOccurredNotification(event);
    assertNotNull(event);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void sendDataTypeTransformationExceptionTest() {
    AdaptDatatypeTransformationExceptionOccuredEvent event =
        new AdaptDatatypeTransformationExceptionOccuredEvent();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);

    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendDataTypeTransformationExceptionEvent(event);
    assertNotNull(event);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void sendJobFailedExceptionTest() {
    JobFailedOccurredEvent event = new JobFailedOccurredEvent();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);

    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendJobFailedEvent(event);
    assertNotNull(event);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void sendJobCompletedTest() {
    JobCompletedOccurredEvent event = new JobCompletedOccurredEvent();
    event.setFileId(1);
    event.setFileVersion(1);
    event.setJobId(1);

    when(asyncRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class)))
        .thenReturn(null);
    eventNotificationService.sendJobCompletedEvent(event);
    assertNotNull(event);
  }

}
