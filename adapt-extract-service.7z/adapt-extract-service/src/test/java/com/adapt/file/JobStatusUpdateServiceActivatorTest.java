package com.adapt.file;

import static org.junit.Assert.assertNotNull;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.messaging.JobStatusUpdateServiceActivator;
import com.adapt.file.service.JobService;
import com.adapt.file.service.JobServiceImpl;
import com.adapt.util.MockDataUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobStatusUpdateServiceActivator.class, JobServiceImpl.class })
public class JobStatusUpdateServiceActivatorTest {

  @Autowired
  private JobStatusUpdateServiceActivator jobStatusUpdateServiceActivator;

  @MockBean
  private JobService jobService;

  @Test
  public void testUpdateJobStatus() {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");

    builder.setHeader(Constant.JOB_MODEL_HEADER, MockDataUtil.buildDelimitedJobModel());

    Message<?> updateJobStatus = jobStatusUpdateServiceActivator.updateJobStatus(builder.build());
    assertNotNull(updateJobStatus);

  }

  @Test(expected = InvalidMessage.class)
  public void testUpdateJobStatus_jobid_null() {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");

    JobModel jobModel = MockDataUtil.buildDelimitedJobModel();
    jobModel.setJobId(null);
    builder.setHeader(Constant.JOB_MODEL_HEADER, jobModel);
    Message<?> updateJobStatus = jobStatusUpdateServiceActivator.updateJobStatus(builder.build());
    assertNotNull(updateJobStatus);

  }
}
