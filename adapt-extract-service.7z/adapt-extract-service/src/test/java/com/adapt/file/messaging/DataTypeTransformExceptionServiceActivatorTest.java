package com.adapt.file.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.config.Constant;
import com.adapt.exception.NullResponseException;
import com.adapt.file.service.EventNotificationService;
import com.adapt.file.service.JobService;
import com.adapt.util.MockDataUtil;
import com.alight.adapt.datasets.AbstractDataset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.AsyncRestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DataTypeTransformExceptionServiceActivator.class })
public class DataTypeTransformExceptionServiceActivatorTest {

  @MockBean
  private EventNotificationService eventNotificationService;

  @MockBean
  private JobService jobService;

  @MockBean
  private AsyncRestTemplate asyncRestTempalte;

  @Autowired
  private DataTypeTransformExceptionServiceActivator dataTypeTransformExceptionServiceActivator;

  @Test
  public void testSendError_Sucess() {

    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_ID_HEADER, 1);
    headerMap.put(Constant.FILE_IDENTIFIER, 1);
    List<AbstractDataset> payload = MockDataUtil.buildAceAbstractAllDataSet();
    MessageBuilder<List<AbstractDataset>> builder =
        new DefaultMessageBuilderFactory().withPayload(payload).copyHeaders(headerMap);
    Message<List<AbstractDataset>> message = builder.build();
    Message<?> sendEventAndFilter =
        dataTypeTransformExceptionServiceActivator.sendEventAndFilter(message);
    assertNotNull(sendEventAndFilter);

  }

  @Test(expected = NullResponseException.class)
  public void testSendError_PayloadEmpty() {

    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_ID_HEADER, 1);
    headerMap.put(Constant.FILE_IDENTIFIER, 1);
    List<AbstractDataset> payload = new ArrayList<AbstractDataset>(0);
    MessageBuilder<List<AbstractDataset>> builder =
        new DefaultMessageBuilderFactory().withPayload(payload).copyHeaders(headerMap);
    Message<List<AbstractDataset>> message = builder.build();
    dataTypeTransformExceptionServiceActivator.sendEventAndFilter(message);

  }

  @Test(expected = NullResponseException.class)
  public void testSendError_AllError() {

    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_ID_HEADER, 1);
    headerMap.put(Constant.FILE_IDENTIFIER, 1);
    List<AbstractDataset> payload = MockDataUtil.buildAceAbstractFailedDataSet();

    MessageBuilder<List<AbstractDataset>> builder =
        new DefaultMessageBuilderFactory().withPayload(payload).copyHeaders(headerMap);
    Message<List<AbstractDataset>> message = builder.build();
    dataTypeTransformExceptionServiceActivator.sendEventAndFilter(message);

  }

  @Test(expected = NullResponseException.class)
  public void testSendError_adaptFileIdAndJobIdIsNull() {

    Map<String, Object> headerMap = new HashMap<String, Object>();
    headerMap.put(Constant.JOB_ID_HEADER, null);
    headerMap.put(Constant.FILE_IDENTIFIER, null);

    List<AbstractDataset> payload = MockDataUtil.buildAceAbstractFailedDataSet();

    MessageBuilder<List<AbstractDataset>> builder =
        new DefaultMessageBuilderFactory().withPayload(payload).copyHeaders(headerMap);
    Message<List<AbstractDataset>> message = builder.build();
    dataTypeTransformExceptionServiceActivator.sendEventAndFilter(message);

  }

}