package com.adapt.file.messaging;

import com.adapt.exception.NullResponseException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { GatewayNullResponseServiceActivator.class })
public class GatewayNullResponseServiceActivatorTest {

  @Autowired
  private GatewayNullResponseServiceActivator gatewayNullResponseServiceActivator;

  @Test(expected = NullResponseException.class)
  public void test_cleanup1() throws Exception {
    Message<?> message = Mockito.mock(Message.class);
    gatewayNullResponseServiceActivator.handleGatewayNullResponse(message);

  }

}
