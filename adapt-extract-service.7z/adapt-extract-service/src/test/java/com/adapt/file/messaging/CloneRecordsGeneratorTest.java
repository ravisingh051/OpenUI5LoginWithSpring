package com.adapt.file.messaging;

import static org.junit.Assert.assertTrue;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.util.MockDataUtil;
import com.alight.adapt.datasets.AbstractDataset;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CloneRecordsGenerator.class })
public class CloneRecordsGeneratorTest {

  @Autowired
  private CloneRecordsGenerator cloneRecordsGenerator;

  @Test
  public void test_generateClones() throws Exception {

    JobModel job = MockDataUtil.buildDelimitedJobModel();
    Message<List<AbstractDataset>> messageList = MessageBuilder
        .withPayload(MockDataUtil.buildAceAbstractAllDataSet())
        .setHeader(Constant.JOB_MODEL_HEADER, job).build();

    Message<List<AbstractDataset>> newMessageList = cloneRecordsGenerator
        .generateClones(messageList);
    assertTrue(!newMessageList.getPayload().isEmpty());
  }

}
