package com.adapt.workorder.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.config.Constant;
import com.adapt.exception.JobModelConvesionException;
import com.adapt.file.entity.FileModel;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.entity.MessageFormat;
import com.adapt.file.entity.MessageFormatType;
import com.adapt.file.entity.MessageType;
import com.adapt.file.entity.Section;
import com.adapt.file.entity.SectionAttributeEntity;
import com.adapt.file.service.JobService;
import com.adapt.file.service.SecondaryDataService;
import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobHeaderSetFromPriorityJobServiceActivator.class,
    PgpRsaPublicPrivateKeyGenerator.class })
public class JobHeaderSetFromPriorityJobServiceActivatorTest {

  @Autowired
  private JobHeaderSetFromPriorityJobServiceActivator jobHeaderSetFromPriorityJobServiceActivator;

  @MockBean
  private JobService jobService;

  @MockBean
  private SecondaryDataService secondaryDataService;

  @Test
  public void tes_transformation() throws Exception {

    JobPriorityGetPayload jobPriorityGetPayload = createJobPriorityGetPaylod();
    Mockito
        .when(jobService
            .jobFilePriorityEntityToJobModel(jobPriorityGetPayload.getJobFilePriorityEntity()))
        .thenReturn(getJobModel());
    Message<JobPriorityGetPayload> message = MessageBuilder.withPayload(jobPriorityGetPayload)
        .build();
    message = jobHeaderSetFromPriorityJobServiceActivator.getFileFromJobPriorityDetail(message);
    assertNotNull(message.getHeaders().get(Constant.JOB_MODEL_HEADER));

  }

  @Test(expected = JobModelConvesionException.class)
  public void tes_transformation_noJobModel() throws Exception {

    JobPriorityGetPayload jobPriorityGetPayload = createJobPriorityGetPaylod();
    Mockito
        .when(jobService
            .jobFilePriorityEntityToJobModel(jobPriorityGetPayload.getJobFilePriorityEntity()))
        .thenReturn(null);
    Message<JobPriorityGetPayload> message = MessageBuilder.withPayload(jobPriorityGetPayload)
        .build();
    jobHeaderSetFromPriorityJobServiceActivator.getFileFromJobPriorityDetail(message);

  }

  private JobPriorityGetPayload createJobPriorityGetPaylod() {

    String privateKey = "hello";
    JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();
    jobFilePriorityEntity.setJobId(1);
    jobFilePriorityEntity.setExpectedDate(new Date(new java.util.Date().getTime()));
    jobFilePriorityEntity.setErrorThreshHold(1);
    jobFilePriorityEntity.setFileMinRecordCountAllowed(1);
    jobFilePriorityEntity.setFileTransmissionName("fileName");
    jobFilePriorityEntity.setFileType("census");
    jobFilePriorityEntity.setFileFormatName("csv");
    jobFilePriorityEntity.setRowDelimiter("\n");
    jobFilePriorityEntity.setFieldDelimiter(",");
    jobFilePriorityEntity.setEscapeCharacter("1");
    jobFilePriorityEntity.setSegmentDelimiter("1");
    jobFilePriorityEntity.setPriority(1);
    jobFilePriorityEntity.setEmployerIdAndClientIdAndTestCfgs("1::1::QX2B,2::1::QX2B");
    jobFilePriorityEntity.setMasterFileTemplateId(1);
    jobFilePriorityEntity.setMasterFileTemplateVersion(1);
    jobFilePriorityEntity.setFullOrChange(1);
    jobFilePriorityEntity.setResultsMode(1);
    jobFilePriorityEntity.setFileMaxRecordCountAllowed(100);
    jobFilePriorityEntity.setFileProcessingErrorThresholdFormat("1");
    jobFilePriorityEntity.setFileIdentifier(1);
    jobFilePriorityEntity.setFileId(1);
    jobFilePriorityEntity.setFileVersion(1);
    jobFilePriorityEntity.setCloneNumberList("1,2");

    jobFilePriorityEntity.setFileStateId(1);
    jobFilePriorityEntity.setFilePath("filePath");
    jobFilePriorityEntity.setFileName("fileName");

    byte[] privateKey_byte = privateKey.getBytes(StandardCharsets.UTF_8);
    jobFilePriorityEntity.setFileStatePrivatekey(privateKey_byte);

    jobFilePriorityEntity.setMasterPrivateKey("master");
    jobFilePriorityEntity.setFileNewName("fileName");

    jobFilePriorityEntity.setSectionAttributeEntities(createSectionAttributeEntity());

    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();
    jobPriorityGetPayload.setJobFilePriorityEntity(jobFilePriorityEntity);
    return jobPriorityGetPayload;

  }

  private List<SectionAttributeEntity> createSectionAttributeEntity() {
    SectionAttributeEntity sectionAttributeEntity = new SectionAttributeEntity();
    sectionAttributeEntity.setStandardizedName("firstName");
    sectionAttributeEntity.setAttributeDataType("int");
    sectionAttributeEntity.setOrder(1);
    sectionAttributeEntity.setSectionType("1");
    sectionAttributeEntity.setSectionDelimiter(",");
    sectionAttributeEntity.setIsAttributeMandatory(true);
    sectionAttributeEntity.setAttributeSize(1);
    sectionAttributeEntity.setAttributeStartPosition(1);
    sectionAttributeEntity.setAttributeEndPosition(2);

    List<SectionAttributeEntity> sectionAttributeList = new ArrayList<>();
    sectionAttributeList.add(sectionAttributeEntity);
    return sectionAttributeList;
  }

  /**
   * Gets the job model.
   *
   * @return the job model
   */
  public JobModel getJobModel() {
    JobModel jobModel = new JobModel();
    jobModel.setJobId(1);
    jobModel.setExpectedDate(LocalDate.now());
    jobModel.setPriority(1);

    jobModel.setEmployerId(123);
    jobModel.setClientId("1");
    jobModel.setFullOrChange(true);
    jobModel.setTestCfgConfig("QX2B");

    // File Model Values
    FileModel fileModel = new FileModel();
    fileModel.setFileIdentifier(1);
    fileModel.setFileId(1);
    fileModel.setFileVersion(1);
    fileModel.setFileTransmissionName("darden.txt");
    fileModel.setFileType(MessageType.INBOUND_ACA_FTE_DATASET);
    fileModel.setErrorThreshold(1);
    fileModel.setFileMinRecordCountAllowed(1);
    fileModel.setMasterFileTemplateId(1);
    fileModel.setMasterFileTemplateVersion(1);
    fileModel.setResultsMode(true);
    fileModel.setFileMaxRecordCountAllowed(1);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat.NONE);

    // Message Format Values
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter("\n");
    messageFormat.setFieldDelimiter(",");
    messageFormat.setMessageFormatType(MessageFormatType.FILE_DELIMITED);
    messageFormat.setRowDelimiter("\n");
    messageFormat.setSegmentDelimiter("1");
    fileModel.setMessageFormat(messageFormat);

    Set<Section> sectionSet = new HashSet<>();
    fileModel.setSections(new ArrayList<>(sectionSet));
    jobModel.setFileModel(fileModel);

    List<Integer> list = Arrays.asList(1, 2, 3);
    jobModel.setCloneNumberList(list);
    return jobModel;

  }

}
