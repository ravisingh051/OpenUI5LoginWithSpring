package com.adapt.workorder.messaging;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = { "passcode=ADaPT_APP@123" })
@SpringBootTest(classes = { PgpRsaPublicPrivateKeyGenerator.class })
public class PgpRsaPublicPrivateKeyGeneratorTest {

  @Value("${passcode}")
  private String passcode;

  @Autowired
  private PgpRsaPublicPrivateKeyGenerator pgpRsaPublicPrivateKeyGenerator;

  @Test
  public void test_generatePublicPrivateKey_with_stream() throws Exception {
    ByteArrayOutputStream pubKeyStream = new ByteArrayOutputStream();
    ByteArrayOutputStream privateKeyStream = new ByteArrayOutputStream();
    pgpRsaPublicPrivateKeyGenerator.generatePublicPrivateKey(pubKeyStream, privateKeyStream);
    assertNotEquals(0, privateKeyStream.size());
  }

  @Test
  public void test_encryptFileStream() throws Exception {
    String key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "mQENBFwY7ocDCACcMJUl/pt5rcTXFGTivkCu2lR/ho2SuIcMIRht+ET8RX9nI36z\r\n"
        + "Nb/juvrsd8jWWqkhm7NdDRr3FMINKooAaD8dJvqxCLS3r37Q76kX2vrEnNClTjTL\r\n"
        + "UKw5v5Kg8lw43j7dLgTqtCi3pAMtkSnxY61Hn7p2JJLjkqLNmJvClT2Y72wZl7E2\r\n"
        + "tlo8CeRak5VFZXVuri4TzTXdyxJ8FMmnqHlsZP2ElmpD1GpJ/TKgABhqaKKvYaIU\r\n"
        + "wrsRhKX/0gf/fpGg+oLTcv2MQm/9t5bkypqGYIWZTz6CsROFKwW/XbmNB4PcSrl9\r\n"
        + "6/wpdXpi8/j9JEyQm/o06TpqglTdniqbIfMLABEBAAG0FTEuMi44NDAuMTEzNTQ5\r\n"
        + "LjEuMS4xMokBKAQTAwkAEgUCXBjuiAIbAwILCQIVCQIeAQAKCRA8NgZBaudCwYOH\r\n"
        + "B/0dZYmNSnoTSaaG7NELPiNR5Ln9PHRb1efLB85SA4OpC4w/weDXdaQqeTv6uS8x\r\n"
        + "SbABRxMLSyaNFMKaSl3hAmKV0jzcJPRkWHuxpjt3aLAZCCRvoCDDynjjPkPCbQqL\r\n"
        + "bvMNL89xvZK+IzNnOiAU8zeiwqy0NaucjJbqMoGb9PM94pKtLWq8T4oyQkuTnOsS\r\n"
        + "zH8937cxcqO3SDF3fyebbSYWgl1eo6qCtHFZ/0WsWMZ7dYxhPohzYCQsysYQA4pC\r\n"
        + "Ht4RYHZfeDsfkTuwDpOEUwrF+jbFm3f6A2bcJrsGlPg/XroPTfHCCeHe7dvbjNq5\r\n"
        + "GjdQR/XmBu9PawB0lOKcnMD9uQENBFwY7ogCCADOTtAZNkOG7LTrViKy2HDXz/Mi\r\n"
        + "vrxXHnn3N4p6k6aWQz+sPZ8VnTsZ9jZNs8TWT3zuoTps3m/oUHA19aqqxoIJiFYp\r\n"
        + "xzTIo9d8q5ZkoYWgR9DFoykmKYyHKwlH75tBR+sHCQNxCJOL/rNtkzpinKv6ZnYc\r\n"
        + "TMl42VA7lKIZzgQOy6pA3sA455kHfTPLZIe1wBIuet8xhryjBdA48JejG6LE4J4j\r\n"
        + "1dzPVedQ8LgR1bJH0yDr3ywFE8N3BDsAcz/OJqKaIIEbY//KsC6v6kSspNgn2a2H\r\n"
        + "/8lMLuCiRMliw2RwgQJbEiazwXlRzLxZtvJ4pMAMNVbvxyDCtWRbVrhuKThRABEB\r\n"
        + "AAGJAR8EGAMJAAkFAlwY7ogCGwwACgkQPDYGQWrnQsGDGgf+MKHr/AslfdT2yG5r\r\n"
        + "uUU/5syzCdTHACYd1ObmTmcPnFWrBXOhNeD87gYa5FfF+KpjkQhfhV6ZsB6v8quF\r\n"
        + "CwCZMnIL6Mm4Zlds5PqvXXtKvY4r4Q2ab/RxrmYTDa196IauNPHk3Z2lz7NSrLoR\r\n"
        + "saMiqWUYdCwW7r3mG71afloTysE+GyLDcqiSahHJyXd6hfeij3aYeqhMk+mqFUc+\r\n"
        + "4fNCh2OHYHkgBJaMj0u2vs6zT3Um9Y5F2aoZuDf853KqtQCphIPN1O8mCAiWpAPZ\r\n"
        + "+NCnBi0JXsgTo0xHYcAU34Fsa68iZhUi34WsfVcbktBksAJ/Gl/lGrqKTsJTRZ68\r\n" + "bND60w==\r\n"
        + "=EkYv\r\n" + "-----END PGP PUBLIC KEY BLOCK-----";
    InputStream in = new ByteArrayInputStream(key.getBytes(StandardCharsets.UTF_8));
    PGPPublicKey pgpKey = pgpRsaPublicPrivateKeyGenerator.readPublicKey(in);
    byte[] content = "fileContent".getBytes(StandardCharsets.UTF_8);
    byte[] fileContent = content;
    ByteArrayOutputStream pubKeyStream = new ByteArrayOutputStream();
    pgpRsaPublicPrivateKeyGenerator.encryptStream(pubKeyStream, fileContent, pgpKey, true, true);
    assertNotEquals(pubKeyStream.toByteArray(), fileContent);
  }

  @Test
  public void test_readPublicKey() throws Exception {
    String key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "mQENBFwY7ocDCACcMJUl/pt5rcTXFGTivkCu2lR/ho2SuIcMIRht+ET8RX9nI36z\r\n"
        + "Nb/juvrsd8jWWqkhm7NdDRr3FMINKooAaD8dJvqxCLS3r37Q76kX2vrEnNClTjTL\r\n"
        + "UKw5v5Kg8lw43j7dLgTqtCi3pAMtkSnxY61Hn7p2JJLjkqLNmJvClT2Y72wZl7E2\r\n"
        + "tlo8CeRak5VFZXVuri4TzTXdyxJ8FMmnqHlsZP2ElmpD1GpJ/TKgABhqaKKvYaIU\r\n"
        + "wrsRhKX/0gf/fpGg+oLTcv2MQm/9t5bkypqGYIWZTz6CsROFKwW/XbmNB4PcSrl9\r\n"
        + "6/wpdXpi8/j9JEyQm/o06TpqglTdniqbIfMLABEBAAG0FTEuMi44NDAuMTEzNTQ5\r\n"
        + "LjEuMS4xMokBKAQTAwkAEgUCXBjuiAIbAwILCQIVCQIeAQAKCRA8NgZBaudCwYOH\r\n"
        + "B/0dZYmNSnoTSaaG7NELPiNR5Ln9PHRb1efLB85SA4OpC4w/weDXdaQqeTv6uS8x\r\n"
        + "SbABRxMLSyaNFMKaSl3hAmKV0jzcJPRkWHuxpjt3aLAZCCRvoCDDynjjPkPCbQqL\r\n"
        + "bvMNL89xvZK+IzNnOiAU8zeiwqy0NaucjJbqMoGb9PM94pKtLWq8T4oyQkuTnOsS\r\n"
        + "zH8937cxcqO3SDF3fyebbSYWgl1eo6qCtHFZ/0WsWMZ7dYxhPohzYCQsysYQA4pC\r\n"
        + "Ht4RYHZfeDsfkTuwDpOEUwrF+jbFm3f6A2bcJrsGlPg/XroPTfHCCeHe7dvbjNq5\r\n"
        + "GjdQR/XmBu9PawB0lOKcnMD9uQENBFwY7ogCCADOTtAZNkOG7LTrViKy2HDXz/Mi\r\n"
        + "vrxXHnn3N4p6k6aWQz+sPZ8VnTsZ9jZNs8TWT3zuoTps3m/oUHA19aqqxoIJiFYp\r\n"
        + "xzTIo9d8q5ZkoYWgR9DFoykmKYyHKwlH75tBR+sHCQNxCJOL/rNtkzpinKv6ZnYc\r\n"
        + "TMl42VA7lKIZzgQOy6pA3sA455kHfTPLZIe1wBIuet8xhryjBdA48JejG6LE4J4j\r\n"
        + "1dzPVedQ8LgR1bJH0yDr3ywFE8N3BDsAcz/OJqKaIIEbY//KsC6v6kSspNgn2a2H\r\n"
        + "/8lMLuCiRMliw2RwgQJbEiazwXlRzLxZtvJ4pMAMNVbvxyDCtWRbVrhuKThRABEB\r\n"
        + "AAGJAR8EGAMJAAkFAlwY7ogCGwwACgkQPDYGQWrnQsGDGgf+MKHr/AslfdT2yG5r\r\n"
        + "uUU/5syzCdTHACYd1ObmTmcPnFWrBXOhNeD87gYa5FfF+KpjkQhfhV6ZsB6v8quF\r\n"
        + "CwCZMnIL6Mm4Zlds5PqvXXtKvY4r4Q2ab/RxrmYTDa196IauNPHk3Z2lz7NSrLoR\r\n"
        + "saMiqWUYdCwW7r3mG71afloTysE+GyLDcqiSahHJyXd6hfeij3aYeqhMk+mqFUc+\r\n"
        + "4fNCh2OHYHkgBJaMj0u2vs6zT3Um9Y5F2aoZuDf853KqtQCphIPN1O8mCAiWpAPZ\r\n"
        + "+NCnBi0JXsgTo0xHYcAU34Fsa68iZhUi34WsfVcbktBksAJ/Gl/lGrqKTsJTRZ68\r\n" + "bND60w==\r\n"
        + "=EkYv\r\n" + "-----END PGP PUBLIC KEY BLOCK-----";
    InputStream inputStream = new ByteArrayInputStream(key.getBytes(StandardCharsets.UTF_8));
    PGPPublicKey readPublicKey = pgpRsaPublicPrivateKeyGenerator.readPublicKey(inputStream);
    assertNotNull(readPublicKey);
  }

  @Test
  public void test_decryptFile() throws IOException, PGPException {
    ByteArrayOutputStream encFileStream = new ByteArrayOutputStream();

    String key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "mQENBFwp/ioDCACx7H5vZf1t/8xc6lPEMYj8/mf5q14PiddDO+fu1IMCJSf9Bqas\r\n"
        + "/AoeJ54SW7D8w+lTpr9oZODfGwwXdlbR7M7SkDRkaY05rYBpeOmh8RMub6EnV8XS\r\n"
        + "81n/sKQJuUMqp5OidGPhQ91yKvShHh9WjXe+O+Md6Lp5dic8evKul2VxzeNAzgKX\r\n"
        + "jfL7mxzGelWGYtFEvcsF4V3DinVP+fJmkIXfivdClq4sbS4fxZpxm6AdOpCYaN0Z\r\n"
        + "QSBRKO4a4pEmCmPl3y8BLlbNslb4qv1yBlqrkFpTyRX+pWcg/hiBcTkfR+dgwmtg\r\n"
        + "9fPu/99gM4EwdxNkJXB8PoRWRgkag+D0/ssdABEBAAG0FTEuMi44NDAuMTEzNTQ5\r\n"
        + "LjEuMS4xMokBKAQTAwkAEgUCXCn+KgIbAwILCQIVCQIeAQAKCRDu6rv/Dk7k2HG5\r\n"
        + "B/0ViY0JdjiFTla5KeuuizieowE7hIrBehyVhbyLi34l4uDJ/hDgah27V0usO28N\r\n"
        + "/+zjkyVrLw4RB+1AOdX5DoTFUSc8X5MW8SrTZXr4H/uxwegZ8aqkGG+48SYKWOe2\r\n"
        + "bPBl1j/2jFm0pzbyk+jKLI3asr98+Nxw3MMulyQs90/SAKV87W0e0Rcpx0rlh4E7\r\n"
        + "gQiAuyD+cjlpT5Eik6V+/ZdPWFKfFo7GR39napjfdT+nh5n9NvZqx299QosKe/Eb\r\n"
        + "b9hAvtlT5RdcRit7g95vGuYB+lFjEc9zdS7gDKxPvrDXRGhwtq2mSirpF4X6f646\r\n"
        + "MMb4GttyMHIxpbDtmUQqlLpWuQENBFwp/ioCCAD16tG2BIR3uUaMt21FbAghCIyg\r\n"
        + "/8sX1oyEjsnHy9bSg3WlfHJstHbZhLomdcCMs0bmiy5fJme69V/TPb3yWV6GcJEe\r\n"
        + "5FNEb1zQOr7CDDFixoLXKZY97y7VPSdEPWiH3EtdqtNHkbu2kaZ5Dj97ovQNrSYb\r\n"
        + "5IxUm2rFX+4qrLJDy7s5xWCpOdBbOHcaL9SEzCSsOZLYs3pwb0vbwvtEA06H/24X\r\n"
        + "vfkdiDTgrdjMZhLVwu0Bj/vlQvfLnX7CQS8tD0OIDi8tehf/5L2Xem77cVzaUlb9\r\n"
        + "OehmAgms/OoWW6eOWigzRICxvz1zwK0yVb35S7wKhdEoOznBLt4q3ashX7Q5ABEB\r\n"
        + "AAGJAR8EGAMJAAkFAlwp/ioCGwwACgkQ7uq7/w5O5NhI9Qf+Jm/0fXjC0scYxcgo\r\n"
        + "xp0H8Zp1C87eJUpeD6/OPO5+8+kINUhfTiXmbQFXT3yF7vh61TU3nNE1IaF3fh75\r\n"
        + "27nnIw1rXxfxezZijTD702cEPk5gbiwRP1Pjftd3xSltB/U/vwujQBLmelO+QtS/\r\n"
        + "EiRZePzaNSQqA2Swl0+0f9H/tZlxkFS1kX6Gm4q+yc0A8cQ1qiC954768C0RogiI\r\n"
        + "15eVCWM/PVqzmJVAdx7w8hX5tVfyUXf6EJ01582/BJ8//DpKSE3H7V1lxoHHr8Ht\r\n"
        + "4vbOiK/3ErsUiGOsRcvhlkJZHJadPA+CeF/hSl3RRxLsU1kpLC7G4hsHce65OFJb\r\n" + "Rft/Kg==\r\n"
        + "=BMDs\r\n" + "-----END PGP PUBLIC KEY BLOCK-----\r\n" + "";
    InputStream in = new ByteArrayInputStream(key.getBytes(StandardCharsets.UTF_8));
    PGPPublicKey pgpKey = pgpRsaPublicPrivateKeyGenerator.readPublicKey(in);
    byte[] fileContent = "fileContent".getBytes(StandardCharsets.UTF_8);
    pgpRsaPublicPrivateKeyGenerator.encryptStream(encFileStream, fileContent, pgpKey, true, true);

    String privateKey = "-----BEGIN PGP PRIVATE KEY BLOCK-----\r\n" + "Version: BCPG v1.60\r\n"
        + "\r\n" + "lQPGBFwp/ioDCACx7H5vZf1t/8xc6lPEMYj8/mf5q14PiddDO+fu1IMCJSf9Bqas\r\n"
        + "/AoeJ54SW7D8w+lTpr9oZODfGwwXdlbR7M7SkDRkaY05rYBpeOmh8RMub6EnV8XS\r\n"
        + "81n/sKQJuUMqp5OidGPhQ91yKvShHh9WjXe+O+Md6Lp5dic8evKul2VxzeNAzgKX\r\n"
        + "jfL7mxzGelWGYtFEvcsF4V3DinVP+fJmkIXfivdClq4sbS4fxZpxm6AdOpCYaN0Z\r\n"
        + "QSBRKO4a4pEmCmPl3y8BLlbNslb4qv1yBlqrkFpTyRX+pWcg/hiBcTkfR+dgwmtg\r\n"
        + "9fPu/99gM4EwdxNkJXB8PoRWRgkag+D0/ssdABEBAAH+CQMJGztQeAhiBPUMF2qU\r\n"
        + "k/LoOs3WgXf1vPivX8v76+oH3D0C/nOsEIzn+SWjl3uafIEBClipfoXj1GOHcAlA\r\n"
        + "u59OrP1Lp5+c/e/fCfTsbGXd7lt4w37E+nQNj4c2Sh7K51/oyXuRcCHrifvX+IxG\r\n"
        + "4VcuxUPCnR0fBn5FoChb2mcGr/MD7Jofk3kOsJoHLpXE+SxEcthQKU+mOWS40rxc\r\n"
        + "qTq3RgYk18LUWZj8RjVZOgP9WJqhx+dWZfE8ubXl8EVNaBAWDkZYotIvSVGO91V/\r\n"
        + "GoWGwTkSG07PowykZZj1zSOnZLocVwwEsM8QjlVhEgdhERQRFmsv7O1TM/0beVst\r\n"
        + "RnI0EhVzR+447ywbSh0Bxpd144Sj827oiyS46qSdh2kPlwZRZE4c/Gxn8nv6Rtza\r\n"
        + "v4+BVYh6YoxJIeuh5vVOXoYS0Vx29oDO8ibNjYKHnCdvDHcNPWug2E97RLqic7w5\r\n"
        + "U3Q2oG6+txA7GkXuqU/O/TnhrIj89KVfbNeEo9OLnKMR1ge5an7x9vb0TYfTL4jS\r\n"
        + "cam+a98CM5FRJbLIkpACPhRskHa45vLb1raqfSR9KfQxeAYSD61HIswWyET8Hjvt\r\n"
        + "GYprl0qQ0w6xbnYCG1/uoBZw8ju+iCG9vFVVJCLXzRpjaTgVoWGYZJF02OQoZ2lM\r\n"
        + "H7aaFphlaEZ9mZ9fJoah28UD14uinB3gslbY/h+Ya5pNghuXYb3IYGutVYCCDClM\r\n"
        + "JCH6/iGOshF8YFqXwDZ8bZ9U3vWh9Sro9k2J2u5HWBOunEMLyWjEAzd69McOaKTA\r\n"
        + "myA7rnRIkqUUQ1pk48RjjIVYC5BkRjkIHvNoBrBRVgHhJEcXtn3JNq4TNqUU86vH\r\n"
        + "EWPYphjkPHSZKeAaKdalW0Au4XWVa6wVikUtuOFbcHCMtzXwmilvp3AITzKDe3eg\r\n"
        + "M7+PQR9oIPZCtBUxLjIuODQwLjExMzU0OS4xLjEuMTKJASgEEwMJABIFAlwp/ioC\r\n"
        + "GwMCCwkCFQkCHgEACgkQ7uq7/w5O5NhxuQf9FYmNCXY4hU5WuSnrros4nqMBO4SK\r\n"
        + "wXoclYW8i4t+JeLgyf4Q4Godu1dLrDtvDf/s45Mlay8OEQftQDnV+Q6ExVEnPF+T\r\n"
        + "FvEq02V6+B/7scHoGfGqpBhvuPEmCljntmzwZdY/9oxZtKc28pPoyiyN2rK/fPjc\r\n"
        + "cNzDLpckLPdP0gClfO1tHtEXKcdK5YeBO4EIgLsg/nI5aU+RIpOlfv2XT1hSnxaO\r\n"
        + "xkd/Z2qY33U/p4eZ/Tb2asdvfUKLCnvxG2/YQL7ZU+UXXEYre4PebxrmAfpRYxHP\r\n"
        + "c3Uu4AysT76w10RocLatpkoq6ReF+n+uOjDG+BrbcjByMaWw7ZlEKpS6Vp0DxgRc\r\n"
        + "Kf4qAggA9erRtgSEd7lGjLdtRWwIIQiMoP/LF9aMhI7Jx8vW0oN1pXxybLR22YS6\r\n"
        + "JnXAjLNG5osuXyZnuvVf0z298llehnCRHuRTRG9c0Dq+wgwxYsaC1ymWPe8u1T0n\r\n"
        + "RD1oh9xLXarTR5G7tpGmeQ4/e6L0Da0mG+SMVJtqxV/uKqyyQ8u7OcVgqTnQWzh3\r\n"
        + "Gi/UhMwkrDmS2LN6cG9L28L7RANOh/9uF735HYg04K3YzGYS1cLtAY/75UL3y51+\r\n"
        + "wkEvLQ9DiA4vLXoX/+S9l3pu+3Fc2lJW/TnoZgIJrPzqFlunjlooM0SAsb89c8Ct\r\n"
        + "MlW9+Uu8CoXRKDs5wS7eKt2rIV+0OQARAQAB/gkDCRs7UHgIYgT1DPAfiURPpk6e\r\n"
        + "P4kG5Zc+uHA3LwXo/cTWiPDYJc8agE32UvLrV7svmfCbj9BI2tLblFIT9yud+ZK8\r\n"
        + "qUZrnR3ct5WBZz6fcfBPutKAJct3+FbkFKOizevx04Krc9pGSP50Qr/rGFaIOVFX\r\n"
        + "i7wtbWs3tYtmBkqR78q4U8MPGNTG4t/uA2ghqoebPRsNWp9LnRe8IEDIJd8mBTLO\r\n"
        + "p21I879HJRBYBwu4gCCLqwWLuZ4UUYI3j2NeCoL02RvY2F3btCJdJR3mGgRdJgPm\r\n"
        + "V3YObA2OeV3TGwprrHe/OJFavldnS5hx64fkxbgxJk9XMjmdnX91T+kWtex+Mqmp\r\n"
        + "+x7eYg11Fw/FxTV6pvccLNcan8dvytg4xKOOLgQCsMGcLuH3lS+f9blGQMMwq3yJ\r\n"
        + "Gb9rCytmObR8XwY9SyRq1lmHN6RV9p/h7fj+RfXkk58Ny7HEYsWouGgr0OrSAeXE\r\n"
        + "7pP1sVC+XBZWNSbR3w01K3eMRXrH+Ysn+zMDPNlBUmNHsymCNEV4855WDEUIGKJB\r\n"
        + "S+zAj7Mi0i4UUrCYlp48weEcUbCqEbUH161ZBClMMf+2Cq3y8D+2PdEOm2+Kvv4n\r\n"
        + "VW97NOO114zh5DGU7syfsI0qF79f41dp3O+9KdKa99iqCgng9iKA4xLdSjciHpag\r\n"
        + "n9GLqlfCwT9i91LHIHGPHxRLa+KCbrTA/cIyZRkzp2R2koQ/QGWMGTI5Ubruhjre\r\n"
        + "4pXAkGfezRNgwhwcjf16oLQoFxECOEbGCT2e8eEmbT+GDys/HfUZrtKtIjBFs3oD\r\n"
        + "+VXVI53/hOcVauoPHBvtFHPKlttrQpXe0pyvOU+GCj4VuHZBG/p3cQFp0XylPnPK\r\n"
        + "MwAT96NBG29iLUY0JDs2tFvjSfXzRJVdDaHzEecZqvUg2ocC7279zUk0aU+cP/x5\r\n"
        + "4jxPKIkBHwQYAwkACQUCXCn+KgIbDAAKCRDu6rv/Dk7k2Ej1B/4mb/R9eMLSxxjF\r\n"
        + "yCjGnQfxmnULzt4lSl4Pr8487n7z6Qg1SF9OJeZtAVdPfIXu+HrVNTec0TUhoXd+\r\n"
        + "HvnbuecjDWtfF/F7NmKNMPvTZwQ+TmBuLBE/U+N+13fFKW0H9T+/C6NAEuZ6U75C\r\n"
        + "1L8SJFl4/No1JCoDZLCXT7R/0f+1mXGQVLWRfoabir7JzQDxxDWqIL3njvrwLRGi\r\n"
        + "CIjXl5UJYz89WrOYlUB3HvDyFfm1V/JRd/oQnTXnzb8Enz/8OkpITcftXWXGgcev\r\n"
        + "we3i9s6Ir/cSuxSIY6xFy+GWQlkclp08D4J4X+FKXdFHEuxTWSksLsbiGwdx7rk4\r\n" + "UltF+38q\r\n"
        + "=UEfD\r\n" + "-----END PGP PRIVATE KEY BLOCK-----\r\n" + "";

    InputStream encStream = new ByteArrayInputStream(encFileStream
        .toString(Charset.defaultCharset().toString()).getBytes(StandardCharsets.UTF_8));
    ByteArrayOutputStream decStream = new ByteArrayOutputStream();
    pgpRsaPublicPrivateKeyGenerator.decryptFile(encStream, decStream,
        new ByteArrayInputStream(privateKey.getBytes(StandardCharsets.UTF_8)));
    assertArrayEquals(fileContent, decStream.toByteArray());
  }
}
