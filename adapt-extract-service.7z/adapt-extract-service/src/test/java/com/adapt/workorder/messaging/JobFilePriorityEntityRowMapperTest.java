package com.adapt.workorder.messaging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.adapt.file.entity.JobFilePriorityEntity;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobFilePriorityEntityRowMapper.class })
public class JobFilePriorityEntityRowMapperTest {

  private static final String JOB_ID = "jobId";
  private static final String JOB_EXPECTED_STARTDATETIME = "jobExpectedStartDateTime";
  private static final String FILE_PROCESSING_ERROR_THRESHOLD_COUNT = "fileProcessingErrorThresholdCount";
  private static final String FILE_MIN_RECORD_COUNT_ALLOWED = "fileMinRecordCountAllowed";
  private static final String FILE_TRANSMISSION_NAME = "fileTransmissionName";
  private static final String FILE_TYPE_NAME = "fileTypeName";
  private static final String FILE_FORMAT_NAME = "fileFormatName";
  private static final String FILE_FORMAT_ROW_DELIMITER = "fileFormatRowDelimiter";
  private static final String FILE_FORMAT_FIELD_DDELIMITER = "fileFormatFieldDdelimiter";
  private static final String FILE_FORMAT_ESCAPE_CHAR = "fileFormatEscapeChar";
  private static final String FILE_FORMAT_SEGMENT_DELIMITER = "fileFormatSegmentDelimiter";
  private static final String PRIORITY = "priority";
  private static final String EMPLOYER_IDS = "employerIds";
  private static final String MASTER_FILE_TEMPLATE_ID = "masterFileTemplateId";
  private static final String MASTER_FILE_TEMPLATE_VERSION = "masterFileTemplateVersion";
  private static final String FULL_OR_CHANGE = "fullOrChange";
  private static final String RESULTS_MODE = "resultsMode";
  private static final String TEST_CFG_CONFIG = "testCfgConfig";
  private static final String FILE_MAX_RECORD_COUNT_ALLOWED = "fileMaxRecordCountAllowed";
  private static final String FILE_PROCESSING_ERROR_THRESHOLD_FORMAT = "fileProcessingErrorThresholdFormat";
  private static final String FILE_IDENTIFIER = "fileIdentifier";
  private static final String FILE_ID = "fileId";
  private static final String FILE_VERSION = "fileVersion";
  private static final String CLONE_NUMBER_LIST = "cloneNumberList";

  private static final String FILE_STATE_ID = "fileStateId";
  private static final String FILE_PATH = "filePath";
  private static final String FILE_NAME = "fileName";
  private static final String FILE_STATE_PRIVATEKEY = "fileStatePrivatekey";
  private static final String MASTER_PRIVATE_KEY = "masterPrivateKey";
  private static final String NEW_FILE_NAME = "newFileName";
  private static final String DIRECTION = "direction";
  private static final String DATA_SOURCE_TYPE = "data_source_type";
  private static final String DATA_TARGET_TYPE = "data_target_type";
  private static final String PLAN_ADDITION_FACTOR = "planAdditionFactor";
  private static final String SYSTEM_DATE = "systemDate";
  private static final String LOOK_BACK_PERIOD = "lookBackPeriod";
  private static final String LOOK_AHEAD_PERIOD = "lookAheadPeriod";
  private static final String PROFILE_ID = "profileId";

  @Autowired
  private JobFilePriorityEntityRowMapper jobFilePriorityEntityRowMapper;

  @Test
  public void testTransformation() throws Exception {

    ResultSet rs = Mockito.mock(ResultSet.class);
    Mockito.when(rs.getInt(JOB_ID)).thenReturn(1);
    Mockito.when(rs.getDate(JOB_EXPECTED_STARTDATETIME))
        .thenReturn(new Date(new java.util.Date().getTime()));
    Mockito.when(rs.getInt(FILE_PROCESSING_ERROR_THRESHOLD_COUNT)).thenReturn(1);
    Mockito.when(rs.getInt(FILE_MIN_RECORD_COUNT_ALLOWED)).thenReturn(1);
    Mockito.when(rs.getString(FILE_TRANSMISSION_NAME)).thenReturn("1");
    Mockito.when(rs.getString(FILE_TYPE_NAME)).thenReturn("1");
    Mockito.when(rs.getString(FILE_FORMAT_NAME)).thenReturn("1");
    Mockito.when(rs.getString(FILE_FORMAT_ROW_DELIMITER)).thenReturn("1");
    Mockito.when(rs.getString(FILE_FORMAT_FIELD_DDELIMITER)).thenReturn("1");
    Mockito.when(rs.getString(FILE_FORMAT_ESCAPE_CHAR)).thenReturn("1");
    Mockito.when(rs.getString(FILE_FORMAT_SEGMENT_DELIMITER)).thenReturn("1");
    Mockito.when(rs.getInt(PRIORITY)).thenReturn(1);
    Mockito.when(rs.getString(EMPLOYER_IDS)).thenReturn("1");
    Mockito.when(rs.getInt(MASTER_FILE_TEMPLATE_ID)).thenReturn(1);
    Mockito.when(rs.getInt(MASTER_FILE_TEMPLATE_VERSION)).thenReturn(1);
    Mockito.when(rs.getInt(FULL_OR_CHANGE)).thenReturn(1);
    Mockito.when(rs.getInt(RESULTS_MODE)).thenReturn(1);
    Mockito.when(rs.getString(TEST_CFG_CONFIG)).thenReturn("1");
    Mockito.when(rs.getInt(FILE_MAX_RECORD_COUNT_ALLOWED)).thenReturn(1);
    Mockito.when(rs.getString(FILE_PROCESSING_ERROR_THRESHOLD_FORMAT)).thenReturn("1");
    Mockito.when(rs.getInt(FILE_IDENTIFIER)).thenReturn(1);
    Mockito.when(rs.getInt(FILE_ID)).thenReturn(1);
    Mockito.when(rs.getInt(FILE_VERSION)).thenReturn(1);
    Mockito.when(rs.getString(CLONE_NUMBER_LIST)).thenReturn("1");
    Mockito.when(rs.getInt(FILE_STATE_ID)).thenReturn(1);
    Mockito.when(rs.getString(FILE_PATH)).thenReturn("1");
    Mockito.when(rs.getString(FILE_NAME)).thenReturn("1");
    Mockito.when(rs.getBytes(FILE_STATE_PRIVATEKEY)).thenReturn(new byte[0]);
    Mockito.when(rs.getString(MASTER_PRIVATE_KEY)).thenReturn("1");
    Mockito.when(rs.getString(DIRECTION)).thenReturn("1");
    Mockito.when(rs.getString(DATA_SOURCE_TYPE)).thenReturn("API");
    Mockito.when(rs.getString(DATA_TARGET_TYPE)).thenReturn("FILE");
    Mockito.when(rs.getString(PLAN_ADDITION_FACTOR)).thenReturn("1");
    Mockito.when(rs.getString(SYSTEM_DATE)).thenReturn("10-11-2011");
    Mockito.when(rs.getString(LOOK_BACK_PERIOD)).thenReturn("12");
    Mockito.when(rs.getString(LOOK_AHEAD_PERIOD)).thenReturn("11");
    Mockito.when(rs.getInt(PROFILE_ID)).thenReturn(1);

    JobFilePriorityEntity jobFilePriorityEntity = jobFilePriorityEntityRowMapper.mapRow(rs, 1);

    assertNotNull(jobFilePriorityEntity);

    assertEquals(Integer.valueOf(1), jobFilePriorityEntity.getJobId());
    assertEquals("1", jobFilePriorityEntity.getFileFormatName());
    assertEquals("1", jobFilePriorityEntity.getRowDelimiter());
    assertEquals("1", jobFilePriorityEntity.getFieldDelimiter());
    assertEquals("1", jobFilePriorityEntity.getEscapeCharacter());
    assertEquals(Integer.valueOf(1), jobFilePriorityEntity.getPriority());
    assertEquals("1", jobFilePriorityEntity.getPlanYearAdditiveFactor());
    assertEquals("10-11-2011", jobFilePriorityEntity.getSystemDate());
    assertEquals("12", jobFilePriorityEntity.getLookBackPeriod());
    assertEquals("11", jobFilePriorityEntity.getLookAheadPeriod());
    assertEquals(Integer.valueOf(1), jobFilePriorityEntity.getProfileId());
  }

  @Test(expected = SQLException.class)
  public void testTransformationWithException() throws SQLException {
    ResultSet rs = Mockito.mock(ResultSet.class);
    Mockito.when(rs.getInt(JOB_ID)).thenThrow(new SQLException("Test Exception"));
    jobFilePriorityEntityRowMapper.mapRow(rs, 1);

  }

}
