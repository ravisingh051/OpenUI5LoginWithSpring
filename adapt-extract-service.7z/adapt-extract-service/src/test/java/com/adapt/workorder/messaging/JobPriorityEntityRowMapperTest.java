package com.adapt.workorder.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.file.entity.JobPriorityEntity;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Calendar;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobPriorityEntityRowMapper.class })
public class JobPriorityEntityRowMapperTest {

  @Autowired
  private JobPriorityEntityRowMapper jobPriorityEntityRowMapper;

  public static final String JOB_PRIORITIZATION_ROW_MAPPING_JOB_ID = "job_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_SLA = "is_sla_mapped";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_FILE_ID = "file_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_EMPLOYER_IDS = "employer_ids";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_TRADING_PARTNER = "trading_partner_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_FILE_TYPE = "file_type_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_DIRECTION = "direction";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_EXPECTED_DATE = "expected_start_date";
  public static final String JOB_PRIORITIZATION_EXPLICIT_HIGH_PRIORITIZATION = "explicit_high_prioritization";
  public static final String JOB_PRIORITIZATION_EXPLICIT_LOW_PRIORITIZATION = "explicit_low_prioritization";
  public static final String JOB_PRIORITIZATION_EXPLICIT_PRIORITIZATION_DATE = "explicit_prioritization_date";

  @Test
  public void test_transformation() throws Exception {

    ResultSet rs = Mockito.mock(ResultSet.class);
    Mockito.when(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_JOB_ID)).thenReturn(1);
    Mockito.when(rs.getBoolean(JOB_PRIORITIZATION_ROW_MAPPING_SLA)).thenReturn(false);
    Mockito.when(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_FILE_ID)).thenReturn(1);
    Mockito.when(rs.getString(JOB_PRIORITIZATION_ROW_MAPPING_EMPLOYER_IDS)).thenReturn("1,2");
    Mockito.when(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_TRADING_PARTNER)).thenReturn(1);
    Mockito.when(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_FILE_TYPE)).thenReturn(1);
    Mockito.when(rs.getString(JOB_PRIORITIZATION_ROW_MAPPING_DIRECTION)).thenReturn("Inbound");
    Mockito.when(rs.getDate(JOB_PRIORITIZATION_ROW_MAPPING_EXPECTED_DATE))
        .thenReturn(new Date(Calendar.getInstance().getTime().getTime()));
    Mockito.when(rs.getBoolean(JOB_PRIORITIZATION_EXPLICIT_HIGH_PRIORITIZATION)).thenReturn(false);
    Mockito.when(rs.getBoolean(JOB_PRIORITIZATION_EXPLICIT_LOW_PRIORITIZATION)).thenReturn(false);
    Mockito.when(rs.getDate(JOB_PRIORITIZATION_EXPLICIT_PRIORITIZATION_DATE))
        .thenReturn(new Date(Calendar.getInstance().getTime().getTime()));
    Mockito.when(rs.getTimestamp(JOB_PRIORITIZATION_EXPLICIT_PRIORITIZATION_DATE))
        .thenReturn(new Timestamp(1));
    JobPriorityEntity jobPriorityEntity = jobPriorityEntityRowMapper.mapRow(rs, 1);
    assertNotNull(jobPriorityEntity);

  }

}
