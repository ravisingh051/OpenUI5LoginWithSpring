package com.adapt.workorder.messaging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.adapt.file.entity.JobPriorityEntity;
import com.adapt.file.entity.JobPriortizationPayload;
import com.adapt.file.entity.PriorityInfoEntity;
import com.adapt.workorder.config.ClassificationTypeEnum;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobPriorityServiceActivator.class })
public class JobPriorityServiceActivatorTest {

  @Autowired
  private JobPriorityServiceActivator jobPriorityServiceActivator;

  @Test
  public void test_sla() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createSlaMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_file_id() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createFileIdMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_employer() {
    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createEmployerIdsMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_trading_partner() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createTradingPartnerMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_file_type() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createFileTypeMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_direction() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createFileDirectionMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_prev_day() {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createFilePrevDayMappedPriorityInfo());
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());

  }

  @Test
  public void test_all() {
    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    assertNotNull(size);
    List<PriorityInfoEntity> priorityInfoEntities = createPriorityInfoEntity();
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    jobPrioritizationPayload.setPriorityInfoListEntity(priorityInfoEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();

    assertEquals(size, jobPriorityEntities2.size());
  }

  @Test
  public void test_No_priority_info_entity() {
    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    int size = jobPriorityEntities.size();
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    jobPrioritizationPayload.setJobPriorityListEntity(jobPriorityEntities);
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();
    assertEquals(size, jobPriorityEntities2.size());
  }

  @Test
  public void test_no_priority_info_entity_no_job_priority() {
    JobPriortizationPayload jobPrioritizationPayload = new JobPriortizationPayload();
    Message<?> message = MessageBuilder.withPayload(jobPrioritizationPayload).build();
    message = jobPriorityServiceActivator.sortAllJobs(message);
    List<JobPriorityEntity> jobPriorityEntities2 = (List<JobPriorityEntity>) message.getPayload();
    assertEquals(0, jobPriorityEntities2.size());
  }

  private List<JobPriorityEntity> createJobPriorityEntityList() {

    List<JobPriorityEntity> jobPriorityEntities = new ArrayList<JobPriorityEntity>();
    for (int i = 1; i < 15; i++) {
      JobPriorityEntity jobPriorityEntity = new JobPriorityEntity();
      jobPriorityEntity.setJobId(i);
      jobPriorityEntity.setDirection("Outbound");
      jobPriorityEntity.setEmployerIds((String.valueOf(i) + "," + String.valueOf(i + 1)));
      final Calendar calender = Calendar.getInstance();
      calender.set(Calendar.HOUR_OF_DAY, 0);
      calender.set(Calendar.MINUTE, 0);
      calender.set(Calendar.SECOND, 0);
      calender.set(Calendar.MILLISECOND, 0);
      jobPriorityEntity.setExpectedStartDate(new Date(calender.getTime().getTime()));
      jobPriorityEntity.setFileId(i);
      jobPriorityEntity.setFileTypeId(i);
      jobPriorityEntity.setIsSlaMapped(false);
      jobPriorityEntity.setTradingPartnerId(i);
      if (i % 4 == 0) {
        jobPriorityEntity.setExplicitHighPrioritization(true);
      }
      if (i % 5 == 0) {
        jobPriorityEntity.setExplicitLowPrioritization(true);
      }
      if (i == 1 || i == 8) {
        jobPriorityEntity.setIsSlaMapped(true);
      }
      if (i == 2 || i == 9) {
        jobPriorityEntity.setFileId(222);
      }
      if (i == 3 || i == 10) {
        jobPriorityEntity.setEmployerIds("333");
      }
      if (i == 4 || i == 11) {
        jobPriorityEntity.setTradingPartnerId(444);
      }
      if (i == 5 || i == 12 || i == 7) {
        jobPriorityEntity.setFileTypeId(555);
      }
      if (i == 6 || i == 13) {
        jobPriorityEntity.setDirection("Inbound");
      }
      if (i == 7 || i == 14) {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        jobPriorityEntity.setExpectedStartDate(new Date(cal.getTime().getTime()));
      }
      if (i == 4 || i == 8) {
        jobPriorityEntity
            .setExplicitPrioritizationDate(createDateFromString(i, "01-FEB-2019 12:01:01"));
      } else {
        jobPriorityEntity
            .setExplicitPrioritizationDate(createDateFromString(i, "01-FEB-2019 12:01:"));
      }
      jobPriorityEntities.add(jobPriorityEntity);
    }
    return jobPriorityEntities;
  }

  private List<PriorityInfoEntity> createPriorityInfoEntity() {
    List<PriorityInfoEntity> priorityInfoEntities = new ArrayList<PriorityInfoEntity>();
    priorityInfoEntities.add(createSlaMappedPriorityInfo());
    priorityInfoEntities.add(createFileIdMappedPriorityInfo());
    priorityInfoEntities.add(createEmployerIdsMappedPriorityInfo());
    priorityInfoEntities.add(createTradingPartnerMappedPriorityInfo());
    priorityInfoEntities.add(createFileTypeMappedPriorityInfo());
    priorityInfoEntities.add(createFileDirectionMappedPriorityInfo());
    priorityInfoEntities.add(createFilePrevDayMappedPriorityInfo());
    return priorityInfoEntities;
  }

  private PriorityInfoEntity createSlaMappedPriorityInfo() {

    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(1);
    prio.setCriteria(ClassificationTypeEnum.SLA.name());
    prio.setValue("YES");
    prio.setPriority(1);
    return prio;

  }

  private PriorityInfoEntity createFileIdMappedPriorityInfo() {
    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(2);
    prio.setCriteria("File ID");
    prio.setValue("222");
    prio.setPriority(2);
    return prio;

  }

  private PriorityInfoEntity createEmployerIdsMappedPriorityInfo() {

    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(3);
    prio.setCriteria("Employer");
    prio.setValue("333");
    prio.setPriority(3);
    return prio;
  }

  private PriorityInfoEntity createTradingPartnerMappedPriorityInfo() {

    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(4);
    prio.setCriteria("Trading Partner");
    prio.setValue("444");
    prio.setPriority(1);
    return prio;
  }

  private PriorityInfoEntity createFileTypeMappedPriorityInfo() {

    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(5);
    prio.setCriteria("File Type");
    prio.setValue("555");
    prio.setPriority(5);
    return prio;
  }

  private PriorityInfoEntity createFileDirectionMappedPriorityInfo() {
    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(6);
    prio.setCriteria("File Direction");
    prio.setValue("Inbound");
    prio.setPriority(6);
    return prio;

  }

  private PriorityInfoEntity createFilePrevDayMappedPriorityInfo() {

    PriorityInfoEntity prio = new PriorityInfoEntity();
    prio.setPriorityId(7);
    prio.setCriteria("Previous Day's Unfinished Jobs");
    prio.setValue("Yes");
    prio.setPriority(7);
    return prio;
  }

  private Date createDateFromString(Integer jobId, String date) {
    SimpleDateFormat f = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
    int randomNum = ThreadLocalRandom.current().nextInt(00, 59 + 1);
    if (jobId != 4 && jobId != 8) {
      if (randomNum < 10) {
        date = date + "0" + randomNum;
      } else {
        date = date + randomNum;
      }
    }

    java.util.Date d;
    try {
      d = f.parse(date);
      return new Date(d.getTime());
    } catch (ParseException e) {

    }

    return null;

  }

}
