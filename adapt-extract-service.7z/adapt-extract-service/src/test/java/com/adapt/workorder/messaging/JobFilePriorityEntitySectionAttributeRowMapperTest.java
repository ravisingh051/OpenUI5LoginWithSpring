package com.adapt.workorder.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.file.entity.SectionAttributeEntity;
import java.sql.ResultSet;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobFilePriorityEntitySectionAttributeRowMapper.class })
public class JobFilePriorityEntitySectionAttributeRowMapperTest {

  @Autowired
  private JobFilePriorityEntitySectionAttributeRowMapper jobFilePriorityEntitySectionAttributeRowMapper;

  private static final String ATTRIBUTE_NAME = "standardizedName";
  private static final String DEFAULT_DATATYPE = "defaultDatatype";
  private static final String COLUMN_ORDER = "columnOrder";
  private static final String SECTION_TYPE = "sectionType";
  private static final String SECTION_DELIMITER = "nodeDelimiter";
  private static final String IS_ATTRIBUTE_MANDATORY = "mandatory";
  private static final String ATTRIBUTE_SIZE = "nodeSize";
  private static final String ATTRIBUTE_START_POSITION = "nodeColumnStartPosition";
  private static final String ATTRIBUTE_END_POSITION = "nodeColumnEndPosition";

  @Test
  public void test_transformation() throws Exception {

    ResultSet rs = Mockito.mock(ResultSet.class);
    Mockito.when(rs.getString(ATTRIBUTE_NAME)).thenReturn("1");
    Mockito.when(rs.getString(DEFAULT_DATATYPE)).thenReturn("1");
    Mockito.when(rs.getInt(COLUMN_ORDER)).thenReturn(1);
    Mockito.when(rs.getString(SECTION_TYPE)).thenReturn("1");
    Mockito.when(rs.getString(SECTION_DELIMITER)).thenReturn("1");
    Mockito.when(rs.getBoolean(IS_ATTRIBUTE_MANDATORY)).thenReturn(true);
    Mockito.when(rs.getInt(ATTRIBUTE_SIZE)).thenReturn(1);
    Mockito.when(rs.getInt(ATTRIBUTE_START_POSITION)).thenReturn(1);
    Mockito.when(rs.getInt(ATTRIBUTE_END_POSITION)).thenReturn(1);

    SectionAttributeEntity sectionAttributeEntity = jobFilePriorityEntitySectionAttributeRowMapper
        .mapRow(rs, 1);

    assertNotNull(sectionAttributeEntity);

  }

  @Test
  public void test_transformation_null() throws Exception {

    ResultSet rs = Mockito.mock(ResultSet.class);
    Mockito.when(rs.getString(ATTRIBUTE_NAME)).thenReturn("1");
    Mockito.when(rs.getString(DEFAULT_DATATYPE)).thenReturn("1");
    Mockito.when(rs.getObject(COLUMN_ORDER)).thenReturn("1");
    Mockito.when(rs.getInt(COLUMN_ORDER)).thenReturn(1);
    Mockito.when(rs.getString(SECTION_TYPE)).thenReturn("1");
    Mockito.when(rs.getString(SECTION_DELIMITER)).thenReturn("1");
    Mockito.when(rs.getBoolean(IS_ATTRIBUTE_MANDATORY)).thenReturn(true);
    Mockito.when(rs.getInt(ATTRIBUTE_SIZE)).thenReturn(1);
    Mockito.when(rs.getInt(ATTRIBUTE_START_POSITION)).thenReturn(1);
    Mockito.when(rs.getInt(ATTRIBUTE_END_POSITION)).thenReturn(1);

    SectionAttributeEntity sectionAttributeEntity = jobFilePriorityEntitySectionAttributeRowMapper
        .mapRow(rs, 1);

    assertNotNull(sectionAttributeEntity);

  }

}
