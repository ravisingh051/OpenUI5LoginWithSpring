package com.adapt.workorder.messaging;

import static org.junit.Assert.assertTrue;

import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.entity.SectionAttributeEntity;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.MessageTransformationException;
import org.springframework.messaging.Message;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = { "passcode=ADaPT_APP@123" })
@SpringBootTest(classes = { DecryptFileForJobPriorityTransformer.class,
    PgpRsaPublicPrivateKeyGenerator.class })
public class DecryptFileForJobPriorityTransformerTest {

  @Value("${passcode}")
  private String passcode;

  @Autowired
  private DecryptFileForJobPriorityTransformer decryptFileForJobPriorityTransformer;

  @Rule
  public TemporaryFolder folder = new TemporaryFolder();

  @Test
  public void tes_transformation() throws Exception {

    String path = folder.getRoot().getAbsolutePath();
    String fileName = "darden.txt";
    String fileContent = "-----BEGIN PGP MESSAGE-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "hQEMA9P56wEuhe7aAgf/Zc9rDmGBUFmpqk8Ggz3s6/SqQu7jYldT0Xct3LCsIy5W\r\n"
        + "/hXESqM4AWfL3fv+vKt0HVGHZ1PV09QvgHTg7eIQuvJX3+VrN4PhCknVk68F3pvp\r\n"
        + "6e6YxQTQxtPEZqVfr43sIn1gASR2kW4NjqdgwSMsSwUdd1vFcfhWnnLJ3WYuy/4e\r\n"
        + "JOHAOlemK5vrc9hAhUb1Ig4+UCt5uZU0rcpt6w5AZh8jl/x326/AtHtnVcAH5rRS\r\n"
        + "ezFFEwGtJ7p/I8xQiQp4if4gZDbWeuxl0ucZnFajtOkwOtSamO6YvxZspXrKBrGh\r\n"
        + "TTPX6BQFxMDVrHg/30sOrlCkJwOnqhrgQT3USmMol9LAGAHh5INcnLph+pyzA3Nk\r\n"
        + "y12UI2otMoVzgvRUmwZswqO9WvUEwsGq3VvZehTSNcs+1/Vz/pNAfls4HqYeBbmM\r\n"
        + "ZLJnm6HTQz6QRo4jBcQe17qX+/OeUi6yIJPrupkg8sd5qZ1CDo3jBIIdnDgITzVX\r\n"
        + "BDVQNu6NzS89YZM0ZxRyjCcvQVHcbBzFo6vW3hRDdo0Fv8xrE/lT2HS19KMUI4nP\r\n"
        + "ERSLFzdb6JC6Hy9z94fBhDbNU+I7a4a05dH4++1R+ofhahqY7Y6l4HpFmxZ12rlG\r\n"
        + "3KNNtYcFmEXw0Q==\r\n" + "=5HkP\r\n" + "-----END PGP MESSAGE-----\r\n" + "";

    final File file1 = folder.newFile(fileName);

    FileUtils.writeStringToFile(file1, fileContent);
    JobPriorityGetPayload jobPriorityGetPayload = createJobPriorityGetPaylod(path, fileName);
    Message<?> message = MessageBuilder.withPayload(jobPriorityGetPayload).build();
    message = decryptFileForJobPriorityTransformer.transform(message);
    assertTrue(message.getPayload() instanceof File);

  }

  @Test(expected = MessageTransformationException.class)
  public void tes_transformation_noencKey() throws Exception {

    String path = folder.getRoot().getAbsolutePath();
    String fileName = "darden.txt";
    String fileContent = "-----BEGIN PGP MESSAGE-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "hQEMA9P56wEuhe7aAgf/Zc9rDmGBUFmpqk8Ggz3s6/SqQu7jYldT0Xct3LCsIy5W\r\n"
        + "/hXESqM4AWfL3fv+vKt0HVGHZ1PV09QvgHTg7eIQuvJX3+VrN4PhCknVk68F3pvp\r\n"
        + "6e6YxQTQxtPEZqVfr43sIn1gASR2kW4NjqdgwSMsSwUdd1vFcfhWnnLJ3WYuy/4e\r\n"
        + "JOHAOlemK5vrc9hAhUb1Ig4+UCt5uZU0rcpt6w5AZh8jl/x326/AtHtnVcAH5rRS\r\n"
        + "ezFFEwGtJ7p/I8xQiQp4if4gZDbWeuxl0ucZnFajtOkwOtSamO6YvxZspXrKBrGh\r\n"
        + "TTPX6BQFxMDVrHg/30sOrlCkJwOnqhrgQT3USmMol9LAGAHh5INcnLph+pyzA3Nk\r\n"
        + "y12UI2otMoVzgvRUmwZswqO9WvUEwsGq3VvZehTSNcs+1/Vz/pNAfls4HqYeBbmM\r\n"
        + "ZLJnm6HTQz6QRo4jBcQe17qX+/OeUi6yIJPrupkg8sd5qZ1CDo3jBIIdnDgITzVX\r\n"
        + "BDVQNu6NzS89YZM0ZxRyjCcvQVHcbBzFo6vW3hRDdo0Fv8xrE/lT2HS19KMUI4nP\r\n"
        + "ERSLFzdb6JC6Hy9z94fBhDbNU+I7a4a05dH4++1R+ofhahqY7Y6l4HpFmxZ12rlG\r\n"
        + "3KNNtYcFmEXw0Q==\r\n" + "=5HkP\r\n" + "-----END PGP MESSAGE-----\r\n" + "";

    final File file1 = folder.newFile(fileName);

    FileUtils.writeStringToFile(file1, fileContent);
    JobPriorityGetPayload jobPriorityGetPayload = createJobPriorityGetPaylod(path, fileName);
    jobPriorityGetPayload.getJobFilePriorityEntity().setFileStatePrivatekey(null);

    Message<?> message = MessageBuilder.withPayload(jobPriorityGetPayload).build();
    decryptFileForJobPriorityTransformer.transform(message);

  }

  private JobPriorityGetPayload createJobPriorityGetPaylod(String filePath, String fileName) {

    String masterKey = "-----BEGIN PGP PRIVATE KEY BLOCK-----\r\n" + "Version: BCPG v1.60\r\n"
        + "\r\n" + "lQPGBFwHuBMDCACqqr0M/cd1M7Dry2jwKxA9uDnGdIeAXL4EwmbnXqCIqu04/ncD\r\n"
        + "yvPBWXYc/LmArEbcA4+9IGP6OVgyHPeqZ4hpsU9jKZMjIG5We+3h6pbyL+m5G0Gy\r\n"
        + "TLg7OC8QIMWaeC+rRwL0dowZnhaMqs6ygNNz7S7TO3Quolm3sOUyGFHqytYRa8A/\r\n"
        + "mD7kvcXDKqR6ub4GjZ8XutENUnWT3AxQR1SQC/K9HJF296iRSU62RiUpMariXcet\r\n"
        + "e/bTOZPdncOhLCz+/GP/bRxGWeGvB15SS65jScs9N/OmKAvBl1SMsaBpTHbIuQJH\r\n"
        + "jEPNc7bzF0YvoEGamicyBdk1goL33MA7sslBABEBAAH+CQMJQzyhk4BaHMoM74SL\r\n"
        + "VXR1i6uZnXjMidRz4BQemCTZ694DIvtNjwp8Sfe6U+hylQQgEsBVZdmHR57PGkkw\r\n"
        + "9Sczn3PrVFmhBgRuPMvW2uyWw2qGvZG53USEGCvnnumb/zCBiBwpLHKeBCvGQ88m\r\n"
        + "b/VFgHhn2EWaVIvN4onCpueKXl4s29JbtCje3dyDG9RfpSf/4yXyU8Etib9n7jun\r\n"
        + "ZdLc4KsGHkAld62XvuhvJi1rt8L/LSokgtRNYaZHuHHnfBU/iOUyQ5lNmB2Je240\r\n"
        + "4JXURAVy6Fl2ms2NO0vrAhaOyZCkX0MVyegSziFEykyqalEJMkMx84ttTAxUz8VZ\r\n"
        + "BkI7uP6OMMyNQFJtV5BxcDzlixqS5GoPIhaO0LlNlEr8xW048ITlMoXAxELy/jhV\r\n"
        + "Ks9NTOf9eD7zvepnTEeH4svfe33llkvb4GvFJE/pZBD+mLhInnExreatlx9p1KXE\r\n"
        + "a8ic8+euB2OdtwGZ3NBZKtsuO6r9yp66pa//TDw2TT1U3MjAcmRztbvJtmXQGqwU\r\n"
        + "ydibWz2HMpC+mgPNCkUxtMyaFnXUCgvj4Qz2PDAetPhnez/dLFG2bALJty+5dfmV\r\n"
        + "uDlx1ywe0J9NGXRJge/fUZr3U/2s1YQN9JL6zRIR0sjIFmSwqP7bJVGwsRohdh//\r\n"
        + "yNkvnyxeK1SOVMEOnEwPYjbWzi5eEcv8fnpmJQDPI712BksDh9lTS9VQFqa5y2LL\r\n"
        + "4665hMfjuea69u2Q4/4Tj1pyFU9MGnG5232MjML3alpTRXM1xfWpFJERJth8jB2S\r\n"
        + "AzSjcqz2d5xaLBfhWxyIDEy83VueNc8LtME+98ja7a1rogI3a4dI0mrBJoc8N2Gh\r\n"
        + "ZEVGPu2DZuFOQP12TF6FkqUjqR9f36x0XAyupHTfEbt2wkrL+Nf/6T6nk5zHYaHk\r\n"
        + "y5+G7Xs+fZCftBUxLjIuODQwLjExMzU0OS4xLjEuMTKJASgEEwMJABIFAlwHuBMC\r\n"
        + "GwMCCwkCFQkCHgEACgkQX6ctJ6HC6wucSgf/VvTJZohwfyrQUuiTBpC1rjBtPAGc\r\n"
        + "H9Zhay4DfHEB3x9Na9dLWmCVJiVCFlMvT2sYtBw7QYv6jC/AvpZQ4AACCVYRvvOO\r\n"
        + "2BrvAmqTqAroF0iLkHYB0KOAThOL6GfRu2PpeSREMCHrvh6fq/FHg1AcXSfd5bvM\r\n"
        + "eBJpGZtcEnGM1ro776goQEpmPklX/Tiw3pakDkHwnacn/K0hlbTVGzpim1O+UQ0Z\r\n"
        + "DsWmAdz8w9TvL6S1ojUN/1vg24to8VPMgZPe0RLUe9OXtIyteI8m2k5oPe29DXk/\r\n"
        + "MyNockGgPiPFlyYr6230mmDwywC3zCC9Gbcllt7n6l9Kmwp2hRjeOtAltJ0DxgRc\r\n"
        + "B7gTAggAjxM3F7vae5ey9VhKc2xvVx5RvQRCm0F9f1qUcILZKKaQOvv41hhDrqc/\r\n"
        + "UMrCwQf4qOocUt4fS48yMldnsV8smqC/FX190gAAl+0huh6uB5nXo0b9pjPt450g\r\n"
        + "h+lA5uYerSMRiTZzH3islkXvq91vYFlpPrBLPWQE4Hl7NZTqYmaHrlyYOnJu0jNz\r\n"
        + "CDxTqGGEoggWrxjk0un1mD1O0JbQKUjv70IOzAjom6FaUezVCpdCnDJ8a545NC/r\r\n"
        + "cnGO9rj4CeMxjY9/KtRtBAn117ow4BW5orO7/TZKHq8OKlb0DLsUDbI9wsCMobPq\r\n"
        + "ByU30JuaNABvFWQ80aZj3D7S6H0hSQARAQAB/gkDCUM8oZOAWhzKDL8BXO8B09hJ\r\n"
        + "UlQVrcqCMmXsaeFX3I9UKAI5CDZm0DtqhZ1plLtNoHf2vThP/+gre3xsCvuACJCq\r\n"
        + "d0+ypYOK9qfuDLVvSQ3vAj8wGi/MOP+jZStuQkF9Aqufymh4gWMYshN8HeCwx4EG\r\n"
        + "XzE1d3briqoqoECiOJD0reM4OYrNJIJ/gRS9nr0YTVmc1L346ZK0i9w6mtU7m6Mx\r\n"
        + "OIdSxRL8dVLTAVOOanFgcoubcwm5OyRATTJMUwgvvhyaNB42ZvDacrM7LFDk/LB9\r\n"
        + "2q0vlTdQup+9ghXZzK5xHFzyw4r98fYTiX3ORrmbtOYuJS5v72wvgTTb2r6W6bIk\r\n"
        + "nVsZpQfrB8IZfWbeF3zHpdOyHp/6q8rwftNVp73UhnBVGnbeh9KzxOmfnlt4gXT9\r\n"
        + "cU8w9bus5IXzJMDuFCvXH/9FvlBOEFf+BXVvVFjkfiEPNEC9eQgUxMq8Ru7vOENc\r\n"
        + "9VHXMSAbcgGmW8/8/mvD2DxYGGQIxpUVW4iXyWRfolTpMtJvHCY0m7jjtJXSreFc\r\n"
        + "3Wbr7ClmiG0qGEDnCgFVsiyUdGv1mlfF05Gf2tigiKNYaJD2s+lSfcElElDRDyee\r\n"
        + "OZamU8L+CKa3PvOV1QfnLJWjQPHwNRdJbVu5UUj/VxRAmKvXM7BwOyEoY7CEkUrn\r\n"
        + "lJljOvR5iCf7XJBv1Y+uPHmdv0Q98/EVzrjTBOO9Yuy2wMIHA6Q40Bm7YfUg5wel\r\n"
        + "Zm6Iz4ZJ6PN0428MNqcTkCIvPFuFW2ICrqVL466LpFBdJuSHz3dAbu/QbPKSKWSK\r\n"
        + "b+a0MemTRiSvT0XfW14wrVKl0PiMFV32fNT9/oav2uWjxJI/5GXHlWifYa8XozCS\r\n"
        + "vI9wS9ViNGQHIDq/5UxV7xZmLaWbgQ4GdZEHYXA/YOinPWUIEV2XKSv10843Crm6\r\n"
        + "8tUk8IkBHwQYAwkACQUCXAe4EwIbDAAKCRBfpy0nocLrC1A/CACBl4c1cKZxF/Uo\r\n"
        + "AhH+r616ywPALfbcnoU+D0DJcUWkna5Mp7r1O4MGUIOFx0A9Y0OVKYseiKXJ7e8m\r\n"
        + "Cu8AEn66BzHyfYtCoRoM8ppJBzFYm2x+QOEOT4LI+8YSEwokmvmzBeTxSJ/QxHkD\r\n"
        + "KxfjVj4PjdEcra1qF9sC3th0VQ7OVNtB4lGsecHES/7NEjMM1a07U4K9oaJ5O/ax\r\n"
        + "X+N6ckpWuKHLMkQyPBSk2c9Hu4NqFKzX6miZoaFp7OKjc5QPHUcIw0Pm2nuHVi96\r\n"
        + "EPZ+WZtulAYXQgbn/DOvODDCKPgBKMwvlAtrTfzj11xL9L3Wf0JbftMtAYAgLELT\r\n" + "SI6NC9Zp\r\n"
        + "=XVYl\r\n" + "-----END PGP PRIVATE KEY BLOCK-----\r\n" + "";

    String privateKey = "-----BEGIN PGP MESSAGE-----\r\n" + "Version: BCPG v1.60\r\n" + "\r\n"
        + "hQEMAzbp7xA/V2+vAgf/V3bU+S7cGg0+gWpWV9apKVoz5mA2lBuyAk2czQElzKcj\r\n"
        + "dRxgZTCJLnUI/0Gd1PJbv2Q+wy4vh6fQqjTZPhGwf4ughBqD4FXZaVzxqWauWpb/\r\n"
        + "PxK3ZPV7GpL7XhB8xKRzO9l+D0SwKs6EirtPx402WK8HFFJgzQJAzFVuOIO09lMm\r\n"
        + "wIbuWTgND8QhcJsse1QtW5GtFR4QvfwcNrGg08QEiRALeVSjmBgiyFvUkN7z4U2p\r\n"
        + "0t8chiACjkEhs53GSuAuG8810es2XyFOxHDd2CAOUlcqmXY41DJWHf8tZ7i/3T04\r\n"
        + "TX6s8kkryuZqNiZsL6r/b+oYUt//1TCtbWqjotrwkdLKSAG+qk3hWyJKp35o2AJJ\r\n"
        + "NBKxDVzrTaBJaB+397cXc6FTAG0GTKHKDpyj6aTLZoMz77/BXipjbNtVBg90KOfH\r\n"
        + "UZI8xvI8fzrm5pK2BP8lFcUM6X9lZzz+Qd7jhNW+VOxIeWgx8J7JXGD4HceNbnU5\r\n"
        + "Cj+tPdjSMmws+Acpk+xid9rWxFtBVKAJObboNEF8qAzENI+u5qFVtiJ2H1Aaqy6l\r\n"
        + "SkD/gtYrDsNS162EFGVVbaxXodR0lJozByb5Y4tawwcBnnQALNb+RiPLVO7eo2VL\r\n"
        + "ijPWUwmM+VSOPe9gC1suLrfCUGEPVVVXTIp3KIywqkp7/OmxoOn7fXvFpFb7j2Gm\r\n"
        + "PE3UYuthjtVkdWUFrP5lPHkcRR5ryAWx5+rtlej1LzFDFTGhIlA6cqg9fcPxlKgG\r\n"
        + "MaTmeTRbs3RpiIcIv4EmrKRWnL7ca6nzAi7KEcvsGepkHzFq3oWWMgDgGGCWR7xp\r\n"
        + "HRRxbLpNl2WNVpPfI7mRQtz0e+n7rpPGxt1uwFUUS9q28+9QF9g370mN6ECTkD6F\r\n"
        + "mb2gzla+VTiBNMKJ8zhwxfzy52lJ1jnk+szmLmag54J6BMmRAxpQfvuRo5cb9BQ5\r\n"
        + "x1E7Ogqg805WExagf71vEgahtX9khkFFrLs7s+YAeBnpRUn8PmapFSq8sq1+Phs9\r\n"
        + "VH2JsVEEHG5E4uYqHywEe7QDBt4xPtKLxv3fIeF+0I5envsGoXv5KJHkS57GXL8x\r\n"
        + "+0qYMrVH0Ue1Vu3QKPuBtEE+Xdi9dkPc7shNGgMeho4f5P/dMe7xJmEEU8vaYmX2\r\n"
        + "WlAMb30PxFDDarCK0ET1jXM5WBRaqIghwHqBvA58jFfupdE+kTPL4VCmf4+gs/93\r\n"
        + "5rjUoizy3hN4bQRP5f+t4aaMPofgGy515/3Oszq9pBHMAgFWSqVsn+RkvH0rmV6M\r\n"
        + "+uVxc+aO7kayu9cMFgf8V3koPmemivPeVKmYI19ydMvuqPHbNlMI0QTb2v8Vtyhe\r\n"
        + "N0u9cOsjo/ujMp1BKtYTA0sWagTEf3u/jXbjS6WCwagCRzhOorNP5laijDb1VVsk\r\n"
        + "8bKu2dfAoQ7Xv9vQbsqlPtv+haR2s5YpSb/OBbOypXjNjg1lFDyIwOAbvC2gEfFc\r\n"
        + "8XGSgKhfzLg8D1C0x6PRJWZbdOxHb9wh1iK+pHQy+nimcOAFC2BAFoS1dD4q+hpW\r\n"
        + "MDLKxTlhFnlR+EVx4CRa+js8PKVf7QIIBMqLGPH5rEBmqqBX1AyIB3Dhq0WJWOSa\r\n"
        + "7dEGyKF6j2ooBXKZ0g1JlRFssJNXdf30hRu+kNgEbVPHGL+2YKbA1mhd4ROC6mOM\r\n"
        + "Dc+GHnSPC+lOmc+BBcis6mvUJ16qTJ9NJHXwdoKiLgCFQTcO0aidkTDPtEivxTpK\r\n"
        + "1Y12wipQiRglaWP71NRaYwTKwWpr9Ni4HEcI2IiUhi55NDG60W7cr8bm8AjWsJ4i\r\n"
        + "SbxZcOK98Z7Pk/JC9ohqxdXL2Y9b2/c4ZeDU6jjJqHsmd7QYVRKGDP73Wj/Uf04e\r\n"
        + "dEhB8Ch1SGFZXlp1ei9aGU4tNtN1cRfHMHLR7/uZuTkn39L8wh/bbbKB58dsrqDG\r\n"
        + "FUvywy9lddGc3aehsCRZmv/vIbK3rdp6WBBrV50xazDg0kUJrpOV+77lXVWOvcu0\r\n"
        + "wu9388SPwCTigUsrzZvYKS4e1EH/hv/KjG2F9r8p3Pid4Gm6NEYhvyS+/i7nEkZo\r\n"
        + "TCKB2FdwUOj17rOFTnQZNZZUlhRFlWdxVk7bu1OqGkjg2xZKQN6SpclFnVVuFYyr\r\n"
        + "PBWZrglc8bH3Gy87zRPLsc/Qup/qxlSr1mPbIa2yYd3R1s0QQeEtkSQe/yqiubTw\r\n"
        + "5mapXWc66tCh/oydUZQcSA7+wZu2r/RxgU6Lepvf1LHBj6yI9knstC3Vk3/WD7Ix\r\n"
        + "Io+Kcx+0ONewSWIPIdZ4WMbLHONGnMKrqSxBR1zuFnZgztviLcj6yt/6EsbCkTEo\r\n"
        + "q3TZcjkgtaJ1tX8wysyHnX320kJlUXH8F0maOEjQqLuGzWrM+zLbjDARaGiZyCyl\r\n"
        + "NsH9YfoREsvZUiaWwm39l/LABkZtukkf0CjkWs6KjPShLDeSnEB7G/wrwtLYoEkN\r\n"
        + "u+tnRssTnNUv6ARe/0uBq6zYFALqyW5fxivyk8SfpSCdLBX0FmYwahZShCKR4e1n\r\n"
        + "2iZHv6gVOf97pDIBwDaUsLn8BDT9HrRPdtLssPhESZk9TY6/9h3fIcs8dyZNYJbc\r\n"
        + "Kx/r2rQ9QGKwAMFCrn6E3O1+u1igp4VV+5mrhYlZCjeygV3pkKnTiUmmQhapJZ4Z\r\n"
        + "wLoIAIT2+v737uKuTv0qZke3PGH2uvuG0ezznuqoGRvsUAHofJ6MogHCp97Zx0ii\r\n"
        + "3sc4HpSiu2xwvbW4i9l2IeI3LkbYhC8WuWalNYvILpRfDloyADilhdmu/aekgAyV\r\n"
        + "jvuUcHOcu+a5/OaB6GCR2Ct+7vEeiU7KLQ1kx6KXeIdhbcPzG6tgAEbrO3OsW77w\r\n"
        + "xjyygbZVUv0aPDd+cHH/niqq1Dv7c9erkLfbqy4Nt4HIkacU6ItvPGBXYwl2KXQt\r\n"
        + "Vop9L6CuBF6Q9hfuBQPaPwfD1AaXnxvxde1vRjrnqcxUAhaJZVcApfP7pVAZXQy7\r\n"
        + "GQuDxyBg4piLMSMYIYVsdViQ4HUaNxpw0rlASecnczILOmxgJrkbUbfUusmivX9V\r\n"
        + "08SFhLuaoNZnClP0irJ08jgnWTJNiVWXofxmYSQJGmUHU+PVEA110bRpsKp2mhYx\r\n"
        + "y/NsemE4EQG3kjs3rOPLHizgntdRJB1uaamTJEgLQOHL1kp62GXyTJ8DPUpasn0X\r\n"
        + "iBbL1Dbn0goeUTPkaE4bZHiq5sCzGKZU9HxmKNI/8CT0BOK5IieBZtZSXp8mWA2s\r\n"
        + "jTGA5cviFgh+T1P5KXlPrbkLPWVr4IxO48DbUdwlfpx/LYDsj1/J0NusnedLeL+t\r\n"
        + "fvxPFGfX85ORRrvsR5infdszQ3yEntBqJb2akLsPJbDpB7bty8YigDbPFJPgOWtH\r\n"
        + "ELesJJfbLQXWBKtninx8a2oAu0Jgkw5exeGMPYD28qQNRlUJOxpCWIADGH6pDWKL\r\n"
        + "3zcBrns+0jHpd6Usa3Cuulq6P+ufHT9FcKkS7QVG5wPN2M3HprbwAQmv/6zoNr6g\r\n"
        + "L/wdSh0B1RuReGYI7JHY4qMPqwbn+aPRvz3ePvZRjwSiUySYhFvsynpzQNzuCzTz\r\n"
        + "9sfiZkRiPsZb6wP04VvC8HTdtIOOC8Qg/rLLRQiupnCwNZItPmIJYyp2SY/bGREx\r\n"
        + "1vFTf/+z5x5fypcvrLzbytGToRHHQnnjlsVw7N/Pu5WA0383AjNIlzWO8AJ5igc1\r\n"
        + "skLiE9WVzhsCzLOLzrOKtSbVoFpAJCXnRLevoFuqvYEd/h6o9Sx8299LX/qmi4kA\r\n"
        + "DwVXqUK5QgfOeAz+Az52CVeCmGBDzfnj25OSfmCRYI5vjt/cmgFDQDH0x5VAvJga\r\n"
        + "XbLDHjQQ3FpBQTdCn9oKX7SDdMBUwcvbTvI9lbjCmp0EdPjfxWA+85veOk2QrCyj\r\n"
        + "x3tpcT54zM84UYqr/youzM0HO92wDJc3lRevpV4BgPt4zH53mwxarjGxc2lXXlTS\r\n"
        + "70AN9CfL3Uxh7dw8pd3vsFfCKEMXHwn5X+N8em116I0WUNppOHxNzsUfznxNg9Tt\r\n"
        + "HzZlK255G/t1yJVwWgRbGJrVMhEQrEfZVQziglwwZgZ3wKNfgemOsIZx5lLMkBtO\r\n"
        + "2zDoW5KQQuOcXALY6ePdI1zMZrveZ7nj1EmBJWnzhT2zkjTOETsZTEyvVyIbQLZd\r\n"
        + "D6irge6dZ6ioFZB/rptk2RqijIaIVK1RHTo=\r\n" + "=HTxc\r\n" + "-----END PGP MESSAGE-----";
    byte[] privateKey_byte = privateKey.getBytes(StandardCharsets.UTF_8);
    JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();
    jobFilePriorityEntity.setJobId(1);
    jobFilePriorityEntity.setExpectedDate(new Date(new java.util.Date().getTime()));
    jobFilePriorityEntity.setErrorThreshHold(1);
    jobFilePriorityEntity.setFileMinRecordCountAllowed(1);
    jobFilePriorityEntity.setFileTransmissionName(fileName);
    jobFilePriorityEntity.setFileType("census");
    jobFilePriorityEntity.setFileFormatName("csv");
    jobFilePriorityEntity.setRowDelimiter("\n");
    jobFilePriorityEntity.setFieldDelimiter(",");
    jobFilePriorityEntity.setEscapeCharacter("1");
    jobFilePriorityEntity.setSegmentDelimiter("1");
    jobFilePriorityEntity.setPriority(1);
    jobFilePriorityEntity.setEmployerIdAndClientIdAndTestCfgs("1::1::testcfg1,2::1::testcfg1");
    jobFilePriorityEntity.setMasterFileTemplateId(1);
    jobFilePriorityEntity.setMasterFileTemplateVersion(1);
    jobFilePriorityEntity.setFullOrChange(1);
    jobFilePriorityEntity.setResultsMode(1);
    jobFilePriorityEntity.setFileMaxRecordCountAllowed(100);
    jobFilePriorityEntity.setFileProcessingErrorThresholdFormat("1");
    jobFilePriorityEntity.setFileIdentifier(1);
    jobFilePriorityEntity.setFileId(1);
    jobFilePriorityEntity.setFileVersion(1);
    jobFilePriorityEntity.setCloneNumberList("1,2");

    jobFilePriorityEntity.setFileStateId(1);
    jobFilePriorityEntity.setFilePath(filePath);
    jobFilePriorityEntity.setFileName(fileName);
    jobFilePriorityEntity.setFileStatePrivatekey(privateKey_byte);
    jobFilePriorityEntity.setMasterPrivateKey(masterKey);
    jobFilePriorityEntity.setFileNewName(fileName);

    jobFilePriorityEntity.setSectionAttributeEntities(createSectionAttributeEntity());
    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();
    jobPriorityGetPayload.setJobFilePriorityEntity(jobFilePriorityEntity);
    return jobPriorityGetPayload;

  }

  private List<SectionAttributeEntity> createSectionAttributeEntity() {
    SectionAttributeEntity sectionAttributeEntity = new SectionAttributeEntity();
    sectionAttributeEntity.setStandardizedName("firstName");
    sectionAttributeEntity.setAttributeDataType("int");
    sectionAttributeEntity.setOrder(1);
    sectionAttributeEntity.setSectionType("1");
    sectionAttributeEntity.setSectionDelimiter(",");
    sectionAttributeEntity.setIsAttributeMandatory(true);
    sectionAttributeEntity.setAttributeSize(1);
    sectionAttributeEntity.setAttributeStartPosition(1);
    sectionAttributeEntity.setAttributeEndPosition(2);
    List<SectionAttributeEntity> sectionAttributeList = new ArrayList<>();
    sectionAttributeList.add(sectionAttributeEntity);
    return sectionAttributeList;
  }

}
