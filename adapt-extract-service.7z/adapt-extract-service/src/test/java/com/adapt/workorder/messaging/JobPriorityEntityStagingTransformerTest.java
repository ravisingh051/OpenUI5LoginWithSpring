package com.adapt.workorder.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.file.entity.JobDetailsPrioritizationStagingEntity;
import com.adapt.file.entity.JobPriorityEntity;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobPriorityEntityStagingTransformer.class })
public class JobPriorityEntityStagingTransformerTest {

  @Autowired
  private JobPriorityEntityStagingTransformer jobPriorityEntityStagingTransformer;

  @Test
  public void tes_transformation() throws Exception {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    Message<?> message = MessageBuilder.withPayload(jobPriorityEntities).build();
    List<JobDetailsPrioritizationStagingEntity> jobDetailsPrioritizationStagingEntities = (List<JobDetailsPrioritizationStagingEntity>) jobPriorityEntityStagingTransformer
        .doTransform(message);
    assertEquals(jobDetailsPrioritizationStagingEntities.size(), jobPriorityEntities.size());
  }

  @Test
  public void tes_transformation_with_headers() throws Exception {

    List<JobPriorityEntity> jobPriorityEntities = createJobPriorityEntityList();
    Message<?> message = MessageBuilder.withPayload(jobPriorityEntities)
        .setHeader("sourceInstance", "Source1").build();
    List<JobDetailsPrioritizationStagingEntity> jobDetailsPrioritizationStagingEntities = (List<JobDetailsPrioritizationStagingEntity>) jobPriorityEntityStagingTransformer
        .doTransform(message);
    assertEquals(jobDetailsPrioritizationStagingEntities.size(), jobPriorityEntities.size());
  }

  @Test
  public void tes_transformation_without_prio() throws Exception {

    List<JobPriorityEntity> jobPriorityEntities = new ArrayList<>();
    Message<?> message = MessageBuilder.withPayload(jobPriorityEntities)
        .setHeader("sourceInstance", "Source1").build();
    List<JobDetailsPrioritizationStagingEntity> jobDetailsPrioritizationStagingEntities = (List<JobDetailsPrioritizationStagingEntity>) jobPriorityEntityStagingTransformer
        .doTransform(message);
    assertEquals(0, jobDetailsPrioritizationStagingEntities.size());

  }

  private List<JobPriorityEntity> createJobPriorityEntityList() {

    List<JobPriorityEntity> jobPriorityEntities = new ArrayList<JobPriorityEntity>();
    for (int i = 1; i < 15; i++) {
      JobPriorityEntity jobPriorityEntity = new JobPriorityEntity();
      jobPriorityEntity.setJobId(i);
      jobPriorityEntity.setDirection("Outbound");
      jobPriorityEntity.setEmployerIds((String.valueOf(i) + "," + String.valueOf(i + 1)));
      final Calendar calender = Calendar.getInstance();
      calender.set(Calendar.HOUR_OF_DAY, 0);
      calender.set(Calendar.MINUTE, 0);
      calender.set(Calendar.SECOND, 0);
      calender.set(Calendar.MILLISECOND, 0);
      jobPriorityEntity.setExpectedStartDate(new Date(calender.getTime().getTime()));
      jobPriorityEntity.setFileId(i);
      jobPriorityEntity.setFileTypeId(i);
      jobPriorityEntity.setIsSlaMapped(false);
      jobPriorityEntity.setTradingPartnerId(i);
      if (i == 1 || i == 8) {
        jobPriorityEntity.setIsSlaMapped(true);
      }
      if (i == 2 || i == 9) {
        jobPriorityEntity.setFileId(222);
      }
      if (i == 3 || i == 10) {
        jobPriorityEntity.setEmployerIds("333");
      }
      if (i == 4 || i == 11) {
        jobPriorityEntity.setTradingPartnerId(444);
      }
      if (i == 5 || i == 12) {
        jobPriorityEntity.setFileTypeId(555);
      }
      if (i == 6 || i == 13) {
        jobPriorityEntity.setDirection("Inbound");
      }
      if (i == 7 || i == 14) {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        jobPriorityEntity.setExpectedStartDate(new Date(cal.getTime().getTime()));
      }
      jobPriorityEntities.add(jobPriorityEntity);
    }
    return jobPriorityEntities;
  }

}
