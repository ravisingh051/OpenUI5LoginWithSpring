package com.adapt.workorder.predicate;

import static org.junit.Assert.assertTrue;

import com.adapt.file.entity.JobPriorityEntity;
import com.adapt.workorder.config.ClassificationTypeEnum;
import com.adapt.workorder.service.PrioritizationFactory;
import java.sql.Date;
import java.util.Calendar;
import java.util.function.Predicate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { PrioritizationFactory.class })
public class PrioritizationFactoryTest {

  @Test
  public void tes_transformation() throws Exception {

    Predicate<JobPriorityEntity> predicateSla = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.SLA, "YES");
    JobPriorityEntity jobPriorityEntity = new JobPriorityEntity();
    jobPriorityEntity.setIsSlaMapped(true);
    assertTrue(predicateSla.test(jobPriorityEntity));

    Predicate<JobPriorityEntity> predicateFile = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.FILE_ID, "123");
    JobPriorityEntity jobPriorityEntityFile = new JobPriorityEntity();
    jobPriorityEntityFile.setFileId(123);
    assertTrue(predicateFile.test(jobPriorityEntityFile));

    Predicate<JobPriorityEntity> predicateEmployerId = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.EMPLOYER, "123");
    JobPriorityEntity jobPriorityEntityEmp = new JobPriorityEntity();
    jobPriorityEntityEmp.setEmployerIds("123");
    assertTrue(predicateEmployerId.test(jobPriorityEntityEmp));

    Predicate<JobPriorityEntity> predicateTrading = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.TRADING_PARTNER, "123");
    JobPriorityEntity jobPriorityEntityTrading = new JobPriorityEntity();
    jobPriorityEntityTrading.setTradingPartnerId(123);
    assertTrue(predicateTrading.test(jobPriorityEntityTrading));

    Predicate<JobPriorityEntity> predicateFileType = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.FILE_TYPE, "123");
    JobPriorityEntity jobPriorityFileType = new JobPriorityEntity();
    jobPriorityFileType.setFileTypeId(123);
    assertTrue(predicateFileType.test(jobPriorityFileType));

    Predicate<JobPriorityEntity> predicateDir = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.FILE_DIRECTION, "Inbound");
    JobPriorityEntity jobPriorityEntityDir = new JobPriorityEntity();
    jobPriorityEntityDir.setDirection("INBOUND");
    assertTrue(predicateDir.test(jobPriorityEntityDir));

    Predicate<JobPriorityEntity> predicatePrev = PrioritizationFactory
        .getPredicate(ClassificationTypeEnum.PREVIOUS_DAY, "YES");
    JobPriorityEntity jobPriorityEntityprev = new JobPriorityEntity();
    final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, -1);
    jobPriorityEntityprev.setExpectedStartDate(new Date(cal.getTime().getTime()));
    assertTrue(predicatePrev.test(jobPriorityEntityprev));

  }

}
