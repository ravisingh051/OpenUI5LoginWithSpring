package com.adapt.message;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import com.adapt.exception.NullResponseException;
import com.adapt.file.entity.JobPriorityGetPayload;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { InvokeJobPrioritizationServiceActivator.class })
public class InvokeJobPrioritizationServiceActivatorTest {

  @Autowired
  private InvokeJobPrioritizationServiceActivator invokeJobPrioritizationServiceActivator;

  @Test
  public void testExecute() throws Exception {

    JobPrioritizationGateway jobPrioritizationGateway = Mockito
        .mock(JobPrioritizationGateway.class);
    invokeJobPrioritizationServiceActivator.setJobPrioritizationGateway(jobPrioritizationGateway);
    assertNotNull(invokeJobPrioritizationServiceActivator.getJobPrioritizationGateway());
    invokeJobPrioritizationServiceActivator.setComponentName("1");
    Message<JobPriorityGetPayload> message = Mockito.mock(Message.class);
    Mockito.when(jobPrioritizationGateway.startJobPrioritization(message)).thenReturn(null);
    Message<?> executeMsg = invokeJobPrioritizationServiceActivator.execute(message);
    assertNull(executeMsg);

  }

  @Test
  public void testExecuteNullResponse() throws Exception {

    JobPrioritizationGateway jobPrioritizationGateway = Mockito
        .mock(JobPrioritizationGateway.class);
    invokeJobPrioritizationServiceActivator.setJobPrioritizationGateway(jobPrioritizationGateway);
    assertNotNull(invokeJobPrioritizationServiceActivator.getJobPrioritizationGateway());
    invokeJobPrioritizationServiceActivator.setComponentName("1");
    Message<JobPriorityGetPayload> message = Mockito.mock(Message.class);
    Mockito.when(jobPrioritizationGateway.startJobPrioritization(message))
        .thenThrow(new NullResponseException("Test"));
    Message<?> executeMsg = invokeJobPrioritizationServiceActivator.execute(message);
    assertNull(executeMsg);

  }

}
