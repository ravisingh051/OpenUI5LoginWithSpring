package com.adapt.message;

import static org.junit.Assert.assertNotNull;

import com.alight.adapt.datasets.HeaderDataset;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CreateEmptyHeaderServiceActivator.class })
public class CreateEmptyHeaderServiceActivatorTest {
  @Autowired
  private CreateEmptyHeaderServiceActivator createEmptyHeaderServiceActivator;

  @Test
  public void testDoTransform() throws Exception {
    MessageBuilder<HeaderDataset> messageBuilder = MessageBuilder.withPayload(new HeaderDataset());
    Message<HeaderDataset> headerDataSet =
        createEmptyHeaderServiceActivator.doTransform(messageBuilder.build());
    assertNotNull(headerDataSet);

  }

}
