package com.adapt.message;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adapt.exception.RawDataExtractionException;
import com.adapt.file.entity.FileOutBoundModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.service.EventNotificationService;
import org.assertj.core.util.CheckReturnValue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpServerErrorException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RawDataExtractionErrorProcessorServiceActivator.class })
public class RawDataExtractionErrorProcessorServiceActivatorTest {

  @Autowired
  RawDataExtractionErrorProcessorServiceActivator rawDataExtractionErrorProcessorServiceActivator;

  @MockBean
  EventNotificationService eventNotificationService;

  @MockBean(name = "mainMessage")
  Message<?> message;

  @MockBean(name = "failedMessage")
  Message<?> failedMessage;

  @MockBean
  MessagingException messagingException;

  @MockBean
  JobModelMultiEmployer jobModelMultiEmployer;

  @MockBean
  HttpServerErrorException httpServerErrorException;

  @MockBean
  FileOutBoundModel fileOutBoundModel;

  @Test
  public void test_exceptionOccured_jobFailedEventCalled() {
    Mockito.doReturn(messagingException).when(message).getPayload();
    if (Mockito.doReturn(failedMessage).when(messagingException).getFailedMessage() == null) {
      Mockito.doReturn(jobModelMultiEmployer).when(failedMessage).getPayload();
    }
    when(messagingException.getCause()).thenReturn(httpServerErrorException);
    when(jobModelMultiEmployer.getFileOutBoundModel()).thenReturn(fileOutBoundModel);
    when(jobModelMultiEmployer.getJobId()).thenReturn(1);
    when(fileOutBoundModel.getFileId()).thenReturn(1);
    when(fileOutBoundModel.getFileIdentifier()).thenReturn(1);
    when(fileOutBoundModel.getFileVersion()).thenReturn(1);

    rawDataExtractionErrorProcessorServiceActivator.processMessage(message);
    assertTrue(failedMessage != null);
    verify(eventNotificationService, times(1)).sendJobFailedEvent(Mockito.any());
  }
}
