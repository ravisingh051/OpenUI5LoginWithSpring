package com.adapt.message;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import com.adapt.exception.NullResponseException;
import com.adapt.file.entity.JobPriorityGetPayload;
import java.util.HashMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { GetJobServiceActivator.class })
public class GetJobServiceActivatorTest {

  @Autowired
  private GetJobServiceActivator getJobServiceActivator;

  @Test
  public void testGetJob() throws Exception {

    DbJobGateway dbJobGateway = Mockito.mock(DbJobGateway.class);
    getJobServiceActivator.setDbJobGateway(dbJobGateway);
    assertNotNull(getJobServiceActivator.getDbJobGateway());
    getJobServiceActivator.setComponentName("1");
    Message<JobPriorityGetPayload> message = Mockito.mock(Message.class);
    MessageHeaders headers = new MessageHeaders(new HashMap<>());
    JobPriorityGetPayload jobPriorityGetPayload = Mockito.mock(JobPriorityGetPayload.class);
    Mockito.when(message.getHeaders()).thenReturn(headers);
    Mockito.when(message.getPayload()).thenReturn(jobPriorityGetPayload);
    Mockito.when(dbJobGateway.getDbJob(jobPriorityGetPayload, headers)).thenReturn(null);
    Message<?> job = getJobServiceActivator.getJob(message);
    assertNull(job);

  }

  @Test
  public void testGetJobException() throws Exception {
    DbJobGateway dbJobGateway = Mockito.mock(DbJobGateway.class);
    getJobServiceActivator.setDbJobGateway(dbJobGateway);
    getJobServiceActivator.setComponentName("1");
    Message<JobPriorityGetPayload> message = Mockito.mock(Message.class);
    MessageHeaders headers = new MessageHeaders(new HashMap<>());
    JobPriorityGetPayload jobPriorityGetPayload = Mockito.mock(JobPriorityGetPayload.class);
    Mockito.when(message.getHeaders()).thenReturn(headers);
    Mockito.when(message.getPayload()).thenReturn(jobPriorityGetPayload);
    Mockito.when(dbJobGateway.getDbJob(jobPriorityGetPayload, headers))
        .thenThrow(new NullResponseException("Test"));
    Message<?> job = getJobServiceActivator.getJob(message);
    assertNull(job);
  }

}
