package com.adapt.message;

import static org.junit.Assert.assertNotNull;

import com.adapt.config.Constant;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { SourceTypeConfigurationServiceActivator.class })
public class SourceTypeConfigurationServiceActivatorTest {

  @Autowired
  private SourceTypeConfigurationServiceActivator sourceTypeConfigurationServiceActivator;

  @Test
  public void testSourceTypeConfigurationFile() throws Exception {

    ConfigurationGateway apiConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    ConfigurationGateway fileConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(apiConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(fileConfigurationGateway);
    assertNotNull(sourceTypeConfigurationServiceActivator.getApiConfigurationGateway());
    assertNotNull(sourceTypeConfigurationServiceActivator.getFileConfigurationGateway());
    sourceTypeConfigurationServiceActivator.setComponentName("1");

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_DEL)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationFileFixedWidth() throws Exception {

    ConfigurationGateway apiConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    ConfigurationGateway fileConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(apiConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(fileConfigurationGateway);
    assertNotNull(sourceTypeConfigurationServiceActivator.getApiConfigurationGateway());
    assertNotNull(sourceTypeConfigurationServiceActivator.getFileConfigurationGateway());
    sourceTypeConfigurationServiceActivator.setComponentName("1");

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_FIX)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationAPI() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_DEL)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    ConfigurationGateway apiConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    ConfigurationGateway fileConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(apiConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(fileConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationWithoutFileGateway() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_DEL)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    ConfigurationGateway apiConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(apiConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(null);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationWithFileGatewayNull() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_DEL)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(null);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationWithAPIGatewayNull() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_API)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(null);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationWithoutAPIGatewayNull() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_API)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    ConfigurationGateway apiConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(apiConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

  @Test
  public void testSourceTypeConfigurationWithoutAPIGateway() throws Exception {

    Message<?> message =
        MessageBuilder.withPayload("1").setHeader("dataSourceType", Constant.SOURCE_TYPE_FILE_DEL)
            .setHeader("dataTargetType", Constant.SOURCE_TYPE_API).build();

    ConfigurationGateway fileConfigurationGateway = Mockito.mock(ConfigurationGateway.class);
    sourceTypeConfigurationServiceActivator.setApiConfigurationGateway(null);
    sourceTypeConfigurationServiceActivator.setFileConfigurationGateway(fileConfigurationGateway);
    sourceTypeConfigurationServiceActivator.setComponentName("1");
    sourceTypeConfigurationServiceActivator.executeSourceType(message);
  }

}
