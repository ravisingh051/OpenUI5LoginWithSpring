package com.adapt.message;

import com.adapt.exception.RawDataExtractionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RawDataExtractionErrorServiceActivator.class })
public class RawDataExtractionErrorServiceActivatorTest {

  @Autowired
  RawDataExtractionErrorServiceActivator rawDataExtractionErrorServiceActivator;

  @MockBean
  Message<?> message;

  @Test(expected = RawDataExtractionException.class)
  public void test_rawDataExtractionExceptionThrown() {
    rawDataExtractionErrorServiceActivator.throwRawDataExtractionException(message);
  }

  @Test(expected = RawDataExtractionException.class)
  public void test_rawDataExtractionExceptionThrownWithoutServiceActivator() {
    throw new RawDataExtractionException("Raw Data Extraction Exception Occurred");
  }
}
