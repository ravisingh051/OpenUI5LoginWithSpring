package com.adapt.api.messaging;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.adapt.api.messaging.JobFilePriorityEntityToJobModelMultiEmployerTransformer;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.service.JobService;
import com.adapt.util.MockDataUtil;
import java.time.LocalDate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JobFilePriorityEntityToJobModelMultiEmployerTransformer.class })
public class JobFilePriorityEntityToJobModelMultiEmployerTransformerTest {

  @MockBean
  private JobService jobService;

  @Autowired
  private JobFilePriorityEntityToJobModelMultiEmployerTransformer jobConfigurationLoader;

  @Test
  public void doTransform() throws Exception {
    when(jobService.jobFilePriorityEntityToJobModelMultiEmployerTransformer(any(LocalDate.class),
        any(JobFilePriorityEntity.class))).thenReturn(MockDataUtil.buildJobModelMultiEmployer());
    JobPriorityGetPayload jobPriorityGetPayload = new JobPriorityGetPayload();
    jobPriorityGetPayload.setJobFilePriorityEntity(MockDataUtil.buildJobFilePriorityEntity());
    MessageBuilder<?> messageBuilder = MessageBuilder.withPayload(jobPriorityGetPayload);
    JobModelMultiEmployer jobDetails = (JobModelMultiEmployer) jobConfigurationLoader
        .doTransform(messageBuilder.build());
    assertEquals(MockDataUtil.buildJobModelMultiEmployer().getJobId(), jobDetails.getJobId());
  }

}
