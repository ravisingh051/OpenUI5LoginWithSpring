package com.adapt.api.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.api.messaging.CoreTransactionExtractionDetailsCountConfig;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.util.MockDataUtil;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CoreTransactionExtractionDetailsCountConfig.class })
public class CoreTransactionExtractionDetailsCountConfigTest {

  @Autowired
  private CoreTransactionExtractionDetailsCountConfig coreTransactionExtractionDetailsCountConfig;

  @Test
  public void configTest() {
    JobModelMultiEmployer jobModelMultiEmployer = MockDataUtil.buildJobModelMultiEmployer();
    MessageBuilder<JobModelMultiEmployer> builder = new DefaultMessageBuilderFactory()
        .withPayload(jobModelMultiEmployer);
    Message<List<TransactionExtractionDetails>> config = coreTransactionExtractionDetailsCountConfig
        .config(builder.build());
    assertNotNull(config.getPayload());

  }
}
