package com.adapt.api.messaging;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.adapt.api.service.ChangeCriteriaDroolsService;
import com.adapt.api.service.SelectionCriteriaDroolsService;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.util.MockDataUtil;
import com.alight.adapt.dataextraction.coretransaction.v1.models.CoreTransactionDataset;
import com.alight.adapt.datasets.AbstractDataset;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RuleExecutorServiceActivator.class })
public class RuleExecutorServiceActivatorTest {

  @Autowired
  private RuleExecutorServiceActivator selectionCriteriaRuleServiceActivator;

  @MockBean
  private SelectionCriteriaDroolsService selectionCriteriaDroolsService;

  @MockBean
  private ChangeCriteriaDroolsService changeCriteriaDroolsService;

  @Test
  public void applyFormattingRulesTest() {
    MessageBuilder<AbstractDataset> messageBuilder = MessageBuilder
        .withPayload(new CoreTransactionDataset());
    JobModelMultiEmployer jobModelMultiEmployer = MockDataUtil.buildJobModelMultiEmployer();
    messageBuilder.setHeader("jobModelMultiEmployer", MockDataUtil.buildJobModelMultiEmployer());
    when(selectionCriteriaDroolsService.executeRules(
        eq(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier()), anyObject()))
            .thenReturn(1);
    when(changeCriteriaDroolsService.executeRules(
        eq(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier()), anyObject()))
            .thenReturn(1);
    Message<AbstractDataset> applyRules = selectionCriteriaRuleServiceActivator
        .applyRules(messageBuilder.build());
    assertNotNull(applyRules);
  }

}
