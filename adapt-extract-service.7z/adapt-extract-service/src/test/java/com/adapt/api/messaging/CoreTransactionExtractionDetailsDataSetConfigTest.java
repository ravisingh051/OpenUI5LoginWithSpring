package com.adapt.api.messaging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.util.MockDataUtil;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CoreTransactionExtractionDetailsDataSetConfig.class })
@TestPropertySource(properties = { "dataset.processing.outbound.extraction.batchsize=100" })
public class CoreTransactionExtractionDetailsDataSetConfigTest {

  @Autowired
  public CoreTransactionExtractionDetailsDataSetConfig coreTExtractionDetailsDataSetConfig;

  @Test
  public void testConfig() {
    List<TransactionExtractionDetails> coreTransactionExtractionDetailsList = new ArrayList<>();
    int totalCount = 1050;
    TransactionExtractionDetails buildCoreTransactionExtractionDetails = MockDataUtil
        .buildCoreTransactionExtractionDetails();
    buildCoreTransactionExtractionDetails.setExtractionCount(Long.valueOf(totalCount));
    coreTransactionExtractionDetailsList.add(buildCoreTransactionExtractionDetails);

    MessageBuilder<List<TransactionExtractionDetails>> builder = new DefaultMessageBuilderFactory()
        .withPayload(coreTransactionExtractionDetailsList);
    Message<List<TransactionExtractionDetailsPaginated>> config = coreTExtractionDetailsDataSetConfig
        .config(builder.build());
    long totalPage = totalCount / 100;
    totalPage = totalPage + ((totalCount % 100) != 0 ? 1 : 0);
    assertNotNull(config);
    assertEquals(config.getPayload().size(), totalPage);
  }

  @Test
  public void testConfigForRoundData() {
    List<TransactionExtractionDetails> coreTransactionExtractionDetailsList = new ArrayList<>();
    int totalCount = 1000;
    TransactionExtractionDetails buildCoreTransactionExtractionDetails = MockDataUtil
        .buildCoreTransactionExtractionDetails();
    buildCoreTransactionExtractionDetails.setExtractionCount(Long.valueOf(totalCount));
    coreTransactionExtractionDetailsList.add(buildCoreTransactionExtractionDetails);

    MessageBuilder<List<TransactionExtractionDetails>> builder = new DefaultMessageBuilderFactory()
        .withPayload(coreTransactionExtractionDetailsList);
    Message<List<TransactionExtractionDetailsPaginated>> messageBuilder = coreTExtractionDetailsDataSetConfig
        .config(builder.build());
    long totalPage = totalCount / 100;
    totalPage = totalPage + ((totalCount % 100) != 0 ? 1 : 0);
    assertNotNull(messageBuilder);
    assertEquals(messageBuilder.getPayload().size(), totalPage);
  }

}
