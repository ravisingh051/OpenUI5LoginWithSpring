package com.adapt.api.messaging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NoContentDatasetConfig.class })
public class NoContentDatasetConfigTest {

  @Autowired
  public NoContentDatasetConfig noContentDatasetConfig;

  @Test
  public void testConfig() {
    List<TransactionExtractionDetailsPaginated> transactionExtractionDetailsPaginatedList =
        new ArrayList<>();
    MessageBuilder<List<TransactionExtractionDetailsPaginated>> builder =
        new DefaultMessageBuilderFactory().withPayload(transactionExtractionDetailsPaginatedList);
    Message<List<TransactionExtractionDetailsPaginated>> config = noContentDatasetConfig.config(
        builder.build());
    assertNotNull(config);
    assertEquals(config.getPayload().size(), 1);

  }

}
