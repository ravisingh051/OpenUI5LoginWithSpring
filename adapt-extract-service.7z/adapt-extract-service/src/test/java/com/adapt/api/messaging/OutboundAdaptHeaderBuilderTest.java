package com.adapt.api.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.OutboundConstant;
import com.adapt.config.Constant;
import com.adapt.util.MockDataUtil;
import com.alight.adapt.dataextraction.coretransaction.v1.models.CoreTransactionDataset;
import com.alight.adapt.datasets.AbstractDataset;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { OutboundAdaptHeaderBuilder.class, ObjectMapper.class })
public class OutboundAdaptHeaderBuilderTest {

  @Autowired
  private OutboundAdaptHeaderBuilder outboundAdaptHeaderBuilder;

  @Autowired
  ObjectMapper objectMapper;

  @Test
  public void test_build() throws Exception {
    MessageBuilder<AbstractDataset> messageBuilder = MessageBuilder
        .withPayload(new CoreTransactionDataset());
    messageBuilder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER,
        MockDataUtil.buildJobModelMultiEmployer());
    messageBuilder.setHeader(Constant.HEADER_CLAIM_CHECK, UUID.randomUUID());
    messageBuilder.setHeader(Constant.TRAILER_CLAIM_CHECK, UUID.randomUUID());
    String adaptHeaderString = outboundAdaptHeaderBuilder.build(messageBuilder.build());
    assertNotNull(adaptHeaderString);
  }

  @Test
  public void test_build_OtherHeaders() throws Exception {
    MessageBuilder<AbstractDataset> messageBuilder = MessageBuilder
        .withPayload(new CoreTransactionDataset());
    messageBuilder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER,
        MockDataUtil.buildJobModelMultiEmployer());

    UUID headerClaimCheck = UUID.randomUUID();

    UUID trailerClaimCheck = UUID.randomUUID();
    messageBuilder.setHeader(Constant.HEADER_CLAIM_CHECK, headerClaimCheck);
    messageBuilder.setHeader(Constant.TRAILER_CLAIM_CHECK, trailerClaimCheck);
    messageBuilder.setHeader("correlationId", UUID.randomUUID());
    messageBuilder.setHeader(Constant.SEQUENCE_NUMBER_HEADER, 5);
    messageBuilder.setHeader(Constant.SEQUENCE_SIZE_HEADER, 55);
    String adaptHeaderString = outboundAdaptHeaderBuilder.build(messageBuilder.build());
    assertNotNull(adaptHeaderString);

  }
}
