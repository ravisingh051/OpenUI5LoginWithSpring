package com.adapt.api.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.OutboundConstant;
import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.util.MockDataUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CoreTransactionExtractionDetailsDataSetRequestConfig.class })
public class CoreTransactionExtractionDetailsDataSetRequestConfigTest {

  @Autowired
  private CoreTransactionExtractionDetailsDataSetRequestConfig coreTransactionExtractionDetailsDataSetRequestConfig;

  @Test
  public void extractionDataRequestConfig() throws Exception {
    TransactionExtractionDetailsPaginated coreTeDetailsPaginated = new TransactionExtractionDetailsPaginated();
    coreTeDetailsPaginated.setChunkNumber(1L);
    coreTeDetailsPaginated.setChunkSize(12L);
    coreTeDetailsPaginated.setExtractionCount(2L);
    coreTeDetailsPaginated.setPlanSubtypes("planSubtypes");
    coreTeDetailsPaginated.setSourceEmployerId(2);
    coreTeDetailsPaginated.setPlanYear(2020);
    MessageBuilder<TransactionExtractionDetailsPaginated> builder = new DefaultMessageBuilderFactory()
        .withPayload(coreTeDetailsPaginated);
    builder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER,
        MockDataUtil.buildJobModelMultiEmployer());
    Message<TransactionExtractionDetailsPaginated> extractionDataRequestConfig = coreTransactionExtractionDetailsDataSetRequestConfig
        .extractionDataRequestConfig(builder.build());
    assertNotNull(extractionDataRequestConfig);
  }
}
