package com.adapt.api.messaging;

import static org.junit.Assert.assertEquals;

import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.api.messaging.TransactionDatasetTransformer;
import com.adapt.config.Constant;
import com.alight.adapt.dataextraction.coretransaction.v1.models.CoreTransactionDataset;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { TransactionDatasetTransformer.class })
public class TransactionDatasetTransformerTest {

  @Autowired
  private TransactionDatasetTransformer coreTransactionDatasetTransformer;

  @Test
  public void getJobDetailsTest() throws Exception {
    List<TransactionExtractionDetailsPaginated> aggrigatedMessage = new ArrayList<>();
    {
      TransactionExtractionDetailsPaginated coreTransactionExtractionDetailsPaginated = new TransactionExtractionDetailsPaginated();
      aggrigatedMessage.add(coreTransactionExtractionDetailsPaginated);
      coreTransactionExtractionDetailsPaginated.setAbstractDatasets(new ArrayList<>());
      coreTransactionExtractionDetailsPaginated.getAbstractDatasets()
          .add(new CoreTransactionDataset());
      coreTransactionExtractionDetailsPaginated.getAbstractDatasets()
          .add(new CoreTransactionDataset());
    }
    {
      TransactionExtractionDetailsPaginated coreTransactionExtractionDetailsPaginated = new TransactionExtractionDetailsPaginated();
      aggrigatedMessage.add(coreTransactionExtractionDetailsPaginated);
      coreTransactionExtractionDetailsPaginated.setAbstractDatasets(new ArrayList<>());
      coreTransactionExtractionDetailsPaginated.getAbstractDatasets()
          .add(new CoreTransactionDataset());
      coreTransactionExtractionDetailsPaginated.getAbstractDatasets()
          .add(new CoreTransactionDataset());
    }
    MessageBuilder<List<TransactionExtractionDetailsPaginated>> builder = new DefaultMessageBuilderFactory()
        .withPayload(aggrigatedMessage);
    
    int extractionCount = 123;
    builder.setHeader(Constant.FILE_RECORD_COUNT, extractionCount);
    
    Object doTransform = coreTransactionDatasetTransformer.doTransform(builder.build());
    assertEquals(ArrayList.class, doTransform.getClass());
    assertEquals(4, ((List) doTransform).size());
  }

}
