package com.adapt.api.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DroolsServiceImpl.class })
public class DroolsServiceImplTest {

  @Autowired
  private DroolsServiceImpl droolsServiceImpl;

  @MockBean
  private RuleService ruleService;

  @Test
  public void prepareBusinessCriteriaRuleContainerTest() {
    KieContainer prepareBusinessCriteriaRuleContainer = droolsServiceImpl
        .prepareBusinessCriteriaRuleContainer(1);
    assertNotNull(prepareBusinessCriteriaRuleContainer);
  }

  @Test
  public void removeBusinessCriteriaRuleContainerTest() {
    droolsServiceImpl.removeBusinessCriteriaRuleContainer();
    assertNotNull(droolsServiceImpl);
  }

  @Test
  public void prepareChangeCriteriaRuleContainerTest() {
    KieContainer prepareChangeCriteriaRuleContainer = droolsServiceImpl
        .prepareChangeCriteriaRuleContainer(1);
    assertNotNull(prepareChangeCriteriaRuleContainer);
  }

  @Test
  public void removeChangeCriteriaRuleContainerTest() {
    droolsServiceImpl.removeChangeCriteriaRuleContainer();
    assertNotNull(droolsServiceImpl);
  }

  @Test
  public void prepareSelectionCriteriaRulesContainerTest() {
    KieContainer prepareSelectionCriteriaRulesContainer = droolsServiceImpl
        .prepareSelectionCriteriaRulesContainer(1);
    assertNotNull(prepareSelectionCriteriaRulesContainer);
  }

  @Test
  public void removeSelectionCriteriaRulesContainerTest() {
    droolsServiceImpl.removeSelectionCriteriaRulesContainer();
    assertNotNull(droolsServiceImpl);
  }

}
