package com.adapt.api.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.adapt.file.entity.DroolsBusinessRulesDecisionTableEntity;
import com.adapt.file.entity.ProcessorRuleModel;
import com.adapt.repository.DroolsBusinessRuleGroupName;
import com.adapt.repository.RuleRepository;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RuleServiceImpl.class })
public class RuleServiceImplTest {

  @Autowired
  private RuleService ruleService;

  @MockBean
  private RuleRepository ruleRepository;

  @Test
  public void getBusinessCriteriaRules_test() {
    DroolsBusinessRulesDecisionTableEntity rulesEntity = new DroolsBusinessRulesDecisionTableEntity();
    rulesEntity.setCurrent(true);
    rulesEntity.setDroolsBusinessRuleDrlFileContent("droolsBusinessRuleDrlFileContent");
    rulesEntity.setDroolsBusinessRuleId(1);
    rulesEntity.setDroolsBusinessRuleVersion(1);
    when(ruleRepository.getRules(eq(1),
        any(DroolsBusinessRuleGroupName.BUSINESS_CRITERIA.getClass())))
            .thenReturn(Arrays.asList(rulesEntity));
    List<ProcessorRuleModel> businessCriteriaRules = ruleService.getBusinessCriteriaRules(1);
    assertNotNull(businessCriteriaRules);
  }

  @Test
  public void getChangeCriteriaRules_test() {
    DroolsBusinessRulesDecisionTableEntity rulesEntity = new DroolsBusinessRulesDecisionTableEntity();
    rulesEntity.setCurrent(true);
    rulesEntity.setDroolsBusinessRuleDrlFileContent("droolsBusinessRuleDrlFileContent");
    rulesEntity.setDroolsBusinessRuleId(1);
    rulesEntity.setDroolsBusinessRuleVersion(1);
    when(
        ruleRepository.getRules(eq(1), any(DroolsBusinessRuleGroupName.CHANGE_CRITERIA.getClass())))
            .thenReturn(Arrays.asList(rulesEntity));
    List<ProcessorRuleModel> changeCriteriaRules = ruleService.getChangeCriteriaRules(1);
    assertNotNull(changeCriteriaRules);
  }

  @Test
  public void getSelectionCriteriaRules_test() {
    DroolsBusinessRulesDecisionTableEntity rulesEntity = new DroolsBusinessRulesDecisionTableEntity();
    rulesEntity.setCurrent(true);
    rulesEntity.setDroolsBusinessRuleDrlFileContent("droolsBusinessRuleDrlFileContent");
    rulesEntity.setDroolsBusinessRuleId(1);
    rulesEntity.setDroolsBusinessRuleVersion(1);
    when(ruleRepository.getRules(eq(1),
        any(DroolsBusinessRuleGroupName.SELECTION_CRITERIA.getClass())))
            .thenReturn(Arrays.asList(rulesEntity));
    List<ProcessorRuleModel> selectionCriteriaRules = ruleService.getSelectionCriteriaRules(1);
    assertNotNull(selectionCriteriaRules);
  }

}
