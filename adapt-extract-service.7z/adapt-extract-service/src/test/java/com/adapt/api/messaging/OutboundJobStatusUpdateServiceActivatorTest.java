package com.adapt.api.messaging;

import static org.junit.Assert.assertNotNull;

import com.adapt.api.config.OutboundConstant;
import com.adapt.config.Constant;
import com.adapt.file.InvalidMessage;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.service.JobService;
import com.adapt.file.service.JobServiceImpl;
import com.adapt.util.MockDataUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { OutboundJobStatusUpdateServiceActivator.class, JobServiceImpl.class })
public class OutboundJobStatusUpdateServiceActivatorTest {

  @Autowired
  private OutboundJobStatusUpdateServiceActivator outboundJobStatusUpdateServiceActivator;

  @MockBean
  private JobService jobService;

  @Test
  public void testUpdateJobStatus() {
    int extractionCount = 123;
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");

    builder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER, MockDataUtil.buildJobModelMultiEmployer());
    builder.setHeader(Constant.FILE_RECORD_COUNT, extractionCount);
    Message<?> updateJobStatus = outboundJobStatusUpdateServiceActivator.updateJobStatus(builder.build());
    assertNotNull(updateJobStatus);

  }

  @Test(expected = InvalidMessage.class)
  public void testUpdateJobStatus_jobid_null() {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload("");

    JobModelMultiEmployer jobModelMultiEmployer = MockDataUtil.buildJobModelMultiEmployer();
    jobModelMultiEmployer.setJobId(null);
    builder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER, jobModelMultiEmployer);
    Message<?> updateJobStatus = outboundJobStatusUpdateServiceActivator.updateJobStatus(builder.build());
    assertNotNull(updateJobStatus);

  }
}
