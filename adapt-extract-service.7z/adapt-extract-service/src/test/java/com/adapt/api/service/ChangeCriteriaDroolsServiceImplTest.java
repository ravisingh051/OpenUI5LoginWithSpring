package com.adapt.api.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import com.alight.adapt.dataextraction.coretransaction.v1.models.CoreTransactionDataset;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { ChangeCriteriaDroolsServiceImpl.class })
public class ChangeCriteriaDroolsServiceImplTest {

  @Autowired
  private ChangeCriteriaDroolsServiceImpl changeCriteriaDroolsServiceImpl;

  @MockBean(name = "droolsCacheServiceImpl")
  private DroolsService droolsService;

  @Mock
  private KieContainer kieContainer;

  @Mock
  private KieSession kieSession;

  @Test
  public void loadContainerTest() {
    changeCriteriaDroolsServiceImpl.loadContainer(1);
    assertNotNull(changeCriteriaDroolsServiceImpl);
  }

  @Test
  public void executeRulesTest() {
    KieSessionConfig kieSessionConfig = new ChangeCriteriaKieSessionConfig(
        new CoreTransactionDataset());
    when(droolsService.prepareChangeCriteriaRuleContainer(1)).thenReturn(kieContainer);
    when(kieContainer.newKieSession()).thenReturn(kieSession);
    Integer executeRules = changeCriteriaDroolsServiceImpl.executeRules(1, kieSessionConfig);
    assertNotNull(executeRules);
  }

}
