package com.adapt.api;

import static org.junit.Assert.assertEquals;

import com.adapt.config.EndPointConfigurationHelper;
import com.adapt.file.entity.MessageType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { EndPointConfigurationHelper.class }, properties = {
    "coreTransactionDatasets.url=http://127.0.0.1:8080/target/outboundtarget" })
public class EndPointConfigurationHelperTest {

  @Test
  public void test_getEndPointUrl() {
    String endPointUrl = EndPointConfigurationHelper.getEndPointUrl(MessageType.OUTBOUND_CORE_T);
    assertEquals("http://127.0.0.1:8080/target/outboundtarget", endPointUrl);
  }

}
