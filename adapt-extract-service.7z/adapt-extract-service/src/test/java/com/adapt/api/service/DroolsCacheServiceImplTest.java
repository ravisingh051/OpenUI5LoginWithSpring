package com.adapt.api.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DroolsCacheServiceImpl.class })
public class DroolsCacheServiceImplTest {

  @Autowired
  private DroolsCacheServiceImpl droolsCacheServiceImpl;

  @MockBean
  private DroolsServiceImpl droolsServiceImpl;

  @Test
  public void prepareBusinessCriteriaRuleContainerTest() {
    KieContainer prepareBusinessCriteriaRuleContainer = droolsCacheServiceImpl
        .prepareBusinessCriteriaRuleContainer(1);
    assertNull(prepareBusinessCriteriaRuleContainer);
  }

  @Test
  public void removeBusinessCriteriaRuleContainerTest() {
    droolsCacheServiceImpl.removeBusinessCriteriaRuleContainer();
    assertNotNull(droolsCacheServiceImpl);
  }

  @Test
  public void prepareChangeCriteriaRuleContainerTest() {
    KieContainer prepareChangeCriteriaRuleContainer = droolsCacheServiceImpl
        .prepareChangeCriteriaRuleContainer(1);
    assertNull(prepareChangeCriteriaRuleContainer);
  }

  @Test
  public void removeChangeCriteriaRuleContainerTest() {
    droolsCacheServiceImpl.removeChangeCriteriaRuleContainer();
    assertNotNull(droolsCacheServiceImpl);
  }

  @Test
  public void prepareSelectionCriteriaRulesContainerTest() {
    KieContainer prepareSelectionCriteriaRulesContainer = droolsCacheServiceImpl
        .prepareSelectionCriteriaRulesContainer(1);
    assertNull(prepareSelectionCriteriaRulesContainer);
  }

  @Test
  public void removeSelectionCriteriaRulesContainerTest() {
    droolsCacheServiceImpl.removeSelectionCriteriaRulesContainer();
    assertNotNull(droolsCacheServiceImpl);
  }

}
