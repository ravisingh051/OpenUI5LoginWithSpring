package com.adapt.exception;

import org.junit.Test;

public class NullResponseExceptionTest {

  @Test(expected = NullResponseException.class)
  public void testConfigurationException() {
    throw new NullResponseException("Null Response Exception Occurred");
  }

  @Test(expected = NullResponseException.class)
  public void testConfigurationException_WithThrowable() {
    throw new NullResponseException("Null Response Exception Occurred", new RuntimeException());
  }

}