package com.adapt.exception;

import com.adapt.exception.JobModelConvesionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class JobModelConversionExceptionTest {

  @Test(expected = JobModelConvesionException.class)
  public void testConfigurationException() {
    throw new JobModelConvesionException("Job Model Convesion Exception Occurred");
  }

  @Test(expected = JobModelConvesionException.class)
  public void testConfigurationException_WithThrowable() {
    throw new JobModelConvesionException("Job Model Convesion Exception", new RuntimeException());
  }

}
