package com.adapt.exception;

import com.adapt.exception.SecondaryDataException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SecondaryDataExceptionTest {

  @Test(expected = SecondaryDataException.class)
  public void testConfigurationException() {
    throw new SecondaryDataException("Secondary Data Exception Occurred");
  }

  @Test(expected = SecondaryDataException.class)
  public void testConfigurationException_WithThrowable() {
    throw new SecondaryDataException("Secondary Data Exception", new RuntimeException());
  }

}
