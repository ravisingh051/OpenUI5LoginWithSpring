package com.adapt.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AttributeMapToDatasetTransformerExceptionTest {

  @Test(expected = AttributeMapToDatasetTransformerException.class)
  public void testConfigurationException() {
    throw new AttributeMapToDatasetTransformerException(
        "Attribute Map To Dataset Transformer Exception");
  }

  @Test(expected = AttributeMapToDatasetTransformerException.class)
  public void testConfigurationException_WithThrowable() {
    throw new AttributeMapToDatasetTransformerException(
        "Attribute Map To Dataset Transformer Exception", new RuntimeException());
  }

  @Test(expected = AttributeMapToDatasetTransformerException.class)
  public void testConfigurationException_WithOnlyThrowable() {
    throw new AttributeMapToDatasetTransformerException(new RuntimeException());
  }

  @Test(expected = AttributeMapToDatasetTransformerException.class)
  public void testConfigurationException_WithOnlyThrowable_subscription() {
    throw new AttributeMapToDatasetTransformerException(
        "Attribute Map To Dataset Transformer Exception", new RuntimeException(), false, false);
  }
}
