package com.adapt.exception;

import org.junit.Test;

public class ConfigurationExceptionTest {

  @Test(expected = ConfigurationException.class)
  public void testConfigurationException() {

    throw new ConfigurationException("Configuration Exception Occurred");
  }

}
