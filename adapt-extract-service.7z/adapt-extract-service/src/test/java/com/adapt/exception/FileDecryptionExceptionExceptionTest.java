package com.adapt.exception;

import com.adapt.exception.FileDecryptionException;
import org.junit.Test;

public class FileDecryptionExceptionExceptionTest {

  @Test(expected = FileDecryptionException.class)
  public void testConfigurationException() {
    throw new FileDecryptionException("File Decryption Occurred");
  }

  @Test(expected = FileDecryptionException.class)
  public void testConfigurationException_WithThrowable() {
    throw new FileDecryptionException("File Decryption Occurred", new RuntimeException());
  }

}
