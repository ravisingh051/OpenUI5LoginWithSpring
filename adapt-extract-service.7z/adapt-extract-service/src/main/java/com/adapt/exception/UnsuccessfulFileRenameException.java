package com.adapt.exception;

public class UnsuccessfulFileRenameException extends RuntimeException {

  private static final long serialVersionUID = -7675434094425846795L;

  public UnsuccessfulFileRenameException(String message) {
    super(message);
  }

}
