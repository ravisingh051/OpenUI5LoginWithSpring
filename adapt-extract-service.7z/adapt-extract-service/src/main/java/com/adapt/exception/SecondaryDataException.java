package com.adapt.exception;

public class SecondaryDataException extends RuntimeException {

  private static final long serialVersionUID = -3573320321630189358L;

  public SecondaryDataException(String message) {
    super(message);
  }

  public SecondaryDataException(String message, Throwable cause) {
    super(message, cause);
  }

}
