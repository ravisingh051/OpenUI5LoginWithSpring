package com.adapt.exception;

public class JobModelConvesionException extends RuntimeException {

  private static final long serialVersionUID = -8572125908609907598L;

  public JobModelConvesionException(String message) {
    super(message);
  }

  public JobModelConvesionException(String message, Throwable cause) {
    super(message, cause);
  }

}
