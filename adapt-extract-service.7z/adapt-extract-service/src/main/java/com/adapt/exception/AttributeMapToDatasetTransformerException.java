package com.adapt.exception;

public class AttributeMapToDatasetTransformerException extends RuntimeException {

  private static final long serialVersionUID = 2467561278912975559L;

  public AttributeMapToDatasetTransformerException(String message) {
    super(message);
  }

  public AttributeMapToDatasetTransformerException(Throwable cause) {
    super(cause);
  }

  public AttributeMapToDatasetTransformerException(String message, Throwable cause) {
    super(message, cause);
  }

  public AttributeMapToDatasetTransformerException(String message, Throwable cause,
      boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}