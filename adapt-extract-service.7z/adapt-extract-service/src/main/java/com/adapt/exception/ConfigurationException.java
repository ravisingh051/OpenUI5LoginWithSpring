package com.adapt.exception;

public class ConfigurationException extends RuntimeException {

  private static final long serialVersionUID = 7751167328087544055L;

  public ConfigurationException(String message) {
    super(message);
  }
}
