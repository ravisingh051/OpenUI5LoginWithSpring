package com.adapt.exception;

public class FileDecryptionException extends RuntimeException {

  private static final long serialVersionUID = -8572125908609907598L;

  public FileDecryptionException(String message) {
    super(message);
  }

  public FileDecryptionException(String message, Throwable cause) {
    super(message, cause);
  }

}
