package com.adapt.exception;

public class NullResponseException extends RuntimeException {

  private static final long serialVersionUID = -7469748354832312181L;

  public NullResponseException(String message) {
    super(message);
  }

  public NullResponseException(String message, Throwable cause) {
    super(message, cause);
  }

}