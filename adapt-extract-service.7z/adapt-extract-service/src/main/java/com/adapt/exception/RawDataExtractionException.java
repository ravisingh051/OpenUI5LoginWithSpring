package com.adapt.exception;

public class RawDataExtractionException extends RuntimeException{

  private static final long serialVersionUID = -8200494052683032952L;
  
  public RawDataExtractionException(String message) {
    super(message);
  }

  public RawDataExtractionException(String message, Throwable cause) {
    super(message, cause);
  }

}
