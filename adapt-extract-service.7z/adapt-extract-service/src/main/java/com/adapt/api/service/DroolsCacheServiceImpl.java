package com.adapt.api.service;

import org.kie.api.runtime.KieContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service("droolsCacheServiceImpl")
public class DroolsCacheServiceImpl implements DroolsService {
  private static final Logger LOGGER = LoggerFactory.getLogger(DroolsCacheServiceImpl.class);

  @Autowired
  private DroolsServiceImpl droolsServiceImpl;

  @Override
  @Cacheable(cacheNames = "businessCriteriaRuleKieContainer", sync = true)
  public KieContainer prepareBusinessCriteriaRuleContainer(Integer fileIdentifier) {
    LOGGER.debug("prepareBusinessCriteriaRuleContainer cache method call");
    return droolsServiceImpl.prepareBusinessCriteriaRuleContainer(fileIdentifier);
  }

  @Override
  @CacheEvict(value = "businessCriteriaRuleKieContainer", allEntries = true)
  public void removeBusinessCriteriaRuleContainer() {
    LOGGER.debug("businessCriteriaRuleKieContainer cache method call");
    droolsServiceImpl.removeBusinessCriteriaRuleContainer();
  }

  @Override
  @Cacheable(cacheNames = "changeCriteriaRuleContainer", sync = true)
  public KieContainer prepareChangeCriteriaRuleContainer(Integer fileIdentifier) {
    LOGGER.debug("changeCriteriaRuleContainer cache method call");
    return droolsServiceImpl.prepareChangeCriteriaRuleContainer(fileIdentifier);
  }

  @Override
  @CacheEvict(value = "changeCriteriaRuleContainer", allEntries = true)
  public void removeChangeCriteriaRuleContainer() {
    LOGGER.debug("changeCriteriaRuleContainer cache method call");
    droolsServiceImpl.removeChangeCriteriaRuleContainer();
  }

  @Override
  @Cacheable(cacheNames = "selectionCriteriaRulesContainer", sync = true)
  public KieContainer prepareSelectionCriteriaRulesContainer(Integer fileIdentifier) {
    LOGGER.debug("selectionCriteriaRulesContainer cache method call");
    return droolsServiceImpl.prepareSelectionCriteriaRulesContainer(fileIdentifier);
  }

  @Override
  @CacheEvict(value = "selectionCriteriaRulesContainer", allEntries = true)
  public void removeSelectionCriteriaRulesContainer() {
    LOGGER.debug("selectionCriteriaRulesContainer cache method call");
    droolsServiceImpl.removeSelectionCriteriaRulesContainer();
  }

}
