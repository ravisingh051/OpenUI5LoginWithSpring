package com.adapt.api.messaging;

import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.service.JobService;
import java.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("jobFilePriorityEntityToJobModelMultiEmployerTransformer")
public class JobFilePriorityEntityToJobModelMultiEmployerTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(JobFilePriorityEntityToJobModelMultiEmployerTransformer.class);

  @Autowired
  private JobService jobService;

  @Override
  protected Object doTransform(Message<?> message) throws Exception {
    LOGGER.debug("start doTransform");
    JobPriorityGetPayload jobPriorityGetPayload = (JobPriorityGetPayload) message.getPayload();
    JobModelMultiEmployer jobFileWithMultiEmployerEntity = jobService
        .jobFilePriorityEntityToJobModelMultiEmployerTransformer(LocalDate.now(),
            jobPriorityGetPayload.getJobFilePriorityEntity());
    LOGGER.debug("end doTransform jobFileWithMultiEmployerEntity {}",
        jobFileWithMultiEmployerEntity);
    return jobFileWithMultiEmployerEntity;
  }

}
