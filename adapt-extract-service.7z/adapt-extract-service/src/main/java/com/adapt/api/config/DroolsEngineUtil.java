package com.adapt.api.config;

import com.adapt.file.entity.ProcessorRuleModel;
import java.util.List;
import org.drools.compiler.kie.builder.impl.InternalKieModule;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.builder.ReleaseId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DroolsEngineUtil {
  private static final Logger LOGGER = LoggerFactory.getLogger(DroolsEngineUtil.class);

  private DroolsEngineUtil() {
  }

  /**
   * Method to create kie module using rule model.
   * 
   * @param releaseId
   *          the release id for kie file system
   * @param ruleModels
   *          the rule models for creating kie builder
   * @return
   */
  public static byte[] createKieModule(ReleaseId releaseId, List<ProcessorRuleModel> ruleModels) {
    KieServices kieServices = KieServices.Factory.get();
    KieFileSystem kfs = kieServices.newKieFileSystem();
    kfs.generateAndWritePomXML(releaseId);
    ruleModels.forEach(ruleModel -> kfs.write(
        "src/main/resources/" + ruleModel.getRuleId().hashCode() + ".drl", ruleModel.getRule()));
    KieBuilder kb = kieServices.newKieBuilder(kfs).buildAll();
    if (kb.getResults().hasMessages(Message.Level.ERROR)) {
      for (Message result : kb.getResults().getMessages()) {
        LOGGER.error(result.getText());
      }
      return new byte[0];
    }
    InternalKieModule kieModule = (InternalKieModule) kieServices.getRepository()
        .getKieModule(releaseId);
    return kieModule.getBytes();
  }
}
