package com.adapt.api.service;

import org.kie.api.runtime.KieSession;

public abstract class KieSessionConfig {

  private KieSession kieSession;

  /**
   * prepare kieSession, like insert knowledge.
   */
  public abstract void config();

  public void addKnowledge(Object object) {
    kieSession.insert(object);
  }

  public void addAgendaGroup(String groupName) {
    kieSession.getAgenda().getAgendaGroup(groupName).setFocus();
  }

  public void setKieSession(KieSession kieSession) {
    this.kieSession = kieSession;
  }

}
