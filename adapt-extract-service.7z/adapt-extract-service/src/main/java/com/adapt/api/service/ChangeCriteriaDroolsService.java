package com.adapt.api.service;

public interface ChangeCriteriaDroolsService {

  void loadContainer(Integer fileIdentifier);

  Integer executeRules(Integer fileIdentifier, KieSessionConfig kieSessionConfig);

}
