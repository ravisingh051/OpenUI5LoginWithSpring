package com.adapt.api.messaging;

import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.config.Constant;
import com.alight.adapt.datasets.AbstractDataset;
import com.alight.adapt.datasets.NoContentDataset;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("noContentDatasetConfig")
public class NoContentDatasetConfig {
  private static final Logger LOGGER = LoggerFactory.getLogger(NoContentDatasetConfig.class);

  /**
   * Configure no content dataset object to continue file flow in case of zero records from
   * extraction.
   *
   * @param message
   *          the message
   * @return the list
   */
  public Message<List<TransactionExtractionDetailsPaginated>> config(
      Message<List<TransactionExtractionDetailsPaginated>> message) {
    List<TransactionExtractionDetailsPaginated> transactionExtractionDetailsPaginatedList = message
        .getPayload();

    TransactionExtractionDetailsPaginated transactionExtractionDetailsPaginated =
        new TransactionExtractionDetailsPaginated();
    transactionExtractionDetailsPaginated.setChunkNumber(1l);
    transactionExtractionDetailsPaginated.setChunkSize(1l);
    List<AbstractDataset> dataset = new ArrayList<>();
    dataset.add(new NoContentDataset());
    transactionExtractionDetailsPaginated.setAbstractDatasets(dataset);
    transactionExtractionDetailsPaginatedList.add(transactionExtractionDetailsPaginated);

    MessageBuilder<List<TransactionExtractionDetailsPaginated>> builder =
        new DefaultMessageBuilderFactory().withPayload(transactionExtractionDetailsPaginatedList);
    builder.copyHeaders(message.getHeaders());
    builder.setHeader(Constant.IS_NO_CONTENT_DATASET_HEADER, true);
    return builder.build();

  }

}
