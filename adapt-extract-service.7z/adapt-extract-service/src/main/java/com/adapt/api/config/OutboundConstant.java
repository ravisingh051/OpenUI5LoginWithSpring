package com.adapt.api.config;

public final class OutboundConstant {

  private OutboundConstant() {
  }

  public static final String JOB_MODEL_MULTI_EMPLOYER_HEADER = "jobModelMultiEmployer";
  public static final String CORE_TRANSACTION_EXTRACTION_DETAILS_HEADER = "coreTransactionExtractionDetails";
  public static final String CORE_TRANSACTION_EXTRACTION_DETAILS_PAGINATED_HEADER = "coreTransactionExtractionDetailsPaginated";
}
