package com.adapt.api.service;

public class SelectionCriteriaKieSessionConfig extends KieSessionConfig {
  private final Object payLoad;

  public SelectionCriteriaKieSessionConfig(Object payLoad) {
    this.payLoad = payLoad;
  }

  @Override
  public void config() {
    addKnowledge(payLoad);
  }
}
