package com.adapt.api.service;

import com.adapt.file.entity.ProcessorRuleModel;
import java.util.List;

public interface RuleService {
  List<ProcessorRuleModel> getBusinessCriteriaRules(Integer fileIdentifier);

  List<ProcessorRuleModel> getChangeCriteriaRules(Integer fileIdentifier);

  List<ProcessorRuleModel> getSelectionCriteriaRules(Integer fileIdentifier);

}
