package com.adapt.api.messaging;

import com.adapt.api.config.OutboundConstant;
import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.config.Constant;
import com.adapt.file.AdaptHeaderBuilderDirector;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.alight.adapt.header.AdaptHeader;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("coreTransactionExtractionDetailsCountRequestConfig")
public class CoreTransactionExtractionDetailsCountRequestConfig {

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public CoreTransactionExtractionDetailsCountRequestConfig() {
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  /**
   * Count request configuration.
   *
   * @param message
   *          the message
   * @return the message
   * @throws Exception
   *           the exception
   */
  public Message<TransactionExtractionDetails> countRequestConfig(
      Message<TransactionExtractionDetails> message) throws Exception {
    Assert.notNull(message, "Message should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "Message headers should not be null");
    JobModelMultiEmployer jobModelMultiEmployer = headers
        .get(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER, JobModelMultiEmployer.class);
    TransactionExtractionDetails transactionExtractionDetails = message.getPayload();
    Assert.notNull(jobModelMultiEmployer, "jobModelMultiEmployer should not be null");
    AdaptHeader adaptHeader = AdaptHeaderBuilderDirector.constructAdaptHeaderForExtractionCountApi(
        jobModelMultiEmployer, transactionExtractionDetails);
    MessageBuilder<TransactionExtractionDetails> builder = new DefaultMessageBuilderFactory()
        .withPayload(message.getPayload()).copyHeaders(message.getHeaders());
    builder.setHeader(Constant.ADAPT_HEADER, jsonObjectMapper.toJson(adaptHeader));
    return builder.build();
  }

}
