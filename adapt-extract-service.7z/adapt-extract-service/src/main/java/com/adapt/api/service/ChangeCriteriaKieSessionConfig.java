package com.adapt.api.service;

public class ChangeCriteriaKieSessionConfig extends KieSessionConfig {
  private final Object payLoad;

  public ChangeCriteriaKieSessionConfig(Object payLoad) {
    this.payLoad = payLoad;
  }

  @Override
  public void config() {
    addKnowledge(payLoad);
  }
}
