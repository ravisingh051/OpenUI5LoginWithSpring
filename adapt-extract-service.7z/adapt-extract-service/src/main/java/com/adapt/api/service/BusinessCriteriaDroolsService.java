package com.adapt.api.service;

public interface BusinessCriteriaDroolsService {

  void loadContainer(Integer fileIdentifier);

  Integer executeRules(Integer fileIdentifier, KieSessionConfig kieSessionConfig);

}
