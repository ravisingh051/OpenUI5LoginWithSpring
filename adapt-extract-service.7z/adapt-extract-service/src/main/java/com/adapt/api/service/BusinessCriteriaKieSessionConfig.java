package com.adapt.api.service;

public class BusinessCriteriaKieSessionConfig extends KieSessionConfig {
  private final Object payLoad;

  public BusinessCriteriaKieSessionConfig(Object payLoad) {
    this.payLoad = payLoad;
  }

  @Override
  public void config() {
    addKnowledge(payLoad);
  }
}
