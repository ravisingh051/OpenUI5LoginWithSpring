package com.adapt.api.config.domain;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TransactionExtractionDetails implements Serializable {
  private static final long serialVersionUID = -2455107387707943180L;

  private Integer sourceEmployerId;
  private Integer planYear;
  private String planSubtypes;
  private Long extractionCount;
  private String testCfg;
  private String systemDate;
  private String planYearAdditiveFactor;
  private String lookBackPeriod;
  private String lookAheadPeriod;

}
