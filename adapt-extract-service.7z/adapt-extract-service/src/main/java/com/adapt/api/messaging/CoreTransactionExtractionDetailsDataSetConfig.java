package com.adapt.api.messaging;

import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.config.Constant;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("coreTransactionExtractionDetailsDataSetConfig")
public class CoreTransactionExtractionDetailsDataSetConfig {
  private static final Logger LOGGER = LoggerFactory.getLogger(
      CoreTransactionExtractionDetailsDataSetConfig.class);

  @Value("${dataset.processing.outbound.extraction.batchsize}")
  private int batchSize = 100;

  /**
   * Configure paginated object for getting data from extraction.
   *
   * @param message
   *          the message
   * @return the list
   */
  public Message<List<TransactionExtractionDetailsPaginated>> config(
      Message<List<TransactionExtractionDetails>> message) {
    List<TransactionExtractionDetails> transactionExtractionDetailsList = message.getPayload();
    long extractionCount = 0;
    List<TransactionExtractionDetailsPaginated> tranExtractDetailsPaginatedList = new ArrayList<>();
    for (TransactionExtractionDetails transactionExtractionDetails : transactionExtractionDetailsList) {
      extractionCount = extractionCount + transactionExtractionDetails.getExtractionCount();
      long totalPage = calculateTotalPage(transactionExtractionDetails.getExtractionCount(),
          batchSize);
      LOGGER.debug("employer id {}, totalNumberOfRecords {}, totalPage {}, batchSize{}",
          transactionExtractionDetails.getSourceEmployerId(), transactionExtractionDetails
              .getExtractionCount(), totalPage, batchSize);
      for (long pageNumber = 0; pageNumber < totalPage; pageNumber++) {
        TransactionExtractionDetailsPaginated transactionExtractionDetailsPaginated = new TransactionExtractionDetailsPaginated();
        transactionExtractionDetailsPaginated
            .setPlanSubtypes(transactionExtractionDetails.getPlanSubtypes());
        transactionExtractionDetailsPaginated
            .setPlanYear(transactionExtractionDetails.getPlanYear());
        transactionExtractionDetailsPaginated
            .setSourceEmployerId(transactionExtractionDetails.getSourceEmployerId());
        transactionExtractionDetailsPaginated.setChunkNumber(pageNumber * batchSize);
        transactionExtractionDetailsPaginated.setChunkSize((long) batchSize);
        transactionExtractionDetailsPaginated.setExtractionCount(transactionExtractionDetails
            .getExtractionCount());
        transactionExtractionDetailsPaginated.setTestCfg(transactionExtractionDetails.getTestCfg());
        tranExtractDetailsPaginatedList.add(transactionExtractionDetailsPaginated);
      }
    }
    
    MessageBuilder<List<TransactionExtractionDetailsPaginated>> builder = new DefaultMessageBuilderFactory()
        .withPayload(tranExtractDetailsPaginatedList);
    builder.copyHeaders(message.getHeaders());
    builder.setHeader(Constant.FILE_RECORD_COUNT, Math.toIntExact(extractionCount));
    
    return builder.build();
  }

  private long calculateTotalPage(long totalCount, long batchSize) {
    long totalPage = totalCount / batchSize;
    totalPage = totalPage + ((totalCount % batchSize) != 0 ? 1 : 0);
    return totalPage;
  }
}
