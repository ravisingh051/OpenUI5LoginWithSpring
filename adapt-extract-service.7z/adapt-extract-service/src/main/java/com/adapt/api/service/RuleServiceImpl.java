package com.adapt.api.service;

import com.adapt.file.entity.DroolsBusinessRulesDecisionTableEntity;
import com.adapt.file.entity.ProcessorRuleModel;
import com.adapt.repository.DroolsBusinessRuleGroupName;
import com.adapt.repository.RuleRepository;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ruleService")
public class RuleServiceImpl implements RuleService {

  private static final Logger LOGGER = LoggerFactory.getLogger(RuleServiceImpl.class);

  @Autowired
  private RuleRepository ruleRepository;

  @Override
  public List<ProcessorRuleModel> getBusinessCriteriaRules(Integer fileIdentifier) {
    LOGGER.debug("businessCriteriaRules fileIdentifier = {}", fileIdentifier);
    List<DroolsBusinessRulesDecisionTableEntity> ruleEntityList = ruleRepository
        .getRules(fileIdentifier, DroolsBusinessRuleGroupName.BUSINESS_CRITERIA);
    List<ProcessorRuleModel> ruleModelList = transform(ruleEntityList);
    LOGGER.debug("businessCriteriaRules fileIdentifier = {}, number of rules = {}", fileIdentifier,
        ruleModelList.size());
    return ruleModelList;
  }

  @Override
  public List<ProcessorRuleModel> getChangeCriteriaRules(Integer fileIdentifier) {
    LOGGER.debug("ChangeCriteriaRules fileIdentifier = {}", fileIdentifier);
    List<DroolsBusinessRulesDecisionTableEntity> ruleEntityList = ruleRepository
        .getRules(fileIdentifier, DroolsBusinessRuleGroupName.CHANGE_CRITERIA);
    List<ProcessorRuleModel> ruleModelList = transform(ruleEntityList);
    LOGGER.debug("ChangeCriteriaRules fileIdentifier = {}, number of rules = {}", fileIdentifier,
        ruleModelList.size());
    return ruleModelList;
  }

  @Override
  public List<ProcessorRuleModel> getSelectionCriteriaRules(Integer fileIdentifier) {
    LOGGER.debug("selectionCriteriaRules fileIdentifier = {}", fileIdentifier);
    List<DroolsBusinessRulesDecisionTableEntity> ruleEntityList = ruleRepository
        .getRules(fileIdentifier, DroolsBusinessRuleGroupName.SELECTION_CRITERIA);
    List<ProcessorRuleModel> ruleModelList = transform(ruleEntityList);
    LOGGER.debug("selectionCriteriaRules fileIdentifier = {}, number of rules = {}", fileIdentifier,
        ruleModelList.size());
    return ruleModelList;
  }

  private List<ProcessorRuleModel> transform(
      List<DroolsBusinessRulesDecisionTableEntity> droolsBusinessRulesDecisionTableEntityList) {
    List<ProcessorRuleModel> ruleModelList = new ArrayList<>(
        droolsBusinessRulesDecisionTableEntityList.size());
    droolsBusinessRulesDecisionTableEntityList.forEach(droolsBusinessRulesDecisionTableEntity -> {
      ProcessorRuleModel ruleModel = new ProcessorRuleModel();
      ruleModel.setRuleId(droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleId());
      ruleModel
          .setRuleVersion(droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleVersion());
      ruleModel
          .setRule(droolsBusinessRulesDecisionTableEntity.getDroolsBusinessRuleDrlFileContent());
      ruleModel.setCurrent(droolsBusinessRulesDecisionTableEntity.getCurrent());
      ruleModel.setRuleExecutionSequence(
          droolsBusinessRulesDecisionTableEntity.getRuleExecutionSequence());
      ruleModelList.add(ruleModel);
    });
    return ruleModelList;
  }

}
