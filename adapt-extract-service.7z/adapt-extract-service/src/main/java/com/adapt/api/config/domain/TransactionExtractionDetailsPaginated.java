package com.adapt.api.config.domain;

import com.alight.adapt.datasets.AbstractDataset;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TransactionExtractionDetailsPaginated extends TransactionExtractionDetails
    implements Serializable {

  private static final long serialVersionUID = -1910812649056600709L;
  private Long chunkSize;
  private Long chunkNumber;
  private List<AbstractDataset> abstractDatasets;

}
