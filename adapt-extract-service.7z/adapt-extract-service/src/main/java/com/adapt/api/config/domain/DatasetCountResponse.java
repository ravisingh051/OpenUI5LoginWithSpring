package com.adapt.api.config.domain;

import java.io.Serializable;

public class DatasetCountResponse implements Serializable {

  /**
   * Default serial version uid.
   */
  private static final long serialVersionUID = 5738273325323267979L;

  private Integer count;

  public DatasetCountResponse() {
    super();
  }

  public Integer getCount() {
    return count;
  }

  public void setCount(Integer count) {
    this.count = count;
  }

}
