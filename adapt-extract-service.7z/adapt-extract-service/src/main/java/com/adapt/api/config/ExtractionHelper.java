package com.adapt.api.config;

import com.adapt.file.entity.JobModelMultiEmployer;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public final class ExtractionHelper {

  public static final String EMPLOYER_IDS = "employerIds";
  public static final String PLAN_SUBTYPES = "planSubtypes";
  public static final String PLAN_YEAR = "planYear";
  public static final String SYSTEM_DATE = "systemDate";
  public static final String PLAN_YEAR_ADDITIVE_FACTOR = "planYearAdditiveFactor";
  public static final String LOOK_BACK_PERIOD = "lookBackPeriod";
  public static final String LOOK_AHEAD_PERIOD = "lookAheadPeriod";
  private static final String COMMA_WITH_QUOTE = Pattern.quote(",");

  private ExtractionHelper() {
  }

  public static void setEmployerIdsList(String employerIds,
      JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(EMPLOYER_IDS,
        Arrays.asList(employerIds.split(COMMA_WITH_QUOTE)));
  }

  public static void setPlanSubtypesList(String planSubtypes,
      JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(PLAN_SUBTYPES,
        Arrays.asList(planSubtypes.split(COMMA_WITH_QUOTE)));
  }

  public static void setPlanYear(Integer planYear, JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(PLAN_YEAR, planYear);
  }

  public static Integer getPlanYear(JobModelMultiEmployer jobModelMultiEmployer) {
    return (Integer) jobModelMultiEmployer.getExtractionParameters().get(PLAN_YEAR);
  }

  public static List<String> getPlanSubtypes(JobModelMultiEmployer jobModelMultiEmployer) {
    return (List<String>) jobModelMultiEmployer.getExtractionParameters().get(PLAN_SUBTYPES);
  }

  public static List<String> getEmployerIdsList(JobModelMultiEmployer jobModelMultiEmployer) {
    return (List<String>) jobModelMultiEmployer.getExtractionParameters().get(EMPLOYER_IDS);
  }

  public static String getSystemDate(JobModelMultiEmployer jobModelMultiEmployer) {
    return (String) jobModelMultiEmployer.getExtractionParameters().get(SYSTEM_DATE);
  }

  public static String getPlanYearAdditiveFactor(JobModelMultiEmployer jobModelMultiEmployer) {
    return (String) jobModelMultiEmployer.getExtractionParameters().get(PLAN_YEAR_ADDITIVE_FACTOR);
  }

  public static String getLookBackPeriod(JobModelMultiEmployer jobModelMultiEmployer) {
    return (String) jobModelMultiEmployer.getExtractionParameters().get(LOOK_BACK_PERIOD);
  }

  public static String getLookAheadPeriod(JobModelMultiEmployer jobModelMultiEmployer) {
    return (String) jobModelMultiEmployer.getExtractionParameters().get(LOOK_AHEAD_PERIOD);
  }

  public static void setSystemDate(String systemDate, JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(SYSTEM_DATE, systemDate);
  }

  public static void setPlanYearAdditiveFactor(String planYearAdditiveFactor,
      JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(PLAN_YEAR_ADDITIVE_FACTOR,
        planYearAdditiveFactor);
  }

  public static void setLookBackPeriod(String lookBackPeriod,
      JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(LOOK_BACK_PERIOD, lookBackPeriod);
  }

  public static void setLookAheadPeriod(String lookAheadPeriod,
      JobModelMultiEmployer jobModelMultiEmployer) {
    jobModelMultiEmployer.getExtractionParameters().put(LOOK_AHEAD_PERIOD, lookAheadPeriod);
  }

}
