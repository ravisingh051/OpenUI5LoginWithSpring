package com.adapt.api.service;

import org.kie.api.event.rule.DebugAgendaEventListener;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("selectionCriteriaDroolsService")
public class SelectionCriteriaDroolsServiceImpl implements SelectionCriteriaDroolsService {
  private static final Logger LOGGER = LoggerFactory
      .getLogger(SelectionCriteriaDroolsServiceImpl.class);

  @Autowired
  @Qualifier("droolsCacheServiceImpl")
  private DroolsService droolsService;

  /**
   * Load container.
   *
   * @param fileIdentifier
   *          the file identifier
   */
  @Override
  public void loadContainer(Integer fileIdentifier) {
    droolsService.prepareChangeCriteriaRuleContainer(fileIdentifier);
  }

  /**
   * Execute rules.
   *
   * @param fileIdentifier
   *          the file identifier
   * @param kieSessionConfig
   *          the kie session config
   * @return the integer
   */
  @Override
  public Integer executeRules(Integer fileIdentifier, KieSessionConfig kieSessionConfig) {
    KieSession kieSession = getKieSession(fileIdentifier);
    kieSessionConfig.setKieSession(kieSession);
    kieSessionConfig.config();
    int numberOfRules = kieSession.fireAllRules();
    LOGGER.debug("the number of rules fired: {} ", numberOfRules);
    kieSession.dispose();
    return numberOfRules;
  }

  private KieSession getKieSession(Integer fileIdentifier) {
    KieContainer container = droolsService.prepareSelectionCriteriaRulesContainer(fileIdentifier);
    KieSession kieSession = container.newKieSession();
    if (LOGGER.isDebugEnabled()) {
      DebugAgendaEventListener debugAgendaEventListener = new DebugAgendaEventListener();
      kieSession.addEventListener(debugAgendaEventListener);
    }
    return kieSession;
  }

}
