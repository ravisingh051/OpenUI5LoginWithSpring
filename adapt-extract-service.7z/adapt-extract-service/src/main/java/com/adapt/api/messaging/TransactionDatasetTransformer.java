package com.adapt.api.messaging;

import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.config.Constant;
import com.alight.adapt.datasets.AbstractDataset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("transactionDatasetTransformer")
public class TransactionDatasetTransformer extends AbstractTransformer {
  private static final Logger LOGGER = LoggerFactory.getLogger(TransactionDatasetTransformer.class);

  @Override
  protected Object doTransform(Message<?> message) throws Exception {
    Object payload = message.getPayload();
    List<AbstractDataset> transformList = new ArrayList<>();
    if (payload instanceof Collection) {
      Collection<? extends TransactionExtractionDetailsPaginated> payloadCollection = (Collection<? extends TransactionExtractionDetailsPaginated>) payload;
      for (TransactionExtractionDetailsPaginated transactionExtractionDetailsPaginated : payloadCollection) {
        transformList.addAll(transactionExtractionDetailsPaginated.getAbstractDatasets());
      }
    } else {
      LOGGER.warn("no collection transactionDataset found !!!");
    }
    LOGGER.debug("number of transactionDataset found for all employer: {}",
        transformList.size());

    Assert.notNull(message, "Message should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "headers should not be null");
    if (headers.get(Constant.FILE_RECORD_COUNT) != null) {
      Integer totalRecordsInFile = headers.get(Constant.FILE_RECORD_COUNT, Integer.class);
      if (totalRecordsInFile !=null && totalRecordsInFile > transformList.size()) {
        LOGGER.error(
            "extraction count {} is more than number of transactionDataset found for all employer: {} !!!",
            totalRecordsInFile, transformList.size());
      }
    }
    return transformList;
  }

}
