package com.adapt.api.messaging;

import com.adapt.api.config.OutboundConstant;
import com.adapt.config.Constant;
import com.adapt.file.AdaptHeaderBuilderDirector;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.alight.adapt.header.AdaptHeader;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("outboundAdaptHeaderBuilder")
public class OutboundAdaptHeaderBuilder {
  private static final Logger LOGGER = LoggerFactory.getLogger(OutboundAdaptHeaderBuilder.class);

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public OutboundAdaptHeaderBuilder() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  /**
   * Builds the adaptHeader and covert to json.
   *
   * @param message
   *          the message
   * @return the string
   * @throws Exception
   *           the exception
   */
  public String build(Message<?> message) throws Exception {
    LOGGER.debug("build adapt header");
    String correlationId = null;
    Integer sequenceNumberHeader = null;
    Integer sequenceSizeHeader = null;

    if (message.getHeaders().get("correlationId") != null) {
      correlationId = String.valueOf(message.getHeaders().get("correlationId"));
    }

    if (message.getHeaders().get(Constant.SEQUENCE_NUMBER_HEADER) != null) {
      sequenceNumberHeader = Integer
          .parseInt(String.valueOf(message.getHeaders().get(Constant.SEQUENCE_NUMBER_HEADER)));
    }

    if (message.getHeaders().get(Constant.SEQUENCE_SIZE_HEADER) != null) {
      sequenceSizeHeader = Integer
          .parseInt(String.valueOf(message.getHeaders().get(Constant.SEQUENCE_SIZE_HEADER)));
    }
    JobModelMultiEmployer jobModelMultiEmployer = message.getHeaders()
        .get(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER, JobModelMultiEmployer.class);
    UUID headerUuid = message.getHeaders().get(Constant.HEADER_CLAIM_CHECK, UUID.class);
    UUID trailerUuid = message.getHeaders().get(Constant.TRAILER_CLAIM_CHECK, UUID.class);
    Assert.notNull(headerUuid, "headerUuid should not be null");
    Assert.notNull(trailerUuid, "trailerUuid should not be null");
    String headerUuidInString = headerUuid.toString();
    String trailerUuidInString = trailerUuid.toString();
    Assert.notNull(jobModelMultiEmployer, "jobModelMultiEmployer should not be null");
    AdaptHeader adaptHeader = AdaptHeaderBuilderDirector.constructAdaptHeaderForTargetServiceApi(
        jobModelMultiEmployer, correlationId, sequenceNumberHeader, sequenceSizeHeader,
        headerUuidInString, trailerUuidInString);
    return jsonObjectMapper.toJson(adaptHeader);

  }
}
