package com.adapt.api.messaging;

import com.adapt.api.config.OutboundConstant;
import com.adapt.config.Constant;
import com.adapt.file.InvalidMessage;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.service.JobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("outboundJobStatusUpdateServiceActivator")
public class OutboundJobStatusUpdateServiceActivator {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(OutboundJobStatusUpdateServiceActivator.class);

  @Autowired
  private JobService jobService;

  /**
   * Update job status.
   *
   * @param message
   *          the message
   */
  public Message<?> updateJobStatus(Message<?> message) {
    Assert.notNull(message, "Message should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "headers should not be null");
    JobModelMultiEmployer jobModelMultiEmployer = (JobModelMultiEmployer) headers
        .get(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER);
    Assert.notNull(jobModelMultiEmployer, "jobModelMultiEmployer should not be null");
    Integer jobId = jobModelMultiEmployer.getJobId();
    if (jobId == null) {
      LOGGER.error("Cannot update job status with Job Id : null");
      throw new InvalidMessage("Cannot update job status with Job Id : null");
    } else {
      if (headers.get(Constant.FILE_RECORD_COUNT) != null) {
        Integer totalRecordsInFile = headers.get(Constant.FILE_RECORD_COUNT, Integer.class);
        jobService.updateJobIntialCountDetails(jobId, 0, 0, 0, 0, totalRecordsInFile);
      }
    }
    return message;
  }
}
