package com.adapt.api.service;

import com.adapt.api.config.DroolsEngineUtil;
import com.adapt.file.entity.ProcessorRuleModel;
import java.util.List;
import java.util.UUID;
import org.drools.compiler.kproject.ReleaseIdImpl;
import org.kie.api.KieServices;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.ReleaseId;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("droolsServiceImpl")
public class DroolsServiceImpl implements DroolsService {
  private static final Logger LOGGER = LoggerFactory.getLogger(DroolsServiceImpl.class);

  private static final String BUSINESS_CRITERIA_RULE = "businessCriteria";
  private static final String CHANGE_CRITERIA_RULE = "changeCriteria";
  private static final String SELECTION_CRITERIA_RULE = "selectionCriteria";

  @Autowired
  private RuleService ruleService;

  private KieServices kieServices;

  public DroolsServiceImpl() {
    kieServices = KieServices.Factory.get();
  }

  @Override
  public KieContainer prepareBusinessCriteriaRuleContainer(Integer fileIdentifier) {
    String containerName = getContainerName(BUSINESS_CRITERIA_RULE, fileIdentifier);
    return prepareBusinessCriteriaRuleContainer(containerName, fileIdentifier);
  }

  private KieContainer prepareBusinessCriteriaRuleContainer(String containerName,
      Integer fileIdentifier) {
    LOGGER.debug("prepareBusinessCriteriaRule rules for fileIdentifier = {}", fileIdentifier);
    // retrieve rules from db
    List<ProcessorRuleModel> rules = ruleService.getBusinessCriteriaRules(fileIdentifier);
    LOGGER.debug("total {} rules for prepareBusinessCriteriaRule", rules.size());
    return prepareKieContainer(containerName, rules);
  }

  @Override
  public void removeBusinessCriteriaRuleContainer() {
    // clean objects if needed
  }

  @Override
  public KieContainer prepareChangeCriteriaRuleContainer(Integer fileIdentifier) {
    String containerName = getContainerName(CHANGE_CRITERIA_RULE, fileIdentifier);
    return prepareChangeCriteriaRuleContainer(containerName, fileIdentifier);
  }

  private KieContainer prepareChangeCriteriaRuleContainer(String containerName,
      Integer fileIdentifier) {
    LOGGER.debug("prepareChangeCriteriaRuleContainer rules for fileIdentifier = {}",
        fileIdentifier);
    // retrieve rules from db
    List<ProcessorRuleModel> rules = ruleService.getChangeCriteriaRules(fileIdentifier);
    LOGGER.debug("total {} rules for prepareChangeCriteriaRuleContainer", rules.size());
    return prepareKieContainer(containerName, rules);
  }

  @Override
  public void removeChangeCriteriaRuleContainer() {
    // clean objects if needed
  }

  @Override
  public KieContainer prepareSelectionCriteriaRulesContainer(Integer fileIdentifier) {
    String containerName = getContainerName(SELECTION_CRITERIA_RULE, fileIdentifier);
    return prepareSelectionCriteriaRulesContainer(containerName, fileIdentifier);
  }

  private KieContainer prepareSelectionCriteriaRulesContainer(String containerName,
      Integer fileIdentifier) {
    LOGGER.debug("SelectionCriteria rules for fileIdentifier = {}", fileIdentifier);
    // retrieve rules from db
    List<ProcessorRuleModel> rules = ruleService.getSelectionCriteriaRules(fileIdentifier);
    LOGGER.debug("total {} rules for SelectionCriteria", rules.size());
    return prepareKieContainer(containerName, rules);
  }

  @Override
  public void removeSelectionCriteriaRulesContainer() {
    // clean objects if needed
  }

  private String getContainerName(String ruleType, Integer fileIdentifier) {
    return ruleType + "-" + fileIdentifier;
  }

  private KieContainer prepareKieContainer(String containerName, List<ProcessorRuleModel> rules) {
    ReleaseId releaseId = new ReleaseIdImpl("com.adapt", containerName,
        "1.0.0-" + UUID.randomUUID().toString().replaceAll("-", ""));
    Resource resource = kieServices.getResources()
        .newByteArrayResource(DroolsEngineUtil.createKieModule(releaseId, rules));

    KieModule module = kieServices.getRepository().addKieModule(resource);
    KieContainer kieContainer = kieServices.newKieContainer(module.getReleaseId());
    // remove the repo immediately
    kieServices.getRepository().removeKieModule(module.getReleaseId());
    return kieContainer;
  }

}
