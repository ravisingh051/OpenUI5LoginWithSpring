package com.adapt.api.messaging;

import com.adapt.api.config.ExtractionHelper;
import com.adapt.api.config.OutboundConstant;
import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.file.entity.EmployerInfo;
import com.adapt.file.entity.JobModelMultiEmployer;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("coreTransactionExtractionDetailsCountConfig")
public class CoreTransactionExtractionDetailsCountConfig {

  /**
   * configure message model for call extraction count api call.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<List<TransactionExtractionDetails>> config(
      Message<JobModelMultiEmployer> message) {

    JobModelMultiEmployer jobModelMultiEmployer = message.getPayload();

    List<TransactionExtractionDetails> transactionExtractionDetailsList = new ArrayList<>();
    List<String> extractionEmployerIdsList = ExtractionHelper
        .getEmployerIdsList(jobModelMultiEmployer);
    for (EmployerInfo employerInfo : jobModelMultiEmployer.getEmployerInfoList()) {
      // if employer is part of extraction selection then only create CoreTractionExtrationDetils
      if (extractionEmployerIdsList.contains(employerInfo.getEmployerId().toString())) {
        TransactionExtractionDetails transactionExtractionDetails = new TransactionExtractionDetails();
        transactionExtractionDetails.setSourceEmployerId(employerInfo.getEmployerId());
        String planSubtypes = StringUtils
            .join(ExtractionHelper.getPlanSubtypes(jobModelMultiEmployer), ",");
        transactionExtractionDetails.setPlanSubtypes(planSubtypes);
        Integer planYear = ExtractionHelper.getPlanYear(jobModelMultiEmployer);
        transactionExtractionDetails.setPlanYear(planYear);
        transactionExtractionDetails.setTestCfg(employerInfo.getTestCfg());
        transactionExtractionDetails
            .setLookAheadPeriod(ExtractionHelper.getLookAheadPeriod(jobModelMultiEmployer));
        transactionExtractionDetails
            .setLookBackPeriod(ExtractionHelper.getLookBackPeriod(jobModelMultiEmployer));
        transactionExtractionDetails.setPlanYearAdditiveFactor(
            ExtractionHelper.getPlanYearAdditiveFactor(jobModelMultiEmployer));
        transactionExtractionDetails
            .setSystemDate(ExtractionHelper.getSystemDate(jobModelMultiEmployer));
        transactionExtractionDetailsList.add(transactionExtractionDetails);
      }
    }

    MessageBuilder<List<TransactionExtractionDetails>> builder = new DefaultMessageBuilderFactory()
        .withPayload(transactionExtractionDetailsList);
    builder.setHeader(OutboundConstant.JOB_MODEL_MULTI_EMPLOYER_HEADER, jobModelMultiEmployer);
    return builder.build();
  }

}
