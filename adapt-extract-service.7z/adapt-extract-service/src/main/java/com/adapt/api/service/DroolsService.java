package com.adapt.api.service;

import org.kie.api.runtime.KieContainer;

public interface DroolsService {
  KieContainer prepareBusinessCriteriaRuleContainer(Integer fileIdentifier);

  void removeBusinessCriteriaRuleContainer();

  KieContainer prepareChangeCriteriaRuleContainer(Integer fileIdentifier);

  void removeChangeCriteriaRuleContainer();

  KieContainer prepareSelectionCriteriaRulesContainer(Integer fileIdentifier);

  void removeSelectionCriteriaRulesContainer();

}
