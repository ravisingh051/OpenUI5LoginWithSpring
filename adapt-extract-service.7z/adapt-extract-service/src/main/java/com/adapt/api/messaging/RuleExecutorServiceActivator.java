package com.adapt.api.messaging;

import com.adapt.api.service.ChangeCriteriaDroolsService;
import com.adapt.api.service.ChangeCriteriaKieSessionConfig;
import com.adapt.api.service.SelectionCriteriaDroolsService;
import com.adapt.api.service.SelectionCriteriaKieSessionConfig;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.alight.adapt.datasets.AbstractDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("ruleExecutorServiceActivator")
public class RuleExecutorServiceActivator {

  @Autowired
  private SelectionCriteriaDroolsService selectionCriteriaDroolsService;
  @Autowired
  private ChangeCriteriaDroolsService changeCriteriaDroolsService;

  /**
   * ApplyRules Method.
   * 
   * @param message
   *          AbstractDataset
   * @return AbstractDataset
   */
  public Message<AbstractDataset> applyRules(Message<AbstractDataset> message) {
    JobModelMultiEmployer jobModelMultiEmployer = (JobModelMultiEmployer) message.getHeaders()
        .get("jobModelMultiEmployer");
    Assert.notNull(jobModelMultiEmployer, "jobModelMultiEmployer should not be null");
    Integer fileIdentifier = jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier();
    AbstractDataset payload = message.getPayload();
    executeSelectionCriteriaRule(fileIdentifier, payload);
    executeChangeCriteria(fileIdentifier, payload);
    return message;
  }

  private void executeChangeCriteria(Integer fileIdentifier, AbstractDataset payLoad) {
    ChangeCriteriaKieSessionConfig changeCriteriaKieSessionConfig = new ChangeCriteriaKieSessionConfig(
        payLoad);
    changeCriteriaDroolsService.executeRules(fileIdentifier, changeCriteriaKieSessionConfig);
  }

  private void executeSelectionCriteriaRule(Integer fileIdentifier, AbstractDataset payLoad) {
    SelectionCriteriaKieSessionConfig selectionCriteriaKieSessionConfig = new SelectionCriteriaKieSessionConfig(
        payLoad);
    selectionCriteriaDroolsService.executeRules(fileIdentifier, selectionCriteriaKieSessionConfig);
  }
}
