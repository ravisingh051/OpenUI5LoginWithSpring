package com.adapt.config;

public class Constant {

  private Constant() {
  }

  public static final String IS_HEADER_KEY = "isHeader";
  public static final String IS_FOOTER_KEY = "isFooter";
  public static final String FILE_FOOTER_HEADER = "fileFooter";
  public static final String FILE_HEADER_HEADER = "fileHeader";
  public static final String FORMAT_HEADER = "FORMAT";
  public static final String JOB_MODEL_HEADER = "JOB_MODEL";
  public static final String JOB_ID_HEADER = "jobId";
  public static final String IS_NO_CONTENT_DATASET_HEADER = "isNoContentDataset";

  public static final String FILE_IDENTIFIER = "fileIdentifier";
  public static final String FILE_ID = "fileId";
  public static final String FILE_VERSION = "fileVersion";
  public static final String SEQUENCE_NUMBER_HEADER = "sequenceNumber";
  public static final String SEQUENCE_SIZE_HEADER = "sequenceSize";
  public static final String ORIGINAL_FILE_NAME_HEADER = "originalFileName";
  public static final String EXPECTED_HEADER = "EXPECTED";
  public static final String FILE_TYPE_HEADER = "fileType";
  public static final String MASTER_FILE_TEMPLATE_ID_HEADER = "masterFileTemplateId";
  public static final String MASTER_FILE_TEMPLATE_VERSION_HEADER = "masterFileTemplateVersion";
  public static final String RESULTS_MODE_HEADER = "resultsMode";
  public static final String FULL_OR_CHANGE_FILE_HEADER = "fullOrChange";
  public static final String SECONDARY_DATA_INFO_HEADER = "secondaryDataInfo";

  public static final String USP_GET_EXPECTED_JOBS_BY_DATE = "USP_Get_Expected_Jobs_By_Date";
  public static final String USP_GET_EXPECTED_JOBS_BY_DATE_AND_PRIORITY = "USP_Get_Expected_Jobs_By_Date_And_Priority";
  public static final String USP_GET_FILE_ATTRIBUTE_DETAILS = "USP_Get_File_Attribute_Details";

  public static final String FILE_RECORD_COUNT = "fileRecordCount";
  public static final String IS_HEADER_EXIST_HEADER = "isHeaderExist";
  public static final String IS_TRAILER_EXIST_HEADER = "isTrailerExist";

  public static final String FILE_FOOTER_MAP_HEADER = "fileMapFooter";
  public static final String FILE_HEADER_MAP_HEADER = "fileMapHeader";

  public static final String FILE_MIN_RECORD_COUNT_ALLOWED = "fileMinRecordCountAllowed";
  public static final String FILE_MAX_RECORD_COUNT_ALLOWED = "fileMaxRecordCountAllowed";

  public static final String CLIENT_ID_HEADER = "clientId";
  public static final String TEST_CFG_HEADER = "testCfg";
  public static final String EMPLOYER_ID_HEADER = "employerId";

  public static final String FILE_PROCESSING_ERROR_THRESHOLD_FORMAT_HEADER = "fileProcessingErrorThresholdFormat";
  public static final String ERROR_THRESHOLD_HEADER = "errorThreshold";
  public static final String ADAPT_HEADER = "adaptheader";

  public static final String USP_GET_RULES = "USP_Get_Rules";

  public static final String JOB_PRIOTIZATION_AUDIT_FAILED = "FAILED";
  public static final String JOB_PRIOTIZATION_AUDIT_STARTED = "STARTED";

  public static final String JOB_PRIOTIZATION_ROW_MAPPING_JOB_ID = "job_id";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_SLA = "is_sla_mapped";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_FILE_ID = "file_id";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_EMPLOYER_IDS = "employer_ids";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_TRADING_PARTNER = "trading_partner_id";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_FILE_TYPE = "file_type_id";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_DIRECTION = "direction";
  public static final String JOB_PRIOTIZATION_ROW_MAPPING_EXPECTED_DATE = "expected_start_date";

  public static final String SOURCE_INSTANCE_HEADER = "sourceInstance";

  public static final String FILE_DECRYPTED = ".decrypted";

  public static final String SOURCE_TYPE_FILE_DEL = "File - Delimited";
  public static final String SOURCE_TYPE_FILE_FIX = "File - Fixed Width";
  public static final String SOURCE_TYPE_API = "API Call Out - JSON";
  public static final String PROFILE_ID = "profileId";

  public static final String HEADER_CLAIM_CHECK = "headerClaimCheck";
  public static final String TRAILER_CLAIM_CHECK = "trailerClaimCheck";

}
