package com.adapt.config;

import com.adapt.file.entity.MessageType;
import com.alight.adapt.dataextraction.transaction.v1.models.TransactionDataset;
import com.alight.adapt.datasets.acaftedata.v1.ProcessorAcaFteDataset;
import com.alight.adapt.datasets.acaftehoursdata.v1.ProcessorAcaFteHoursDataset;
import com.alight.adapt.datasets.acaindividualeindata.v1.ProcessorAcaIndividualEinDataset;
import com.alight.adapt.datasets.acaotherdata1.v1.ProcessorAcaOther1Dataset;
import com.alight.adapt.datasets.acaotherdata3.v1.ProcessorAcaOther3Dataset;
import com.alight.adapt.datasets.addresssync.v1.ProcessorAddressSyncDataset;
import com.alight.adapt.datasets.census.v1.ProcessorCensusDataset;
import com.alight.adapt.datasets.dependentverification.v1.ProcessorDependentVerificationDataset;
import com.alight.adapt.datasets.election.v1.ProcessorElectionDataset;
import com.alight.adapt.datasets.employermandate.v1.ProcessorEmployerMandateDataset;
import com.alight.adapt.datasets.eoidecisions.v1.ProcessorEoiDecisionsDataset;
import com.alight.adapt.datasets.pensionpayments.v1.ProcessorPensionPaymentsDataset;
import com.alight.adapt.datasets.retireelengthofservice.v1.ProcessorRetireeLengthOfServiceDataset;
import com.alight.adapt.datasets.udfdata.v1.ProcessorUdfDataset;
import com.alight.adapt.datasets.wellnessprogram.v1.ProcessorWellnessProgramDataset;
import java.util.EnumMap;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("messageTypeConfigHelper")
public class MessageTypeConfigHelper {

  private MessageTypeConfigHelper() {
  }

  @Value("${censusDatasets.url}")
  private String censusDatasetsUrl;

  @Value("${wellnessProgramDatasets.url}")
  private String wellnessProgramDatasetsUrl;

  @Value("${dependentVerificationDatasets.url}")
  private String dependentVerificationDatasetsUrl;

  @Value("${acaFteDatasets.url}")
  private String acaFteDatasetsUrl;

  @Value("${acaFteHoursDatasets.url}")
  private String acaFteHoursDatasetsUrl;

  @Value("${acaIndividualEinDatasets.url}")
  private String acaIndividualEinDatasetsUrl;

  @Value("${employerMandateDatasets.url}")
  private String employerMandateDatasetsUrl;

  @Value("${retireeLengthOfServiceDatasets.url}")
  private String retireeLengthOfServiceDatasetsUrl;

  @Value("${acaOther1Datasets.url}")
  private String acaOther1DatasetsUrl;

  @Value("${acaOther3Datasets.url}")
  private String acaOther3DatasetsUrl;

  @Value("${pensionPaymentsDatasets.url}")
  private String pensionPaymentsDatasetsUrl;

  @Value("${addressSyncDatasets.url}")
  private String addressSyncDatasetsUrl;

  @Value("${udfDatasets.url}")
  private String udfDatasetsUrl;

  @Value("${eoiDecisionsDatasets.url}")
  private String eoiDecisionsDatasetsUrl;

  @Value("${electionDatasets.url}")
  private String electionDatasetsUrl;

  @Value("${coreTransactionDatasets.url}")
  private String coreTransactionDatasetsUrl;

  private static EnumMap<MessageType, MessageTypeConfig> messageTypeConfigMap = new EnumMap<>(
      MessageType.class);

  /**
   * Message type configuration.
   */
  @PostConstruct
  public void messageTypeConfiguration() {
    messageTypeConfigMap.put(MessageType.INBOUND_CENSUS,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_CENSUS)
            .endPoint(censusDatasetsUrl).datasetTransformerClazz(ProcessorCensusDataset.class)
            .build());

    messageTypeConfigMap.put(MessageType.INBOUND_WELLNESS,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_WELLNESS)
            .endPoint(wellnessProgramDatasetsUrl)
            .datasetTransformerClazz(ProcessorWellnessProgramDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_DVS,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_DVS)
            .endPoint(dependentVerificationDatasetsUrl)
            .datasetTransformerClazz(ProcessorDependentVerificationDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ACA_FTE_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ACA_FTE_DATASET)
            .endPoint(acaFteDatasetsUrl).datasetTransformerClazz(ProcessorAcaFteDataset.class)
            .build());

    messageTypeConfigMap.put(MessageType.INBOUND_ACA_FTE_HOURS_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ACA_FTE_HOURS_DATASET)
            .endPoint(acaFteHoursDatasetsUrl)
            .datasetTransformerClazz(ProcessorAcaFteHoursDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ACA_INDIVIDUAL_EIN_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ACA_INDIVIDUAL_EIN_DATASET)
            .endPoint(acaIndividualEinDatasetsUrl)
            .datasetTransformerClazz(ProcessorAcaIndividualEinDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ER_MANDATE_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ER_MANDATE_DATASET)
            .endPoint(employerMandateDatasetsUrl)
            .datasetTransformerClazz(ProcessorEmployerMandateDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_RETIREE_LENGTH_OF_SERVICE_DATASET,
        MessageTypeConfig.builder()
            .messageType(MessageType.INBOUND_RETIREE_LENGTH_OF_SERVICE_DATASET)
            .endPoint(retireeLengthOfServiceDatasetsUrl)
            .datasetTransformerClazz(ProcessorRetireeLengthOfServiceDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ACA_OTHER_DATASOURCE1_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ACA_OTHER_DATASOURCE1_DATASET)
            .endPoint(acaOther1DatasetsUrl).datasetTransformerClazz(ProcessorAcaOther1Dataset.class)
            .build());

    messageTypeConfigMap.put(MessageType.INBOUND_ACA_OTHER_DATASOURCE3_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ACA_OTHER_DATASOURCE3_DATASET)
            .endPoint(acaOther3DatasetsUrl).datasetTransformerClazz(ProcessorAcaOther3Dataset.class)
            .build());

    messageTypeConfigMap.put(MessageType.INBOUND_PENSION_PAYMENTS_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_PENSION_PAYMENTS_DATASET)
            .endPoint(pensionPaymentsDatasetsUrl)
            .datasetTransformerClazz(ProcessorPensionPaymentsDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ADDRESS_SYNC_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ADDRESS_SYNC_DATASET)
            .endPoint(addressSyncDatasetsUrl)
            .datasetTransformerClazz(ProcessorAddressSyncDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_UDF_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_UDF_DATASET)
            .endPoint(udfDatasetsUrl).datasetTransformerClazz(ProcessorUdfDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_EOI_DECISIONS_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_EOI_DECISIONS_DATASET)
            .endPoint(eoiDecisionsDatasetsUrl)
            .datasetTransformerClazz(ProcessorEoiDecisionsDataset.class).build());

    messageTypeConfigMap.put(MessageType.INBOUND_ELECTION_DATASET,
        MessageTypeConfig.builder().messageType(MessageType.INBOUND_ELECTION_DATASET)
            .endPoint(electionDatasetsUrl).datasetTransformerClazz(ProcessorElectionDataset.class)
            .build());

    messageTypeConfigMap.put(MessageType.OUTBOUND_CORE_T,
        MessageTypeConfig.builder().messageType(MessageType.OUTBOUND_CORE_T)
            .endPoint(coreTransactionDatasetsUrl).datasetTransformerClazz(TransactionDataset.class)
            .build());

  }

  public static MessageTypeConfig getMessageTypeConfiguration(MessageType messageType) {
    return messageTypeConfigMap.get(messageType);
  }

}
