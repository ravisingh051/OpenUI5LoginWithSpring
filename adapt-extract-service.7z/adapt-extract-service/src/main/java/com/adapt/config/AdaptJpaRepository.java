package com.adapt.config;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdaptJpaRepository<T, ID> extends JpaRepository<T, ID> {

  /**
   * use saveAll instead of this method.
   *
   * @param entities
   *          the entities
   * @return the list
   * 
   */
  public default List<T> save(List<T> entities) {
    return this.saveAll(entities);
  }

  /**
   * use findById instead of this method.
   *
   * @param id
   *          the id
   * @return the t
   * 
   */
  public default T findOne(ID id) {
    Optional<T> optionalEntity = this.findById(id);
    if (optionalEntity.isPresent()) {
      return optionalEntity.get();
    } else {
      return null;
    }
  }

}
