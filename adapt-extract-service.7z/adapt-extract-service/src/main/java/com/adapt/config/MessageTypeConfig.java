package com.adapt.config;

import com.adapt.file.entity.MessageType;
import com.alight.adapt.datasets.AbstractDataset;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class MessageTypeConfig {

  private MessageType messageType;
  private String endPoint;
  private Class<? extends AbstractDataset> datasetTransformerClazz;

}
