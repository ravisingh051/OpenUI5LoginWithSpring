package com.adapt.config;

import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.service.JobService;
import com.adapt.file.service.SecondaryDataService;
import java.time.LocalDate;
import java.util.Collection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CacheScheduler {

  private static final Logger LOGGER = LoggerFactory.getLogger(CacheScheduler.class);

  @Autowired
  private JobService jobService;

  @Autowired
  private SecondaryDataService secondaryDataService;

  /**
   * Gets the current day job details.
   *
   */
  @Scheduled(cron = "${cache.cron.expression}")
  public void getCurrentDayJobDetails() {

    LOGGER.info("Scheduler started to cache data ");
    Collection<JobFileEntity> jobFileEntities = jobService.findJobsByExpectedDate(LocalDate.now());

    jobFileEntities.forEach(jobFileEntity -> secondaryDataService
        .getSecondaryDataInfo(jobFileEntity.getFileIdentifier()));

    LOGGER.info("Scheduler ends ");
  }

  /**
   * Removes cache at specified time defined in cron expression.
   */
  @Scheduled(cron = "${cache.evict.cron.expression}")
  public void removeCache() {
    secondaryDataService.removeSecondaryDataFromCache();
  }

}
