package com.adapt.config;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.integration.jdbc.store.JdbcMessageStore;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "idisEntityManager", transactionManagerRef = "idisTransactionManager", basePackages = "com.adapt.repository")
public class MetaInfoDBConfig {

  @Autowired(required = false)
  private PersistenceUnitManager persistenceUnitManager;

  @Bean
  @Primary
  @ConfigurationProperties("spring.jpa")
  public JpaProperties idisJpaProperties() {
    return new JpaProperties();
  }

  @Bean
  @Primary
  @ConfigurationProperties(prefix = "spring.datasource")
  public DataSource idisDataSource() {
    return DataSourceBuilder.create().build();
  }

  /**
   * Entity manager.
   *
   * @param idisJpaProperties
   *          the idis jpa properties
   * @return the local container entity manager factory bean
   */
  @Bean
  @Primary
  public LocalContainerEntityManagerFactoryBean idisEntityManager(JpaProperties idisJpaProperties) {
    EntityManagerFactoryBuilder builder = createEntityManagerFactoryBuilder(idisJpaProperties);

    Map<String, Object> vendorProperties = new LinkedHashMap<>();
    vendorProperties.putAll(idisJpaProperties().getProperties());

    return builder.dataSource(idisDataSource()).properties(vendorProperties)
        .packages("com.adapt.file.entity").persistenceUnit("idisDs").build();
  }

  @Bean
  @Primary
  public JpaTransactionManager idisTransactionManager(EntityManagerFactory idisEntityManager) {
    return new JpaTransactionManager(idisEntityManager);
  }

  private EntityManagerFactoryBuilder createEntityManagerFactoryBuilder(
      JpaProperties idisJpaProperties) {
    JpaVendorAdapter jpaVendorAdapter = createJpaVendorAdapter(idisJpaProperties);
    return new EntityManagerFactoryBuilder(jpaVendorAdapter, idisJpaProperties.getProperties(),
        this.persistenceUnitManager);
  }

  private JpaVendorAdapter createJpaVendorAdapter(JpaProperties jpaProperties) {
    AbstractJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
    adapter.setShowSql(jpaProperties.isShowSql());
    adapter.setDatabase(jpaProperties.getDatabase());
    adapter.setDatabasePlatform(jpaProperties.getDatabasePlatform());
    adapter.setGenerateDdl(jpaProperties.isGenerateDdl());
    return adapter;
  }

  @Bean
  public JdbcMessageStore jdbcMessageGroupStore() {
    return new JdbcMessageStore(idisDataSource());
  }

}
