package com.adapt.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLContext;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.nio.client.HttpAsyncClient;
import org.apache.http.nio.conn.NHttpClientConnectionManager;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.AsyncClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

  @Value("${client.ssl.trust-store}")
  private File trustStore;

  @Value("${client.ssl.trust-store-password}")
  private String trustStorePassword;

  @Value("${http.connection.pooling.limit}")
  private Integer maxTotal;

  @Value("${restTemplate.timeout.required}")
  private Boolean isTimeoutRequired;

  @Value("${restTemplate.read.timeout}")
  private Integer readTimeout;

  @Value("${restTemplate.connect.timeout}")
  private Integer connectTimeout;

  /**
   * Rest template.
   *
   * @return the rest template
   */
  @Bean
  public RestTemplate restTemplate() {
    HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(
        httpClient());
    RestTemplate restTemplate = new RestTemplate(factory);
    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    ObjectMapper objectMapper = new ObjectMapper();
    converter.setObjectMapper(objectMapper);
    restTemplate.getMessageConverters().add(converter);
    if (isTimeoutRequired) {
      ((HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory())
          .setConnectTimeout(connectTimeout);
      ((HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory())
          .setReadTimeout(readTimeout);
    }
    return restTemplate;

  }

  /**
   * Registry.
   *
   * @param sslConnectionSocketFactory
   *          the ssl connection socket factory
   * @return the registry
   */
  public Registry<ConnectionSocketFactory> registry(
      SSLConnectionSocketFactory sslConnectionSocketFactory) {
    return RegistryBuilder.<ConnectionSocketFactory>create()
        .register("http", new PlainConnectionSocketFactory())
        .register("https", sslConnectionSocketFactory).build();
  }

  /**
   * Connection manager.
   *
   * @return the http client connection manager
   */
  public HttpClientConnectionManager connectionManager() {
    PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(
        registry(sslConnectionSocketFactory()));
    cm.setMaxTotal(maxTotal);
    return cm;
  }

  public HttpClient httpClient() {

    return HttpClients.custom().setConnectionManager(connectionManager()).build();
  }

  public SSLConnectionSocketFactory sslConnectionSocketFactory() {
    return new SSLConnectionSocketFactory(sslContext(), NoopHostnameVerifier.INSTANCE);
  }

  /**
   * Ssl context.
   *
   * @return the SSL context
   */
  public SSLContext sslContext() {
    try {
      return SSLContextBuilder.create()
          .loadTrustMaterial(trustStore, trustStorePassword.toCharArray()).build();
    } catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException
        | CertificateException | IOException e) {
      throw new RuntimeException(e.getMessage());

    }
  }

  /**
   * Async rest tempalte.
   *
   * @return the async rest template
   */
  @Bean
  public AsyncRestTemplate asyncRestTempalte() {
    AsyncRestTemplate asyncRestTemplate = new AsyncRestTemplate(asyncHttpRequestFactory(),
        restTemplate());
    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    ObjectMapper objectMapper = new ObjectMapper();
    converter.setObjectMapper(objectMapper);
    asyncRestTemplate.getMessageConverters().add(converter);
    return asyncRestTemplate;
  }

  /**
   * Async http request factory.
   *
   * @return the async client http request factory
   */
  public AsyncClientHttpRequestFactory asyncHttpRequestFactory() {
    return new HttpComponentsAsyncClientHttpRequestFactory(asyncHttpClient());
  }

  /**
   * Async connection manager.
   *
   * @return the n http client connection manager
   */
  public NHttpClientConnectionManager asyncConnectionManager() {
    PoolingNHttpClientConnectionManager connectionManager;
    try {
      connectionManager = new PoolingNHttpClientConnectionManager(
          new DefaultConnectingIOReactor(IOReactorConfig.DEFAULT));
      connectionManager.setMaxTotal(100);
    } catch (IOReactorException e) {
      throw new RuntimeException(e.getMessage());
    }
    return connectionManager;
  }

  /**
   * Async http client.
   *
   * @return the http async client
   */
  public HttpAsyncClient asyncHttpClient() {
    return HttpAsyncClients.custom().setConnectionManager(asyncConnectionManager()).build();
  }
}
