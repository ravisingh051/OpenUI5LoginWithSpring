package com.adapt.config;

import com.adapt.file.entity.MessageType;
import java.util.EnumMap;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.PropertyResolver;
import org.springframework.stereotype.Component;

@Component
public class EndPointConfigurationHelper {
  private static final String CORE_TRANSACTION_DATASETS_URL = "coreTransactionDatasets.url";

  private static EnumMap<MessageType, String> endPoints = new EnumMap<>(MessageType.class);

  @Autowired
  private PropertyResolver propertyResolver;

  @PostConstruct
  public void configureEndPoint() {
    endPoints.put(MessageType.OUTBOUND_CORE_T,
        propertyResolver.getProperty(CORE_TRANSACTION_DATASETS_URL));
  }

  public static String getEndPointUrl(MessageType messageType) {
    return endPoints.get(messageType);
  }

}
