package com.adapt.file.messaging;

public interface Locker {

  Object lock(Object payload);

}
