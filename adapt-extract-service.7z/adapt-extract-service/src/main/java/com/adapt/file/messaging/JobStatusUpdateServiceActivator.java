package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.InvalidMessage;
import com.adapt.file.entity.JobModel;
import com.adapt.file.service.JobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("jobStatusUpdateServiceActivator")
public class JobStatusUpdateServiceActivator {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(JobStatusUpdateServiceActivator.class);

  @Autowired
  private JobService jobService;

  /**
   * Update job status.
   *
   * @param message
   *          the message
   */
  public Message<?> updateJobStatus(Message<?> message) {
    Assert.notNull(message, "Message should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "headers should not be null");
    JobModel jobModel = (JobModel) headers.get(Constant.JOB_MODEL_HEADER);
    Assert.notNull(jobModel, "jobModel should not be null");
    Integer jobId = jobModel.getJobId();
    if (jobId == null) {
      LOGGER.error("Cannot update job status with Job Id : null");
      throw new InvalidMessage("Cannot update job status with Job Id : null");
    } else {
      Integer totalRecordsInFile = (Integer) headers.get(Constant.FILE_RECORD_COUNT);
      jobService.updateJobIntialCountDetails(jobId, 0, 0, 0, 0, totalRecordsInFile);
    }
    return message;
  }
}
