package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.alight.adapt.datasets.AbstractDataset;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * This is to do cloning of records.
 *
 */
@Component("cloneRecordsGenerator")
public class CloneRecordsGenerator {

  private static final Logger LOGGER = LoggerFactory.getLogger(CloneRecordsGenerator.class);

  /**
   * GenerateClones Method.
   * 
   * @param message
   *          List of AbstractDataset
   */
  public Message<List<AbstractDataset>> generateClones(Message<List<AbstractDataset>> message) {
    List<AbstractDataset> payload = message.getPayload();
    List<AbstractDataset> finalPayload = new ArrayList<>();

    updateCloneNumber(payload, 0);
    finalPayload.addAll(payload);

    JobModel job = (JobModel) message.getHeaders().get(Constant.JOB_MODEL_HEADER);
    Assert.notNull(job, "Job shoud not be null");
    if (job.getCloneNumberList() != null && !job.getCloneNumberList().isEmpty()) {

      job.getCloneNumberList().forEach(cloneNumber -> {
        List<AbstractDataset> clonedPayload = clonePayload(payload);
        updateCloneNumber(clonedPayload, cloneNumber);
        finalPayload.addAll(clonedPayload);
      });
      LOGGER.debug("number of records found after cloning: {} ", finalPayload.size());

    } else {
      LOGGER.info("No clones configured for this file");
    }
    MessageBuilder<List<AbstractDataset>> builder = new DefaultMessageBuilderFactory()
        .withPayload(finalPayload).copyHeaders(message.getHeaders());

    return builder.build();

  }

  private List<AbstractDataset> clonePayload(List<AbstractDataset> payload) {
    // deep cloning
    List<AbstractDataset> newDataset = new ArrayList<>();
    payload.forEach(dataset -> newDataset.add(SerializationUtils.clone(dataset)));
    return newDataset;
  }

  private void updateCloneNumber(List<AbstractDataset> list, Integer cloneNumber) {
    list.forEach(dataset -> dataset.setRecordCopyId(cloneNumber));
  }

}
