package com.adapt.file.entity;

import java.io.Serializable;
import java.util.List;

public class JobPriortizationPayload implements Serializable {

  private static final long serialVersionUID = 5619312749202735949L;

  private List<JobPriorityEntity> jobPriorityListEntity;
  private List<PriorityInfoEntity> priorityInfoListEntity;

  public List<JobPriorityEntity> getJobPriorityListEntity() {
    return jobPriorityListEntity;
  }

  public void setJobPriorityListEntity(List<JobPriorityEntity> jobPriorityListEntity) {
    this.jobPriorityListEntity = jobPriorityListEntity;
  }

  public List<PriorityInfoEntity> getPriorityInfoListEntity() {
    return priorityInfoListEntity;
  }

  public void setPriorityInfoListEntity(List<PriorityInfoEntity> priorityInfoListEntity) {
    this.priorityInfoListEntity = priorityInfoListEntity;
  }

  @Override
  public String toString() {
    return "JobPriortizationPayload [jobPriorityListEntity=" + jobPriorityListEntity
        + ", priorityInfoListEntity=" + priorityInfoListEntity + "]";
  }

}
