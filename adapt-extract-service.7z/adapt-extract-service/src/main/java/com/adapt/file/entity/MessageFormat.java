package com.adapt.file.entity;

import java.io.Serializable;

public class MessageFormat implements Serializable {

  private static final long serialVersionUID = 2770318889528735894L;
  private MessageFormatType messageFormatType;
  private String rowDelimiter;
  private String fieldDelimiter;
  private String escapeCharacter;
  private String segmentDelimiter;

  public MessageFormatType getMessageFormatType() {
    return messageFormatType;
  }

  public void setMessageFormatType(MessageFormatType messageFormatType) {
    this.messageFormatType = messageFormatType;
  }

  public String getRowDelimiter() {
    return rowDelimiter;
  }

  public void setRowDelimiter(String rowDelimiter) {
    this.rowDelimiter = rowDelimiter;
  }

  public String getFieldDelimiter() {
    return fieldDelimiter;
  }

  public void setFieldDelimiter(String fieldDelimiter) {
    this.fieldDelimiter = fieldDelimiter;
  }

  public String getEscapeCharacter() {
    return escapeCharacter;
  }

  public void setEscapeCharacter(String escapeCharacter) {
    this.escapeCharacter = escapeCharacter;
  }

  public String getSegmentDelimiter() {
    return segmentDelimiter;
  }

  public void setSegmentDelimiter(String segmentDelimiter) {
    this.segmentDelimiter = segmentDelimiter;
  }

}
