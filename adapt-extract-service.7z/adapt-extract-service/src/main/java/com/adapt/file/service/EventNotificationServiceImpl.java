package com.adapt.file.service;

import com.adapt.event.AdaptDatatypeTransformationExceptionOccuredEvent;
import com.adapt.event.DatasetCountExceedOccurred;
import com.adapt.event.DatasetCountSubceedOccurred;
import com.adapt.event.InboundFileOccurred;
import com.adapt.event.JobCompletedOccurredEvent;
import com.adapt.event.JobFailedOccurredEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.AsyncRestTemplate;

@Service("eventNotificationService")
public class EventNotificationServiceImpl implements EventNotificationService {

  private static final Logger LOGGER = LoggerFactory.getLogger(EventNotificationServiceImpl.class);

  @Autowired
  private AsyncRestTemplate asyncRestTempalte;

  @Value("${dataset.processing.inbound.file.url}")
  private String inboundFileOccurredUrl;

  @Value("${dataset.processing.count.exceed.url}")
  private String countExceedOccurredUrl;

  @Value("${dataset.processing.count.subceed.url}")
  private String countSubceedOccurredUrl;

  @Value("${dataset.datatype.transformation.exception.url}")
  private String dataTypeTransformationExceptionUrl;

  @Value("${dataset.datatype.job.failed.exception.url}")
  private String jobFailedEventUrl;

  @Value("${dataset.processing.job.success.url}")
  private String jobCompletedEventUrl;

  @Value("${dataset.runtime.exception.url}")
  private String runtimeExceptionEventUrl;

  @Override
  public void sendInboundFileOccuredNotification(InboundFileOccurred inboundFileOccurred) {
    HttpEntity<InboundFileOccurred> requestEntity = new HttpEntity<>(inboundFileOccurred);
    asyncRestTempalte.postForEntity(inboundFileOccurredUrl, requestEntity, String.class);
    LOGGER.debug("Inbound file occurred : jobid : {}, fileID: {}, fileVersion: {}",
        inboundFileOccurred.getJobId(), inboundFileOccurred.getFileId(),
        inboundFileOccurred.getFileVersion());
  }

  @Override
  public void
      sendCountExceededOccurredNotification(DatasetCountExceedOccurred datasetCountExceedOccurred) {
    HttpEntity<DatasetCountExceedOccurred> requestEntity =
        new HttpEntity<>(datasetCountExceedOccurred);
    asyncRestTempalte.postForEntity(countExceedOccurredUrl, requestEntity, String.class);
    LOGGER.debug("Count Exceed occurred : jobid : {}, fileID: {}, fileVersion: {}",
        datasetCountExceedOccurred.getJobId(), datasetCountExceedOccurred.getFileId(),
        datasetCountExceedOccurred.getFileVersion());

  }

  @Override
  public void sendCountSubceededOccurredNotification(
      DatasetCountSubceedOccurred datasetCountSubceedOccurred) {
    HttpEntity<DatasetCountSubceedOccurred> requestEntity =
        new HttpEntity<>(datasetCountSubceedOccurred);
    asyncRestTempalte.postForEntity(countSubceedOccurredUrl, requestEntity, String.class);
    LOGGER.debug("Count Subceed occurred : jobid : {}, fileID: {}, fileVersion: {}",
        datasetCountSubceedOccurred.getJobId(), datasetCountSubceedOccurred.getFileId(),
        datasetCountSubceedOccurred.getFileVersion());

  }

  @Override
  public void sendDataTypeTransformationExceptionEvent(
      AdaptDatatypeTransformationExceptionOccuredEvent adaptDatatypeTransformationExceptionOccured) {
    HttpEntity<AdaptDatatypeTransformationExceptionOccuredEvent> requestEntity =
        new HttpEntity<>(adaptDatatypeTransformationExceptionOccured);
    asyncRestTempalte.postForEntity(dataTypeTransformationExceptionUrl, requestEntity,
        String.class);
    LOGGER.debug(
        "Data Type Transformation Exception Occurred : jobid : {}, fileID: {}, fileVersion: {}",
        adaptDatatypeTransformationExceptionOccured.getJobId(),
        adaptDatatypeTransformationExceptionOccured.getFileId(),
        adaptDatatypeTransformationExceptionOccured.getFileVersion());

  }

  @Override
  public void sendJobFailedEvent(JobFailedOccurredEvent jobFailedOccurredEvent) {
    HttpEntity<JobFailedOccurredEvent> requestEntity = new HttpEntity<>(jobFailedOccurredEvent);
    asyncRestTempalte.postForEntity(jobFailedEventUrl, requestEntity, String.class);
    LOGGER.debug("Job Failed Occurred: jobid : {}, fileID: {}, fileVersion: {}",
        jobFailedOccurredEvent.getJobId(), jobFailedOccurredEvent.getFileId(),
        jobFailedOccurredEvent.getFileVersion());

  }

  @Override
  public void sendJobCompletedEvent(JobCompletedOccurredEvent jobCompletedOccurredEvent) {
    HttpEntity<JobCompletedOccurredEvent> requestEntity =
        new HttpEntity<>(jobCompletedOccurredEvent);
    asyncRestTempalte.postForEntity(jobCompletedEventUrl, requestEntity, String.class);
    LOGGER.debug("Job Completed Occurred: jobid : {}, fileID: {}, fileVersion: {}",
        jobCompletedOccurredEvent.getJobId(), jobCompletedOccurredEvent.getFileId(),
        jobCompletedOccurredEvent.getFileVersion());

  }

}
