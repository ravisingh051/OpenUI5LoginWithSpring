package com.adapt.file.entity;

import java.util.HashMap;
import java.util.Map;

/**
 * This class maps a Attributes object to the IntermediaryAttributes object, which is a map that
 * lets user get the attribute by the order of the attribute.
 *
 */
public class IntermediaryAttributeMapper {

  /**
   * From input attributes.
   *
   * @param from
   *          the from
   * @return the intermediary attributes
   */
  public IntermediaryAttributes fromInputAttributes(Attributes from) {

    Map<Integer, IntermediaryAttribute> outputAttributes = new HashMap<>();
    for (Attribute att : from.getAttributeList()) {
      IntermediaryAttribute intermediaryAttribute = new IntermediaryAttribute(
          att.getStandardizedName(), att.getDatatype(), att.getRequired(), att.getAttributeSize(),
          att.getAttributeStartPosition(), att.getAttributeEndPosition());
      outputAttributes.put(att.getOrder(), intermediaryAttribute);
    }

    return new IntermediaryAttributes(outputAttributes);
  }

  /**
   * From fix width input attributes.
   *
   * @param from
   *          the from
   * @return the intermediary attributes
   */
  public IntermediaryAttributes fromFixWidthInputAttributes(Attributes from) {

    Map<Integer, IntermediaryAttribute> outputAttributes = new HashMap<>();
    for (Attribute att : from.getAttributeList()) {
      IntermediaryAttribute intermediaryAttribute = new IntermediaryAttribute(
          att.getStandardizedName(), att.getDatatype(), att.getRequired(), att.getAttributeSize(),
          att.getAttributeStartPosition(), att.getAttributeEndPosition());
      outputAttributes.put(att.getAttributeStartPosition(), intermediaryAttribute);
    }

    return new IntermediaryAttributes(outputAttributes);
  }

}
