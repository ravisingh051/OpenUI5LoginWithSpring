package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.entity.IntermediaryAttributes;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.Section.SectionType;
import com.adapt.file.service.FileAttributePreparer;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("fixWidthFileHeaderAndTrailerToMapTransformer")
public class FixWidthFileHeaderAndTrailerToMapTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(FixWidthFileHeaderAndTrailerToMapTransformer.class);

  @Autowired
  private FileAttributePreparer fileAttributePreparer;

  @Override
  protected Message<?> doTransform(Message<?> message) throws Exception {
    Assert.notNull(message, "Message should be not null");
    MessageHeaders headers = message.getHeaders();

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().fromMessage(message);
    builder.copyHeaders(message.getHeaders());

    JobModel jobModel = (JobModel) headers.get("JOB_MODEL");

    Boolean isHeaderExist = (Boolean) message.getHeaders().get(Constant.IS_HEADER_EXIST_HEADER);
    if (isHeaderExist != null && isHeaderExist) {
      Map<String, Object> headerAttributes = prepareHeaderAttributes(message, jobModel);
      LOGGER.debug("number of header configuration found is: {}", headerAttributes.size());
      builder.setHeader(Constant.FILE_HEADER_MAP_HEADER, headerAttributes);
    }

    Boolean isTrailerExist = (Boolean) message.getHeaders().get(Constant.IS_TRAILER_EXIST_HEADER);
    if (isTrailerExist != null && isTrailerExist) {
      Map<String, Object> trailerAttributes = prepareTrailerAttributes(message, jobModel);
      LOGGER.debug("number of trailer configuration found is: {}", trailerAttributes.size());
      builder.setHeader(Constant.FILE_FOOTER_MAP_HEADER, trailerAttributes);
    }

    return builder.build();
  }

  private Map<String, Object> prepareHeaderAttributes(Message<?> message, JobModel jobModel) {
    SectionType sectionType = SectionType.HEADER;
    IntermediaryAttributes intermediaryAttributes = fileAttributePreparer
        .prepareFixWidthIntermediaryAttributes(jobModel, sectionType);
    Object header = message.getHeaders().get(Constant.FILE_HEADER_HEADER);
    return fileAttributePreparer.prepareAttributesMap((String) header, intermediaryAttributes);
  }

  private Map<String, Object> prepareTrailerAttributes(Message<?> message, JobModel jobModel) {
    SectionType sectionType = SectionType.TRAILER;
    IntermediaryAttributes intermediaryAttributes = fileAttributePreparer
        .prepareFixWidthIntermediaryAttributes(jobModel, sectionType);
    Object trailer = message.getHeaders().get(Constant.FILE_FOOTER_HEADER);
    return fileAttributePreparer.prepareAttributesMap((String) trailer, intermediaryAttributes);
  }

}