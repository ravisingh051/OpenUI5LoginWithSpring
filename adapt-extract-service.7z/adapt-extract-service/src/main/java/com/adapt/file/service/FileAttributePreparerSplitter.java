package com.adapt.file.service;

public class FileAttributePreparerSplitter {
  
  private int currentPosition;
  private int endPosition;
  private int next;
  private int endQuotePosition;
  private int endDelimiterAfterQuote;
  private boolean inQuote;
 
  public int getCurrentPosition() {
    return currentPosition;
  }

  public void setCurrentPosition(int currentPosition) {
    this.currentPosition = currentPosition;
  }

  public int getEndPosition() {
    return endPosition;
  }

  public void setEndPosition(int endPosition) {
    this.endPosition = endPosition;
  }

  public int getNext() {
    return next;
  }

  public void setNext(int next) {
    this.next = next;
  }

  public int getEndQuotePosition() {
    return endQuotePosition;
  }

  public void setEndQuotePosition(int endQuotePosition) {
    this.endQuotePosition = endQuotePosition;
  }

  public int getEndDelimiterAfterQuote() {
    return endDelimiterAfterQuote;
  }

  public void setEndDelimiterAfterQuote(int endDelimiterAfterQuote) {
    this.endDelimiterAfterQuote = endDelimiterAfterQuote;
  }

  public boolean isInQuote() {
    return inQuote;
  }

  public void setInQuote(boolean inQuote) {
    this.inQuote = inQuote;
  }
}
