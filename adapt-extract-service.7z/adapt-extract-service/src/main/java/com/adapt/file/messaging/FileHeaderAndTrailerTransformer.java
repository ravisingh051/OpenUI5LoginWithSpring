package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.exception.UnsuccessfulFileRenameException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("fileHeaderAndTrailerTransformer")
public class FileHeaderAndTrailerTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(FileHeaderAndTrailerTransformer.class);

  private static final String TMP_EXTENSION = ".tmp";

  public static final String CHARSET_UTF_8 = "UTF-8";

  @Override
  protected Message<?> doTransform(Message<?> message) throws IOException {
    LOGGER.debug("inside file transformer");

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().fromMessage(message);
    builder.copyHeaders(message.getHeaders());

    File file = (File) message.getPayload();
    File tempFile = new File(file.getParent(), file.getName() + TMP_EXTENSION);

    Boolean isHeaderExist = (Boolean) message.getHeaders().get(Constant.IS_HEADER_EXIST_HEADER);
    Boolean isTrailerExist = (Boolean) message.getHeaders().get(Constant.IS_TRAILER_EXIST_HEADER);

    String firstLine;
    String lastLine = null;
    String line;
    int lineCount = 0;

    try (
        BufferedReader br = new BufferedReader(
            new InputStreamReader(new FileInputStream(file), CHARSET_UTF_8));
        BufferedWriter writer = new BufferedWriter(
            new OutputStreamWriter(new FileOutputStream(tempFile), CHARSET_UTF_8))) {
      firstLine = br.readLine();
      if (isHeaderExist != null && !isHeaderExist) {
        writer.write(firstLine);
        writer.newLine();
        lineCount++;
        builder.setHeader(Constant.FILE_HEADER_HEADER, "");
      } else {
        builder.setHeader(Constant.FILE_HEADER_HEADER, firstLine);
      }
      while ((line = br.readLine()) != null) {
        if (lastLine != null) {
          writer.write(lastLine);
          writer.newLine();
          lineCount++;
        }
        lastLine = line;
      }

      if (isTrailerExist != null && !isTrailerExist) {
        if (lastLine != null) {
          writer.write(lastLine);
          writer.newLine();
          lineCount++;
        }
        builder.setHeader(Constant.FILE_FOOTER_HEADER, "");
      } else {
        builder.setHeader(Constant.FILE_FOOTER_HEADER, lastLine);
      }
      builder.setHeader(Constant.FILE_RECORD_COUNT, lineCount);
    }

    // Delete the original file
    deleteFile(file);
    doRename(tempFile, file);

    LOGGER.debug("Line count in file excluding header and trailer {}", lineCount);
    return builder.build();
  }

  private void deleteFile(File inFile) throws IOException {
    Path path = Paths.get(inFile.getParent(), inFile.getName());
    Files.delete(path);
  }

  private void doRename(File tempFile, File inFile) {
    if (!tempFile.renameTo(inFile)) {
      throw new UnsuccessfulFileRenameException(
          "Could not rename file after deleting header and trailer");
    }
  }

}
