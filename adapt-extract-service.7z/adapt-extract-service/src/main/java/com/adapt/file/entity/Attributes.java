package com.adapt.file.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Attributes implements Serializable {

  private static final long serialVersionUID = 2203734628747607982L;
  private List<Attribute> attributeList = new ArrayList<>();

  public List<Attribute> getAttributeList() {
    return attributeList;
  }

  public void setAttributeList(List<Attribute> attributes) {
    this.attributeList = attributes;
  }

}
