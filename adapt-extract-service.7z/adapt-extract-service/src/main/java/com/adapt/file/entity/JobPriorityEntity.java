package com.adapt.file.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class JobPriorityEntity implements Serializable {

  private static final long serialVersionUID = -7104843097314146234L;

  @Id
  @Column(name = "job_id")
  private Integer jobId;
  @Column(name = "is_sla_mapped")
  private Boolean isSlaMapped;
  @Column(name = "file_id")
  private Integer fileId;
  @Column(name = "employer_ids")
  private String employerIds;
  @Column(name = "trading_partner_id")
  private Integer tradingPartnerId;
  @Column(name = "file_type_id")
  private Integer fileTypeId;
  @Column(name = "direction")
  private String direction;
  @Column(name = "expected_start_date")
  private Date expectedStartDate;
  @Column(name = "explicit_high_prioritization")
  private Boolean explicitHighPrioritization;
  @Column(name = "explicit_low_prioritization")
  private Boolean explicitLowPrioritization;
  @Column(name = "explicit_prioritization_date")
  private Date explicitPrioritizationDate;

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public Boolean getIsSlaMapped() {
    return isSlaMapped;
  }

  public void setIsSlaMapped(Boolean isSlaMapped) {
    this.isSlaMapped = isSlaMapped;
  }

  public Integer getFileId() {
    return fileId;
  }

  public void setFileId(Integer fileId) {
    this.fileId = fileId;
  }

  public String getEmployerIds() {
    return employerIds;
  }

  public void setEmployerIds(String employerIds) {
    this.employerIds = employerIds;
  }

  public Integer getTradingPartnerId() {
    return tradingPartnerId;
  }

  public void setTradingPartnerId(Integer tradingPartnerId) {
    this.tradingPartnerId = tradingPartnerId;
  }

  public Integer getFileTypeId() {
    return fileTypeId;
  }

  public void setFileTypeId(Integer fileTypeId) {
    this.fileTypeId = fileTypeId;
  }

  public String getDirection() {
    return direction;
  }

  public void setDirection(String direction) {
    this.direction = direction;
  }

  /**
   * GetExpectedStartDate Method.
   * 
   * @return Date
   */
  public Date getExpectedStartDate() {
    if (expectedStartDate != null) {
      return new Date(expectedStartDate.getTime());
    } else {
      return null;
    }

  }

  /**
   * SetExpectedStartDate Method.
   * 
   */
  public void setExpectedStartDate(Date expectedStartDate) {

    if (expectedStartDate != null) {
      this.expectedStartDate = (Date) expectedStartDate.clone();
    } else {
      this.expectedStartDate = null;
    }
  }

  public Boolean getExplicitHighPrioritization() {
    return explicitHighPrioritization;
  }

  public void setExplicitHighPrioritization(Boolean explicitHighPrioritization) {
    this.explicitHighPrioritization = explicitHighPrioritization;
  }

  public Boolean getExplicitLowPrioritization() {
    return explicitLowPrioritization;
  }

  public void setExplicitLowPrioritization(Boolean explicitLowPrioritization) {
    this.explicitLowPrioritization = explicitLowPrioritization;
  }

  /**
   * GetExplicitPrioritizationDate Method.
   * 
   * @return Date
   */
  public Date getExplicitPrioritizationDate() {
    if (explicitPrioritizationDate != null) {
      return new Date(explicitPrioritizationDate.getTime());
    } else {
      return null;
    }

  }

  /**
   * SetExplicitPrioritizationDate Method.
   * 
   */
  public void setExplicitPrioritizationDate(Date explicitPrioritizationDate) {
    if (explicitPrioritizationDate != null) {
      this.explicitPrioritizationDate = (Date) explicitPrioritizationDate.clone();
    } else {
      this.explicitPrioritizationDate = null;
    }
  }

  @Override
  public String toString() {
    return "JobPriorityEntity [jobId=" + jobId + ", isSlaMapped=" + isSlaMapped + ", fileId="
        + fileId + ", employerIds=" + employerIds + ", tradingPartnerId=" + tradingPartnerId
        + ", fileTypeId=" + fileTypeId + ", direction=" + direction + ", expectedStartDate="
        + expectedStartDate + "]";
  }

}
