package com.adapt.file.service;

import com.adapt.file.entity.EnrichmentApiInfo;
import com.adapt.file.entity.SecondaryDataInfo;
import com.adapt.repository.SecondaryDataRepository;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service("secondaryDataService")
public class SecondaryDataServiceImpl implements SecondaryDataService {

  private static final Logger LOGGER = LoggerFactory.getLogger(SecondaryDataService.class);

  @Autowired
  private SecondaryDataRepository secondaryDataRepository;

  @Override
  @Cacheable(cacheNames = "secondaryApiInfoData", sync = true)
  public List<SecondaryDataInfo> getSecondaryDataInfo(Integer fileIdentifier) {

    LOGGER.debug("fileIdentifier : {} ", fileIdentifier);
    List<EnrichmentApiInfo> secondaryDataInfoEntityList =
        secondaryDataRepository.getSecondaryDataInfoEntity(fileIdentifier);
    LOGGER.debug("number of api information found {} ", secondaryDataInfoEntityList.size());
    List<SecondaryDataInfo> secondaryDataInfoApiDetail =
        new ArrayList<>(secondaryDataInfoEntityList.size());
    for (EnrichmentApiInfo enrichmentApiInfo : secondaryDataInfoEntityList) {
      SecondaryDataInfo enrichmentApiDetail = new SecondaryDataInfo();
      secondaryDataInfoApiDetail.add(enrichmentApiDetail);
      enrichmentApiDetail
          .setSecondaryDataEndpoint(enrichmentApiInfo.getEnrichmentApiMappedObjEndpoint());
      enrichmentApiDetail.setSecondaryDataPojoName(enrichmentApiInfo.getEnrichmentApiPojoName());
    }
    return secondaryDataInfoApiDetail;
  }

  @Override
  @CacheEvict(value = "secondaryApiInfoData", allEntries = true)
  public void removeSecondaryDataFromCache() {
    // intentionally blank
  }

}
