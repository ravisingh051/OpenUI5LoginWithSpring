package com.adapt.file.entity;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class JobFileEntity implements Serializable {

  private static final long serialVersionUID = -4768802292635071766L;
  @ColumnIndex(value = 0)
  private Integer jobId;

  @ColumnIndex(value = 1)
  private Date expectedDate;

  @ColumnIndex(value = 2)
  private Integer errorThreshHold;

  @ColumnIndex(value = 3)
  private Integer fileMinRecordCountAllowed;

  @ColumnIndex(value = 4)
  private String fileTransmissionName;

  @ColumnIndex(value = 5)
  private String fileType;

  @ColumnIndex(value = 6)
  private String fileFormatName;

  @ColumnIndex(value = 7)
  private String rowDelimiter;

  @ColumnIndex(value = 8)
  private String fieldDelimiter;

  @ColumnIndex(value = 9)
  private String escapeCharacter;

  @ColumnIndex(value = 10)
  private String segmentDelimiter;

  @ColumnIndex(value = 11)
  private Integer priority;

  private List<SectionAttributeEntity> sectionAttributeEntities = new ArrayList<>(0);

  @ColumnIndex(value = 12)
  private String employerIdAndClientIds;

  @ColumnIndex(value = 13)
  private Integer masterFileTemplateId;

  @ColumnIndex(value = 14)
  private Integer masterFileTemplateVersion;

  @ColumnIndex(value = 15)
  private Integer fullOrChange;

  @ColumnIndex(value = 16)
  private Integer resultsMode;

  @ColumnIndex(value = 17)
  private String testCfg;

  @ColumnIndex(value = 18)
  private Integer fileMaxRecordCountAllowed;

  @ColumnIndex(value = 19)
  private String fileProcessingErrorThresholdFormat;

  @ColumnIndex(value = 20)
  private Integer fileIdentifier;

  @ColumnIndex(value = 21)
  private Integer fileId;

  @ColumnIndex(value = 22)
  private Integer fileVersion;

  @ColumnIndex(value = 23)
  private String cloneNumberList;

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  /**
   * Gets the expected date.
   *
   * @return the expected date
   */
  public Date getExpectedDate() {
    if (expectedDate != null) {
      return new Date(expectedDate.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the expected date.
   *
   * @param expectedDate
   *          the new expected date
   */
  public void setExpectedDate(Date expectedDate) {
    if (expectedDate != null) {
      this.expectedDate = (Date) expectedDate.clone();
    } else {
      this.expectedDate = null;
    }
  }

  public Integer getErrorThreshHold() {
    return errorThreshHold;
  }

  public void setErrorThreshHold(Integer errorThreshHold) {
    this.errorThreshHold = errorThreshHold;
  }

  public Integer getFileMinRecordCountAllowed() {
    return fileMinRecordCountAllowed;
  }

  public void setFileMinRecordCountAllowed(Integer fileMinRecordCountAllowed) {
    this.fileMinRecordCountAllowed = fileMinRecordCountAllowed;
  }

  public String getFileTransmissionName() {
    return fileTransmissionName;
  }

  public void setFileTransmissionName(String fileTransmissionName) {
    this.fileTransmissionName = fileTransmissionName;
  }

  public String getFileType() {
    return fileType;
  }

  public void setFileType(String fileType) {
    this.fileType = fileType;
  }

  public String getFileFormatName() {
    return fileFormatName;
  }

  public void setFileFormatName(String fileFormatName) {
    this.fileFormatName = fileFormatName;
  }

  public String getRowDelimiter() {
    return rowDelimiter;
  }

  public void setRowDelimiter(String rowDelimiter) {
    this.rowDelimiter = rowDelimiter;
  }

  public String getFieldDelimiter() {
    return fieldDelimiter;
  }

  public void setFieldDelimiter(String fieldDelimiter) {
    this.fieldDelimiter = fieldDelimiter;
  }

  public String getEscapeCharacter() {
    return escapeCharacter;
  }

  public void setEscapeCharacter(String escapeCharacter) {
    this.escapeCharacter = escapeCharacter;
  }

  public String getSegmentDelimiter() {
    return segmentDelimiter;
  }

  public void setSegmentDelimiter(String segmentDelimiter) {
    this.segmentDelimiter = segmentDelimiter;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public List<SectionAttributeEntity> getSectionAttributeEntities() {
    return sectionAttributeEntities;
  }

  public void setSectionAttributeEntities(List<SectionAttributeEntity> sectionAttributeEntities) {
    this.sectionAttributeEntities = sectionAttributeEntities;
  }

  public String getEmployerIdAndClientIds() {
    return employerIdAndClientIds;
  }

  public void setEmployerIdAndClientIds(String employerIdAndClientIds) {
    this.employerIdAndClientIds = employerIdAndClientIds;
  }

  public Integer getMasterFileTemplateId() {
    return masterFileTemplateId;
  }

  public void setMasterFileTemplateId(Integer masterFileTemplateId) {
    this.masterFileTemplateId = masterFileTemplateId;
  }

  public Integer getMasterFileTemplateVersion() {
    return masterFileTemplateVersion;
  }

  public void setMasterFileTemplateVersion(Integer masterFileTemplateVersion) {
    this.masterFileTemplateVersion = masterFileTemplateVersion;
  }

  public Integer getFullOrChange() {
    return fullOrChange;
  }

  public void setFullOrChange(Integer fullOrChange) {
    this.fullOrChange = fullOrChange;
  }

  public Integer getResultsMode() {
    return resultsMode;
  }

  public void setResultsMode(Integer resultsMode) {
    this.resultsMode = resultsMode;
  }

  public String getTestCfg() {
    return testCfg;
  }

  public void setTestCfg(String testCfg) {
    this.testCfg = testCfg;
  }

  public Integer getFileMaxRecordCountAllowed() {
    return fileMaxRecordCountAllowed;
  }

  public void setFileMaxRecordCountAllowed(Integer fileMaxRecordCountAllowed) {
    this.fileMaxRecordCountAllowed = fileMaxRecordCountAllowed;
  }

  public String getFileProcessingErrorThresholdFormat() {
    return fileProcessingErrorThresholdFormat;
  }

  public void setFileProcessingErrorThresholdFormat(String fileProcessingErrorThresholdFormat) {
    this.fileProcessingErrorThresholdFormat = fileProcessingErrorThresholdFormat;
  }

  public Integer getFileIdentifier() {
    return fileIdentifier;
  }

  public void setFileIdentifier(Integer fileIdentifier) {
    this.fileIdentifier = fileIdentifier;
  }

  public Integer getFileId() {
    return fileId;
  }

  public void setFileId(Integer fileId) {
    this.fileId = fileId;
  }

  public Integer getFileVersion() {
    return fileVersion;
  }

  public void setFileVersion(Integer fileVersion) {
    this.fileVersion = fileVersion;
  }

  public String getCloneNumberList() {
    return cloneNumberList;
  }

  public void setCloneNumberList(String cloneNumberList) {
    this.cloneNumberList = cloneNumberList;
  }

}
