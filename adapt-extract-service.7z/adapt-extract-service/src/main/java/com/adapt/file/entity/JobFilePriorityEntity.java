package com.adapt.file.entity;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JobFilePriorityEntity implements Serializable {

  private static final long serialVersionUID = 4392028926846698744L;

  private Integer jobId;

  private Date expectedDate;

  private Integer errorThreshHold;

  private Integer fileMinRecordCountAllowed;

  private String fileTransmissionName;

  private String fileType;

  private String fileFormatName;

  private String rowDelimiter;

  private String fieldDelimiter;

  private String escapeCharacter;

  private String segmentDelimiter;

  private Integer priority;

  private List<SectionAttributeEntity> sectionAttributeEntities = new ArrayList<>(0);

  private String employerIdAndClientIdAndTestCfgs;

  private Integer masterFileTemplateId;

  private Integer masterFileTemplateVersion;

  private Integer fullOrChange;

  private Integer resultsMode;

  private Integer fileMaxRecordCountAllowed;

  private String fileProcessingErrorThresholdFormat;

  private Integer fileIdentifier;

  private Integer fileId;

  private Integer fileVersion;

  private String cloneNumberList;

  private Integer fileStateId;

  private String filePath;

  private String fileName;

  private byte[] fileStatePrivatekey;

  private String masterPrivateKey;

  private String fileNewName;

  private String direction;

  private String planSubtypes;

  private String extractionEmployerIds;

  private Integer planYear;

  private String dataSourceType;

  private String dataTargetType;

  private String systemDate;

  private String planYearAdditiveFactor;

  private String lookBackPeriod;

  private String lookAheadPeriod;

  private Integer profileId;

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  /**
   * Gets the expected date.
   *
   * @return the expected date
   */
  public Date getExpectedDate() {
    if (expectedDate != null) {
      return new Date(expectedDate.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the expected date.
   *
   * @param expectedDate
   *          the new expected date
   */
  public void setExpectedDate(Date expectedDate) {
    if (expectedDate != null) {
      this.expectedDate = (Date) expectedDate.clone();
    } else {
      this.expectedDate = null;
    }
  }

  public Integer getErrorThreshHold() {
    return errorThreshHold;
  }

  public void setErrorThreshHold(Integer errorThreshHold) {
    this.errorThreshHold = errorThreshHold;
  }

  public Integer getFileMinRecordCountAllowed() {
    return fileMinRecordCountAllowed;
  }

  public void setFileMinRecordCountAllowed(Integer fileMinRecordCountAllowed) {
    this.fileMinRecordCountAllowed = fileMinRecordCountAllowed;
  }

  public String getFileTransmissionName() {
    return fileTransmissionName;
  }

  public void setFileTransmissionName(String fileTransmissionName) {
    this.fileTransmissionName = fileTransmissionName;
  }

  public String getFileType() {
    return fileType;
  }

  public void setFileType(String fileType) {
    this.fileType = fileType;
  }

  public String getFileFormatName() {
    return fileFormatName;
  }

  public void setFileFormatName(String fileFormatName) {
    this.fileFormatName = fileFormatName;
  }

  public String getRowDelimiter() {
    return rowDelimiter;
  }

  public void setRowDelimiter(String rowDelimiter) {
    this.rowDelimiter = rowDelimiter;
  }

  public String getFieldDelimiter() {
    return fieldDelimiter;
  }

  public void setFieldDelimiter(String fieldDelimiter) {
    this.fieldDelimiter = fieldDelimiter;
  }

  public String getEscapeCharacter() {
    return escapeCharacter;
  }

  public void setEscapeCharacter(String escapeCharacter) {
    this.escapeCharacter = escapeCharacter;
  }

  public String getSegmentDelimiter() {
    return segmentDelimiter;
  }

  public void setSegmentDelimiter(String segmentDelimiter) {
    this.segmentDelimiter = segmentDelimiter;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public List<SectionAttributeEntity> getSectionAttributeEntities() {
    return sectionAttributeEntities;
  }

  public void setSectionAttributeEntities(List<SectionAttributeEntity> sectionAttributeEntities) {
    this.sectionAttributeEntities = sectionAttributeEntities;
  }

  public String getEmployerIdAndClientIdAndTestCfgs() {
    return employerIdAndClientIdAndTestCfgs;
  }

  public void setEmployerIdAndClientIdAndTestCfgs(String employerIdAndClientIdAndTestCfgs) {
    this.employerIdAndClientIdAndTestCfgs = employerIdAndClientIdAndTestCfgs;
  }

  public Integer getMasterFileTemplateId() {
    return masterFileTemplateId;
  }

  public void setMasterFileTemplateId(Integer masterFileTemplateId) {
    this.masterFileTemplateId = masterFileTemplateId;
  }

  public Integer getMasterFileTemplateVersion() {
    return masterFileTemplateVersion;
  }

  public void setMasterFileTemplateVersion(Integer masterFileTemplateVersion) {
    this.masterFileTemplateVersion = masterFileTemplateVersion;
  }

  public Integer getFullOrChange() {
    return fullOrChange;
  }

  public void setFullOrChange(Integer fullOrChange) {
    this.fullOrChange = fullOrChange;
  }

  public Integer getResultsMode() {
    return resultsMode;
  }

  public void setResultsMode(Integer resultsMode) {
    this.resultsMode = resultsMode;
  }

  public Integer getFileMaxRecordCountAllowed() {
    return fileMaxRecordCountAllowed;
  }

  public void setFileMaxRecordCountAllowed(Integer fileMaxRecordCountAllowed) {
    this.fileMaxRecordCountAllowed = fileMaxRecordCountAllowed;
  }

  public String getFileProcessingErrorThresholdFormat() {
    return fileProcessingErrorThresholdFormat;
  }

  public void setFileProcessingErrorThresholdFormat(String fileProcessingErrorThresholdFormat) {
    this.fileProcessingErrorThresholdFormat = fileProcessingErrorThresholdFormat;
  }

  public Integer getFileIdentifier() {
    return fileIdentifier;
  }

  public void setFileIdentifier(Integer fileIdentifier) {
    this.fileIdentifier = fileIdentifier;
  }

  public Integer getFileId() {
    return fileId;
  }

  public void setFileId(Integer fileId) {
    this.fileId = fileId;
  }

  public Integer getFileVersion() {
    return fileVersion;
  }

  public void setFileVersion(Integer fileVersion) {
    this.fileVersion = fileVersion;
  }

  public String getCloneNumberList() {
    return cloneNumberList;
  }

  public void setCloneNumberList(String cloneNumberList) {
    this.cloneNumberList = cloneNumberList;
  }

  public Integer getFileStateId() {
    return fileStateId;
  }

  public void setFileStateId(Integer fileStateId) {
    this.fileStateId = fileStateId;
  }

  public String getFilePath() {
    return filePath;
  }

  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getMasterPrivateKey() {
    return masterPrivateKey;
  }

  public void setMasterPrivateKey(String masterPrivateKey) {
    this.masterPrivateKey = masterPrivateKey;
  }

  public byte[] getFileStatePrivatekey() {
    return fileStatePrivatekey == null ? null : fileStatePrivatekey.clone();
  }

  public void setFileStatePrivatekey(byte[] fileStatePrivatekey) {
    this.fileStatePrivatekey = fileStatePrivatekey == null ? null : fileStatePrivatekey.clone();
  }

  public String getFileNewName() {
    return fileNewName;
  }

  public void setFileNewName(String fileNewName) {
    this.fileNewName = fileNewName;
  }

  public String getDirection() {
    return direction;
  }

  public void setDirection(String direction) {
    this.direction = direction;
  }

  public String getExtractionEmployerIds() {
    return extractionEmployerIds;
  }

  public void setExtractionEmployerIds(String extractionEmployerIds) {
    this.extractionEmployerIds = extractionEmployerIds;
  }

  public Integer getPlanYear() {
    return planYear;
  }

  public void setPlanYear(Integer planYear) {
    this.planYear = planYear;
  }

  public String getPlanSubtypes() {
    return planSubtypes;
  }

  public void setPlanSubtypes(String planSubtypes) {
    this.planSubtypes = planSubtypes;
  }

  public String getDataSourceType() {
    return dataSourceType;
  }

  public void setDataSourceType(String dataSourceType) {
    this.dataSourceType = dataSourceType;
  }

  public String getDataTargetType() {
    return dataTargetType;
  }

  public void setDataTargetType(String dataTargetType) {
    this.dataTargetType = dataTargetType;
  }

  public String getSystemDate() {
    return systemDate;
  }

  public String getPlanYearAdditiveFactor() {
    return planYearAdditiveFactor;
  }

  public String getLookBackPeriod() {
    return lookBackPeriod;
  }

  public String getLookAheadPeriod() {
    return lookAheadPeriod;
  }

  public void setSystemDate(String systemDate) {
    this.systemDate = systemDate;
  }

  public void setPlanYearAdditiveFactor(String planYearAdditiveFactor) {
    this.planYearAdditiveFactor = planYearAdditiveFactor;
  }

  public void setLookBackPeriod(String lookBackPeriod) {
    this.lookBackPeriod = lookBackPeriod;
  }

  public void setLookAheadPeriod(String lookAheadPeriod) {
    this.lookAheadPeriod = lookAheadPeriod;
  }

  public Integer getProfileId() {
    return profileId;
  }

  public void setProfileId(Integer profileId) {
    this.profileId = profileId;
  }

  @Override
  public String toString() {
    return "JobFilePriorityEntity [jobId=" + jobId + ", expectedDate=" + expectedDate
        + ", errorThreshHold=" + errorThreshHold + ", fileMinRecordCountAllowed="
        + fileMinRecordCountAllowed + ", fileTransmissionName=" + fileTransmissionName
        + ", fileType=" + fileType + ", fileFormatName=" + fileFormatName + ", rowDelimiter="
        + rowDelimiter + ", fieldDelimiter=" + fieldDelimiter + ", escapeCharacter="
        + escapeCharacter + ", segmentDelimiter=" + segmentDelimiter + ", priority=" + priority
        + ", sectionAttributeEntities=" + sectionAttributeEntities
        + ", employerIdAndClientIdAndTestCfgs=" + employerIdAndClientIdAndTestCfgs
        + ", masterFileTemplateId=" + masterFileTemplateId + ", masterFileTemplateVersion="
        + masterFileTemplateVersion + ", fullOrChange=" + fullOrChange + ", resultsMode="
        + resultsMode + ", fileMaxRecordCountAllowed=" + fileMaxRecordCountAllowed
        + ", fileProcessingErrorThresholdFormat=" + fileProcessingErrorThresholdFormat
        + ", fileIdentifier=" + fileIdentifier + ", fileId=" + fileId + ", fileVersion="
        + fileVersion + ", cloneNumberList=" + cloneNumberList + ", fileStateId=" + fileStateId
        + ", filePath=" + filePath + ", fileName=" + fileName + ", fileStatePrivatekey="
        + Arrays.toString(fileStatePrivatekey) + ", masterPrivateKey=" + masterPrivateKey
        + ", fileNewName=" + fileNewName + ", direction=" + direction + ", planSubtypes="
        + planSubtypes + ", extractionEmployerIds=" + extractionEmployerIds + ", planYear="
        + planYear + ", dataSourceType=" + dataSourceType + ", dataTargetType=" + dataTargetType
        + ", systemDate=" + systemDate + ", planYearAdditiveFactor=" + planYearAdditiveFactor
        + ", lookBackPeriod=" + lookBackPeriod + ", lookAheadPeriod=" + lookAheadPeriod
        + ", profileId=" + profileId + "]";
  }

}
