package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.event.EventFactory;
import com.adapt.event.EventMessage;
import com.adapt.event.EventTypeEnum;
import com.adapt.event.RunTimeExceptionOccurredEvent;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.util.AdaptSourceUtils;
import com.alight.adapt.header.AdaptHeader;
import com.alight.adapt.header.File;
import com.alight.idis.jobs.JobStatus;
import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.client.HttpServerErrorException;

@Component("errorHandlingTransformer")
public class ErrorHandlingTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandlingTransformer.class);
  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public ErrorHandlingTransformer() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  @Override
  protected Message<?> doTransform(Message<?> message) throws Exception {
    LOGGER.error("Error occurred in source");
    if (message != null) {
      MessagingException messagingException = (MessagingException) message.getPayload();
      if (messagingException.getCause() instanceof HttpServerErrorException) {
        LOGGER.error("Error occurred in source For HTTP Call {}",
            ((HttpServerErrorException) messagingException.getCause()).getResponseBodyAsString());
      }
      Message<?> failedMsg = messagingException.getFailedMessage();
      if (failedMsg != null) {
        MessageHeaders messageHeaders = failedMsg.getHeaders();

        if (messageHeaders.get(Constant.ADAPT_HEADER) == null) {

          return errorWithNoAdaptHeaderPresent(message, messagingException, messageHeaders);
        } else {

          return errorWithAdapterHeaderPresent(message, messagingException, messageHeaders);
        }
      } else {
        LOGGER.error("Runtime Exception Occurred in Source. {}", messagingException);
        return null;
      }
    } else {
      LOGGER.error("Runtime Exception Occurred in Source.");
      return null;
    }
  }

  private Message<?> errorWithAdapterHeaderPresent(Message<?> message,
      MessagingException messagingException, MessageHeaders messageHeaders) throws Exception {
    AdaptHeader adaptHeaderObject = jsonObjectMapper
        .fromJson(messageHeaders.get(Constant.ADAPT_HEADER), AdaptHeader.Builder.class).build();

    Integer fileId = null;
    Integer fileIdentifier = null;
    Integer fileVersion = null;
    if (adaptHeaderObject.getProcessing() != null
        && adaptHeaderObject.getProcessing().getJobId() != null) {
      LOGGER.error("adaptHeaderObject {}, Runtime Exception Occurred in Source. {}",
          adaptHeaderObject, messagingException);

      Integer jobId = adaptHeaderObject.getProcessing().getJobId();

      if (adaptHeaderObject.getProcessing().getFile() != null) {
        fileId = getFileIdFromFile(adaptHeaderObject.getProcessing().getFile());
        fileVersion = getFileVersionFromFile(adaptHeaderObject.getProcessing().getFile());
        fileIdentifier = getFileIdentifierFromFile(adaptHeaderObject.getProcessing().getFile());
      }

      RunTimeExceptionOccurredEvent runTimeExceptionOccurredEvent = createRuntimeExceptionOccurredEvent(
          jobId, fileId, fileVersion, fileIdentifier,
          AdaptSourceUtils.getSummaryOfError(messagingException.getCause()));
      MessageBuilder<?> builder = MessageBuilder.withPayload(runTimeExceptionOccurredEvent);
      builder.copyHeaders(message.getHeaders());
      message = builder.build();
      return message;
    } else {
      LOGGER.error("Runtime Exception Occurred in Source. {}", messagingException);
      return null;
    }
  }

  private Message<?> errorWithNoAdaptHeaderPresent(Message<?> message,
      MessagingException messagingException, MessageHeaders messageHeaders) {
    if (messageHeaders.get(Constant.JOB_ID_HEADER) == null
        || messageHeaders.get(Constant.FILE_IDENTIFIER) == null) {
      Assert.notNull(messagingException, "Message Exception should not null");
      Message<?> failedMessage = messagingException.getFailedMessage();
      Assert.notNull(failedMessage, "Not Find Failed Message");
      Object payload = failedMessage.getPayload();
      Assert.notNull(payload, "Not Find Payload From Failed Message");
      if (payload instanceof JobPriorityGetPayload) {
        JobPriorityGetPayload jobPriorityGetPayload = (JobPriorityGetPayload) payload;
        Assert.notNull(jobPriorityGetPayload, "jobPriorityGetPayload Should not be Null");
        if ((jobPriorityGetPayload.getJobFilePriorityEntity() != null)
            && (jobPriorityGetPayload.getJobFilePriorityEntity().getJobId() != null
                || jobPriorityGetPayload.getJobFilePriorityEntity().getFileIdentifier() != null)) {
          LOGGER.error("Runtime Exception Occurred in Source Job Details Found. {}",
              messagingException);
          RunTimeExceptionOccurredEvent runTimeExceptionOccurredEvent = createRuntimeExceptionOccurredEvent(
              jobPriorityGetPayload.getJobFilePriorityEntity().getJobId(),
              jobPriorityGetPayload.getJobFilePriorityEntity().getFileId(),
              jobPriorityGetPayload.getJobFilePriorityEntity().getFileVersion(),
              jobPriorityGetPayload.getJobFilePriorityEntity().getFileIdentifier(),
              AdaptSourceUtils.getSummaryOfError(messagingException.getCause()));
          MessageBuilder<?> builder = MessageBuilder.withPayload(runTimeExceptionOccurredEvent);
          builder.copyHeaders(message.getHeaders());
          message = builder.build();
          return message;
        } else {
          LOGGER.error("Runtime Exception Occurred in Source and Job Details Not Found. {}",
              messagingException);
        }

      } else {
        LOGGER.error("Runtime Exception Occurred in Source and Job Details Not Found. {}",
            messagingException);
      }

      return null;
    } else {
      LOGGER.error("Runtime Exception Occurred in Source Job Details Found. {}",
          messagingException);
      Integer jobId = AdaptSourceUtils.getJobIdFromHeader(messageHeaders);
      Integer fileId = AdaptSourceUtils.getFileIdFromHeader(messageHeaders);
      Integer fileVersion = AdaptSourceUtils.getFileVersionFromHeader(messageHeaders);
      Integer fileIdentifier = AdaptSourceUtils.getFileIdentifierFromHeader(messageHeaders);
      RunTimeExceptionOccurredEvent runTimeExceptionOccurredEvent = createRuntimeExceptionOccurredEvent(
          jobId, fileId, fileVersion, fileIdentifier,
          AdaptSourceUtils.getSummaryOfError(messagingException.getCause()));
      MessageBuilder<?> builder = MessageBuilder.withPayload(runTimeExceptionOccurredEvent);
      builder.copyHeaders(message.getHeaders());
      message = builder.build();
      return message;
    }
  }

  private RunTimeExceptionOccurredEvent createRuntimeExceptionOccurredEvent(Integer jobId,
      Integer fileId, Integer fileVersion, Integer fileIdentifier, String errorMessage) {

    RunTimeExceptionOccurredEvent runTimeExceptionOccurredEvent = (RunTimeExceptionOccurredEvent) EventFactory
        .getEventType(EventTypeEnum.RUNTIME_EXCEPTION_OCCURRED);
    runTimeExceptionOccurredEvent.setFileId(fileId);
    runTimeExceptionOccurredEvent.setFileVersion(fileVersion);
    runTimeExceptionOccurredEvent.setFileIdentifier(fileIdentifier);
    runTimeExceptionOccurredEvent.setJobId(jobId);
    runTimeExceptionOccurredEvent.setEventType(EventTypeEnum.RUNTIME_EXCEPTION_OCCURRED.name());
    runTimeExceptionOccurredEvent.setTime(LocalDateTime.now());
    EventMessage eventMessage = new EventMessage();
    eventMessage.setMessage(errorMessage);
    runTimeExceptionOccurredEvent.setMessage(eventMessage);
    runTimeExceptionOccurredEvent.setJobStatus(JobStatus.FAILED.getValue());
    return runTimeExceptionOccurredEvent;
  }

  private Integer getFileIdFromFile(File file) {
    if (file.getFileId() != null) {
      return file.getFileId();
    }
    return null;
  }

  private Integer getFileVersionFromFile(File file) {
    if (file.getFileVersion() != null) {
      return file.getFileVersion();
    }
    return null;
  }

  private Integer getFileIdentifierFromFile(File file) {
    if (file.getFileIdentifier() != null) {
      return file.getFileIdentifier();
    }
    return null;
  }

}
