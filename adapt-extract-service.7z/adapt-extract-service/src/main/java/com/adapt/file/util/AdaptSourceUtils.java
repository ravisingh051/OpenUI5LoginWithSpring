package com.adapt.file.util;

import com.adapt.config.Constant;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageHeaders;
import org.springframework.web.client.HttpServerErrorException;

public class AdaptSourceUtils {

  private static final Logger LOGGER = LoggerFactory.getLogger(AdaptSourceUtils.class);
  private static final Integer ERROR_LENGTH = 2;

  private AdaptSourceUtils() {
  }

  /**
   * Gets the summary of error.
   *
   * @param t
   *          the t
   * @return the summary of error
   */
  public static String getSummaryOfError(Throwable t) {

    String errorDetail = "";
    if (t instanceof HttpServerErrorException) {
      errorDetail = ((HttpServerErrorException) t).getResponseBodyAsString();
    } else {
      String[] traceFrames = ExceptionUtils.getStackFrames(t);
      int length = traceFrames.length > ERROR_LENGTH ? ERROR_LENGTH : traceFrames.length;
      if (length > 0) {
        StringBuilder sb = new StringBuilder();
        // getting first 2 lines
        for (int i = 0; i < length; i++) {
          sb.append(traceFrames[i]);
        }
        errorDetail = sb.toString();
      } else {
        LOGGER.debug("No Stack Trace found for Exception");
      }
    }

    return errorDetail;
  }

  /**
   * Gets the job id from header.
   *
   * @param messageHeaders
   *          the message headers
   * @return the job id from header
   */
  public static Integer getJobIdFromHeader(MessageHeaders messageHeaders) {
    if (messageHeaders.get(Constant.JOB_ID_HEADER) != null) {
      return (Integer) messageHeaders.get(Constant.JOB_ID_HEADER);
    }
    return null;
  }

  /**
   * Gets the file id from header.
   *
   * @param messageHeaders
   *          the message headers
   * @return the file id from header
   */
  public static Integer getFileIdFromHeader(MessageHeaders messageHeaders) {
    if (messageHeaders.get(Constant.FILE_ID) != null) {
      return (Integer) messageHeaders.get(Constant.FILE_ID);
    }
    return null;
  }

  /**
   * Gets the file version from header.
   *
   * @param messageHeaders
   *          the message headers
   * @return the file version from header
   */
  public static Integer getFileVersionFromHeader(MessageHeaders messageHeaders) {
    if (messageHeaders.get(Constant.FILE_VERSION) != null) {
      return (Integer) messageHeaders.get(Constant.FILE_VERSION);
    }
    return null;
  }

  /**
   * Gets the file identifier from header.
   *
   * @param messageHeaders
   *          the message headers
   * @return the file identifier from header
   */
  public static Integer getFileIdentifierFromHeader(MessageHeaders messageHeaders) {
    if (messageHeaders.get(Constant.FILE_IDENTIFIER) != null) {
      return (Integer) messageHeaders.get(Constant.FILE_IDENTIFIER);
    }
    return null;
  }

  /**
   * Gets the current date.
   *
   * @return the current date
   */
  public static String getCurrentDate() {
    return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
  }

}
