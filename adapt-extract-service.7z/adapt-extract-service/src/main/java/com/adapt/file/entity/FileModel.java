package com.adapt.file.entity;

import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import java.io.Serializable;
import java.util.List;

public class FileModel implements Serializable {

  private static final long serialVersionUID = 5139534521708674417L;

  private String fileTransmissionName;
  private Integer errorThreshold;
  private MessageFormat messageFormat;
  private MessageType fileType;
  private List<Section> sections;
  private Integer masterFileTemplateId;
  private Integer masterFileTemplateVersion;
  private Boolean resultsMode;
  private Integer fileMaxRecordCountAllowed;
  private Integer fileMinRecordCountAllowed;
  private FileProcessingErrorThresholdFormat fileProcessingErrorThresholdFormat;
  private Integer fileIdentifier;
  private Integer fileId;
  private Integer fileVersion;

  public Integer getFileVersion() {
    return fileVersion;
  }

  public void setFileVersion(Integer fileVersion) {
    this.fileVersion = fileVersion;
  }

  public Integer getFileId() {
    return fileId;
  }

  public void setFileId(Integer fileId) {
    this.fileId = fileId;
  }

  public Integer getMasterFileTemplateId() {
    return masterFileTemplateId;
  }

  public void setMasterFileTemplateId(Integer masterFileTemplateId) {
    this.masterFileTemplateId = masterFileTemplateId;
  }

  public Integer getMasterFileTemplateVersion() {
    return masterFileTemplateVersion;
  }

  public void setMasterFileTemplateVersion(Integer masterFileTemplateVersion) {
    this.masterFileTemplateVersion = masterFileTemplateVersion;
  }

  public String getFileTransmissionName() {
    return fileTransmissionName;
  }

  public void setFileTransmissionName(String fileTransmissionName) {
    this.fileTransmissionName = fileTransmissionName;
  }

  public Integer getErrorThreshold() {
    return errorThreshold;
  }

  public void setErrorThreshold(Integer errorThreshold) {
    this.errorThreshold = errorThreshold;
  }

  public MessageFormat getMessageFormat() {
    return messageFormat;
  }

  public void setMessageFormat(MessageFormat messageFormat) {
    this.messageFormat = messageFormat;
  }

  public MessageType getFileType() {
    return fileType;
  }

  public void setFileType(MessageType fileType) {
    this.fileType = fileType;
  }

  public List<Section> getSections() {
    return sections;
  }

  public void setSections(List<Section> sections) {
    this.sections = sections;
  }

  public Boolean getResultsMode() {
    return resultsMode;
  }

  public void setResultsMode(Boolean resultsMode) {
    this.resultsMode = resultsMode;
  }

  public Integer getFileMaxRecordCountAllowed() {
    return fileMaxRecordCountAllowed;
  }

  public void setFileMaxRecordCountAllowed(Integer fileMaxRecordCountAllowed) {
    this.fileMaxRecordCountAllowed = fileMaxRecordCountAllowed;
  }

  public Integer getFileMinRecordCountAllowed() {
    return fileMinRecordCountAllowed;
  }

  public void setFileMinRecordCountAllowed(Integer fileMinRecordCountAllowed) {
    this.fileMinRecordCountAllowed = fileMinRecordCountAllowed;
  }

  public FileProcessingErrorThresholdFormat getFileProcessingErrorThresholdFormat() {
    return fileProcessingErrorThresholdFormat;
  }

  public void setFileProcessingErrorThresholdFormat(
      FileProcessingErrorThresholdFormat fileProcessingErrorThresholdFormat) {
    this.fileProcessingErrorThresholdFormat = fileProcessingErrorThresholdFormat;
  }

  public Integer getFileIdentifier() {
    return fileIdentifier;
  }

  public void setFileIdentifier(Integer fileIdentifier) {
    this.fileIdentifier = fileIdentifier;
  }

}
