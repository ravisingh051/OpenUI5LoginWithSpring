package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.event.DatasetCountExceedOccurred;
import com.adapt.event.DatasetCountSubceedOccurred;
import com.adapt.event.EventFactory;
import com.adapt.event.EventMessage;
import com.adapt.event.EventTypeEnum;
import com.adapt.event.InboundFileOccurred;
import com.adapt.event.JobCompletedOccurredEvent;
import com.adapt.file.service.EventNotificationService;
import com.alight.idis.jobs.JobStatus;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

@Component("notificationEventService")
@Slf4j
public class NotificationEventService {

  @Autowired
  private EventNotificationService eventNotificationService;

  public static final String COUNT_SUBCEEDED_MESSAGE =
      "Failed due to minimum records not present, expected minimum record {0} and total records are {1}";
  public static final String COUNT_EXCEEDED_MESSAGE =
      "Failed due to maximum records exceeded, expected maximum records {0} and total records are {1}";

  /**
   * Send Event Notification.
   *
   * @param message
   *          the message
   */
  public Message<?> sendInboundFileOccured(Message<?> message) {

    MessageHeaders messageHeaders = message.getHeaders();
    Object jobId = messageHeaders.get(Constant.JOB_ID_HEADER);
    Object fileId = messageHeaders.get(Constant.FILE_ID);
    Object fileVersion = messageHeaders.get(Constant.FILE_VERSION);
    Object fileIdentifier = messageHeaders.get(Constant.FILE_IDENTIFIER);
    InboundFileOccurred inboundFileOccurred =
        (InboundFileOccurred) EventFactory.getEventType(EventTypeEnum.INBOUND_FILE_OCCURRED);
    inboundFileOccurred.setFileId((Integer) fileId);
    inboundFileOccurred.setJobId((Integer) jobId);
    inboundFileOccurred.setFileVersion((Integer) fileVersion);
    inboundFileOccurred.setFileIdentifier((Integer) fileIdentifier);
    inboundFileOccurred.setEventType(EventTypeEnum.INBOUND_FILE_OCCURRED.name());
    log.debug("Sending INBOUND_FILE_OCCURRED Event");
    eventNotificationService.sendInboundFileOccuredNotification(inboundFileOccurred);
    return message;

  }

  /**
   * Send dataset count subceeded occurred.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> sendDatasetCountSubceededOccurred(Message<?> message) {
    MessageHeaders messageHeaders = message.getHeaders();
    Object jobId = messageHeaders.get(Constant.JOB_ID_HEADER);
    Object fileId = messageHeaders.get(Constant.FILE_ID);
    Object totalFileRecords = messageHeaders.get(Constant.FILE_RECORD_COUNT);
    Object fileMinRecordCountAllowed = messageHeaders.get(Constant.FILE_MIN_RECORD_COUNT_ALLOWED);
    EventMessage eventMessage = new EventMessage();
    String messageDetails =
        MessageFormat.format(COUNT_SUBCEEDED_MESSAGE, fileMinRecordCountAllowed, totalFileRecords);
    eventMessage.setMessage(messageDetails);
    DatasetCountSubceedOccurred datasetCountSubceedOccurred =
        (DatasetCountSubceedOccurred) EventFactory
            .getEventType(EventTypeEnum.DATASET_COUNT_SUBCEEDED_OCCURRED);
    datasetCountSubceedOccurred.setFileId((Integer) fileId);
    datasetCountSubceedOccurred.setJobId((Integer) jobId);

    Object fileIdentifier = messageHeaders.get(Constant.FILE_IDENTIFIER);
    datasetCountSubceedOccurred.setFileIdentifier((Integer) fileIdentifier);

    Object fileVersion = messageHeaders.get(Constant.FILE_VERSION);
    datasetCountSubceedOccurred.setFileVersion((Integer) fileVersion);
    datasetCountSubceedOccurred.setMessage(eventMessage);
    datasetCountSubceedOccurred.setEventType(EventTypeEnum.DATASET_COUNT_SUBCEEDED_OCCURRED.name());
    datasetCountSubceedOccurred.setTime(LocalDateTime.now());
    log.debug("Sending DATASET_COUNT_SUBCEEDED_OCCURRED Event");
    eventNotificationService.sendCountSubceededOccurredNotification(datasetCountSubceedOccurred);
    return message;
  }

  /**
   * Send count exceeded occurred notification.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> sendCountExceededOccurredNotification(Message<?> message) {
    MessageHeaders messageHeaders = message.getHeaders();
    Object jobId = messageHeaders.get(Constant.JOB_ID_HEADER);
    Object fileId = messageHeaders.get(Constant.FILE_ID);
    Object totalFileRecords = messageHeaders.get(Constant.FILE_RECORD_COUNT);
    Object fileMaxRecordCountAllowed = messageHeaders.get(Constant.FILE_MAX_RECORD_COUNT_ALLOWED);
    EventMessage eventMessage = new EventMessage();
    String messageDetails =
        MessageFormat.format(COUNT_EXCEEDED_MESSAGE, fileMaxRecordCountAllowed, totalFileRecords);
    eventMessage.setMessage(messageDetails);

    DatasetCountExceedOccurred datasetCountExceedOccurred =
        (DatasetCountExceedOccurred) EventFactory
            .getEventType(EventTypeEnum.DATASET_COUNT_EXCEEDED_OCCURRED);

    datasetCountExceedOccurred.setFileId((Integer) fileId);
    datasetCountExceedOccurred.setJobId((Integer) jobId);

    Object fileIdentifier = messageHeaders.get(Constant.FILE_IDENTIFIER);
    datasetCountExceedOccurred.setFileIdentifier((Integer) fileIdentifier);

    Object fileVersion = messageHeaders.get(Constant.FILE_VERSION);
    datasetCountExceedOccurred.setFileVersion((Integer) fileVersion);
    datasetCountExceedOccurred.setMessage(eventMessage);
    datasetCountExceedOccurred.setEventType(EventTypeEnum.DATASET_COUNT_EXCEEDED_OCCURRED.name());
    datasetCountExceedOccurred.setTime(LocalDateTime.now());
    log.debug("Sending DATASET_COUNT_EXCEEDED_OCCURRED Event");
    eventNotificationService.sendCountExceededOccurredNotification(datasetCountExceedOccurred);
    return message;
  }

  /**
   * Send job completed occurred.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> sendJobCompletedOccurred(Message<?> message) {

    MessageHeaders messageHeaders = message.getHeaders();
    Object jobId = messageHeaders.get(Constant.JOB_ID_HEADER);
    Object fileId = messageHeaders.get(Constant.FILE_ID);
    Object fileVersion = messageHeaders.get(Constant.FILE_VERSION);
    Object fileIdentifier = messageHeaders.get(Constant.FILE_IDENTIFIER);
    JobCompletedOccurredEvent jobCompletedOccurredEvent =
        (JobCompletedOccurredEvent) EventFactory.getEventType(EventTypeEnum.JOB_COMPLETED);
    jobCompletedOccurredEvent.setFileId((Integer) fileId);
    jobCompletedOccurredEvent.setJobId((Integer) jobId);
    jobCompletedOccurredEvent.setFileVersion((Integer) fileVersion);
    jobCompletedOccurredEvent.setFileIdentifier((Integer) fileIdentifier);
    jobCompletedOccurredEvent.setEventType(EventTypeEnum.JOB_COMPLETED.name());
    jobCompletedOccurredEvent.setJobStatus(JobStatus.COMPLETED.getValue());
    jobCompletedOccurredEvent.setNotificationFlag(Boolean.FALSE);
    log.debug("Sending JOB_COMPLETED Event");
    eventNotificationService.sendJobCompletedEvent(jobCompletedOccurredEvent);
    return message;

  }

}
