package com.adapt.file.messaging;

import com.adapt.exception.NullResponseException;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service("gatewayNullResponseServiceActivator")
public class GatewayNullResponseServiceActivator {

  /**
   * Handle gateway null response.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> handleGatewayNullResponse(Message<?> message) {

    throw new NullResponseException("Null Response From Gateway");

  }
}
