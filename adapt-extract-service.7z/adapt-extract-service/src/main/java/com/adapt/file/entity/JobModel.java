package com.adapt.file.entity;

import com.adapt.file.entity.Section.SectionType;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class JobModel implements Serializable {

  private static final long serialVersionUID = 4834973237692007399L;
  private Integer jobId;
  private LocalDate expectedDate;
  private Integer priority;
  private FileModel fileModel;
  private Integer employerId;
  private String clientId;
  private String testCfgConfig;
  private Boolean fullOrChange;
  private List<Integer> cloneNumberList;
  private String sourceType;
  private String targetType;
  private Integer profileId;

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public LocalDate getExpectedDate() {
    return expectedDate;
  }

  public void setExpectedDate(LocalDate expectedDate) {
    this.expectedDate = expectedDate;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public FileModel getFileModel() {
    return fileModel;
  }

  public void setFileModel(FileModel fileModel) {
    this.fileModel = fileModel;
  }

  public Integer getEmployerId() {
    return employerId;
  }

  public void setEmployerId(Integer employerId) {
    this.employerId = employerId;
  }

  public Boolean getFullOrChange() {
    return fullOrChange;
  }

  public void setFullOrChange(Boolean fullOrChange) {
    this.fullOrChange = fullOrChange;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getTestCfgConfig() {
    return testCfgConfig;
  }

  public void setTestCfgConfig(String testCfgConfig) {
    this.testCfgConfig = testCfgConfig;
  }

  public boolean headerConfigured() {
    return sectionTypeConfigured(SectionType.HEADER);
  }

  public boolean trailerConfigured() {
    return sectionTypeConfigured(SectionType.TRAILER);
  }

  private boolean sectionTypeConfigured(SectionType sectionType) {
    List<Section> sections = fileModel.getSections();
    for (Section section : sections) {
      if (section.getSectionType().equals(sectionType)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Find attributes by section type.
   *
   * @param sectionType
   *          the section type
   * @return the attributes
   */
  public Attributes findAttributesBySectionType(SectionType sectionType) {
    List<Section> sections = fileModel.getSections();
    for (Section section : sections) {
      if (section.getSectionType().equals(sectionType)) {
        return section.getAttributes();
      }
    }
    return null;
  }

  public List<Integer> getCloneNumberList() {
    return cloneNumberList;
  }

  public void setCloneNumberList(List<Integer> cloneNumberList) {
    this.cloneNumberList = cloneNumberList;
  }

  public String getSourceType() {
    return sourceType;
  }

  public void setSourceType(String sourceType) {
    this.sourceType = sourceType;
  }

  public String getTargetType() {
    return targetType;
  }

  public void setTargetType(String targetType) {
    this.targetType = targetType;
  }

  public Integer getProfileId() {
    return profileId;
  }

  public void setProfileId(Integer profileId) {
    this.profileId = profileId;
  }

}
