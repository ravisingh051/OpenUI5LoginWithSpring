package com.adapt.file.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the job_prioritization_audit database table.
 * 
 */
@Entity
@Table(name = "job_prioritization_audit")
public class JobPrioritizationAudit implements Serializable {

  private static final long serialVersionUID = -6086231909706763791L;

  @Id
  @Column(name = "job_prioritization_audit_id")
  private Integer jobPrioritizationAuditId;

  @Column(name = "job_prioritization_status")
  private String jobPrioritizationStatus;

  @Column(name = "job_prioritization_start_time")
  private Date jobPrioritizationStartTime;

  @Column(name = "job_prioritization_end_time")
  private Date jobPrioritizationEndTime;

  @Column(name = "source_instance")
  private String sourceInstance;

  @Column(name = "created_date_time")
  private Date createdDateTime;

  @Column(name = "updated_by")
  private String updatedBy;

  @Column(name = "updated_date_time")
  private Date updatedDateTime;

  public Integer getJobPrioritizationAuditId() {
    return jobPrioritizationAuditId;
  }

  public void setJobPrioritizationAuditId(Integer jobPrioritizationAuditId) {
    this.jobPrioritizationAuditId = jobPrioritizationAuditId;
  }

  public String getJobPrioritizationStatus() {
    return jobPrioritizationStatus;
  }

  public void setJobPrioritizationStatus(String jobPrioritizationStatus) {
    this.jobPrioritizationStatus = jobPrioritizationStatus;
  }

  /**
   * getJobPrioritizationStartTime Method.
   * 
   * @return Date
   * 
   */
  public Date getJobPrioritizationStartTime() {

    if (jobPrioritizationStartTime != null) {
      return new Date(jobPrioritizationStartTime.getTime());
    } else {
      return null;
    }
  }

  /**
   * setJobPrioritizationStartTime Method.
   * 
   * @param Date
   * 
   */
  public void setJobPrioritizationStartTime(Date jobPrioritizationStartTime) {
    if (jobPrioritizationStartTime != null) {
      this.jobPrioritizationStartTime = (Date) jobPrioritizationStartTime.clone();
    } else {
      this.jobPrioritizationStartTime = null;
    }
  }

  /**
   * getJobPrioritizationEndTime Method.
   * 
   * @return Date
   * 
   */
  public Date getJobPrioritizationEndTime() {
    if (jobPrioritizationEndTime != null) {
      return new Date(jobPrioritizationEndTime.getTime());
    } else {
      return null;
    }
  }

  /**
   * setJobPrioritizationEndTime Method.
   * 
   * @param Date
   * 
   */
  public void setJobPrioritizationEndTime(Date jobPrioritizationEndTime) {
    if (jobPrioritizationEndTime != null) {
      this.jobPrioritizationEndTime = (Date) jobPrioritizationEndTime.clone();
    } else {
      this.jobPrioritizationEndTime = null;
    }
  }

  public String getSourceInstance() {
    return sourceInstance;
  }

  public void setSourceInstance(String sourceInstance) {
    this.sourceInstance = sourceInstance;
  }

  /**
   * GetCreatedDateTime Method.
   * 
   * @return Date
   * 
   */
  public Date getCreatedDateTime() {
    if (createdDateTime != null) {
      return new Date(createdDateTime.getTime());
    } else {
      return null;
    }
  }

  /**
   * SetCreatedDateTime Method.
   * 
   * @param Date
   * 
   */
  public void setCreatedDateTime(Date createdDateTime) {
    if (createdDateTime != null) {
      this.createdDateTime = (Date) createdDateTime.clone();
    } else {
      this.createdDateTime = null;
    }
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * GetUpdatedDateTime Method.
   * 
   * @return Date
   * 
   */
  public Date getUpdatedDateTime() {
    if (updatedDateTime != null) {
      return new Date(updatedDateTime.getTime());
    } else {
      return null;
    }
  }

  /**
   * SetUpdatedDateTime Method.
   * 
   * @param Date
   * 
   */
  public void setUpdatedDateTime(Date updatedDateTime) {
    if (updatedDateTime != null) {
      this.updatedDateTime = (Date) updatedDateTime.clone();
    } else {
      this.updatedDateTime = null;
    }
  }

}
