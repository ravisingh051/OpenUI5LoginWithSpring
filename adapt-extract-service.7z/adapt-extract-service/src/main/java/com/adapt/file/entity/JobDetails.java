package com.adapt.file.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the job_details database table.
 * 
 */
@Entity
@Table(name = "job_details")
public class JobDetails implements Serializable {

  private static final long serialVersionUID = 2408866663677799274L;

  @Id
  @Column(name = "job_id")
  private Integer jobId;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "file_data_extraction_mode")
  private String fileDataExtractionMode;

  @Column(name = "file_processing_priority")
  private Integer fileProcessingPriority;

  @Column(name = "job_actual_start_datetime")
  private Date jobActualStartDatetime;

  @Column(name = "job_completion_datetime")
  private Date jobCompletionDatetime;

  @Column(name = "job_creation_datetime")
  private Date jobCreationDatetime;

  @Column(name = "job_expected_start_datetime")
  private Date jobExpectedStartDatetime;

  @Column(name = "job_status")
  private String jobStatus;

  @Column(name = "total_error_records")
  private Integer totalErrorRecords;

  @Column(name = "total_records_processed_adapt")
  private Integer totalRecordsProcessedAdapt;

  @Column(name = "total_records_in_file")
  private Integer totalRecordsInFile;

  @Column(name = "updated_by")
  private String updatedBy;

  @Column(name = "updated_date")
  private Date updatedDate;

  @Column(name = "total_warning_records")
  private Integer totalWarningRecords;

  @Column(name = "total_ignored_records")
  private Integer totalIgnoredRecords;

  @Column(name = "job_status_details")
  private String jobStatusDetails;

  @Column(name = "explicit_high_prioritization")
  private Boolean explicitHighPrioritization;

  @Column(name = "explicit_low_prioritization")
  private Boolean explicitLowPrioritization;

  @Column(name = "job_soft_deleted")
  private Boolean jobSoftDeleted;

  @Column(name = "explicit_prioritization_date")
  private Date explicitPrioritizationDate;

  // NOTE: we are not added FileIdGenerator and FileProcessingSchedule entity as from inbound engine
  // should not update this.

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getFileDataExtractionMode() {
    return fileDataExtractionMode;
  }

  public void setFileDataExtractionMode(String fileDataExtractionMode) {
    this.fileDataExtractionMode = fileDataExtractionMode;
  }

  public Integer getFileProcessingPriority() {
    return fileProcessingPriority;
  }

  public void setFileProcessingPriority(Integer fileProcessingPriority) {
    this.fileProcessingPriority = fileProcessingPriority;
  }

  /**
   * Gets the job actual start datetime.
   *
   * @return the job actual start datetime
   */
  public Date getJobActualStartDatetime() {
    if (jobActualStartDatetime != null) {
      return new Date(jobActualStartDatetime.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the job actual start datetime.
   *
   * @param jobActualStartDatetime
   *          the new job actual start datetime
   */
  public void setJobActualStartDatetime(Date jobActualStartDatetime) {
    if (jobActualStartDatetime != null) {
      this.jobActualStartDatetime = (Date) jobActualStartDatetime.clone();
    } else {
      this.jobActualStartDatetime = null;
    }
  }

  /**
   * Gets the job completion datetime.
   *
   * @return the job completion datetime
   */
  public Date getJobCompletionDatetime() {
    if (jobCompletionDatetime != null) {
      return new Date(jobCompletionDatetime.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the job completion datetime.
   *
   * @param jobCompletionDatetime
   *          the new job completion datetime
   */
  public void setJobCompletionDatetime(Date jobCompletionDatetime) {
    if (jobCompletionDatetime != null) {
      this.jobCompletionDatetime = (Date) jobCompletionDatetime.clone();
    } else {
      this.jobCompletionDatetime = null;
    }
  }

  /**
   * Gets the job creation datetime.
   *
   * @return the job creation datetime
   */
  public Date getJobCreationDatetime() {
    if (jobCreationDatetime != null) {
      return new Date(jobCreationDatetime.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the job creation datetime.
   *
   * @param jobCreationDatetime
   *          the new job creation datetime
   */
  public void setJobCreationDatetime(Date jobCreationDatetime) {
    if (jobCreationDatetime != null) {
      this.jobCreationDatetime = (Date) jobCreationDatetime.clone();
    } else {
      this.jobCreationDatetime = null;
    }
  }

  /**
   * Gets the job expected start datetime.
   *
   * @return the job expected start datetime
   */
  public Date getJobExpectedStartDatetime() {
    if (jobExpectedStartDatetime != null) {
      return new Date(jobExpectedStartDatetime.getTime());
    } else {
      return null;
    }

  }

  /**
   * Sets the job expected start datetime.
   *
   * @param jobExpectedStartDatetime
   *          the new job expected start datetime
   */
  public void setJobExpectedStartDatetime(Date jobExpectedStartDatetime) {
    if (jobExpectedStartDatetime != null) {
      this.jobExpectedStartDatetime = (Date) jobExpectedStartDatetime.clone();
    } else {
      this.jobExpectedStartDatetime = null;
    }
  }

  public String getJobStatus() {
    return jobStatus;
  }

  public void setJobStatus(String jobStatus) {
    this.jobStatus = jobStatus;
  }

  public Integer getTotalErrorRecords() {
    return totalErrorRecords;
  }

  public void setTotalErrorRecords(Integer totalErrorRecords) {
    this.totalErrorRecords = totalErrorRecords;
  }

  public Integer getTotalRecordsProcessedAdapt() {
    return totalRecordsProcessedAdapt;
  }

  public void setTotalRecordsProcessedAdapt(Integer totalRecordsProcessedAdapt) {
    this.totalRecordsProcessedAdapt = totalRecordsProcessedAdapt;
  }

  public Integer getTotalRecordsInFile() {
    return totalRecordsInFile;
  }

  public void setTotalRecordsInFile(Integer totalRecordsInFile) {
    this.totalRecordsInFile = totalRecordsInFile;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * Gets the updated date.
   *
   * @return the updated date
   */
  public Date getUpdatedDate() {
    if (updatedDate != null) {
      return new Date(updatedDate.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate
   *          the new updated date
   */
  public void setUpdatedDate(Date updatedDate) {
    if (updatedDate != null) {
      this.updatedDate = (Date) updatedDate.clone();
    } else {
      this.updatedDate = null;
    }
  }

  public Integer getTotalWarningRecords() {
    return totalWarningRecords;
  }

  public void setTotalWarningRecords(Integer totalWarningRecords) {
    this.totalWarningRecords = totalWarningRecords;
  }

  public Integer getTotalIgnoredRecords() {
    return totalIgnoredRecords;
  }

  public void setTotalIgnoredRecords(Integer totalIgnoredRecords) {
    this.totalIgnoredRecords = totalIgnoredRecords;
  }

  public String getJobStatusDetails() {
    return jobStatusDetails;
  }

  public void setJobStatusDetails(String jobStatusDetails) {
    this.jobStatusDetails = jobStatusDetails;
  }

  public Boolean getExplicitHighPrioritization() {
    return explicitHighPrioritization;
  }

  public void setExplicitHighPrioritization(Boolean explicitHighPrioritization) {
    this.explicitHighPrioritization = explicitHighPrioritization;
  }

  public Boolean getExplicitLowPrioritization() {
    return explicitLowPrioritization;
  }

  public void setExplicitLowPrioritization(Boolean explicitLowPrioritization) {
    this.explicitLowPrioritization = explicitLowPrioritization;
  }

  public Boolean getJobSoftDeleted() {
    return jobSoftDeleted;
  }

  public void setJobSoftDeleted(Boolean jobSoftDeleted) {
    this.jobSoftDeleted = jobSoftDeleted;
  }

  /**
   * Gets the explicit prioritization date.
   *
   * @return the explicit prioritization date
   */
  public Date getExplicitPrioritizationDate() {
    if (explicitPrioritizationDate != null) {
      return new Date(explicitPrioritizationDate.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the explicit prioritization date.
   *
   * @param explicitPrioritizationDate
   *          the new explicit prioritization date
   */
  public void setExplicitPrioritizationDate(Date explicitPrioritizationDate) {
    if (explicitPrioritizationDate != null) {
      this.explicitPrioritizationDate = (Date) explicitPrioritizationDate.clone();
    } else {
      this.explicitPrioritizationDate = null;
    }
  }

}
