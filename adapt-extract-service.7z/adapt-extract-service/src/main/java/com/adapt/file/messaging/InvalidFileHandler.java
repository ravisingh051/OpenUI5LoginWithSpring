package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.InvalidMessage;
import com.adapt.file.entity.JobDetailsDto;
import com.adapt.file.entity.JobModel;
import com.adapt.file.service.JobService;
import com.alight.idis.jobs.JobStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("invalidFileHandler")
public class InvalidFileHandler {

  private static final Logger LOGGER = LoggerFactory.getLogger(InvalidFileHandler.class);

  @Autowired
  private JobService jobService;

  /**
   * Update job status with Failed Status.
   *
   * @param message
   *          the message
   */
  public Message<?> updateJobStatus(Message<?> message) {
    LOGGER.info("File Processing Stopped Due to Min / Max Validation Failed");
    Assert.notNull(message, "Message should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "headers should not be null");
    JobModel jobModel = (JobModel) headers.get(Constant.JOB_MODEL_HEADER);
    Assert.notNull(jobModel, "jobModel should not be null");
    Integer jobId = jobModel.getJobId();
    if (jobId == null) {
      LOGGER.error("Cannot update job status with Job Id : null");
      throw new InvalidMessage("Cannot update job status with Job Id : null");
    } else {
      JobDetailsDto jobDetailsDto = new JobDetailsDto();
      jobDetailsDto.setJobId(jobId);
      jobDetailsDto.setTotalErrorCount(0);
      jobDetailsDto.setTotalProcessedCount(0);
      jobDetailsDto.setTotalWarningCount(0);
      Integer totalRecordsInFile = (Integer) headers.get(Constant.FILE_RECORD_COUNT);
      jobDetailsDto.setTotalRecordsInFile(totalRecordsInFile);
      jobDetailsDto.setJobStatus(JobStatus.FAILED);
      jobService.updateJobStatus(jobDetailsDto);
    }
    return message;
  }
}
