package com.adapt.file.service;

import com.adapt.api.config.ExtractionHelper;
import com.adapt.config.EndPointConfigurationHelper;
import com.adapt.file.entity.Attribute;
import com.adapt.file.entity.Attributes;
import com.adapt.file.entity.EmployerInfo;
import com.adapt.file.entity.FileModel;
import com.adapt.file.entity.FileOutBoundModel;
import com.adapt.file.entity.JobDetails;
import com.adapt.file.entity.JobDetailsDto;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.entity.MessageFormat;
import com.adapt.file.entity.MessageFormatType;
import com.adapt.file.entity.MessageType;
import com.adapt.file.entity.Section;
import com.adapt.file.entity.Section.SectionType;
import com.adapt.file.entity.SectionAttributeEntity;
import com.adapt.repository.JobDetailsCrudRepository;
import com.adapt.repository.JobRepository;
import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import com.alight.idis.jobs.JobStatus;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("jobService")
public class JobServiceImpl implements JobService {

  private static final Logger LOGGER = LoggerFactory.getLogger(JobServiceImpl.class);

  public static final String EMPLOYER_AND_CLIENT_SPLITTER = "::";
  private static final String EMPLOYER_AND_CLIENT_SPLITTER_WITH_QUOTE = Pattern
      .quote(EMPLOYER_AND_CLIENT_SPLITTER);
  private static final String COMMA_WITH_QUOTE = Pattern.quote(",");

  @Autowired
  private JobRepository jobRepository;

  @Autowired
  private JobDetailsCrudRepository jobDetailsCrudRepository;

  @Override
  public Collection<JobFileEntity> findJobsByExpectedDate(LocalDate expectedDate) {
    return jobRepository.findJobsByExpectedDate(expectedDate);
  }

  /*
   * @see com.adapt.file.service.JobService#jobFilePriorityEntityToJobModel(com.adapt.file.entity.
   * JobFilePriorityEntity)
   */
  @Override
  public JobModel jobFilePriorityEntityToJobModel(JobFilePriorityEntity jobFilePriorityEntity) {
    JobModel jobModel = new JobModel();
    jobModel.setJobId(jobFilePriorityEntity.getJobId());
    jobModel.setProfileId(jobFilePriorityEntity.getProfileId());
    jobModel.setExpectedDate(
        validateAndReturnValue(LocalDate::parse, jobFilePriorityEntity.getExpectedDate()));
    jobModel.setPriority(jobFilePriorityEntity.getPriority());
    String employerIds = jobFilePriorityEntity.getEmployerIdAndClientIdAndTestCfgs();

    String[] employerIdAndClientIdAndTestCfgs = employerIds
        .split(EMPLOYER_AND_CLIENT_SPLITTER_WITH_QUOTE);
    jobModel.setEmployerId(Integer.valueOf(employerIdAndClientIdAndTestCfgs[0]));
    jobModel.setClientId(employerIdAndClientIdAndTestCfgs[1]);
    jobModel.setTestCfgConfig(employerIdAndClientIdAndTestCfgs[2]);
    jobModel.setFullOrChange(jobFilePriorityEntity.getFullOrChange() == 1);

    // File Model Values
    FileModel fileModel = new FileModel();
    fileModel.setFileIdentifier(jobFilePriorityEntity.getFileIdentifier());
    fileModel.setFileId(jobFilePriorityEntity.getFileId());
    fileModel.setFileVersion(jobFilePriorityEntity.getFileVersion());
    fileModel.setFileTransmissionName(jobFilePriorityEntity.getFileTransmissionName());
    fileModel
        .setFileType(MessageType.valueOf(MessageType.class, jobFilePriorityEntity.getFileType()));
    fileModel.setErrorThreshold(jobFilePriorityEntity.getErrorThreshHold());
    fileModel
        .setFileMinRecordCountAllowed(jobFilePriorityEntity.getFileMinRecordCountAllowed() != null
            ? jobFilePriorityEntity.getFileMinRecordCountAllowed()
            : 0);
    fileModel.setMasterFileTemplateId(jobFilePriorityEntity.getMasterFileTemplateId());
    fileModel.setMasterFileTemplateVersion(jobFilePriorityEntity.getMasterFileTemplateVersion());
    fileModel.setResultsMode(jobFilePriorityEntity.getResultsMode() == 1);
    fileModel
        .setFileMaxRecordCountAllowed(jobFilePriorityEntity.getFileMaxRecordCountAllowed() != null
            ? jobFilePriorityEntity.getFileMaxRecordCountAllowed()
            : 0);
    fileModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat
        .valueOf(jobFilePriorityEntity.getFileProcessingErrorThresholdFormat()));

    // Message Format Values
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter(jobFilePriorityEntity.getEscapeCharacter());
    messageFormat.setFieldDelimiter(jobFilePriorityEntity.getFieldDelimiter());
    messageFormat.setMessageFormatType(MessageFormatType.valueOf(MessageFormatType.class,
        jobFilePriorityEntity.getFileFormatName()));
    messageFormat.setRowDelimiter(jobFilePriorityEntity.getRowDelimiter());
    messageFormat.setSegmentDelimiter(jobFilePriorityEntity.getSegmentDelimiter());
    fileModel.setMessageFormat(messageFormat);

    List<SectionAttributeEntity> sectionAttributeEntities = jobFilePriorityEntity
        .getSectionAttributeEntities();
    List<Section> sections = sectionAttributeEntities.stream()
        .map(sectionAttributeEntity -> sectionAttributeEntityToSection(sectionAttributeEntity))
        .collect(Collectors.toList());
    Set<Section> sectionSet = new HashSet<>();
    sections.stream().forEach(section -> sectionAttributeEntityToSection(sectionSet, section));
    fileModel.setSections(new ArrayList<>(sectionSet));
    jobModel.setFileModel(fileModel);

    List<String> list = Arrays.asList(jobFilePriorityEntity.getCloneNumberList().split(","));
    jobModel.setCloneNumberList((jobFilePriorityEntity.getCloneNumberList() == null
        || jobFilePriorityEntity.getCloneNumberList().equals("")) ? (null)
            : list.stream().map(Integer::parseInt).collect(Collectors.toList()));

    jobModel.setSourceType(jobFilePriorityEntity.getDataSourceType());
    jobModel.setTargetType(jobFilePriorityEntity.getDataTargetType());

    return jobModel;

  }

  @Override
  @Transactional
  public void updateJobStatus(JobDetailsDto jobDetailsDto) {
    if (jobDetailsDto != null) {
      Integer jobId = jobDetailsDto.getJobId();
      JobStatus nextJobStatus = jobDetailsDto.getJobStatus();
      if (jobId == null) {
        LOGGER.warn("Job Id is null!!!!");
      } else {
        JobDetails jobDetails = jobDetailsCrudRepository.findOne(jobId);
        if (jobDetails != null) {
          jobDetails.setTotalErrorRecords(jobDetailsDto.getTotalErrorCount());
          jobDetails.setTotalRecordsInFile(jobDetailsDto.getTotalRecordsInFile());
          jobDetails.setTotalRecordsProcessedAdapt(jobDetailsDto.getTotalProcessedCount());
          jobDetails.setTotalWarningRecords(jobDetailsDto.getTotalWarningCount());
          updateJobStatus(jobId, nextJobStatus, jobDetails);
        } else {
          LOGGER.warn("Job with Id : {} Not Found!!!!", jobId);
        }
      }
    }
  }

  private void updateJobStatus(Integer jobId, JobStatus nextJobStatus, JobDetails jobDetails) {
    JobStatus currentJobStatus = JobStatus.getByValue(jobDetails.getJobStatus());
    if (currentJobStatus == null) {
      LOGGER.warn("Current Job Status is invalid or NULL!!!!");
    } else if (nextJobStatus == null) {
      LOGGER.warn("Job Status is invalid or NULL!!!!");
    } else {
      if (currentJobStatus.isValidNextJobStatus(nextJobStatus)) {
        LOGGER.info("Updating Job Status : {} for Job with Id : {} ", nextJobStatus.getValue(),
            jobId);
        jobDetails.setJobStatus(nextJobStatus.getValue());
        jobDetails.setJobActualStartDatetime(new Date(Calendar.getInstance().getTimeInMillis()));
        jobDetailsCrudRepository.save(jobDetails);
      } else {
        LOGGER.warn("Job Status : {} is invalid or NULL!!!!", nextJobStatus);
      }
    }
  }

  private Attribute sectionAttributeEntityToAttribute(
      SectionAttributeEntity sectionAttributeEntity) {
    Attribute attribute = new Attribute();
    attribute.setDatatype(sectionAttributeEntity.getAttributeDataType());
    attribute.setStandardizedName(sectionAttributeEntity.getStandardizedName());
    attribute.setOrder(sectionAttributeEntity.getOrder());
    attribute.setRequired(sectionAttributeEntity.getIsAttributeMandatory());
    attribute.setAttributeSize(sectionAttributeEntity.getAttributeSize());
    attribute.setAttributeStartPosition(sectionAttributeEntity.getAttributeStartPosition());
    attribute.setAttributeEndPosition(sectionAttributeEntity.getAttributeEndPosition());
    return attribute;
  }

  private Section sectionAttributeEntityToSection(SectionAttributeEntity sectionAttributeEntity) {
    Section section = new Section();
    section.setSectionDelimiter(sectionAttributeEntity.getSectionDelimiter());
    section.setSectionType(SectionType.valueOf(sectionAttributeEntity.getSectionType()));
    Attributes attributes = new Attributes();
    attributes.getAttributeList().add(sectionAttributeEntityToAttribute(sectionAttributeEntity));
    section.setAttributes(attributes);
    return section;
  }

  private void sectionAttributeEntityToSection(Set<Section> sectionsSet, Section section) {
    Section sectionTemp = null;
    for (Section temp : sectionsSet) {
      if (temp.getSectionType().equals(section.getSectionType())) {
        sectionTemp = temp;
        break;
      }
    }
    if (null != sectionTemp && null != section.getAttributes()) {
      Attributes attributes = sectionTemp.getAttributes();
      attributes.getAttributeList().addAll(section.getAttributes().getAttributeList());
    } else {
      sectionsSet.add(section);
    }
  }

  private <T> T validateAndReturnValue(Function<String, T> function, Object object) {
    return object != null ? function.apply(String.valueOf(object)) : null;
  }

  @Override
  public boolean isValidJobToProcess(Integer jobId,
      FileProcessingErrorThresholdFormat fileProcessingErrorThresholdFormat,
      Integer errorThreshold) {
    boolean validJobToProcess = true;
    JobDetails jobDetails = jobDetailsCrudRepository.findOne(jobId);
    if (jobDetails.getJobStatus().equals(JobStatus.FAILED.getValue())) {
      return false;
    } else if (fileProcessingErrorThresholdFormat.equals(FileProcessingErrorThresholdFormat.NONE)) {
      return true;
    } else {
      if (fileProcessingErrorThresholdFormat.equals(FileProcessingErrorThresholdFormat.COUNT)) {
        Integer totalErrorRecords = jobDetails.getTotalErrorRecords();
        if (totalErrorRecords > errorThreshold) {
          jobDetails.setJobStatus(JobStatus.FAILED.getValue());
          jobDetailsCrudRepository.save(jobDetails);
          LOGGER.debug("invalid job to process {}", totalErrorRecords);
          return false;
        }
      } else if (fileProcessingErrorThresholdFormat
          .equals(FileProcessingErrorThresholdFormat.PERCENTAGE)) {
        Integer totalErrorRecords = jobDetails.getTotalErrorRecords();
        double totalRecordsInFile = jobDetails.getTotalRecordsInFile();
        if (totalErrorRecords == 0) {
          return true;
        } else if (totalErrorRecords > Math.floor((totalRecordsInFile * errorThreshold) / 100.0)) {
          jobDetails.setJobStatus(JobStatus.FAILED.getValue());
          jobDetailsCrudRepository.save(jobDetails);
          LOGGER.debug("invalid job to process {} % ",
              Math.floor((totalRecordsInFile * totalErrorRecords) / 100.0));
          return false;
        }
      }
    }
    return validJobToProcess;
  }

  @Override
  public void updateJobErrorCount(JobDetails jobDetails) {
    LOGGER.debug(
        "updating jobid={} totalProcessedCount={} totalWarningCount={} errorCount={} totalIgnoredCount={}",
        jobDetails.getJobId(), jobDetails.getTotalRecordsProcessedAdapt(),
        jobDetails.getTotalWarningRecords(), jobDetails.getTotalErrorRecords(),
        jobDetails.getTotalIgnoredRecords());
    jobDetailsCrudRepository.updateJobDetails(jobDetails.getJobId(),
        jobDetails.getTotalRecordsProcessedAdapt(), jobDetails.getTotalWarningRecords(),
        jobDetails.getTotalErrorRecords(), jobDetails.getTotalIgnoredRecords());
  }

  @Override
  public JobModelMultiEmployer jobFilePriorityEntityToJobModelMultiEmployerTransformer(
      LocalDate expectedDate, JobFilePriorityEntity jobFilePriorityEntity) {
    JobModelMultiEmployer jobModelMultiEmployer = new JobModelMultiEmployer();
    jobModelMultiEmployer.setExpectedDate(expectedDate);
    jobModelMultiEmployer.setEmployerInfoList(getEmployerInfo(jobFilePriorityEntity));
    ExtractionHelper.setEmployerIdsList(jobFilePriorityEntity.getExtractionEmployerIds(),
        jobModelMultiEmployer);
    ExtractionHelper.setPlanYear(jobFilePriorityEntity.getPlanYear(), jobModelMultiEmployer);
    ExtractionHelper.setPlanSubtypesList(jobFilePriorityEntity.getPlanSubtypes(),
        jobModelMultiEmployer);
    ExtractionHelper.setSystemDate(jobFilePriorityEntity.getSystemDate(), jobModelMultiEmployer);
    ExtractionHelper.setPlanYearAdditiveFactor(jobFilePriorityEntity.getPlanYearAdditiveFactor(),
        jobModelMultiEmployer);
    ExtractionHelper.setLookAheadPeriod(jobFilePriorityEntity.getLookAheadPeriod(),
        jobModelMultiEmployer);
    ExtractionHelper.setLookBackPeriod(jobFilePriorityEntity.getLookBackPeriod(),
        jobModelMultiEmployer);

    jobModelMultiEmployer.setJobId(jobFilePriorityEntity.getJobId());
    jobModelMultiEmployer.setExpectedDate(
        validateAndReturnValue(LocalDate::parse, jobFilePriorityEntity.getExpectedDate()));
    jobModelMultiEmployer.setPriority(jobFilePriorityEntity.getPriority());

    jobModelMultiEmployer.setFullOrChange(jobFilePriorityEntity.getFullOrChange() == 1);

    // File Model Values
    FileOutBoundModel fileOutBoundModel = new FileOutBoundModel();
    fileOutBoundModel.setFileIdentifier(jobFilePriorityEntity.getFileIdentifier());
    fileOutBoundModel.setFileId(jobFilePriorityEntity.getFileId());
    fileOutBoundModel.setFileVersion(jobFilePriorityEntity.getFileVersion());
    fileOutBoundModel.setFileTransmissionName(jobFilePriorityEntity.getFileTransmissionName());
    fileOutBoundModel
        .setFileType(MessageType.valueOf(MessageType.class, jobFilePriorityEntity.getFileType()));
    fileOutBoundModel.setErrorThreshold(jobFilePriorityEntity.getErrorThreshHold());
    fileOutBoundModel
        .setFileMinRecordCountAllowed(jobFilePriorityEntity.getFileMinRecordCountAllowed() != null
            ? jobFilePriorityEntity.getFileMinRecordCountAllowed()
            : 0);
    fileOutBoundModel.setMasterFileTemplateId(jobFilePriorityEntity.getMasterFileTemplateId());
    fileOutBoundModel
        .setMasterFileTemplateVersion(jobFilePriorityEntity.getMasterFileTemplateVersion());
    fileOutBoundModel.setResultsMode(jobFilePriorityEntity.getResultsMode() == 1);
    fileOutBoundModel
        .setFileMaxRecordCountAllowed(jobFilePriorityEntity.getFileMaxRecordCountAllowed() != null
            ? jobFilePriorityEntity.getFileMaxRecordCountAllowed()
            : 0);
    fileOutBoundModel.setFileProcessingErrorThresholdFormat(FileProcessingErrorThresholdFormat
        .valueOf(jobFilePriorityEntity.getFileProcessingErrorThresholdFormat()));

    // Message Format Values
    MessageFormat messageFormat = new MessageFormat();
    messageFormat.setEscapeCharacter(jobFilePriorityEntity.getEscapeCharacter());
    messageFormat.setFieldDelimiter(jobFilePriorityEntity.getFieldDelimiter());
    messageFormat.setMessageFormatType(MessageFormatType.valueOf(MessageFormatType.class,
        jobFilePriorityEntity.getFileFormatName()));
    messageFormat.setRowDelimiter(jobFilePriorityEntity.getRowDelimiter());
    messageFormat.setSegmentDelimiter(jobFilePriorityEntity.getSegmentDelimiter());
    fileOutBoundModel.setMessageFormat(messageFormat);

    jobModelMultiEmployer.setFileOutBoundModel(fileOutBoundModel);

    jobModelMultiEmployer.setSourceType(jobFilePriorityEntity.getDataSourceType());
    jobModelMultiEmployer.setTargetType(jobFilePriorityEntity.getDataTargetType());
    jobModelMultiEmployer.setProfileId(jobFilePriorityEntity.getProfileId());

    String endPointUrl = EndPointConfigurationHelper
        .getEndPointUrl(fileOutBoundModel.getFileType());
    LOGGER.debug("job id = {}, endPointUrl = {}", jobModelMultiEmployer.getJobId(), endPointUrl);
    jobModelMultiEmployer.setEndPointUrl(endPointUrl);
    return jobModelMultiEmployer;
  }

  private List<EmployerInfo> getEmployerInfo(JobFilePriorityEntity jobFilePriorityEntity) {
    String employerIdAndClientIdsAnsTestCfgList = jobFilePriorityEntity
        .getEmployerIdAndClientIdAndTestCfgs();
    List<EmployerInfo> employerInfoList = new ArrayList<>();
    for (String employerIdAndClientIdsAnsTestCfg : employerIdAndClientIdsAnsTestCfgList
        .split(COMMA_WITH_QUOTE)) {
      EmployerInfo employerInfo = new EmployerInfo();
      employerInfoList.add(employerInfo);
      String[] employerIdAndClinetId = employerIdAndClientIdsAnsTestCfg
          .split(EMPLOYER_AND_CLIENT_SPLITTER_WITH_QUOTE);
      employerInfo.setEmployerId(Integer.valueOf(employerIdAndClinetId[0]));
      employerInfo.setClientId(employerIdAndClinetId[1]);
      employerInfo.setTestCfg(employerIdAndClinetId[2]);
    }
    return employerInfoList;
  }

  @Override
  public void updateJobIntialCountDetails(Integer jobId, Integer totalRecordsProcessedAdapt,
      Integer totalWarningRecords, Integer errorCount, Integer ignoreCount,
      Integer totalRecordsInFile) {
    if (jobId != null) {
      jobDetailsCrudRepository.updateJobIntialCountDetails(jobId, totalRecordsProcessedAdapt,
          totalWarningRecords, errorCount, ignoreCount, totalRecordsInFile);
    } else {
      LOGGER.warn("Job Id is null!!!!");
    }

  }

}
