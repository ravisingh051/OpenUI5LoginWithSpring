package com.adapt.file.messaging;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.scheduling.PollSkipAdvice;

@Configuration
public class BlackoutWindowPollSkipAdvice extends PollSkipAdvice {

  @Bean
  public PollSkipAdvice blackoutWindowSkipPollAdvice() {
    BlackoutWindowPollSkipStrategy strategy = new BlackoutWindowPollSkipStrategy();
    return new PollSkipAdvice(strategy);
  }

}
