package com.adapt.file.entity;

import java.io.Serializable;

public class SectionAttributeEntity implements Serializable {

  private static final long serialVersionUID = -8234591090431228843L;

  @ColumnIndex(value = 0)
  private String standardizedName;

  @ColumnIndex(value = 1)
  private String attributeDataType;

  // indiacates attribute row position
  @ColumnIndex(value = 2)
  private Integer order;

  @ColumnIndex(value = 3)
  private String sectionType;

  @ColumnIndex(value = 6)
  private String sectionDelimiter;

  @ColumnIndex(value = 7)
  private Boolean isAttributeMandatory;

  @ColumnIndex(value = 8)
  private Integer attributeSize;

  @ColumnIndex(value = 9)
  private Integer attributeStartPosition;

  @ColumnIndex(value = 10)
  private Integer attributeEndPosition;

  public String getStandardizedName() {
    return standardizedName;
  }

  public void setStandardizedName(String standardizedName) {
    this.standardizedName = standardizedName;
  }

  public String getAttributeDataType() {
    return attributeDataType;
  }

  public void setAttributeDataType(String attributeDataType) {
    this.attributeDataType = attributeDataType;
  }

  public Integer getOrder() {
    return order;
  }

  public void setOrder(Integer order) {
    this.order = order;
  }

  public String getSectionType() {
    return sectionType;
  }

  public void setSectionType(String sectionType) {
    this.sectionType = sectionType;
  }

  public String getSectionDelimiter() {
    return sectionDelimiter;
  }

  public void setSectionDelimiter(String sectionDelimiter) {
    this.sectionDelimiter = sectionDelimiter;
  }

  public Boolean getIsAttributeMandatory() {
    return isAttributeMandatory;
  }

  public void setIsAttributeMandatory(Boolean isAttributeMandatory) {
    this.isAttributeMandatory = isAttributeMandatory;
  }

  public Integer getAttributeSize() {
    return attributeSize;
  }

  public void setAttributeSize(Integer attributeSize) {
    this.attributeSize = attributeSize;
  }

  public Integer getAttributeStartPosition() {
    return attributeStartPosition;
  }

  public void setAttributeStartPosition(Integer attributeStartPosition) {
    this.attributeStartPosition = attributeStartPosition;
  }

  public Integer getAttributeEndPosition() {
    return attributeEndPosition;
  }

  public void setAttributeEndPosition(Integer attributeEndPosition) {
    this.attributeEndPosition = attributeEndPosition;
  }

}
