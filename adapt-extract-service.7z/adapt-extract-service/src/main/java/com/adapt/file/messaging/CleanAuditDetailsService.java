package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.repository.JobPrioritizationAuditRepository;
import java.util.concurrent.atomic.AtomicBoolean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

@Service("cleanAuditDetailsService")
public class CleanAuditDetailsService implements ApplicationRunner {

  private AtomicBoolean isCleanup = new AtomicBoolean(false);

  @Autowired
  private JobPrioritizationAuditRepository jobPrioritizationAuditRepository;

  @Value("${source.instance.identifier}")
  private String sourceInstance;

  public Boolean isCleanupCompleted() {
    return isCleanup.get();
  }

  private void cleanupCompleted() {
    isCleanup.set(true);

  }

  @Override
  public void run(ApplicationArguments args) throws Exception {
    jobPrioritizationAuditRepository.cleanUpJobPrioritizationAuditWithStarted(
        Constant.JOB_PRIOTIZATION_AUDIT_FAILED, Constant.JOB_PRIOTIZATION_AUDIT_STARTED,
        sourceInstance);
    cleanupCompleted();

  }

}
