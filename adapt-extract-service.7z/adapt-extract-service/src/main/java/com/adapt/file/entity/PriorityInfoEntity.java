package com.adapt.file.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PriorityInfoEntity implements Serializable {

  private static final long serialVersionUID = 1468676310783629676L;

  @Id
  @Column(name = "priority_id")
  private Integer priorityId;

  @Column(name = "priority")
  private Integer priority;
  @Column(name = "criteria")
  private String criteria;
  @Column(name = "value")
  private String value;

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public String getCriteria() {
    return criteria;
  }

  public void setCriteria(String criteria) {
    this.criteria = criteria;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public Integer getPriorityId() {
    return priorityId;
  }

  public void setPriorityId(Integer priorityId) {
    this.priorityId = priorityId;
  }

  @Override
  public String toString() {
    return "PriorityInfoEntity [priorityId=" + priorityId + ", priority=" + priority + ", criteria="
        + criteria + ", value=" + value + "]";
  }

}
