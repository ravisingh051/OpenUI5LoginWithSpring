package com.adapt.file.entity;

import java.io.Serializable;

/**
 * The Class Section.
 *
 * @author AH28510
 */
public class Section implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 556673205112332173L;

  /**
   * The Enum SectionType.
   */
  public enum SectionType {

    /** The header. */
    HEADER("HEADER"),
    /** The detail. */
    DETAIL("DETAIL"),
    /** The trailer. */
    TRAILER("TRAILER");

    /** The value. */
    private String value;

    /**
     * Instantiates a new section type.
     *
     * @param value
     *          the value
     */
    SectionType(String value) {
      this.value = value;
    }

    /**
     * Value.
     *
     * @return the string
     */
    public String value() {
      return this.value;
    }
  }

  /** The section type. */
  private SectionType sectionType;

  /** The attributes. */
  private Attributes attributes;

  /** The section delimiter. */
  private String sectionDelimiter;

  /**
   * Gets the section type.
   *
   * @return the section type
   */
  public SectionType getSectionType() {
    return sectionType;
  }

  /**
   * Sets the section type.
   *
   * @param sectionType
   *          the new section type
   */
  public void setSectionType(SectionType sectionType) {
    this.sectionType = sectionType;
  }

  /**
   * Gets the attributes.
   *
   * @return the attributes
   */
  public Attributes getAttributes() {
    return attributes;
  }

  /**
   * Sets the attributes.
   *
   * @param attributes
   *          the new attributes
   */
  public void setAttributes(Attributes attributes) {
    this.attributes = attributes;
  }

  /**
   * Gets the section delimiter.
   *
   * @return the section delimiter
   */
  public String getSectionDelimiter() {
    return sectionDelimiter;
  }

  /**
   * Sets the section delimiter.
   *
   * @param sectionDelimiter
   *          the new section delimiter
   */
  public void setSectionDelimiter(String sectionDelimiter) {
    this.sectionDelimiter = sectionDelimiter;
  }

}
