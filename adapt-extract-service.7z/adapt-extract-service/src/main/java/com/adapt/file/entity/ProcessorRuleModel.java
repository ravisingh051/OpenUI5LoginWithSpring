package com.adapt.file.entity;

import java.io.Serializable;

public class ProcessorRuleModel implements Serializable {

  private static final long serialVersionUID = 7531218891290372525L;
  private Integer ruleId;
  private Integer ruleVersion;
  private String rule;
  private Integer priority;
  private Boolean isCurrent;
  private Integer ruleExecutionSequence;

  public Integer getRuleExecutionSequence() {
    return ruleExecutionSequence;
  }

  public void setRuleExecutionSequence(Integer ruleExecutionSequence) {
    this.ruleExecutionSequence = ruleExecutionSequence;
  }

  public Integer getRuleId() {
    return ruleId;
  }

  public void setRuleId(Integer ruleId) {
    this.ruleId = ruleId;
  }

  public Integer getRuleVersion() {
    return ruleVersion;
  }

  public void setRuleVersion(Integer ruleVersion) {
    this.ruleVersion = ruleVersion;
  }

  public String getRule() {
    return rule;
  }

  public void setRule(String rule) {
    this.rule = rule;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public boolean isCurrent() {
    return isCurrent;
  }

  public void setCurrent(boolean isCurrent) {
    this.isCurrent = isCurrent;
  }

}
