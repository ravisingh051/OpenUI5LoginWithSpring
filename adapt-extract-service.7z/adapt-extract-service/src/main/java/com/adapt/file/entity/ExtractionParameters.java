package com.adapt.file.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class ExtractionParameters implements Serializable {

  private static final long serialVersionUID = 3652241862334535937L;
  private List<String> carriersList;
  private LocalDateTime planStartDate;
  private LocalDateTime planEndDate;
  private List<String> planSubtypesList;

  public List<String> getCarriersList() {
    return carriersList;
  }

  public void setCarriersList(List<String> carriersList) {
    this.carriersList = carriersList;
  }

  public LocalDateTime getPlanStartDate() {
    return planStartDate;
  }

  public void setPlanStartDate(LocalDateTime planStartDate) {
    this.planStartDate = planStartDate;
  }

  public LocalDateTime getPlanEndDate() {
    return planEndDate;
  }

  public void setPlanEndDate(LocalDateTime planEndDate) {
    this.planEndDate = planEndDate;
  }

  public List<String> getPlanSubtypesList() {
    return planSubtypesList;
  }

  public void setPlanSubtypesList(List<String> planSubtypesList) {
    this.planSubtypesList = planSubtypesList;
  }

}
