package com.adapt.file.service;

import com.adapt.file.entity.JobDetails;
import com.adapt.file.entity.JobDetailsDto;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.alight.idis.jobs.FileProcessingErrorThresholdFormat;
import java.time.LocalDate;
import java.util.Collection;

public interface JobService {

  void updateJobStatus(JobDetailsDto jobDetailsDto);

  boolean isValidJobToProcess(Integer jobId,
      FileProcessingErrorThresholdFormat fileProcessingErrorThresholdFormat,
      Integer errorThreshold);

  Collection<JobFileEntity> findJobsByExpectedDate(LocalDate expectedDate);

  void updateJobErrorCount(JobDetails jobDetails);

  JobModel jobFilePriorityEntityToJobModel(JobFilePriorityEntity jobFilePriorityEntity);

  void updateJobIntialCountDetails(Integer jobId, Integer totalRecordsProcessedAdapt,
      Integer totalWarningRecords, Integer errorCount, Integer ignoreCount,
      Integer totalRecordsInFile);

  JobModelMultiEmployer jobFilePriorityEntityToJobModelMultiEmployerTransformer(
      LocalDate expectedDate, JobFilePriorityEntity jobFilePriorityEntity);
}
