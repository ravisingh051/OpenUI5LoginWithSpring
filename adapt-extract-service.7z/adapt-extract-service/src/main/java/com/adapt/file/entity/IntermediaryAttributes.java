package com.adapt.file.entity;

import java.util.HashMap;
import java.util.Map;

public class IntermediaryAttributes {

  Map<Integer, IntermediaryAttribute> attributes = new HashMap<>();

  public IntermediaryAttributes(Map<Integer, IntermediaryAttribute> attributes) {
    this.attributes = attributes;
  }

  public Map<Integer, IntermediaryAttribute> getAttributes() {
    return this.attributes;
  }

  public void setAttributes(Map<Integer, IntermediaryAttribute> attributes) {
    this.attributes = attributes;
  }

}
