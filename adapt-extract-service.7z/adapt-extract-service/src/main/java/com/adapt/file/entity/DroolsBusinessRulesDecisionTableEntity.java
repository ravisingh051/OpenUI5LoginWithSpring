package com.adapt.file.entity;

import java.io.Serializable;

public class DroolsBusinessRulesDecisionTableEntity implements Serializable {

  private static final long serialVersionUID = -7731576438919721855L;

  @ColumnIndex(value = 0)
  private Integer droolsBusinessRuleId;

  @ColumnIndex(value = 1)
  private Integer droolsBusinessRuleVersion;

  @ColumnIndex(value = 2)
  private String droolsBusinessRuleDrlFileContent;

  @ColumnIndex(value = 3)
  private Boolean current;

  @ColumnIndex(4)
  private Integer ruleExecutionSequence;

  public Integer getDroolsBusinessRuleId() {
    return droolsBusinessRuleId;
  }

  public void setDroolsBusinessRuleId(Integer droolsBusinessRuleId) {
    this.droolsBusinessRuleId = droolsBusinessRuleId;
  }

  public Integer getDroolsBusinessRuleVersion() {
    return droolsBusinessRuleVersion;
  }

  public void setDroolsBusinessRuleVersion(Integer droolsBusinessRuleVersion) {
    this.droolsBusinessRuleVersion = droolsBusinessRuleVersion;
  }

  public String getDroolsBusinessRuleDrlFileContent() {
    return droolsBusinessRuleDrlFileContent;
  }

  public void setDroolsBusinessRuleDrlFileContent(String droolsBusinessRuleDrlFileContent) {
    this.droolsBusinessRuleDrlFileContent = droolsBusinessRuleDrlFileContent;
  }

  public Boolean getCurrent() {
    return current;
  }

  public void setCurrent(Boolean current) {
    this.current = current;
  }

  public Integer getRuleExecutionSequence() {
    return ruleExecutionSequence;
  }

  public void setRuleExecutionSequence(Integer ruleExecutionSequence) {
    this.ruleExecutionSequence = ruleExecutionSequence;
  }

}
