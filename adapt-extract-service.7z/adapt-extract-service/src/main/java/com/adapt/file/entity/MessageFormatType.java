package com.adapt.file.entity;

public enum MessageFormatType {
  FILE_DELIMITED("FILE_DELIMITED"), FILE_FIXED_WIDTH("FILE_FIXED_WIDTH");

  private String value;

  MessageFormatType(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }
}
