package com.adapt.file.service;

import com.adapt.event.AdaptDatatypeTransformationExceptionOccuredEvent;
import com.adapt.event.DatasetCountExceedOccurred;
import com.adapt.event.DatasetCountSubceedOccurred;
import com.adapt.event.InboundFileOccurred;
import com.adapt.event.JobCompletedOccurredEvent;
import com.adapt.event.JobFailedOccurredEvent;

public interface EventNotificationService {

  void sendInboundFileOccuredNotification(InboundFileOccurred inboundFileOccurred);

  void sendCountExceededOccurredNotification(DatasetCountExceedOccurred datasetCountExceedOccurred);

  void sendCountSubceededOccurredNotification(
      DatasetCountSubceedOccurred datasetCountSubceedOccurred);

  void sendDataTypeTransformationExceptionEvent(
      AdaptDatatypeTransformationExceptionOccuredEvent adaptDatatypeTransformationExceptionOccured);

  void sendJobFailedEvent(JobFailedOccurredEvent jobFailedOccurredEvent);

  void sendJobCompletedEvent(JobCompletedOccurredEvent jobCompletedOccurredEvent);

}
