package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.exception.SecondaryDataException;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.SecondaryDataInfo;
import com.adapt.file.service.SecondaryDataService;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service("secondaryDataConfiguration")
public class SecondaryDataConfiguration {

  private static final Logger LOGGER = LoggerFactory.getLogger(SecondaryDataConfiguration.class);

  @Autowired
  private SecondaryDataService secondaryDataService;

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public SecondaryDataConfiguration() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  /**
   * secondary data configuration.
   *
   * @param message the message
   * @return the message
   */
  public Message<?> secondaryDataConfiguration(Message<?> message) {
    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().fromMessage(message);
    builder.copyHeaders(message.getHeaders());
    JobModel jobModel = (JobModel) builder.getHeaders().get(Constant.JOB_MODEL_HEADER);
    List<SecondaryDataInfo> secondaryDataInfo =
        secondaryDataService.getSecondaryDataInfo(jobModel.getFileModel().getFileIdentifier());
    try {
      builder.setHeader(Constant.SECONDARY_DATA_INFO_HEADER,
          jsonObjectMapper.toJson(secondaryDataInfo));
    } catch (Exception e) {
      throw new SecondaryDataException("not able to update secondary Data api infoamrtion", e);
    }
    LOGGER.debug("enriched secondory api configuration");
    return builder.build();
  }
}
