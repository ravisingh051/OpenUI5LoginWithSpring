package com.adapt.file.entity;

import java.io.Serializable;

public class JobPriorityGetPayload implements Serializable {

  private static final long serialVersionUID = 6848794220282379092L;

  private JobFilePriorityEntity jobFilePriorityEntity;

  public JobFilePriorityEntity getJobFilePriorityEntity() {
    return jobFilePriorityEntity;
  }

  public void setJobFilePriorityEntity(JobFilePriorityEntity jobFilePriorityEntity) {
    this.jobFilePriorityEntity = jobFilePriorityEntity;
  }

  @Override
  public String toString() {
    return "JobPriorityGetPaylod [jobFilePriorityEntity=" + jobFilePriorityEntity + "]";
  }

}
