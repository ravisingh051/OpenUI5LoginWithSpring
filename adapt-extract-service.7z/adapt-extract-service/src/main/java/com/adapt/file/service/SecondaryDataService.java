package com.adapt.file.service;

import com.adapt.file.entity.SecondaryDataInfo;
import java.util.List;

public interface SecondaryDataService {

  List<SecondaryDataInfo> getSecondaryDataInfo(Integer fileIdentifier);

  void removeSecondaryDataFromCache();
}
