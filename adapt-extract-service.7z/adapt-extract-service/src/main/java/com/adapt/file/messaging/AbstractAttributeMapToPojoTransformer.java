package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.config.MessageTypeConfig;
import com.adapt.config.MessageTypeConfigHelper;
import com.adapt.exception.AttributeMapToDatasetTransformerException;
import com.adapt.file.entity.JobModel;
import com.adapt.file.util.AdaptSourceUtils;
import com.alight.adapt.datasets.AbstractDataset;
import com.alight.adapt.datasets.RuleFailure;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.util.Assert;

@Slf4j
public abstract class AbstractAttributeMapToPojoTransformer extends AbstractTransformer {

  protected static final String INVALID_CONFIGURATION_FOR_TARGET_CLASS_VS_MESSAGE_TYPE = "invalid configuration for target class vs Message type";

  @Override
  protected Object doTransform(Message<?> message) throws Exception {
    log.debug("Transformer start");
    JobModel jobModel = (JobModel) message.getHeaders().get(Constant.JOB_MODEL_HEADER);
    Assert.notNull(jobModel, "Job Model Can not be Null");
    @SuppressWarnings("unchecked")
    Map<String, Object> attributeMap = (Map<String, Object>) message.getPayload();
    trimValue(attributeMap);
    AbstractDataset abstractDataset = null;
    try {
      abstractDataset = transformToPojo(jobModel, attributeMap);
    } catch (Exception e) {
      abstractDataset = getErrorObject(jobModel);
      setError(abstractDataset, AdaptSourceUtils.getSummaryOfError(e.getCause()));
    }
    log.debug("Transformer end");
    return abstractDataset;
  }

  public abstract AbstractDataset transformToPojo(JobModel jobModel,
      Map<String, Object> attributeMap);

  /**
   * getErrorObject method.
   * 
   * @return AbstractDataset
   */
  public AbstractDataset getErrorObject(JobModel jobModel) {

    MessageTypeConfig messageTypeConfig = MessageTypeConfigHelper
        .getMessageTypeConfiguration(jobModel.getFileModel().getFileType());
    if (messageTypeConfig != null && messageTypeConfig.getDatasetTransformerClazz() != null) {
      Class<? extends AbstractDataset> targetClazz = MessageTypeConfigHelper
          .getMessageTypeConfiguration(jobModel.getFileModel().getFileType())
          .getDatasetTransformerClazz();

      try {
        return targetClazz.newInstance();
      } catch (InstantiationException | IllegalAccessException e) {
        log.debug(e.getMessage(), e);
        throw new AttributeMapToDatasetTransformerException(
            INVALID_CONFIGURATION_FOR_TARGET_CLASS_VS_MESSAGE_TYPE, e);
      }
    } else {
      log.error("target class not found for message type: {}",
          jobModel.getFileModel().getFileType().getValue());
      throw new AttributeMapToDatasetTransformerException(
          INVALID_CONFIGURATION_FOR_TARGET_CLASS_VS_MESSAGE_TYPE);
    }
  }

  private void trimValue(Map<String, Object> attributeMap) {
    attributeMap.forEach((key, value) -> {
      if (value instanceof String) {
        attributeMap.put(key, cleanTextContent((String) value));
      }
    });
  }

  protected void setError(AbstractDataset abstractDataset, String error) {

    List<RuleFailure> ruleFailureList = new ArrayList<>(0);
    RuleFailure ruleFailure = new RuleFailure();
    ruleFailure.setError(true);
    ruleFailure.setErrorDescription(error);
    ruleFailureList.add(ruleFailure);
    abstractDataset.setRuleFailures(ruleFailureList);

  }

  private String cleanTextContent(String text) {

    String normalized = Normalizer.normalize(text, Normalizer.Form.NFD);
    text = normalized.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    // strips off all non-ASCII characters
    text = text.replaceAll("[^\\x00-\\x7F]", "");

    return StringUtils.trim(text);

  }

}
