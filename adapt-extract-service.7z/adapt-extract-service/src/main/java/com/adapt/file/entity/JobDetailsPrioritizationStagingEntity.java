package com.adapt.file.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "job_details_prioritization_staging")
public class JobDetailsPrioritizationStagingEntity implements Serializable {

  private static final long serialVersionUID = -3683241818177565910L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "job_detail_prioritization_staging_id")
  private Integer jobDetailPrioritizationStagingId;

  @Column(name = "job_id")
  private Integer jobId;

  @Column(name = "job_status")
  private String jobStatus;

  @Column(name = "job_priority")
  private Integer jobPriority;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "created_date_time")
  private Date createdDateTime;

  @Column(name = "updated_by")
  private String updatedBy;

  @Column(name = "updated_date_time")
  private Date updatedDateTime;

  public Integer getJobDetailPrioritizationStagingId() {
    return jobDetailPrioritizationStagingId;
  }

  public void setJobDetailPrioritizationStagingId(Integer jobDetailPrioritizationStagingId) {
    this.jobDetailPrioritizationStagingId = jobDetailPrioritizationStagingId;
  }

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public String getJobStatus() {
    return jobStatus;
  }

  public void setJobStatus(String jobStatus) {
    this.jobStatus = jobStatus;
  }

  public Integer getJobPriority() {
    return jobPriority;
  }

  public void setJobPriority(Integer jobPriority) {
    this.jobPriority = jobPriority;
  }

  public Boolean getIsActive() {
    return isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * Gets the created date time.
   *
   * @return the created date time
   */
  public Date getCreatedDateTime() {

    if (createdDateTime != null) {
      return new Date(createdDateTime.getTime());
    } else {
      return null;
    }
  }

  /**
   * Sets the created date time.
   *
   * @param createdDateTime
   *          the new created date time
   */
  public void setCreatedDateTime(Date createdDateTime) {

    if (createdDateTime != null) {
      this.createdDateTime = (Date) createdDateTime.clone();
    } else {
      this.createdDateTime = null;
    }

  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * Gets the updated date time.
   *
   * @return the updated date time
   */
  public Date getUpdatedDateTime() {

    if (updatedDateTime != null) {
      return new Date(updatedDateTime.getTime());
    } else {
      return null;
    }

  }

  /**
   * Sets the updated date time.
   *
   * @param updatedDateTime
   *          the new updated date time
   */
  public void setUpdatedDateTime(Date updatedDateTime) {
    if (updatedDateTime != null) {
      this.updatedDateTime = (Date) updatedDateTime.clone();
    } else {
      this.updatedDateTime = null;
    }

  }

}
