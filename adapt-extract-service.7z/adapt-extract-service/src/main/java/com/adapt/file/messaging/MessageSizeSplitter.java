package com.adapt.file.messaging;

import com.adapt.file.InvalidMessage;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.integration.splitter.AbstractMessageSplitter;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Component("messageSizeSplitter")
@Slf4j
public class MessageSizeSplitter extends AbstractMessageSplitter {

  private static final Logger LOGGER = LoggerFactory.getLogger(MessageSizeSplitter.class);

  private static final long ONE_KB_IN_BYTES = 1024L;

  @Value("${splitSize}")
  public int messageSizeInKb;

  private long messageSizeInBytes = ONE_KB_IN_BYTES;

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public MessageSizeSplitter() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  @PostConstruct
  public void init() {
    messageSizeInBytes = messageSizeInKb * ONE_KB_IN_BYTES;
  }

  @Override
  @SuppressWarnings("unchecked")
  protected Object splitMessage(Message<?> message) {
    Object payload = message.getPayload();
    if (payload instanceof Collection) {
      Collection<? extends Object> payloadCollection = (Collection<? extends Object>) payload;
      List<String> newPayload = new ArrayList<>();
      List<Object> subPayload = new ArrayList<>();
      try {
        long totalChunkSizeInByte = 0;
        for (Object object : payloadCollection) {
          long messageLengthInByte = findMessageLength(new ArrayList<>(), object);
          if (messageLengthInByte > messageSizeInBytes) {
            String jsonObject = jsonObjectMapper.toJson(object);
            LOGGER.warn("message size is greater than split size skiping record !!! {}",
                jsonObject);
            List<Object> subPayloadForMaxSizeResult = new ArrayList<>();
            subPayloadForMaxSizeResult.add(object);
            String chunkJson = jsonObjectMapper.toJson(subPayloadForMaxSizeResult);
            newPayload.add(chunkJson);
            continue;
          }
          if (totalChunkSizeInByte != 0) {
            totalChunkSizeInByte = totalChunkSizeInByte + (messageLengthInByte - "[]".length())
                + ",".length();
          } else {
            // first time we have to consider "[] and ,"
            totalChunkSizeInByte = totalChunkSizeInByte + messageLengthInByte;
          }
          if (totalChunkSizeInByte > messageSizeInBytes) {
            // create json array to send to the processor
            String chunkJson = jsonObjectMapper.toJson(subPayload);
            newPayload.add(chunkJson);
            subPayload = new ArrayList<>();
            totalChunkSizeInByte = messageLengthInByte;
            LOGGER.debug("chunk found");
          }
          subPayload.add(object);
        }
        addChunkToNewPayload(newPayload, subPayload);
        LOGGER.debug("message size splitter is completed");
        return newPayload;
      } catch (Exception e) {
        LOGGER.error(e.getMessage(), e);
        throw new InvalidMessage(e.getMessage(), e);
      }
    }
    return payload;
  }

  private void addChunkToNewPayload(List<String> newPayload, List<Object> subPayload)
      throws Exception {
    if (!subPayload.isEmpty()) {
      String chunkJson = jsonObjectMapper.toJson(subPayload);
      newPayload.add(chunkJson);
    }
  }

  private int findMessageLength(String jsonMessage) {

    // UTF-8 for now if we found any specific requirement this will update
    return jsonMessage.getBytes(StandardCharsets.UTF_8).length;
  }

  private int findMessageLength(List<Object> subPayload, Object nextObject) throws Exception {
    List<Object> temp = new ArrayList<>(subPayload);
    temp.add(nextObject);
    String jsonMessage = jsonObjectMapper.toJson(temp);
    return findMessageLength(jsonMessage);
  }

}
