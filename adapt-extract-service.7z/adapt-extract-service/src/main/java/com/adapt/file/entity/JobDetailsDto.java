package com.adapt.file.entity;

import com.alight.idis.jobs.JobStatus;
import java.io.Serializable;

/**
 * This class represents the JobDetails entity.
 */
public class JobDetailsDto implements Serializable {

  private static final long serialVersionUID = 2833135293166175678L;

  private JobStatus jobStatus;
  private Integer jobId;
  private Integer totalRecordsInFile;
  private Integer totalProcessedCount;
  private Integer totalErrorCount;
  private Integer totalWarningCount;

  public JobStatus getJobStatus() {
    return jobStatus;
  }

  public void setJobStatus(JobStatus jobStatus) {
    this.jobStatus = jobStatus;
  }

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public Integer getTotalProcessedCount() {
    return totalProcessedCount;
  }

  public void setTotalProcessedCount(Integer totalProcessedCount) {
    this.totalProcessedCount = totalProcessedCount;
  }

  public Integer getTotalErrorCount() {
    return totalErrorCount;
  }

  public void setTotalErrorCount(Integer totalErrorCount) {
    this.totalErrorCount = totalErrorCount;
  }

  public Integer getTotalWarningCount() {
    return totalWarningCount;
  }

  public void setTotalWarningCount(Integer totalWarningCount) {
    this.totalWarningCount = totalWarningCount;
  }

  public Integer getTotalRecordsInFile() {
    return totalRecordsInFile;
  }

  public void setTotalRecordsInFile(Integer totalRecordsInFile) {
    this.totalRecordsInFile = totalRecordsInFile;
  }



}
