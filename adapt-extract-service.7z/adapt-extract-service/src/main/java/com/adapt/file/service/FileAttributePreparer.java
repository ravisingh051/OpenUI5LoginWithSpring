package com.adapt.file.service;

import com.adapt.file.entity.Attributes;
import com.adapt.file.entity.IntermediaryAttribute;
import com.adapt.file.entity.IntermediaryAttributeMapper;
import com.adapt.file.entity.IntermediaryAttributes;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.Section.SectionType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service("fileAttributePreparer")
@Slf4j
public class FileAttributePreparer {

  private static final String DOUBLEQUOTE = "\"";
  
  private static final char QUOTE='"';
  
  private static final int DELIMITER_NOT_FOUND = -1;
  
  private static final int ENDQUOTE_NOT_FOUND = -1;

  private static final int ADD_ONE = 1;

  private static final int INDEX_ZERO = 0;
  
  
  /**
   * Prepare delimited intermediary attributes.
   *
   * @param jobModel    the job model
   * @param sectionType the section type
   * @return the intermediary attributes
   */
  public IntermediaryAttributes prepareDelimitedIntermediaryAttributes(JobModel jobModel, SectionType sectionType) {
    Attributes inputAttributes = jobModel.findAttributesBySectionType(sectionType);

    IntermediaryAttributeMapper interMapper = new IntermediaryAttributeMapper();
    return interMapper.fromInputAttributes(inputAttributes);
  }

  /**
   * Prepare fix width intermediary attributes.
   *
   * @param jobModel    the job model
   * @param sectionType the section type
   * @return the intermediary attributes
   */
  public IntermediaryAttributes prepareFixWidthIntermediaryAttributes(JobModel jobModel, SectionType sectionType) {
    Attributes inputAttributes = jobModel.findAttributesBySectionType(sectionType);

    IntermediaryAttributeMapper interMapper = new IntermediaryAttributeMapper();
    return interMapper.fromFixWidthInputAttributes(inputAttributes);
  }

  /**
   * Prepare attributes map for delimited file.
   *
   * @param input                  the payload
   * @param fieldDelimiter         the field delimiter
   * @param intermediaryAttributes the intermediary attributes
   * @return the map
   */
  public Map<String,
      Object> prepareAttributesMap(String input, String fieldDelimiter, IntermediaryAttributes intermediaryAttributes) {

    boolean startsWith = StringUtils.startsWith(input, fieldDelimiter);
    if (startsWith) {
      // if first char is same as fieldDelimiter scanner not returning back data first
      // data as a
      // empty string to overcome we are adding space
      input = " " + input;
    }
    return getAttributesMap(input, fieldDelimiter, intermediaryAttributes);
  }

  /**
   * this method will create a map with list of attributes delimited with the
   * given field delimiter.
   *
   * @param input the input
   * @param fieldDelimiter the field delimiter
   * @param intermediaryAttributes the intermediary attributes
   * @return the attributes map
   */
  private Map<String,
      Object> getAttributesMap(String input, String fieldDelimiter, IntermediaryAttributes intermediaryAttributes) {
    List<String> splitLineList = buildSplittedDelimitedList(input, fieldDelimiter);
    return buildAttributesMap(splitLineList, intermediaryAttributes);
  }

  /**
   * Prepare attributes map, with list of attributes delimited by field delimiter.
   *
   * @param splitLineList the split line list
   * @param intermediaryAttributes the intermediary attributes
   * @return the map
   */
  private Map<String, Object> buildAttributesMap(List<
      String> splitLineList, IntermediaryAttributes intermediaryAttributes) {
    Map<String, Object> attributes = new HashMap<>();
    int columnNumber = 1;
    for (String value : splitLineList) {
      // remove double quotes "e1,e2" should be e1,e2
      value = removeDoubleQuotes(value);
      if (null != intermediaryAttributes.getAttributes().get(columnNumber)) {
        attributes.put(intermediaryAttributes.getAttributes().get(columnNumber).getStandardizedName(), value);
      } else {
        log.warn("this attribute is coming from the file but not configured in the UI !!!");
      }
      columnNumber++;
    }
    return attributes;
  }

  /**
   * Split the list, based on the given field delimiter.
   *
   * @param input the input
   * @param fieldDelimiter the field delimiter
   * @return the list
   */
  private List<String> buildSplittedDelimitedList(String input, String fieldDelimiter) {
    List<String> splitLineList = new ArrayList<>();
    if (input.contains(DOUBLEQUOTE)) {
      splitLineList = splitByDelimiterInQuotes(input, fieldDelimiter.charAt(0));
    } else {
      try (Scanner lineScanner = new Scanner(input)) {
        lineScanner.useDelimiter(Pattern.quote(fieldDelimiter));
        while (lineScanner.hasNext()) {
          splitLineList.add(lineScanner.next());
        }
      }
    }
    return splitLineList;
  }
  
  /**
   * This method will remove double quotes if present at the start and end of
   * string like "e1,e2" will be e1,e2.
   *
   * @param value the value
   * @return the string
   */
  private String removeDoubleQuotes(String value) {
    if (StringUtils.startsWith(value, DOUBLEQUOTE) && StringUtils.endsWith(value, DOUBLEQUOTE)) {
      value = StringUtils.removeStart(value, DOUBLEQUOTE);
      value = StringUtils.removeEnd(value, DOUBLEQUOTE);
    }
    return value;
  }

  /**
   * Prepare attributes map for fix width file.
   *
   * @param input                  the payload
   * @param intermediaryAttributes the intermediary attributes
   * @return the map
   */
  public Map<String,
      Object> prepareAttributesMap(String input, IntermediaryAttributes intermediaryAttributes) {
    Map<String, Object> attributes = new HashMap<>();

    for (Entry<Integer,
        IntermediaryAttribute> entry : intermediaryAttributes.getAttributes().entrySet()) {
      IntermediaryAttribute intermediaryAttribute = entry.getValue();
      Integer attributeStartPosition = intermediaryAttribute.getAttributeStartPosition();
      Integer attributeEndPosition = intermediaryAttribute.getAttributeEndPosition();
      if (attributeStartPosition != null && attributeEndPosition != null) {
        String value;
        try {
          value = input.substring(attributeStartPosition - 1, attributeEndPosition);
        } catch (StringIndexOutOfBoundsException e) {
          value = null;
        }
        attributes.put(intermediaryAttribute.getStandardizedName(), value);
      }
    }
    return attributes;
  }

   /**
   * The logic for parsing is - double quote is to be considered in parsing (where
   * a starting and closing double quote is expected) is when a double quote
   * immediately follows the delimiter character or when it is the first character
   * in the record. In both of these instances, a closing double quote would be
   * expected immediately before the next field delimiter character or as the last
   * character in the record. Otherwise, a double quote should be considered as
   * just another character in the field.<br>
   * Input1 :- "Dow,,F,Unknown,,\"3301, Kntario Ave\",,,Kelando" then output will
   * be [Dow, , F, Unknown, , "3301, Kntario Ave", Kelando] <br>
   * Input2:- 12"x14"x6",Rectangle Box,Express Mail then output will be
   * [12"x14"x6", Rectangle Box, Express Mail]
   *
   * @param inputString    the input string
   * @param fieldDelimiter the field delimiter
   * @return the list
   */
  private List<String> splitByDelimiterInQuotes(String inputString, char fieldDelimiter) {
    List<String> list = new ArrayList<>();
    splitDelimitedString(inputString, fieldDelimiter, list);
    splitIfEndsWithFieldDelimiter(inputString, fieldDelimiter, list);
    return list;
  }

  
  /**
   * Split the given input string, based on the field delimiter.
   *
   * @param inputString the input string
   * @param fieldDelimiter the field delimiter
   * @param list the list
   */
  private void splitDelimitedString(String inputString, char fieldDelimiter, List<String> list) {
    
    FileAttributePreparerSplitter fileAttributePreparerSplitter =
        new FileAttributePreparerSplitter();
    fileAttributePreparerSplitter.setCurrentPosition(INDEX_ZERO);

    splitIfStartsWithDoubleQuote(inputString, fieldDelimiter, list, fileAttributePreparerSplitter);

    while (fileAttributePreparerSplitter.getCurrentPosition() < inputString.length()) {
      fileAttributePreparerSplitter.setEndPosition(inputString.indexOf(fieldDelimiter, fileAttributePreparerSplitter.getCurrentPosition()));

      if (fileAttributePreparerSplitter.getEndPosition() == DELIMITER_NOT_FOUND) {
        list.add(inputString.substring(fileAttributePreparerSplitter.getCurrentPosition()));
        break;
      } else {
        if (fileAttributePreparerSplitter.getCurrentPosition() != fileAttributePreparerSplitter.getEndPosition()) {
          list.add(inputString.substring(fileAttributePreparerSplitter.getCurrentPosition(), fileAttributePreparerSplitter.getEndPosition()));
        }

        fileAttributePreparerSplitter.setNext(fileAttributePreparerSplitter.getEndPosition() + ADD_ONE);
        if (fileAttributePreparerSplitter.getNext() < inputString.length()
            && inputString.charAt(fileAttributePreparerSplitter.getNext()) == fieldDelimiter) {
          list.add("");
          fileAttributePreparerSplitter.setCurrentPosition(fileAttributePreparerSplitter.getEndPosition()
              + ADD_ONE);
        } else if (fileAttributePreparerSplitter.getNext() < inputString.length()
            && inputString.charAt(fileAttributePreparerSplitter.getNext()) == QUOTE) {
              splitTheStringWithinQuotes(inputString, fieldDelimiter, list, fileAttributePreparerSplitter);
        } else {
          fileAttributePreparerSplitter.setCurrentPosition(fileAttributePreparerSplitter.getEndPosition()
              + ADD_ONE);
        }
      }
    }
  }
  
  /**
   * split the string if it begins with double quote.
   * like "A"
   * @param inputString the input string
   * @param fieldDelimiter the field delimiter
   * @param list the list
   * @param fileAttributePreparerSplitter the file attribute preparer splitter
   */
  private void splitIfStartsWithDoubleQuote(String inputString, char fieldDelimiter, List<
      String> list, FileAttributePreparerSplitter fileAttributePreparerSplitter) {
    if (fileAttributePreparerSplitter.getCurrentPosition() == INDEX_ZERO && inputString.charAt(INDEX_ZERO) == QUOTE) {
      splitTheStringWithinQuotes(inputString, fieldDelimiter, list, fileAttributePreparerSplitter);
      if (!fileAttributePreparerSplitter.isInQuote()
          && fileAttributePreparerSplitter.getEndQuotePosition() == ENDQUOTE_NOT_FOUND) {
        fileAttributePreparerSplitter.setCurrentPosition(INDEX_ZERO);
      }
    }
  }

  /**
   * split the string if it starts and ends with a double quote.
   *
   * @param inputString the input string
   * @param fieldDelimiter the field delimiter
   * @param list the list
   * @param fileAttributePreparerSplitter the file attribute preparer splitter
   */
  private void splitTheStringWithinQuotes(String inputString, char fieldDelimiter, List<
      String> list, FileAttributePreparerSplitter fileAttributePreparerSplitter) {
    checkEnclosedWithinQuotes(inputString, fieldDelimiter, fileAttributePreparerSplitter);
    if (fileAttributePreparerSplitter.isInQuote()) {
      list.add(inputString.substring(fileAttributePreparerSplitter.getNext(), fileAttributePreparerSplitter.getEndQuotePosition()
          + ADD_ONE));
      fileAttributePreparerSplitter.setCurrentPosition(fileAttributePreparerSplitter.getEndQuotePosition()
          + ADD_ONE);
      fileAttributePreparerSplitter.setInQuote(false);
    } else {
      fileAttributePreparerSplitter.setCurrentPosition(fileAttributePreparerSplitter.getEndPosition()
          + ADD_ONE);
    }
  }
  
  /**
   * check the string if it starts and ends with the double quote
   * and set value inQuote to true/false.
   *
   * @param inputString the input string
   * @param fieldDelimiter the field delimiter
   * @param fileAttributePreparerSplitter the file attribute preparer splitter
   */
  private void checkEnclosedWithinQuotes(String inputString, char fieldDelimiter, FileAttributePreparerSplitter fileAttributePreparerSplitter) {
    fileAttributePreparerSplitter.setEndQuotePosition(inputString.indexOf(QUOTE, fileAttributePreparerSplitter.getNext()
        + ADD_ONE));
    if (fileAttributePreparerSplitter.getEndQuotePosition() != ENDQUOTE_NOT_FOUND) {
      if (inputString.charAt(inputString.length() - 1) == QUOTE
          && fileAttributePreparerSplitter.getEndQuotePosition() == inputString.length() - 1) {
        fileAttributePreparerSplitter.setInQuote(true);
      } else {
        fileAttributePreparerSplitter.setEndDelimiterAfterQuote(fileAttributePreparerSplitter.getEndQuotePosition()
            + ADD_ONE);
        if (fileAttributePreparerSplitter.getEndDelimiterAfterQuote() < inputString.length()
            && inputString.charAt(fileAttributePreparerSplitter.getEndDelimiterAfterQuote()) == fieldDelimiter) {
          fileAttributePreparerSplitter.setInQuote(true);
        }
      }
    }
  }

  
  /**
   * Split if ends with field delimiter.
   * like input A,B,c,, output will be [A , B , c , ,]
   * @param inputString the input string
   * @param fieldDelimiter the field delimiter
   * @param list the list
   */
  private void splitIfEndsWithFieldDelimiter(String inputString, char fieldDelimiter, List<
      String> list) {
    if (inputString.charAt(inputString.length() - 1) == fieldDelimiter) {
      list.add("");
    }
  }
}
