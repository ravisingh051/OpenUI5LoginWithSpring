package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.event.AdaptDatatypeTransformationExceptionOccuredEvent;
import com.adapt.event.EventFactory;
import com.adapt.event.EventMessage;
import com.adapt.event.EventTypeEnum;
import com.adapt.event.JobFailedOccurredEvent;
import com.adapt.exception.NullResponseException;
import com.adapt.file.entity.JobDetails;
import com.adapt.file.service.EventNotificationService;
import com.adapt.file.service.JobService;
import com.adapt.file.util.AdaptSourceUtils;
import com.alight.adapt.datasets.AbstractDataset;
import com.alight.idis.jobs.JobStatus;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

@Component("dataTypeTransformExceptionServiceActivator")
@Slf4j
public class DataTypeTransformExceptionServiceActivator {

  @Autowired
  private EventNotificationService eventNotificationService;

  @Autowired
  private JobService jobService;

  private static final String JOB_FAILED_MESSAGE = "No Records found for Processing";
  private static final String JOB_FAILED_PAYLOADEMPTY_MESSAGE = "No Records found for Processing , PAYLOADEMPTY";

  /**
   * Update job status.
   *
   * @param message
   *          the message
   */
  public Message<?> sendEventAndFilter(Message<List<AbstractDataset>> message) {
    MessageHeaders headers = message.getHeaders();
    List<AbstractDataset> payload = message.getPayload();
    List<AbstractDataset> sucessRecords = new ArrayList<>(payload.size());
    if (!payload.isEmpty()) {
      int errorCount = 0;
      for (AbstractDataset abstractDataset : payload) {
        if (abstractDataset.hasErrors()) {
          // SEND ERROR EVENT
          sendDataTypeTransformationExceptionEvent(headers, abstractDataset);
          errorCount++;
          // Update Error Count
        } else {
          sucessRecords.add(abstractDataset);
        }
      }
      if (errorCount > 0) {

        Object jobId = headers.get(Constant.JOB_ID_HEADER);

        JobDetails jobDetails = new JobDetails();
        jobDetails.setJobId((Integer) jobId);
        jobDetails.setTotalErrorRecords(errorCount);
        jobDetails.setTotalRecordsProcessedAdapt(errorCount);
        jobDetails.setTotalWarningRecords(0);
        jobDetails.setTotalIgnoredRecords(0);
        log.debug("Updating Error Count for DataType Transformation Exception {} ", errorCount);
        jobService.updateJobErrorCount(jobDetails);
      }
      if (!sucessRecords.isEmpty() && !payload.isEmpty()) {
        message = MessageBuilder.withPayload(sucessRecords).copyHeadersIfAbsent(headers).build();
      } else {
        // mark file as failed
        sendJobFailedEventEmptyAllRecordError(headers);
        throw new NullResponseException("All reacords Error");
      }
    } else {
      // file failed
      sendJobFailedEventEmptyPayLoad(headers);
      throw new NullResponseException("Empty Records");
    }

    return message;
  }

  private void sendDataTypeTransformationExceptionEvent(MessageHeaders messageHeaders,
      AbstractDataset abstractDataset) {

    Integer jobId = AdaptSourceUtils.getJobIdFromHeader(messageHeaders);
    Integer fileId = AdaptSourceUtils.getFileIdFromHeader(messageHeaders);
    Integer fileVersion = AdaptSourceUtils.getFileVersionFromHeader(messageHeaders);
    Integer fileIdentifier = AdaptSourceUtils.getFileIdentifierFromHeader(messageHeaders);
    AdaptDatatypeTransformationExceptionOccuredEvent adaptDatatypeTransformationExceptionOccured = (AdaptDatatypeTransformationExceptionOccuredEvent) EventFactory
        .getEventType(EventTypeEnum.DATATYPE_TRANSFORMATION_EXCEPTION_OCCURED);
    adaptDatatypeTransformationExceptionOccured.setFileId(fileId);
    adaptDatatypeTransformationExceptionOccured.setJobId(jobId);
    adaptDatatypeTransformationExceptionOccured.setFileVersion(fileVersion);
    adaptDatatypeTransformationExceptionOccured.setFileIdentifier(fileIdentifier);
    adaptDatatypeTransformationExceptionOccured.setTime(LocalDateTime.now());
    adaptDatatypeTransformationExceptionOccured
        .setEventType(EventTypeEnum.DATATYPE_TRANSFORMATION_EXCEPTION_OCCURED.name());
    EventMessage eventMessage = new EventMessage();
    eventMessage.setMessage(abstractDataset.getRuleFailures().get(0).getErrorDescription());
    adaptDatatypeTransformationExceptionOccured.setMessage(eventMessage);
    log.debug("Sending DataType Transformation Execption Occurred Event");
    eventNotificationService
        .sendDataTypeTransformationExceptionEvent(adaptDatatypeTransformationExceptionOccured);

  }

  private void sendJobFailedEventEmptyPayLoad(MessageHeaders messageHeaders) {

    log.debug(JOB_FAILED_PAYLOADEMPTY_MESSAGE);
    sendJobFailedEvent(messageHeaders, JOB_FAILED_PAYLOADEMPTY_MESSAGE);

  }

  private void sendJobFailedEventEmptyAllRecordError(MessageHeaders messageHeaders) {

    log.debug(JOB_FAILED_MESSAGE);
    sendJobFailedEvent(messageHeaders, JOB_FAILED_MESSAGE);

  }

  private void sendJobFailedEvent(MessageHeaders messageHeaders, String message) {

    Integer jobId = AdaptSourceUtils.getJobIdFromHeader(messageHeaders);
    Integer fileId = AdaptSourceUtils.getFileIdFromHeader(messageHeaders);
    Integer fileVersion = AdaptSourceUtils.getFileVersionFromHeader(messageHeaders);
    Integer fileIdentifier = AdaptSourceUtils.getFileIdentifierFromHeader(messageHeaders);
    JobFailedOccurredEvent jobFailedOccurredEvent = (JobFailedOccurredEvent) EventFactory
        .getEventType(EventTypeEnum.JOB_FAILED);
    jobFailedOccurredEvent.setFileId(fileId);
    jobFailedOccurredEvent.setJobId(jobId);
    jobFailedOccurredEvent.setFileVersion(fileVersion);
    jobFailedOccurredEvent.setFileIdentifier(fileIdentifier);
    jobFailedOccurredEvent.setTime(LocalDateTime.now());
    jobFailedOccurredEvent.setEventType(EventTypeEnum.JOB_FAILED.name());
    jobFailedOccurredEvent.setJobStatus(JobStatus.FAILED.getValue());
    EventMessage eventMessage = new EventMessage();
    eventMessage.setMessage(message);
    jobFailedOccurredEvent.setMessage(eventMessage);

    eventNotificationService.sendJobFailedEvent(jobFailedOccurredEvent);

  }
}