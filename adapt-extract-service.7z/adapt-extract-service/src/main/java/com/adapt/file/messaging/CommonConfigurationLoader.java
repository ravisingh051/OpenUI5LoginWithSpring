package com.adapt.file.messaging;

import org.springframework.messaging.Message;

/**
 * Abstract class for enriching the header with the headers of EXPECTED and JOB_MODEL.
 * Implementations of this class simply need to implement the findJobModel() method to return a
 * single JobModel instance.
 *
 */
public interface CommonConfigurationLoader {

  Message<?> load(Message<?> message);

}
