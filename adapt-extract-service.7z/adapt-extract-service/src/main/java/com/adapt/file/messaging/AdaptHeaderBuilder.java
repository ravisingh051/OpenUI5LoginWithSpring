package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.AdaptHeaderBuilderDirector;
import com.alight.adapt.header.AdaptHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;

@Service("adaptHeaderBuilder")
public class AdaptHeaderBuilder {

  private static final Logger LOGGER = LoggerFactory.getLogger(AdaptHeaderBuilder.class);

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public AdaptHeaderBuilder() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  /**
   * Builds the.
   *
   * @param message
   *          the message
   * @return the message
   * @throws Exception
   *           the exception
   */
  public Message<?> build(Message<?> message) throws Exception {
    LOGGER.debug("build adapt header");

    MessageHeaders messageHeaders = message.getHeaders();

    AdaptHeader adaptHeader = AdaptHeaderBuilderDirector
        .constructAdaptHeaderForInbound(messageHeaders);

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(message.getPayload())
        .setHeader(Constant.FILE_TYPE_HEADER, message.getHeaders().get(Constant.FILE_TYPE_HEADER));
    builder.copyHeadersIfAbsent(messageHeaders);
    builder.setHeader(Constant.ADAPT_HEADER, jsonObjectMapper.toJson(adaptHeader));

    return builder.build();
  }
}
