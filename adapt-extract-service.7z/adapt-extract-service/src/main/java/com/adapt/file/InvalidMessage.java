package com.adapt.file;

public class InvalidMessage extends RuntimeException {

  private static final long serialVersionUID = 6041589981451913315L;

  public InvalidMessage(String message) {
    super(message);
  }

  public InvalidMessage(String message, Throwable cause) {
    super(message, cause);
  }

}
