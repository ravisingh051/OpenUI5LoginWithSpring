package com.adapt.file.messaging;

import com.adapt.exception.UnsuccessfulFileRenameException;
import java.io.File;
import org.springframework.stereotype.Component;

@Component("fileLocker")
public class FileLocker implements Locker {

  public static final String FILE_RECEIVED_EXTENSIONS = ".received";

  @Override
  public Object lock(Object payload) {
    File inFile = (File) payload;
    File outFile = new File(inFile.getParent(), inFile.getName() + FILE_RECEIVED_EXTENSIONS);
    boolean fileRenameResult = inFile.renameTo(outFile);
    if (!fileRenameResult) {
      throw new UnsuccessfulFileRenameException("Could not rename file: " + inFile.getName());
    }
    return outFile;
  }

}
