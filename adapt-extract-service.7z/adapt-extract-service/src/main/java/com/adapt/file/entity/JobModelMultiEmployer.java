package com.adapt.file.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JobModelMultiEmployer implements Serializable {

  private static final long serialVersionUID = -794348659821643947L;
  private Integer jobId;
  private LocalDate expectedDate;
  private Integer priority;
  private FileOutBoundModel fileOutBoundModel;
  private Boolean fullOrChange;
  private String sourceType;
  private String targetType;
  private String endPointUrl;
  private Map<String, Object> extractionParameters = new HashMap<>();

  private List<EmployerInfo> employerInfoList;

  private Integer profileId;

  public FileOutBoundModel getFileOutBoundModel() {
    return fileOutBoundModel;
  }

  public void setFileOutBoundModel(FileOutBoundModel fileOutBoundModel) {
    this.fileOutBoundModel = fileOutBoundModel;
  }

  public Map<String, Object> getExtractionParameters() {
    return extractionParameters;
  }

  public void setExtractionParameters(Map<String, Object> extractionParameters) {
    this.extractionParameters = extractionParameters;
  }

  public List<EmployerInfo> getEmployerInfoList() {
    return employerInfoList;
  }

  public void setEmployerInfoList(List<EmployerInfo> employerInfoList) {
    this.employerInfoList = employerInfoList;
  }

  public Integer getJobId() {
    return jobId;
  }

  public void setJobId(Integer jobId) {
    this.jobId = jobId;
  }

  public LocalDate getExpectedDate() {
    return expectedDate;
  }

  public void setExpectedDate(LocalDate expectedDate) {
    this.expectedDate = expectedDate;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public Boolean getFullOrChange() {
    return fullOrChange;
  }

  public void setFullOrChange(Boolean fullOrChange) {
    this.fullOrChange = fullOrChange;
  }

  public String getSourceType() {
    return sourceType;
  }

  public void setSourceType(String sourceType) {
    this.sourceType = sourceType;
  }

  public String getTargetType() {
    return targetType;
  }

  public void setTargetType(String targetType) {
    this.targetType = targetType;
  }

  public String getEndPointUrl() {
    return endPointUrl;
  }

  public void setEndPointUrl(String endPointUrl) {
    this.endPointUrl = endPointUrl;
  }

  public Integer getProfileId() {
    return profileId;
  }

  public void setProfileId(Integer profileId) {
    this.profileId = profileId;
  }

  @Override
  public String toString() {
    return "JobModelMultiEmployer [jobId=" + jobId + ", expectedDate=" + expectedDate
        + ", priority=" + priority + ", fileOutBoundModel=" + fileOutBoundModel + ", fullOrChange="
        + fullOrChange + ", sourceType=" + sourceType + ", targetType=" + targetType
        + ", endPointUrl=" + endPointUrl + ", extractionParameters=" + extractionParameters
        + ", employerInfoList=" + employerInfoList + ", profileId=" + profileId + "]";
  }

}
