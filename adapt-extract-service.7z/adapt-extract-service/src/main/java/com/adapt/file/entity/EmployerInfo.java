package com.adapt.file.entity;

import java.io.Serializable;

public class EmployerInfo implements Serializable {

  private static final long serialVersionUID = -5374970652788189430L;
  protected Integer employerId;
  protected String clientId;
  protected String testCfg;

  public EmployerInfo() {
    super();
  }

  public Integer getEmployerId() {
    return employerId;
  }

  public void setEmployerId(Integer employerId) {
    this.employerId = employerId;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getTestCfg() {
    return testCfg;
  }

  public void setTestCfg(String testCfg) {
    this.testCfg = testCfg;
  }

}