package com.adapt.file.messaging;

import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.scheduling.PollSkipStrategy;

@Slf4j
public class BlackoutWindowPollSkipStrategy implements PollSkipStrategy {

  @Override
  public boolean skipPoll() {
    log.warn("return if there is a blackout period in effect");
    return false;
  }
}
