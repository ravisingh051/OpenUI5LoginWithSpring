package com.adapt.file.entity;

import java.io.Serializable;

public class SecondaryDataInfo implements Serializable {

  private static final long serialVersionUID = -8143283321429910720L;

  private String secondaryDataPojoName;

  private String secondaryDataEndpoint;

  public String getSecondaryDataEndpoint() {
    return secondaryDataEndpoint;
  }

  public void setSecondaryDataEndpoint(String enrichmentApiMappedObjEndpoint) {
    this.secondaryDataEndpoint = enrichmentApiMappedObjEndpoint;
  }

  public String getSecondaryDataPojoName() {
    return secondaryDataPojoName;
  }

  public void setSecondaryDataPojoName(String enrichmentApiPojoName) {
    this.secondaryDataPojoName = enrichmentApiPojoName;
  }

}
