package com.adapt.file.messaging;

import com.adapt.config.Constant;
import com.adapt.file.entity.IntermediaryAttributes;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.Section.SectionType;
import com.adapt.file.service.FileAttributePreparer;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("delimitedStringToMapTransformer")
public class DelimitedStringToMapTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(DelimitedStringToMapTransformer.class);

  @Autowired
  private FileAttributePreparer fileAttributePreparer;

  @Override
  protected Message<?> doTransform(Message<?> message) throws Exception {
    Assert.notNull(message, "Messsage should not be null");
    MessageHeaders headers = message.getHeaders();
    Assert.notNull(headers, "headers should not be null");

    JobModel jobModel = (JobModel) headers.get("JOB_MODEL");
    Assert.notNull(jobModel, "jobModel should not be null");

    Map<String, Object> attributes = prepareDetailAttributes(message, jobModel);

    Boolean isHeaderExist = (Boolean) message.getHeaders().get(Constant.IS_HEADER_EXIST_HEADER);
    if (Boolean.TRUE.equals(isHeaderExist)) {
      Map<String, Object> headerAttributes = (Map<String, Object>) headers
          .get(Constant.FILE_HEADER_MAP_HEADER);
      if (headerAttributes != null) {
        LOGGER.debug("number of header configuration found is: {}", headerAttributes.size());
        attributes.putAll(headerAttributes);
      } else {
        LOGGER.warn("trailer is exist in configuration but transform map not found");
      }
    }

    Boolean isTrailerExist = (Boolean) message.getHeaders().get(Constant.IS_TRAILER_EXIST_HEADER);
    if (Boolean.TRUE.equals(isTrailerExist)) {
      Map<String, Object> trailerAttributes = (Map<String, Object>) headers
          .get(Constant.FILE_FOOTER_MAP_HEADER);
      if (trailerAttributes != null) {
        LOGGER.debug("number of trailer configuration found is: {}", trailerAttributes.size());
        attributes.putAll(trailerAttributes);
      } else {
        LOGGER.warn("trailer is exist in configuration but transform map not found");
      }
    }

    MessageBuilder<?> builder = new DefaultMessageBuilderFactory().withPayload(attributes);
    builder.copyHeaders(message.getHeaders());

    return builder.build();
  }

  private Map<String, Object> prepareDetailAttributes(Message<?> message, JobModel jobModel) {
    SectionType sectionType = SectionType.DETAIL;
    IntermediaryAttributes intermediaryAttributes = fileAttributePreparer
        .prepareDelimitedIntermediaryAttributes(jobModel, sectionType);

    return fileAttributePreparer.prepareAttributesMap((String) message.getPayload(),
        jobModel.getFileModel().getMessageFormat().getFieldDelimiter(), intermediaryAttributes);
  }
}
