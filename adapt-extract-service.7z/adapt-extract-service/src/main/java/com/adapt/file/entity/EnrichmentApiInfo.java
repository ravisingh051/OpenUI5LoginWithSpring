package com.adapt.file.entity;

import java.io.Serializable;

public class EnrichmentApiInfo implements Serializable {

  private static final long serialVersionUID = 6147053559514963609L;

  @ColumnIndex(value = 0)
  private String enrichmentApiPojoName;

  @ColumnIndex(value = 1)
  private String enrichmentApiMappedObjEndpoint;

  public String getEnrichmentApiMappedObjEndpoint() {
    return enrichmentApiMappedObjEndpoint;
  }

  public void setEnrichmentApiMappedObjEndpoint(String enrichmentApiMappedObjEndpoint) {
    this.enrichmentApiMappedObjEndpoint = enrichmentApiMappedObjEndpoint;
  }

  public String getEnrichmentApiPojoName() {
    return enrichmentApiPojoName;
  }

  public void setEnrichmentApiPojoName(String enrichmentApiPojoName) {
    this.enrichmentApiPojoName = enrichmentApiPojoName;
  }

}
