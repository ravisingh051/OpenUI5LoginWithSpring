package com.adapt.file.entity;

import java.io.Serializable;

public class Attribute implements Serializable {

  private static final long serialVersionUID = -7688366328957028229L;

  private Integer order;
  private String standardizedName;
  private String datatype;
  private Boolean required;
  private Integer attributeSize;
  private Integer attributeStartPosition;
  private Integer attributeEndPosition;

  public Integer getOrder() {
    return order;
  }

  public void setOrder(Integer order) {
    this.order = order;
  }

  public String getStandardizedName() {
    return standardizedName;
  }

  public void setStandardizedName(String standardizedName) {
    this.standardizedName = standardizedName;
  }

  public String getDatatype() {
    return datatype;
  }

  public void setDatatype(String datatype) {
    this.datatype = datatype;
  }

  public Boolean getRequired() {
    return required;
  }

  public void setRequired(Boolean required) {
    this.required = required;
  }

  public Integer getAttributeSize() {
    return attributeSize;
  }

  public void setAttributeSize(Integer attributeSize) {
    this.attributeSize = attributeSize;
  }

  public Integer getAttributeStartPosition() {
    return attributeStartPosition;
  }

  public void setAttributeStartPosition(Integer attributeStartPosition) {
    this.attributeStartPosition = attributeStartPosition;
  }

  public Integer getAttributeEndPosition() {
    return attributeEndPosition;
  }

  public void setAttributeEndPosition(Integer attributeEndPosition) {
    this.attributeEndPosition = attributeEndPosition;
  }

}
