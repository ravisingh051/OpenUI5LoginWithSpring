package com.adapt.file.messaging;

import com.adapt.config.MessageTypeConfig;
import com.adapt.config.MessageTypeConfigHelper;
import com.adapt.exception.AttributeMapToDatasetTransformerException;
import com.adapt.file.entity.JobModel;
import com.alight.adapt.datasets.AbstractDataset;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.stereotype.Service;

@Service("attributeMapToDatasetTransformer")
@Slf4j
public class AttributeMapToDatasetTransformer extends AbstractAttributeMapToPojoTransformer {

  @Override
  public AbstractDataset transformToPojo(JobModel jobModel, Map<String, Object> attributeMap) {
    log.debug("messge type/file type : {}", jobModel.getFileModel().getFileType().getValue());
    ObjectMapper objectMapper = new ObjectMapper();
    MessageTypeConfig messageTypeConfig = MessageTypeConfigHelper
        .getMessageTypeConfiguration(jobModel.getFileModel().getFileType());
    if (messageTypeConfig != null && messageTypeConfig.getDatasetTransformerClazz() != null) {
      Class<? extends AbstractDataset> targetClazz = messageTypeConfig.getDatasetTransformerClazz();

      AbstractDataset abstractDataset = objectMapper.convertValue(attributeMap, targetClazz);

      Integer employerId = jobModel.getEmployerId();
      if (employerId != null) {
        PropertyAccessorFactory.forBeanPropertyAccess(abstractDataset)
            .setPropertyValue("employerId", jobModel.getEmployerId());
      } else {
        log.warn("Employer Id not Found");
      }
      return abstractDataset;
    } else {
      log.error("target class not found for message type: {}",
          jobModel.getFileModel().getFileType().getValue());
      throw new AttributeMapToDatasetTransformerException(
          INVALID_CONFIGURATION_FOR_TARGET_CLASS_VS_MESSAGE_TYPE);
    }

  }

}