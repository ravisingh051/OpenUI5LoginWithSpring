package com.adapt.file;

import com.adapt.api.config.domain.TransactionExtractionDetails;
import com.adapt.api.config.domain.TransactionExtractionDetailsPaginated;
import com.adapt.config.Constant;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.alight.adapt.header.AdaptHeader;
import com.alight.adapt.header.AdaptHeader.Builder;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

public class AdaptHeaderBuilderDirector {

  private AdaptHeaderBuilderDirector() {
  }

  /**
   * Construct adapt header for extraction data api.
   *
   * @param jobModelMultiEmployer
   *          the job model multi employer
   * @param transactionExtractionDetailsPaginated
   *          the core transaction extraction details paginated
   * @return the adapt header
   */
  public static AdaptHeader constructAdaptHeaderForExtractionDataApi(
      JobModelMultiEmployer jobModelMultiEmployer,
      TransactionExtractionDetailsPaginated transactionExtractionDetailsPaginated) {
    Builder adaptHeaderBuilder = new AdaptHeader.Builder();
    adaptHeaderBuilder.setJobId(jobModelMultiEmployer.getJobId())
        .setSourceClientId(transactionExtractionDetailsPaginated.getSourceEmployerId())
        .setFileIdentifier(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier())
        .setSourceType(jobModelMultiEmployer.getSourceType())
        .setTargetType(jobModelMultiEmployer.getTargetType())
        .setRecordId(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier())
        .setTestCfg(transactionExtractionDetailsPaginated.getTestCfg());
    return adaptHeaderBuilder.build();
  }

  /**
   * Construct adapt header for extraction count api.
   *
   * @param jobModelMultiEmployer
   *          the job model multi employer
   * @param transactionExtractionDetails
   *          the core transaction extraction details
   * @return the adapt header
   */
  public static AdaptHeader constructAdaptHeaderForExtractionCountApi(
      JobModelMultiEmployer jobModelMultiEmployer,
      TransactionExtractionDetails transactionExtractionDetails) {
    Builder adaptHeaderBuilder = new AdaptHeader.Builder();
    adaptHeaderBuilder.setJobId(jobModelMultiEmployer.getJobId())
        .setSourceClientId(transactionExtractionDetails.getSourceEmployerId())
        .setSourceType(jobModelMultiEmployer.getSourceType())
        .setTargetType(jobModelMultiEmployer.getTargetType())
        .setRecordId(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier())
        .setTestCfg(transactionExtractionDetails.getTestCfg());
    return adaptHeaderBuilder.build();
  }

  /**
   * Construct adapt header for target service api.
   *
   * @param jobModelMultiEmployer
   *          the job model multi employer
   * @param correlationId
   *          the correlation id
   * @param sequenceNumberHeader
   *          the sequence number header
   * @param sequenceSizeHeader
   *          the sequence size header
   * @param trailerUuid
   *          the trailerClaimCheck
   * @param headerUuid
   *          the headerClaimCheck
   * @return the adapt header
   */
  public static AdaptHeader constructAdaptHeaderForTargetServiceApi(
      JobModelMultiEmployer jobModelMultiEmployer, String correlationId,
      Integer sequenceNumberHeader, Integer sequenceSizeHeader, String headerUuid,
      String trailerUuid) {
    Builder adaptHeaderBuilder = new AdaptHeader.Builder();

    adaptHeaderBuilder
        .setFileIdentifier(jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier());

    adaptHeaderBuilder.setSourceType(jobModelMultiEmployer.getSourceType());
    adaptHeaderBuilder.setTargetType(jobModelMultiEmployer.getTargetType());

    adaptHeaderBuilder.setFileId(jobModelMultiEmployer.getFileOutBoundModel().getFileId());

    Assert.notNull(jobModelMultiEmployer.getEmployerInfoList().get(0), "TestCfg cannot be null");
    adaptHeaderBuilder
        .setSourceClientId(jobModelMultiEmployer.getEmployerInfoList().get(0).getEmployerId());
    adaptHeaderBuilder.setTestCfg(jobModelMultiEmployer.getEmployerInfoList().get(0).getTestCfg());
    adaptHeaderBuilder.setMinRowsRequired(
        jobModelMultiEmployer.getFileOutBoundModel().getFileMinRecordCountAllowed());
    adaptHeaderBuilder.setMaxRowsAllowed(
        jobModelMultiEmployer.getFileOutBoundModel().getFileMaxRecordCountAllowed());
    adaptHeaderBuilder.setProfileId(jobModelMultiEmployer.getProfileId());

    adaptHeaderBuilder
        .setFileVersion(jobModelMultiEmployer.getFileOutBoundModel().getFileVersion());

    adaptHeaderBuilder
        .setFileType(jobModelMultiEmployer.getFileOutBoundModel().getFileType().getValue());

    adaptHeaderBuilder.setMasterFileTemplateId(
        jobModelMultiEmployer.getFileOutBoundModel().getMasterFileTemplateId());

    adaptHeaderBuilder.setMasterFileTemplateVersion(
        jobModelMultiEmployer.getFileOutBoundModel().getMasterFileTemplateVersion());

    adaptHeaderBuilder.setJobId(jobModelMultiEmployer.getJobId());

    if (correlationId != null) {
      adaptHeaderBuilder.setCorrelationId(correlationId);
    }

    if (sequenceNumberHeader != null) {
      adaptHeaderBuilder.setChunkNumber(sequenceNumberHeader);
    }

    if (sequenceSizeHeader != null) {
      adaptHeaderBuilder.setChunkSize(sequenceSizeHeader);
    }

    adaptHeaderBuilder.setPriority(jobModelMultiEmployer.getPriority());

    adaptHeaderBuilder
        .setErrorThreshold(jobModelMultiEmployer.getFileOutBoundModel().getErrorThreshold());

    adaptHeaderBuilder.setErrorThresholdFormat(jobModelMultiEmployer.getFileOutBoundModel()
        .getFileProcessingErrorThresholdFormat().name());

    adaptHeaderBuilder
        .setResultsMode(jobModelMultiEmployer.getFileOutBoundModel().getResultsMode());

    adaptHeaderBuilder.setTransmissionName(
        jobModelMultiEmployer.getFileOutBoundModel().getFileTransmissionName());

    adaptHeaderBuilder.setHeaderUuid(headerUuid);
    adaptHeaderBuilder.setTrailerUuid(trailerUuid);
    return adaptHeaderBuilder.build();

  }

  /**
   * Construct adapt header for inbound.
   *
   * @param MessageHeaders
   *          the messageHeaders
   * @return the adapt header
   */
  public static AdaptHeader constructAdaptHeaderForInbound(Map<?, ?> messageHeaders) {
    JobModel job = null;
    if (messageHeaders.get(Constant.JOB_MODEL_HEADER) != null) {
      job = (JobModel) messageHeaders.get(Constant.JOB_MODEL_HEADER);
    }

    Builder adaptHeaderBuilder = new AdaptHeader.Builder();

    // File

    if (messageHeaders.get(Constant.FILE_IDENTIFIER) != null) {
      adaptHeaderBuilder.setFileIdentifier(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.FILE_IDENTIFIER))));
    }
    if (messageHeaders.get(Constant.FILE_ID) != null) {
      adaptHeaderBuilder
          .setFileId(Integer.parseInt(String.valueOf(messageHeaders.get(Constant.FILE_ID))));
    }
    if (messageHeaders.get(Constant.FILE_VERSION) != null) {
      adaptHeaderBuilder.setFileVersion(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.FILE_VERSION))));
    }

    if (messageHeaders.get(Constant.FILE_TYPE_HEADER) != null) {
      adaptHeaderBuilder.setFileType(String.valueOf(messageHeaders.get(Constant.FILE_TYPE_HEADER)));
    }

    if (messageHeaders.get(Constant.FILE_RECORD_COUNT) != null) {
      adaptHeaderBuilder.setFileRecordCount(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.FILE_RECORD_COUNT))));
    }

    if (messageHeaders.get(Constant.MASTER_FILE_TEMPLATE_ID_HEADER) != null) {
      adaptHeaderBuilder.setMasterFileTemplateId(Integer
          .parseInt(String.valueOf(messageHeaders.get(Constant.MASTER_FILE_TEMPLATE_ID_HEADER))));
    }

    if (messageHeaders.get(Constant.MASTER_FILE_TEMPLATE_VERSION_HEADER) != null) {
      adaptHeaderBuilder.setMasterFileTemplateVersion(Integer.parseInt(
          String.valueOf(messageHeaders.get(Constant.MASTER_FILE_TEMPLATE_VERSION_HEADER))));

    }

    if (job != null && job.getCloneNumberList() != null && !job.getCloneNumberList().isEmpty()) {
      adaptHeaderBuilder.setRecordCopyIds(job.getCloneNumberList());
    }

    // InboundFile

    if (messageHeaders.get(Constant.FULL_OR_CHANGE_FILE_HEADER) != null) {
      adaptHeaderBuilder.setFullOrChange(
          Boolean.valueOf(String.valueOf(messageHeaders.get(Constant.FULL_OR_CHANGE_FILE_HEADER))));
    }

    if (messageHeaders.get(Constant.ORIGINAL_FILE_NAME_HEADER) != null) {
      adaptHeaderBuilder.setOriginalFileNameInbound(
          String.valueOf(messageHeaders.get(Constant.ORIGINAL_FILE_NAME_HEADER)));

    }

    if (messageHeaders.get(Constant.FILE_FOOTER_HEADER) != null) {
      adaptHeaderBuilder.setFileFooter(
          StringUtils.trim(String.valueOf(messageHeaders.get(Constant.FILE_FOOTER_HEADER))));
    }

    if (messageHeaders.get(Constant.FILE_HEADER_HEADER) != null) {
      adaptHeaderBuilder.setFileHeader(
          StringUtils.trim(String.valueOf(messageHeaders.get(Constant.FILE_HEADER_HEADER))));
    }

    // Processing

    if (job != null) {
      adaptHeaderBuilder.setSourceType(job.getSourceType());
      adaptHeaderBuilder.setTargetType(job.getTargetType());
    }

    if (messageHeaders.get(Constant.JOB_ID_HEADER) != null) {
      adaptHeaderBuilder
          .setJobId(Integer.parseInt(String.valueOf(messageHeaders.get(Constant.JOB_ID_HEADER))));
    }

    if (messageHeaders.get("correlationId") != null) {
      adaptHeaderBuilder.setCorrelationId(String.valueOf(messageHeaders.get("correlationId")));
    }

    if (messageHeaders.get(Constant.SEQUENCE_NUMBER_HEADER) != null) {
      adaptHeaderBuilder.setChunkNumber(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.SEQUENCE_NUMBER_HEADER))));
    }

    if (messageHeaders.get(Constant.SEQUENCE_SIZE_HEADER) != null) {
      adaptHeaderBuilder.setChunkSize(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.SEQUENCE_SIZE_HEADER))));
    }

    if (messageHeaders.get("priority") != null) {
      adaptHeaderBuilder
          .setPriority(Integer.parseInt(String.valueOf(messageHeaders.get("priority"))));
    }

    if (messageHeaders.get(Constant.SECONDARY_DATA_INFO_HEADER) != null) {
      adaptHeaderBuilder.setSecondaryDataInfo(
          String.valueOf(messageHeaders.get(Constant.SECONDARY_DATA_INFO_HEADER)));

    }

    if (messageHeaders.get(Constant.ERROR_THRESHOLD_HEADER) != null) {
      adaptHeaderBuilder.setErrorThreshold(
          Integer.parseInt(String.valueOf(messageHeaders.get(Constant.ERROR_THRESHOLD_HEADER))));
    }

    if (messageHeaders.get(Constant.FILE_PROCESSING_ERROR_THRESHOLD_FORMAT_HEADER) != null) {
      adaptHeaderBuilder.setErrorThresholdFormat(String
          .valueOf(messageHeaders.get(Constant.FILE_PROCESSING_ERROR_THRESHOLD_FORMAT_HEADER)));
    }

    if (messageHeaders.get(Constant.RESULTS_MODE_HEADER) != null) {
      adaptHeaderBuilder.setResultsMode(
          Boolean.valueOf(String.valueOf(messageHeaders.get(Constant.RESULTS_MODE_HEADER))));

    }

    // Adapt Header

    if (messageHeaders.get(Constant.EMPLOYER_ID_HEADER) != null) {
      adaptHeaderBuilder.setSourceClientId(
          Integer.valueOf(String.valueOf(messageHeaders.get(Constant.EMPLOYER_ID_HEADER))));
    }

    if (messageHeaders.get(Constant.TEST_CFG_HEADER) != null) {
      adaptHeaderBuilder.setTestCfg(String.valueOf(messageHeaders.get(Constant.TEST_CFG_HEADER)));
    }

    if (messageHeaders.get(Constant.CLIENT_ID_HEADER) != null) {
      adaptHeaderBuilder.setClientId(
          Integer.valueOf(String.valueOf(messageHeaders.get(Constant.CLIENT_ID_HEADER))));
    }

    return adaptHeaderBuilder.build();
  }
}
