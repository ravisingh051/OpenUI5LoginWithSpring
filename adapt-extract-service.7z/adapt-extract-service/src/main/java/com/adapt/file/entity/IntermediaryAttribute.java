package com.adapt.file.entity;

public class IntermediaryAttribute {

  private String standardizedName;
  private String datatype;
  private Boolean required;
  private Object value;
  private Integer attributeSize;
  private Integer attributeStartPosition;
  private Integer attributeEndPosition;

  /**
   * Instantiates a new intermediary attribute.
   *
   * @param standardName
   *          the standard name
   * @param datatype
   *          the datatype
   * @param required
   *          the required
   * @param attributeSize
   *          the attribute size
   * @param attributeStartPosition
   *          the attribute start position
   * @param attributeEndPosition
   *          the attribute end position
   */
  public IntermediaryAttribute(String standardName, String datatype, Boolean required,
      Integer attributeSize, Integer attributeStartPosition, Integer attributeEndPosition) {
    this.standardizedName = standardName;
    this.datatype = datatype;
    this.required = required;
    this.attributeSize = attributeSize;
    this.attributeStartPosition = attributeStartPosition;
    this.attributeEndPosition = attributeEndPosition;
  }

  public String getStandardizedName() {
    return standardizedName;
  }

  public String getDatatype() {
    return datatype;
  }

  public Boolean getRequired() {
    return required;
  }

  public Object getValue() {
    return value;
  }

  public Integer getAttributeSize() {
    return attributeSize;
  }

  public Integer getAttributeStartPosition() {
    return attributeStartPosition;
  }

  public Integer getAttributeEndPosition() {
    return attributeEndPosition;
  }

  public void setValue(Object value) {
    this.value = value;
  }

}
