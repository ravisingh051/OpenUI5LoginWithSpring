package com.adapt.workorder.messaging;

import com.adapt.file.entity.JobPriorityEntity;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("jobPriorityEntityRowMapper")
public class JobPriorityEntityRowMapper implements RowMapper<JobPriorityEntity> {
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_JOB_ID = "job_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_SLA = "is_sla_mapped";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_FILE_ID = "file_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_EMPLOYER_IDS = "employer_ids";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_TRADING_PARTNER = "trading_partner_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_FILE_TYPE = "file_type_id";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_DIRECTION = "direction";
  public static final String JOB_PRIORITIZATION_ROW_MAPPING_EXPECTED_DATE = "expected_start_date";
  public static final String JOB_PRIORITIZATION_EXPLICIT_HIGH_PRIORITIZATION = "explicit_high_prioritization";
  public static final String JOB_PRIORITIZATION_EXPLICIT_LOW_PRIORITIZATION = "explicit_low_prioritization";
  public static final String JOB_PRIORITIZATION_EXPLICIT_PRIORITIZATION_DATE = "explicit_prioritization_date";

  @Override
  public JobPriorityEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
    JobPriorityEntity jobPriorityEntity = new JobPriorityEntity();
    jobPriorityEntity.setJobId(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_JOB_ID));
    jobPriorityEntity.setIsSlaMapped(rs.getBoolean(JOB_PRIORITIZATION_ROW_MAPPING_SLA));
    jobPriorityEntity.setFileId(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_FILE_ID));
    jobPriorityEntity.setEmployerIds(rs.getString(JOB_PRIORITIZATION_ROW_MAPPING_EMPLOYER_IDS));
    jobPriorityEntity
        .setTradingPartnerId(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_TRADING_PARTNER));
    jobPriorityEntity.setFileTypeId(rs.getInt(JOB_PRIORITIZATION_ROW_MAPPING_FILE_TYPE));
    jobPriorityEntity.setDirection(rs.getString(JOB_PRIORITIZATION_ROW_MAPPING_DIRECTION));
    jobPriorityEntity
        .setExpectedStartDate(rs.getDate(JOB_PRIORITIZATION_ROW_MAPPING_EXPECTED_DATE));
    jobPriorityEntity.setExplicitHighPrioritization(
        rs.getBoolean(JOB_PRIORITIZATION_EXPLICIT_HIGH_PRIORITIZATION));
    jobPriorityEntity.setExplicitLowPrioritization(
        rs.getBoolean(JOB_PRIORITIZATION_EXPLICIT_LOW_PRIORITIZATION));

    Timestamp timestamp = rs.getTimestamp(JOB_PRIORITIZATION_EXPLICIT_PRIORITIZATION_DATE);
    if (timestamp != null) {
      jobPriorityEntity.setExplicitPrioritizationDate(new Date(timestamp.getTime()));
    }

    return jobPriorityEntity;
  }

}
