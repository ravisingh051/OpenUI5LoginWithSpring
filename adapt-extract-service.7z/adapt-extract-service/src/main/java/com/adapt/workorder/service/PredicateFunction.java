package com.adapt.workorder.service;

import com.adapt.file.entity.JobPriorityEntity;
import java.util.function.Predicate;

@FunctionalInterface
public interface PredicateFunction<R> {

  Predicate<JobPriorityEntity> predicate(Object r);
}
