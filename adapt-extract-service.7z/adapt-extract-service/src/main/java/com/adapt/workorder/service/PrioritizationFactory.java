package com.adapt.workorder.service;

import com.adapt.file.entity.JobPriorityEntity;
import com.adapt.workorder.config.ClassificationTypeEnum;
import java.util.EnumMap;
import java.util.function.Predicate;

public class PrioritizationFactory {

  private static final EnumMap<ClassificationTypeEnum, PredicateFunction<?>> REGISTER_EVENT = new EnumMap<>(
      ClassificationTypeEnum.class);

  private PrioritizationFactory() {
  }

  static {

    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.SLA,
        PriorityPredicateFunctions::predicateSla);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.FILE_ID,
        PriorityPredicateFunctions::predicateFileId);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.EMPLOYER,
        PriorityPredicateFunctions::predicateEmployer);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.TRADING_PARTNER,
        PriorityPredicateFunctions::predicateTradingPartner);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.FILE_TYPE,
        PriorityPredicateFunctions::predicateFileType);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.FILE_DIRECTION,
        PriorityPredicateFunctions::predicateFileDirection);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.PREVIOUS_DAY,
        PriorityPredicateFunctions::predicatePreviousDay);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.EXPLICIT_HIGH_PRIORITIZATION,
        PriorityPredicateFunctions::predicateExplicitHighPrioritization);
    PrioritizationFactory.registerPredicate(ClassificationTypeEnum.EXPLICIT_LOW_PRIORITIZATION,
        PriorityPredicateFunctions::predicateExplicitLowPrioritization);

  }

  public static void registerPredicate(ClassificationTypeEnum eventType, PredicateFunction<?> a) {
    REGISTER_EVENT.put(eventType, a);
  }

  /**
   * Gets the event type.
   *
   * @param classificationTypeEnum
   *          the Classification type enum
   * @return the Predicate of JobPriority
   */
  public static Predicate<JobPriorityEntity> getPredicate(
      ClassificationTypeEnum classificationTypeEnum, Object value) {
    return REGISTER_EVENT.get(classificationTypeEnum).predicate(value);
  }

}
