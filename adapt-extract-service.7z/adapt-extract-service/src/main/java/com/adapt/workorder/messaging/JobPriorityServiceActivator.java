package com.adapt.workorder.messaging;

import com.adapt.file.entity.JobPriorityEntity;
import com.adapt.file.entity.JobPriortizationPayload;
import com.adapt.file.entity.PriorityInfoEntity;
import com.adapt.workorder.config.ClassificationTypeEnum;
import com.adapt.workorder.service.PrioritizationFactory;
import com.adapt.workorder.service.PriorityPredicateFunctions;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("jobPriorityServiceActivator")
public class JobPriorityServiceActivator {

  private static final Logger LOGGER = LoggerFactory.getLogger(JobPriorityServiceActivator.class);

  /**
   * Sort all jobs.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> sortAllJobs(Message<?> message) {
    LOGGER.debug("Starting Job Prioritization Sorting ");
    JobPriortizationPayload jobPriortizationPayload = (JobPriortizationPayload) message
        .getPayload();
    List<JobPriorityEntity> jobPriorityEntitiesFilteredFinal = new ArrayList<>();
    Assert.notNull(jobPriortizationPayload, "jobPriortizationPayload should not be null");
    if (jobPriortizationPayload.getJobPriorityListEntity() != null
        && !jobPriortizationPayload.getJobPriorityListEntity().isEmpty()) {

      List<JobPriorityEntity> jobPriorityEntitiesActual = jobPriortizationPayload
          .getJobPriorityListEntity();
      if (jobPriortizationPayload.getPriorityInfoListEntity() != null
          && !jobPriortizationPayload.getPriorityInfoListEntity().isEmpty()) {

        LOGGER.debug("Total count Before Sorting Prioritization: {} ",
            jobPriorityEntitiesActual.size());
        // Here we need to do Prioritization for the Explicit High Jobs
        List<JobPriorityEntity> jobPriorityEntitiesFilteredExplicitHigh = prioritizeJob(
            ClassificationTypeEnum.EXPLICIT_HIGH_PRIORITIZATION, "true", jobPriorityEntitiesActual);
        List<JobPriorityEntity> jobPriorityEntitiesFilteredExplicitLowSorted = new ArrayList<>();
        if (!jobPriorityEntitiesFilteredExplicitHigh.isEmpty()) {
          jobPriorityEntitiesActual.removeAll(jobPriorityEntitiesFilteredExplicitHigh);
          // SORTING BASED ON EXPLICITDATE
          List<JobPriorityEntity> jobPriorityEntitiesFilteredExplicitHighSorted = sortByDateDesc(
              jobPriorityEntitiesFilteredExplicitHigh);
          jobPriorityEntitiesFilteredFinal.addAll(jobPriorityEntitiesFilteredExplicitHighSorted);
        }
        // Here we need to do Prioritization for the Explicit Low Jobs
        List<JobPriorityEntity> jobPriorityEntitiesFilteredExplicitLow = prioritizeJob(
            ClassificationTypeEnum.EXPLICIT_LOW_PRIORITIZATION, "true", jobPriorityEntitiesActual);

        if (!jobPriorityEntitiesFilteredExplicitLow.isEmpty()) {
          jobPriorityEntitiesActual.removeAll(jobPriorityEntitiesFilteredExplicitLow);
          // SORTING BASED ON EXPLICITDATE
          jobPriorityEntitiesFilteredExplicitLowSorted = sortByDateAsc(
              jobPriorityEntitiesFilteredExplicitLow);

        }
        for (PriorityInfoEntity priorityInfoEntity : jobPriortizationPayload
            .getPriorityInfoListEntity()) {
          ClassificationTypeEnum classificationTypeEnum = ClassificationTypeEnum
              .getEnumFromValue(priorityInfoEntity.getCriteria());

          if (classificationTypeEnum != null) {

            List<JobPriorityEntity> jobPriorityEntitiesFiltered = prioritizeJob(
                classificationTypeEnum, priorityInfoEntity.getValue(), jobPriorityEntitiesActual);

            if (!jobPriorityEntitiesFiltered.isEmpty()) {
              jobPriorityEntitiesActual.removeAll(jobPriorityEntitiesFiltered);
              jobPriorityEntitiesFilteredFinal.addAll(jobPriorityEntitiesFiltered);
            }
          }

        }
        if (!jobPriorityEntitiesActual.isEmpty()) {
          // Remaining Jobs
          jobPriorityEntitiesFilteredFinal.addAll(jobPriorityEntitiesActual);
        }
        // And Lastly Add Low Priorities job
        if (!jobPriorityEntitiesFilteredExplicitLow.isEmpty()) {
          jobPriorityEntitiesFilteredFinal.addAll(jobPriorityEntitiesFilteredExplicitLowSorted);
        }

        LOGGER.debug("Total Records After Priotization Sorting: {}",
            jobPriorityEntitiesFilteredFinal.size());

      } else {
        LOGGER.debug("NO any Prioritization Criteria Found");
        jobPriorityEntitiesFilteredFinal = jobPriorityEntitiesActual;
      }

    } else {
      LOGGER.debug("No Jobs found in Prioritization");
    }

    message = MessageBuilder.withPayload(jobPriorityEntitiesFilteredFinal)
        .copyHeaders(message.getHeaders()).build();
    return message;
  }

  private List<JobPriorityEntity> prioritizeJob(ClassificationTypeEnum classificationTypeEnum,
      String value, List<JobPriorityEntity> jobPriorityEntitiesActual) {

    Predicate<JobPriorityEntity> jobPriorityPredicate = PrioritizationFactory
        .getPredicate(classificationTypeEnum, value);
    List<JobPriorityEntity> jobPriorityEntitiesFiltered = PriorityPredicateFunctions
        .evalPredicate(jobPriorityEntitiesActual, jobPriorityPredicate);
    LOGGER.debug("Sorted Recored: {} for Function: {} of value: {}",
        jobPriorityEntitiesFiltered.size(), classificationTypeEnum, value);

    return jobPriorityEntitiesFiltered;

  }

  private List<JobPriorityEntity> sortByDateDesc(List<JobPriorityEntity> jobPriorityEntities) {
    return jobPriorityEntities.stream()
        .sorted(Comparator.comparing(JobPriorityEntity::getExplicitPrioritizationDate,
            Comparator.nullsLast(Comparator.reverseOrder())))
        .collect(Collectors.toList());
  }

  private List<JobPriorityEntity> sortByDateAsc(List<JobPriorityEntity> jobPriorityEntities) {
    return jobPriorityEntities.stream()
        .sorted(Comparator.comparing(JobPriorityEntity::getExplicitPrioritizationDate,
            Comparator.nullsLast(Comparator.naturalOrder())))
        .collect(Collectors.toList());
  }

}
