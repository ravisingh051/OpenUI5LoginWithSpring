package com.adapt.workorder.messaging;

import com.adapt.config.Constant;
import com.adapt.exception.FileDecryptionException;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobPriorityGetPayload;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.FileUtils;
import org.bouncycastle.openpgp.PGPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("decryptFileForJobPriorityTransformer")
public class DecryptFileForJobPriorityTransformer extends AbstractTransformer {

  @Autowired
  private PgpRsaPublicPrivateKeyGenerator pgpRsaPublicPrivateKeyGenerator;

  private static final Logger LOGGER = LoggerFactory
      .getLogger(DecryptFileForJobPriorityTransformer.class);

  @Override
  protected Object doTransform(Message<?> message) throws Exception {

    LOGGER.debug("Starting Getting File Details for file");
    JobPriorityGetPayload jobPriorityGetPayload = (JobPriorityGetPayload) message.getPayload();
    JobFilePriorityEntity jobFilePriorityEntity = jobPriorityGetPayload.getJobFilePriorityEntity();

    LOGGER.debug("File Decrypting: {}", jobFilePriorityEntity.getFileName());
    String newFileToDecrypt = jobFilePriorityEntity.getFilePath() + File.separator
        + jobFilePriorityEntity.getFileNewName() + Constant.FILE_DECRYPTED;
    File newDecryptedFile = new File(newFileToDecrypt);
    if (!newDecryptedFile.exists()) {
      FileUtils.touch(newDecryptedFile);
    }
    getInboundFile(jobFilePriorityEntity.getFileStatePrivatekey(),
        jobFilePriorityEntity.getMasterPrivateKey(), jobFilePriorityEntity.getFilePath(),
        jobFilePriorityEntity.getFileNewName(), newDecryptedFile);

    if (newDecryptedFile.length() > 0) {

      LOGGER.debug("File Decrypted...");
      return newDecryptedFile;

    } else {
      LOGGER.error("Error While Decrypting File: {}", jobFilePriorityEntity.getFileName());
      throw new FileDecryptionException(
          "Error While Decrypting File: " + jobFilePriorityEntity.getFileName());

    }

  }

  private void getInboundFile(byte[] fileStateEncryptedKey, String masterPrivateKey,
      String filePath, String fileNewName, File newFileToDecryptedFile)
      throws IOException, PGPException {

    String encryptedFileName = filePath + File.separator + fileNewName;

    if (null != fileStateEncryptedKey) {
      byte[] decryptedPrivateKey = getDecryptedPrivateKey(fileStateEncryptedKey, masterPrivateKey);

      InputStream privateKeyStream = new ByteArrayInputStream(decryptedPrivateKey);
      try (FileInputStream encFileStream = new FileInputStream(encryptedFileName);
          FileOutputStream fileOutputStream = new FileOutputStream(newFileToDecryptedFile)) {
        pgpRsaPublicPrivateKeyGenerator.decryptFile(encFileStream, fileOutputStream,
            privateKeyStream);

      }
    } else {
      // throw an error
      LOGGER.error("NO ENCRYPTED KEY FOUND FOR FILE: {}", fileNewName);

    }
  }

  private byte[] getDecryptedPrivateKey(byte[] encryptedPrivateKey, String masterPrivateKey)
      throws IOException, PGPException {

    InputStream encPrivateKeyStream = new ByteArrayInputStream(encryptedPrivateKey);
    InputStream masterPrivateKeyStream = new ByteArrayInputStream(
        masterPrivateKey.getBytes(StandardCharsets.UTF_8));
    ByteArrayOutputStream decOutputStream = new ByteArrayOutputStream();

    pgpRsaPublicPrivateKeyGenerator.decryptFile(encPrivateKeyStream, decOutputStream,
        masterPrivateKeyStream);

    byte[] decArray = decOutputStream.toByteArray();
    decOutputStream.close();
    masterPrivateKeyStream.close();
    return decArray;
  }

}
