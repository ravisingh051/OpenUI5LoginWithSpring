package com.adapt.workorder.service;

import com.adapt.file.entity.JobPriorityEntity;
import java.sql.Date;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PriorityPredicateFunctions {

  private static final String PREDICATE_YES = "YES";
  private static final String SLA_NOT_MAPPED = "NO";

  private PriorityPredicateFunctions() {
  }

  public static Predicate<JobPriorityEntity> predicateExplicitHighPrioritization(
      Object explicitHighValue) {
    return p -> (Boolean.TRUE.equals(p.getExplicitHighPrioritization()));
  }

  public static Predicate<JobPriorityEntity> predicateExplicitLowPrioritization(
      Object explicitLowValue) {
    return p -> (Boolean.TRUE.equals(p.getExplicitLowPrioritization()));
  }

  public static Predicate<JobPriorityEntity> predicateSla(Object slaValue) {
    return p -> (p.getIsSlaMapped() ? PREDICATE_YES : SLA_NOT_MAPPED)
        .equalsIgnoreCase(String.valueOf(slaValue));
  }

  public static Predicate<JobPriorityEntity> predicateFileId(Object fileId) {
    return p -> p.getFileId().equals(Integer.valueOf(fileId.toString()));
  }

  public static Predicate<JobPriorityEntity> predicateEmployer(Object employer) {

    return p -> (Arrays.asList(p.getEmployerIds().split(","))).contains(employer);
  }

  public static Predicate<JobPriorityEntity> predicateTradingPartner(Object tradingPartner) {
    return p -> p.getTradingPartnerId().equals(Integer.valueOf(tradingPartner.toString()));
  }

  public static Predicate<JobPriorityEntity> predicateFileType(Object fileType) {
    return p -> p.getFileTypeId().equals(Integer.valueOf(fileType.toString()));
  }

  public static Predicate<JobPriorityEntity> predicateFileDirection(Object fileDirection) {
    return p -> p.getDirection().equalsIgnoreCase(String.valueOf(fileDirection));
  }

  /**
   * Predicate previous day.
   *
   * @param previousDay
   *          the previous day
   * @return the predicate
   */
  public static Predicate<JobPriorityEntity> predicatePreviousDay(Object previousDay) {
    if (previousDay.toString().equalsIgnoreCase(PREDICATE_YES)) {
      final Calendar cal = Calendar.getInstance();
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      cal.set(Calendar.MILLISECOND, 0);
      return p -> p.getExpectedStartDate().compareTo(new Date(cal.getTime().getTime())) < 0;
    } else {
      // All Including Today's Jobs
      return p -> true;

    }
  }

  /**
   * Eval predicate.
   *
   * @param jobPriorityList
   *          the job priority list
   * @param predicate
   *          the predicate
   * @return the list
   */
  public static List<JobPriorityEntity> evalPredicate(List<JobPriorityEntity> jobPriorityList,
      Predicate<JobPriorityEntity> predicate) {

    return jobPriorityList.stream().filter(predicate).collect(Collectors.toList());
  }

}
