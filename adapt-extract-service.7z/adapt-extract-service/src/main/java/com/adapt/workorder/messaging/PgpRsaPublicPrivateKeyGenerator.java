package com.adapt.workorder.messaging;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;
import org.apache.commons.io.IOUtils;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.bcpg.sig.Features;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.crypto.generators.RSAKeyPairGenerator;
import org.bouncycastle.crypto.params.RSAKeyGenerationParameters;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.KeyFingerPrintCalculator;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.PBESecretKeyEncryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculator;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPGPKeyPair;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.util.Arrays;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PgpRsaPublicPrivateKeyGenerator {

  @Value("${passcode}")
  private String passcode;

  private static final KeyFingerPrintCalculator KEY_FINGER_PRINT_CALCULATOR = new JcaKeyFingerprintCalculator();

  /**
   * generatePublicPrivateKey Method.
   * 
   * @param publicKeyStream
   *          OutputStream
   * @param privateKeyStream
   *          OutputStream
   * @throws PGPException
   *           Exception
   * @throws IOException
   *           Exception
   */
  public void generatePublicPrivateKey(OutputStream publicKeyStream, OutputStream privateKeyStream)
      throws PGPException, IOException {
    Security.addProvider(new BouncyCastleProvider());
    RSAKeyPairGenerator rsaKeyPairGenerator = new RSAKeyPairGenerator();

    rsaKeyPairGenerator.init(
        new RSAKeyGenerationParameters(BigInteger.valueOf(0x10001), new SecureRandom(), 2048, 12));

    PGPSignatureSubpacketGenerator signhashgen = new PGPSignatureSubpacketGenerator();
    signhashgen.setKeyFlags(false, KeyFlags.SIGN_DATA | KeyFlags.CERTIFY_OTHER);

    signhashgen.setPreferredSymmetricAlgorithms(false,
        new int[] { SymmetricKeyAlgorithmTags.AES_256 });

    signhashgen.setPreferredHashAlgorithms(false, new int[] { HashAlgorithmTags.SHA384 });
    signhashgen.setFeature(false, Features.FEATURE_MODIFICATION_DETECTION);
    PGPSignatureSubpacketGenerator enchashgen = new PGPSignatureSubpacketGenerator();
    enchashgen.setKeyFlags(false, KeyFlags.ENCRYPT_COMMS | KeyFlags.ENCRYPT_STORAGE);
    PGPDigestCalculator sha1Calc = new BcPGPDigestCalculatorProvider().get(HashAlgorithmTags.SHA1);

    PGPDigestCalculator sha384Calc = new BcPGPDigestCalculatorProvider()
        .get(HashAlgorithmTags.SHA384);

    PBESecretKeyEncryptor pske = (new BcPBESecretKeyEncryptorBuilder(PGPEncryptedData.AES_256,
        sha384Calc, 12)).build(passcode.toCharArray());

    PGPKeyPair rsaSign = new BcPGPKeyPair(PGPPublicKey.RSA_SIGN,
        rsaKeyPairGenerator.generateKeyPair(), new Date());
    PGPKeyRingGenerator keyRingGen = new PGPKeyRingGenerator(PGPSignature.POSITIVE_CERTIFICATION,
        rsaSign, PKCSObjectIdentifiers.sha384WithRSAEncryption.getId(), sha1Calc,
        signhashgen.generate(), null, new BcPGPContentSignerBuilder(
            rsaSign.getPublicKey().getAlgorithm(), HashAlgorithmTags.SHA384),
        pske);

    PGPKeyPair rsaEnc = new BcPGPKeyPair(PGPPublicKey.RSA_ENCRYPT,
        rsaKeyPairGenerator.generateKeyPair(), new Date());
    keyRingGen.addSubKey(rsaEnc, enchashgen.generate(), null);
    PGPPublicKeyRing publicKey = keyRingGen.generatePublicKeyRing();
    OutputStream publicKeyOutStream = new ArmoredOutputStream(publicKeyStream);
    publicKey.encode(publicKeyOutStream);
    publicKeyOutStream.close();
    publicKeyStream.close();

    PGPSecretKeyRing secretKey = keyRingGen.generateSecretKeyRing();
    OutputStream secretKeyOutstream = new ArmoredOutputStream(privateKeyStream);
    secretKey.encode(secretKeyOutstream);
    secretKeyOutstream.close();
    privateKeyStream.close();

  }

  /**
   * readPublicKey method.
   * 
   * @param in
   *          InputStream
   * @return
   */
  public PGPPublicKey readPublicKey(InputStream in) throws IOException, PGPException {
    PGPPublicKeyRingCollection keyRingCollection = new PGPPublicKeyRingCollection(
        PGPUtil.getDecoderStream(in), KEY_FINGER_PRINT_CALCULATOR);

    PGPPublicKey publicKey = null;

    // iterate through the key rings.
    Iterator<PGPPublicKeyRing> rIt = keyRingCollection.getKeyRings();

    while (publicKey == null && rIt.hasNext()) {
      PGPPublicKeyRing kRing = rIt.next();
      Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
      while (publicKey == null && kIt.hasNext()) {
        PGPPublicKey key = kIt.next();
        if (key.isEncryptionKey()) {
          publicKey = key;
        }
      }
    }

    if (publicKey == null) {
      throw new IllegalArgumentException("Can't find public key in the key ring.");
    }
    return publicKey;
  }

  /**
   * encryptStream method.
   * 
   * @param out
   *          OutputStream
   */
  public void encryptStream(OutputStream out, byte[] in, PGPPublicKey encKey, boolean armor,
      boolean withIntegrityCheck) throws IOException, PGPException {
    Security.addProvider(new BouncyCastleProvider());

    if (armor) {
      out = new ArmoredOutputStream(out);
    }

    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZIP);
    ByteArrayInputStream byteIs = new ByteArrayInputStream(in);
    Date d = new Date();
    writeDataToStream(byteIs, comData.open(byteArrayOutputStream), String.valueOf(d.getTime()),
        in.length, d);
    byteIs.close();
    comData.close();

    BcPGPDataEncryptorBuilder dataEncryptor = new BcPGPDataEncryptorBuilder(
        PGPEncryptedData.TRIPLE_DES);

    dataEncryptor.setWithIntegrityPacket(withIntegrityCheck);
    dataEncryptor.setSecureRandom(new SecureRandom());
    PGPEncryptedDataGenerator encryptedDataGenerator = new PGPEncryptedDataGenerator(dataEncryptor);
    encryptedDataGenerator.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));

    byte[] bytes = byteArrayOutputStream.toByteArray();
    try (OutputStream outputStream = encryptedDataGenerator.open(out, bytes.length)) {
      outputStream.write(bytes);
    }
    out.close();
  }

  /**
   * decryptFile method.
   * 
   * @param in
   *          InputStream
   * @param out
   *          OutputStream
   */
  public void decryptFile(InputStream in, OutputStream out, InputStream keyIn)
      throws IOException, PGPException {
    Security.addProvider(new BouncyCastleProvider());
    in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);
    PGPObjectFactory pgpF = new PGPObjectFactory(in, KEY_FINGER_PRINT_CALCULATOR);
    PGPEncryptedDataList enc;
    Object o = pgpF.nextObject();

    // the first object might be a PGP marker packet.
    if (o instanceof PGPEncryptedDataList) {
      enc = (PGPEncryptedDataList) o;
    } else {
      enc = (PGPEncryptedDataList) pgpF.nextObject();
    }

    // find the secret key
    @SuppressWarnings("unchecked")
    Iterator<PGPPublicKeyEncryptedData> it = enc.getEncryptedDataObjects();
    PGPPrivateKey sKey = null;
    PGPPublicKeyEncryptedData pbe = null;

    while (sKey == null && it.hasNext()) {
      pbe = it.next();
      sKey = findPrivateKey(keyIn, pbe.getKeyID(), passcode.toCharArray());
    }

    if (sKey == null) {
      throw new IllegalArgumentException("Secret key for message not found.");
    }

    InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
    PGPObjectFactory plainFact = new PGPObjectFactory(clear, KEY_FINGER_PRINT_CALCULATOR);
    Object message = plainFact.nextObject();

    if (message instanceof PGPCompressedData) {
      PGPCompressedData cData = (PGPCompressedData) message;
      PGPObjectFactory pgpFact = new PGPObjectFactory(cData.getDataStream(),
          KEY_FINGER_PRINT_CALCULATOR);
      message = pgpFact.nextObject();
    }

    if (message instanceof PGPLiteralData) {
      PGPLiteralData ld = (PGPLiteralData) message;
      InputStream unc = ld.getInputStream();
      try {
        IOUtils.copy(unc, out);
      } finally {
        unc.close();
      }

    } else if (message instanceof PGPOnePassSignatureList) {
      throw new PGPException("Encrypted message contains a signed message - not literal data.");
    } else {
      throw new PGPException("Message is not a simple encrypted file - type unknown.");
    }

    if (pbe.isIntegrityProtected() && !pbe.verify()) {
      throw new PGPException("Message failed integrity check");
    }
  }

  private PGPPrivateKey findPrivateKey(InputStream keyIn, long keyID, char[] pass)
      throws IOException, PGPException {
    PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(
        PGPUtil.getDecoderStream(keyIn), KEY_FINGER_PRINT_CALCULATOR);
    return findPrivateKey(pgpSec.getSecretKey(keyID), pass);
  }

  private PGPPrivateKey findPrivateKey(PGPSecretKey pgpSecKey, char[] pass) throws PGPException {
    if (pgpSecKey == null) {
      return null;
    }
    PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(
        new BcPGPDigestCalculatorProvider()).build(pass);
    return pgpSecKey.extractPrivateKey(decryptor);
  }

  private void writeDataToStream(ByteArrayInputStream in, OutputStream pOut, String name,
      int length, Date modificationTime) throws IOException {
    PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();
    OutputStream out = lData.open(pOut, PGPLiteralData.BINARY, name, length, modificationTime);
    pipeFileContents(in, out, new byte[32768]);
  }

  private void pipeFileContents(ByteArrayInputStream in, OutputStream pOut, byte[] buf)
      throws IOException {
    try {
      int len;
      while ((len = in.read(buf)) > 0) {
        pOut.write(buf, 0, len);
      }
      pOut.close();
    } finally {
      Arrays.fill(buf, (byte) 0);
      try {
        in.close();
      } catch (IOException ignored) {
        // ignore...
      }
    }
  }
}
