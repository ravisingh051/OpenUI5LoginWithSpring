package com.adapt.workorder.messaging;

import java.util.Collections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.handler.advice.AbstractRequestHandlerAdvice;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("requestHandlerAdviceForEmptyResult")
public class RequestHandlerAdviceForEmptyResult extends AbstractRequestHandlerAdvice {
  private static final Logger LOG = LoggerFactory
      .getLogger(RequestHandlerAdviceForEmptyResult.class);

  @Override
  protected Object doInvoke(ExecutionCallback callback, Object target, Message<?> message)
      throws Exception {
    Object result = callback.execute();

    if (result == null) {
      LOG.debug("no result found");
      result = Collections.emptyList();
    }
    return result;
  }

}
