package com.adapt.workorder.messaging;

import com.adapt.config.Constant;
import com.adapt.exception.JobModelConvesionException;
import com.adapt.exception.SecondaryDataException;
import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.entity.JobModel;
import com.adapt.file.entity.JobPriorityGetPayload;
import com.adapt.file.entity.SecondaryDataInfo;
import com.adapt.file.service.JobService;
import com.adapt.file.service.SecondaryDataService;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.DefaultMessageBuilderFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.support.json.JsonObjectMapper;
import org.springframework.integration.support.json.JsonObjectMapperProvider;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("jobHeaderSetFromPriorityJobServiceActivator")
public class JobHeaderSetFromPriorityJobServiceActivator {

  @Autowired
  private JobService jobService;

  @Autowired
  private SecondaryDataService secondaryDataService;

  private final JsonObjectMapper<?, ?> jsonObjectMapper;

  public JobHeaderSetFromPriorityJobServiceActivator() {
    super();
    this.jsonObjectMapper = JsonObjectMapperProvider.newInstance();
  }

  private static final Logger LOGGER = LoggerFactory
      .getLogger(JobHeaderSetFromPriorityJobServiceActivator.class);

  /**
   * Gets the file from job priority detail.
   *
   * @param message
   *          the message
   * @return the file from job priority detail
   * @throws Exception
   *           the exception
   */
  public Message<JobPriorityGetPayload>
      getFileFromJobPriorityDetail(Message<JobPriorityGetPayload> message) throws Exception {

    LOGGER.debug("Starting Getting Job Details for file");
    JobPriorityGetPayload jobPriorityGetPayload = message.getPayload();
    JobFilePriorityEntity jobFilePriorityEntity = jobPriorityGetPayload.getJobFilePriorityEntity();

    MessageBuilder<JobPriorityGetPayload> builder = new DefaultMessageBuilderFactory()
        .fromMessage(message);
    builder.copyHeaders(message.getHeaders());

    JobModel job = jobService.jobFilePriorityEntityToJobModel(jobFilePriorityEntity);

    if (job == null) {
      builder.setHeader(Constant.EXPECTED_HEADER, "false");
      // if job is not found dont send this message further
      LOGGER.error("Error Converting JobFilePriorityEntity to JobModel for job {} and file {}",
          jobFilePriorityEntity.getJobId(), jobFilePriorityEntity.getFileName());
      // NEEDS To CALL JOB_FAILED
      throw new JobModelConvesionException("Error Converting JobFilePriorityEntity to JobModel");

    }

    builder.setHeader(Constant.EXPECTED_HEADER, "true");
    builder.setPriority(job.getPriority());
    builder.setHeader(Constant.JOB_MODEL_HEADER, job);
    builder.setHeader(Constant.FILE_ID, job.getFileModel().getFileId());
    builder.setHeader(Constant.FILE_VERSION, job.getFileModel().getFileVersion());
    builder.setHeader(Constant.ORIGINAL_FILE_NAME_HEADER,
        job.getFileModel().getFileTransmissionName());
    builder.setHeader(Constant.FORMAT_HEADER,
        job.getFileModel().getMessageFormat().getMessageFormatType().getValue());
    builder.setHeader(Constant.FILE_TYPE_HEADER, job.getFileModel().getFileType().getValue());
    builder.setHeader(Constant.MASTER_FILE_TEMPLATE_ID_HEADER,
        job.getFileModel().getMasterFileTemplateId());
    builder.setHeader(Constant.MASTER_FILE_TEMPLATE_VERSION_HEADER,
        job.getFileModel().getMasterFileTemplateVersion());
    builder.setHeader(Constant.RESULTS_MODE_HEADER, job.getFileModel().getResultsMode());
    builder.setHeader(Constant.FULL_OR_CHANGE_FILE_HEADER, job.getFullOrChange());
    builder.setHeader(Constant.IS_HEADER_EXIST_HEADER, job.headerConfigured());
    builder.setHeader(Constant.IS_TRAILER_EXIST_HEADER, job.trailerConfigured());

    builder.setHeader(Constant.FILE_MIN_RECORD_COUNT_ALLOWED,
        job.getFileModel().getFileMinRecordCountAllowed());
    builder.setHeader(Constant.FILE_MAX_RECORD_COUNT_ALLOWED,
        job.getFileModel().getFileMaxRecordCountAllowed());

    builder.setHeader(Constant.EMPLOYER_ID_HEADER, job.getEmployerId());
    builder.setHeader(Constant.CLIENT_ID_HEADER, job.getClientId());
    builder.setHeader(Constant.TEST_CFG_HEADER, job.getTestCfgConfig());

    builder.setHeader(Constant.FILE_PROCESSING_ERROR_THRESHOLD_FORMAT_HEADER,
        job.getFileModel().getFileProcessingErrorThresholdFormat().name());
    builder.setHeader(Constant.ERROR_THRESHOLD_HEADER, job.getFileModel().getErrorThreshold());

    List<SecondaryDataInfo> secondaryDataInfo = secondaryDataService
        .getSecondaryDataInfo(job.getFileModel().getFileIdentifier());
    try {
      builder.setHeader(Constant.SECONDARY_DATA_INFO_HEADER,
          jsonObjectMapper.toJson(secondaryDataInfo));
    } catch (Exception e) {
      throw new SecondaryDataException("not able to retrieve secondary Data api information", e);
    }
    return builder.build();

  }

}
