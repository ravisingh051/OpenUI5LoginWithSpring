package com.adapt.workorder.config;

import java.io.Serializable;

public enum ClassificationTypeEnum implements Serializable {
  SLA("SLA"), FILE_ID("File ID"), EMPLOYER("Employer"), TRADING_PARTNER(
      "Trading Partner"), FILE_TYPE("File Type"), FILE_DIRECTION("File Direction"), PREVIOUS_DAY(
          "Previous Day's Unfinished Jobs"), EXPLICIT_HIGH_PRIORITIZATION(
              "Explicit High Prioritization"), EXPLICIT_LOW_PRIORITIZATION(
                  "Explicit Low Prioritization");
  String dbValue;

  private ClassificationTypeEnum(String dbValue) {

    this.dbValue = dbValue;
  }

  /**
   * getEnumFromValue method.
   * 
   * @return ClassificationTypeEnum
   */
  public static ClassificationTypeEnum getEnumFromValue(String dbValue) {
    for (ClassificationTypeEnum classificationTypeEnum : ClassificationTypeEnum.values()) {
      if (classificationTypeEnum.dbValue.equals(dbValue)) {
        return classificationTypeEnum;
      }
    }
    return null;
  }
}
