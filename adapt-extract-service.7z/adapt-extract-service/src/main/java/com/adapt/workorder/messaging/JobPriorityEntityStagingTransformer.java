package com.adapt.workorder.messaging;

import com.adapt.config.Constant;
import com.adapt.file.entity.JobDetailsPrioritizationStagingEntity;
import com.adapt.file.entity.JobPriorityEntity;
import com.alight.idis.jobs.JobStatus;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component("JobPriorityEntityStagingTransformer")
public class JobPriorityEntityStagingTransformer extends AbstractTransformer {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(JobPriorityEntityStagingTransformer.class);

  @Override
  protected Object doTransform(Message<?> message) throws Exception {
    LOGGER.debug("Start Converting JobPriorityEntity  to JobDetailsPrioritizationStagingEntity");
    List<JobDetailsPrioritizationStagingEntity> jobDetailsPrioritizationStagingList = new ArrayList<>();
    List<JobPriorityEntity> jobPriorityEntityList = (List<JobPriorityEntity>) message.getPayload();
    if (jobPriorityEntityList != null && !jobPriorityEntityList.isEmpty()) {

      String createdBy = null;
      if (message.getHeaders().get(Constant.SOURCE_INSTANCE_HEADER) != null) {
        MessageHeaders headers = message.getHeaders();
        Assert.notNull(headers, "headers should not be null");
        createdBy = headers.get(Constant.SOURCE_INSTANCE_HEADER, String.class);
      }
      for (int i = 0; i < jobPriorityEntityList.size(); i++) {
        JobDetailsPrioritizationStagingEntity jobDetailsPrioritizationStaging = new JobDetailsPrioritizationStagingEntity();
        JobPriorityEntity jobPriorityEntity = jobPriorityEntityList.get(i);
        jobDetailsPrioritizationStaging.setIsActive(true);
        jobDetailsPrioritizationStaging.setJobId(jobPriorityEntity.getJobId());
        jobDetailsPrioritizationStaging.setJobPriority(i + 1);

        jobDetailsPrioritizationStaging.setCreatedBy(createdBy);
        jobDetailsPrioritizationStaging.setJobStatus(JobStatus.READY.getValue());

        jobDetailsPrioritizationStaging
            .setCreatedDateTime(new Date(Calendar.getInstance().getTimeInMillis()));

        jobDetailsPrioritizationStagingList.add(jobDetailsPrioritizationStaging);

      }
      LOGGER.debug("outside Transformer after JobDetailsPrioritizationStagingEntity Conversion: {}",
          jobDetailsPrioritizationStagingList.size());

    } else {
      LOGGER.debug("No jobs Found for Prioritization");
    }

    return jobDetailsPrioritizationStagingList;
  }

}
