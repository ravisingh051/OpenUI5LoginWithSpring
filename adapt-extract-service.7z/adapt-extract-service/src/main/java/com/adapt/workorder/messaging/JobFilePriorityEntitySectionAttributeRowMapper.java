package com.adapt.workorder.messaging;

import com.adapt.file.entity.SectionAttributeEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.BiConsumer;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("jobFilePriorityEntitySectionAttributeRowMapper")
public class JobFilePriorityEntitySectionAttributeRowMapper
    implements RowMapper<SectionAttributeEntity> {

  private static final String ATTRIBUTE_NAME = "standardizedName";
  private static final String DEFAULT_DATATYPE = "defaultDatatype";
  private static final String COLUMN_ORDER = "columnOrder";
  private static final String SECTION_TYPE = "sectionType";
  private static final String SECTION_DELIMITER = "nodeDelimiter";
  private static final String IS_ATTRIBUTE_MANDATORY = "mandatory";
  private static final String ATTRIBUTE_SIZE = "nodeSize";
  private static final String ATTRIBUTE_START_POSITION = "nodeColumnStartPosition";
  private static final String ATTRIBUTE_END_POSITION = "nodeColumnEndPosition";

  @Override
  public SectionAttributeEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
    SectionAttributeEntity sectionAttributeEntity = new SectionAttributeEntity();

    sectionAttributeEntity.setStandardizedName(rs.getString(ATTRIBUTE_NAME));
    sectionAttributeEntity.setAttributeDataType(rs.getString(DEFAULT_DATATYPE));
    setIntegerData(sectionAttributeEntity, rs, COLUMN_ORDER, SectionAttributeEntity::setOrder);
    sectionAttributeEntity.setSectionType(rs.getString(SECTION_TYPE));
    sectionAttributeEntity.setSectionDelimiter(rs.getString(SECTION_DELIMITER));
    sectionAttributeEntity.setIsAttributeMandatory(rs.getBoolean(IS_ATTRIBUTE_MANDATORY));
    setIntegerData(sectionAttributeEntity, rs, ATTRIBUTE_SIZE,
        SectionAttributeEntity::setAttributeSize);
    setIntegerData(sectionAttributeEntity, rs, ATTRIBUTE_START_POSITION,
        SectionAttributeEntity::setAttributeStartPosition);
    setIntegerData(sectionAttributeEntity, rs, ATTRIBUTE_END_POSITION,
        SectionAttributeEntity::setAttributeEndPosition);
    return sectionAttributeEntity;
  }

  private void setIntegerData(SectionAttributeEntity sectionAttributeEntity, ResultSet rs,
      String columnName, BiConsumer<SectionAttributeEntity, Integer> biConsumer)
      throws SQLException {
    Object object = rs.getObject(columnName);
    if (object != null) {
      biConsumer.accept(sectionAttributeEntity, rs.getInt(columnName));
    } else {
      biConsumer.accept(sectionAttributeEntity, null);
    }
  }

}
