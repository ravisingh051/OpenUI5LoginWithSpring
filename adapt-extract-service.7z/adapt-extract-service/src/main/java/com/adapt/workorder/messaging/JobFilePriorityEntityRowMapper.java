package com.adapt.workorder.messaging;

import com.adapt.file.entity.JobFilePriorityEntity;
import com.adapt.file.service.JobServiceImpl;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("jobFilePriorityEntityRowMapper")
public class JobFilePriorityEntityRowMapper implements RowMapper<JobFilePriorityEntity> {

  private static final Logger LOGGER = LoggerFactory.getLogger(JobServiceImpl.class);

  private static final String EXTRACTION_EMPLOYER_IDS = "extractionEmployerIds";
  private static final String PLAN_SUBTYPES = "PlanSubtypes";
  private static final String PLAN_YEAR = "planYear";
  private static final String JOB_ID = "jobId";
  private static final String JOB_EXPECTED_STARTDATETIME = "jobExpectedStartDateTime";
  private static final String FILE_PROCESSING_ERROR_THRESHOLD_COUNT = "fileProcessingErrorThresholdCount";
  private static final String FILE_MIN_RECORD_COUNT_ALLOWED = "fileMinRecordCountAllowed";
  private static final String FILE_TRANSMISSION_NAME = "fileTransmissionName";
  private static final String FILE_TYPE_NAME = "fileTypeName";
  private static final String FILE_FORMAT_NAME = "fileFormatName";
  private static final String FILE_FORMAT_ROW_DELIMITER = "fileFormatRowDelimiter";
  private static final String FILE_FORMAT_FIELD_DDELIMITER = "fileFormatFieldDdelimiter";
  private static final String FILE_FORMAT_ESCAPE_CHAR = "fileFormatEscapeChar";
  private static final String FILE_FORMAT_SEGMENT_DELIMITER = "fileFormatSegmentDelimiter";
  private static final String PRIORITY = "priority";
  private static final String EMPLOYER_CLIENTID_TESTCFGS = "employerClientIdTestCfgs";
  private static final String MASTER_FILE_TEMPLATE_ID = "masterFileTemplateId";
  private static final String MASTER_FILE_TEMPLATE_VERSION = "masterFileTemplateVersion";
  private static final String FULL_OR_CHANGE = "fullOrChange";
  private static final String RESULTS_MODE = "resultsMode";
  private static final String FILE_MAX_RECORD_COUNT_ALLOWED = "fileMaxRecordCountAllowed";
  private static final String FILE_PROCESSING_ERROR_THRESHOLD_FORMAT = "fileProcessingErrorThresholdFormat";
  private static final String FILE_IDENTIFIER = "fileIdentifier";
  private static final String FILE_ID = "fileId";
  private static final String FILE_VERSION = "fileVersion";
  private static final String CLONE_NUMBER_LIST = "cloneNumberList";

  private static final String FILE_STATE_ID = "fileStateId";
  private static final String FILE_PATH = "filePath";
  private static final String FILE_NAME = "fileName";
  private static final String FILE_STATE_PRIVATEKEY = "fileStatePrivatekey";
  private static final String MASTER_PRIVATE_KEY = "masterPrivateKey";
  private static final String NEW_FILE_NAME = "newFileName";
  private static final String DIRECTION = "direction";
  private static final String DATA_SOURCE_TYPE = "data_source_type";
  private static final String DATA_TARGET_TYPE = "data_target_type";
  private static final String PLAN_ADDITION_FACTOR = "planAdditionFactor";
  private static final String SYSTEM_DATE = "systemDate";
  private static final String LOOK_BACK_PERIOD = "lookBackPeriod";
  private static final String LOOK_AHEAD_PERIOD = "lookAheadPeriod";
  private static final String PROFILE_ID = "profileId";

  @Override
  public JobFilePriorityEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
    try {
      JobFilePriorityEntity jobFilePriorityEntity = new JobFilePriorityEntity();
      jobFilePriorityEntity.setJobId(rs.getInt(JOB_ID));
      jobFilePriorityEntity.setExpectedDate(rs.getDate(JOB_EXPECTED_STARTDATETIME));
      jobFilePriorityEntity.setErrorThreshHold(rs.getInt(FILE_PROCESSING_ERROR_THRESHOLD_COUNT));
      jobFilePriorityEntity.setFileMinRecordCountAllowed(rs.getInt(FILE_MIN_RECORD_COUNT_ALLOWED));
      jobFilePriorityEntity.setFileTransmissionName(rs.getString(FILE_TRANSMISSION_NAME));
      jobFilePriorityEntity.setFileType(rs.getString(FILE_TYPE_NAME));
      jobFilePriorityEntity.setFileFormatName(rs.getString(FILE_FORMAT_NAME));
      jobFilePriorityEntity.setRowDelimiter(rs.getString(FILE_FORMAT_ROW_DELIMITER));
      jobFilePriorityEntity.setFieldDelimiter(rs.getString(FILE_FORMAT_FIELD_DDELIMITER));
      jobFilePriorityEntity.setEscapeCharacter(rs.getString(FILE_FORMAT_ESCAPE_CHAR));
      jobFilePriorityEntity.setSegmentDelimiter(rs.getString(FILE_FORMAT_SEGMENT_DELIMITER));
      jobFilePriorityEntity.setPriority(rs.getInt(PRIORITY));
      jobFilePriorityEntity
          .setEmployerIdAndClientIdAndTestCfgs(rs.getString(EMPLOYER_CLIENTID_TESTCFGS));
      jobFilePriorityEntity.setMasterFileTemplateId(rs.getInt(MASTER_FILE_TEMPLATE_ID));
      jobFilePriorityEntity.setMasterFileTemplateVersion(rs.getInt(MASTER_FILE_TEMPLATE_VERSION));
      jobFilePriorityEntity.setFullOrChange(rs.getInt(FULL_OR_CHANGE));
      jobFilePriorityEntity.setResultsMode(rs.getInt(RESULTS_MODE));
      jobFilePriorityEntity.setFileMaxRecordCountAllowed(rs.getInt(FILE_MAX_RECORD_COUNT_ALLOWED));
      jobFilePriorityEntity.setFileProcessingErrorThresholdFormat(
          rs.getString(FILE_PROCESSING_ERROR_THRESHOLD_FORMAT));
      jobFilePriorityEntity.setFileIdentifier(rs.getInt(FILE_IDENTIFIER));
      jobFilePriorityEntity.setFileId(rs.getInt(FILE_ID));
      jobFilePriorityEntity.setFileVersion(rs.getInt(FILE_VERSION));
      jobFilePriorityEntity.setCloneNumberList(rs.getString(CLONE_NUMBER_LIST));

      jobFilePriorityEntity.setFileStateId(rs.getInt(FILE_STATE_ID));
      jobFilePriorityEntity.setFilePath(rs.getString(FILE_PATH));
      jobFilePriorityEntity.setFileName(rs.getString(FILE_NAME));
      jobFilePriorityEntity.setFileStatePrivatekey(rs.getBytes(FILE_STATE_PRIVATEKEY));
      jobFilePriorityEntity.setMasterPrivateKey(rs.getString(MASTER_PRIVATE_KEY));
      jobFilePriorityEntity.setFileNewName(rs.getString(NEW_FILE_NAME));
      jobFilePriorityEntity.setDirection(rs.getString(DIRECTION));
      jobFilePriorityEntity.setPlanSubtypes(rs.getString(PLAN_SUBTYPES));
      jobFilePriorityEntity.setPlanYear(rs.getInt(PLAN_YEAR));
      jobFilePriorityEntity.setExtractionEmployerIds(rs.getString(EXTRACTION_EMPLOYER_IDS));
      jobFilePriorityEntity.setDataSourceType(rs.getString(DATA_SOURCE_TYPE));
      jobFilePriorityEntity.setDataTargetType(rs.getString(DATA_TARGET_TYPE));

      jobFilePriorityEntity.setPlanYearAdditiveFactor(rs.getString(PLAN_ADDITION_FACTOR));
      jobFilePriorityEntity.setSystemDate(rs.getString(SYSTEM_DATE));
      jobFilePriorityEntity.setLookBackPeriod(rs.getString(LOOK_BACK_PERIOD));
      jobFilePriorityEntity.setLookAheadPeriod(rs.getString(LOOK_AHEAD_PERIOD));
      jobFilePriorityEntity.setProfileId(rs.getInt(PROFILE_ID));

      return jobFilePriorityEntity;
    } catch (SQLException sqlException) {
      LOGGER.error("exception while formating job: ", sqlException);
      throw sqlException;
    }
  }

}
