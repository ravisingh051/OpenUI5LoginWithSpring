package com.adapt.repository;

import com.adapt.file.entity.ColumnIndex;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

public abstract class StoreProcedureRepository<T> {

  private StoredProcedureQuery storedProcedureQuery;
  Class<T> clazz;

  /**
   * StoreProcedureRepository Method.
   * 
   * @param entityManager
   *          spName
   */
  @SuppressWarnings("unchecked")
  public StoreProcedureRepository(EntityManager entityManager, String spName) {
    storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
    clazz = (Class<T>) ((ParameterizedType) this.getClass().getGenericSuperclass())
        .getActualTypeArguments()[0];
  }

  /**
   * Execute store procedure.
   *
   * @return the list
   */
  public List<T> execute() {
    configureStoreProcedure();
    @SuppressWarnings("unchecked")
    List<Object[]> resultList = storedProcedureQuery.getResultList();
    List<T> entityList = Collections.emptyList();
    if (resultList != null && !resultList.isEmpty()) {
      entityList = resultList.stream().map(objects -> transformToEntity(objects))
          .collect(Collectors.toList());
    }
    return entityList;
  }

  public void registerStoredProcedureParameter(String parameterName, Class<?> type,
      ParameterMode mode, Object value) {
    getStoredProcedureQuery().registerStoredProcedureParameter(parameterName, type, mode);
    getStoredProcedureQuery().setParameter(parameterName, value);
  }

  public StoredProcedureQuery getStoredProcedureQuery() {
    return storedProcedureQuery;
  }

  public abstract void configureStoreProcedure();

  /**
   * Transform to entity.
   *
   * @param objects
   *          the objects
   * @return the t
   */
  public T transformToEntity(Object[] objects) {
    Field[] fields = clazz.getDeclaredFields();
    T bean = null;
    try {
      bean = clazz.newInstance();
    } catch (InstantiationException | IllegalAccessException e) {
      throw new RuntimeException(
          String.format("Unable To Create Instance of class : %s", clazz.getName()), e);
    }
    for (Field field : fields) {
      if (field.isAnnotationPresent(ColumnIndex.class)) {
        ColumnIndex columnIndex = field.getAnnotation(ColumnIndex.class);
        Object value = objects[columnIndex.value()];
        field.setAccessible(true);
        try {
          field.set(bean, value);
        } catch (IllegalArgumentException | IllegalAccessException e) {
          throw new RuntimeException(
              String.format("Unable To Set Value of Field: %s for Class : %s", field.getName(),
                  clazz.getName()),
              e);
        }
      }
    }
    return bean;
  }

}
