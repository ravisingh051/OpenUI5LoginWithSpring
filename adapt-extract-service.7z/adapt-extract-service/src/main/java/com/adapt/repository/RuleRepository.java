package com.adapt.repository;

import com.adapt.file.entity.DroolsBusinessRulesDecisionTableEntity;
import java.util.List;

public interface RuleRepository {
  List<DroolsBusinessRulesDecisionTableEntity> getRules(Integer fileId,
      DroolsBusinessRuleGroupName droolsBusinessRuleGroupName);

}
