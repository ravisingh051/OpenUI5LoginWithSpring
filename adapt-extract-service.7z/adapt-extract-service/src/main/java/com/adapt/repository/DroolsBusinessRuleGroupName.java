package com.adapt.repository;

public enum DroolsBusinessRuleGroupName {
  // NOTE: put single quote before and after group name
  CHANGE_CRITERIA("'ChangeCriteria'"), BUSINESS_CRITERIA("'BusinessCriteria'"), SELECTION_CRITERIA(
      "'SelectionCriteria'");

  private String value;

  DroolsBusinessRuleGroupName(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }
}
