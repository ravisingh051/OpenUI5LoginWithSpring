package com.adapt.repository;

import com.adapt.config.Constant;
import com.adapt.file.entity.DroolsBusinessRulesDecisionTableEntity;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository("ruleRepository")
public class RuleRepositoryImpl implements RuleRepository {

  @Qualifier("idisEntityManager")
  @Autowired
  private EntityManager entityManager;

  @Override
  public List<DroolsBusinessRulesDecisionTableEntity> getRules(Integer fileIdentifier,
      DroolsBusinessRuleGroupName droolsBusinessRuleGroupName) {

    StoreProcedureRepository<DroolsBusinessRulesDecisionTableEntity> stroreProcedureRepository = new StoreProcedureRepository<DroolsBusinessRulesDecisionTableEntity>(
        entityManager, Constant.USP_GET_RULES) {

      @Override
      public void configureStoreProcedure() {
        registerStoredProcedureParameter("i_file_identifier", Integer.class, ParameterMode.IN,
            fileIdentifier);

        registerStoredProcedureParameter("i_group_names", String.class, ParameterMode.IN,
            droolsBusinessRuleGroupName.getValue());

        registerStoredProcedureParameter("i_clone_num", Integer.class, ParameterMode.IN, 0);
      }
    };
    return stroreProcedureRepository.execute();
  }
}
