package com.adapt.repository;

import com.adapt.api.config.domain.JobFileWithMultiEmployerEntity;
import com.adapt.config.Constant;
import com.adapt.file.entity.JobFileEntity;
import com.adapt.file.entity.SectionAttributeEntity;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository(value = "jobRepository")
public class JobRepositoryImpl implements JobRepository {

  @Qualifier("idisEntityManager")
  @Autowired
  private EntityManager entityManager;

  @Override
  public Collection<JobFileEntity> findJobsByExpectedDate(LocalDate date) {
    return getJobFileDetails(date);
  }

  @Override
  public JobFileWithMultiEmployerEntity getJobFileWithMultiEmployerEntity(LocalDate date) {
    StoreProcedureRepository<JobFileWithMultiEmployerEntity> storeProcedureRepository = new StoreProcedureRepository<JobFileWithMultiEmployerEntity>(
        entityManager, Constant.USP_GET_EXPECTED_JOBS_BY_DATE_AND_PRIORITY) {
      @Override
      public void configureStoreProcedure() {
        registerStoredProcedureParameter("i_date", java.sql.Date.class, ParameterMode.IN,
            java.sql.Date.valueOf(date));
      }
    };
    List<JobFileWithMultiEmployerEntity> jobList = storeProcedureRepository.execute();
    if (jobList != null && !jobList.isEmpty()) {
      return jobList.get(0);
    } else {
      return null;
    }
  }

  private List<JobFileEntity> getJobFileDetails(LocalDate date) {

    StoreProcedureRepository<JobFileEntity> storeProcedureRepository = new StoreProcedureRepository<JobFileEntity>(
        entityManager, Constant.USP_GET_EXPECTED_JOBS_BY_DATE) {
      @Override
      public void configureStoreProcedure() {
        registerStoredProcedureParameter("i_date", java.sql.Date.class, ParameterMode.IN,
            java.sql.Date.valueOf(date));
      }
    };
    List<JobFileEntity> jobFileEntities = storeProcedureRepository.execute();

    for (JobFileEntity jobFileEntity : jobFileEntities) {
      List<SectionAttributeEntity> sectionAttributeEntities = getSectionAttributeDetails(
          jobFileEntity.getFileIdentifier());
      jobFileEntity.setSectionAttributeEntities(sectionAttributeEntities);
    }
    return jobFileEntities;
  }

  private List<SectionAttributeEntity> getSectionAttributeDetails(Integer fileIdentifier) {
    StoreProcedureRepository<SectionAttributeEntity> storeProcedureRepository = new StoreProcedureRepository<SectionAttributeEntity>(
        entityManager, Constant.USP_GET_FILE_ATTRIBUTE_DETAILS) {
      @Override
      public void configureStoreProcedure() {
        registerStoredProcedureParameter("i_file_identifier", Integer.class, ParameterMode.IN,
            fileIdentifier);
      }
    };
    return storeProcedureRepository.execute();
  }

}
