package com.adapt.repository;

import com.adapt.file.entity.EnrichmentApiInfo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository(value = "secondaryDataRepository")
public class SecondaryDataRepositoryImpl implements SecondaryDataRepository {

  private static final Logger LOGGER = LoggerFactory.getLogger(SecondaryDataRepositoryImpl.class);

  public static final String SP_USP_GET_FILE_ENRICHMENT_INFO = "USP_Get_File_Enrichment_Info";


  @Qualifier("idisEntityManager")
  @Autowired
  private EntityManager entityManager;

  @Override
  public List<EnrichmentApiInfo> getSecondaryDataInfoEntity(Integer fileIdentifier) {
    LOGGER.debug("fileIdentifier : {}  ", fileIdentifier);
    StoreProcedureRepository<EnrichmentApiInfo> stroreProcedureRepository =
        new StoreProcedureRepository<EnrichmentApiInfo>(entityManager,
            SP_USP_GET_FILE_ENRICHMENT_INFO) {
          @Override
          public void configureStoreProcedure() {
            registerStoredProcedureParameter("i_file_identifier", Integer.class, ParameterMode.IN,
                fileIdentifier);
          }
        };
    List<EnrichmentApiInfo> enrichmentApiInfoList = stroreProcedureRepository.execute();
    LOGGER.debug("number of {} enrichmentApiInfoList found for fileid : {}  ",
        enrichmentApiInfoList.size(), fileIdentifier);
    return enrichmentApiInfoList;
  }

}
