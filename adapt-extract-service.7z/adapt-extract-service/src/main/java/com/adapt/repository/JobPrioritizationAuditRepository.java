package com.adapt.repository;

import com.adapt.file.entity.JobPrioritizationAudit;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository(value = "jobPrioritizationAuditRepository")
public interface JobPrioritizationAuditRepository
    extends JpaRepository<JobPrioritizationAudit, Integer> {

  @Transactional
  @Modifying(clearAutomatically = true)
  @Query("update JobPrioritizationAudit set jobPrioritizationStatus = :jobPrioritizationStatus where  jobPrioritizationStatus = :jobPrioritizationSourceStatus and sourceInstance = :sourceInstance")
  public void cleanUpJobPrioritizationAuditWithStarted(
      @Param("jobPrioritizationStatus") String jobPrioritizationStatus,
      @Param("jobPrioritizationSourceStatus") String jobPrioritizationSourceStatus,
      @Param("sourceInstance") String sourceInstance);

}
