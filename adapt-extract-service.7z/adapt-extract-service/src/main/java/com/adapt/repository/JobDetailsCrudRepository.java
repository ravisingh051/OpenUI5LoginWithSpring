package com.adapt.repository;

import com.adapt.config.AdaptJpaRepository;
import com.adapt.file.entity.JobDetails;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository(value = "jobDetailsCrudRepository")
public interface JobDetailsCrudRepository extends AdaptJpaRepository<JobDetails, Integer> {

  @Transactional
  @Modifying(clearAutomatically = true)
  @Query("update JobDetails " + "set totalErrorRecords =  isnull(totalErrorRecords,0) + :errorCount"
      + ",totalRecordsProcessedAdapt = isnull(totalRecordsProcessedAdapt,0) + :totalRecordsProcessedAdapt"
      + ",totalWarningRecords = isnull(totalWarningRecords,0) + :totalWarningRecords"
      + ",totalIgnoredRecords = isnull(totalIgnoredRecords,0) + :ignoreCount"
      + " where jobId = :jobId ")
  public void updateJobDetails(@Param("jobId") Integer jobId,
      @Param("totalRecordsProcessedAdapt") Integer totalRecordsProcessedAdapt,
      @Param("totalWarningRecords") Integer totalWarningRecords,
      @Param("errorCount") Integer errorCount, @Param("ignoreCount") Integer ignoreCount);

  @Transactional
  @Modifying(clearAutomatically = true)
  @Query("update JobDetails " + "set totalErrorRecords =  :errorCount"
      + ",totalRecordsProcessedAdapt = :totalRecordsProcessedAdapt"
      + ",totalWarningRecords = :totalWarningRecords" + ",totalIgnoredRecords =  :ignoreCount"
      + ",totalRecordsInFile = :totalRecordsInFile" + " where jobId = :jobId ")
  public void updateJobIntialCountDetails(@Param("jobId") Integer jobId,
      @Param("totalRecordsProcessedAdapt") Integer totalRecordsProcessedAdapt,
      @Param("totalWarningRecords") Integer totalWarningRecords,
      @Param("errorCount") Integer errorCount, @Param("ignoreCount") Integer ignoreCount,
      @Param("totalRecordsInFile") Integer totalRecordsInFile);

}
