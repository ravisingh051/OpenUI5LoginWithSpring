package com.adapt.repository;

import com.adapt.file.entity.EnrichmentApiInfo;
import java.util.List;

public interface SecondaryDataRepository {
  public List<EnrichmentApiInfo> getSecondaryDataInfoEntity(Integer fileIdentifier);
}
