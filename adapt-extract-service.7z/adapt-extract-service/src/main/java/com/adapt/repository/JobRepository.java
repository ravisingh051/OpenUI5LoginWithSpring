package com.adapt.repository;

import com.adapt.api.config.domain.JobFileWithMultiEmployerEntity;
import com.adapt.file.entity.JobFileEntity;
import java.time.LocalDate;
import java.util.Collection;

public interface JobRepository {
  Collection<JobFileEntity> findJobsByExpectedDate(LocalDate expectedDate);

  JobFileWithMultiEmployerEntity getJobFileWithMultiEmployerEntity(LocalDate date);

}
