package com.adapt.message;

import com.adapt.file.messaging.CleanAuditDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("jobPrioritizationServiceActivator")
public class JobPrioritizationServiceActivator implements JobPrioritizationConfiguration {

  @Autowired
  private CleanAuditDetailsService cleanAuditDetailsService;

  @Override
  public Boolean jobAuditCleanUp() {
    return cleanAuditDetailsService.isCleanupCompleted();

  }

}
