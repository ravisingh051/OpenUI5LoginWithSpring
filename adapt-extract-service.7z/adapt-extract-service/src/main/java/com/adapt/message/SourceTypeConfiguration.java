package com.adapt.message;

import org.springframework.messaging.Message;

public interface SourceTypeConfiguration {
  Message<?> executeSourceType(Message<?> message);
}