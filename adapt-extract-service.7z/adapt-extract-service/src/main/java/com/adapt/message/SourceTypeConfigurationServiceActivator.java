package com.adapt.message;

import com.adapt.config.Constant;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.messaging.Message;
import org.springframework.util.Assert;

@Setter
@Getter
@Slf4j
public class SourceTypeConfigurationServiceActivator implements SourceTypeConfiguration {

  private static final String DATA_SOURCE_TYPE = "dataSourceType";
  private ConfigurationGateway apiConfigurationGateway;
  private ConfigurationGateway fileConfigurationGateway;
  private String componentName;

  @Override
  public Message<?> executeSourceType(Message<?> message) {
    log.debug("invoke : {} ", getComponentName());
    String dataSourceType = message.getHeaders().get(DATA_SOURCE_TYPE, String.class);
    log.debug("dataSourceType : {} ", dataSourceType);
    Message<?> returnMessage;
    Assert.notNull(dataSourceType, "Source Type must not be null");
    if (StringUtils.equalsIgnoreCase(dataSourceType, Constant.SOURCE_TYPE_FILE_DEL)
        || StringUtils.equalsIgnoreCase(dataSourceType, Constant.SOURCE_TYPE_FILE_FIX)) {
      if (fileConfigurationGateway != null) {
        returnMessage = fileConfigurationGateway.execute(message);
      } else {
        returnMessage = message;
      }
    } else {
      if (apiConfigurationGateway != null) {
        returnMessage = apiConfigurationGateway.execute(message);
      } else {
        returnMessage = message;
      }
    }
    if (returnMessage == null) {
      log.debug("Gateway Timeout Occurred");
    }
    log.debug("execution completed : {} ", getComponentName());
    return returnMessage;
  }
}