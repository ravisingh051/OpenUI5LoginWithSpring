package com.adapt.message;

public interface JobPrioritizationConfiguration {
  Boolean jobAuditCleanUp();
}
