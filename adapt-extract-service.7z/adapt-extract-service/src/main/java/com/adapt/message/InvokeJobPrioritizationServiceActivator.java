package com.adapt.message;

import com.adapt.exception.NullResponseException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;

@Setter
@Getter
@Slf4j
public class InvokeJobPrioritizationServiceActivator {

  private JobPrioritizationGateway jobPrioritizationGateway;
  private String componentName;

  /**
   * Execute.
   *
   * @param message
   *          the message
   * @return the message
   */
  public Message<?> execute(Message<?> message) {
    log.debug("Start: Invoke Job Prioritization {} ", getComponentName());
    Message<?> retMessage = null;
    try {
      retMessage = jobPrioritizationGateway.startJobPrioritization(message);
      if (retMessage == null) {
        log.debug("Gateway Timeout Occurred");
      }

    } catch (NullResponseException nullResponseException) {
      log.debug("No Job Found for Prioritization");
    }
    log.debug("End: Invoke Job Prioritization {} ", getComponentName());
    return retMessage;
  }
}
