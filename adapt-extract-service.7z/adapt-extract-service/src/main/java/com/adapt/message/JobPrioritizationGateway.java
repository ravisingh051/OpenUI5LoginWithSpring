package com.adapt.message;

import org.springframework.messaging.Message;

public interface JobPrioritizationGateway {
  Message<?> startJobPrioritization(Message<?> message);
}
