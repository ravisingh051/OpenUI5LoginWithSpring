package com.adapt.message;

import com.adapt.exception.RawDataExtractionException;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;

@Component("rawDataExtractionErrorServiceActivator")
public class RawDataExtractionErrorServiceActivator {

  public void throwRawDataExtractionException(Message<?> message) {
    throw new RawDataExtractionException("Unable to read data from source.",
        ((MessagingException) message.getPayload()));
  }

}
