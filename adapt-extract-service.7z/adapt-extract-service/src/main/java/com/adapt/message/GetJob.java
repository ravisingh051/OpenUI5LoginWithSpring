package com.adapt.message;

import com.adapt.file.entity.JobPriorityGetPayload;
import org.springframework.messaging.Message;

public interface GetJob {
  Message<?> getJob(Message<JobPriorityGetPayload> message);
}