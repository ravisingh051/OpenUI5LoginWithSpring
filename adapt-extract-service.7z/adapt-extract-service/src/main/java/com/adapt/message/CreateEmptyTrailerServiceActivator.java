package com.adapt.message;

import com.alight.adapt.datasets.TrailerDataset;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("createEmptyTrailerServiceActivator")
public class CreateEmptyTrailerServiceActivator extends AbstractTransformer {

  @Override
  public Message<TrailerDataset> doTransform(Message<?> message) throws Exception {
    MessageBuilder<TrailerDataset> messageBuilder = MessageBuilder
        .withPayload(new TrailerDataset());
    messageBuilder.setHeader("replyChannel", message.getHeaders().get("replyChannel"));
    messageBuilder.setHeader("output-channel", message.getHeaders().get("output-channel"));

    return messageBuilder.build();
  }

}
