package com.adapt.message;

import com.adapt.file.entity.JobPriorityGetPayload;
import java.util.Map;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

public interface DbJobGateway {
  Message<?> getDbJob(@Payload JobPriorityGetPayload jobPriorityGetPayload,
      @Headers Map<String, Object> header);
}
