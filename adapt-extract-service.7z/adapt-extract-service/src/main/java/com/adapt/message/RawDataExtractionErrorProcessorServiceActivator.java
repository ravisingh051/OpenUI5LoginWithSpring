package com.adapt.message;

import com.adapt.event.EventFactory;
import com.adapt.event.EventMessage;
import com.adapt.event.EventTypeEnum;
import com.adapt.event.JobFailedOccurredEvent;
import com.adapt.file.entity.JobModelMultiEmployer;
import com.adapt.file.service.EventNotificationService;
import com.alight.idis.jobs.JobStatus;
import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.client.HttpServerErrorException;

@Component("rawDataExtractionErrorProcessorServiceActivator")
public class RawDataExtractionErrorProcessorServiceActivator {

  @Autowired
  EventNotificationService eventNotificationService;

  private static final Logger LOGGER = LoggerFactory
      .getLogger(RawDataExtractionErrorProcessorServiceActivator.class);

  /**
   * This method processes the message and invokes jobFailed event.
   * 
   * @param message
   *          - The message
   */
  public void processMessage(Message<?> message) {
    LOGGER.error("Error occurred in source");
    if (message != null) {
      MessagingException messagingException = (MessagingException) message.getPayload();
      if (messagingException.getCause() instanceof HttpServerErrorException) {
        LOGGER.error("Error occurred in source For HTTP Call {}",
            ((HttpServerErrorException) messagingException.getCause()).getResponseBodyAsString());
      }
      Message<?> failedMessage = messagingException.getFailedMessage();
      if (failedMessage != null) {
        Object payload = failedMessage.getPayload();
        Assert.notNull(payload, "Did not find payload from the failed message");
        if (payload instanceof JobModelMultiEmployer) {
          JobModelMultiEmployer jobModelMultiEmployer = (JobModelMultiEmployer) payload;
          Assert.notNull(jobModelMultiEmployer, "jobModelMultiEmployer should not be null");

          sendJobFailedEvent(jobModelMultiEmployer, messagingException.getCause().getMessage());
        }

      }
    }
  }

  private void sendJobFailedEvent(JobModelMultiEmployer jobModelMultiEmployer, String message) {
    Integer jobId = jobModelMultiEmployer.getJobId();
    Integer fileId = jobModelMultiEmployer.getFileOutBoundModel().getFileId();
    Integer fileVersion = jobModelMultiEmployer.getFileOutBoundModel().getFileVersion();
    Integer fileIdentifier = jobModelMultiEmployer.getFileOutBoundModel().getFileIdentifier();
    JobFailedOccurredEvent jobFailedOccurredEvent = (JobFailedOccurredEvent) EventFactory
        .getEventType(EventTypeEnum.JOB_FAILED);
    jobFailedOccurredEvent.setFileId(fileId);
    jobFailedOccurredEvent.setJobId(jobId);
    jobFailedOccurredEvent.setFileVersion(fileVersion);
    jobFailedOccurredEvent.setFileIdentifier(fileIdentifier);
    jobFailedOccurredEvent.setTime(LocalDateTime.now());
    jobFailedOccurredEvent.setEventType(EventTypeEnum.JOB_FAILED.name());
    jobFailedOccurredEvent.setJobStatus(JobStatus.FAILED.getValue());
    EventMessage eventMessage = new EventMessage();
    eventMessage.setMessage(message);
    jobFailedOccurredEvent.setMessage(eventMessage);

    eventNotificationService.sendJobFailedEvent(jobFailedOccurredEvent);
  }

}