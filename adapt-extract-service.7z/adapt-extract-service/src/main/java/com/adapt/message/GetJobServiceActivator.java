package com.adapt.message;

import com.adapt.exception.NullResponseException;
import com.adapt.file.entity.JobPriorityGetPayload;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;

@Setter
@Getter
@Slf4j
public class GetJobServiceActivator implements GetJob {

  private DbJobGateway dbJobGateway;
  private String componentName;

  @Override
  public Message<?> getJob(Message<JobPriorityGetPayload> message) {
    log.debug("invoke : {} ", getComponentName());
    Message<?> returnMessage = null;
    try {
      returnMessage = dbJobGateway.getDbJob(message.getPayload(), message.getHeaders());
      if (returnMessage == null) {
        log.debug("Gateway Timeout Occurred");
      }

    } catch (NullResponseException nullResponseException) {
      log.debug("No Job Found for Prioritization");
    }

    log.debug("execution completed : {} ", getComponentName());
    return returnMessage;
  }
}