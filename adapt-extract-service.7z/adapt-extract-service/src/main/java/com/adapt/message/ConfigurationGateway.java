package com.adapt.message;

import org.springframework.messaging.Message;

public interface ConfigurationGateway {
  Message<?> execute(Message<?> message);

}
