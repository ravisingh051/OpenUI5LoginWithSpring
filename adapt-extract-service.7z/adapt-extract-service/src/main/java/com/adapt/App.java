package com.adapt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.config.EnableIntegrationManagement;
import org.springframework.integration.http.config.EnableIntegrationGraphController;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@Configuration
@EnableAsync
@ImportResource({ "extract-flow.xml" })
@EnableIntegrationGraphController
@EnableIntegrationManagement
public class App {

  public static void main(String[] args) {
    SpringApplication.run(App.class, args);
  }

}
