package com.alight.adapt.dbmigrator.runner;

import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class BaseMigrationRunner {

  String datasource;
  String username;
  String password;
  String scriptsPath;

  @Autowired
  Flyway flyway;

  public void runMigration() {
    flyway.setDataSource(datasource, username, password);
    flyway.setBaselineOnMigrate(true);
    flyway.setSchemas("dbo");
    flyway.setOutOfOrder(true);

    flyway.setLocations(scriptsPath);
    flyway.migrate();

  }

}
