package com.alight.adapt.dbmigrator.runner;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("metainfoMigrationRunner")
public class MetainfoMigrationRunner extends BaseMigrationRunner {
  
  @Value("${spring.metainfo.url}")
  private String metainfoDatasource;
  
  @Value("${spring.metainfo.username}")
  private String metainfoUsername;
  
  @Value("${spring.metainfo.password}")
  private String metainfoPassword;
  
  @Value("${metainfoScriptsPath}")
  private String metainfoScriptsPath;

  @Override
  public void runMigration() {
    this.datasource = metainfoDatasource;
    this.username = metainfoUsername;
    this.password = metainfoPassword;
    this.scriptsPath = metainfoScriptsPath;
    super.runMigration();
  }
  
}
