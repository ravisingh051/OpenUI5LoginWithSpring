package com.alight.adapt.dbmigrator.mail;

public class Mail {
  
  private String from;
  private String to;
  private String subject;
  private String content;

  Mail() {
  }

  String getFrom() {
      return from;
  }

  void setFrom(String from) {
      this.from = from;
  }

  String getTo() {
      return to;
  }

  void setTo(String to) {
      this.to = to;
  }

  String getSubject() {
      return subject;
  }

  void setSubject(String subject) {
      this.subject = subject;
  }

  String getContent() {
      return content;
  }

  void setContent(String content) {
      this.content = content;
  }

  
}