package com.alight.adapt.dbmigrator.mail;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MailConfiguration {
  
  @Value("${mail.from}")
  String from;
  
  @Value("${mail.to}")
  String to;

  MailConfiguration() {
  }

  String getFrom() {
    return from;
  }

  String getTo() {
    return to;
  }
  
  

  
}