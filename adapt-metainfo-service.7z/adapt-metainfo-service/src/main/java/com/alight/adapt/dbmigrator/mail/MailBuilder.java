package com.alight.adapt.dbmigrator.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MailBuilder {
  
  @Autowired
  private MailConfiguration mailConfiguration;
  
  public Mail build(String subject, String content) {
    Mail mail = new Mail();
    mail.setTo(mailConfiguration.getTo());
    mail.setFrom(mailConfiguration.getFrom());
    mail.setSubject(subject);
    mail.setContent(content);
    return mail;
  }

}
