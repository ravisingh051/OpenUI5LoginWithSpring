package com.alight.adapt.dbmigrator;

import com.alight.adapt.dbmigrator.mail.EmailSender;
import com.alight.adapt.dbmigrator.mail.Mail;
import com.alight.adapt.dbmigrator.mail.MailBuilder;
import com.alight.adapt.dbmigrator.runner.BaseMigrationRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class DatabaseMigrator implements ApplicationRunner {

  private static Logger LOG = LoggerFactory.getLogger(App.class);

  @Autowired
  private BaseMigrationRunner metainfoMigrationRunner;

  @Autowired
  private EmailSender emailSender;

  @Autowired
  private MailBuilder mailBuilder;

  @Value("${environment}")
  private String environment;

  @Override
  public void run(ApplicationArguments args) throws Exception {
    runMigration();
  }

  void runMigration() {
    String startMessage = "Starting database migrations using Flyway...";
    LOG.info(startMessage);
    boolean success = false;
    try {
      metainfoMigrationRunner.runMigration();
      success = true;
    } catch (Exception e) {
      String message = e.getMessage();
      LOG.error(message);
      sendErrorMail(message);
    }

    if (success) {
      sendSuccessMail();
    }
    String endMessage = "Database migrations using Flyway have completed.";
    LOG.info(endMessage);
  }

  private void sendErrorMail(String message) {
    Mail mail = mailBuilder.build("ADaPT Database Migration Error", message);
    emailSender.sendMessage(mail);
  }

  private void sendSuccessMail() {
    String subject = "ADaPT meta-info Database Migration Completed Successfully on " + environment;
    String content = "Database migrations have completed on environment " + environment;
    Mail mail = mailBuilder.build(subject, content);
    emailSender.sendMessage(mail);
  }
}
