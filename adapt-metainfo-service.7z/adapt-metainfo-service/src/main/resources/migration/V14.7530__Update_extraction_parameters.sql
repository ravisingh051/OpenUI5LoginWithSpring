use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-10-10   Divya Jain			ADAPT-7530 : Data Extraction Improvements - UI changes
*/

-------- Add Extraction Parameters for newly added fields --------
if not exists (select 1 from [extraction_parameters] where [ep_id] between 43 and 46)
BEGIN
SET IDENTITY_INSERT [dbo].[extraction_parameters] ON
INSERT INTO [dbo].[extraction_parameters]([ep_id],[ep_ept_id],[ep_name],[ep_standardized_name],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES(44,1,'Plan year Additive Factor','planAdditionFactor','Divya Jain',getDate(),NULL,NULL)
INSERT INTO [dbo].[extraction_parameters]([ep_id],[ep_ept_id],[ep_name],[ep_standardized_name],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES(43,1,'System Date','systemDate','Divya Jain',getDate(),NULL,NULL)
INSERT INTO [dbo].[extraction_parameters]([ep_id],[ep_ept_id],[ep_name],[ep_standardized_name],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES(45,1,'Look Back Period (in days)','lookBackPeriod','Divya Jain',getDate(),NULL,NULL)
INSERT INTO [dbo].[extraction_parameters]([ep_id],[ep_ept_id],[ep_name],[ep_standardized_name],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES(46,1,'Look Ahead Period (in days)','lookAheadPeriod','Divya Jain',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[extraction_parameters] OFF
END
GO



if exists(select * from information_schema.columns where table_name='planyear_lookup')
begin
	drop table planyear_lookup
end;
go
