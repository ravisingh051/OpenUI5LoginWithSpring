USE [idis-metainfo]
GO
/*
Filename:  V13.7429__add_source_system_file_id.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-10-01   Pravin Rajput		 ADAPT-7429 : File ID attribute needed in Election File Master 
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 1014 and attribute_name = 'Source System File ID')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1014,'Source System File ID','Source System File ID','VARCHAR',NULL,NULL,50,'A1020682',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4688 and file_type_id = 16 and attribute_id = 1014)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4688,16,1014,'VARCHAR',0,NULL,'A1020682',getDate(),NULL,NULL,'sourceSystemFileId',NULL)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2122 and master_file_template_record_id = 16 and attribute_id = 1014)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2122,16,1,1014,'VARCHAR',0,12,NULL,75,'A1020682',getDate(),16,50,4688,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from drools_business_rules_decision_table where drools_business_rule_id = 87574)
BEGIN
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON 
INSERT INTO [dbo].[drools_business_rules_decision_table]
           ([drools_business_rule_id]
		   ,[drools_business_rule_name]
           ,[drools_business_rule_group_id]
           ,[rule_group_hierarchy_string]
           ,[drools_business_rule_version]
           ,[drools_business_rule_drl_file_content]
           ,[is_current]
           ,[created_by]
           ,[created_date]
           ,[drools_business_rule_ui_json_text]
           ,[drools_business_rule_pre_drl_text])
     VALUES
           (87574,'Mix_Template',6,NULL,1,'package com.alight.idis; import com.alight.adapt.datasets.RuleFailure; import com.alight.adapt.datasets.election.v1.ElectionDataset; import java.util.ArrayList; import com.alight.idis.template.rule.helper.RuleHelper; import com.alight.adapt.datasets.RuleFailureCode;   rule "sourceSystemFileId Length Validation Functions 89324110428344 0" salience 0 when 	$electionDataset : ElectionDataset() 	$ruleHelper : RuleHelper()  	if(89324110428344l > 0 && ( !java.util.Objects.equals($electionDataset.getSourceSystemFileId(), null ) && !java.util.Objects.equals($electionDataset.getSourceSystemFileId(), "" )  && $ruleHelper.isValidLength($electionDataset.getSourceSystemFileId(),50) != true   ) ) break [GOTO_THEN_1] then 	 /** NOTHING TO DO -- DEFAULT CASE */  then [GOTO_THEN_1]  	RuleFailure $ruleFailure = new RuleFailure(); 	if($electionDataset.getRuleFailures() == null){ 		$electionDataset.setRuleFailures(new ArrayList<>()); 	} 	$ruleFailure.setAttributeName("sourceSystemFileId"); 	$ruleFailure.setError(false); 	$ruleFailure.setErrorDescription("sourceSystemFileId length validation failed."); 	$ruleFailure.setRuleName("sourceSystemFileId Length Validation Functions 89324110428344 0"); 	$ruleFailure.setRuleFailureCode(RuleFailureCode.WARNING); 	$electionDataset.getRuleFailures().add($ruleFailure);  end   rule "sourceSystemFileId Length Validation Functions 89324113910685 -1" salience -1 when 	$electionDataset : ElectionDataset() 	$ruleHelper : RuleHelper()  	if(89324113910685l > 0 && ( $ruleHelper.isValidLength($electionDataset.getSourceSystemFileId(),50) != true  ) ) break [GOTO_THEN_1] then 	 /** NOTHING TO DO -- DEFAULT CASE */  then [GOTO_THEN_1]  	$electionDataset.setSourceSystemFileId($ruleHelper.getLeftValue($electionDataset.getSourceSystemFileId(),50)); end',1,'A1020682',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF 
END
GO

if not exists (select 1 from master_file_template_attr_br_assoc where mft_attr_br_assoc_id = 402)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attr_br_assoc] ON 
INSERT INTO [dbo].[master_file_template_attr_br_assoc]
           ([mft_attr_br_assoc_id]
		   ,[mftaa_id]
           ,[business_rule_id]
           ,[rule_execution_sequence]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[is_active])
     VALUES
           (402,2122,87574,1,'A1020682',getDate(),NULL,NULL,1)
SET IDENTITY_INSERT [dbo].[master_file_template_attr_br_assoc] OFF 
END
GO