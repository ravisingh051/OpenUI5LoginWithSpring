USE [idis-metainfo]
GO

/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
23-05-2019  Jinesh Vora	   ADAPT-2176 : User should be able to configure notification for the Outbound File Events & General Events
Data Insert Into Below Tables

Table List
notification_template_metainfo_elements
processing_system_events

*/

USE [idis-metainfo]

if not exists(select 1 from [dbo].[notification_template_metainfo_elements] where ntme_id = 29)
begin
SET IDENTITY_INSERT [dbo].[notification_template_metainfo_elements] ON;

INSERT [dbo].[notification_template_metainfo_elements] ([ntme_id], [element_name], [default_value], [created_by], [created_date_time], [updated_by], [updated_date_time], [templatized_name]) VALUES (29, N'Profile', N'', N'Valmik Pujara', CAST(N'2018-12-12 11:29:23.683' AS DateTime), NULL, NULL, N'{Profile}') 

SET IDENTITY_INSERT [dbo].[notification_template_metainfo_elements] OFF;
END;
GO


if not exists(select 1 from [dbo].[processing_system_events] where [event_id] in (13,14))
begin
SET IDENTITY_INSERT [dbo].[processing_system_events] ON;

INSERT INTO [dbo].[processing_system_events] ([event_id],[event_name],[event_description],[file_direction],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES (13,'OUTBOUND_FILE_DELIVERED','Outbound File Delivered','O','Jinesh',getdate(),NULL,NULL)
INSERT INTO [dbo].[processing_system_events] ([event_id],[event_name],[event_description],[file_direction],[created_by],[created_date_time],[updated_by],[updated_date_time]) VALUES (14,'TRANSMISSION_RE-TRIES_FAILURE','Transmission Re-tries Failure','O','Jinesh',getdate(),NULL,NULL)

SET IDENTITY_INSERT [dbo].[processing_system_events] OFF;
END;
GO
