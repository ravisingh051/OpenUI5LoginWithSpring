USE [idis-metainfo]
GO

/*
Date        Author          		Description
----------  ------------    		-------------------------------------------------------------------------------------------
2019-12-26	Valmik Pujara			ADAPT-8825: Support history in dataset writing rules

*/

/*
Updating Template For Dataset Writing Rule
*/

if exists (select 1 from drools_business_rule_template where drools_business_rule_template_name='Dataset Writing Rule')
BEGIN
SET IDENTITY_INSERT [dbo].[drools_business_rule_template] ON
UPDATE [dbo].[drools_business_rule_template] SET drools_business_rule_template_content='template header objName1

package com.alight.idis;

/*
{
	"ruleType": "DataSetWritingRule",
	"ruleConditionValue": [
		{
			"attributeName": "attrname1",
			"conditions": [
				{
					"id": "1",
					"label": "Conditional Statements",
					"helpText": "Text area for creating rules",
					"type": "textarea",
					"userInput": "",
					"endpoint": "",
					"columns": "6",
					"separator": "false"
				},
				{
					"id": "2",
					"label": "Action Statements",
					"helpText": "Text area for creating Action Statements",
					"type": "textarea",
					"userInput": "",
					"endpoint": "",
					"columns": "6",
					"separator": "true"
				},
				{
					"id": "3",
					"label": "Attributes",
					"helpText": "",
					"type": "dropdown",
					"userInput": "",
					"endpoint": "",
					"columns": "2",
					"separator": "false",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				},
				{
					"id": "4",
					"label": "Operators",
					"helpText": "",
					"type": "dropdown",
					"userInput": "",
					"endpoint": "/operators",
					"columns": "2",
					"separator": "false",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				},
				{
					"id": "5",
					"label": "Functions",
					"helpText": "",
					"type": "dropdown",
					"userInput": "",
					"endpoint": "/functions/outbound/all",
					"columns": "2",
					"separator": "false",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				},
				{
					"id": "6",
					"label": "Select Function",
					"helpText": "",
					"type": "dropdown",
					"userInput": "",
					"endpoint": "/functions/conditional/action/outbound/all",
					"columns": "3",
					"separator": "true",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				},
				{
					"id": "7",
					"label": "History Attributes",
					"helpText": "",
					"type": "groupDropdown",
					"userInput": "",
					"endpoint": "",
					"columns": "3",
					"separator": "false",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				},
				{
					"id": "8",
					"label": "History Attributes",
					"helpText": "",
					"type": "groupDropdown",
					"userInput": "",
					"endpoint": "",
					"columns": "3",
					"separator": "false",
					"options": [
						{
							"label": "-Please Select-",
							"value": "-Please Select-"
						}
					]
				}
			]
		}
	]
}
*/


template "DataSetWritingRule"


end template' where drools_business_rule_template_name='Dataset Writing Rule'
SET IDENTITY_INSERT [dbo].[drools_business_rule_template] OFF 
END
GO