USE [idis-metainfo];

/*
Filename:  V2.3707__add_column_trading_partner_auth_key_file_name.sql

Update Log

Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-04-25 Bhaumik sathvara ADAPT-3707 : User should be able to configure Key for Outbound
*/

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'trading_partner_auth_key_info' and
column_name = 'trading_partner_auth_key_file_name')

begin
    alter table trading_partner_auth_key_info add trading_partner_auth_key_file_name varchar(50) null
end

go
