USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
11-06-2018	Divya Jain		CC-34665: Updated to get attributeSize,attributeStartPosition,attributeEndPosition
12-09-2019	Snehal Patel	ADAPT-2993 : Column names in tables - Characters are missing - misspelled - Example foreign key - DB - High - Beyond Phase 2.
*/


IF OBJECT_ID('dbo.USP_Get_File_Attribute_Details') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_File_Attribute_Details AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_File_Attribute_Details]
	(
		@i_file_identifier int
	) 
AS
BEGIN

SET NOCOUNT ON; 
declare @inputFileIdentifier int;

set @inputFileIdentifier=@i_file_identifier;


select ftaa.standardized_name as attributeName,
	case
	when ad.default_data_type = 'VARCHAR' then 'java.lang.String' 
	when ad.default_data_type = 'INTEGER' then 'java.lang.Integer' 
	when ad.default_data_type = 'DATE' then 'java.util.Date' 
	when ad.default_data_type = 'DOUBLE' then 'java.lang.Double' 
	when ad.default_data_type = 'BIT' then 'java.lang.Boolean' 
	else ad.default_data_type end
	as defaultDatatype,
faa.attribute_row_position as columnOrder,
	case
	when fsa.file_compliant_section_short_name ='H' then 'HEADER'
	when fsa.file_compliant_section_short_name ='D' then 'DETAIL'
	when fsa.file_compliant_section_short_name ='T' then 'TRAILER'
	else fsa.file_compliant_section_short_name end
	as sectionType,
fsa.sequence as sequence,
fsa.is_mandatory as isSectionMandatory,
NULL as sectionDelimiter,
faa.is_mandatory as isAttributeMandatory,
faa.attribute_size as attributeSize,
faa.attribute_start_position as attributeStartPosition,
faa.attribute_end_position as attributeEndPosition
from file_attribute_association faa
join attribute_dictionary ad on faa.attribute_id=ad.attribute_id
join file_section_association fsa on fsa.fsa_id=faa.fsa_id and fsa.file_identifier=faa.file_identifier
join file_meta_info fmi on fmi.record_id = faa.file_identifier
join file_type_meta_info ftmi on fmi.file_type_id=ftmi.file_type_id
join file_type_attribute_association ftaa on ftmi.file_type_id=ftaa.file_type_id and faa.attribute_id=ftaa.attribute_id
where faa.file_identifier=@inputFileIdentifier
and faa.clone_num = 0
order by sectionType asc, sequence asc, columnOrder asc

END


Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_File_Attribute_Details TO exec_proc
GO

