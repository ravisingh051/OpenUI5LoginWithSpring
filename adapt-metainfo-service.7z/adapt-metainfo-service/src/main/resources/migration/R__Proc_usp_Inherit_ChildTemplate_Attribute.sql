USE [idis-metainfo]
GO

/****** Object:  StoredProcedure [dbo].[USP_Inherit_ChildTemplate_Attribute]    Script Date: 3/20/2018 4:15:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Dhaval Thakkar
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
Filename: Proc_USP_Inherit_ChildTemplate_Attribute.sql
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2018-12-24	Richa Ashara	ADAPT-307: User should be able to view the Last updated information for PMT/File Templates & Job Schedule
2018-01-11	Richa Asahra		ADAPT-300: User should be able to setup dataset writing rules for an Outbound 834 PMT & File
2019-08-05	Jinesh Vora		ADAPT-6906 : Clone records should be at the PMT level, not just the file level
2019-08-27  Divya Jain		ADAPT-7324: Removed is_draft column from drools_business_rules_decision_table and added to_do column in child_file_template_attribute_association.
2019-09-12  Snehal Patel	ADAPT-2993 : Column names in tables - Characters are missing - misspelled - Example foreign key - DB - High - Beyond Phase 2
2019-09-29	Jinesh Vora		ADAPT-7708 : Remove PMT - Phase 3
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/


IF OBJECT_ID('dbo.USP_Inherit_ChildTemplate_Attribute') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Inherit_ChildTemplate_Attribute');
GO

/*
IF OBJECT_ID('dbo.USP_Inherit_ChildTemplate_Attribute') IS NULL
EXEC('CREATE PROCEDURE dbo.[USP_Inherit_ChildTemplate_Attribute] AS SELECT 1')
GO

-- Added as part of PMT

ALTER PROCEDURE [dbo].[USP_Inherit_ChildTemplate_Attribute] AS SELECT 1;

-- Added up to here as part of PMT

-- Added All proc code in comment as part of PMT Remove

ALTER PROCEDURE [dbo].[USP_Inherit_ChildTemplate_Attribute]
	-- Add the parameters for the stored procedure here
	@CHILD_FILE_TEMPLATE_ID INT,
	@FILE_TEMPLATE_ID INT,
	@CHILD_FILE_TEMPLATE_VERSION INT,
	@CREATED_BY VARCHAR(50)
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	
	DECLARE @file_type_id INT;
	DECLARE @record_id INT;


	select @record_id=@FILE_TEMPLATE_ID;


	SELECT @file_type_id=[file_type_id] from [dbo].[child_file_template_meta_info] cftmi join [dbo].[master_file_template_meta_info] mftmi
		on cftmi.master_file_template_id=mftmi.master_file_template_id and cftmi.master_file_template_version=mftmi.master_file_template_version 
		where [child_file_template_id]=@CHILD_FILE_TEMPLATE_ID and [child_file_template_version]=@CHILD_FILE_TEMPLATE_VERSION

    ----count of ----
	DECLARE @NEW_RECORDS_COUNT INT
	SET @NEW_RECORDS_COUNT = (SELECT count(1) FROM [idis-metainfo].[dbo].[child_file_template_section_assoc] where [child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND [child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION)

	----retriving current identity number-----
	DECLARE @CURRENT_ID INT
	SET @CURRENT_ID = 0
	SET @CURRENT_ID = (SELECT IDENT_CURRENT( 'file_section_association' ) AS A)

	----update the identity number for new records, have a buffer of 5 records to avoid error-----
	DECLARE @NEW_RESEED INT
	SET @NEW_RESEED = @CURRENT_ID+@NEW_RECORDS_COUNT+5
	DBCC CHECKIDENT ('file_section_association', RESEED, @NEW_RESEED)


	DECLARE @NEW_IDENT INT
	SET @NEW_IDENT = @CURRENT_ID + 2;

	---------------------------------------------------
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int )

	INSERT INTO #TEMP_OLDNEWKEY
	SELECT  @NEW_IDENT+Row_number() Over(Order by B.cftsa_id) ,B.cftsa_id	
	FROM
		[idis-metainfo].[dbo].[child_file_template_section_assoc] B
		WHERE B.[child_file_template_id] = @CHILD_FILE_TEMPLATE_ID and B.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
		

	---------------------------------------------------

	SET IDENTITY_INSERT [dbo].[file_section_association] ON

	INSERT INTO [dbo].[file_section_association] 
		( [fsa_id]
		  ,[template_section_id]
		  ,[file_identifier]
		  ,[file_compliant_section_short_name]
		  --,[parent_fsa_id]
		  ,[section_display_name]
		  ,[sequence]
		  ,[is_mandatory]
		  --,[is_repeatable]
		  --,[max_repeat_count]
		  --,[section_delimiter]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time] )
	( SELECT 
		@NEW_IDENT+Row_number() Over(Order by B.cftsa_id) AS [fsa_id]
		,B.[template_section_id]
		,@record_id AS [file_identifier]
		,B.[template_compliant_section_short_name] AS [file_compliant_section_short_name]
		--,NULL
		,B.[section_display_name]
		,B.[sequence]
		,0
		--,0
		--,0
		--,NULL
		,@CREATED_BY
		,B.[created_date_time]
		,B.[updated_by]
		,B.[updated_date_time]
	FROM
	[idis-metainfo].[dbo].[child_file_template_section_assoc] B
	WHERE B.[child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND B.[child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION)

	SET IDENTITY_INSERT [dbo].[file_section_association] OFF

	-- ADAPT - 6906
	-- Clone inheritance 


INSERT INTO file_clone_info
	([file_identifier],[clone_num],[clone_name],[created_by],[created_date_time],[updated_by],[updated_date_time])
	SELECT 
		@record_id AS [file_identifier],
		cftci.clone_num,
		cftci.clone_name,
		@CREATED_BY,
		getdate(),
		@CREATED_BY,
		getdate()
	FROM child_file_template_clone_info cftci join child_file_template_meta_info cftmi on cftci.child_file_template_record_id = cftmi.child_file_template_record_id
	where [child_file_template_id]=@CHILD_FILE_TEMPLATE_ID and [child_file_template_version]=@CHILD_FILE_TEMPLATE_VERSION

	-- child file to file clone 
	-- ADAPT - 6906 

	-----------------------------------------------------------
	IF OBJECT_ID('tempdb..#TEMP_FTAA') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_FTAA; END

	-------------------------------------------------------------
	--Inherit Lookup Table Associations

	--faa_id,cftaa_id,need_lookup_table
	SELECT top 0 [faa_id],[cftaa_id]
	INTO #TEMP_FTAA  FROM [idis-metainfo].[dbo].[lookup_table_file_association];
	--ALTER TABLE #TEMP_FTAA ADD [needs_lookup_table] bit null;


	--insert into tmp table for the right order
	SELECT 
		@record_id AS [file_identifier],
		A.[attribute_id],
		A.[data_type],
		A.[is_mandatory],
		A.[attribute_row_position],
		A.[attribute_start_position],
		A.[attribute_end_position],
		--A.[needs_lookup_table],
		@CREATED_BY as created_by,
		A.[application_compliant_attribute_name],
		GETDATE() AS [created_date_time],
		--0 AS [is_hardcoded],
		--NULL AS [default_value],
		B.new_id AS [fsa_id], A.cftaa_id, A.[attribute_size],1 AS [is_inherited], A.[to_do]
		,A.clone_num 		-- ADAPT - 6906
	INTO #FILE_ATTR_TMP
	FROM 
		[idis-metainfo].[dbo].[child_file_template_attribute_association] A
		INNER JOIN #TEMP_OLDNEWKEY B ON A.cftsa_id = B.old_id
	WHERE [child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND [child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION
	order by A.attribute_row_position asc


	MERGE [idis-metainfo].[dbo].[file_attribute_association] AS TARGET
	USING (
		select * from #FILE_ATTR_TMP) AS SOURCE
	ON 1=0
	WHEN NOT MATCHED THEN
		INSERT ([file_identifier]
		,[attribute_id]
		,[data_type]
		,[is_mandatory]
		,[attribute_row_position]
		,[attribute_start_position]
		,[attribute_end_position]
		--,[needs_lookup_table]
		,[created_by]
		,[created_date_time]
		--,[is_hardcoded]
		--,[default_value]
		,[fsa_id]
		,[attribute_size]
		,[is_inherited]
		,[cftaa_id]
		,[file_format_compliant_attribute_name]
		,[updated_by]
		,[updated_date_time]
		,[clone_num]
		,[to_do])
	VALUES (
		SOURCE.[file_identifier],
		SOURCE.[attribute_id],
		SOURCE.[data_type],
		SOURCE.[is_mandatory],
		SOURCE.[attribute_row_position],
		SOURCE.[attribute_start_position],
		SOURCE.[attribute_end_position],
		--SOURCE.[needs_lookup_table],
		@CREATED_BY,
		GETDATE(),
		--SOURCE.[is_hardcoded],
		--SOURCE.[default_value],
		SOURCE.[fsa_id],
		SOURCE.[attribute_size],
		SOURCE.[is_inherited],
		SOURCE.cftaa_id,
		SOURCE.[application_compliant_attribute_name],
		@CREATED_BY,
		GETDATE(),
		SOURCE.clone_num,		-- ADAPT - 6906
		SOURCE.to_do
		)
	OUTPUT INSERTED.[faa_id], SOURCE.cftaa_id INTO #TEMP_FTAA;

	

-----------------------------------------------------------
--Inherit  Business Rules Associations
--- get record count for rules ----
DECLARE @RULES_COUNT INT
SET @RULES_COUNT = (select count(1) from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND cftaa.[child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION
)+
(select count(1) from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@CHILD_FILE_TEMPLATE_ID AND ltmi.lookup_table_version = @CHILD_FILE_TEMPLATE_VERSION
and ltmi.associated_file_type_id=@file_type_id
)+
(
select count(1) from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION and ctlsni.is_active=1
)+
(select count(1) from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION and cftsmaba.is_active=1
)

--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2

IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	CREATE TABLE #TEMP_DBRDT_OLDNEWKEY ( new_id int, old_id int ,rule_version int)

INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version)
(select @NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version from (
select drools_business_rule_id,drools_business_rule_version from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND cftaa.[child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION
union
select drools_business_rule_id,drools_business_rule_version from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@CHILD_FILE_TEMPLATE_ID AND ltmi.lookup_table_version = @CHILD_FILE_TEMPLATE_VERSION and ltmi.associated_file_type_id=@file_type_id
union
select drools_business_rule_id,drools_business_rule_version from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION and ctlsni.is_active=1
union
select drools_business_rule_id,drools_business_rule_version from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION and cftsmaba.is_active=1
) a)

SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@CREATED_BY,getDate() from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY
on drools_business_rule_id=old_id)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

INSERT INTO [idis-metainfo].[dbo].[file_attr_br_assoc]
      ([faa_id]
      ,[business_rule_id]
      ,[business_rule_version]
	  ,[rule_execution_sequence]
	  ,[rule_execution_comment]
      ,[created_by]
      ,[created_date_time]
      ,[updated_by]
      ,[updated_date_time])
	SELECT 
		A.faa_id,
		C.new_id,
		C.rule_version,
		D.rule_execution_sequence,
		D.rule_execution_comment,
		@CREATED_BY,
		GETDATE(),
		@CREATED_BY,
		GETDATE()

	FROM #TEMP_FTAA A
		INNER JOIN [idis-metainfo].[dbo].[file_attribute_association]  E
		ON A.faa_id = E.faa_id
		INNER JOIN [idis-metainfo].[dbo].[child_file_template_attr_br_assoc] D
		ON A.cftaa_id = D.cftaa_id
		INNER JOIN #TEMP_DBRDT_OLDNEWKEY C
		ON D.business_rule_id=C.old_id
		INNER JOIN [idis-metainfo].[dbo].[file_meta_info] F
		ON E.file_identifier = F.record_id;


		INSERT INTO [dbo].[file_secondary_mapping_attr_assoc]
		([fsmaa_file_identifier]
		,[fsmaa_faa_id]
		,[fsmaa_node_name]
		,[fsmaa_standardized_name]
		,[created_date_time]
		,[created_by]
		,[updated_date_time]
		,[updated_by]
		)
		(SELECT @record_id
		,A.faa_id
		,[csmaa_node_name]
		,[csmaa_standardized_name]
		,getDate()
		,@CREATED_BY
		,getDate()
		,@CREATED_BY
			FROM [dbo].[child_secondary_mapping_attr_assoc]  csmaa
			join #TEMP_FTAA A on csmaa.csmaa_cftaa_id=A.cftaa_id
			join child_file_template_meta_info cftmi on csmaa.csmaa_child_file_template_record_id=cftmi.child_file_template_record_id 
			where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION)

-----------------------------------------------------------
	
	
	--- get record count for lookup tables ----
DECLARE @LT_COUNT INT
SET @LT_COUNT = (select count(1) from lookup_table_meta_info ltmi where associated_file_level='C' and associated_file_type_id=@file_type_id and 
lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID)


--- reseed the identity ----
DECLARE @NEW_LT_RESEED INT=0
DECLARE @CURRENT_LT_RESEED INT=0
DECLARE @NEW_LT_INDENT INT=0
SET @CURRENT_LT_RESEED=(SELECT IDENT_CURRENT( 'lookup_table_meta_info' ) AS A)
SET @CURRENT_LT_RESEED= case when @CURRENT_LT_RESEED is NULL then 0 else @CURRENT_LT_RESEED end;
SET @NEW_LT_RESEED =@CURRENT_LT_RESEED+5
DBCC CHECKIDENT ('lookup_table_meta_info', RESEED, @NEW_LT_RESEED)
SET @NEW_LT_INDENT=@CURRENT_LT_RESEED+2

IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END
	CREATE TABLE #TEMP_LT_OLDNEWKEY ( new_id int, old_id int)

--print @fileId

INSERT into #TEMP_LT_OLDNEWKEY (new_id,old_id)
(select @NEW_LT_INDENT+Row_number() Over(Order by lookup_table_id),lookup_table_id from lookup_table_meta_info ltmi where associated_file_level='C' and associated_file_type_id=@file_type_id and 
lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID)

SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON 
insert into lookup_table_meta_info(lookup_table_id,lookup_table_name,lookup_key_description,lookup_table_version,associated_file_level,associated_file_level_id,associated_file_type_id,created_by,created_date_time)
(select new_id,lookup_table_name,lookup_key_description,1,'F',@FILE_TEMPLATE_ID, associated_file_type_id,@CREATED_BY,created_date_time
from lookup_table_meta_info join #TEMP_LT_OLDNEWKEY temp on temp.old_id=lookup_table_id where associated_file_level='C' and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID
and  lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION and associated_file_type_id=@file_type_id)
SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF

insert into lookup_table_details (lookup_table_id,lookup_table_version,lookup_key,lookup_value,created_by,created_date_time)
(select temp.new_id,1 ,lookup_key,lookup_value,@CREATED_BY,ltd.created_date_time from lookup_table_details ltd
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltd.lookup_table_id and ltmi.lookup_table_version=ltd.lookup_table_version
join #TEMP_LT_OLDNEWKEY temp on temp.old_id=ltmi.lookup_table_id
where associated_file_level='C' and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID and ltmi.lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION 
and associated_file_type_id=@file_type_id)

insert into lookup_table_composite_key_mapping(lookup_table_id,lookup_table_version,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,business_rule_id,
created_by,created_date_time,updated_by,updated_date_time)(select templt.new_id,1 ,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,
case when business_rule_id is NULL then NULL when business_rule_id is NOT NULL then temp.new_id end,
@CREATED_BY,ltckm.created_date_time,@CREATED_BY, GETDATE() from lookup_table_composite_key_mapping  ltckm
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltckm.lookup_table_id and ltmi.lookup_table_version=ltckm.lookup_table_version
INNER JOIN #TEMP_LT_OLDNEWKEY templt on templt.old_id= ltmi.lookup_table_id 
LEFT OUTER JOIN #TEMP_DBRDT_OLDNEWKEY temp on temp.old_id=business_rule_id 
where associated_file_level='C' and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID
and  ltmi.lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION and associated_file_type_id=@file_type_id)

insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,cftaa_id,is_active,created_by,created_date_time, updated_by,updated_date_time)
(select templt.new_id,1 ,temp.faa_id,null,null,1,@CREATED_BY,ltfa.created_date_time,@CREATED_BY,ltfa.created_date_time
from lookup_table_file_association ltfa
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
INNER JOIN #TEMP_FTAA temp on temp.cftaa_id=ltfa.cftaa_id 
INNER JOIN #TEMP_LT_OLDNEWKEY templt on templt.old_id= ltmi.lookup_table_id where associated_file_level='C' and associated_file_level_id=@CHILD_FILE_TEMPLATE_ID
and ltmi.lookup_table_version=@CHILD_FILE_TEMPLATE_VERSION and associated_file_type_id=@file_type_id and is_active=1 and ltfa.faa_id is NULL)



				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
			
				if exists(select 1 from child_template_layout_schema_node_info ctlsni join child_file_template_meta_info cftmi on cftmi.child_file_template_record_id=ctlsni.child_file_template_record_id
				where [child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND [child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION)
				BEGIN

				DECLARE @CTLSNI_COUNT INT
				select @CTLSNI_COUNT= count(1) from child_template_layout_schema_node_info ctlsni join child_file_template_meta_info cftmi on cftmi.child_file_template_record_id=ctlsni.child_file_template_record_id
				where [child_file_template_id] = @CHILD_FILE_TEMPLATE_ID AND [child_file_template_version] = @CHILD_FILE_TEMPLATE_VERSION and ctlsni.is_active=1
			
			
									DECLARE @NEW_FLSNI_RESEED INT=0
									DECLARE @CURRENT_FLSNI_RESEED INT=0
									DECLARE @NEW_FLSNI_INDENT INT=0
									SET @CURRENT_FLSNI_RESEED =(SELECT IDENT_CURRENT( 'file_layout_schema_node_info' ) AS A)
									SET @CURRENT_FLSNI_RESEED = case when @CURRENT_FLSNI_RESEED is NULL then 0 else @CURRENT_FLSNI_RESEED end;
									SET @NEW_FLSNI_RESEED =@CURRENT_FLSNI_RESEED+@CTLSNI_COUNT+5
									DBCC CHECKIDENT ('file_layout_schema_node_info', RESEED, @NEW_FLSNI_RESEED)
									SET @NEW_FLSNI_INDENT=@CURRENT_FLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_CTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_CTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_CTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_CTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_FLSNI_INDENT+Row_number() Over(Order by ctlsni_id),ctlsni_id
									from child_template_layout_schema_node_info ctlsni join child_file_template_meta_info cftmi 
									on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id where 
									cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1)

								
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] ON 
									INSERT INTO [dbo].[file_layout_schema_node_info]([flsni_id],[ctlsni_id],[file_identifier],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[node_clone_num])
									SELECT new_id,ctlsni_id,@record_id,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@CREATED_BY,getDate()
									,@CREATED_BY,getDate(),[node_max_size],[node_min_size],[node_clone_num] FROM child_template_layout_schema_node_info ctlsni 
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsni.ctlsni_id=old_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] OFF
								
									INSERT INTO [dbo].[file_layout_schema_node_assoc]([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time], [updated_by],[updated_date_time])
									SELECT a.new_id,
									case when parent_ctlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@CREATED_BY,getDate(),@CREATED_BY,getDate() from [child_template_layout_schema_node_assoc] ctlsna
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsna.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsna.ctlsni_id=old_id left outer join #TEMP_CTLSNI_OLDNEWKEY b on ctlsna.parent_ctlsni_id=b.old_id
									where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1
								
									INSERT INTO [dbo].[fls_node_enum_value_assoc]([flsni_id],[ctaeva_id],[enum_value],[enum_value_description],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,ctaeva_id,enum_value,enum_value_description,ctlsnea.is_active,@CREATED_BY,getDate(),@CREATED_BY,getDate() from ctls_node_enum_value_assoc ctlsnea 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnea.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsnea.ctlsni_id=old_id 
									where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1  
								
									INSERT INTO [dbo].[fls_node_dm_element_assoc]([flsni_id],[faa_id],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,faa.faa_id,ctlsnda.is_active,@CREATED_BY,getDate(),@CREATED_BY,getDate() from ctls_node_dm_element_assoc ctlsnda 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnda.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id 
									join file_attribute_association faa on faa.cftaa_id=ctlsnda.cftaa_id
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsnda.ctlsni_id=old_id 
									where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1 and faa.file_identifier=@record_id     
								
									INSERT INTO [dbo].[fls_node_br_assoc]([flsni_id],[business_rule_id],[rule_execution_sequence],[rule_execution_comment],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,rule_execution_comment,1,@CREATED_BY,getDate(),@CREATED_BY,getDate() from ctls_node_br_assoc ctlsnba 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join #TEMP_DBRDT_OLDNEWKEY b on ctlsnba.business_rule_id=b.old_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsnba.ctlsni_id=a.old_id where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION
									and ctlsni.is_active=1  and ctlsnba.is_active=1  
		
		
									INSERT INTO [dbo].[file_special_mapping_attr_br_assoc] ([file_identifier],[business_rule_id],[ftaa_id],[attribute_usage_type],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									(SELECT @record_id, new_id, ftaa_id,attribute_usage_type,1,@CREATED_BY,getDate(),@CREATED_BY,getDate() from cft_special_mapping_attr_br_assoc cftsmaba 
									join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id 
									left join #TEMP_DBRDT_OLDNEWKEY a on cftsmaba.business_rule_id=a.old_id
									where cftmi.child_file_template_id=@CHILD_FILE_TEMPLATE_ID AND cftmi.child_file_template_version = @CHILD_FILE_TEMPLATE_VERSION 
									and cftsmaba.is_active=1)
								
								
				END;

IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END

IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END

END


GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 

GRANT EXECUTE ON dbo.USP_Inherit_ChildTemplate_Attribute TO exec_proc
GO
*/