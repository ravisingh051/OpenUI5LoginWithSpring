use [idis-metainfo]
GO

/*
Filename:  V7.6609__update_cteva_id_for_file_to_allow_nulls.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-06-28   Divya Jain  		ADAPT-6609 : Outbound Voya file- Unable to add enumerated values
*/



if exists(select 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='fls_node_enum_value_assoc' and COLUMN_NAME='ctaeva_id' and IS_NULLABLE='NO')
begin
alter table fls_node_enum_value_assoc alter column ctaeva_id int null
end;
GO


