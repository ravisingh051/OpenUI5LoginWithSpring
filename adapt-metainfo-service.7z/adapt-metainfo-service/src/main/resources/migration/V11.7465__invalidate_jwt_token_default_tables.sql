USE [idis-metainfo]

---- Token storage details  -----------

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[oauth_access_token](
	[token_id] [varchar](255) NULL,
	[token] [varbinary](max) NULL,
	[authentication_id] [varchar](255) NOT NULL,
	[user_name] [varchar](255) NULL,
	[client_id] [varchar](255) NULL,
	[authentication] [varbinary](max) NULL,
	[refresh_token] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[authentication_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[oauth_refresh_token](
	[token_id] [varchar](255) NULL,
	[token] [varbinary](max) NULL,
	[authentication] [varbinary](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
