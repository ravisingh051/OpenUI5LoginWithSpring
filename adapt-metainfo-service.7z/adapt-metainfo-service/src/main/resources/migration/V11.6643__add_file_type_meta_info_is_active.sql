USE [idis-metainfo]
GO
/*
Filename:  V11.6643__add_file_type_meta_info_is_active.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-08-26   Bhaumik Sathvara  ADAPT-6643 : User is getting "Outbound Transaction 834" in File Type at Notification page.
*/

IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_type_meta_info' and column_name ='is_active')
BEGIN
alter table file_type_meta_info add is_active bit not null CONSTRAINT DF_file_type_meta_info_is_active DEFAULT(1)
END;

GO

IF EXISTS (SELECT 1 FROM file_type_meta_info WHERE file_type_name = 'Outbound Transaction 834' AND is_active = 1)
BEGIN
update file_type_meta_info set is_active = 0 WHERE file_type_name = 'Outbound Transaction 834'
END;
GO