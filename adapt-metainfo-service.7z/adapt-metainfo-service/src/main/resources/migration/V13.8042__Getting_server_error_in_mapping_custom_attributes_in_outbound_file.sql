use [idis-Metainfo]
GO

/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-10-14   Mayur Tanna			ADAPT-8042 : Getting server error in mapping custom attributes in outbound file (Remove un-used older entries )
*/

IF EXISTS (select 1 from master_file_template_attribute_association
where ftaa_id in (select ftaa_id from file_type_attribute_association where file_type_id=17 and ftaa_id in (4419,4420,4421,4422,4423,4424,4425,4426,4427,4428,4429,4550,4551,4552,4553,4554,4555,4556,4557,4558,4559,4560,4561,4562,4563,4564,4565,4566,4567,4568)))
BEGIN
DELETE from master_file_template_attribute_association
where ftaa_id in (select ftaa_id from file_type_attribute_association where file_type_id=17 and ftaa_id in (4419,4420,4421,4422,4423,4424,4425,4426,4427,4428,4429,4550,4551,4552,4553,4554,4555,4556,4557,4558,4559,4560,4561,4562,4563,4564,4565,4566,4567,4568))
END
GO

IF EXISTS (select 1 from file_type_attribute_association where file_type_id=17 and ftaa_id in (4419,4420,4421,4422,4423,4424,4425,4426,4427,4428,4429,4550,4551,4552,4553,4554,4555,4556,4557,4558,4559,4560,4561,4562,4563,4564,4565,4566,4567,4568))
BEGIN
DELETE FROM file_type_attribute_association where file_type_id=17 and ftaa_id in (4419,4420,4421,4422,4423,4424,4425,4426,4427,4428,4429,4550,4551,4552,4553,4554,4555,4556,4557,4558,4559,4560,4561,4562,4563,4564,4565,4566,4567,4568)
END
GO
