USE [idis-metainfo]
GO

/*
Update Log	
----------  -----------    ---------------------------------------------------------------------------------------
07-18-2019  Divya Jain	   ADAPT-6652 : Add transaction attributes to transaction pojo & assign standardized names

*/

if exists(select * from master_file_template_section_assoc where section_standardized_name is NULL and template_compliant_section_short_name='D' 
and master_file_template_record_id in (2,17,18))
begin
update master_file_template_section_assoc set section_standardized_name='excessCredits' where master_file_template_record_id in (2,17,18) and section_display_name='Excess Credit' and template_compliant_section_short_name='D' 
update master_file_template_section_assoc set section_standardized_name='electionCredits' where master_file_template_record_id in (2,17,18) and section_display_name='Election Credit' and template_compliant_section_short_name='D' 
update master_file_template_section_assoc set section_standardized_name='surcharges' where master_file_template_record_id in (2,17,18) and section_display_name='Surcharge' and template_compliant_section_short_name='D' 
update master_file_template_section_assoc set section_standardized_name='surchargeQuesAnswers' where master_file_template_record_id in (2,17,18) and section_display_name='Surcharge Question Answer' and template_compliant_section_short_name='D' 
update master_file_template_section_assoc set section_standardized_name='designatedBeneficiaries' where master_file_template_record_id in (2,17,18) and section_display_name='Designated Beneficiary' and template_compliant_section_short_name='D' 
update master_file_template_section_assoc set section_standardized_name='wellnessCreditQuesAnswers' where master_file_template_record_id in (2,17,18) and section_display_name='Wellness Credit EE QA' and template_compliant_section_short_name='D' 
end;
go


if exists(select 1 from file_type_attribute_association where file_type_id in (2,17) and attribute_logical_group_id in (67,6,13,68,2,69) and standardized_name not like '%.%')
begin
update file_type_attribute_association set standardized_name='excessCredits.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 67
update file_type_attribute_association set standardized_name='electionCredits.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 6
update file_type_attribute_association set standardized_name='surcharges.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 13
update file_type_attribute_association set standardized_name='surchargeQuesAnswers.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 68
update file_type_attribute_association set standardized_name='designatedBeneficiaries.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 2
update file_type_attribute_association set standardized_name='wellnessCreditQuesAnswers.'+standardized_name where file_type_id in (2,17) and attribute_logical_group_id = 69
end;
go

