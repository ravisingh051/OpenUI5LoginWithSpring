USE [idis-metainfo];
GO

/*
Filename:  V20.8948__remove_advanced_selection_criteria.sql

Update Log

Date			Author					Description
----------	 ------------		-------------------------------------------------------------------------------------------
2020-01-13	 Nilesh Jariya		ADAPT-8948 : Remove advanced selection criteria 
*/

IF EXISTS(select 1 from drools_business_rules_decision_table where drools_business_rule_id in (select fepba_br_id from file_ext_param_br_assoc))
BEGIN
	alter table file_ext_param_br_assoc DROP CONSTRAINT FK_fepba_K4_dbr_K1
	delete from drools_business_rules_decision_table where drools_business_rule_id in (select fepba_br_id from file_ext_param_br_assoc)
END;

IF EXISTS(select  1 from Sys.tables where name = 'file_ext_param_br_assoc')
BEGIN
	drop table [dbo].file_ext_param_br_assoc
END;
GO
