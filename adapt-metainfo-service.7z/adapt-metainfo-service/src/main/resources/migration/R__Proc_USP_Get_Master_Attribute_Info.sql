USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Master_Attribute_Info') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Master_Attribute_Info AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_Master_Attribute_Info]
	(
              @i_mft_id int,
              @i_mft_version int
			  --@i_mft_rec_id int
			  
       )
AS
BEGIN

SET NOCOUNT ON;
declare @masterFileId int;
declare @masterFileVersion int;

set @masterFileId=@i_mft_id;
set @masterFileVersion=@i_mft_version;

select distinct ad.attribute_name, mftaa.data_type, ad.attribute_size, mftaa.is_mandatory,  mftaa.attribute_row_position,vt.validation_type_id, ad.attribute_id,
STUFF((SELECT 
case when vvg.validation_type_id=2 then ' OR ' + vv.valid_value_name
else ',' + vv.valid_value_name end from valid_values vv left join mftaa_valid_value_assoc mf on vv.valid_value_id = mf.valid_value_id
join valid_value_groups vvg ON vv.valid_value_group_id = vvg.valid_value_group_id
where  mf.mftaa_id = mftaa.mftaa_id and vv.is_active = 1 and mf.is_active=1 
FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,case when vvg.validation_type_id=2 then 4 else 1 end,'') validation,
mftsa.section_display_name as section_name, mftsa.sequence as section_sequence
from master_file_template_attribute_association mftaa INNER JOIN attribute_dictionary ad ON ad.attribute_id = mftaa.attribute_id
INNER JOIN master_file_template_meta_info mftmi on mftaa.master_file_template_id=mftmi.master_file_template_id and mftaa.master_file_template_version=mftmi.master_file_template_version
INNER JOIN master_file_template_section_assoc mftsa on mftaa.mftsa_id=mftsa.mftsa_id
--INNER JOIN template_sections ts on ts.template_section_id=mftsa.template_section_id
left join mftaa_valid_value_assoc mfvv ON mftaa.mftaa_id=mfvv.mftaa_id and mfvv.is_active=1
left join valid_values vv ON  mfvv.valid_value_id = vv.valid_value_id and vv.is_active=1
left join valid_value_groups vvg ON vv.valid_value_group_id = vvg.valid_value_group_id and vvg.is_active=1 
left join validation_types vt ON vvg.validation_type_id = vt.validation_type_id
where mftaa.master_file_template_id = @masterFileId and   mftaa.master_file_template_version = @masterFileVersion
--where mftmi.master_file_template_record_id = @i_mft_rec_id
order by mftsa.sequence asc ,ad.attribute_name asc


END 

GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Master_Attribute_Info TO exec_proc
GO

