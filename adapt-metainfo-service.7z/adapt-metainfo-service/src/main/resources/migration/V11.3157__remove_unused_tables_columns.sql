USE [idis-metainfo]
GO

/*
Filename:  V11.3157_remove_unused_tables_columns.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-03	Divya Jain			ADAPT-3157:Remove unused and redundant tables/columns from metainfo database and their references (if any)
*/

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='application_audit_log')
BEGIN
drop table application_audit_log
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='application_notification_log')
BEGIN
drop table application_notification_log
END;
GO


IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='error_log_application')
BEGIN
drop table error_log_application
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='error_log_data_file_processing')
BEGIN
drop table error_log_data_file_processing
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='error_code')
BEGIN
drop table error_code
END;
GO


IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='error_severity')
BEGIN
drop table error_severity
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='error_type')
BEGIN
drop table error_type
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='expectation_attempt_log')
BEGIN
drop table expectation_attempt_log
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='file_export_queries')
BEGIN
-- (also remove SP corresponding to this.)
drop table file_export_queries
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='file_format_attribute_association')
BEGIN
drop table file_format_attribute_association
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='file_meta_info_fist')
BEGIN
drop table file_meta_info_fist
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='file_processing_audit_log')
BEGIN
drop table file_processing_audit_log
END;
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE name = N'FK_itm_K2_idis_team_K1' and type='F')
BEGIN
alter table idis_team_member drop constraint FK_itm_K2_idis_team_K1
END;
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE name = N'FK_fmi_K25_idis_team_member_K1' and type='F')
BEGIN
alter table file_meta_info drop constraint FK_fmi_K25_idis_team_member_K1
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='idis_team_member')
BEGIN
drop table idis_team_member
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='idis_team_trading_partner_association')
BEGIN
drop table idis_team_trading_partner_association
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.tables where table_name='trading_partner_lob_association')
BEGIN
drop table trading_partner_lob_association
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='job_details' and column_name='test_cfg_config')
BEGIN
alter table job_details drop column test_cfg_config
END;
GO


IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_info' and column_name='trading_partner_employer_id')
BEGIN
alter table trading_partner_info drop column trading_partner_employer_id
END;
GO


IF EXISTS (SELECT 1 FROM sys.objects WHERE name = N'DF_trading_partner_info_trading_partner_is_consenting' and type='D')
BEGIN
alter table trading_partner_info drop constraint DF_trading_partner_info_trading_partner_is_consenting
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_info' and column_name='trading_partner_is_consenting')
BEGIN
alter table trading_partner_info drop column trading_partner_is_consenting
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fci_K2_fmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_clone_info')
	)
BEGIN
ALTER TABLE [dbo].[file_clone_info]  WITH CHECK ADD  CONSTRAINT [FK_fci_K2_fmi_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_clone_info] CHECK CONSTRAINT [FK_fci_K2_fmi_K1]
END;
GO


 