USE [idis-metainfo]
GO
/*
Filename:  V9.6754__add_file_type_attribute_association.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-17   Shipra Maheshwari  ADAPT-6754 : Employee Assigned ID attribute is missing and needed in Inbound Election File Master (file #16)
*/
if not exists (select 1 from file_type_attribute_association where ftaa_id = 4655 and file_type_id = 16 and attribute_id = 4)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4655,16,4,'VARCHAR',0,NULL,'Shipra Maheshwari',getDate(),NULL,NULL,'employerAssignedId',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2118 and master_file_template_record_id = 16 and attribute_id = 4)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2118,16,1,4,'VARCHAR',0,11,NULL,75,'shipra maheshwari',getDate(),16,50,4655,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from drools_business_rules_decision_table where drools_business_rule_id = 80837)
BEGIN
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON 
INSERT INTO [dbo].[drools_business_rules_decision_table]
           ([drools_business_rule_id]
		   ,[drools_business_rule_name]
           ,[drools_business_rule_group_id]
           ,[rule_group_hierarchy_string]
           ,[drools_business_rule_version]
           ,[drools_business_rule_drl_file_content]
           ,[is_current]
           ,[created_by]
           ,[created_date]
           ,[drools_business_rule_ui_json_text]
           ,[drools_business_rule_pre_drl_text])
     VALUES
           (80837,'Mix_Template',6,NULL,1,'package com.alight.idis; import com.alight.adapt.datasets.RuleFailureCode; import com.alight.adapt.datasets.RuleFailure; import com.alight.adapt.datasets.election.v1.ElectionDataset; import com.alight.idis.template.rule.helper.RuleHelper; import java.util.ArrayList;   rule "employerAssignedId Length Validation Functions 94045343119153 0" salience 0 when 	$electionDataset : ElectionDataset() 	$ruleHelper : RuleHelper()  	if(94045343119153l > 0 && ( !java.util.Objects.equals($electionDataset.getEmployerAssignedId(), null ) && !java.util.Objects.equals($electionDataset.getEmployerAssignedId(), "" )  && $ruleHelper.isValidLength($electionDataset.getEmployerAssignedId(),50) != true   ) ) break [GOTO_THEN_1] then 	 /** NOTHING TO DO -- DEFAULT CASE */ then [GOTO_THEN_1] 	RuleFailure $ruleFailure = new RuleFailure(); 	if($electionDataset.getRuleFailures() == null){ 		$electionDataset.setRuleFailures(new ArrayList<>()); 	} 	$ruleFailure.setAttributeName("employerAssignedId"); 	$ruleFailure.setError(false); 	$ruleFailure.setErrorDescription("employerAssignedId length validation failed."); 	$ruleFailure.setRuleName("employerAssignedId Length Validation Functions 94045343119153 0"); 	$ruleFailure.setRuleFailureCode(RuleFailureCode.WARNING); 	$electionDataset.getRuleFailures().add($ruleFailure);  end   rule "employerAssignedId Length Validation Functions 94045394910274 -1" salience -1 when 	$electionDataset : ElectionDataset() 	$ruleHelper : RuleHelper()  	if(94045394910274l > 0 && ( $ruleHelper.isValidLength($electionDataset.getEmployerAssignedId(),50) != true  ) ) break [GOTO_THEN_1] then 	 /** NOTHING TO DO -- DEFAULT CASE */ then [GOTO_THEN_1] 	$electionDataset.setEmployerAssignedId($ruleHelper.getLeftValue($electionDataset.getEmployerAssignedId(),50)); end',1,'shipra maheshwari',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF 
END
GO

if not exists (select 1 from master_file_template_attr_br_assoc where mft_attr_br_assoc_id = 401)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attr_br_assoc] ON 
INSERT INTO [dbo].[master_file_template_attr_br_assoc]
           ([mft_attr_br_assoc_id]
		   ,[mftaa_id]
           ,[business_rule_id]
           ,[rule_execution_sequence]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[is_active])
     VALUES
           (401,2118,80837,1,'shipra maheshwari',getDate(),NULL,NULL,1)
SET IDENTITY_INSERT [dbo].[master_file_template_attr_br_assoc] OFF 
END
GO



