USE [idis-metainfo]
GO

/****** Object:  StoredProcedure [dbo].[USP_Inherit_MasterTemplate_Attribute]    Script Date: 2/28/2018 8:19:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Dhaval Thakkar
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2018-12-26	Richa Ashara	ADAPT-307: User should be able to view the Last updated information for PMT/File Templates & Job Schedule
2019-08-27  Divya Jain		ADAPT-7324: Removed is_draft column from drools_business_rules_decision_table and added to_do column in child_file_template_attribute_association.
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/


IF OBJECT_ID('dbo.USP_Inherit_MasterTemplate_Attribute') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Inherit_MasterTemplate_Attribute');
GO

/*
IF OBJECT_ID('dbo.USP_Inherit_MasterTemplate_Attribute') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Inherit_MasterTemplate_Attribute AS SELECT 1')
GO
ALTER PROCEDURE [dbo].[USP_Inherit_MasterTemplate_Attribute]
	-- Add the parameters for the stored procedure here
	@MASTER_FILE_TEMPLATE_ID INT,
	@CHILD_FILE_TEMPLATE_ID INT,
	@MASTER_FILE_TEMPLATE_VERSION INT,
	@CREATED_BY VARCHAR(50)
AS
BEGIN

	DECLARE @MASTER_RECORDID INT;
	DECLARE @CHILD_RECORDID INT

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
	--Update  master_file_template_record_id in CHILD
	update cftmi set cftmi.master_file_template_record_id=mftmi.master_file_template_record_id, updated_by = @CREATED_BY, updated_date_time = getdate()  from child_file_template_meta_info cftmi
	join master_file_template_meta_info mftmi on cftmi.master_file_template_id=mftmi.master_file_template_id
	and cftmi.master_file_template_version=mftmi.master_file_template_version where child_file_template_id=@CHILD_FILE_TEMPLATE_ID
	
	select @MASTER_RECORDID=master_file_template_record_id,@CHILD_RECORDID=child_file_template_record_id from child_file_template_meta_info
	where child_file_template_id=@CHILD_FILE_TEMPLATE_ID

    ----count of ----
	DECLARE @NEW_RECORDS_COUNT INT
	SET @NEW_RECORDS_COUNT = (SELECT count(1) FROM [idis-metainfo].[dbo].[master_file_template_section_assoc] where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID and [master_file_template_version]= @MASTER_FILE_TEMPLATE_VERSION)

	----retriving current identity number-----
	DECLARE @CURRENT_ID INT
	SET @CURRENT_ID = 0
	SET @CURRENT_ID = (SELECT IDENT_CURRENT( 'child_file_template_section_assoc' ) AS A)

	----update the identity number for new records, have a buffer of 5 records to avoid error-----
	DECLARE @NEW_RESEED INT
	SET @NEW_RESEED = @CURRENT_ID+@NEW_RECORDS_COUNT+5
	DBCC CHECKIDENT ('child_file_template_section_assoc', RESEED, @NEW_RESEED)


	DECLARE @NEW_IDENT INT
	SET @NEW_IDENT = @CURRENT_ID + 2;
	
	---------------------------------------------------
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int )

	INSERT INTO #TEMP_OLDNEWKEY
	SELECT  @NEW_IDENT+Row_number() Over(Order by B.mftsa_id) ,B.mftsa_id	
	FROM
		[idis-metainfo].[dbo].[master_file_template_section_assoc] B
    where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID and [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION

	---------------------------------------------------

	SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] ON

	INSERT INTO [dbo].[child_file_template_section_assoc] 
		( [cftsa_id]
		  ,[template_section_id]
		  ,[child_file_template_id]
		  ,[child_file_template_record_id]
		  ,[template_compliant_section_short_name]
		  ,[section_display_name]
		  ,[child_file_template_version]
		  ,[sequence]
		  ,[is_madatory]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time] )
	( SELECT 
		@NEW_IDENT+Row_number() Over(Order by B.mftsa_id) AS [cftsa_id]
		,B.[template_section_id]
		,@CHILD_FILE_TEMPLATE_ID AS [child_file_template_id]
		,@CHILD_RECORDID
		,[template_compliant_section_short_name]
		,[section_display_name]
		,1 AS [child_file_template_version]
		,B.[sequence]
		,B.[is_mandatory]
		,@CREATED_BY
		,GETDATE()
		,@CREATED_BY
		,GETDATE()
	FROM
	[idis-metainfo].[dbo].[master_file_template_section_assoc] B
	where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID AND [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION )
	SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] OFF

	-----------------------------child file attribute association


	----count of ----
	DECLARE @NEW_cftaa_COUNT INT
	SET @NEW_cftaa_COUNT = (SELECT count(1) FROM [idis-metainfo].[dbo].[master_file_template_attribute_association] where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID and [master_file_template_version]= @MASTER_FILE_TEMPLATE_VERSION)

	----retriving current identity number-----
	DECLARE @CURRENT_cftaa_ID INT
	SET @CURRENT_cftaa_ID = 0
	SET @CURRENT_cftaa_ID = (SELECT IDENT_CURRENT( 'child_file_template_attribute_association' ) AS A)

	----update the identity number for new records, have a buffer of 5 records to avoid error-----
	DECLARE @NEW_cftaa_RESEED INT
	SET @NEW_cftaa_RESEED = @CURRENT_cftaa_ID+@NEW_cftaa_COUNT+5
	DBCC CHECKIDENT ('child_file_template_attribute_association', RESEED, @NEW_cftaa_RESEED)


	DECLARE @NEW_cftaa_IDENT INT
	SET @NEW_cftaa_IDENT = @CURRENT_cftaa_ID + 2;

	SET IDENTITY_INSERT [dbo].[child_file_template_attribute_association] ON

	--insert into tmp table in the expected order
	INSERT INTO [child_file_template_attribute_association]
	([cftaa_id],[attribute_row_position],[created_by],[created_date_time],[child_file_template_version],[data_type],[is_mandatory]
	,[attribute_id],[child_file_template_id],[child_file_template_record_id],[cftsa_id],[application_compliant_attribute_name],
	[mftaa_id],[attribute_size],[is_inherited],[to_do])
	SELECT 
		@NEW_cftaa_IDENT+Row_number() Over(Order by A.attribute_row_position) AS [cftaa_id],NULL, @CREATED_BY,GETDATE() AS [created_date_time],
		1 AS [child_file_template_version],A.[data_type],A.[is_mandatory],A.[attribute_id],@CHILD_FILE_TEMPLATE_ID AS [child_file_template_id],@CHILD_RECORDID,
		B.new_id AS [cftsa_id],A.[application_compliant_attribute_name],A.mftaa_id, 
		case when A.max_size_allowed is NULL then AD.[attribute_size] else A.max_size_allowed end,1 as [is_inherited],0
	FROM 
		[idis-metainfo].[dbo].[master_file_template_attribute_association] A
		INNER JOIN #TEMP_OLDNEWKEY B ON A.mftsa_id = B.old_id
		INNER JOIN [idis-metainfo].[dbo].[attribute_dictionary] AD ON A.attribute_id=AD.attribute_id
	WHERE [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID AND [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION

	SET IDENTITY_INSERT [dbo].[child_file_template_attribute_association] OFF


	
				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
				
				if exists(select 1 from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi on mftmi.master_file_template_record_id=mtlsni.master_file_template_record_id
				where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID AND [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION)
				BEGIN

				DECLARE @MTLSNI_COUNT INT
				select @MTLSNI_COUNT= count(1) from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi on mftmi.master_file_template_record_id=mtlsni.master_file_template_record_id
				where [master_file_template_id] = @MASTER_FILE_TEMPLATE_ID AND [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION and mtlsni.is_active=1
									
									DECLARE @NEW_CTLSNI_RESEED INT
									DECLARE @CURRENT_CTLSNI_RESEED INT
									DECLARE @NEW_CTLSNI_INDENT INT
									SET @CURRENT_CTLSNI_RESEED=(SELECT IDENT_CURRENT( 'child_template_layout_schema_node_info' ) AS A)
									
									SET @NEW_CTLSNI_RESEED =@CURRENT_CTLSNI_RESEED+@MTLSNI_COUNT+5
									DBCC CHECKIDENT ('child_template_layout_schema_node_info', RESEED, @NEW_CTLSNI_RESEED)
									SET @NEW_CTLSNI_INDENT=@CURRENT_CTLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_CTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_CTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_CTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_CTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_CTLSNI_INDENT+Row_number() Over(Order by mtlsni_id),mtlsni_id
									from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi 
									on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id where 
									mftmi.master_file_template_id= @MASTER_FILE_TEMPLATE_ID AND [master_file_template_version] = @MASTER_FILE_TEMPLATE_VERSION
									and mtlsni.is_active=1)

									SET IDENTITY_INSERT [dbo].[child_template_layout_schema_node_info] ON 
									INSERT INTO [dbo].[child_template_layout_schema_node_info]([ctlsni_id],[mtlsni_id],[child_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time], [updated_by], [updated_date_time]
									,[node_max_size],[node_min_size])
									SELECT new_id,old_id,@CHILD_RECORDID,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@CREATED_BY,getDate(), @CREATED_BY,getDate()
									,[node_max_size],[node_min_size]
									FROM master_template_layout_schema_node_info mtlsni join #TEMP_CTLSNI_OLDNEWKEY on mtlsni.mtlsni_id=old_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION
									and mtlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[child_template_layout_schema_node_info] OFF

									INSERT INTO [dbo].[child_template_layout_schema_node_assoc]([ctlsni_id],[parent_ctlsni_id],[node_has_children],[created_by],[created_date_time], [updated_by], [updated_date_time])
									SELECT a.new_id,
									case when parent_mtlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@CREATED_BY,getDate(),@CREATED_BY,getDate() from [master_template_layout_schema_node_assoc] mtlsna
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsna.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY a on mtlsna.mtlsni_id=a.old_id left outer join #TEMP_CTLSNI_OLDNEWKEY b on mtlsna.parent_mtlsni_id=b.old_id
									where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION
									and mtlsni.is_active=1
									
									INSERT INTO [dbo].[ctls_node_enum_value_assoc]([ctlsni_id],[enum_value],[enum_value_description],[mtaeva_id],[is_active],[created_by],[created_date_time], [updated_by], [updated_date_time])
									SELECT new_id,enum_value,enum_value_description,old_id,0,@CREATED_BY,getDate(), @CREATED_BY,getDate() from mtls_node_enum_value_assoc mtlsnea 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnea.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY on mtlsnea.mtlsni_id=old_id where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID 
									AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION and mtlsni.is_active=1  and mtlsnea.is_active=1 
									
									
									INSERT INTO [dbo].[ctls_node_dm_element_assoc]([ctlsni_id],[cftaa_id],[is_active],[created_by],[created_date_time], [updated_by], [updated_date_time])
									SELECT a.new_id,cftaa.cftaa_id,case when ftmi.direction='Inbound' then 1 else 0 end
									,@CREATED_BY,getDate(),@CREATED_BY,getDate() from mtls_node_dm_element_assoc mtlsnda 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnda.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id 
									join child_file_template_attribute_association cftaa on cftaa.mftaa_id=mtlsnda.mftaa_id
									join file_type_meta_info ftmi on ftmi.file_type_id=mftmi.file_type_id
									join #TEMP_CTLSNI_OLDNEWKEY a on mtlsnda.mtlsni_id=a.old_id where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID
									AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION and mtlsni.is_active=1 and mtlsnda.is_active=1 
									AND cftaa.child_file_template_record_id=@CHILD_RECORDID     
									

									DECLARE @RULES_COUNT INT
									SET @RULES_COUNT = (select count(1) from mtls_node_br_assoc mtlsnba
									join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION 
									and mtlsni.is_active=1)

									if @RULES_COUNT>0
									BEGIN

									DECLARE @NEW_DBRDT_RESEED INT
									DECLARE @CURRENT_DBRDT_RESEED INT
									DECLARE @NEW_DBRDT_INDENT INT
									SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
									SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
									DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
									SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2

									INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version)
									(select @NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id),drools_business_rule_id,1 from
									(select drools_business_rule_id,drools_business_rule_version from mtls_node_br_assoc mtlsnba
									join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION and 
									mtlsni.is_active=1
									) a)

									SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
									insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
									drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
									drools_business_rule_ui_json_text,created_by,created_date)
									(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
									rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
									drools_business_rule_ui_json_text,@CREATED_BY,getDate() from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY
									on drools_business_rule_id=old_id)
									SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

									INSERT INTO [dbo].[mtls_node_br_assoc]([mtlsni_id],[business_rule_id],[rule_execution_sequence],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,1,@CREATED_BY,getDate(),@CREATED_BY,getDate() from mtls_node_br_assoc mtlsnba 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									join #TEMP_DBRDT_OLDNEWKEY b on mtlsnba.business_rule_id=b.old_id
									join #TEMP_CTLSNI_OLDNEWKEY a on mtlsnba.mtlsni_id=a.old_id where mftmi.master_file_template_id=@MASTER_FILE_TEMPLATE_ID 
									AND mftmi.master_file_template_version = @MASTER_FILE_TEMPLATE_VERSION and mtlsni.is_active=1  and mtlsnba.is_active=1  
									
									END;
					END;				


END



GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Inherit_MasterTemplate_Attribute TO exec_proc
GO
*/
