-- USP_Create_Flat_Schema_Inbound_PMT
use [idis-metainfo]
GO

/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
14-03-2019  Richa Ashara		ADAPT-2719 : Populate inbound schema for new/edited PMT's
12-08-2019	Jinesh vora			ADAPT-6906 : Clone records should be at the PMT level, not just the file level	
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/

IF OBJECT_ID('dbo.USP_Create_Flat_Schema_Inbound_PMT') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Create_Flat_Schema_Inbound_PMT');
GO

/*
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Create_Flat_Schema_Inbound_PMT') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Create_Flat_Schema_Inbound_PMT AS SELECT 1')
GO



ALTER Procedure [dbo].[USP_Create_Flat_Schema_Inbound_PMT]
	(
		@ipmt_record_id INT,
		@oError_code INT OUT
	) 
AS

BEGIN

SET NOCOUNT ON; 

declare @cftsa_id int;
declare @parent_ctlsni_id int;
declare @template_id int;
declare @created_by varchar(50);
declare @created_date_time datetime;

if EXISTS(SELECT 1 FROM child_template_layout_schema_node_info WHERE child_file_template_record_id = @ipmt_record_id)
	BEGIN
		 BEGIN TRANSACTION T1;
		 BEGIN TRY
			 DELETE FROM ctls_node_dm_element_assoc Where ctlsni_id in (SELECT ctlsni_id FROM child_template_layout_schema_node_info WHERE child_file_template_record_id = @ipmt_record_id)
			 DELETE FROM child_template_layout_schema_node_assoc Where ctlsni_id in (SELECT ctlsni_id FROM child_template_layout_schema_node_info WHERE child_file_template_record_id = @ipmt_record_id)
			 DELETE FROM child_template_layout_schema_node_info WHERE child_file_template_record_id = @ipmt_record_id
			 COMMIT TRANSACTION T1;
			 SET @oError_code = 0;
			 print 'Existing PMT data deleted successfully from flat schema...'
		 END TRY
		 BEGIN CATCH
			ROLLBACK TRANSACTION T1;
			SET @oError_code = -1;
			print 'Error while deleting existing PMT data from flat schema...'
		END CATCH 
	END;

	BEGIN TRANSACTION T2
	BEGIN TRY 

	DECLARE cur CURSOR LOCAL FOR SELECT [cftsa_id],[template_section_id] FROM [dbo].[child_file_template_section_assoc] where 
	[child_file_template_record_id]=@ipmt_record_id order by sequence asc;

	declare @rowPosition int=1;
			OPEN cur;

			FETCH NEXT FROM cur INTO @cftsa_id,@template_id;
			WHILE @@FETCH_STATUS = 0
				BEGIN
				
					INSERT INTO [dbo].[child_template_layout_schema_node_info] ([child_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
					[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
					[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],
					[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num])						
					(select @ipmt_record_id,'Section',case when section_display_name is null then ts.section_name else section_display_name end,1,1,1
					,@rowPosition,@rowPosition,NULL,1,NULL,section_name,@template_id,
					template_compliant_section_short_name,1,cftsa.created_by,cftsa.created_date_time,cftsa.sequence,NULL,NULL,0
					from child_file_template_section_assoc cftsa
					join template_sections ts on cftsa.template_section_id=ts.template_section_id where cftsa_id=@cftsa_id)

					select @parent_ctlsni_id=ctlsni_id,@created_by=created_by,@created_date_time=created_date_time
					from child_template_layout_schema_node_info where child_file_template_record_id=@ipmt_record_id and
					mapped_template_section_id=@template_id

					declare @attrFlag bit=0;
					select top 1 @attrFlag=1 from child_file_template_attribute_association where cftsa_id=@cftsa_id 

					INSERT INTO [dbo].[child_template_layout_schema_node_assoc] ([ctlsni_id],[parent_ctlsni_id],[node_has_children],[created_by],[created_date_time]) 
					values(@parent_ctlsni_id,NULL,@attrFlag,@created_by,@created_date_time)

					if exists(select 1 from child_file_template_attribute_association where cftsa_id=@cftsa_id )
					begin
					--print 'exists'
					--end

					declare @cftaa_id int;
					declare @attribute_name varchar(max);
					declare @ctlsni_id int;
					DECLARE @clone_num INT;
					DECLARE attrCur CURSOR LOCAL FOR SELECT [cftaa_id],
					case when application_compliant_attribute_name is not null then application_compliant_attribute_name else attribute_name end,
					cftaa.clone_num
					FROM [dbo].[child_file_template_attribute_association] cftaa join attribute_dictionary ad on cftaa.attribute_id=ad.attribute_id where 
					[child_file_template_record_id]=@ipmt_record_id and cftsa_id=@cftsa_id
					order by attribute_row_position asc;
					OPEN attrCur;

						FETCH NEXT FROM attrCur INTO @cftaa_id,@attribute_name,@clone_num;
						WHILE @@FETCH_STATUS = 0
							BEGIN
						
							INSERT INTO [dbo].[child_template_layout_schema_node_info] ([child_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
							[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
							[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[node_max_size],
							[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num])						-- ADAPT : 6906  -- ADDED 
							(select  @ipmt_record_id,'Element',
							case when application_compliant_attribute_name is null then @attribute_name else application_compliant_attribute_name end,
							adt.attribute_data_type_id,1,1,@rowPosition,@rowPosition,NULL,cftaa.is_mandatory,NULL,'Data Element And/Or Enumerated Values',
							NULL,cftsa.template_compliant_section_short_name,1,cftaa.created_by,cftaa.created_date_time,cftaa.attribute_size,
							cftaa.attribute_row_position,cftaa.attribute_start_position,cftaa.attribute_end_position,cftaa.clone_num			-- ADAPT : 6906  -- ADDED 
							from [child_file_template_attribute_association] cftaa join attribute_dictionary ad on ad.attribute_id=cftaa.attribute_id
							join child_file_template_section_assoc cftsa on cftaa.cftsa_id=cftsa.cftsa_id
							left join attribute_data_types adt on adt.attribute_data_type_name=cftaa.data_type
							where cftaa_id=@cftaa_id)

							select @ctlsni_id=ctlsni_id,@created_by=created_by,@created_date_time=created_date_time 
							from child_template_layout_schema_node_info where child_file_template_record_id=@ipmt_record_id and
							node_display_name=@attribute_name and node_row_position=@rowPosition and node_clone_num = @clone_num						-- ADAPT : 6906  -- ADDED 
					
							INSERT INTO [dbo].[child_template_layout_schema_node_assoc] ([ctlsni_id],[parent_ctlsni_id],[node_has_children],[created_by],[created_date_time]) 
							values(@ctlsni_id,@parent_ctlsni_id,0,@created_by,@created_date_time)

							INSERT INTO [dbo].[ctls_node_dm_element_assoc]([ctlsni_id],[cftaa_id],[is_active],[created_by],[created_date_time]) 
							select @ctlsni_id,@cftaa_id,1,@created_by,@created_date_time from [child_file_template_attribute_association]
							where cftaa_id=@cftaa_id

	--						select * from [child_file_template_attribute_association] where cftaa_id=@cftaa_id

							FETCH NEXT FROM attrCur INTO @cftaa_id,@attribute_name,@clone_num;
							END
						CLOSE attrCur 
						DEALLOCATE attrCur  
					END
					FETCH NEXT FROM cur INTO @cftsa_id,@template_id;
					select @rowPosition=@rowPosition+1;
				END
			CLOSE cur    
			DEALLOCATE cur
			COMMIT TRANSACTION T2;
			SET @oError_code = 0;
			print 'PMT inserted successfully into flat schema...'
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION T2;
			SET @oError_code = -2;
			print 'Error while inserting PMT data to flat schema...'
		END CATCH 

END;
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 


GRANT EXECUTE ON dbo.USP_Create_Flat_Schema_Inbound_PMT TO exec_proc
GO

*/
