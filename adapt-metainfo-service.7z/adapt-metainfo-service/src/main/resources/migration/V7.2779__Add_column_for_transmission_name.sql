/*
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-06-28	Jinesh vora		ADAPT-2779: User should be able to configure transmission name inside the Transmission Tab-File Setup.
*/

-- check if the column is already exists in table:
use [idis-metainfo]

-- Add path column
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_transmission_info' and column_name ='path' 
)
BEGIN
ALTER TABLE file_transmission_info Add path varchar(500) null;
END;

-- Add set_as_default column
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_transmission_info' and column_name ='set_as_default' 
)
BEGIN
ALTER TABLE file_transmission_info Add set_as_default bit not null constraint DF_fti_set_as_default default (0);
END;

-- Add constraint for set_as_default column
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_fti_set_as_default]') AND type = 'D')
BEGIN
ALTER TABLE file_transmission_info add constraint DF_fti_set_as_default default 0 for set_as_default;
END;

--add column transmission_name
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_transmission_info' and column_name ='transmission_name'
)
BEGIN
ALTER TABLE file_transmission_info Add transmission_name varchar(80) null;
END;
GO

if exists(select 1 from file_transmission_info where transmission_name is null)
begin
--Migration script for job_transmission_connection_id
update fti set fti.transmission_name= fmi.file_transmission_name from file_transmission_info fti 
join file_meta_info fmi on fmi.record_id=fti.file_identifier where fmi.file_transmission_name is not null
END;
GO

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_transmission_info' and column_name ='transmission_name' and is_nullable='YES'
)
BEGIN
ALTER TABLE file_transmission_info alter column transmission_name varchar(80) not null;
END;
GO


IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='file_transmission_name'
)
BEGIN
ALTER TABLE file_meta_info drop column file_transmission_name ;
END;
GO

--Add Unique constraint for trading_partner_id, tpci_username, tpci_adapt_env_id
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[UK_tpci_tpid_username_envid]'))
BEGIN
Alter TABLE trading_partner_connection_info
ADD Constraint UK_tpci_tpid_username_envid Unique (trading_partner_id, tpci_username, tpci_adapt_env_id);
END;

GO

--Add tooltip field
if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 271)
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_web_page_fields] ON 
INSERT [dbo].[adapt_web_page_fields]([adapt_web_page_field_id], [adapt_web_page_id] , [adapt_web_page_field_name], [adapt_web_page_field_desc], [is_active], [created_by], [updated_by], [created_date_time], [updated_date_time]) VALUES (271, 27, N'Transmission Name', N'Transmission Name', 1, N'RS',NULL, CAST(N'2019-06-27 07:01:54.870' AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[adapt_web_page_fields] OFF
END;
GO 

-- Add column for current env
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='adapt_env_config_info' and column_name ='is_current_env')
BEGIN
ALTER TABLE adapt_env_config_info ADD is_current_env bit not null constraint DF_adapt_env_config_info_current DEFAULT(0);
END
GO


--Add column job_transmission_connection_id
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='job_details' and column_name ='job_transmission_connection_id')
BEGIN
ALTER TABLE job_details ADD job_transmission_connection_id int null
END;
GO

BEGIN
--Migration script for job_transmission_connection_id
update jd set jd.job_transmission_connection_id= ti.file_tranmission_connection_id from job_details jd join (
select file_identifier,max(file_transmission_connection_id) as file_tranmission_connection_id from file_transmission_info fti
join adapt_env_config_info aeci on aeci.adapt_env_id=fti.adapt_env_id and aeci.is_current_env=1 where fti.is_active=1
group by file_identifier) ti on jd.file_identifier=ti.file_identifier

END
GO

--Add FK to job_transmission_connection_id
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_job_details_K32_fti_K11'
			AND c.parent_object_id = OBJECT_ID('dbo.job_details')
	)
BEGIN
ALTER TABLE [dbo].[job_details]  WITH NOCHECK ADD CONSTRAINT [FK_job_details_K32_fti_K11] FOREIGN KEY([job_transmission_connection_id])
REFERENCES [dbo].[file_transmission_info] ([file_transmission_connection_id])
END;
GO


