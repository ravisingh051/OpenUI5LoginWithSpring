use [idis-metainfo]
GO

/*
Filename:  V10.7065__update_processing_system_events_for_Job Failed_event.sql

Update Log
Date         Author            	Description
----------   ----------------   --------------------------------------------------------------------------------------------
2019-08-01   Jinesh Vora  		ADAPT-7065 : User should receive notification when Job Failed 
*/

if EXISTS (SELECT 1 FROM processing_system_events where event_id=3 and event_name = 'File Unsuccessful')
BEGIN
Update processing_system_events  SET event_name = 'JOB_FAILED',event_description = 'Job Failed',updated_by = 'Jinesh vora',updated_date_time = getdate() where event_id = 3 and event_name='File Unsuccessful';
END;
GO
