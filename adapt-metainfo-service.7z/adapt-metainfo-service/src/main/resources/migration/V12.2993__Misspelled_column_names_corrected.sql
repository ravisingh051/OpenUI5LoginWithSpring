USE [idis-metainfo]

/*
--Update Log
--Date        	Author          Description
------------  	------------    -------------------------------------------------------------------------------------------
--2019-09-12	Snehal Patel	ADAPT-2993 : Column names in tables - Characters are missing - misspelled - Example foreign key - DB - High - Beyond Phase 2

-- Table Used 
-- file_section_association
-- master_file_template_section_assoc
-- drools_business_rule_template
-- drools_business_rules_decision_table

*/

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_section_association' and column_name ='is_madatory' 
)
BEGIN
EXEC sp_RENAME 'file_section_association.is_madatory', 'is_mandatory' , 'COLUMN'
END;

GO

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='master_file_template_section_assoc' and column_name ='is_madatory' 
)
BEGIN
EXEC sp_RENAME 'master_file_template_section_assoc.is_madatory', 'is_mandatory' , 'COLUMN'
END;

GO

IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='drools_business_rule_template' and column_name ='drools_business_rule_tempalte_content' 
)
BEGIN
EXEC sp_RENAME 'drools_business_rule_template.drools_business_rule_tempalte_content', 'drools_business_rule_template_content' , 'COLUMN'
END;

GO

IF EXISTS (SELECT 1 FROM drools_business_rules_decision_table WHERE CHARINDEX('droolsBusinessRuleTempalteContent',drools_business_rule_ui_json_text) > 0
)
BEGIN
UPDATE drools_business_rules_decision_table
SET drools_business_rule_ui_json_text = CAST(REPLACE(CAST(drools_business_rule_ui_json_text as NVarchar(MAX)),'droolsBusinessRuleTempalteContent','droolsBusinessRuleTemplateContent') AS NText)
WHERE drools_business_rule_ui_json_text IS NOT NULL;
END;

GO
