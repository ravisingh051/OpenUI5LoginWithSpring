use [idis-metainfo]
GO

/*
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-06-28	Jinesh vora		ADAPT-6915:  User can add transmission name with same connection username.
*/

--Add Unique constraint for file_identifier, adapt_env_id, trading_partner_connection_id
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[UK_file_transmission_info_K2_K3_K4]'))
BEGIN
Alter TABLE file_transmission_info
ADD Constraint UK_file_transmission_info_K2_K3_K4 Unique (file_identifier, adapt_env_id, trading_partner_connection_id);
END;
GO
