USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[Proc_USP_Child_File_Template_Deletion]    Script Date: 09/14/2018 11:00:00 AM ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
/*
-- Author:		Richa Ashara
-- Create date:	09/14/2018
-- Description:	Delete child template with given version

Update Log 
07-08-2019	Jinesh vora		ADAPT-6906 : child_file_template_record_id
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/


IF OBJECT_ID('dbo.USP_Child_File_Template_Deletion') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Child_File_Template_Deletion');
GO

-- =============================================

/*
IF OBJECT_ID('dbo.USP_Child_File_Template_Deletion') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Child_File_Template_Deletion AS SELECT 1')
GO

-- Added this as part of PMT

ALTER PROCEDURE USP_Child_File_Template_Deletion AS SELECT 1;

-- Added Upto here


-- Put This into Comments As Part of PMT Removal

--ALTER PROCEDURE [dbo].[USP_Child_File_Template_Deletion]
--	-- Add the parameters for the stored procedure here
--   @iChildTemplate_id int,
--   @iChildTemplate_version int
--AS
--BEGIN

--    DECLARE @file_type_id int;
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;

	
--    SELECT @file_type_id=[file_type_id] from [dbo].[child_file_template_meta_info] cftmi join [dbo].[master_file_template_meta_info] mftmi
--    on cftmi.master_file_template_id=mftmi.master_file_template_id and cftmi.master_file_template_version=mftmi.master_file_template_version 
--    where [child_file_template_id]=@iChildTemplate_id and [child_file_template_version]=@iChildTemplate_version

--    DELETE FROM [dbo].[lookup_table_file_association]  where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_version)

--    DELETE FROM [dbo].[lookup_table_composite_key_mapping]  where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_version)

--    DELETE FROM [dbo].[lookup_table_details] where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_version)

--    DELETE  from [dbo].[lookup_table_meta_info] where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_version

--    select br.business_rule_id,br.cftaa_id into #rules FROM [dbo].[child_file_template_attr_br_assoc] br join [child_file_template_attribute_association] attr on br.cftaa_id=attr.cftaa_id where [child_file_template_id]=@iChildTemplate_id and child_file_template_version=@iChildTemplate_version
 
--    DELETE  FROM [dbo].[child_file_template_attr_br_assoc] where cftaa_id in(select cftaa_id FROM #rules)
	
--	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #rules)
	
--	select ctlsni.ctlsni_id into #nodes from child_template_layout_schema_node_info ctlsni join child_file_template_meta_info cftmi on cftmi.child_file_template_record_id=ctlsni.child_file_template_record_id
--				where [child_file_template_id] = @iChildTemplate_id AND [child_file_template_version] = @iChildTemplate_version
	
--	select business_rule_id  into #node_rules from ctls_node_br_assoc where ctlsni_id in (select ctlsni_id from #nodes)
	
--	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #node_rules)
	
--	DELETE FROM ctls_node_br_assoc where ctlsni_id in (select ctlsni_id from #nodes)
	
--	DELETE FROM ctls_node_dm_element_assoc where ctlsni_id in (select ctlsni_id from #nodes)
	
--	DELETE FROM ctls_node_enum_value_assoc where ctlsni_id in (select ctlsni_id from #nodes)
	
--	DELETE FROM child_template_layout_schema_node_assoc where ctlsni_id in (select ctlsni_id from #nodes)
	
--	DELETE FROM child_template_layout_schema_node_info where ctlsni_id in (select ctlsni_id from #nodes)
	
--	select cftsamba.business_rule_id  into #node_sp_rules from cft_special_mapping_attr_br_assoc cftsamba join child_file_template_meta_info cftmi on cftmi.child_file_template_record_id=cftsamba.child_file_template_record_id
--	where [child_file_template_id] = @iChildTemplate_id AND [child_file_template_version] = @iChildTemplate_version
	
--	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #node_sp_rules)
	
--	DELETE  FROM [cft_special_mapping_attr_br_assoc]  where business_rule_id in (select business_rule_id FROM #node_sp_rules)
	
--	DELETE FROM [dbo].child_secondary_mapping_attr_assoc where csmaa_child_file_template_record_id=
--		(select child_file_template_record_id from [dbo].[child_file_template_meta_info] WHERE child_file_template_id = @iChildTemplate_id and child_file_template_version = @iChildTemplate_version)
	
--    -- ADAPT-6906
--	DELETE FROM [child_file_template_clone_info] where child_file_template_record_id in (SELECT child_file_template_record_id FROM [child_file_template_meta_info] 
--	WHERE child_file_template_id = @iChildTemplate_id and child_file_template_version = @iChildTemplate_version)
--	-- ADAPT-6906
	
--	DELETE FROM [dbo].[child_file_template_attribute_association] where [child_file_template_id]=@iChildTemplate_id and child_file_template_version=@iChildTemplate_version

--    DELETE FROM [dbo].[child_file_template_section_assoc] where [child_file_template_id]=@iChildTemplate_id and child_file_template_version=@iChildTemplate_version
	
--    DELETE FROM [dbo].[child_file_template_meta_info] WHERE child_file_template_id = @iChildTemplate_id and child_file_template_version = @iChildTemplate_version

--END
--GO


-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.[USP_Child_File_Template_Deletion] TO exec_proc
GO

GO
*/
