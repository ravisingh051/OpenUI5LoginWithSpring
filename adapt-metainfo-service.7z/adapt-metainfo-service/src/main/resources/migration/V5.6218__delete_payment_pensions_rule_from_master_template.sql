USE [idis-metainfo];
GO

/*
Filename:  V5.6218__delete_payment_pensions_rule_from_master_template.sql

Update Log

Date			Author					Description
----------	 ------------		-------------------------------------------------------------------------------------------
2019-06-03	 Richa Ashara		ADAPT-6218 : Inbound Pension Payments Master Template - Remove Validation
2019-06-04	 Nilesh Jariya		ADAPT-6218 : Inbound Pension Payments Valid Values - Inactive valid values Master Association 
*/

IF EXISTS(select 1 from drools_business_rules_decision_table   where  drools_business_rule_id = 749)
BEGIN
	IF EXISTS(select * from master_file_template_attr_br_assoc   where   business_rule_id = 749)
	BEGIN
		delete from master_file_template_attr_br_assoc   where    business_rule_id = 749
	END;
	delete  from drools_business_rules_decision_table   where  drools_business_rule_id = 749
END;

IF EXISTS(select 1 from mftaa_valid_value_assoc where mftaa_valid_value_assoc_id in (482,483)  and is_active = 1)
BEGIN
	update mftaa_valid_value_assoc set is_active = 0 where mftaa_valid_value_assoc_id in (482,483) and is_active = 1;
END;

GO
