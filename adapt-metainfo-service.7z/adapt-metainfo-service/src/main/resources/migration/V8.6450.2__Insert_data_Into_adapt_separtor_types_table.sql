/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-10   Divya Jain			ADAPT-6450 : User should be able to configure  delimiter/terminator for the Outbound File
*/


if not exists (select 1 from adapt_separtor_types where adapt_sep_type_id =7)
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] ON 
INSERT INTO [dbo].[adapt_separtor_types] (adapt_sep_type_id,adapt_sep_type_name,adapt_sep_type_is_active,created_date_time,created_by,updated_by,updated_date_time)
values (7,N'$',1,getdate(),N'Divya Jain',NULL,NULL);
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] OFF 
END
GO
