use [idis-metainfo]
GO

/*
Filename:  V2.3635__data_population_for_idis_dbrd_func_actions.sql

Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-06-10   Bhaumik Sathvara		ADAPT-3635 : User should be able to view prescripted Master & PMT OUTBOUND , so that Voya file can be created
*/

if exists (select 1 from extraction_parameters where ep_standardized_name in ('coverageStartDate', 'coverageEndDate'))
BEGIN
delete from extraction_parameters where ep_standardized_name in ('coverageStartDate', 'coverageEndDate')
END;
GO