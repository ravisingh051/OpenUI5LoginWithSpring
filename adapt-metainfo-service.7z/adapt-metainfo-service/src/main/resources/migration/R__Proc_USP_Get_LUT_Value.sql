USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_LUT_Value') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_LUT_Value AS SELECT 1')
GO

--- Updated on 2018-06-19: CC-35044: Store procedure and valid value related changes

ALTER Procedure [dbo].[USP_Get_LUT_Value]
	(
               @i_file_identifier int
       )
AS
BEGIN

SET NOCOUNT ON;

select
LTMI.lookup_table_id,
LTMI.lookup_table_version,
LTD.lookup_key,
LTD.lookup_value,
LTMI.lookup_table_name 
from lookup_table_meta_info LTMI
INNER JOIN lookup_table_details LTD ON LTMI.lookup_table_id=LTD.lookup_table_id AND LTMI.lookup_table_version=LTD.lookup_table_version
where LTMI.associated_file_level_id=@i_file_identifier and LTMI.associated_file_level = 'F'

END 

GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_LUT_Value TO exec_proc
GO

