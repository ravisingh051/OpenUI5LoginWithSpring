USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Dynamic_Schema_Attribute') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Dynamic_Schema_Attribute AS SELECT 1')
GO

--- Updated on 2018-06-19: CC-35044: Store procedure and valid value related changes
-- Updated on 2019-08-02 : ADAPT-6580 
-- Updated on 2019-08-21 : ADAPT-7283
-- Updated on 2019-10-15 : ADAPT-7998: Remove enumerated values and print display name

ALTER Procedure [dbo].[USP_Get_Dynamic_Schema_Attribute](@i_file_identifier int,@i_node_section_short_name varchar(20) = null)
AS
BEGIN

SET NOCOUNT ON;

	
if (@i_node_section_short_name IS NULL OR @i_node_section_short_name  = '')
	BEGIN
		SELECT @i_node_section_short_name  = COALESCE(@i_node_section_short_name,'') +''''+a.node_section_short_name +''''+ ',' 
		  from (SELECT distinct node_section_short_name from file_layout_schema_node_info) a;
		SET @i_node_section_short_name = substring(@i_node_section_short_name,1,len(@i_node_section_short_name)-1)
		print ' -- section short name == ' + @i_node_section_short_name
	END
	ELSE
	BEGIN
		SET @i_node_section_short_name = '''' + @i_node_section_short_name + '''' 
	END;

	print '@i_file_identifier : :: ' + CAST (@i_file_identifier as varchar)
	--select @i_node_section_short_name

	declare @query varchar(max) = 'select 
	cast(ni.node_row_position as varchar) as noderowposition, 
	ni.flsni_id as id, 
	ni.node_ref_num as referenceId, 
	ni.node_category as category, 
	attribute_data_type_name as dataType, 
	case
	when attribute_data_type_name = ''VARCHAR'' then ''java.lang.String''
	when (attribute_data_type_name = ''INTEGER'' OR attribute_data_type_name = ''NUMBER'') then ''java.lang.Integer''
	when (attribute_data_type_name = ''DATE'') then ''java.util.Date'' 
	when attribute_data_type_name = ''DOUBLE'' then ''java.lang.Double'' 
	when attribute_data_type_name = ''BIT'' then ''java.lang.Boolean''
	when attribute_data_type_name = ''NODE'' then ''java.lang.Object''
	when (attribute_data_type_name = ''DATETIME'' OR attribute_data_type_name = ''TIME'') then ''java.util.Date''
	else attribute_data_type_name end
	as defaultDatatype,
	ni.node_display_name as displayName, 
	na.parent_flsni_id as parentId, 
	ni.node_description as description, 
	ni.node_is_mandatory as mandatory, 
	fileTypeaa.standardized_name as standardizedName, 
	node_min_count as minOccurrence, 
	case when node_max_count is NULL then ''-1'' else cast(node_max_count as varchar) end as maxOccurrence, 
	mftsa.section_standardized_name as mappedColumnName, 
	fndi.node_delimiter as nodeDelimiter, 
	fndi.node_terminator as nodeTerminator,
	ad.attribute_size as nodeSize,
	ni.mapped_column_start_position as nodeColumnStartPosition,
	ni.mapped_column_end_position as nodeColumnEndPosition,
	ni.mapped_column_order  as columnOrder,
	case
	when ni.node_section_short_name =''H'' then ''HEADER''
	when ni.node_section_short_name =''D'' then ''DETAIL''
	when ni.node_section_short_name =''T'' then ''TRAILER''
	else ni.node_section_short_name end
	as sectionType
	from 
	file_layout_schema_node_info ni 
	join file_layout_schema_node_assoc na on ni.flsni_id = na.flsni_id 
	join attribute_data_types adt on adt.attribute_data_type_id = ni.node_data_type_id 
	left join fls_node_dm_element_assoc fd on fd.flsni_id = ni.flsni_id and fd.is_active = 1 
	left join file_attribute_association ftaa on fd.faa_id = ftaa.faa_id 
	left join attribute_dictionary ad on ftaa.attribute_id = ad.attribute_id 
	join file_meta_info fmi on fmi.record_id = ni.file_identifier 
	join file_type_meta_info ftmi on fmi.file_type_id = ftmi.file_type_id 
	left join file_type_attribute_association fileTypeaa on ftmi.file_type_id = fileTypeaa.file_type_id and ad.attribute_id = fileTypeaa.attribute_id  
	left join template_sections ts on template_section_id = ni.mapped_template_section_id 
	left join master_file_template_section_assoc mftsa on mftsa.template_section_id = ts.template_section_id and mftsa.master_file_template_record_id = fmi.master_file_template_record_id 
		and mftsa.template_compliant_section_short_name in (' + @i_node_section_short_name + ')
	left join fls_node_delimiter_info fndi on fndi.file_identifier = ni.file_identifier AND fndi.node_name = ni.node_category 
	AND fndi.is_active = 1 
	where   
       ni.is_active=1 and
	ni.file_identifier = ' + CAST (@i_file_identifier as varchar) +
	' and ISNULL(ni.node_clone_num,0)=0 and ni.node_section_short_name in ( ' + @i_node_section_short_name + ')'+
	case when (select data_source_target_type_name from file_meta_info fmi join data_source_target_type dstt on fmi.data_source_type_id=dstt.data_source_target_type_id where record_id=@i_file_identifier) like 'File%'
	and (select data_source_target_type_name from file_meta_info fmi join data_source_target_type dstt on fmi.data_target_type_id=dstt.data_source_target_type_id where record_id=@i_file_identifier) like 'API%'
	then ' and  ni.node_category=''Element'' ' else '' end
	+
	case when (select data_source_target_type_name from file_meta_info fmi join data_source_target_type dstt on fmi.data_source_type_id=dstt.data_source_target_type_id where record_id=@i_file_identifier) like 'File%'
	and (select data_source_target_type_name from file_meta_info fmi join data_source_target_type dstt on fmi.data_target_type_id=dstt.data_source_target_type_id where record_id=@i_file_identifier) like 'API%'
	then ' order by sectionType,columnOrder ' else '	order by ni.node_row_position asc' end
	   

	print @query

	exec (@query) 



END
GO


-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Dynamic_Schema_Attribute TO exec_proc
GO

