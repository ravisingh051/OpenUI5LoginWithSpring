USE [idis-metainfo]
GO

/****** Object: StoredProcedure [dbo].[USP_Get_Master_Validations]  ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Get_Master_Validations') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Master_Validations AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_Master_Validations]
(
@i_master_file_template_id int,
@i_master_file_template_version int
)
AS
BEGIN
SET NOCOUNT ON;

declare @masterFileTemplateId int;
declare @masterFileTemplateVersion int;
set @masterFileTemplateId=@i_master_file_template_id;
set @masterFileTemplateVersion=@i_master_file_template_version;

select
ftaa.standardized_name,
mftaa.data_type,
ad.attribute_size,
mftaa.is_mandatory,
vt.validation_type_name,
vv.valid_value_standardized_name
from master_file_template_attribute_association mftaa 
INNER JOIN attribute_dictionary ad ON ad.attribute_id = mftaa.attribute_id
INNER JOIN master_file_template_meta_info mftmi on mftmi.master_file_template_id=mftaa.master_file_template_id and mftmi.master_file_template_version=mftaa.master_file_template_version
INNER JOIN file_type_attribute_association ftaa on ftaa.file_type_id=mftmi.file_type_id and ad.attribute_id=ftaa.attribute_id
join mftaa_valid_value_assoc mfvv ON mftaa.mftaa_id=mfvv.mftaa_id
join valid_values vv ON mfvv.valid_value_id = vv.valid_value_id
join valid_value_groups vvg ON vv.valid_value_group_id = vvg.valid_value_group_id
join validation_types vt ON vvg.validation_type_id = vt.validation_type_id
where mftaa.master_file_template_id = @masterFileTemplateId and mftaa.master_file_template_version = @masterFileTemplateVersion 
and vvg.is_active=1 and vv.is_active=1 and mfvv.is_active=1
order by mftaa.attribute_row_position asc, validation_type_name asc

END 
Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Master_Validations TO exec_proc
GO
