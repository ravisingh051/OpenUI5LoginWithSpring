use [idis-metainfo]
GO

/*
Filename:  V11.7313__code-corrections-for-transmission-feedback.sql

Update Log
Date         Author            	Description
----------   ----------------   --------------------------------------------------------------------------------------------
2019-09-10   Mayur Tanna  		ADAPT-7313 : code-corrections-for-transmission-feedback
*/

if EXISTS (SELECT 1 FROM processing_system_events where event_id=2 and event_name = 'DATASET_DELIVERED')
BEGIN
Update processing_system_events  SET event_name = 'FILE_TRANSFER_OCCURRED_EVENT',event_description = 'File Transfer Occurred',updated_by = 'Mayur Tanna',updated_date_time = getdate() where event_id = 2 and event_name='DATASET_DELIVERED';
END;
GO


if EXISTS (SELECT 1 FROM processing_system_events where event_id=14 and event_name = 'DATASET_DELIVERY_FAILED')
BEGIN
Update processing_system_events  SET event_name = 'FILE_TRANSFER_FAILED_EVENT',event_description = 'File Transfer Failed',updated_by = 'Mayur Tanna',updated_date_time = getdate() where event_id = 14 and event_name='DATASET_DELIVERY_FAILED';
END;
GO