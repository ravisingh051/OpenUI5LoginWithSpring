USE [idis-metainfo] 

go 

/*  
Update Log  

Date          Author            Description  
----------   ----------------    -------------------------------------------------------------------------------------------  
2019-08-08    Snehal Patel      ADAPT-6331 ER Mandate file needs to be able to accept negative hours  

-- Table   
-- valid_values  
-- mftaa_valid_value_assoc  
*/ 

IF NOT EXISTS (SELECT 1 
               FROM   [valid_values] 
               WHERE  [valid_value_id] = 443) 
  BEGIN 
      SET IDENTITY_INSERT [dbo].[valid_values] ON 

      INSERT INTO [dbo].[valid_values] 
                  ([valid_value_id], 
                   [valid_value_name], 
                   [valid_value_desc], 
                   [valid_value_group_id], 
                   [is_active], 
                   [valid_value_standardized_name], 
                   [created_by], 
                   [created_date_time], 
                   [updated_by], 
                   [updated_date_time]) 
      VALUES      (443, 
                   N'+/-999999.99', 
                   NULL, 
                   16, 
                   1, 
                   N'-?\d{1,6}.\d{1,2}', 
                   N'A0745106', 
                   Getdate(), 
                   N'A0745106', 
                   Getdate() ); 

      SET IDENTITY_INSERT [dbo].[valid_values] OFF 
  END 

go 

IF EXISTS(SELECT 1 
          FROM   [mftaa_valid_value_assoc] 
          WHERE  [mftaa_valid_value_assoc_id] = 479 
                 AND [valid_value_id] = 84) 
  BEGIN 
      UPDATE [mftaa_valid_value_assoc] 
      SET    [valid_value_id] = 443 
      WHERE  [mftaa_valid_value_assoc_id] = 479; 
  END 

go 