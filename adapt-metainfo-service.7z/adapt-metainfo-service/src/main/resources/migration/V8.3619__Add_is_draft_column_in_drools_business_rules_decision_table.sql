USE [idis-metainfo]

/*
--Update Log
--Date        	Author          Description
----------  	------------    -------------------------------------------------------------------------------------------
--2019-07-08	Jinesh Vora		ADAPT-3619 Subtask -> ADAPT-6713: Add a column in table: drools_business_rules_decision_table to save draft rules

-- Table Used 
-- drools_business_rules_decision_table

*/
-- 1 ADD is_draft column & Default CONSTRAINT in drools_business_rules_decision_table Table.
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='drools_business_rules_decision_table' and column_name ='is_draft' 
UNION 
SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_drools_business_rules_decision_table_is_draft]') AND type = 'D'
)
BEGIN
ALTER TABLE drools_business_rules_decision_table 
Add is_draft bit NULL CONSTRAINT DF_drools_business_rules_decision_table_is_draft default 0;
END;
GO
