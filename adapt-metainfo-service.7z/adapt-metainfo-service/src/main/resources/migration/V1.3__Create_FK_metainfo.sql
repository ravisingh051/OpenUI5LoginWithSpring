use [idis-metainfo]
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_apbi_K7_idsi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.adapt_processing_blackout_info')
	)
BEGIN
ALTER TABLE [dbo].[adapt_processing_blackout_info]  WITH CHECK ADD  CONSTRAINT [FK_apbi_K7_idsi_K1] FOREIGN KEY([apbi_platform])
REFERENCES [dbo].[idis_data_source_info] ([source_id])
ALTER TABLE [dbo].[adapt_processing_blackout_info] CHECK CONSTRAINT [FK_apbi_K7_idsi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_awpf_K2_awp_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.adapt_web_page_fields')
		)
BEGIN
	ALTER TABLE [dbo].[adapt_web_page_fields]
		WITH CHECK ADD CONSTRAINT [FK_awpf_K2_awp_K1] FOREIGN KEY ([adapt_web_page_id]) REFERENCES [dbo].[adapt_web_pages]([adapt_web_page_id])

	ALTER TABLE [dbo].[adapt_web_page_fields] CHECK CONSTRAINT [FK_awpf_K2_awp_K1]
END;
GO
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaa_K2_child_file_template_meta_info_K19'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_approval_audit')
	)
BEGIN
	ALTER TABLE [dbo].[child_file_template_approval_audit]  WITH NOCHECK ADD  CONSTRAINT [FK_cftaa_K2_child_file_template_meta_info_K19] FOREIGN KEY([child_file_template_record_id])
	REFERENCES [dbo].[child_file_template_meta_info] (child_file_template_record_id)
	ALTER TABLE [dbo].[child_file_template_approval_audit] NOCHECK CONSTRAINT [FK_cftaa_K2_child_file_template_meta_info_K19]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaa_K2_K3_child_file_template_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_attribute_association')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_attribute_association]  WITH CHECK ADD  CONSTRAINT [FK_cftaa_K2_K3_child_file_template_K1_K2] FOREIGN KEY([child_file_template_id],[child_file_template_version])
REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_id],[child_file_template_version])
ALTER TABLE [dbo].[child_file_template_attribute_association] CHECK CONSTRAINT [FK_cftaa_K2_K3_child_file_template_K1_K2]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaa_K3_approval_status_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_approval_audit')
	)
BEGIN
	ALTER TABLE [dbo].[child_file_template_approval_audit]  WITH CHECK ADD  CONSTRAINT [FK_cftaa_K3_approval_status_K1] FOREIGN KEY([approval_status_id])
	REFERENCES [dbo].[approval_status] (approval_status_id)
	ALTER TABLE [dbo].[child_file_template_approval_audit] CHECK CONSTRAINT [FK_cftaa_K3_approval_status_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaa_K12_cftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_attribute_association')
	)
BEGIN
 ALTER TABLE [dbo].[child_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_cftaa_K12_cftmi_K15] FOREIGN KEY([child_file_template_record_id])
  REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_record_id])
  ALTER TABLE [dbo].[child_file_template_attribute_association] CHECK CONSTRAINT [FK_cftaa_K12_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaa_K12_cftsa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_attribute_association')
	)
BEGIN
  ALTER TABLE [dbo].[child_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_cftaa_K12_cftsa_K1] FOREIGN KEY([cftsa_id])
  REFERENCES [dbo].[child_file_template_section_assoc] ([cftsa_id])
  ALTER TABLE [dbo].[child_file_template_attribute_association] CHECK CONSTRAINT [FK_cftaa_K12_cftsa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaba_K2_cftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_cftaba_K2_cftaa_K1] FOREIGN KEY([cftaa_id])
REFERENCES [dbo].[child_file_template_attribute_association] ([cftaa_id])
ALTER TABLE [dbo].[child_file_template_attr_br_assoc] CHECK CONSTRAINT [FK_cftaba_K2_cftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftmi_K4_K5_master_file_template_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_cftmi_K4_K5_master_file_template_K1_K2] FOREIGN KEY([master_file_template_id],[master_file_template_version])
REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_id],[master_file_template_version])
ALTER TABLE [dbo].[child_file_template_meta_info] CHECK CONSTRAINT [FK_cftmi_K4_K5_master_file_template_K1_K2]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftaba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_cftaba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
ALTER TABLE [dbo].[child_file_template_attr_br_assoc] CHECK CONSTRAINT [FK_cftaba_K3_dbrdt_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftmi_K7_trading_partner_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_cftmi_K7_trading_partner_info_K1] FOREIGN KEY([trading_partner_id])
REFERENCES [dbo].[trading_partner_info] ([trading_partner_id])
ALTER TABLE [dbo].[child_file_template_meta_info] CHECK CONSTRAINT [FK_cftmi_K7_trading_partner_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftmi_K8_lob_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_cftmi_K8_lob_K1] FOREIGN KEY([lob_id])
REFERENCES [dbo].[lob] ([lob_id])
ALTER TABLE [dbo].[child_file_template_meta_info] CHECK CONSTRAINT [FK_cftmi_K8_lob_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftmi_K10_approval_status_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[child_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_cftmi_K10_approval_status_K1] FOREIGN KEY([approval_status_id])
REFERENCES [dbo].[approval_status] ([approval_status_id])
ALTER TABLE [dbo].[child_file_template_meta_info] CHECK CONSTRAINT [FK_cftmi_K10_approval_status_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_cftsa_K3_K4_cftmi_K1_K2'
      AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[child_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_cftsa_K3_K4_cftmi_K1_K2] FOREIGN KEY([child_file_template_id],[child_file_template_version])
  REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_id],[child_file_template_version])
  ALTER TABLE [dbo].[child_file_template_section_assoc] CHECK CONSTRAINT [FK_cftsa_K3_K4_cftmi_K1_K2]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_cftsa_K6_template_section_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[child_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_cftsa_K6_template_section_K1] FOREIGN KEY([template_section_id])
  REFERENCES [dbo].[template_sections] ([template_section_id])
  ALTER TABLE [dbo].[child_file_template_section_assoc] CHECK CONSTRAINT [FK_cftsa_K6_template_section_K1]
END;  
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_cftsa_K13_cftmi_K15'
      AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[child_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_cftsa_K13_cftmi_K15] FOREIGN KEY([child_file_template_record_id])
  REFERENCES [dbo].[child_file_template_meta_info] (child_file_template_record_id)
  ALTER TABLE [dbo].[child_file_template_section_assoc] CHECK CONSTRAINT [FK_cftsa_K13_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftsmaba_K3_drools_business_rules_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.cft_special_mapping_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[cft_special_mapping_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_cftsmaba_K3_drools_business_rules_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
ALTER TABLE [dbo].[cft_special_mapping_attr_br_assoc] CHECK CONSTRAINT [FK_cftsmaba_K3_drools_business_rules_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_client_employer_assoc_K5_idsi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.client_employer_assoc')
	)
BEGIN
ALTER TABLE [dbo].[client_employer_assoc]  WITH CHECK ADD  CONSTRAINT [FK_client_employer_assoc_K5_idsi_K1] FOREIGN KEY([data_source_id])
REFERENCES [dbo].[idis_data_source_info] (source_id)
ALTER TABLE [dbo].[client_employer_assoc] CHECK CONSTRAINT [FK_client_employer_assoc_K5_idsi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cftsmaba_K2_cftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.cft_special_mapping_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[cft_special_mapping_attr_br_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_cftsmaba_K2_cftmi_K15] FOREIGN KEY([child_file_template_record_id])
REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_record_id])
ALTER TABLE [dbo].[cft_special_mapping_attr_br_assoc] NOCHECK CONSTRAINT [FK_cftsmaba_K2_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cpai_K3_aeci_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.config_promotion_audit_info')
	)
BEGIN
ALTER TABLE [dbo].[config_promotion_audit_info]  WITH CHECK ADD  CONSTRAINT [FK_cpai_K3_aeci_K1] FOREIGN KEY([target_env_id])
REFERENCES [dbo].[adapt_env_config_info] ([adapt_env_id])
ALTER TABLE [dbo].[config_promotion_audit_info] CHECK CONSTRAINT [FK_cpai_K3_aeci_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cpai_K5_cps_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.config_promotion_audit_info')
	)
BEGIN
ALTER TABLE [dbo].[config_promotion_audit_info]  WITH CHECK ADD  CONSTRAINT [FK_cpai_K5_cps_K1] FOREIGN KEY([promotion_status_id])
REFERENCES [dbo].[config_promotion_status] ([config_promotion_status_id])
ALTER TABLE [dbo].[config_promotion_audit_info] CHECK CONSTRAINT [FK_cpai_K5_cps_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cpai_K2_aeci_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.config_promotion_audit_info')
	)
BEGIN
ALTER TABLE [dbo].[config_promotion_audit_info]  WITH CHECK ADD  CONSTRAINT [FK_cpai_K2_aeci_K1] FOREIGN KEY([source_env_id])
REFERENCES [dbo].[adapt_env_config_info] ([adapt_env_id])
ALTER TABLE [dbo].[config_promotion_audit_info] CHECK CONSTRAINT [FK_cpai_K2_aeci_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_cpad_K2_cpai_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.config_promotion_audit_details')
	)
BEGIN
ALTER TABLE [dbo].[config_promotion_audit_details]  WITH CHECK ADD  CONSTRAINT [FK_cpad_K2_cpai_K1] FOREIGN KEY([config_promotion_audit_id])
REFERENCES [dbo].[config_promotion_audit_info] ([config_promotion_audit_id])
ALTER TABLE [dbo].[config_promotion_audit_details] CHECK CONSTRAINT [FK_cpad_K2_cpai_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsda_K2_ctlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_dm_element_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsda_K2_ctlsni_K1] FOREIGN KEY([ctlsni_id])
REFERENCES [dbo].[child_template_layout_schema_node_info] (ctlsni_id)
ALTER TABLE [dbo].[ctls_node_dm_element_assoc] CHECK CONSTRAINT [FK_ctlsda_K2_ctlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsda_K3_cftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_dm_element_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsda_K3_cftaa_K1] FOREIGN KEY([cftaa_id])
REFERENCES [dbo].[child_file_template_attribute_association] (cftaa_id)
ALTER TABLE [dbo].[ctls_node_dm_element_assoc] CHECK CONSTRAINT [FK_ctlsda_K3_cftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsna_K2_ctlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_template_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[child_template_layout_schema_node_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsna_K2_ctlsni_K1] FOREIGN KEY([ctlsni_id])
REFERENCES [dbo].[child_template_layout_schema_node_info] (ctlsni_id)
ALTER TABLE [dbo].[child_template_layout_schema_node_assoc] CHECK CONSTRAINT [FK_ctlsna_K2_ctlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_csmaa_K2_cftmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_secondary_mapping_attr_assoc')
	)
BEGIN
ALTER TABLE [dbo].[child_secondary_mapping_attr_assoc]  WITH CHECK ADD  CONSTRAINT [FK_csmaa_K2_cftmi_K1] FOREIGN KEY([csmaa_child_file_template_record_id])
REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_record_id])
ALTER TABLE [dbo].[child_secondary_mapping_attr_assoc] CHECK CONSTRAINT [FK_csmaa_K2_cftmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctaeva_K2_ctlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_enum_value_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_enum_value_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctaeva_K2_ctlsni_K1] FOREIGN KEY([ctlsni_id])
REFERENCES [dbo].[child_template_layout_schema_node_info] (ctlsni_id)
ALTER TABLE [dbo].[ctls_node_enum_value_assoc] CHECK CONSTRAINT [FK_ctaeva_K2_ctlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsnba_K2_ctlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsnba_K2_ctlsni_K1] FOREIGN KEY([ctlsni_id])
REFERENCES [dbo].[child_template_layout_schema_node_info] (ctlsni_id)
ALTER TABLE [dbo].[ctls_node_br_assoc] CHECK CONSTRAINT [FK_ctlsnba_K2_ctlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsnba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsnba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] (drools_business_rule_id)
ALTER TABLE [dbo].[ctls_node_br_assoc] CHECK CONSTRAINT [FK_ctlsnba_K3_dbrdt_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsna_K3_ctlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_template_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[child_template_layout_schema_node_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ctlsna_K3_ctlsni_K1] FOREIGN KEY([parent_ctlsni_id])
REFERENCES [dbo].[child_template_layout_schema_node_info] (ctlsni_id)
ALTER TABLE [dbo].[child_template_layout_schema_node_assoc] CHECK CONSTRAINT [FK_ctlsna_K3_ctlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsni_K5_attribute_data_types_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[child_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_ctlsni_K5_attribute_data_types_K1] FOREIGN KEY([node_data_type_id])
REFERENCES [dbo].[attribute_data_types] (attribute_data_type_id)
ALTER TABLE [dbo].[child_template_layout_schema_node_info] CHECK CONSTRAINT [FK_ctlsni_K5_attribute_data_types_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsni_K14_template_sections_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.child_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[child_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_ctlsni_K14_template_sections_K1] FOREIGN KEY([mapped_template_section_id])
REFERENCES [dbo].[template_sections] (template_section_id)
ALTER TABLE [dbo].[child_template_layout_schema_node_info] CHECK CONSTRAINT [FK_ctlsni_K14_template_sections_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsni_K2_cftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.child_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[child_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_ctlsni_K2_cftmi_K15] FOREIGN KEY([child_file_template_record_id])
REFERENCES [dbo].[child_file_template_meta_info] (child_file_template_record_id)
ALTER TABLE [dbo].[child_template_layout_schema_node_info] CHECK CONSTRAINT [FK_ctlsni_K2_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_dbrpfta_K2_drools_business_rule_pkg_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.drools_business_rule_pkg_file_type_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[drools_business_rule_pkg_file_type_assoc]
		WITH CHECK ADD CONSTRAINT [FK_dbrpfta_K2_drools_business_rule_pkg_K1] FOREIGN KEY ([drools_business_rule_pkg_id],[drools_business_rule_pkg_version])
		REFERENCES [dbo].[drools_business_rule_pkg]([drools_business_rule_pkg_id], [drools_business_rule_pkg_version])
	ALTER TABLE [dbo].[drools_business_rule_pkg_file_type_assoc] CHECK CONSTRAINT [FK_dbrpfta_K2_drools_business_rule_pkg_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_dbrpfta_K4_file_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.drools_business_rule_pkg_file_type_assoc')
	)
BEGIN
ALTER TABLE [dbo].[drools_business_rule_pkg_file_type_assoc]  WITH CHECK ADD  CONSTRAINT [FK_dbrpfta_K4_file_type_K1] FOREIGN KEY([drools_br_pkg_file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
ALTER TABLE [dbo].[drools_business_rule_pkg_file_type_assoc] CHECK CONSTRAINT [FK_dbrpfta_K4_file_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_dbrdt_K3_drools_business_rule_group_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.drools_business_rules_decision_table')
	)
BEGIN
ALTER TABLE [dbo].[drools_business_rules_decision_table]  WITH CHECK ADD  CONSTRAINT [FK_dbrdt_K3_drools_business_rule_group_K1] FOREIGN KEY([drools_business_rule_group_id])
REFERENCES [dbo].[drools_business_rule_group] ([drools_business_rule_group_id])
ALTER TABLE [dbo].[drools_business_rules_decision_table] CHECK CONSTRAINT [FK_dbrdt_K3_drools_business_rule_group_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		from INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'FK_dbrt_K3_business_rule_group_K1'
	)
BEGIN
ALTER TABLE [dbo].[drools_business_rule_template]  WITH CHECK ADD  CONSTRAINT [FK_dbrt_K3_business_rule_group_K1] FOREIGN KEY([drools_business_rule_template_group_id])
REFERENCES [dbo].[drools_business_rule_group] ([drools_business_rule_group_id])
ALTER TABLE [dbo].[drools_business_rule_template] CHECK CONSTRAINT [FK_dbrt_K3_business_rule_group_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_dbrt_K7_approval_status_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.drools_business_rule_template')
	)
BEGIN
ALTER TABLE [dbo].[drools_business_rule_template]  WITH NOCHECK ADD  CONSTRAINT [FK_dbrt_K7_approval_status_K1] FOREIGN KEY([approval_status_id])
REFERENCES [dbo].[approval_status] ([approval_status_id])
ALTER TABLE [dbo].[drools_business_rule_template] CHECK CONSTRAINT [FK_dbrt_K7_approval_status_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ddff_K2_drools_data_format_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.drools_data_format_functions')
	)
BEGIN
ALTER TABLE [dbo].[drools_data_format_functions]  WITH CHECK ADD  CONSTRAINT [FK_ddff_K2_drools_data_format_K1] FOREIGN KEY([drools_data_format_id])
REFERENCES [dbo].[drools_data_formats] ([drools_data_format_id])
ALTER TABLE [dbo].[drools_data_format_functions] CHECK CONSTRAINT [FK_ddff_K2_drools_data_format_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_eldfp_K4_error_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_data_file_processing')
	)
BEGIN
ALTER TABLE [dbo].[error_log_data_file_processing]  WITH CHECK ADD  CONSTRAINT [FK_eldfp_K4_error_type_K1] FOREIGN KEY([error_type_id])
REFERENCES [dbo].[error_type] ([error_type_id])
ALTER TABLE [dbo].[error_log_data_file_processing] CHECK CONSTRAINT [FK_eldfp_K4_error_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_eldfp_K5_error_severity_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_data_file_processing')
	)
BEGIN
ALTER TABLE [dbo].[error_log_data_file_processing]  WITH CHECK ADD  CONSTRAINT [FK_eldfp_K5_error_severity_K1] FOREIGN KEY([error_severity_id])
REFERENCES [dbo].[error_severity] ([error_severity_id])
ALTER TABLE [dbo].[error_log_data_file_processing] CHECK CONSTRAINT [FK_eldfp_K5_error_severity_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_eldfp_K6_job_details_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_data_file_processing')
	)
BEGIN
ALTER TABLE [dbo].[error_log_data_file_processing]  WITH CHECK ADD  CONSTRAINT [FK_eldfp_K6_job_details_K1] FOREIGN KEY([error_data_file_job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[error_log_data_file_processing] CHECK CONSTRAINT [FK_eldfp_K6_job_details_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_eldfp_K2_error_code_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_data_file_processing')
	)
BEGIN
ALTER TABLE [dbo].[error_log_data_file_processing]  WITH CHECK ADD  CONSTRAINT [FK_eldfp_K2_error_code_K1] FOREIGN KEY([error_code])
REFERENCES [dbo].[error_code] ([error_code])
ALTER TABLE [dbo].[error_log_data_file_processing] CHECK CONSTRAINT [FK_eldfp_K2_error_code_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ep_K2_ept_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.extraction_parameters')
	)
BEGIN
ALTER TABLE [dbo].[extraction_parameters]  WITH CHECK ADD CONSTRAINT [FK_ep_K2_ept_K1] FOREIGN KEY([ep_ept_id])
REFERENCES [dbo].[extraction_parameters_types] ([ept_id])
ALTER TABLE [dbo].[extraction_parameters] CHECK CONSTRAINT [FK_ep_K2_ept_K1]
END;
GO


IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ep_K2_ad_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.extraction_parameters')
	)
BEGIN
ALTER TABLE [dbo].[extraction_parameters]  WITH CHECK ADD CONSTRAINT [FK_ep_K2_ad_K1] FOREIGN KEY([ep_attribute_id])
REFERENCES [dbo].[attribute_dictionary] ([attribute_id])
ALTER TABLE [dbo].[extraction_parameters] CHECK CONSTRAINT [FK_ep_K2_ad_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_error_code_K5_error_severity_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_code')
	)
	BEGIN
ALTER TABLE [dbo].[error_code]  WITH CHECK ADD  CONSTRAINT [FK_error_code_K5_error_severity_K1] FOREIGN KEY([error_severity_id])
REFERENCES [dbo].[error_severity] ([error_severity_id])
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_error_log_application_K2_error_code_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_application')
	)
	BEGIN
ALTER TABLE [dbo].[error_log_application]  WITH CHECK ADD  CONSTRAINT [FK_error_log_application_K2_error_code_K1] FOREIGN KEY([error_code])
REFERENCES [dbo].[error_code] ([error_code])
ALTER TABLE [dbo].[error_log_application] CHECK CONSTRAINT [FK_error_log_application_K2_error_code_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_error_log_application_K4_error_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_application')
	)
	BEGIN
ALTER TABLE [dbo].[error_log_application]  WITH CHECK ADD  CONSTRAINT [FK_error_log_application_K4_error_type_K1] FOREIGN KEY([error_type_id])
REFERENCES [dbo].[error_type] ([error_type_id])
ALTER TABLE [dbo].[error_log_application] CHECK CONSTRAINT [FK_error_log_application_K4_error_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_error_log_application_K5_error_severity_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_log_application')
	)
BEGIN
ALTER TABLE [dbo].[error_log_application]  WITH CHECK ADD  CONSTRAINT [FK_error_log_application_K5_error_severity_K1] FOREIGN KEY([error_severity_id])
REFERENCES [dbo].[error_severity] ([error_severity_id])
ALTER TABLE [dbo].[error_log_application] CHECK CONSTRAINT [FK_error_log_application_K5_error_severity_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_error_code_K4_error_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.error_code')
	)
BEGIN
ALTER TABLE [dbo].[error_code]  WITH CHECK ADD  CONSTRAINT [FK_error_code_K4_error_type_K1] FOREIGN KEY([error_type_id])
REFERENCES [dbo].[error_type] ([error_type_id])
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_faa_K3_fsa_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.file_attribute_association')
  )
BEGIN
  ALTER TABLE [dbo].[file_attribute_association] WITH CHECK ADD CONSTRAINT [FK_faa_K3_fsa_K1] FOREIGN KEY([fsa_id])
  REFERENCES [dbo].[file_section_association] ([fsa_id])
  ALTER TABLE [dbo].[file_attribute_association] CHECK CONSTRAINT [FK_faa_K3_fsa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_faa_K5_attribute_dictionary_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_attribute_association')
	)
BEGIN
ALTER TABLE [dbo].[file_attribute_association]  WITH CHECK ADD  CONSTRAINT [FK_faa_K5_attribute_dictionary_K1] FOREIGN KEY([attribute_id])
REFERENCES [dbo].[attribute_dictionary] ([attribute_id])
ALTER TABLE [dbo].[file_attribute_association] CHECK CONSTRAINT [FK_faa_K5_attribute_dictionary_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_faa_K26_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_attribute_association')
	)
	BEGIN
ALTER TABLE [dbo].[file_attribute_association]  WITH CHECK ADD  CONSTRAINT [FK_faa_K26_file_meta_info_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_attribute_association] CHECK CONSTRAINT [FK_faa_K26_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fabra_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_attr_br_assoc')
	)
	BEGIN
ALTER TABLE [dbo].[file_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fabra_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
ALTER TABLE [dbo].[file_attr_br_assoc] CHECK CONSTRAINT [FK_fabra_K3_dbrdt_K1]
END;
GO

IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fea_K2_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_employer_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_employer_assoc]  DROP  CONSTRAINT [FK_fea_K2_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_faba_K11_profiles_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_attr_br_assoc')
	)
BEGIN
	ALTER TABLE [dbo].[file_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_faba_K11_profiles_K1] FOREIGN KEY([profile_id])
	REFERENCES [dbo].[profiles] ([profile_id])
	ALTER TABLE [dbo].[file_attr_br_assoc] CHECK CONSTRAINT [FK_faba_K11_profiles_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fabra_K2_faa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_attr_br_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_fabra_K2_faa_K1] FOREIGN KEY([faa_id])
REFERENCES [dbo].[file_attribute_association] ([faa_id])
ALTER TABLE [dbo].[file_attr_br_assoc] NOCHECK CONSTRAINT [FK_fabra_K2_faa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fea_K7_fmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_employer_assoc')
	)
BEGIN
ALTER TABLE [dbo].file_employer_assoc WITH CHECK ADD CONSTRAINT FK_fea_K7_fmi_K1 FOREIGN KEY(file_identifier)
REFERENCES [dbo].file_meta_info (record_id)
ALTER TABLE [dbo].file_employer_assoc CHECK CONSTRAINT FK_fea_K7_fmi_K1
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepa_K2_ep_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_extraction_parameters_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_extraction_parameters_assoc]  WITH CHECK ADD CONSTRAINT [FK_fepa_K2_ep_K1] FOREIGN KEY(fepa_ep_id)
REFERENCES [dbo].[extraction_parameters] (ep_id)
ALTER TABLE [dbo].[file_extraction_parameters_assoc] CHECK CONSTRAINT [FK_fepa_K2_ep_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepa_K2_fepi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_extraction_parameters_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_extraction_parameters_assoc]  WITH NOCHECK ADD CONSTRAINT [FK_fepa_K2_fepi_K1] FOREIGN KEY(fepa_fepi_id)
REFERENCES [dbo].[file_extraction_parameters_info] (fepi_id)
ALTER TABLE [dbo].[file_extraction_parameters_assoc] NOCHECK CONSTRAINT [FK_fepa_K2_fepi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fea_K4_client_employer_assoc_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_employer_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_employer_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fea_K4_client_employer_assoc_K1] FOREIGN KEY([client_employer_assoc_id])
REFERENCES [dbo].[client_employer_assoc] (client_employer_assoc_id)
ALTER TABLE [dbo].[file_employer_assoc] CHECK CONSTRAINT [FK_fea_K4_client_employer_assoc_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepi_K3_profiles_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_extraction_parameters_info')
	)
BEGIN
ALTER TABLE [dbo].[file_extraction_parameters_info]  WITH CHECK ADD CONSTRAINT [FK_fepi_K3_profiles_K1] FOREIGN KEY([fepi_profile_id])
REFERENCES [dbo].[profiles] ([profile_id])
ALTER TABLE [dbo].[file_extraction_parameters_info] CHECK CONSTRAINT [FK_fepi_K3_profiles_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepi_K2_fmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_extraction_parameters_info')
	)
BEGIN
ALTER TABLE [dbo].[file_extraction_parameters_info]  WITH CHECK ADD CONSTRAINT [FK_fepi_K2_fmi_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_extraction_parameters_info] CHECK CONSTRAINT [FK_fepi_K2_fmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_file_approval_audit_K3_approval_status_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_approval_audit')
	)
BEGIN
	ALTER TABLE [dbo].[file_approval_audit]  WITH NOCHECK ADD  CONSTRAINT [FK_file_approval_audit_K3_approval_status_K1] FOREIGN KEY([approval_status_id])
	REFERENCES [dbo].[approval_status] (approval_status_id)
	ALTER TABLE [dbo].[file_approval_audit] NOCHECK CONSTRAINT [FK_file_approval_audit_K3_approval_status_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_file_approval_audit_K2_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_approval_audit')
	)
BEGIN
	ALTER TABLE [dbo].[file_approval_audit]  WITH NOCHECK ADD  CONSTRAINT [FK_file_approval_audit_K2_file_meta_info_K1] FOREIGN KEY([file_identifier])
	REFERENCES [dbo].[file_meta_info] (record_id)
	ALTER TABLE [dbo].[file_approval_audit] NOCHECK CONSTRAINT [FK_file_approval_audit_K2_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_file_meta_info_K28_TPI_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
	BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_file_meta_info_K28_TPI_K1] FOREIGN KEY([trading_partner_platform_id])
REFERENCES [dbo].[trading_partner_platform_info] ([trading_partner_platform_id])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_file_meta_info_K28_TPI_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fls_node_delimiter_info_file_meta_info'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_delimiter_info')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_delimiter_info]  WITH CHECK ADD  CONSTRAINT [FK_fls_node_delimiter_info_file_meta_info] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[fls_node_delimiter_info] CHECK CONSTRAINT [FK_fls_node_delimiter_info_file_meta_info]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsda_K2_flsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_dm_element_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_flsda_K2_flsni_K1] FOREIGN KEY([flsni_id])
REFERENCES [dbo].[file_layout_schema_node_info] (flsni_id)
ALTER TABLE [dbo].[fls_node_dm_element_assoc] NOCHECK CONSTRAINT [FK_flsda_K2_flsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsda_K3_faa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_dm_element_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_flsda_K3_faa_K1] FOREIGN KEY([faa_id])
REFERENCES [dbo].[file_attribute_association] (faa_id)
ALTER TABLE [dbo].[fls_node_dm_element_assoc] NOCHECK CONSTRAINT [FK_flsda_K3_faa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsna_K2_flsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_layout_schema_node_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_flsna_K2_flsni_K1] FOREIGN KEY([flsni_id])
REFERENCES [dbo].[file_layout_schema_node_info] (flsni_id)
ALTER TABLE [dbo].[file_layout_schema_node_assoc] NOCHECK CONSTRAINT [FK_flsna_K2_flsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsnba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_flsnba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] (drools_business_rule_id)
ALTER TABLE [dbo].[fls_node_br_assoc] CHECK CONSTRAINT [FK_flsnba_K3_dbrdt_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsnba_K2_flsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_flsnba_K2_flsni_K1] FOREIGN KEY([flsni_id])
REFERENCES [dbo].[file_layout_schema_node_info] (flsni_id)
ALTER TABLE [dbo].[fls_node_br_assoc] CHECK CONSTRAINT [FK_flsnba_K2_flsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsna_K3_flsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_layout_schema_node_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_flsna_K3_flsni_K1] FOREIGN KEY([parent_flsni_id])
REFERENCES [dbo].[file_layout_schema_node_info] (flsni_id)
ALTER TABLE [dbo].[file_layout_schema_node_assoc] NOCHECK CONSTRAINT [FK_flsna_K3_flsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsni_K2_fmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.file_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[file_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_flsni_K2_fmi_K15] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] (record_id)
ALTER TABLE [dbo].[file_layout_schema_node_info] CHECK CONSTRAINT [FK_flsni_K2_fmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsni_K5_attribute_data_types_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[file_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_flsni_K5_attribute_data_types_K1] FOREIGN KEY([node_data_type_id])
REFERENCES [dbo].[attribute_data_types] (attribute_data_type_id)
ALTER TABLE [dbo].[file_layout_schema_node_info] CHECK CONSTRAINT [FK_flsni_K5_attribute_data_types_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsni_K14_template_sections_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[file_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_flsni_K14_template_sections_K1] FOREIGN KEY([mapped_template_section_id])
REFERENCES [dbo].[template_sections] (template_section_id)
ALTER TABLE [dbo].[file_layout_schema_node_info] CHECK CONSTRAINT [FK_flsni_K14_template_sections_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_flua_K9_fmi_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.file_linked_urls_assoc')
  )
BEGIN
  ALTER TABLE [dbo].file_linked_urls_assoc WITH NOCHECK ADD CONSTRAINT FK_flua_K9_fmi_K1 FOREIGN KEY(file_identifier)
  REFERENCES [dbo].file_meta_info (record_id)
  ALTER TABLE [dbo].file_linked_urls_assoc NOCHECK CONSTRAINT FK_flua_K9_fmi_K1
  END;
GO 

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K6_K7_cftmi_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K6_K7_cftmi_K1_K2] FOREIGN KEY([child_file_template_id],[child_file_template_version])
REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_id],[child_file_template_version])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_fmi_K6_K7_cftmi_K1_K2]
END;
GO

		IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K2_file_id_generator_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
		ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K2_file_id_generator_K1] FOREIGN KEY(file_id)
		REFERENCES [dbo].[file_id_generator] ([file_id])
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K3_ftmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K3_ftmi_K1] FOREIGN KEY([file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_fmi_K3_ftmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K4_K5_mftmi_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K4_K5_mftmi_K1_K2] FOREIGN KEY([master_file_template_id],[master_file_template_version])
REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_id],[master_file_template_version])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_fmi_K4_K5_mftmi_K1_K2]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K24_file_format_supported_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K24_file_format_supported_K1] FOREIGN KEY([file_format_supported_id])
REFERENCES [dbo].[file_format_supported] ([file_format_supported_id])
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K38_cftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K38_cftmi_K15] FOREIGN KEY([child_file_template_record_id])
REFERENCES [dbo].[child_file_template_meta_info] ([child_file_template_record_id])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_fmi_K38_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fmi_K39_cftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.file_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[file_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_fmi_K39_cftmi_K15] FOREIGN KEY([master_file_template_record_id])
REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_record_id])
ALTER TABLE [dbo].[file_meta_info] CHECK CONSTRAINT [FK_fmi_K39_cftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fntca_K12_fmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_notification_template_contact_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_notification_template_contact_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fntca_K12_fmi_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_notification_template_contact_assoc] CHECK CONSTRAINT [FK_fntca_K12_fmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fntca_K13_idis_team_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_notification_template_contact_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_notification_template_contact_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fntca_K13_idis_team_K1] FOREIGN KEY([idis_team_id])
REFERENCES [dbo].[idis_team] ([idis_team_id])
ALTER TABLE [dbo].[file_notification_template_contact_assoc] CHECK CONSTRAINT [FK_fntca_K13_idis_team_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fntca_K2_nti_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_notification_template_contact_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_notification_template_contact_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fntca_K2_nti_K1] FOREIGN KEY([template_id])
REFERENCES [dbo].[notification_template_info] ([template_id])
ALTER TABLE [dbo].[file_notification_template_contact_assoc] CHECK CONSTRAINT [FK_fntca_K2_nti_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fntca_K3_tpct_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_notification_template_contact_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_notification_template_contact_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fntca_K3_tpct_K1] FOREIGN KEY([trading_partner_contact_type_id])
REFERENCES [dbo].[trading_partner_contact_type] ([trading_partner_contact_type_id])
ALTER TABLE [dbo].[file_notification_template_contact_assoc] CHECK CONSTRAINT [FK_fntca_K3_tpct_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fntca_K4_tpci_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_notification_template_contact_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_notification_template_contact_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fntca_K4_tpci_K1] FOREIGN KEY([trading_partner_contact_id])
REFERENCES [dbo].[trading_partner_contact_info] ([trading_partner_contact_id])
ALTER TABLE [dbo].[file_notification_template_contact_assoc] CHECK CONSTRAINT [FK_fntca_K4_tpci_K1]
END;
GO

IF NOt EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpal_K4_job_details_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_audit_log')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_audit_log]  WITH CHECK ADD  CONSTRAINT [FK_fpal_K4_job_details_K1] FOREIGN KEY([job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[file_processing_audit_log] CHECK CONSTRAINT [FK_fpal_K4_job_details_K1]
END;
GO

IF NOt EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpal_K6_pse_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_audit_log')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_audit_log]  WITH CHECK ADD  CONSTRAINT [FK_fpal_K6_pse_K1] FOREIGN KEY([processing_step_id])
REFERENCES [dbo].[processing_system_events] ([event_id])
ALTER TABLE [dbo].[file_processing_audit_log] CHECK CONSTRAINT [FK_fpal_K6_pse_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpal_K2_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_audit_log')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_audit_log]  WITH CHECK ADD  CONSTRAINT [FK_fpal_K2_file_meta_info_K1] FOREIGN KEY([file_id])
REFERENCES [dbo].[file_id_generator] ([file_id])
ALTER TABLE [dbo].[file_processing_audit_log] CHECK CONSTRAINT [FK_fpal_K2_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpr_K11_recurrence_exception_rules_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_recurrence')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_recurrence]  WITH CHECK ADD  CONSTRAINT [FK_fpr_K11_recurrence_exception_rules_K1] FOREIGN KEY([exception_rule_id])
REFERENCES [dbo].[recurrence_exception_rules] ([recurrence_exception_rule_id])
ALTER TABLE [dbo].[file_processing_recurrence] CHECK CONSTRAINT [FK_fpr_K11_recurrence_exception_rules_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpr_K17_file_processing_mode_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_recurrence')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_recurrence]  WITH CHECK ADD  CONSTRAINT [FK_fpr_K17_file_processing_mode_K1] FOREIGN KEY([file_processing_mode_id])
REFERENCES [dbo].[file_processing_mode] ([file_processing_mode_id])
ALTER TABLE [dbo].[file_processing_recurrence] CHECK CONSTRAINT [FK_fpr_K17_file_processing_mode_K1]
END;
GO

IF NOt EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fprd_K2_file_processing_recurrence_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_recurrence_dates')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_recurrence_dates]  WITH CHECK ADD  CONSTRAINT [FK_fprd_K2_file_processing_recurrence_K1] FOREIGN KEY([file_processing_recurrence_id])
REFERENCES [dbo].[file_processing_recurrence] ([file_processing_recurrence_id])
ALTER TABLE [dbo].[file_processing_recurrence_dates] CHECK CONSTRAINT [FK_fprd_K2_file_processing_recurrence_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpr_K2_recurrence_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_recurrence')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_recurrence]  WITH CHECK ADD  CONSTRAINT [FK_fpr_K2_recurrence_type_K1] FOREIGN KEY([recurrence_type_id])
REFERENCES [dbo].[recurrence_type] ([recurrence_type_id])
ALTER TABLE [dbo].[file_processing_recurrence] CHECK CONSTRAINT [FK_fpr_K2_recurrence_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fps_K16_file_id_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_schedule')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_schedule]  WITH NOCHECK ADD  CONSTRAINT [FK_fps_K16_file_id_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_processing_schedule] NOCHECK CONSTRAINT [FK_fps_K16_file_id_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fps_K16_profiles_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_schedule')
	)
BEGIN
	ALTER TABLE [dbo].[file_processing_schedule]  WITH CHECK ADD  CONSTRAINT [FK_fps_K16_profiles_K1] FOREIGN KEY([profile_id])
	REFERENCES [dbo].[profiles] ([profile_id])
	ALTER TABLE [dbo].[file_processing_schedule] CHECK CONSTRAINT [FK_fps_K16_profiles_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fpsa_K2_file_processing_schedule_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_schedule_audit')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_schedule_audit]  WITH CHECK ADD  CONSTRAINT [FK_fpsa_K2_file_processing_schedule_K1] FOREIGN KEY([file_processing_schedule_id])
REFERENCES [dbo].[file_processing_schedule] ([file_processing_schedule_id])
ALTER TABLE [dbo].[file_processing_schedule_audit] CHECK CONSTRAINT [FK_fpsa_K2_file_processing_schedule_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fps_K7_file_processing_recurrence_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_processing_schedule')
	)
BEGIN
ALTER TABLE [dbo].[file_processing_schedule]  WITH CHECK ADD  CONSTRAINT [FK_fps_K7_file_processing_recurrence_K1] FOREIGN KEY([file_processing_recurrence_id])
REFERENCES [dbo].[file_processing_recurrence] ([file_processing_recurrence_id])
ALTER TABLE [dbo].[file_processing_schedule] CHECK CONSTRAINT [FK_fps_K7_file_processing_recurrence_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fs_K6_job_details_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_state')
	)
	BEGIN
ALTER TABLE [dbo].[file_state]  WITH CHECK ADD  CONSTRAINT [FK_fs_K6_job_details_K1] FOREIGN KEY([job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[file_state] CHECK CONSTRAINT [FK_fs_K6_job_details_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fs_K3_trading_partner_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_state')
	)
	BEGIN
ALTER TABLE [dbo].[file_state]  WITH CHECK ADD  CONSTRAINT [FK_fs_K3_trading_partner_info_K1] FOREIGN KEY([trading_partner_id])
REFERENCES [dbo].[trading_partner_info] ([trading_partner_id])
ALTER TABLE [dbo].[file_state] CHECK CONSTRAINT [FK_fs_K3_trading_partner_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fs_K5_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_state')
	)
	BEGIN
ALTER TABLE [dbo].[file_state]  WITH CHECK ADD  CONSTRAINT [FK_fs_K5_file_meta_info_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_state] CHECK CONSTRAINT [FK_fs_K5_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_fsa_K2_template_sections_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.file_section_association')
  )
BEGIN
  ALTER TABLE [dbo].[file_section_association] WITH CHECK ADD CONSTRAINT [FK_fsa_K2_template_sections_K1] FOREIGN KEY([template_section_id])
  REFERENCES [dbo].[template_sections] ([template_section_id])
  ALTER TABLE [dbo].[file_section_association] CHECK CONSTRAINT [FK_fsa_K2_template_sections_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_fsa_K16_file_meta_info_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.file_section_association')
  )
BEGIN
  ALTER TABLE [dbo].[file_section_association] WITH CHECK ADD CONSTRAINT [FK_fsa_K16_file_meta_info_K1] FOREIGN KEY([file_identifier])
  REFERENCES [dbo].[file_meta_info] ([record_id])
  ALTER TABLE [dbo].[file_section_association] CHECK CONSTRAINT [FK_fsa_K16_file_meta_info_K1]
END; 
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fsa_K2_file_state_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_state_audit')
	)
BEGIN
ALTER TABLE [dbo].[file_state_audit]  WITH CHECK ADD  CONSTRAINT [FK_fsa_K2_file_state_K1] FOREIGN KEY([file_state_id])
REFERENCES [dbo].[file_state] ([file_state_id])
ALTER TABLE [dbo].[file_state_audit] CHECK CONSTRAINT [FK_fsa_K2_file_state_K1]
END;
GO
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fsmaba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_special_mapping_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_special_mapping_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fsmaba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
ALTER TABLE [dbo].[file_special_mapping_attr_br_assoc] CHECK CONSTRAINT [FK_fsmaba_K3_dbrdt_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fsmaa_K2_fmi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_secondary_mapping_attr_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_secondary_mapping_attr_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fsmaa_K2_fmi_K1] FOREIGN KEY([fsmaa_file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_secondary_mapping_attr_assoc] CHECK CONSTRAINT [FK_fsmaa_K2_fmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fsmaba_K2_fmi_K16'
			AND c.parent_object_id = OBJECT_ID('dbo.file_special_mapping_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_special_mapping_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fsmaba_K2_fmi_K16] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_special_mapping_attr_br_assoc] CHECK CONSTRAINT [FK_fsmaba_K2_fmi_K16]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ftaa_K2_file_type_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_type_attribute_association')
	)
BEGIN
ALTER TABLE [dbo].[file_type_attribute_association] ADD  CONSTRAINT [FK_ftaa_K2_file_type_meta_info_K1] FOREIGN KEY([file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ftaa_K3_attribute_dictionary_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_type_attribute_association')
	)
BEGIN
ALTER TABLE [dbo].[file_type_attribute_association] ADD  CONSTRAINT [FK_ftaa_K3_attribute_dictionary_K1] FOREIGN KEY([attribute_id])
REFERENCES [dbo].[attribute_dictionary] ([attribute_id])
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ftaeva_K2_ftlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_enum_value_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_enum_value_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_ftaeva_K2_ftlsni_K1] FOREIGN KEY([flsni_id])
REFERENCES [dbo].[file_layout_schema_node_info] (flsni_id)
ALTER TABLE [dbo].[fls_node_enum_value_assoc] NOCHECK CONSTRAINT [FK_ftaeva_K2_ftlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fti_K3_adapt_env_config_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_transmission_info')
	)
BEGIN
ALTER TABLE [dbo].[file_transmission_info]  WITH CHECK ADD  CONSTRAINT [FK_fti_K3_adapt_env_config_info_K1] FOREIGN KEY([adapt_env_id])
REFERENCES [dbo].[adapt_env_config_info] ([adapt_env_id])
ALTER TABLE [dbo].[file_transmission_info] CHECK CONSTRAINT [FK_fti_K3_adapt_env_config_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fti_K4_trading_partner_connection_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_transmission_info')
	)
BEGIN
ALTER TABLE [dbo].[file_transmission_info]  WITH CHECK ADD  CONSTRAINT [FK_fti_K4_trading_partner_connection_info_K1] FOREIGN KEY([trading_partner_connection_id])
REFERENCES [dbo].[trading_partner_connection_info] ([trading_partner_connection_id])
ALTER TABLE [dbo].[file_transmission_info] CHECK CONSTRAINT [FK_fti_K4_trading_partner_connection_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fti_K5_trading_partner_auth_key_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_transmission_info')
	)
BEGIN
ALTER TABLE [dbo].[file_transmission_info]  WITH CHECK ADD  CONSTRAINT [FK_fti_K5_trading_partner_auth_key_info_K1] FOREIGN KEY([trading_partner_auth_key_id])
REFERENCES [dbo].[trading_partner_auth_key_info] ([trading_partner_auth_key_info_id])
ALTER TABLE [dbo].[file_transmission_info] CHECK CONSTRAINT [FK_fti_K5_trading_partner_auth_key_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fti_K2_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_transmission_info')
	)
BEGIN
ALTER TABLE [dbo].[file_transmission_info]  WITH CHECK ADD  CONSTRAINT [FK_fti_K2_file_meta_info_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[file_transmission_info] CHECK CONSTRAINT [FK_fti_K2_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_ftpla_K8_fmi_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.file_trading_partner_lob_assoc')
  )
BEGIN
  ALTER TABLE [dbo].file_trading_partner_lob_assoc WITH CHECK ADD CONSTRAINT FK_ftpla_K8_fmi_K1 FOREIGN KEY(file_identifier)
  REFERENCES [dbo].file_meta_info (record_id)
  ALTER TABLE [dbo].file_trading_partner_lob_assoc CHECK CONSTRAINT FK_ftpla_K8_fmi_K1
  END;
GO 

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_idfa_K3_dashboard_functionality_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.idis_dbrd_func_actions')
	)
BEGIN
ALTER TABLE [dbo].[idis_dbrd_func_actions]  WITH CHECK ADD  CONSTRAINT [FK_idfa_K3_dashboard_functionality_K1] FOREIGN KEY([functionality_id])
REFERENCES [dbo].[idis_dbrd_func] ([functionality_id])
ALTER TABLE [dbo].[idis_dbrd_func_actions] CHECK CONSTRAINT [FK_idfa_K3_dashboard_functionality_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ftpla_K2_trading_partner_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_trading_partner_lob_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_trading_partner_lob_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ftpla_K2_trading_partner_info_K1] FOREIGN KEY([trading_partner_id])
REFERENCES [dbo].[trading_partner_info] ([trading_partner_id])
ALTER TABLE [dbo].[file_trading_partner_lob_assoc] CHECK CONSTRAINT [FK_ftpla_K2_trading_partner_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ftpla_K3_lob_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_trading_partner_lob_assoc')
	)
BEGIN
ALTER TABLE [dbo].[file_trading_partner_lob_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ftpla_K3_lob_K1] FOREIGN KEY([lob_id])
REFERENCES [dbo].[lob] ([lob_id])
ALTER TABLE [dbo].[file_trading_partner_lob_assoc] CHECK CONSTRAINT [FK_ftpla_K3_lob_K1]
END;
GO
	IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_itfa_K2_idis_team_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.idis_team_file_association')
	)
BEGIN
		ALTER TABLE [dbo].[idis_team_file_association]  WITH CHECK ADD  CONSTRAINT [FK_itfa_K2_idis_team_K1] FOREIGN KEY([idis_team_id])
		REFERENCES [dbo].[idis_team] ([idis_team_id])
		ALTER TABLE [dbo].[idis_team_file_association] CHECK CONSTRAINT [FK_itfa_K2_idis_team_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_itfa_K5_fmi_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.idis_team_file_association')
  )
BEGIN
  ALTER TABLE [dbo].idis_team_file_association WITH CHECK ADD CONSTRAINT FK_itfa_K5_fmi_K1 FOREIGN KEY(file_identifier)
  REFERENCES [dbo].file_meta_info (record_id)
  ALTER TABLE [dbo].idis_team_file_association CHECK CONSTRAINT FK_itfa_K5_fmi_K1
  END;
GO 

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_jdps_K2_jd_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.job_details_prioritization_staging')
	)
BEGIN
ALTER TABLE [dbo].[job_details_prioritization_staging]  WITH CHECK ADD  CONSTRAINT [FK_jdps_K2_jd_K1] FOREIGN KEY([job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[job_details_prioritization_staging] CHECK CONSTRAINT [FK_jdps_K2_jd_K1]
END;
GO

IF NOt EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_jel_K5_job_details_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.job_event_log')
	)
BEGIN
ALTER TABLE [dbo].[job_event_log]  WITH CHECK ADD  CONSTRAINT [FK_jel_K5_job_details_K1] FOREIGN KEY([jel_job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[job_event_log] CHECK CONSTRAINT [FK_jel_K5_job_details_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_jel_K13_file_meta_info_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.job_event_log')
  )
BEGIN
  ALTER TABLE [dbo].[job_event_log] WITH CHECK ADD CONSTRAINT [FK_jel_K13_file_meta_info_K1] FOREIGN KEY([jel_file_identifier])
  REFERENCES [dbo].[file_meta_info] ([record_id])
  ALTER TABLE [dbo].[job_event_log] CHECK CONSTRAINT [FK_jel_K13_file_meta_info_K1]
END;  
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_jdp_K2_jd_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.job_details_prioritization')
	)
BEGIN
ALTER TABLE [dbo].[job_details_prioritization]  WITH CHECK ADD  CONSTRAINT [FK_jdp_K2_jd_K1] FOREIGN KEY([job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[job_details_prioritization] CHECK CONSTRAINT [FK_jdp_K2_jd_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_job_details_K15_fpsi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.job_details')
	)
BEGIN
ALTER TABLE [dbo].[job_details]  WITH CHECK ADD  CONSTRAINT [FK_job_details_K15_fpsi_K1] FOREIGN KEY([file_processing_schedule_id])
REFERENCES [dbo].[file_processing_schedule] ([file_processing_schedule_id])
ALTER TABLE [dbo].[job_details] CHECK CONSTRAINT [FK_job_details_K15_fpsi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_job_details_K25_file_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.job_details')
	)
BEGIN
ALTER TABLE [dbo].[job_details]  WITH NOCHECK ADD  CONSTRAINT [FK_job_details_K25_file_meta_info_K1] FOREIGN KEY([file_identifier])
REFERENCES [dbo].[file_meta_info] ([record_id])
ALTER TABLE [dbo].[job_details] NOCHECK CONSTRAINT [FK_job_details_K25_file_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ltckm_K2_lookup_table_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.lookup_table_composite_key_mapping')
	)
BEGIN
ALTER TABLE [dbo].[lookup_table_composite_key_mapping]  WITH NOCHECK ADD  CONSTRAINT [FK_ltckm_K2_lookup_table_meta_info_K1] FOREIGN KEY([lookup_table_id])
REFERENCES [dbo].[lookup_table_meta_info] ([lookup_table_id])
ALTER TABLE [dbo].[lookup_table_composite_key_mapping] NOCHECK CONSTRAINT [FK_ltckm_K2_lookup_table_meta_info_K1]
END;
Go

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ltckm_K7_attribute_dictionary_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.lookup_table_composite_key_mapping')
	)
BEGIN
ALTER TABLE [dbo].[lookup_table_composite_key_mapping]  WITH CHECK ADD  CONSTRAINT [FK_ltckm_K7_attribute_dictionary_K1] FOREIGN KEY([datamart_element_id])
REFERENCES [dbo].[attribute_dictionary] ([attribute_id])
ALTER TABLE [dbo].[lookup_table_composite_key_mapping] CHECK CONSTRAINT [FK_ltckm_K7_attribute_dictionary_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ltfa_K2_lookup_table_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.lookup_table_file_association')
	)
BEGIN
ALTER TABLE [dbo].[lookup_table_file_association]  WITH NOCHECK ADD  CONSTRAINT [FK_ltfa_K2_lookup_table_meta_info_K1] FOREIGN KEY([lookup_table_id])
REFERENCES [dbo].[lookup_table_meta_info] ([lookup_table_id])
ALTER TABLE [dbo].[lookup_table_file_association] NOCHECK CONSTRAINT [FK_ltfa_K2_lookup_table_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ltmi_K7_file_type_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.lookup_table_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[lookup_table_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_ltmi_K7_file_type_meta_info_K1] FOREIGN KEY([associated_file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
ALTER TABLE [dbo].[lookup_table_meta_info] CHECK CONSTRAINT [FK_ltmi_K7_file_type_meta_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ltd_K2_lookup_table_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.lookup_table_details')
	)
BEGIN
ALTER TABLE [dbo].[lookup_table_details]  WITH NOCHECK ADD  CONSTRAINT [FK_ltd_K2_lookup_table_meta_info_K1] FOREIGN KEY([lookup_table_id])
REFERENCES [dbo].[lookup_table_meta_info] ([lookup_table_id])
ALTER TABLE [dbo].[lookup_table_details] NOCHECK CONSTRAINT [FK_ltd_K2_lookup_table_meta_info_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftaa_K11_mftsa_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attribute_association')
  )
BEGIN
  ALTER TABLE [dbo].[master_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_mftaa_K11_mftsa_K1] FOREIGN KEY([mftsa_id])
  REFERENCES [dbo].[master_file_template_section_assoc] ([mftsa_id])
  ALTER TABLE [dbo].[master_file_template_attribute_association] CHECK CONSTRAINT [FK_mftaa_K11_mftsa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaa_K12_mftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attribute_association')
	)
BEGIN
 ALTER TABLE [dbo].[master_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_mftaa_K12_mftmi_K15] FOREIGN KEY([master_file_template_record_id])
  REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_record_id])
  ALTER TABLE [dbo].[master_file_template_attribute_association] CHECK CONSTRAINT [FK_mftaa_K12_mftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaa_K16_ftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attribute_association')
	)
BEGIN
 ALTER TABLE [dbo].[master_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_mftaa_K16_ftaa_K1] FOREIGN KEY([ftaa_id])
  REFERENCES [dbo].file_type_attribute_association ([ftaa_id])
  ALTER TABLE [dbo].[master_file_template_attribute_association] CHECK CONSTRAINT [FK_mftaa_K16_ftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaa_K3_K4_mftmi_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attribute_association')
	)
BEGIN
 ALTER TABLE [dbo].[master_file_template_attribute_association] WITH CHECK ADD CONSTRAINT [FK_mftaa_K3_K4_mftmi_K1_K2] FOREIGN KEY([master_file_template_id],[master_file_template_version])
  REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_id],[master_file_template_version])
  ALTER TABLE [dbo].[master_file_template_attribute_association] CHECK CONSTRAINT [FK_mftaa_K3_K4_mftmi_K1_K2]
  END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaa_K4_attribute_dictionary_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attribute_association')
	)
BEGIN
ALTER TABLE [dbo].[master_file_template_attribute_association]  WITH CHECK ADD  CONSTRAINT [FK_mftaa_K4_attribute_dictionary_K1] FOREIGN KEY([attribute_id])
REFERENCES [dbo].[attribute_dictionary] ([attribute_id])
ALTER TABLE [dbo].[master_file_template_attribute_association] CHECK CONSTRAINT [FK_mftaa_K4_attribute_dictionary_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaa_vva_K2_K3_mftmi_K1_K2'
			AND c.parent_object_id = OBJECT_ID('dbo.mftaa_valid_value_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mftaa_valid_value_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mftaa_vva_K2_K3_mftmi_K1_K2] FOREIGN KEY([master_file_template_id],[master_file_template_version])
REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_id],[master_file_template_version])
ALTER TABLE [dbo].[mftaa_valid_value_assoc] CHECK CONSTRAINT [FK_mftaa_vva_K2_K3_mftmi_K1_K2]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftaa_vva_K4_mftaa_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.mftaa_valid_value_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[mftaa_valid_value_assoc] WITH CHECK ADD CONSTRAINT [FK_mftaa_vva_K4_mftaa_K1] FOREIGN KEY([mftaa_id])
  REFERENCES [dbo].[master_file_template_attribute_association] ([mftaa_id])
  ALTER TABLE [dbo].[mftaa_valid_value_assoc] CHECK CONSTRAINT [FK_mftaa_vva_K4_mftaa_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftaa_vva_K5_valid_values_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.mftaa_valid_value_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[mftaa_valid_value_assoc] WITH CHECK ADD CONSTRAINT [FK_mftaa_vva_K5_valid_values_K1] FOREIGN KEY([valid_value_id])
  REFERENCES [dbo].[valid_values] ([valid_value_id])
  ALTER TABLE [dbo].[mftaa_valid_value_assoc] CHECK CONSTRAINT [FK_mftaa_vva_K5_valid_values_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaba_K2_mftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[master_file_template_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mftaba_K2_mftaa_K1] FOREIGN KEY([mftaa_id])
REFERENCES [dbo].[master_file_template_attribute_association] ([mftaa_id])
ALTER TABLE [dbo].[master_file_template_attr_br_assoc] CHECK CONSTRAINT [FK_mftaba_K2_mftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftaba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_attr_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[master_file_template_attr_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mftaba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
ALTER TABLE [dbo].[master_file_template_attr_br_assoc] CHECK CONSTRAINT [FK_mftaba_K3_dbrdt_K1]
END;
GO

 IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftsa_K2_template_sections_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[master_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_mftsa_K2_template_sections_K1] FOREIGN KEY([template_section_id])
  REFERENCES [dbo].[template_sections] ([template_section_id])
  ALTER TABLE [dbo].[master_file_template_section_assoc] CHECK CONSTRAINT [FK_mftsa_K2_template_sections_K1]
END;
GO

IF NOt EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftmi_K6_approval_status_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[master_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_mftmi_K6_approval_status_K1] FOREIGN KEY([approval_status_id])
REFERENCES [dbo].[approval_status] ([approval_status_id])
ALTER TABLE [dbo].[master_file_template_meta_info] CHECK CONSTRAINT [FK_mftmi_K6_approval_status_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mftmi_K4_file_type_meta_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_meta_info')
	)
BEGIN
ALTER TABLE [dbo].[master_file_template_meta_info]  WITH CHECK ADD  CONSTRAINT [FK_mftmi_K4_file_type_meta_info_K1] FOREIGN KEY([file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
ALTER TABLE [dbo].[master_file_template_meta_info] CHECK CONSTRAINT [FK_mftmi_K4_file_type_meta_info_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftsa_K13_mftmi_K15'
      AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[master_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_mftsa_K13_mftmi_K15] FOREIGN KEY([master_file_template_record_id])
  REFERENCES [dbo].[master_file_template_meta_info] (master_file_template_record_id)
  ALTER TABLE [dbo].[master_file_template_section_assoc] CHECK CONSTRAINT [FK_mftsa_K13_mftmi_K15]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_mftsa_K3_K4_mftmi_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.master_file_template_section_assoc')
  )
BEGIN
  ALTER TABLE [dbo].[master_file_template_section_assoc] WITH CHECK ADD CONSTRAINT [FK_mftsa_K3_K4_mftmi_K1] FOREIGN KEY([master_file_template_id],[master_file_template_version])
  REFERENCES [dbo].[master_file_template_meta_info] ([master_file_template_id],[master_file_template_version])
  ALTER TABLE [dbo].[master_file_template_section_assoc] CHECK CONSTRAINT [FK_mftsa_K3_K4_mftmi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsda_K3_mftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_dm_element_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsda_K3_mftaa_K1] FOREIGN KEY([mftaa_id])
REFERENCES [dbo].[master_file_template_attribute_association] (mftaa_id)
ALTER TABLE [dbo].[mtls_node_dm_element_assoc] CHECK CONSTRAINT [FK_mtlsda_K3_mftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsda_K2_mtlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_dm_element_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsda_K2_mtlsni_K1] FOREIGN KEY([mtlsni_id])
REFERENCES [dbo].[master_template_layout_schema_node_info] (mtlsni_id)
ALTER TABLE [dbo].[mtls_node_dm_element_assoc] CHECK CONSTRAINT [FK_mtlsda_K2_mtlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtaeva_K2_mtlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_enum_value_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_enum_value_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtaeva_K2_mtlsni_K1] FOREIGN KEY([mtlsni_id])
REFERENCES [dbo].[master_template_layout_schema_node_info] (mtlsni_id)
ALTER TABLE [dbo].[mtls_node_enum_value_assoc] CHECK CONSTRAINT [FK_mtaeva_K2_mtlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsna_K3_mtlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_template_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[master_template_layout_schema_node_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsna_K3_mtlsni_K1] FOREIGN KEY([parent_mtlsni_id])
REFERENCES [dbo].[master_template_layout_schema_node_info] (mtlsni_id)
ALTER TABLE [dbo].[master_template_layout_schema_node_assoc] CHECK CONSTRAINT [FK_mtlsna_K3_mtlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsnba_K2_mtlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsnba_K2_mtlsni_K1] FOREIGN KEY([mtlsni_id])
REFERENCES [dbo].[master_template_layout_schema_node_info] (mtlsni_id)
ALTER TABLE [dbo].[mtls_node_br_assoc] CHECK CONSTRAINT [FK_mtlsnba_K2_mtlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsnba_K3_dbrdt_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_br_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsnba_K3_dbrdt_K1] FOREIGN KEY([business_rule_id])
REFERENCES [dbo].[drools_business_rules_decision_table] (drools_business_rule_id)
ALTER TABLE [dbo].[mtls_node_br_assoc] CHECK CONSTRAINT [FK_mtlsnba_K3_dbrdt_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsna_K2_mtlsni_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_template_layout_schema_node_assoc')
	)
BEGIN
ALTER TABLE [dbo].[master_template_layout_schema_node_assoc]  WITH CHECK ADD  CONSTRAINT [FK_mtlsna_K2_mtlsni_K1] FOREIGN KEY([mtlsni_id])
REFERENCES [dbo].[master_template_layout_schema_node_info] (mtlsni_id)
ALTER TABLE [dbo].[master_template_layout_schema_node_assoc] CHECK CONSTRAINT [FK_mtlsna_K2_mtlsni_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsni_K14_template_sections_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[master_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_mtlsni_K14_template_sections_K1] FOREIGN KEY([mapped_template_section_id])
REFERENCES [dbo].[template_sections] (template_section_id)
ALTER TABLE [dbo].[master_template_layout_schema_node_info] CHECK CONSTRAINT [FK_mtlsni_K14_template_sections_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsni_K5_attribute_data_types_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.master_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[master_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_mtlsni_K5_attribute_data_types_K1] FOREIGN KEY([node_data_type_id])
REFERENCES [dbo].[attribute_data_types] (attribute_data_type_id)
ALTER TABLE [dbo].[master_template_layout_schema_node_info] CHECK CONSTRAINT [FK_mtlsni_K5_attribute_data_types_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsni_K2_mftmi_K15'
			AND c.parent_object_id = OBJECT_ID('dbo.master_template_layout_schema_node_info')
	)
BEGIN
ALTER TABLE [dbo].[master_template_layout_schema_node_info]  WITH CHECK ADD  CONSTRAINT [FK_mtlsni_K2_mftmi_K15] FOREIGN KEY([master_file_template_record_id])
REFERENCES [dbo].[master_file_template_meta_info] (master_file_template_record_id)
ALTER TABLE [dbo].[master_template_layout_schema_node_info] CHECK CONSTRAINT [FK_mtlsni_K2_mftmi_K15]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ntfta_K2_nti_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.notification_template_file_type_assoc')
	)
BEGIN
ALTER TABLE [dbo].[notification_template_file_type_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ntfta_K2_nti_K1] FOREIGN KEY([notification_template_id])
REFERENCES [dbo].[notification_template_info] ([template_id])
ALTER TABLE [dbo].[notification_template_file_type_assoc] CHECK CONSTRAINT [FK_ntfta_K2_nti_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ntfta_K4_ft_K3'
			AND c.parent_object_id = OBJECT_ID('dbo.notification_template_file_type_assoc')
	)
BEGIN
ALTER TABLE [dbo].[notification_template_file_type_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ntfta_K4_ft_K3] FOREIGN KEY([file_type_id])
REFERENCES [dbo].[file_type_meta_info] ([file_type_id])
ALTER TABLE [dbo].[notification_template_file_type_assoc] CHECK CONSTRAINT [FK_ntfta_K4_ft_K3]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_nti_K2_pse_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.notification_template_info')
	)
BEGIN
ALTER TABLE [dbo].[notification_template_info]  WITH CHECK ADD  CONSTRAINT [FK_nti_K2_pse_K1] FOREIGN KEY([event_id])
REFERENCES [dbo].[processing_system_events] ([event_id])
ALTER TABLE [dbo].[notification_template_info] CHECK CONSTRAINT [FK_nti_K2_pse_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_poi_K2_priority_classification_types_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.priority_order_info')
  )
BEGIN
  ALTER TABLE [dbo].[priority_order_info] WITH CHECK ADD CONSTRAINT [FK_poi_K2_priority_classification_types_K1] FOREIGN KEY([priority_class_type_id])
  REFERENCES [dbo].[priority_classification_types] ([priority_class_type_id])
  ALTER TABLE [dbo].[priority_order_info] CHECK CONSTRAINT [FK_poi_K2_priority_classification_types_K1]
END;
GO
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ridaa_K3_idis_db_func_actions_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.roles_idis_dbrd_actions_assoc')
	)
BEGIN
ALTER TABLE [dbo].[roles_idis_dbrd_actions_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ridaa_K3_idis_db_func_actions_K1] FOREIGN KEY([action_id])
REFERENCES [dbo].[idis_dbrd_func_actions] ([action_id])
ALTER TABLE [dbo].[roles_idis_dbrd_actions_assoc] CHECK CONSTRAINT [FK_ridaa_K3_idis_db_func_actions_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ridaa_K2_roles_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.roles_idis_dbrd_actions_assoc')
	)
BEGIN
ALTER TABLE [dbo].[roles_idis_dbrd_actions_assoc]  WITH CHECK ADD  CONSTRAINT [FK_ridaa_K2_roles_K1] FOREIGN KEY([role_id])
REFERENCES [dbo].[roles] ([role_id])
ALTER TABLE [dbo].[roles_idis_dbrd_actions_assoc] CHECK CONSTRAINT [FK_ridaa_K2_roles_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpakd_K1_tpaki_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_auth_key_details')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_auth_key_details]
		WITH CHECK ADD CONSTRAINT [FK_tpakd_K1_tpaki_K1] FOREIGN KEY ([trading_partner_auth_key_info_id]) REFERENCES [dbo].[trading_partner_auth_key_info]([trading_partner_auth_key_info_id])

	ALTER TABLE [dbo].[trading_partner_auth_key_details] CHECK CONSTRAINT [FK_tpakd_K1_tpaki_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpaki_K1_tpi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_auth_key_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_auth_key_info]
		WITH CHECK ADD CONSTRAINT [FK_tpaki_K1_tpi_K1] FOREIGN KEY ([trading_partner_id]) REFERENCES [dbo].[trading_partner_info]([trading_partner_id])

	ALTER TABLE [dbo].[trading_partner_auth_key_info] CHECK CONSTRAINT [FK_tpaki_K1_tpi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpaki_K2_tppi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_auth_key_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_auth_key_info]  WITH NOCHECK ADD  CONSTRAINT [FK_tpaki_K2_tppi_K1] FOREIGN KEY([trading_partner_platform_id])
	REFERENCES [dbo].[trading_partner_platform_info] ([trading_partner_platform_id])

	ALTER TABLE [dbo].[trading_partner_auth_key_info] NOCHECK CONSTRAINT [FK_tpaki_K2_tppi_K1]

END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K2_trading_partner_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_connection_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_connection_info]
		WITH CHECK ADD CONSTRAINT [FK_tpci_K2_trading_partner_info_K1] FOREIGN KEY ([trading_partner_id]) REFERENCES [dbo].[trading_partner_info]([trading_partner_id])

	ALTER TABLE [dbo].[trading_partner_connection_info] CHECK CONSTRAINT [FK_tpci_K2_trading_partner_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K3_trading_partner_platform_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_connection_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_connection_info]  WITH NOCHECK ADD  CONSTRAINT [FK_tpci_K3_trading_partner_platform_K1] FOREIGN KEY([trading_partner_platform_id])
	REFERENCES [dbo].[trading_partner_platform_info] ([trading_partner_platform_id])

	ALTER TABLE [dbo].[trading_partner_connection_info] NOCHECK CONSTRAINT [FK_tpci_K3_trading_partner_platform_K1]

END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K7_transfer_protocol_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_connection_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_connection_info]
		WITH CHECK ADD CONSTRAINT [FK_tpci_K7_transfer_protocol_info_K1] FOREIGN KEY ([tpci_transfer_protocol_id]) REFERENCES [dbo].[transfer_protocol_info]([transfer_protocol_id])

	ALTER TABLE [dbo].[trading_partner_connection_info] CHECK CONSTRAINT [FK_tpci_K7_transfer_protocol_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K11_trading_partner_contact_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_connection_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_connection_info]
		WITH CHECK ADD CONSTRAINT [FK_tpci_K11_trading_partner_contact_info_K1] FOREIGN KEY ([tpci_contact_id]) REFERENCES [dbo].[trading_partner_contact_info]([trading_partner_contact_id])

	ALTER TABLE [dbo].[trading_partner_connection_info] CHECK CONSTRAINT [FK_tpci_K11_trading_partner_contact_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K13_trading_partner_contact_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_contact_info')
	)
BEGIN
ALTER TABLE [dbo].[trading_partner_contact_info]  WITH CHECK ADD  CONSTRAINT [FK_tpci_K13_trading_partner_contact_type_K1] FOREIGN KEY([trading_partner_contact_type_id])
REFERENCES [dbo].[trading_partner_contact_type] ([trading_partner_contact_type_id])
ALTER TABLE [dbo].[trading_partner_contact_info] CHECK CONSTRAINT [FK_tpci_K13_trading_partner_contact_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpci_K6_delivery_mechanism_type_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_connection_info')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_connection_info]
		WITH CHECK ADD CONSTRAINT [FK_tpci_K6_delivery_mechanism_type_K1] FOREIGN KEY ([tpci_delivery_mechanism_type_id]) REFERENCES [dbo].[delivery_mechanism_type]([delivery_mechanism_type_id])

	ALTER TABLE [dbo].[trading_partner_connection_info] CHECK CONSTRAINT [FK_tpci_K6_delivery_mechanism_type_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpcta_K3_trading_partner_contact_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_contact_tpp_assoc')
	)
BEGIN
ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc]  WITH CHECK ADD  CONSTRAINT [FK_tpcta_K3_trading_partner_contact_info_K1] FOREIGN KEY([trading_partner_contact_id])
REFERENCES [dbo].[trading_partner_contact_info] ([trading_partner_contact_id])
ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc] CHECK CONSTRAINT [FK_tpcta_K3_trading_partner_contact_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpla_K2_trading_partner_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_lob_association')
	)
	BEGIN
ALTER TABLE [dbo].[trading_partner_lob_association]  WITH CHECK ADD  CONSTRAINT [FK_tpla_K2_trading_partner_info_K1] FOREIGN KEY([trading_partner_id])
REFERENCES [dbo].[trading_partner_info] ([trading_partner_id])
ALTER TABLE [dbo].[trading_partner_lob_association] CHECK CONSTRAINT [FK_tpla_K2_trading_partner_info_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ttmi_K2_awp_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.tooltip_meta_info')
		)
BEGIN
	ALTER TABLE [dbo].[tooltip_meta_info]
		WITH CHECK ADD CONSTRAINT [FK_ttmi_K2_awp_K1] FOREIGN KEY ([tooltip_field_id]) REFERENCES [dbo].[adapt_web_page_fields]([adapt_web_page_field_id])

	ALTER TABLE [dbo].[tooltip_meta_info] CHECK CONSTRAINT [FK_ttmi_K2_awp_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ufa_K2_jd_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.upload_file_audit')
		)
BEGIN
	ALTER TABLE [dbo].[upload_file_audit]
		WITH CHECK ADD CONSTRAINT [FK_ufa_K2_jd_K1] FOREIGN KEY ([job_id]) REFERENCES [dbo].[job_details]([job_id])

	ALTER TABLE [dbo].[upload_file_audit] CHECK CONSTRAINT [FK_ufa_K2_jd_K1]
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys c
    WHERE name = 'FK_tppi_K2_tpi_K1'
      AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_platform_info')
  )
  BEGIN
  ALTER TABLE [dbo].[trading_partner_platform_info] WITH CHECK ADD CONSTRAINT [FK_tppi_K2_tpi_K1] FOREIGN KEY([trading_partner_id])
  REFERENCES [dbo].[trading_partner_info] ([trading_partner_id])
  ALTER TABLE [dbo].[trading_partner_platform_info] CHECK CONSTRAINT [FK_tppi_K2_tpi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_vv_K4_valid_value_groups_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.valid_values')
	)
BEGIN
ALTER TABLE [dbo].[valid_values] WITH CHECK ADD CONSTRAINT [FK_vv_K4_valid_value_groups_K1] FOREIGN KEY([valid_value_group_id])
REFERENCES [dbo].[valid_value_groups] ([valid_value_group_id])
ALTER TABLE [dbo].[valid_values] CHECK CONSTRAINT [FK_vv_K4_valid_value_groups_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_vvg_K4_validation_types_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.valid_value_groups')
	)
BEGIN
ALTER TABLE [dbo].[valid_value_groups] WITH CHECK ADD CONSTRAINT [FK_vvg_K4_validation_types_K1] FOREIGN KEY([validation_type_id])
REFERENCES [dbo].[validation_types] ([validation_type_id])
ALTER TABLE [dbo].[valid_value_groups] CHECK CONSTRAINT [FK_vvg_K4_validation_types_K1]
END;
GO



IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpla_K3_lob_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_lob_association')
	)
	BEGIN
ALTER TABLE [dbo].[trading_partner_lob_association]  WITH CHECK ADD  CONSTRAINT [FK_tpla_K3_lob_K1] FOREIGN KEY([lob_id])
REFERENCES [dbo].[lob] ([lob_id])
ALTER TABLE [dbo].[trading_partner_lob_association] CHECK CONSTRAINT [FK_tpla_K3_lob_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpcta_K2_trading_partner_platform_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_contact_tpp_assoc')
	)
BEGIN
ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc]  WITH CHECK ADD  CONSTRAINT [FK_tpcta_K2_trading_partner_platform_info_K1] FOREIGN KEY([trading_partner_platform_id])
REFERENCES [dbo].[trading_partner_platform_info] ([trading_partner_platform_id])
ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc] CHECK CONSTRAINT [FK_tpcta_K2_trading_partner_platform_info_K1]
END;
GO



