USE [idis-metainfo]

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

/*

Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-05-21	Jinesh vora		ADAPT-3922: Dashboard column header Change - ADaPT ID should be File ID

*/
-- check if table exists:
IF (OBJECT_ID ('idis-metainfo.dbo.adapt_web_pages') IS not NULL AND OBJECT_ID ('idis-metainfo.dbo.adapt_web_page_fields') IS not NULL
AND (SELECT count(1) FROM [idis-metainfo].dbo.adapt_web_pages where adapt_web_pages_name in ('Dashboard','Held Files')) > 0 
AND (SELECT count(1) FROM [idis-metainfo].dbo.adapt_web_page_fields) > 0)

BEGIN

Update adapt_web_page_fields 
SET adapt_web_page_field_name = 'File ID',adapt_web_page_field_desc = 'File ID'
where adapt_web_page_field_id in
(SELECT awpf.adapt_web_page_field_id FROM adapt_web_page_fields awpf where awpf.adapt_web_page_id in 
(SELECT adapt_web_page_id FROM adapt_web_pages where adapt_web_pages_name in ('Dashboard','Held Files')) 
and adapt_web_page_field_name = 'Adapt Id');

END;
GO
