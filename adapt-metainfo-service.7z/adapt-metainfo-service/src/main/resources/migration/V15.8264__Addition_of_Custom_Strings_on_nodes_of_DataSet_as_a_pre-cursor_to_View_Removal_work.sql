USE [idis-metainfo]
GO
/*
Filename:  V15.8264__Addition_of_Custom_Strings_on_nodes_of_DataSet_as_a_pre-cursor_to_View_Removal_work.sql

Update Log
Date         Author            	Description
----------   ----------------   -----------------------------------------------------------------------------------------------
2019-10-25   Pravin Rajput		ADAPT-8264 : Addition of Custom Strings on nodes of DataSet as a pre-cursor to View Removal work
*/

/*
DB Entry for Covered Dependent -- coveredDependents
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 1025 and attribute_name = 'Covered Dependent Custom Defined1')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1025,'Covered Dependent Custom Defined1','PRE-DEFINED :: Covered Dependent Custom Defined1','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1026 and attribute_name = 'Covered Dependent Custom Defined2')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1026,'Covered Dependent Custom Defined2','PRE-DEFINED :: Covered Dependent Custom Defined2','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1027 and attribute_name = 'Covered Dependent Custom Defined3')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1027,'Covered Dependent Custom Defined3','PRE-DEFINED :: Covered Dependent Custom Defined3','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1028 and attribute_name = 'Covered Dependent Custom Defined4')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1028,'Covered Dependent Custom Defined4','PRE-DEFINED :: Covered Dependent Custom Defined4','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1029 and attribute_name = 'Covered Dependent Custom Defined5')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1029,'Covered Dependent Custom Defined5','PRE-DEFINED :: Covered Dependent Custom Defined5','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1030 and attribute_name = 'Covered Dependent Custom Defined6')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1030,'Covered Dependent Custom Defined6','PRE-DEFINED :: Covered Dependent Custom Defined6','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1031 and attribute_name = 'Covered Dependent Custom Defined7')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1031,'Covered Dependent Custom Defined7','PRE-DEFINED :: Covered Dependent Custom Defined7','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1032 and attribute_name = 'Covered Dependent Custom Defined8')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1032,'Covered Dependent Custom Defined8','PRE-DEFINED :: Covered Dependent Custom Defined8','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1033 and attribute_name = 'Covered Dependent Custom Defined9')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1033,'Covered Dependent Custom Defined9','PRE-DEFINED :: Covered Dependent Custom Defined9','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1034 and attribute_name = 'Covered Dependent Custom Defined10')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1034,'Covered Dependent Custom Defined10','PRE-DEFINED :: Covered Dependent Custom Defined10','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1035 and attribute_name = 'Covered Dependent Custom Defined11')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1035,'Covered Dependent Custom Defined11','PRE-DEFINED :: Covered Dependent Custom Defined11','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1036 and attribute_name = 'Covered Dependent Custom Defined12')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1036,'Covered Dependent Custom Defined12','PRE-DEFINED :: Covered Dependent Custom Defined12','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1037 and attribute_name = 'Covered Dependent Custom Defined13')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1037,'Covered Dependent Custom Defined13','PRE-DEFINED :: Covered Dependent Custom Defined13','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1038 and attribute_name = 'Covered Dependent Custom Defined14')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1038,'Covered Dependent Custom Defined14','PRE-DEFINED :: Covered Dependent Custom Defined14','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1039 and attribute_name = 'Covered Dependent Custom Defined15')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1039,'Covered Dependent Custom Defined15','PRE-DEFINED :: Covered Dependent Custom Defined15','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1040 and attribute_name = 'Covered Dependent Custom Defined16')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1040,'Covered Dependent Custom Defined16','PRE-DEFINED :: Covered Dependent Custom Defined16','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1041 and attribute_name = 'Covered Dependent Custom Defined17')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1041,'Covered Dependent Custom Defined17','PRE-DEFINED :: Covered Dependent Custom Defined17','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1042 and attribute_name = 'Covered Dependent Custom Defined18')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1042,'Covered Dependent Custom Defined18','PRE-DEFINED :: Covered Dependent Custom Defined18','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1043 and attribute_name = 'Covered Dependent Custom Defined19')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1043,'Covered Dependent Custom Defined19','PRE-DEFINED :: Covered Dependent Custom Defined19','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1044 and attribute_name = 'Covered Dependent Custom Defined20')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1044,'Covered Dependent Custom Defined20','PRE-DEFINED :: Covered Dependent Custom Defined20','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1045 and attribute_name = 'Covered Dependent Custom Defined21')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1045,'Covered Dependent Custom Defined21','PRE-DEFINED :: Covered Dependent Custom Defined21','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1046 and attribute_name = 'Covered Dependent Custom Defined22')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1046,'Covered Dependent Custom Defined22','PRE-DEFINED :: Covered Dependent Custom Defined22','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1047 and attribute_name = 'Covered Dependent Custom Defined23')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1047,'Covered Dependent Custom Defined23','PRE-DEFINED :: Covered Dependent Custom Defined23','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1048 and attribute_name = 'Covered Dependent Custom Defined24')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1048,'Covered Dependent Custom Defined24','PRE-DEFINED :: Covered Dependent Custom Defined24','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1049 and attribute_name = 'Covered Dependent Custom Defined25')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1049,'Covered Dependent Custom Defined25','PRE-DEFINED :: Covered Dependent Custom Defined25','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1050 and attribute_name = 'Covered Dependent Custom Defined26')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1050,'Covered Dependent Custom Defined26','PRE-DEFINED :: Covered Dependent Custom Defined26','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1051 and attribute_name = 'Covered Dependent Custom Defined27')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1051,'Covered Dependent Custom Defined27','PRE-DEFINED :: Covered Dependent Custom Defined27','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1052 and attribute_name = 'Covered Dependent Custom Defined28')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1052,'Covered Dependent Custom Defined28','PRE-DEFINED :: Covered Dependent Custom Defined28','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1053 and attribute_name = 'Covered Dependent Custom Defined29')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1053,'Covered Dependent Custom Defined29','PRE-DEFINED :: Covered Dependent Custom Defined29','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1054 and attribute_name = 'Covered Dependent Custom Defined30')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1054,'Covered Dependent Custom Defined30','PRE-DEFINED :: Covered Dependent Custom Defined30','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1055 and attribute_name = 'Covered Dependent Custom Defined31')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1055,'Covered Dependent Custom Defined31','PRE-DEFINED :: Covered Dependent Custom Defined31','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1056 and attribute_name = 'Covered Dependent Custom Defined32')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1056,'Covered Dependent Custom Defined32','PRE-DEFINED :: Covered Dependent Custom Defined32','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1057 and attribute_name = 'Covered Dependent Custom Defined33')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1057,'Covered Dependent Custom Defined33','PRE-DEFINED :: Covered Dependent Custom Defined33','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1058 and attribute_name = 'Covered Dependent Custom Defined34')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1058,'Covered Dependent Custom Defined34','PRE-DEFINED :: Covered Dependent Custom Defined34','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1059 and attribute_name = 'Covered Dependent Custom Defined35')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1059,'Covered Dependent Custom Defined35','PRE-DEFINED :: Covered Dependent Custom Defined35','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1060 and attribute_name = 'Covered Dependent Custom Defined36')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1060,'Covered Dependent Custom Defined36','PRE-DEFINED :: Covered Dependent Custom Defined36','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1061 and attribute_name = 'Covered Dependent Custom Defined37')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1061,'Covered Dependent Custom Defined37','PRE-DEFINED :: Covered Dependent Custom Defined37','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1062 and attribute_name = 'Covered Dependent Custom Defined38')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1062,'Covered Dependent Custom Defined38','PRE-DEFINED :: Covered Dependent Custom Defined38','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1063 and attribute_name = 'Covered Dependent Custom Defined39')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1063,'Covered Dependent Custom Defined39','PRE-DEFINED :: Covered Dependent Custom Defined39','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1064 and attribute_name = 'Covered Dependent Custom Defined40')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1064,'Covered Dependent Custom Defined40','PRE-DEFINED :: Covered Dependent Custom Defined40','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4699 and file_type_id = 17 and attribute_id = 1025)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4699,17,1025,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined1',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4700 and file_type_id = 17 and attribute_id = 1026)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4700,17,1026,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined2',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4701 and file_type_id = 17 and attribute_id = 1027)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4701,17,1027,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined3',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4702 and file_type_id = 17 and attribute_id = 1028)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4702,17,1028,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined4',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4703 and file_type_id = 17 and attribute_id = 1029)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4703,17,1029,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined5',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4704 and file_type_id = 17 and attribute_id = 1030)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4704,17,1030,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined6',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4705 and file_type_id = 17 and attribute_id = 1031)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4705,17,1031,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined7',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4706 and file_type_id = 17 and attribute_id = 1032)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4706,17,1032,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined8',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4707 and file_type_id = 17 and attribute_id = 1033)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4707,17,1033,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined9',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4708 and file_type_id = 17 and attribute_id = 1034)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4708,17,1034,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined10',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4709 and file_type_id = 17 and attribute_id = 1035)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4709,17,1035,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined11',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4710 and file_type_id = 17 and attribute_id = 1036)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4710,17,1036,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined12',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4711 and file_type_id = 17 and attribute_id = 1037)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4711,17,1037,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined13',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4712 and file_type_id = 17 and attribute_id = 1038)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4712,17,1038,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined14',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4713 and file_type_id = 17 and attribute_id = 1039)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4713,17,1039,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined15',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4714 and file_type_id = 17 and attribute_id = 1040)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4714,17,1040,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined16',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4715 and file_type_id = 17 and attribute_id = 1041)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4715,17,1041,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined17',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4716 and file_type_id = 17 and attribute_id = 1042)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4716,17,1042,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined18',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4717 and file_type_id = 17 and attribute_id = 1043)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4717,17,1043,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined19',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4718 and file_type_id = 17 and attribute_id = 1044)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4718,17,1044,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined20',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4719 and file_type_id = 17 and attribute_id = 1045)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4719,17,1045,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined21',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4720 and file_type_id = 17 and attribute_id = 1046)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4720,17,1046,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined22',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4721 and file_type_id = 17 and attribute_id = 1047)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4721,17,1047,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined23',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4722 and file_type_id = 17 and attribute_id = 1048)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4722,17,1048,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined24',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4723 and file_type_id = 17 and attribute_id = 1049)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4723,17,1049,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined25',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4724 and file_type_id = 17 and attribute_id = 1050)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4724,17,1050,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined26',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4725 and file_type_id = 17 and attribute_id = 1051)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4725,17,1051,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined27',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4726 and file_type_id = 17 and attribute_id = 1052)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4726,17,1052,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined28',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4727 and file_type_id = 17 and attribute_id = 1053)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4727,17,1053,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined29',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4728 and file_type_id = 17 and attribute_id = 1054)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4728,17,1054,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined30',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4729 and file_type_id = 17 and attribute_id = 1055)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4729,17,1055,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined31',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4730 and file_type_id = 17 and attribute_id = 1056)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4730,17,1056,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined32',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4731 and file_type_id = 17 and attribute_id = 1057)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4731,17,1057,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined33',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4732 and file_type_id = 17 and attribute_id = 1058)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4732,17,1058,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined34',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4733 and file_type_id = 17 and attribute_id = 1059)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4733,17,1059,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined35',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4734 and file_type_id = 17 and attribute_id = 1060)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4734,17,1060,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined36',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4735 and file_type_id = 17 and attribute_id = 1061)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4735,17,1061,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined37',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4736 and file_type_id = 17 and attribute_id = 1062)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4736,17,1062,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined38',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4737 and file_type_id = 17 and attribute_id = 1063)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4737,17,1063,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined39',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4738 and file_type_id = 17 and attribute_id = 1064)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4738,17,1064,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'coveredDependents.customDefined40',66)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2163 and master_file_template_record_id = 18 and attribute_id = 1025)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2163,18,1,1025,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4699,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2164 and master_file_template_record_id = 18 and attribute_id = 1026)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2164,18,1,1026,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4700,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2165 and master_file_template_record_id = 18 and attribute_id = 1027)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2165,18,1,1027,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4701,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2166 and master_file_template_record_id = 18 and attribute_id = 1028)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2166,18,1,1028,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4702,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2167 and master_file_template_record_id = 18 and attribute_id = 1029)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2167,18,1,1029,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4703,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2168 and master_file_template_record_id = 18 and attribute_id = 1030)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2168,18,1,1030,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4704,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2169 and master_file_template_record_id = 18 and attribute_id = 1031)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2169,18,1,1031,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4705,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2170 and master_file_template_record_id = 18 and attribute_id = 1032)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2170,18,1,1032,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4706,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2171 and master_file_template_record_id = 18 and attribute_id = 1033)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2171,18,1,1033,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4707,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2172 and master_file_template_record_id = 18 and attribute_id = 1034)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2172,18,1,1034,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4708,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2173 and master_file_template_record_id = 18 and attribute_id = 1035)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2173,18,1,1035,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4709,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2174 and master_file_template_record_id = 18 and attribute_id = 1036)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2174,18,1,1036,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4710,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2175 and master_file_template_record_id = 18 and attribute_id = 1037)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2175,18,1,1037,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4711,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2176 and master_file_template_record_id = 18 and attribute_id = 1038)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2176,18,1,1038,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4712,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2177 and master_file_template_record_id = 18 and attribute_id = 1039)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2177,18,1,1039,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4713,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2178 and master_file_template_record_id = 18 and attribute_id = 1040)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2178,18,1,1040,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4714,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2179 and master_file_template_record_id = 18 and attribute_id = 1041)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2179,18,1,1041,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4715,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2180 and master_file_template_record_id = 18 and attribute_id = 1042)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2180,18,1,1042,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4716,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2181 and master_file_template_record_id = 18 and attribute_id = 1043)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2181,18,1,1043,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4717,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2182 and master_file_template_record_id = 18 and attribute_id = 1044)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2182,18,1,1044,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4718,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2183 and master_file_template_record_id = 18 and attribute_id = 1045)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2183,18,1,1045,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4719,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2184 and master_file_template_record_id = 18 and attribute_id = 1046)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2184,18,1,1046,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4720,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2185 and master_file_template_record_id = 18 and attribute_id = 1047)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2185,18,1,1047,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4721,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2186 and master_file_template_record_id = 18 and attribute_id = 1048)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2186,18,1,1048,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4722,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2187 and master_file_template_record_id = 18 and attribute_id = 1049)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2187,18,1,1049,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4723,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2188 and master_file_template_record_id = 18 and attribute_id = 1050)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2188,18,1,1050,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4724,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2189 and master_file_template_record_id = 18 and attribute_id = 1051)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2189,18,1,1051,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4725,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2190 and master_file_template_record_id = 18 and attribute_id = 1052)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2190,18,1,1052,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4726,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2191 and master_file_template_record_id = 18 and attribute_id = 1053)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2191,18,1,1053,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4727,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2192 and master_file_template_record_id = 18 and attribute_id = 1054)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2192,18,1,1054,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4728,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2193 and master_file_template_record_id = 18 and attribute_id = 1055)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2193,18,1,1055,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4729,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2194 and master_file_template_record_id = 18 and attribute_id = 1056)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2194,18,1,1056,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4730,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2195 and master_file_template_record_id = 18 and attribute_id = 1057)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2195,18,1,1057,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4731,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2196 and master_file_template_record_id = 18 and attribute_id = 1058)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2196,18,1,1058,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4732,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2197 and master_file_template_record_id = 18 and attribute_id = 1059)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2197,18,1,1059,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4733,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2198 and master_file_template_record_id = 18 and attribute_id = 1060)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2198,18,1,1060,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4734,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2199 and master_file_template_record_id = 18 and attribute_id = 1061)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2199,18,1,1061,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4735,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2200 and master_file_template_record_id = 18 and attribute_id = 1062)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2200,18,1,1062,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4736,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2201 and master_file_template_record_id = 18 and attribute_id = 1063)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2201,18,1,1063,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4737,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2202 and master_file_template_record_id = 18 and attribute_id = 1064)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2202,18,1,1064,'VARCHAR',0,NULL,NULL,81,'Pravin Rajput',getDate(),18,50,4738,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

/*
DB Entry for Election -- elections
*/
if not exists (select 1 from attribute_dictionary where attribute_id = 1065 and attribute_name = 'Election Custom Defined1')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1065,'Election Custom Defined1','PRE-DEFINED :: Election Custom Defined1','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1066 and attribute_name = 'Election Custom Defined2')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1066,'Election Custom Defined2','PRE-DEFINED :: Election Custom Defined2','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1067 and attribute_name = 'Election Custom Defined3')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1067,'Election Custom Defined3','PRE-DEFINED :: Election Custom Defined3','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1068 and attribute_name = 'Election Custom Defined4')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1068,'Election Custom Defined4','PRE-DEFINED :: Election Custom Defined4','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1069 and attribute_name = 'Election Custom Defined5')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1069,'Election Custom Defined5','PRE-DEFINED :: Election Custom Defined5','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1070 and attribute_name = 'Election Custom Defined6')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1070,'Election Custom Defined6','PRE-DEFINED :: Election Custom Defined6','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1071 and attribute_name = 'Election Custom Defined7')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1071,'Election Custom Defined7','PRE-DEFINED :: Election Custom Defined7','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1072 and attribute_name = 'Election Custom Defined8')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1072,'Election Custom Defined8','PRE-DEFINED :: Election Custom Defined8','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1073 and attribute_name = 'Election Custom Defined9')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1073,'Election Custom Defined9','PRE-DEFINED :: Election Custom Defined9','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1074 and attribute_name = 'Election Custom Defined10')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1074,'Election Custom Defined10','PRE-DEFINED :: Election Custom Defined10','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1075 and attribute_name = 'Election Custom Defined11')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1075,'Election Custom Defined11','PRE-DEFINED :: Election Custom Defined11','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1076 and attribute_name = 'Election Custom Defined12')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1076,'Election Custom Defined12','PRE-DEFINED :: Election Custom Defined12','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1077 and attribute_name = 'Election Custom Defined13')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1077,'Election Custom Defined13','PRE-DEFINED :: Election Custom Defined13','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1078 and attribute_name = 'Election Custom Defined14')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1078,'Election Custom Defined14','PRE-DEFINED :: Election Custom Defined14','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1079 and attribute_name = 'Election Custom Defined15')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1079,'Election Custom Defined15','PRE-DEFINED :: Election Custom Defined15','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1080 and attribute_name = 'Election Custom Defined16')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1080,'Election Custom Defined16','PRE-DEFINED :: Election Custom Defined16','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1081 and attribute_name = 'Election Custom Defined17')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1081,'Election Custom Defined17','PRE-DEFINED :: Election Custom Defined17','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1082 and attribute_name = 'Election Custom Defined18')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1082,'Election Custom Defined18','PRE-DEFINED :: Election Custom Defined18','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1083 and attribute_name = 'Election Custom Defined19')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1083,'Election Custom Defined19','PRE-DEFINED :: Election Custom Defined19','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1084 and attribute_name = 'Election Custom Defined20')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1084,'Election Custom Defined20','PRE-DEFINED :: Election Custom Defined20','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1085 and attribute_name = 'Election Custom Defined21')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1085,'Election Custom Defined21','PRE-DEFINED :: Election Custom Defined21','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1086 and attribute_name = 'Election Custom Defined22')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1086,'Election Custom Defined22','PRE-DEFINED :: Election Custom Defined22','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1087 and attribute_name = 'Election Custom Defined23')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1087,'Election Custom Defined23','PRE-DEFINED :: Election Custom Defined23','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1088 and attribute_name = 'Election Custom Defined24')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1088,'Election Custom Defined24','PRE-DEFINED :: Election Custom Defined24','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1089 and attribute_name = 'Election Custom Defined25')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1089,'Election Custom Defined25','PRE-DEFINED :: Election Custom Defined25','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1090 and attribute_name = 'Election Custom Defined26')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1090,'Election Custom Defined26','PRE-DEFINED :: Election Custom Defined26','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1091 and attribute_name = 'Election Custom Defined27')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1091,'Election Custom Defined27','PRE-DEFINED :: Election Custom Defined27','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1092 and attribute_name = 'Election Custom Defined28')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1092,'Election Custom Defined28','PRE-DEFINED :: Election Custom Defined28','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1093 and attribute_name = 'Election Custom Defined29')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1093,'Election Custom Defined29','PRE-DEFINED :: Election Custom Defined29','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO


if not exists (select 1 from attribute_dictionary where attribute_id = 1094 and attribute_name = 'Election Custom Defined30')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1094,'Election Custom Defined30','PRE-DEFINED :: Election Custom Defined30','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1095 and attribute_name = 'Election Custom Defined31')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1095,'Election Custom Defined31','PRE-DEFINED :: Election Custom Defined31','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1096 and attribute_name = 'Election Custom Defined32')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1096,'Election Custom Defined32','PRE-DEFINED :: Election Custom Defined32','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1097 and attribute_name = 'Election Custom Defined33')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1097,'Election Custom Defined33','PRE-DEFINED :: Election Custom Defined33','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1098 and attribute_name = 'Election Custom Defined34')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1098,'Election Custom Defined34','PRE-DEFINED :: Election Custom Defined34','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1099 and attribute_name = 'Election Custom Defined35')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1099,'Election Custom Defined35','PRE-DEFINED :: Election Custom Defined35','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2000 and attribute_name = 'Election Custom Defined36')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2000,'Election Custom Defined36','PRE-DEFINED :: Election Custom Defined36','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2001 and attribute_name = 'Election Custom Defined37')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2001,'Election Custom Defined37','PRE-DEFINED :: Election Custom Defined37','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2002 and attribute_name = 'Election Custom Defined38')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2002,'Election Custom Defined38','PRE-DEFINED :: Election Custom Defined38','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2003 and attribute_name = 'Election Custom Defined39')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2003,'Election Custom Defined39','PRE-DEFINED :: Election Custom Defined39','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2004 and attribute_name = 'Election Custom Defined40')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2004,'Election Custom Defined40','PRE-DEFINED :: Election Custom Defined40','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4739 and file_type_id = 17 and attribute_id = 1065)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4739,17,1065,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined1',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4740 and file_type_id = 17 and attribute_id = 1066)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4740,17,1066,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined2',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4741 and file_type_id = 17 and attribute_id = 1067)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4741,17,1067,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined3',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4742 and file_type_id = 17 and attribute_id = 1068)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4742,17,1068,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined4',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4743 and file_type_id = 17 and attribute_id = 1069)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4743,17,1069,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined5',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4744 and file_type_id = 17 and attribute_id = 1070)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4744,17,1070,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined6',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4745 and file_type_id = 17 and attribute_id = 1071)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4745,17,1071,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined7',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4746 and file_type_id = 17 and attribute_id = 1072)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4746,17,1072,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined8',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4747 and file_type_id = 17 and attribute_id = 1073)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4747,17,1073,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined9',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4748 and file_type_id = 17 and attribute_id = 1074)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4748,17,1074,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined10',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4749 and file_type_id = 17 and attribute_id = 1075)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4749,17,1075,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined11',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4750 and file_type_id = 17 and attribute_id = 1076)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4750,17,1076,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined12',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4751 and file_type_id = 17 and attribute_id = 1077)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4751,17,1077,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined13',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4752 and file_type_id = 17 and attribute_id = 1078)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4752,17,1078,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined14',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4753 and file_type_id = 17 and attribute_id = 1079)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4753,17,1079,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined15',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4754 and file_type_id = 17 and attribute_id = 1080)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4754,17,1080,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined16',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4755 and file_type_id = 17 and attribute_id = 1081)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4755,17,1081,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined17',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4756 and file_type_id = 17 and attribute_id = 1082)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4756,17,1082,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined18',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4757 and file_type_id = 17 and attribute_id = 1083)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4757,17,1083,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined19',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4758 and file_type_id = 17 and attribute_id = 1084)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4758,17,1084,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined20',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4759 and file_type_id = 17 and attribute_id = 1085)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4759,17,1085,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined21',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4760 and file_type_id = 17 and attribute_id = 1086)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4760,17,1086,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined22',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4761 and file_type_id = 17 and attribute_id = 1087)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4761,17,1087,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined23',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4762 and file_type_id = 17 and attribute_id = 1088)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4762,17,1088,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined24',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4763 and file_type_id = 17 and attribute_id = 1089)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4763,17,1089,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined25',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4764 and file_type_id = 17 and attribute_id = 1090)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4764,17,1090,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined26',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4765 and file_type_id = 17 and attribute_id = 1091)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4765,17,1091,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined27',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4766 and file_type_id = 17 and attribute_id = 1092)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4766,17,1092,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined28',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4767 and file_type_id = 17 and attribute_id = 1093)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4767,17,1093,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined29',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4768 and file_type_id = 17 and attribute_id = 1094)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4768,17,1094,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined30',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4769 and file_type_id = 17 and attribute_id = 1095)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4769,17,1095,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined31',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO
if not exists (select 1 from file_type_attribute_association where ftaa_id = 4770 and file_type_id = 17 and attribute_id = 1096)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4770,17,1096,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined32',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4771 and file_type_id = 17 and attribute_id = 1097)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4771,17,1097,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined33',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4772 and file_type_id = 17 and attribute_id = 1098)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4772,17,1098,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined34',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4773 and file_type_id = 17 and attribute_id = 1099)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4773,17,1099,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined35',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4774 and file_type_id = 17 and attribute_id = 2000)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4774,17,2000,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined36',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4775 and file_type_id = 17 and attribute_id = 2001)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4775,17,2001,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined37',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4776 and file_type_id = 17 and attribute_id = 2002)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4776,17,2002,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined38',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4777 and file_type_id = 17 and attribute_id = 2003)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4777,17,2003,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined39',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4778 and file_type_id = 17 and attribute_id = 2004)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4778,17,2004,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'elections.customDefined40',7)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2203 and master_file_template_record_id = 18 and attribute_id = 1065)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2203,18,1,1065,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4739,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2204 and master_file_template_record_id = 18 and attribute_id = 1066)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2204,18,1,1066,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4740,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2205 and master_file_template_record_id = 18 and attribute_id = 1067)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2205,18,1,1067,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4741,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2206 and master_file_template_record_id = 18 and attribute_id = 1068)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2206,18,1,1068,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4742,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2207 and master_file_template_record_id = 18 and attribute_id = 1069)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2207,18,1,1069,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4743,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2208 and master_file_template_record_id = 18 and attribute_id = 1070)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2208,18,1,1070,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4744,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2209 and master_file_template_record_id = 18 and attribute_id = 1071)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2209,18,1,1071,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4745,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2210 and master_file_template_record_id = 18 and attribute_id = 1072)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2210,18,1,1072,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4746,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2211 and master_file_template_record_id = 18 and attribute_id = 1073)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2211,18,1,1073,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4747,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2212 and master_file_template_record_id = 18 and attribute_id = 1074)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2212,18,1,1074,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4748,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2213 and master_file_template_record_id = 18 and attribute_id = 1075)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2213,18,1,1075,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4749,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2214 and master_file_template_record_id = 18 and attribute_id = 1076)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2214,18,1,1076,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4750,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2215 and master_file_template_record_id = 18 and attribute_id = 1077)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2215,18,1,1077,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4751,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2216 and master_file_template_record_id = 18 and attribute_id = 1078)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2216,18,1,1078,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4752,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2217 and master_file_template_record_id = 18 and attribute_id = 1079)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2217,18,1,1079,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4753,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2218 and master_file_template_record_id = 18 and attribute_id = 1080)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2218,18,1,1080,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4754,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2219 and master_file_template_record_id = 18 and attribute_id = 1081)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2219,18,1,1081,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4755,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2220 and master_file_template_record_id = 18 and attribute_id = 1082)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2220,18,1,1082,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4756,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2221 and master_file_template_record_id = 18 and attribute_id = 1083)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2221,18,1,1083,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4757,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2222 and master_file_template_record_id = 18 and attribute_id = 1084)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2222,18,1,1084,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4758,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2223 and master_file_template_record_id = 18 and attribute_id = 1085)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2223,18,1,1085,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4759,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2224 and master_file_template_record_id = 18 and attribute_id = 1086)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2224,18,1,1086,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4760,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2225 and master_file_template_record_id = 18 and attribute_id = 1087)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2225,18,1,1087,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4761,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2226 and master_file_template_record_id = 18 and attribute_id = 1088)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2226,18,1,1088,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4762,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2227 and master_file_template_record_id = 18 and attribute_id = 1089)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2227,18,1,1089,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4763,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2228 and master_file_template_record_id = 18 and attribute_id = 1090)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2228,18,1,1090,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4764,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2229 and master_file_template_record_id = 18 and attribute_id = 1091)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2229,18,1,1091,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4765,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2230 and master_file_template_record_id = 18 and attribute_id = 1092)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2230,18,1,1092,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4766,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2231 and master_file_template_record_id = 18 and attribute_id = 1093)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2231,18,1,1093,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4767,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2232 and master_file_template_record_id = 18 and attribute_id = 1094)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2232,18,1,1094,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4768,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2233 and master_file_template_record_id = 18 and attribute_id = 1095)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2233,18,1,1095,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4769,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2234 and master_file_template_record_id = 18 and attribute_id = 1096)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2234,18,1,1096,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4770,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2235 and master_file_template_record_id = 18 and attribute_id = 1097)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2235,18,1,1097,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4771,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2236 and master_file_template_record_id = 18 and attribute_id = 1098)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2236,18,1,1098,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4772,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2237 and master_file_template_record_id = 18 and attribute_id = 1099)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2237,18,1,1099,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4773,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2238 and master_file_template_record_id = 18 and attribute_id = 2000)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2238,18,1,2000,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4774,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2239 and master_file_template_record_id = 18 and attribute_id = 2001)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2239,18,1,2001,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4775,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2240 and master_file_template_record_id = 18 and attribute_id = 2002)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2240,18,1,2002,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4776,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2241 and master_file_template_record_id = 18 and attribute_id = 2003)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2241,18,1,2003,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4777,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2242 and master_file_template_record_id = 18 and attribute_id = 2004)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2242,18,1,2004,'VARCHAR',0,NULL,NULL,79,'Pravin Rajput',getDate(),18,50,4778,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

/*
DB Entry for Employee -- employee
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 2005 and attribute_name = 'Employee Custom Defined1')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2005,'Employee Custom Defined1','PRE-DEFINED :: Employee Custom Defined1','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2006 and attribute_name = 'Employee Custom Defined2')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2006,'Employee Custom Defined2','PRE-DEFINED :: Employee Custom Defined2','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2007 and attribute_name = 'Employee Custom Defined3')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2007,'Employee Custom Defined3','PRE-DEFINED :: Employee Custom Defined3','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2008 and attribute_name = 'Employee Custom Defined4')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2008,'Employee Custom Defined4','PRE-DEFINED :: Employee Custom Defined4','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2009 and attribute_name = 'Employee Custom Defined5')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2009,'Employee Custom Defined5','PRE-DEFINED :: Employee Custom Defined5','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2010 and attribute_name = 'Employee Custom Defined6')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2010,'Employee Custom Defined6','PRE-DEFINED :: Employee Custom Defined6','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2011 and attribute_name = 'Employee Custom Defined7')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2011,'Employee Custom Defined7','PRE-DEFINED :: Employee Custom Defined7','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2012 and attribute_name = 'Employee Custom Defined8')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2012,'Employee Custom Defined8','PRE-DEFINED :: Employee Custom Defined8','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2013 and attribute_name = 'Employee Custom Defined9')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2013,'Employee Custom Defined9','PRE-DEFINED :: Employee Custom Defined9','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2014 and attribute_name = 'Employee Custom Defined10')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2014,'Employee Custom Defined10','PRE-DEFINED :: Employee Custom Defined10','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2015 and attribute_name = 'Employee Custom Defined11')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2015,'Employee Custom Defined11','PRE-DEFINED :: Employee Custom Defined11','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2016 and attribute_name = 'Employee Custom Defined12')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2016,'Employee Custom Defined12','PRE-DEFINED :: Employee Custom Defined12','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2017 and attribute_name = 'Employee Custom Defined13')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2017,'Employee Custom Defined13','PRE-DEFINED :: Employee Custom Defined13','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2018 and attribute_name = 'Employee Custom Defined14')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2018,'Employee Custom Defined14','PRE-DEFINED :: Employee Custom Defined14','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2019 and attribute_name = 'Employee Custom Defined15')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2019,'Employee Custom Defined15','PRE-DEFINED :: Employee Custom Defined15','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2020 and attribute_name = 'Employee Custom Defined16')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2020,'Employee Custom Defined16','PRE-DEFINED :: Employee Custom Defined16','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2021 and attribute_name = 'Employee Custom Defined17')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2021,'Employee Custom Defined17','PRE-DEFINED :: Employee Custom Defined17','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2022 and attribute_name = 'Employee Custom Defined18')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2022,'Employee Custom Defined18','PRE-DEFINED :: Employee Custom Defined18','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2023 and attribute_name = 'Employee Custom Defined19')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2023,'Employee Custom Defined19','PRE-DEFINED :: Employee Custom Defined19','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2024 and attribute_name = 'Employee Custom Defined20')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2024,'Employee Custom Defined20','PRE-DEFINED :: Employee Custom Defined20','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2025 and attribute_name = 'Employee Custom Defined21')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2025,'Employee Custom Defined21','PRE-DEFINED :: Employee Custom Defined21','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2026 and attribute_name = 'Employee Custom Defined22')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2026,'Employee Custom Defined22','PRE-DEFINED :: Employee Custom Defined22','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2027 and attribute_name = 'Employee Custom Defined23')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2027,'Employee Custom Defined23','PRE-DEFINED :: Employee Custom Defined23','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2028 and attribute_name = 'Employee Custom Defined24')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2028,'Employee Custom Defined24','PRE-DEFINED :: Employee Custom Defined24','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2029 and attribute_name = 'Employee Custom Defined25')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2029,'Employee Custom Defined25','PRE-DEFINED :: Employee Custom Defined25','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2030 and attribute_name = 'Employee Custom Defined26')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2030,'Employee Custom Defined26','PRE-DEFINED :: Employee Custom Defined26','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2031 and attribute_name = 'Employee Custom Defined27')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2031,'Employee Custom Defined27','PRE-DEFINED :: Employee Custom Defined27','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2032 and attribute_name = 'Employee Custom Defined28')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2032,'Employee Custom Defined28','PRE-DEFINED :: Employee Custom Defined28','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2033 and attribute_name = 'Employee Custom Defined29')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2033,'Employee Custom Defined29','PRE-DEFINED :: Employee Custom Defined29','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 2034 and attribute_name = 'Employee Custom Defined30')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2034,'Employee Custom Defined30','PRE-DEFINED :: Employee Custom Defined30','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1015 and attribute_name = 'Custom Defined31')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined31', attribute_description='PRE-DEFINED :: Employee Custom Defined31', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1015 and attribute_name = 'Custom Defined31'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1016 and attribute_name = 'Custom Defined32')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined32', attribute_description='PRE-DEFINED :: Employee Custom Defined32', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1016 and attribute_name = 'Custom Defined32'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1017 and attribute_name = 'Custom Defined33')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined33', attribute_description='PRE-DEFINED :: Employee Custom Defined33', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1017 and attribute_name = 'Custom Defined33'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1018 and attribute_name = 'Custom Defined34')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined34', attribute_description='PRE-DEFINED :: Employee Custom Defined34', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1018 and attribute_name = 'Custom Defined34'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1019 and attribute_name = 'Custom Defined35')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined35', attribute_description='PRE-DEFINED :: Employee Custom Defined35', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1019 and attribute_name = 'Custom Defined35'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1020 and attribute_name = 'Custom Defined36')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined36', attribute_description='PRE-DEFINED :: Employee Custom Defined36', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1020 and attribute_name = 'Custom Defined36'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1021 and attribute_name = 'Custom Defined37')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined37', attribute_description='PRE-DEFINED :: Employee Custom Defined37', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1021 and attribute_name = 'Custom Defined37'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1022 and attribute_name = 'Custom Defined38')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined38', attribute_description='PRE-DEFINED :: Employee Custom Defined38', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1022 and attribute_name = 'Custom Defined38'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1023 and attribute_name = 'Custom Defined39')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined39', attribute_description='PRE-DEFINED :: Employee Custom Defined39', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1023 and attribute_name = 'Custom Defined39'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_id = 1024 and attribute_name = 'Custom Defined40')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_name = 'Employee Custom Defined40', attribute_description='PRE-DEFINED :: Employee Custom Defined40', updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_id = 1024 and attribute_name = 'Custom Defined40'
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined1')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2005, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined1'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined2')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2006, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined2'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined3')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2007, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined3'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined4')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2008, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined4'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined5')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2009, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined5'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined6')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2010, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined6'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined7')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2011, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined7'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined8')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2012, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined8'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined9')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2013, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined9'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined10')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2014, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined10'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined11')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2015, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined11'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined12')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2016, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined12'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined13')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2017, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined13'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined14')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2018, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined14'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined15')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2019, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined15'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined16')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2020, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined16'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined17')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2021, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined17'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined18')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2022, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined18'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined19')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2023, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined19'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined20')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2024, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined20'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined21')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2025, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined21'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined22')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2026, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined22'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined23')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2027, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined23'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined24')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2028, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined24'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined25')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2029, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined25'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined26')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2030, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined26'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined27')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2031, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined27'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined28')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2032, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined28'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined29')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2033, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined29'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined30')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=2034, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined30'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined31')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1015, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined31'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined32')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1016, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined32'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined33')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1017, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined33'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined34')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1018, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined34'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined35')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1019, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined35'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined36')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1020, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined36'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined37')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1021, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined37'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined38')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1022, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined38'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined39')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1023, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined39'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from file_type_attribute_association where standardized_name = 'employee.customDefined40')
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON
UPDATE [dbo].[file_type_attribute_association] SET attribute_id=1024, updated_by = 'Pravin Rajput', updated_date_time = getDate() where standardized_name = 'employee.customDefined40'
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined1'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2005, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined1')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined2'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2006, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined2')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined3'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2007, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined3')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined4'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2008, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined4')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined5'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2009, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined5')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined6'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2010, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined6')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined7'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2011, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined7')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined8'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2012, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined8')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined9'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2013, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined9')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined10'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2014, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined10')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined11'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2015, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined11')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined12'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2016, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined12')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined13'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2017, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined13')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined14'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2018, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined14')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined15'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2019, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined15')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined16'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2020, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined16')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined17'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2021, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined17')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined18'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2022, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined18')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined19'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2023, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined19')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined20'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2024, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined20')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined21'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2025, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined21')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined22'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2026, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined22')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined23'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2027, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined23')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined24'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2028, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined24')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined25'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2029, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined25')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined26'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2030, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined26')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined27'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2031, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined27')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined28'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2032, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined28')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined29'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2033, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined29')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined30'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=2034, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined30')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined31'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1015, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined31')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined32'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1016, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined32')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined33'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1017, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined33')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined34'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1018, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined34')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined35'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1019, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined35')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined36'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1020, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined36')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined37'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1021, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined37')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined38'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1022, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined38')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined39'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1023, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined39')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from master_file_template_attribute_association where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined40'))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON
UPDATE [dbo].[master_file_template_attribute_association] SET attribute_id=1024, updated_by = 'Pravin Rajput', updated_date_time = getDate() where ftaa_id in (select ftaa_id from file_type_attribute_association where standardized_name like 'employee.customDefined40')
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if exists (select 1 from attribute_dictionary where attribute_description is null)
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON
UPDATE [dbo].[attribute_dictionary] SET attribute_description=attribute_name, updated_by = 'Pravin Rajput', updated_date_time = getDate() where attribute_description is null
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO