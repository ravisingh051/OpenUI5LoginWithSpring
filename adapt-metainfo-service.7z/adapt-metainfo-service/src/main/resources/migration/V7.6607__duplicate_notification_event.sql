USE [idis-metainfo]
GO

/*
Update Log	
----------  -----------    ---------------------------------------------------------------------------------------
01-07-2019  Divya Jain	   ADAPT-6607 : OutboundFile_User is getting File Delivered Option twice in System Event Dropdown

*/

USE [idis-metainfo]

if exists(select 1 from processing_system_events where event_id=13)
begin
	if exists (select 1 from notification_template_info where event_id =13)
	begin
		if exists (select 1 from file_notification_template_contact_assoc where template_id in 
		(select template_id from notification_template_info where event_id =13))
		begin
			delete from file_notification_template_contact_assoc where template_id in 
			(select template_id from notification_template_info where event_id =13)
		end;
		delete from notification_template_info where event_id =13
	end;
	delete from processing_system_events where event_id=13
end;
GO

