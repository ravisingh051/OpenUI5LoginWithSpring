USE [idis-metainfo]
GO
/*
Filename:  V13.7403__implement_fixed_width_support_in_existing_files_api

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-30   Mayur Tanna  ADAPT-7403 : Implement Fixed Width Support In Existing Files API
*/


if not exists (select 1 from file_type_attribute_association where ftaa_id = 4658 and file_type_id = 17 and attribute_id = 528)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4658,17,528,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined1',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4659 and file_type_id = 17 and attribute_id = 617)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4659,17,617,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined2',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4660 and file_type_id = 17 and attribute_id = 618)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4660,17,618,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined3',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4661 and file_type_id = 17 and attribute_id = 619)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4661,17,619,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined4',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4662 and file_type_id = 17 and attribute_id = 620)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4662,17,620,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined5',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4663 and file_type_id = 17 and attribute_id = 621)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4663,17,621,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined6',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4664 and file_type_id = 17 and attribute_id = 622)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4664,17,622,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined7',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO


if not exists (select 1 from file_type_attribute_association where ftaa_id = 4665 and file_type_id = 17 and attribute_id = 623)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4665,17,623,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined8',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4666 and file_type_id = 17 and attribute_id = 624)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4666,17,624,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined9',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4667 and file_type_id = 17 and attribute_id = 625)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4667,17,625,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined10',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4668 and file_type_id = 17 and attribute_id = 218)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4668,17,218,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined11',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4669 and file_type_id = 17 and attribute_id = 770)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4669,17,770,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined12',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO


if not exists (select 1 from file_type_attribute_association where ftaa_id = 4670 and file_type_id = 17 and attribute_id = 771)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4670,17,771,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined13',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4671 and file_type_id = 17 and attribute_id = 772)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4671,17,772,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined14',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4672 and file_type_id = 17 and attribute_id = 773)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4672,17,773,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined15',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4673 and file_type_id = 17 and attribute_id = 774)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4673,17,774,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined16',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4674 and file_type_id = 17 and attribute_id = 775)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4674,17,775,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined17',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4675 and file_type_id = 17 and attribute_id = 776)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4675,17,776,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined18',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4676 and file_type_id = 17 and attribute_id = 777)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4676,17,777,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined19',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4677 and file_type_id = 17 and attribute_id = 778)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4677,17,778,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined20',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO


if not exists (select 1 from file_type_attribute_association where ftaa_id = 4678 and file_type_id = 17 and attribute_id = 779)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4678,17,779,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined21',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4679 and file_type_id = 17 and attribute_id = 780)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4679,17,780,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined22',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4680 and file_type_id = 17 and attribute_id = 781)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4680,17,781,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined23',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4681 and file_type_id = 17 and attribute_id = 782)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4681,17,782,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined24',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4682 and file_type_id = 17 and attribute_id = 783)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4682,17,783,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined25',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4683 and file_type_id = 17 and attribute_id = 784)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4683,17,784,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined26',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4684 and file_type_id = 17 and attribute_id = 785)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4684,17,785,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined27',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO


if not exists (select 1 from file_type_attribute_association where ftaa_id = 4685 and file_type_id = 17 and attribute_id = 786)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4685,17,786,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined28',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4686 and file_type_id = 17 and attribute_id = 787)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4686,17,787,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined29',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4687 and file_type_id = 17 and attribute_id = 789)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4687,17,789,'VARCHAR',0,NULL,'Mayur tanna',getDate(),NULL,NULL,'employee.customDefined30',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO



if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2123 and master_file_template_record_id = 18 and attribute_id = 528)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2123,18,1,528,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4658,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2124 and master_file_template_record_id = 18 and attribute_id = 617)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2124,18,1,617,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4659,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2125 and master_file_template_record_id = 18 and attribute_id = 618)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2125,18,1,618,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4660,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2126 and master_file_template_record_id = 18 and attribute_id = 619)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2126,18,1,619,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4661,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2127 and master_file_template_record_id = 18 and attribute_id = 620)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2127,18,1,620,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4662,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2128 and master_file_template_record_id = 18 and attribute_id = 621)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2128,18,1,621,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4663,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2129 and master_file_template_record_id = 18 and attribute_id = 622)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2129,18,1,622,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4664,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2130 and master_file_template_record_id = 18 and attribute_id = 623)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2130,18,1,623,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4665,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2131 and master_file_template_record_id = 18 and attribute_id = 624)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2131,18,1,624,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4666,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2132 and master_file_template_record_id = 18 and attribute_id = 625)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2132,18,1,625,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4667,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2133 and master_file_template_record_id = 18 and attribute_id = 218)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2133,18,1,218,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4668,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2134 and master_file_template_record_id = 18 and attribute_id = 770)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2134,18,1,770,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4669,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2135 and master_file_template_record_id = 18 and attribute_id = 771)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2135,18,1,771,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4670,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2136 and master_file_template_record_id = 18 and attribute_id = 772)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2136,18,1,772,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4671,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2137 and master_file_template_record_id = 18 and attribute_id = 773)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2137,18,1,773,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4672,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO



if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2138 and master_file_template_record_id = 18 and attribute_id = 774)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2138,18,1,774,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4673,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2139 and master_file_template_record_id = 18 and attribute_id = 775)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2139,18,1,775,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4674,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO



if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2140 and master_file_template_record_id = 18 and attribute_id = 776)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2140,18,1,776,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4675,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2141 and master_file_template_record_id = 18 and attribute_id = 777)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2141,18,1,777,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4676,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2142 and master_file_template_record_id = 18 and attribute_id = 778)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2142,18,1,778,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4677,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2143 and master_file_template_record_id = 18 and attribute_id = 779)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2143,18,1,779,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4678,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2144 and master_file_template_record_id = 18 and attribute_id = 780)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2144,18,1,780,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4679,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2145 and master_file_template_record_id = 18 and attribute_id = 781)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2145,18,1,781,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4680,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2146 and master_file_template_record_id = 18 and attribute_id = 782)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2146,18,1,782,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4681,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2147 and master_file_template_record_id = 18 and attribute_id = 783)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2147,18,1,783,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4682,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2148 and master_file_template_record_id = 18 and attribute_id = 784)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2148,18,1,784,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4683,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2149 and master_file_template_record_id = 18 and attribute_id = 785)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2149,18,1,785,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4684,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2150 and master_file_template_record_id = 18 and attribute_id = 786)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2150,18,1,786,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4685,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO


if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2151 and master_file_template_record_id = 18 and attribute_id = 787)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2151,18,1,787,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4686,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2152 and master_file_template_record_id = 18 and attribute_id = 789)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2152,18,1,789,'VARCHAR',0,NULL,NULL,78,'Mayur Tanna',getDate(),18,50,4687,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO