use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-10-01   Divya Jain			ADAPT-7677 : System should convert existing PMTs to File Template
The Default Team Name that would be used for Migrating PMTs to Files is: Not assigned
Default Employer Name that would be used for Migrating PMTs to Files is: "Unassigned" employer, CAPIS 00000
Default Row Delimiter would be CRLF
Default Threshold Error Format and Threshold # Errors should be No Threshold
Default Delimiter will be the one from the first file which was created from that PMT
If the PMT is a fixed width one then it will be persisted to the file template
Default Analyst Name will be the analyst who built the PMT
All the migrated PMTs should be defaulted as Templates and not File
All the migrated PMTs should use the same name as PMT name, it can be appended with the prefix: "Template_". Mansi to confirm with business
All the cloning details and the Secondary API mappings should be also migrated/copied.
All the migrated Templates (from PMTs), should have status as active.
All the migrated Templates (from PMTs), should have approval status as Draft. User can check & confirm and then apply for approval. This is important to make sure that the user edits these migrated defaults (specially employer and add Extraction details in case on Outbound), to be able to create a fully working template and then get that approved.
Only the latest versions will be migrated. Should be consider draft as latest, if we have one, or we should only consider the latest approved version to be migrated
PMT names with DONOTUSE to not be migrated
The migrated files version will be 1
*/

if not exists(select 1 from information_schema.columns where table_name='file_meta_info' and column_name='is_template')
begin
alter table file_meta_info add is_template bit NOT NULL CONSTRAINT DF_file_meta_info_is_template default(0)
end;
go


--The Default Team Name that would be used for Migrating PMTs to Files is: Not assigned
DECLARE @teamId INT

IF NOT EXISTS(select 1 from [dbo].[idis_team] where idis_team_name='Not assigned')
BEGIN
DECLARE @NEW_TEAM_RESEED INT
DECLARE @CURRENT_TEAM_RESEED INT
SET @CURRENT_TEAM_RESEED=(SELECT IDENT_CURRENT( 'idis_team' ) AS A)
SET @NEW_TEAM_RESEED =@CURRENT_TEAM_RESEED+1
DBCC CHECKIDENT ('idis_team', RESEED, @NEW_TEAM_RESEED)
SET @teamId=@CURRENT_TEAM_RESEED+1
SET IDENTITY_INSERT [dbo].[idis_team] ON 
INSERT [dbo].[idis_team] ([idis_team_id], [idis_team_name], [idis_team_description], [idis_team_common_email_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (@teamId, N'Not assigned', NULL, N'adapt_qa@yahoo.com', N'Divya Jain', getDate(), null, null)
SET IDENTITY_INSERT [dbo].[idis_team] OFF
END
ELSE
BEGIN
select @teamId=idis_team_id from [dbo].[idis_team] where idis_team_name='Not assigned';
END


DECLARE @clientId varchar(10)='00000'
DECLARE @employerId int=0
DECLARE @clientEmployerAssocId int

IF NOT EXISTS(select 1 from [dbo].client_employer_assoc where employer_id=@employerId or client_id=@clientId or employer_name='Unassigned')
BEGIN
DECLARE @NEW_CEA_RESEED INT
DECLARE @CURRENT_CEA_RESEED INT
SET @CURRENT_CEA_RESEED=(SELECT IDENT_CURRENT( 'client_employer_assoc' ) AS A)
SET @NEW_CEA_RESEED =@CURRENT_CEA_RESEED+1
DBCC CHECKIDENT ('client_employer_assoc', RESEED, @NEW_CEA_RESEED)
SET @clientEmployerAssocId=@CURRENT_CEA_RESEED+1
SET IDENTITY_INSERT [dbo].client_employer_assoc ON 
INSERT [dbo].client_employer_assoc ([client_employer_assoc_id], [employer_id], [client_id], [employer_name],[data_source_id],[last_updated_timestamp],source_instance,[table_version],[is_active]) 
VALUES (@clientEmployerAssocId,@employerId,@clientId, N'Unassigned', 1,getDate(),'TEST',1,1)
SET IDENTITY_INSERT [dbo].client_employer_assoc OFF
END
ELSE
BEGIN
select @clientEmployerAssocId=client_employer_assoc_id from [dbo].client_employer_assoc where employer_id=@employerId or client_id=@clientId or employer_name='Unassigned';
END


-------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------- FOR CHILD FILE TEMPLATE ----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------

if not exists (select 1 from information_schema.tables where table_name='child_file_template_meta_info')
BEGIN
	print 'Nothing to migrate'
END
ELSE
BEGIN
declare @ipmt_record_id int=null;
declare @oError_code INT = 0;
DECLARE pmtTempCur CURSOR LOCAL FOR SELECT [child_file_template_record_id] from child_file_template_meta_info a join
(select child_file_template_id as id,max(child_file_template_version) as ver from child_file_template_meta_info
where approval_status_id=3 and is_active=1 group by child_file_template_id)b
on a.child_file_template_id=b.id and a.child_file_template_version=b.ver ;
OPEN pmtTempCur

FETCH NEXT FROM pmtTempCur INTO @ipmt_record_id;
		WHILE @@FETCH_STATUS = 0
			BEGIN
print 'started: ';

declare @createdBy varchar(50);
declare @createdDateTime datetime;
declare @layout varchar(50);
declare @new_file_format_supported int;
declare @pmtId int;
declare @pmtVersion int;
declare @pmtRecordId int;
declare @pmtName varchar(100);
declare @newFileId int;
declare @newRecordId int;
DECLARE @IdentityValue AS TABLE(ID INT);
declare @tpName varchar(50);
declare @lobName varchar(100);
declare @envName varchar(100);
declare @lobId int;
declare @tpId int;
declare @fileTypeId int;

----------------------- START: Get first approved File created from this PMT -----------------
declare @firstFileFromPmtId int;
select @firstFileFromPmtId=isnull(min(record_id),0) from file_meta_info where approval_status_id=3 and is_active=1
and child_file_template_record_id=@ipmt_record_id group by file_id
----------------------- END: Get first approved File created from this PMT -----------------

----------------------- START: Get PMT Details -----------------
select @pmtId=child_file_template_id,@pmtVersion=child_file_template_version,@pmtRecordId=child_file_template_record_id,
@pmtName=child_file_template_name, @layout=child_file_template_layout,@createdBy=cftmi.created_by,@createdDateTime=cftmi.created_date_time,
@tpName=tpi.trading_partner_name,@lobName=lob.lob_name,@tpId=cftmi.trading_partner_id,@lobId=cftmi.lob_id,@fileTypeId=mftmi.file_type_id
from [child_file_template_meta_info] cftmi 
join [master_file_template_meta_info] mftmi on mftmi.master_file_template_record_id=cftmi.master_file_template_record_id
join trading_partner_info tpi on tpi.trading_partner_id=cftmi.trading_partner_id
join lob lob on lob.lob_id=cftmi.lob_id
where child_file_template_record_id=@ipmt_record_id

select @envName=LOWER(case when adapt_env_abbreviation like 'QA%' then 'QA'
when adapt_env_abbreviation like 'QC%' then 'QC'
else adapt_env_abbreviation end)  from adapt_env_config_info where is_current_env=1

----------------------- END: Get PMT Details -----------------

----------------------- START: Insert into  file_format_supported -----------------
SELECT @new_file_format_supported=MAX([file_format_supported_id])+1 from [dbo].[file_format_supported]
DBCC CHECKIDENT ('file_format_supported', RESEED, @new_file_format_supported)
if(@firstFileFromPmtId>0)
begin
	SET IDENTITY_INSERT [dbo].[file_format_supported] ON;
	INSERT INTO [dbo].[file_format_supported]
           ([file_format_supported_id]
		   ,[file_format_name]
           ,[file_format_row_delimiter]
           ,[file_format_field_delimiter]
           ,[file_format_escape_char]
           ,[file_format_segment_delimiter]
           ,[file_has_header]
           ,[file_has_footer]
           ,[file_header_line_count]
           ,[file_footer_line_count]
           ,[file_lines_skip_count]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
     SELECT
           @new_file_format_supported
		   ,file_format_name
           ,file_format_row_delimiter
           ,file_format_field_delimiter
           ,file_format_escape_char
           ,file_format_segment_delimiter
           ,file_has_header
           ,file_has_footer
           ,file_header_line_count
           ,file_footer_line_count
           ,file_lines_skip_count
           ,@createdBy
           ,@createdDateTime
           ,@createdBy
           ,@createdDateTime from file_format_supported where file_format_supported_id=(select file_format_supported_id from file_meta_info 
		   where record_id=@firstFileFromPmtId)
	SET IDENTITY_INSERT [dbo].[file_format_supported] OFF;
end;
else
begin
	SET IDENTITY_INSERT [dbo].[file_format_supported] ON;
	INSERT INTO [dbo].[file_format_supported]
           ([file_format_supported_id]
		   ,[file_format_name]
           ,[file_format_row_delimiter]
           ,[file_format_field_delimiter]
           ,[file_format_escape_char]
           ,[file_format_segment_delimiter]
           ,[file_has_header]
           ,[file_has_footer]
           ,[file_header_line_count]
           ,[file_footer_line_count]
           ,[file_lines_skip_count]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
     VALUES(
           @new_file_format_supported
		   ,@layout
           ,''
           ,case when @layout='DELIMITED' then ',' else null end
           ,NULL
           ,NULL
           ,0
           ,0
           ,NULL
           ,NULL
           ,NULL
           ,@createdBy
           ,@createdDateTime
           ,@createdBy
           ,@createdDateTime)
	SET IDENTITY_INSERT [dbo].[file_format_supported] OFF;
end;
--print '[file_format_supported] done'
--select * from [file_format_supported] where [file_format_supported_id]=@new_file_format_supported
----------------------- END: Insert into  file_format_supported -----------------


----------------------- START: Insert into  file_id_generator -----------------
insert into file_id_generator( created_by, created_date_time)  OUTPUT Inserted.file_id INTO @IdentityValue VALUES( @createdBy, @createdDateTime)
select @newFileId = id from @IdentityValue
--print '[file_id_generator] done'
--select * from file_id_generator where file_id=@newFileId
----------------------- END: Insert into  file_id_generator -----------------


----------------------- START: Insert into  file_meta_info -----------------
INSERT INTO [dbo].[file_meta_info]
		 ([file_id]
		  ,[file_type_id]
		  ,[master_file_template_id]
		  ,[master_file_template_version]
		  ,[child_file_template_id]
		  ,[child_file_template_version]
		  ,[file_version]
		  ,[file_name]
		  ,[is_multi_employer]
		  ,[file_status]
		  ,[old_file_id]
		  ,[archival_location]
		  ,[file_processing_error_threshold_count]
		  ,[file_min_record_count_allowed]
		  ,[file_format_supported_id]
		  ,[trading_partner_platform_id]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time]
		  ,[is_active]
		  ,[approval_status_id]
		  ,[approval_status_updated_by]
		  ,[approval_status_updated_date]
		  ,[approval_status_comment]
		  ,[append_file_run_date]
		  ,[file_max_record_count_allowed]
		  ,[file_processing_error_threshold_format]
		  ,[file_idis_ba_name]
		  ,[file_idis_ba_email_id]
		  ,[child_file_template_record_id]
		  ,[master_file_template_record_id]
		  ,[is_SLA_mapped]
		  ,[data_source_type_id]
		  ,[data_target_type_id]
		  ,[is_template])
	SELECT @newFileId
		  ,ftmi.[file_type_id]
		  ,mftmi.[master_file_template_id]
		  ,mftmi.[master_file_template_version]
		  ,@pmtId
		  ,@pmtVersion
		  ,1
		  ,'Template_'+@pmtName
		  ,0
		  ,'Active'
		  ,null
		  ,'/apps/Benefits/adapt/'+@envName+'/files/archive/'+@tpName+'/'+@lobName+'/'+cast(@newFileId as varchar(10))
		  ,0
		  ,0
		  ,@new_file_format_supported
		  ,NULL
		  ,@createdBy
		  ,@createdDateTime
		  ,@createdBy
		  ,@createdDateTime
		  ,0
		  ,1
		  ,NULL
		  ,NULL
		  ,NULL
		  ,0
		  ,0
		  ,'No Threshold'
		  ,case when @firstFileFromPmtId>0 then (select file_idis_ba_name from file_meta_info where record_id=@firstFileFromPmtId) else 'Mansi Vaswani' end
		  ,case when @firstFileFromPmtId>0 then (select file_idis_ba_email_id from file_meta_info where record_id=@firstFileFromPmtId) else 'mansi.vaswani@alight.com' end
		  ,@pmtRecordId
		  ,mftmi.[master_file_template_record_id]
		  ,0
		  ,[data_source_type_id]
		  ,[data_target_type_id] 
		  ,1 FROM [dbo].[child_file_template_meta_info] cftmi
		  join [master_file_template_meta_info] mftmi on cftmi.master_file_template_record_id=mftmi.master_file_template_record_id
		  join [file_type_meta_info] ftmi on ftmi.file_type_id=mftmi.file_type_id
		  WHERE child_file_template_record_id=@pmtRecordId

--print '[file_meta_info] done'
select @newRecordId=record_id from file_meta_info where file_id=@newFileId
--select * from file_meta_info where file_id=@newFileId
----------------------- END: Insert into  file_meta_info -----------------


----------------------- START: Insert into file_trading_partner_lob_assoc -----------------
INSERT INTO [dbo].[file_trading_partner_lob_assoc]
           ([trading_partner_id]
           ,[lob_id]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[file_identifier])
     VALUES
           (@tpId
           ,@lobId
           ,@createdBy
           ,@createdDateTime
           ,@createdBy
           ,@createdDateTime
           ,@newRecordId)
--print '[[file_trading_partner_lob_assoc]] done'
--select * from [file_trading_partner_lob_assoc] where file_identifier=@newRecordId
----------------------- END: Insert into  file_trading_partner_lob_assoc -----------------


----------------------- START: Insert into file_employer_assoc -----------------
INSERT INTO [dbo].[file_employer_assoc]
           ([client_employer_assoc_id]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[file_identifier])
     VALUES
           (@clientEmployerAssocId
           ,@createdBy
           ,@createdDateTime
           ,@createdBy
           ,@createdDateTime
           ,@newRecordId)
--print '[[file_employer_assoc]] done'
--select * from file_employer_assoc where file_identifier=@newRecordId
----------------------- END: Insert into  file_employer_assoc -----------------


----------------------- START: Insert into idis_team_file_association -----------------
INSERT INTO [dbo].[idis_team_file_association]
           ([idis_team_id]
           ,[created_date]
           ,[created_by]
           ,[file_identifier])
     VALUES
           (@teamId
		   ,@createdDateTime
           ,@createdBy
           ,@newRecordId)
--print '[idis_team_file_association] done'
--select * from [idis_team_file_association] where file_identifier=@newRecordId
----------------------- END: Insert into idis_team_file_association -----------------


----------------------- START: Insert into file_section_association -----------------
	DECLARE @sectionCount INT
	SET @sectionCount = (SELECT count(1) FROM [idis-metainfo].[dbo].[child_file_template_section_assoc] where [child_file_template_record_id] = @pmtRecordId)
	DECLARE @CURRENT_ID INT=0
	SET @CURRENT_ID = (SELECT IDENT_CURRENT( 'file_section_association' ) AS A)
	----update the identity number for new records, have a buffer of 5 records to avoid error-----
	DECLARE @NEW_RESEED INT
	SET @NEW_RESEED = @CURRENT_ID+@sectionCount+5
	DBCC CHECKIDENT ('file_section_association', RESEED, @NEW_RESEED)
	DECLARE @NEW_IDENT INT
	SET @NEW_IDENT = @CURRENT_ID + 2;
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int )

	INSERT INTO #TEMP_OLDNEWKEY
	SELECT  @NEW_IDENT+Row_number() Over(Order by B.cftsa_id) ,B.cftsa_id	
	FROM [idis-metainfo].[dbo].[child_file_template_section_assoc] B WHERE B.[child_file_template_record_id] = @pmtRecordId

	SET IDENTITY_INSERT [dbo].[file_section_association] ON
	INSERT INTO [dbo].[file_section_association] 
		( [fsa_id]
		  ,[template_section_id]
		  ,[file_identifier]
		  ,[file_compliant_section_short_name]
		  ,[section_display_name]
		  ,[sequence]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time] )
	( SELECT 
		@NEW_IDENT+Row_number() Over(Order by B.cftsa_id) AS [fsa_id]
		,B.[template_section_id]
		,@newRecordId AS [file_identifier]
		,B.[template_compliant_section_short_name] AS [file_compliant_section_short_name]
		,B.[section_display_name]
		,B.[sequence]
		,@createdBy
		,@createdDateTime
		,@createdBy
		,@createdDateTime
	FROM [idis-metainfo].[dbo].[child_file_template_section_assoc] B WHERE B.[child_file_template_record_id] = @pmtRecordId)
	SET IDENTITY_INSERT [dbo].[file_section_association] OFF
--print '[file_section_association] done'
--select * from [file_section_association] where file_identifier=@newRecordId
----------------------- END: Insert into file_section_association -----------------


----------------------- START: Insert into file_clone_info -----------------
INSERT INTO file_clone_info
	([file_identifier],[clone_num],[clone_name],[created_by],[created_date_time],[updated_by],[updated_date_time])
	SELECT 
		@newRecordId AS [file_identifier],
		clone_num,
		clone_name,
		@createdBy,
		@createdDateTime,
		@createdBy,
		@createdDateTime
	FROM child_file_template_clone_info cftci where [child_file_template_record_id] = @pmtRecordId
--print '[file_clone_info] done'
--select * from file_clone_info where file_identifier=@newRecordId
----------------------- END: Insert into file_clone_info -----------------



----------------------- START: Insert into file_attribute_association -----------------
	IF OBJECT_ID('tempdb..#TEMP_FTAA') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_FTAA; END
	SELECT top 0 [faa_id],[cftaa_id] INTO #TEMP_FTAA  FROM [idis-metainfo].[dbo].[lookup_table_file_association];

	IF OBJECT_ID('tempdb..#FILE_ATTR_TMP') IS NOT NULL 
	BEGIN DROP TABLE #FILE_ATTR_TMP; END

	SELECT 
		@newRecordId AS [file_identifier],
		A.[attribute_id],
		A.[data_type],
		A.[is_mandatory],
		A.[attribute_row_position],
		A.[attribute_start_position],
		A.[attribute_end_position],
		@createdBy as created_by,
		A.[application_compliant_attribute_name],
		@createdDateTime AS [created_date_time],
		B.new_id AS [fsa_id], 
		A.cftaa_id, 
		A.[attribute_size],
		1 AS [is_inherited], 
		A.[to_do],
		case when A.clone_num is null then 0 else A.clone_num end as clone_num
	INTO #FILE_ATTR_TMP
	FROM [idis-metainfo].[dbo].[child_file_template_attribute_association] A
	INNER JOIN #TEMP_OLDNEWKEY B ON A.cftsa_id = B.old_id
	WHERE [child_file_template_record_id] = @pmtRecordId order by A.attribute_row_position asc


	MERGE [idis-metainfo].[dbo].[file_attribute_association] AS TARGET
	USING (
		select * from #FILE_ATTR_TMP) AS SOURCE
	ON 1=0
	WHEN NOT MATCHED THEN
		INSERT ([file_identifier]
		,[attribute_id]
		,[data_type]
		,[is_mandatory]
		,[attribute_row_position]
		,[attribute_start_position]
		,[attribute_end_position]
		,[created_by]
		,[created_date_time]
		,[fsa_id]
		,[attribute_size]
		,[is_inherited]
		,[cftaa_id]
		,[file_format_compliant_attribute_name]
		,[updated_by]
		,[updated_date_time]
		,[to_do]
		,[clone_num])
	VALUES (
		SOURCE.[file_identifier],
		SOURCE.[attribute_id],
		SOURCE.[data_type],
		SOURCE.[is_mandatory],
		SOURCE.[attribute_row_position],
		SOURCE.[attribute_start_position],
		SOURCE.[attribute_end_position],
		@createdBy,
		@createdDateTime,
		SOURCE.[fsa_id],
		SOURCE.[attribute_size],
		SOURCE.[is_inherited],
		SOURCE.cftaa_id,
		SOURCE.[application_compliant_attribute_name],
		@createdBy,
		@createdDateTime,
		SOURCE.to_do,
		SOURCE.clone_num
		)
	OUTPUT INSERTED.[faa_id], SOURCE.cftaa_id INTO #TEMP_FTAA;

--print '[file_attribute_association] done'
--select * from file_attribute_association where file_identifier=@newRecordId
----------------------- END: Insert into file_attribute_association -----------------



----------------------- START: Insert into rules -----------------
DECLARE @RULES_COUNT INT
SET @RULES_COUNT = (select count(1) from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_record_id] = @pmtRecordId
)+
(select count(1) from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@pmtId AND ltmi.lookup_table_version = @pmtVersion
and ltmi.associated_file_type_id=@fileTypeId
)+
(
select count(1) from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
where ctlsni.child_file_template_record_id = @pmtRecordId and ctlsni.is_active=1
)+
(select count(1) from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
where cftsmaba.child_file_template_record_id=@pmtRecordId and cftsmaba.is_active=1
)

--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2

IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	CREATE TABLE #TEMP_DBRDT_OLDNEWKEY ( new_id int, old_id int ,rule_version int)

INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version)
(select @NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version from (
select drools_business_rule_id,drools_business_rule_version from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_record_id] = @pmtRecordId
union
select drools_business_rule_id,drools_business_rule_version from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@pmtId AND ltmi.lookup_table_version = @pmtVersion
and ltmi.associated_file_type_id=@fileTypeId
union
select drools_business_rule_id,drools_business_rule_version from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
where ctlsni.child_file_template_record_id = @pmtRecordId and ctlsni.is_active=1 and ctlsni.is_active=1
union
select drools_business_rule_id,drools_business_rule_version from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
where cftsmaba.child_file_template_record_id = @pmtRecordId and cftsmaba.is_active=1
) a)

SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@createdBy,@createdDateTime from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY
on drools_business_rule_id=old_id)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

--print 'rules done'
----------------------- END: Insert into rules -----------------


----------------------- START: Insert into file_attr_br_assoc -----------------
INSERT INTO [idis-metainfo].[dbo].[file_attr_br_assoc]
      ([faa_id]
      ,[business_rule_id]
      ,[business_rule_version]
	  ,[rule_execution_sequence]
	  ,[rule_execution_comment]
      ,[created_by]
      ,[created_date_time]
      ,[updated_by]
      ,[updated_date_time])
	SELECT 
		A.faa_id,
		C.new_id,
		C.rule_version,
		D.rule_execution_sequence,
		D.rule_execution_comment,
		@createdBy,
		@createdDateTime,
		@createdBy,
		@createdDateTime

	FROM #TEMP_FTAA A
		INNER JOIN [idis-metainfo].[dbo].[file_attribute_association]  E
		ON A.faa_id = E.faa_id
		INNER JOIN [idis-metainfo].[dbo].[child_file_template_attr_br_assoc] D
		ON A.cftaa_id = D.cftaa_id
		INNER JOIN #TEMP_DBRDT_OLDNEWKEY C
		ON D.business_rule_id=C.old_id
		INNER JOIN [idis-metainfo].[dbo].[file_meta_info] F
		ON E.file_identifier = F.record_id;

--print 'file_attr_br_assoc done'
----------------------- END: Insert into file_attr_br_assoc -----------------


----------------------- START: Insert into file_secondary_mapping_attr_assoc -----------------
		INSERT INTO [dbo].[file_secondary_mapping_attr_assoc]
		([fsmaa_file_identifier]
		,[fsmaa_faa_id]
		,[fsmaa_node_name]
		,[fsmaa_standardized_name]
		,[created_date_time]
		,[created_by]
		,[updated_date_time]
		,[updated_by]
		)
		(SELECT @newRecordId
		,A.faa_id
		,[csmaa_node_name]
		,[csmaa_standardized_name]
		,@createdDateTime
		,@createdBy
		,@createdDateTime
		,@createdBy
		FROM [dbo].[child_secondary_mapping_attr_assoc]  csmaa join #TEMP_FTAA A on csmaa.csmaa_cftaa_id=A.cftaa_id
		where csmaa.csmaa_child_file_template_record_id=@pmtRecordId)

--print 'file_secondary_mapping_attr_assoc done'
--select * from file_secondary_mapping_attr_assoc where fsmaa_file_identifier=@newRecordId
----------------------- END: Insert into file_secondary_mapping_attr_assoc -----------------

		
----------------------- START: Insert into lookup tables -----------------
	--- get record count for lookup tables ----
DECLARE @LT_COUNT INT
SET @LT_COUNT = (select count(1) from lookup_table_meta_info ltmi where associated_file_level='C' and associated_file_type_id=@fileTypeId and 
lookup_table_version=@pmtVersion and associated_file_level_id=@pmtId)


--- reseed the identity ----
DECLARE @NEW_LT_RESEED INT=0
DECLARE @CURRENT_LT_RESEED INT=0
DECLARE @NEW_LT_INDENT INT=0
SET @CURRENT_LT_RESEED=(SELECT IDENT_CURRENT( 'lookup_table_meta_info' ) AS A)
SET @CURRENT_LT_RESEED= case when @CURRENT_LT_RESEED is NULL then 0 else @CURRENT_LT_RESEED end;
SET @NEW_LT_RESEED =@CURRENT_LT_RESEED+5
DBCC CHECKIDENT ('lookup_table_meta_info', RESEED, @NEW_LT_RESEED)
SET @NEW_LT_INDENT=@CURRENT_LT_RESEED+2

IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END
	CREATE TABLE #TEMP_LT_OLDNEWKEY ( new_id int, old_id int)

--print @fileId

INSERT into #TEMP_LT_OLDNEWKEY (new_id,old_id)
(select @NEW_LT_INDENT+Row_number() Over(Order by lookup_table_id),lookup_table_id from lookup_table_meta_info ltmi where associated_file_level='C' 
and associated_file_type_id=@fileTypeId and lookup_table_version=@pmtVersion and associated_file_level_id=@pmtId)

SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON 
insert into lookup_table_meta_info(lookup_table_id,lookup_table_name,lookup_key_description,lookup_table_version,associated_file_level,associated_file_level_id,associated_file_type_id,created_by,created_date_time)
(select new_id,lookup_table_name,lookup_key_description,1,'F',@newRecordId, associated_file_type_id,@createdBy,@createdDateTime
from lookup_table_meta_info join #TEMP_LT_OLDNEWKEY temp on temp.old_id=lookup_table_id where associated_file_level='C' and associated_file_level_id=@pmtId
and  lookup_table_version=@pmtVersion and associated_file_type_id=@fileTypeId)
SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF

insert into lookup_table_details (lookup_table_id,lookup_table_version,lookup_key,lookup_value,created_by,created_date_time)
(select temp.new_id,1 ,lookup_key,lookup_value,@createdBy,@createdDateTime from lookup_table_details ltd
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltd.lookup_table_id and ltmi.lookup_table_version=ltd.lookup_table_version
join #TEMP_LT_OLDNEWKEY temp on temp.old_id=ltmi.lookup_table_id
where associated_file_level='C' and associated_file_level_id=@pmtId and ltmi.lookup_table_version=@pmtVersion and associated_file_type_id=@fileTypeId)

insert into lookup_table_composite_key_mapping(lookup_table_id,lookup_table_version,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,business_rule_id,
created_by,created_date_time,updated_by,updated_date_time)(select templt.new_id,1 ,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,
case when business_rule_id is NULL then NULL when business_rule_id is NOT NULL then temp.new_id end,
@createdBy,@createdDateTime,@createdBy, @createdDateTime from lookup_table_composite_key_mapping  ltckm
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltckm.lookup_table_id and ltmi.lookup_table_version=ltckm.lookup_table_version
INNER JOIN #TEMP_LT_OLDNEWKEY templt on templt.old_id= ltmi.lookup_table_id 
LEFT OUTER JOIN #TEMP_DBRDT_OLDNEWKEY temp on temp.old_id=business_rule_id 
where associated_file_level='C' and associated_file_level_id=@pmtId and  ltmi.lookup_table_version=@pmtVersion and associated_file_type_id=@fileTypeId)

insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,cftaa_id,is_active,created_by,created_date_time, updated_by,updated_date_time)
(select templt.new_id,1 ,temp.faa_id,null,null,1,@createdBy,@createdDateTime,@createdBy,@createdDateTime
from lookup_table_file_association ltfa
join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
INNER JOIN #TEMP_FTAA temp on temp.cftaa_id=ltfa.cftaa_id 
INNER JOIN #TEMP_LT_OLDNEWKEY templt on templt.old_id= ltmi.lookup_table_id where associated_file_level='C' and associated_file_level_id=@pmtId
and ltmi.lookup_table_version=@pmtVersion and associated_file_type_id=@fileTypeId and is_active=1 and ltfa.faa_id is NULL)

--print 'lookup done'
----------------------- END: Insert into lookup tables -----------------



				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------

				DECLARE @CTLSNI_COUNT INT
				select @CTLSNI_COUNT= count(1) from child_template_layout_schema_node_info ctlsni where
				ctlsni.child_file_template_record_id=@pmtRecordId and ctlsni.is_active=1
				
				
									DECLARE @NEW_FLSNI_RESEED INT=0
									DECLARE @CURRENT_FLSNI_RESEED INT=0
									DECLARE @NEW_FLSNI_INDENT INT=0
									SET @CURRENT_FLSNI_RESEED =(SELECT IDENT_CURRENT( 'file_layout_schema_node_info' ) AS A)
									SET @CURRENT_FLSNI_RESEED = case when @CURRENT_FLSNI_RESEED is NULL then 0 else @CURRENT_FLSNI_RESEED end;
									SET @NEW_FLSNI_RESEED =@CURRENT_FLSNI_RESEED+@CTLSNI_COUNT+5
									DBCC CHECKIDENT ('file_layout_schema_node_info', RESEED, @NEW_FLSNI_RESEED)
									SET @NEW_FLSNI_INDENT=@CURRENT_FLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_CTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_CTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_CTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_CTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_FLSNI_INDENT+Row_number() Over(Order by ctlsni_id),ctlsni_id
									from child_template_layout_schema_node_info ctlsni where
									ctlsni.child_file_template_record_id=@pmtRecordId and ctlsni.is_active=1)

									
									----------------------- START: Insert into file_layout_schema_node_info -----------------
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] ON 
									INSERT INTO [dbo].[file_layout_schema_node_info]([flsni_id],[ctlsni_id],[file_identifier],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[node_clone_num])
									SELECT new_id,null,@newRecordId,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@createdBy,@createdDateTime
									,@createdBy,@createdDateTime,[node_max_size],[node_min_size],[node_clone_num] FROM child_template_layout_schema_node_info ctlsni 
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsni.ctlsni_id=old_id
									where ctlsni.child_file_template_record_id=@pmtRecordId and ctlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] OFF
									--print 'file_layout_schema_node_info'
									--select * from file_layout_schema_node_info where file_identifier=@newRecordId
									----------------------- END: Insert into file_layout_schema_node_info -----------------
									

									----------------------- START: Insert into file_layout_schema_node_assoc -----------------
									INSERT INTO [dbo].[file_layout_schema_node_assoc]([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time], [updated_by],[updated_date_time])
									SELECT a.new_id,
									case when parent_ctlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@createdBy,@createdDateTime,@createdBy,@createdDateTime from [child_template_layout_schema_node_assoc] ctlsna
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsna.ctlsni_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsna.ctlsni_id=old_id left outer join #TEMP_CTLSNI_OLDNEWKEY b on ctlsna.parent_ctlsni_id=b.old_id
									where ctlsni.child_file_template_record_id=@pmtRecordId	and ctlsni.is_active=1
									--print 'file_layout_schema_node_assoc'
									--select * from file_layout_schema_node_assoc where flsni_id in (select flsni_id from file_layout_schema_node_info where file_identifier=@newRecordId)
									----------------------- END: Insert into file_layout_schema_node_assoc -----------------
									

									----------------------- START: Insert into fls_node_enum_value_assoc -----------------
									INSERT INTO [dbo].[fls_node_enum_value_assoc]([flsni_id],[ctaeva_id],[enum_value],[enum_value_description],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,ctaeva_id,enum_value,enum_value_description,ctlsnea.is_active,@createdBy,@createdDateTime,@createdBy,@createdDateTime from ctls_node_enum_value_assoc ctlsnea 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnea.ctlsni_id
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsnea.ctlsni_id=old_id 
									where ctlsni.child_file_template_record_id=@pmtRecordId and ctlsni.is_active=1 
									--print 'fls_node_enum_value_assoc'
									--select * from fls_node_enum_value_assoc where flsni_id in (select flsni_id from file_layout_schema_node_info where file_identifier=@newRecordId)
									----------------------- END: Insert into fls_node_enum_value_assoc -----------------
									

									----------------------- START: Insert into fls_node_dm_element_assoc -----------------
									INSERT INTO [dbo].[fls_node_dm_element_assoc]([flsni_id],[faa_id],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,faa.faa_id,ctlsnda.is_active,@createdBy,@createdDateTime,@createdBy,@createdDateTime from ctls_node_dm_element_assoc ctlsnda 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnda.ctlsni_id
									join file_attribute_association faa on faa.cftaa_id=ctlsnda.cftaa_id
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsnda.ctlsni_id=old_id 
									where ctlsni.child_file_template_record_id=@pmtRecordId and ctlsni.is_active=1 and faa.file_identifier=@newRecordId    
									--print 'fls_node_dm_element_assoc'
									--select * from fls_node_dm_element_assoc where flsni_id in (select flsni_id from file_layout_schema_node_info where file_identifier=@newRecordId)
									----------------------- END: Insert into fls_node_dm_element_assoc ----------------- 
									

									----------------------- START: Insert into fls_node_br_assoc -----------------
									INSERT INTO [dbo].[fls_node_br_assoc]([flsni_id],[business_rule_id],[rule_execution_sequence],[rule_execution_comment],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,rule_execution_comment,1,@createdBy,@createdDateTime,@createdBy,@createdDateTime from ctls_node_br_assoc ctlsnba 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
									join #TEMP_DBRDT_OLDNEWKEY b on ctlsnba.business_rule_id=b.old_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsnba.ctlsni_id=a.old_id where ctlsni.child_file_template_record_id=@pmtRecordId
									and ctlsni.is_active=1  and ctlsnba.is_active=1     
									--print 'fls_node_br_assoc'
									--select * from fls_node_br_assoc where flsni_id in (select flsni_id from file_layout_schema_node_info where file_identifier=@newRecordId)
									----------------------- END: Insert into fls_node_dm_element_assoc ----------------- 
			

									----------------------- START: Insert into file_special_mapping_attr_br_assoc -----------------
									INSERT INTO [dbo].[file_special_mapping_attr_br_assoc] ([file_identifier],[business_rule_id],[ftaa_id],[attribute_usage_type],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									(SELECT @newRecordId, new_id, ftaa_id,attribute_usage_type,1,@createdBy,@createdDateTime,@createdBy,@createdDateTime from cft_special_mapping_attr_br_assoc cftsmaba 
									left join #TEMP_DBRDT_OLDNEWKEY a on cftsmaba.business_rule_id=a.old_id
									where cftsmaba.child_file_template_record_id=@pmtRecordId and cftsmaba.is_active=1)   
									--print 'file_special_mapping_attr_br_assoc'
									--select * from file_special_mapping_attr_br_assoc where file_identifier=@newRecordId
									----------------------- END: Insert into file_special_mapping_attr_br_assoc ----------------- 
									
									

FETCH NEXT FROM pmtTempCur INTO @ipmt_record_id;
END
CLOSE pmtTempCur    
DEALLOCATE pmtTempCur

END;
GO


