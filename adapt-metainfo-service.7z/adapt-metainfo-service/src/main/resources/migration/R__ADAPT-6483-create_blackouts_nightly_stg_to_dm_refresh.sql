USE [idis-metainfo]
GO

DECLARE @StartDate AS DATETIME
DECLARE @EndDate AS DATETIME
DECLARE @CurrentDate AS DATETIME


SET @StartDate = cast((cast(datepart(year,getDate()) as varchar)+'-'+cast(datepart(month,getDate()) as varchar)+'-'+cast(datepart(day,getDate()) as varchar)+' 00:00:00.000') as date)
SET @EndDate = cast((cast(datepart(year,getDate()) as varchar)+'-12-31 00:00:00.000') as date)
SET @CurrentDate = @StartDate

WHILE (@CurrentDate < @EndDate)
BEGIN

	if not exists(select 1 from [adapt_processing_blackout_info] where [apbi_start_date_time]=dateadd(minute,30,@CurrentDate) 
	and [apbi_end_date_time]=dateadd(hour,1,@CurrentDate) and is_active=1)
	begin
	INSERT INTO [dbo].[adapt_processing_blackout_info]
	([apbi_start_date_time],[apbi_end_date_time],[apbi_description],[apbi_msg_prior_display_days],[is_active],[apbi_platform],[created_by],[created_date],[updated_by],[updated_date],[is_used_for_display])
	VALUES(dateadd(minute,30,@CurrentDate),dateadd(hour,1,@CurrentDate),'Daily blackout window for daily datamart refresh',0,1,1,'Divya Jain',getDate(),'Divya Jain',getDate(),1)
	end;

SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate); /*increment current date*/
END

GO

