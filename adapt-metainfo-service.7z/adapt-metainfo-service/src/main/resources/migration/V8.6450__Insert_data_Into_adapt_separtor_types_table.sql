/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-15   Jinesh vora			ADAPT-6450 : User should be able to configure  delimiter/terminator for the Outbound File
*/


if not exists (select 1 from adapt_separtor_types where adapt_sep_type_id in (8,9))
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] ON 
INSERT INTO [dbo].[adapt_separtor_types] (adapt_sep_type_id,adapt_sep_type_name,adapt_sep_type_is_active,created_date_time,created_by,updated_by,updated_date_time)
values (8,N'CRLF',1,getdate(),N'Jinesh Vora',NULL,NULL);
INSERT INTO [dbo].[adapt_separtor_types] (adapt_sep_type_id,adapt_sep_type_name,adapt_sep_type_is_active,created_date_time,created_by,updated_by,updated_date_time)
values (9,N',',1,getdate(),N'Jinesh Vora',NULL,NULL);
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] OFF 
END
GO
