USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Rules') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Rules AS SELECT 1')
GO

/*
21-06-2018	Divya Jain	CC-35093: Rules should be executed in the order that the user has specified from the attribute list screen
*/

ALTER Procedure [dbo].[USP_Get_Rules]
	(
              @i_file_identifier int,
              @i_group_names varchar(50),
			  @i_clone_num int
       )
AS
BEGIN

SET NOCOUNT ON;
declare @fileId int;
declare @fileVersion int;
declare @groupNames varchar(50);
declare @query nvarchar(max);

set @fileId=@i_file_identifier;
set @groupNames=@i_group_names;

set @query='SELECT
DROOLS.drools_business_rule_id,
DROOLS.drools_business_rule_version,
DROOLS.drools_business_rule_drl_file_content,
DROOLS.is_current,
case when FBR.rule_execution_sequence is NULL then 0 else FBR.rule_execution_sequence end rule_execution_sequence,
FAA.clone_num
FROM drools_business_rules_decision_table AS DROOLS
INNER JOIN drools_business_rule_group as dbrg ON dbrg.[drools_business_rule_group_id] = DROOLS.drools_business_rule_group_id
INNER JOIN file_attr_br_assoc AS FBR ON DROOLS.drools_business_rule_id=FBR.business_rule_id AND DROOLS.drools_business_rule_version=FBR.business_rule_version
INNER JOIN file_attribute_association AS FAA ON FBR.faa_id = FAA.faa_id
WHERE dbrg.drools_business_rule_group_name in (' + @groupNames + ')
AND FAA.file_identifier = ' + CAST(@fileId as varchar) + '
AND FAA.clone_num = ' + CAST(@i_clone_num as varchar);

EXECUTE sp_executesql @query;

END 



GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Rules TO exec_proc
GO

