USE [idis-metainfo]
GO

/*
Filename:  Proc_Child_Template_Versioning.sql
 
Parameters: 
@iChildTemplate_id
@iChildTemplate_old_version
@iCreated_by
@isRestored_versioning
 
***********************************************

Update Log
----------  ------------    ---------------------------------------------------------------------------------------
14-09-2018  Richa Ashara	   CC-36140  Update the File Versioning and Inheritance SPs to save user name as audit info
2018-12-26	Richa Ashara	ADAPT-307: User should be able to view the Last updated information for PMT/File Templates & Job Schedule
2019-02-27	Divya Jain		ADAPT-2526: Add "Source Type" and "Target Type" to File Setup
2019-06-25	Divya Jain		ADAPT-6510: USP_Get_Dynamic_Schema_Attribute- values under 'columnOrder' are NULL
2019-08-06	Jinesh Vora		ADAPT-6906 : Clone records should be at the PMT level, not just the file level
2019-08-27  Bhaumik Sathvara ADAPT-7324: Removed is_draft column from drools_business_rules_decision_table and added to_do column in child_file_template_attribute_association.
2019-09-29	Jinesh Vora		ADAPT-7708 : PMT Remove 	
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/

IF OBJECT_ID('dbo.Proc_Child_Template_Versioning') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.Proc_Child_Template_Versioning');
GO

/*
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.Proc_Child_Template_Versioning') IS NULL
EXEC('CREATE PROCEDURE dbo.Proc_Child_Template_Versioning AS SELECT 1')
GO

ALTER procedure [dbo].[Proc_Child_Template_Versioning]
   @iChildTemplate_id int,
   @iChildTemplate_old_version int,
   @iCreated_by varchar(50),
   @isRestored_versioning bit,
   @isCopyOfPmt  bit = 0,
   @copiedPmtName varchar(80) = null,
   @oError_code int OUTPUT,
   @oCopiedPmtId int = 0 OUTPUT,
   @oCopiedPmtVer int = 0 OUTPUT,
   @oCopiedPmtRecordId int = 0 OUTPUT
   AS 
   BEGIN


	DECLARE @Error_code INT;
	DECLARE @cftaa_id INT;
	DECLARE @cftsa_id INT;
	DECLARE @cftsa_id_FK INT;
	DECLARE @attribute_id INT;
	DECLARE @NewAttrId INT;
	DECLARE @NewTemplateSectionId INT;
	DECLARE @template_section_id INT;
	DECLARE @parent_cftsa_id INT;
	DECLARE @new_cftsa_id INT;
	DECLARE @counter INT;
	DECLARE @total_row INT;
	DECLARE @inserted TABLE ([ID] INT, [old_id] INT,[counter] INT);
	DECLARE @old_cftsa_id INT;
	DECLARE @file_type_id INT;
	DECLARE @iChildTemplate_new_version int;
	DECLARE @iChildTemplate_max_version int;
	DECLARE @iChildTemplate_max_version_status int;
	DECLARE @NewChildRecordId INT;

	 if(@isCopyOfPmt is null)
		set @isCopyOfPmt = 0 

	SET @Error_code=0;

	   -- check if is this for PMt copying, PMT name is not there.
    if(@isCopyOfPmt = 1)
    BEGIN
     if(@copiedPmtName is null or @copiedPmtName = '' )
	   BEGIN
		  set @Error_code=-3;
		  GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	   END
     -- check unique ness for Child File Template Meta Info
	if EXISTS ( select 1 from [dbo].[child_file_template_meta_info] where child_file_template_name = @copiedPmtName)
	BEGIN
	   set @Error_code=-4;
	   GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	END
    END

	-- Check if a parallel process has not already initiated  a file edit and created a draft
	if(@isRestored_versioning = 0 and @isCopyOfPmt=0)
	BEGIN
	    if exists(select 1 from [dbo].[child_file_template_meta_info] where [child_file_template_id] = @iChildTemplate_id and [approval_status_id] in (1,2))
	    BEGIN
		    set @Error_code=-2;
		  GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	   END 
    END

	 BEGIN TRANSACTION;

	SELECT @iChildTemplate_max_version_status = [approval_status_id], @iChildTemplate_max_version = [child_file_template_version] from [dbo].[child_file_template_meta_info]
	where [child_file_template_id]=@iChildTemplate_id  and  child_file_template_version in (select  max(child_file_template_version) from [dbo].[child_file_template_meta_info]
	where [child_file_template_id]=@iChildTemplate_id )

    IF(@isRestored_versioning = 1 AND @iChildTemplate_max_version_status in (1,2))
	BEGIN
	   EXEC [dbo].[USP_Child_File_Template_Deletion] @iChildTemplate_id = @iChildTemplate_id,@iChildTemplate_version = @iChildTemplate_max_version
	   SET @iChildTemplate_new_version = @iChildTemplate_max_version
	END
	ELSE IF(@isCopyOfPmt = 1)
	BEGIN
		SET @iChildTemplate_new_version= 1;
	END
	ELSE
	BEGIN
	 SET @iChildTemplate_new_version = @iChildTemplate_max_version + 1
	END


	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int)


	BEGIN TRY 

	--select * FROM [dbo].[child_file_template_meta_info] where [child_file_template_id]=@iChildTemplate_id and [child_file_template_version]=@iChildTemplate_old_version
		DECLARE @new_pmt_id int
		SELECT @new_pmt_id=MAX([child_file_template_id])+1 from [dbo].[child_file_template_meta_info]


		-- Duplicating the child meta info row with same child id and new version 
		--SET IDENTITY_INSERT [dbo].[child_file_template_meta_info] ON;
		INSERT INTO [dbo].[child_file_template_meta_info]
           ([child_file_template_id]
            ,[child_file_template_name]
			      ,[child_file_template_description]
			      ,[master_file_template_id]
				  ,[master_file_template_record_id]
			      ,[master_file_template_version]
			      ,[child_file_template_version]
			      ,[trading_partner_id]
			      ,[lob_id]
				  ,[child_file_template_layout]
			      ,[is_active]
			      ,[approval_status_id]
			      ,[approval_status_updated_by]
			      ,[approval_status_updated_date]
			      ,[approval_status_comment]
			      ,[created_by]
			      ,[created_date_time]
				  ,[updated_by]
				  ,[updated_date_time]
				  ,[data_source_type_id]
		          ,[data_target_type_id])
           (SELECT case when @isCopyOfPmt=1 then @new_pmt_id else [child_file_template_id] end
				  ,case when @isCopyOfPmt=1 then @copiedPmtName else [child_file_template_name] end
			      ,[child_file_template_description]
			      ,[master_file_template_id]
				  ,[master_file_template_record_id]
			      ,[master_file_template_version]
			      ,@iChildTemplate_new_version
			      ,[trading_partner_id]
			      ,[lob_id]
				  ,[child_file_template_layout]
			      ,0
			      ,1
			      ,NULL
			      ,NULL
			      ,NULL
			      ,@iCreated_by
			      ,getDate()
				  ,@iCreated_by
			      ,getDate()
				  ,[data_source_type_id]
		          ,[data_target_type_id] FROM [dbo].[child_file_template_meta_info] where [child_file_template_id]=@iChildTemplate_id and [child_file_template_version]=@iChildTemplate_old_version)
		--SET IDENTITY_INSERT [dbo].[child_file_template_meta_info] OFF
	
	
		--select * FROM [dbo].[child_file_template_meta_info] where [child_file_template_id]=@iChildTemplate_id and [child_file_template_version]=@iChildTemplate_new_version

		SELECT @file_type_id=[file_type_id],@NewChildRecordId=child_file_template_record_id  from [dbo].[child_file_template_meta_info] cftmi 
		join [dbo].[master_file_template_meta_info] mftmi on cftmi.master_file_template_id=mftmi.master_file_template_id and 
		cftmi.master_file_template_version=mftmi.master_file_template_version 
		where [child_file_template_id]=case when @isCopyOfPmt=1 then @new_pmt_id else @iChildTemplate_id end 
		and [child_file_template_version]=case when @isCopyOfPmt=1 then 1 else @iChildTemplate_new_version end

	
		 SET @oCopiedPmtId = case when @isCopyOfPmt=1 then @new_pmt_id else @iChildTemplate_id end
		 SET @oCopiedPmtVer = case when @isCopyOfPmt=1 then 1 else @iChildTemplate_new_version end
		 SET @oCopiedPmtRecordId = @NewChildRecordId
	 
	
	------------------------- START:: temp table for rules  ----------------------------------------
	
	IF OBJECT_ID('idis-metainfo.dbo.TEMP_PMT_VERSION_RULE_OLDNEWKEY') IS NULL 
	BEGIN
	CREATE TABLE [idis-metainfo].[dbo].TEMP_PMT_VERSION_RULE_OLDNEWKEY (pmt_id int, new_id int, old_id int ,rule_version int)
	END;

	IF OBJECT_ID('idis-metainfo.dbo.TEMP_PMT_VERSION_RULE_OLDNEWKEY') IS NOT NULL 
	BEGIN
	delete from [idis-metainfo].[dbo].TEMP_PMT_VERSION_RULE_OLDNEWKEY where pmt_id=@NewChildRecordId
	END;

	------------------------- END::  temp table for rules  ----------------------------------------

	
		--- get record count for rules ----
DECLARE @RULES_COUNT INT=0
SET @RULES_COUNT = (select count(1) from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_id] = @iChildTemplate_id AND cftaa.[child_file_template_version] = @iChildTemplate_old_version
)+
(select count(1) from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@iChildTemplate_id AND ltmi.lookup_table_version = @iChildTemplate_old_version
and ltmi.associated_file_type_id=@file_type_id
)+
(select count(1) from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version and ctlsni.is_active=1
)+
(select count(1) from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version and cftsmaba.is_active=1
)

--print @RULES_COUNT

if @RULES_COUNT>0
BEGIN
--Duplicating the Business Rules Association rows with same id and new versions
--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2


INSERT into TEMP_PMT_VERSION_RULE_OLDNEWKEY (pmt_id,new_id,old_id,rule_version)
(select @NewChildRecordId,@NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version+1 from (
select drools_business_rule_id,drools_business_rule_version from child_file_template_attribute_association cftaa
join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftaba.business_rule_id
where cftaa.[child_file_template_id] = @iChildTemplate_id AND cftaa.[child_file_template_version] = @iChildTemplate_old_version
union
select drools_business_rule_id,drools_business_rule_version from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='C' and ltmi.associated_file_level_id=@iChildTemplate_id AND ltmi.lookup_table_version = @iChildTemplate_old_version
and ltmi.associated_file_type_id=@file_type_id
union
select drools_business_rule_id,drools_business_rule_version from ctls_node_br_assoc ctlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ctlsnba.business_rule_id
join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version and ctlsni.is_active=1
union
select drools_business_rule_id,drools_business_rule_version from cft_special_mapping_attr_br_assoc cftsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=cftsmaba.business_rule_id
join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id
where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version and cftsmaba.is_active=1
) a)


SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join TEMP_PMT_VERSION_RULE_OLDNEWKEY
on drools_business_rule_id=old_id and pmt_id=@NewChildRecordId)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

END;
	
		-- inserting in audit table to maintain the version history with ids 
		INSERT INTO [dbo].[child_file_template_version_audit]
               ([child_template_id]
               ,[from_version]
               ,[to_version]
               ,[created_date]
               ,[created_by]
               ,[approval_status_id])
         VALUES
               (case when @isCopyOfPmt=1 then @new_pmt_id else @iChildTemplate_id end
               ,@iChildTemplate_old_version
               ,@iChildTemplate_new_version
               ,GETDATE()
               ,@iCreated_by
               ,1)	
		   
			-- ADAPT : 6906 START 
			INSERT INTO [dbo].[child_file_template_clone_info]
				(
				child_file_template_record_id,
				clone_num,
				clone_name,
				created_by,
				created_date_time,
				updated_by,
				updated_date_time)
				SELECT 
					@NewChildRecordId,
					cftci.clone_num,
					cftci.clone_name,
					@iCreated_by,
					getDate(),
					@iCreated_by,
					getDate()
				FROM 
				[child_file_template_clone_info] cftci JOIN 
				[child_file_template_meta_info]  cftmi
				ON cftci.child_file_template_record_id = cftmi.child_file_template_record_id  
				where cftmi.[child_file_template_id] = @iChildTemplate_id AND cftmi.[child_file_template_version] = @iChildTemplate_old_version
			-- ADAPT : 6906 END
			-- Here		
		   
             
     SET @counter = 1;
    DECLARE cur CURSOR LOCAL FOR SELECT [cftsa_id],[template_section_id] FROM [dbo].[child_file_template_section_assoc] where [child_file_template_id]=@iChildTemplate_id and child_file_template_version=@iChildTemplate_old_version ;
		OPEN cur;

		FETCH NEXT FROM cur INTO @cftsa_id,@template_section_id;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			--SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] ON;
			INSERT INTO [dbo].[child_file_template_section_assoc]
           ([template_section_id]
	           ,[child_file_template_id]
			   ,[child_file_template_record_id]
	           ,[child_file_template_version]
	           ,[template_compliant_section_short_name]
			   ,[section_display_name]
	           ,[sequence]
	           ,[is_madatory]
	           ,[created_by]
	           ,[created_date_time]
	           ,[updated_by]
	           ,[updated_date_time])
			OUTPUT INSERTED.[cftsa_id],@cftsa_id,@counter INTO @inserted([ID],[old_id],[counter])
           (SELECT [template_section_id]
			      ,case when @isCopyOfPmt=1 then @new_pmt_id else child_file_template_id end
				  ,@NewChildRecordId
			      ,@iChildTemplate_new_version
			      ,[template_compliant_section_short_name]
				  ,[section_display_name]
			      ,[sequence]
			      ,[is_madatory]
			      ,@iCreated_by
			      ,getDate()
			      ,@iCreated_by
			      ,getDate()
		  FROM [dbo].[child_file_template_section_assoc] where cftsa_id=@cftsa_id)
	-- 	  SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] OFF;

	  SET  @counter = @counter + 1;

	 -- print 'sections are done too'

      SELECT @NewTemplateSectionId=[cftsa_id]
			FROM dbo.child_file_template_section_assoc WHERE template_section_id=@template_section_id and child_file_template_record_id=@NewChildRecordId;
		
			
				DECLARE attrcur CURSOR LOCAL FOR SELECT [cftsa_id],[cftaa_id],[attribute_id] FROM [dbo].[child_file_template_attribute_association] where [child_file_template_id]=@iChildTemplate_id and child_file_template_version=@iChildTemplate_old_version and cftsa_id=@cftsa_id;
							OPEN attrcur;

							FETCH NEXT FROM attrcur INTO @cftsa_id_FK,@cftaa_id,@attribute_id;
							WHILE @@FETCH_STATUS = 0
							BEGIN
						
								-- JINESH 
								INSERT INTO [dbo].[child_file_template_attribute_association]
								([child_file_template_id]
								,[child_file_template_version]
								,[child_file_template_record_id]
								,[attribute_id]
								,[attribute_row_position]
								,[data_type]
								,[is_mandatory]
								,[application_compliant_attribute_name]
								,[cftsa_id]
								,[attribute_start_position]
								,[attribute_end_position]
								,[attribute_size]
								,[is_inherited]
								,[mftaa_id]
								,[created_by]
								,[created_date_time]
								,[clone_num]					 -- ADAPT : 6906 ADDED
						    	,[to_do])		
								(SELECT case when @isCopyOfPmt=1 then @new_pmt_id else child_file_template_id end
										,@iChildTemplate_new_version
										,@NewChildRecordId
										,[attribute_id]
										,[attribute_row_position]
										,[data_type]
										,[is_mandatory]
										,[application_compliant_attribute_name]
										,@NewTemplateSectionId
										,[attribute_start_position]
										,[attribute_end_position]
										,[attribute_size]
										,[is_inherited]
										,[mftaa_id]
										,@iCreated_by
										,getDate()
										,clone_num			-- ADAPT : 6906 ADDED
										,to_do
								FROM [dbo].[child_file_template_attribute_association] WHERE
								cftsa_id=@cftsa_id_FK and cftaa_id=@cftaa_id and attribute_id=@attribute_id)


					
						  --  print 'sttaribute insertion is done too'
							SELECT @NewAttrId=[cftaa_id]
									FROM dbo.child_file_template_attribute_association WHERE cftsa_id=@NewTemplateSectionId and attribute_id=@attribute_id and 
									child_file_template_record_id=@NewChildRecordId;
						
							insert into #TEMP_OLDNEWKEY(new_id,old_id) values(@NewAttrId,@cftaa_id)
						
															
									INSERT INTO [idis-metainfo].[dbo].[child_file_template_attr_br_assoc]([cftaa_id],[business_rule_id],[business_rule_version],[rule_execution_sequence],[rule_execution_comment]
									,[created_by],[created_date_time], [updated_by],[updated_date_time])
									(SELECT @NewAttrId,C.new_id,C.rule_version,D.rule_execution_sequence,rule_execution_comment,@iCreated_by,GETDATE(),@iCreated_by,GETDATE()
									FROM [idis-metainfo].[dbo].[child_file_template_attr_br_assoc] D INNER JOIN TEMP_PMT_VERSION_RULE_OLDNEWKEY C 
									ON D.business_rule_id=C.old_id and pmt_id=@NewChildRecordId where D.cftaa_id = @cftaa_id)
								
								
									FETCH NEXT FROM attrcur INTO @cftsa_id_FK,@cftaa_id,@attribute_id;
						END
						CLOSE attrcur    
						DEALLOCATE attrcur
		
			FETCH NEXT FROM cur INTO @cftsa_id,@template_section_id;
		END
		CLOSE cur    
		DEALLOCATE cur


INSERT INTO [dbo].[child_secondary_mapping_attr_assoc]
		([csmaa_child_file_template_record_id]
		,[csmaa_cftaa_id]
		,[csmaa_node_name]
		,[csmaa_standardized_name]
		,[created_date_time]
		,[created_by]
		,[updated_date_time]
		,[updated_by]
		)
		(SELECT @NewChildRecordId
		,temp.new_id
		,[csmaa_node_name]
		,[csmaa_standardized_name]
		,getDate()
		,@iCreated_by
		,getDate()
		,@iCreated_by
			FROM [dbo].[child_secondary_mapping_attr_assoc] csmaa
			join #TEMP_OLDNEWKEY temp on temp.old_id=csmaa_cftaa_id
			join child_file_template_meta_info cftmi on csmaa.csmaa_child_file_template_record_id=cftmi.child_file_template_record_id 
			where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version)


		SET @counter = 1
		SELECT @total_row = COUNT(1) from @inserted
		WHILE(@counter <= @total_row )
			BEGIN
				SELECT @new_cftsa_id = ID, @old_cftsa_id = old_id from @inserted where [counter] = @counter
				SET @counter = @counter+ 1;	
			END
								

									DECLARE @NEW_LTMI_RESEED INT
									DECLARE @CURRENT_LTMI_RESEED INT
									DECLARE @NEW_LTMI_INDENT INT
									SET @CURRENT_LTMI_RESEED=(SELECT IDENT_CURRENT( 'lookup_table_meta_info' ) AS A)
									SET @NEW_LTMI_RESEED =@CURRENT_LTMI_RESEED+5
									DBCC CHECKIDENT ('lookup_table_meta_info', RESEED, @NEW_LTMI_RESEED)
									SET @NEW_LTMI_INDENT=@CURRENT_LTMI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END
									CREATE TABLE #TEMP_LT_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_LT_OLDNEWKEY (new_id,old_id) (select @NEW_LTMI_INDENT+Row_number() Over(Order by lookup_table_id),lookup_table_id
									from lookup_table_meta_info where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id 
									and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_old_version)
								
									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON 
									insert into lookup_table_meta_info(lookup_table_id,lookup_table_name,lookup_key_description,lookup_table_version,associated_file_level,associated_file_level_id,
									associated_file_type_id,created_by,created_date_time)
									(select new_id,lookup_table_name,lookup_key_description,@iChildTemplate_new_version,associated_file_level,
									case when @isCopyOfPmt=1 then @new_pmt_id else associated_file_level_id end, associated_file_type_id,@iCreated_by,getDate()
									from lookup_table_meta_info join #TEMP_LT_OLDNEWKEY temp on lookup_table_id=old_id
									where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iChildTemplate_old_version)
									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF

									insert into lookup_table_details (lookup_table_id,lookup_table_version,lookup_key,lookup_value,created_by,created_date_time)
									(select temp.new_id,@iChildTemplate_new_version ,lookup_key,lookup_value,@iCreated_by,getDate() from lookup_table_details ltd
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltd.lookup_table_id and ltmi.lookup_table_version=ltd.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY temp on ltmi.lookup_table_id=temp.old_id
									where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iChildTemplate_old_version)

									insert into lookup_table_composite_key_mapping(lookup_table_id,lookup_table_version,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,business_rule_id,
									created_by,created_date_time,updated_by,updated_date_time)(select templt.new_id,@iChildTemplate_new_version ,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,
									case when business_rule_id is NULL then NULL when business_rule_id is NOT NULL then temp.new_id end,
									@iCreated_by,getDate(),@iCreated_by,getDate() from lookup_table_composite_key_mapping ltckm LEFT OUTER JOIN TEMP_PMT_VERSION_RULE_OLDNEWKEY temp 
									on temp.old_id=business_rule_id and pmt_id=@NewChildRecordId
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltckm.lookup_table_id and ltmi.lookup_table_version=ltckm.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iChildTemplate_old_version)

									insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,cftaa_id,is_active,created_by,created_date_time,updated_by,updated_date_time)
									(select templt.new_id,@iChildTemplate_new_version ,NULL,mftaa_id,temp.new_id,1,@iCreated_by,getDate(),@iCreated_by,getDate() 
									from lookup_table_file_association ltfa  join #TEMP_OLDNEWKEY temp on cftaa_id=temp.old_id
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='C' and associated_file_level_id=@iChildTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iChildTemplate_old_version
									 and faa_id is NULL and is_active=1)


								 
			
								 
				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
									DECLARE @NEW_CTLSNI_RESEED INT
									DECLARE @CURRENT_CTLSNI_RESEED INT
									DECLARE @NEW_CTLSNI_INDENT INT
									SET @CURRENT_CTLSNI_RESEED=(SELECT IDENT_CURRENT( 'child_template_layout_schema_node_info' ) AS A)
									SET @NEW_CTLSNI_RESEED =@CURRENT_CTLSNI_RESEED+5
									DBCC CHECKIDENT ('child_template_layout_schema_node_info', RESEED, @NEW_CTLSNI_RESEED)
									SET @NEW_CTLSNI_INDENT=@CURRENT_CTLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_CTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_CTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_CTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_CTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_CTLSNI_INDENT+Row_number() Over(Order by ctlsni_id),ctlsni_id
									from child_template_layout_schema_node_info ctlsni join child_file_template_meta_info cftmi 
									on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id where 
									cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1)

								
									SET IDENTITY_INSERT [dbo].[child_template_layout_schema_node_info] ON 
									INSERT INTO [dbo].[child_template_layout_schema_node_info]([ctlsni_id],[mtlsni_id],[child_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num])
									SELECT new_id,mtlsni_id,@NewChildRecordId,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@iCreated_by,getDate()
									,@iCreated_by,getDate(),[node_max_size],[node_min_size],[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num]
									FROM child_template_layout_schema_node_info ctlsni 
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsni.ctlsni_id=old_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[child_template_layout_schema_node_info] OFF
								
									INSERT INTO [dbo].[child_template_layout_schema_node_assoc]([ctlsni_id],[parent_ctlsni_id],[node_has_children],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,
									case when parent_ctlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@iCreated_by,getDate(),@iCreated_by,getDate() from [child_template_layout_schema_node_assoc] ctlsna
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsna.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsna.ctlsni_id=a.old_id left outer join #TEMP_CTLSNI_OLDNEWKEY b on ctlsna.parent_ctlsni_id=b.old_id
									where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1

								
									INSERT INTO [dbo].[ctls_node_enum_value_assoc]([ctlsni_id],[mtaeva_id],[enum_value],[enum_value_description],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,[mtaeva_id],enum_value,enum_value_description,ctlsnea.is_active,@iCreated_by,getDate(),@iCreated_by,getDate() from ctls_node_enum_value_assoc ctlsnea 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnea.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join #TEMP_CTLSNI_OLDNEWKEY on ctlsnea.ctlsni_id=old_id 
									where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1 
								
			

									INSERT INTO [dbo].[ctls_node_dm_element_assoc]([ctlsni_id],[cftaa_id],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,ctlsnda.is_active,@iCreated_by,getDate(),@iCreated_by,getDate() from ctls_node_dm_element_assoc ctlsnda 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnda.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id 
									join #TEMP_OLDNEWKEY b on cftaa_id=b.old_id
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsnda.ctlsni_id=a.old_id 
									where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1      
								

									INSERT INTO [dbo].[ctls_node_br_assoc]([ctlsni_id],[business_rule_id],[rule_execution_sequence],[rule_execution_comment],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,rule_execution_comment,1,@iCreated_by,getDate(),@iCreated_by,getDate() from ctls_node_br_assoc ctlsnba 
									join child_template_layout_schema_node_info ctlsni on ctlsni.ctlsni_id=ctlsnba.ctlsni_id
									join child_file_template_meta_info cftmi on ctlsni.child_file_template_record_id=cftmi.child_file_template_record_id
									join TEMP_PMT_VERSION_RULE_OLDNEWKEY b on ctlsnba.business_rule_id=b.old_id and pmt_id=@NewChildRecordId
									join #TEMP_CTLSNI_OLDNEWKEY a on ctlsnba.ctlsni_id=a.old_id where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version
									and ctlsni.is_active=1  and ctlsnba.is_active=1  
		
									INSERT INTO [dbo].[cft_special_mapping_attr_br_assoc] ([child_file_template_record_id],[business_rule_id],[ftaa_id],[attribute_usage_type],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									(SELECT @NewChildRecordId, new_id, ftaa_id,attribute_usage_type,1,@iCreated_by,getDate(),@iCreated_by,getDate() from cft_special_mapping_attr_br_assoc cftsmaba 
									left join TEMP_PMT_VERSION_RULE_OLDNEWKEY a on cftsmaba.business_rule_id=a.old_id  and pmt_id=@NewChildRecordId
									join child_file_template_meta_info cftmi on cftsmaba.child_file_template_record_id=cftmi.child_file_template_record_id 
									where cftmi.child_file_template_id=@iChildTemplate_id AND cftmi.child_file_template_version = @iChildTemplate_old_version and cftsmaba.is_active=1)
		

		
		COMMIT TRANSACTION;
		SET @oError_code = 0;
		SET @Error_code = 0;
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
		SET @Error_code = -1;
	END CATCH 


	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END

		IF OBJECT_ID('tempdb..#TEMP_LT_NEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END

			 END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @Error_code = -2)
			BEGIN
			print 'Error: A draft has already been created for the Chile File Template. A new draft cannot be created'
			SET @oError_code=@Error_code
			RETURN -2
		END
		ELSE IF ( @Error_code <> 0)
			BEGIN
			print 'Error: Some Error occured while creating a version'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE
			BEGIN
			print 'Chile File Template Version created Successfully... '
			SET @oError_code=0
			RETURN 0
		END 
							

END

GO


-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.[Proc_Child_Template_Versioning] TO exec_proc
GO

GO

*/
