use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-26   Jinesh vora			ADAPT-7708 : Remove the PMT Feature 

INDEX REBUILD 

IX_File_Meta_Info_K2
IX_File_Meta_Info_K24_K25_K2
IX_File_Meta_Info_K24_K25_K8_K2
IX_file_meta_info_K6
IX_File_Meta_Info_K6_K7_K38

COLUMN 
	file_meta_info.child_file_template_id
	file_meta_info.child_file_template_version
	file_meta_info.child_file_template_record_id
	lookup_table_file_association.cftaa_id
	file_attribute_association.cftaa_id
	config_promotion_audit_info.pmt_id
	config_promotion_audit_info.pmt_version
	config_promotion_audit_info.was_pmt_promoted
	file_layout_schema_node_info.ctlsni_id
	fls_node_enum_value_assoc.ctaeva_id

*/

-- IX_File_Meta_Info_K2

IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K2] ON [dbo].[File_Meta_Info]
(
	[file_id]
)INCLUDE(record_id, file_type_id, master_file_template_id, master_file_template_version, file_version, file_name, file_status, is_active, approval_status_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO



-- IX_File_Meta_Info_K24_K25_K2

IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K24_K25_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K24_K25_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K24_K25_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K24_K25_K2] ON [dbo].[file_meta_info]
(
	[is_active] ASC,
	[approval_status_id] ASC,
	[file_id] ASC
)
INCLUDE ( 	[record_id],
	[file_version],
	[file_name],
	[file_status],
	[master_file_template_id],
	[master_file_template_version],
	[file_type_id]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO


-- IX_File_Meta_Info_K24_K25_K8_K2
IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K24_K25_K8_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K24_K25_K8_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K24_K25_K8_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K24_K25_K8_K2] ON [dbo].[File_Meta_Info]
(
	[is_active],[approval_status_id],[file_version],[file_id]
)INCLUDE(record_id,file_Name,file_Status,master_file_template_id,master_file_template_version,file_type_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

-- IX_file_meta_info_K6
IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_file_meta_info_K6')
BEGIN
DROP INDEX File_Meta_Info.IX_file_meta_info_K6
END;
GO

-- IX_File_Meta_Info_K6_K7_K38

IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K6_K7_K38')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K6_K7_K38
END;
GO


-- lookup_table_file_association
-- IX_lookup_table_file_association_K6_K7 -- cftaa_id, is_active


IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K6_K7')
BEGIN
DROP INDEX lookup_table_file_association.IX_lookup_table_file_association_K6_K7
END;
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K7')
BEGIN
CREATE NONCLUSTERED INDEX [IX_lookup_table_file_association_K7] ON [dbo].[lookup_table_file_association]
(
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO

-------------------------- FK

-- FILE META INFO
IF EXISTS (
	SELECT *
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_NAME='FK_fmi_K38_cftmi_K15'
	)
BEGIN
alter table file_meta_info
drop constraint FK_fmi_K38_cftmi_K15
END;
GO


IF EXISTS (
	SELECT *
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_NAME='FK_fmi_K6_K7_cftmi_K1_K2'
	)
BEGIN
alter table file_meta_info
drop constraint FK_fmi_K6_K7_cftmi_K1_K2
END;
GO

---------------------------------- DK

IF EXISTS (
	SELECT * FROM dbo.sysobjects WHERE ID = OBJECT_ID(N'DF_config_promotion_audit_info_pmt_promoted')
	)
BEGIN
alter table config_promotion_audit_info
drop constraint DF_config_promotion_audit_info_pmt_promoted
END;
GO


----------------- COLUMN 

-- child_file_template_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_id')
BEGIN
ALTER TABLE file_meta_info
DROP COLUMN child_file_template_id
END;
GO

-- child_file_template_version
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_version')
BEGIN
ALTER TABLE file_meta_info
DROP COLUMN child_file_template_version
END;
GO


-- child_file_template_record_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_record_id')
BEGIN
ALTER TABLE file_meta_info
DROP COLUMN child_file_template_record_id
END;
GO


-- lookup_table_file_association.cftaa_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='lookup_table_file_association' and column_name ='cftaa_id')
BEGIN
ALTER TABLE lookup_table_file_association
DROP COLUMN cftaa_id
END;
GO

-- file_attribute_association.cftaa_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_attribute_association' and column_name ='cftaa_id')
BEGIN
ALTER TABLE file_attribute_association
DROP COLUMN cftaa_id
END;
GO


-- config_promotion_audit_info.pmt_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='pmt_id')
BEGIN
ALTER TABLE config_promotion_audit_info
DROP COLUMN pmt_id
END;
GO

-- pmt_version
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='pmt_version')
BEGIN
ALTER TABLE config_promotion_audit_info
DROP COLUMN pmt_version
END;
GO

-- config_promotion_audit_info.was_pmt_promoted
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='was_pmt_promoted')
BEGIN
ALTER TABLE config_promotion_audit_info
DROP COLUMN was_pmt_promoted
END;
GO

-- 	file_layout_schema_node_info.ctlsni_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_layout_schema_node_info' and column_name ='ctlsni_id')
BEGIN
ALTER TABLE file_layout_schema_node_info
DROP COLUMN ctlsni_id
END;
GO

-- 	fls_node_enum_value_assoc.ctaeva_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='fls_node_enum_value_assoc' and column_name ='ctaeva_id')
BEGIN
ALTER TABLE fls_node_enum_value_assoc
DROP COLUMN ctaeva_id
END;
GO


-----------------------------------------------------------------------------------------------------------------------------


-- Remove Permission Mapping From roles_idis_dbrd_actions_assoc

IF EXISTS (SELECT 1 FROM roles_idis_dbrd_actions_assoc WHERE 
ACTION_ID IN (SELECT ACTION_ID FROM idis_dbrd_func_actions where functionality_id = 3))

BEGIN

DELETE FROM roles_idis_dbrd_actions_assoc WHERE 
ACTION_ID IN (SELECT ACTION_ID FROM idis_dbrd_func_actions where functionality_id = 3);

END;
GO


-- Remove Permission Mapping From idis_dbrd_func_actions

IF EXISTS (SELECT 1 FROM idis_dbrd_func_actions where functionality_id = 3)
BEGIN
DELETE FROM idis_dbrd_func_actions where functionality_id = 3
END;

GO


-- Remove Permission Mapping From idis_dbrd_func
IF EXISTS (select * from idis_dbrd_func where functionality_id = 3 and functionality_name = 'PMT Setup')
BEGIN
DELETE FROM idis_dbrd_func where functionality_id = 3 and functionality_name = 'PMT Setup'
END;
GO

-- Remove Tool Tips FROM adapt_web_page_fields

IF EXISTS (select 1 from tooltip_meta_info where tooltip_field_id in (select adapt_web_page_field_id from adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35)))
BEGIN 
DELETE FROM tooltip_meta_info where tooltip_field_id in (select adapt_web_page_field_id from adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35))
END
GO



-- Remove Web Page & Web Page Fields FROM adapt_web_page_fields

IF EXISTS (SELECT 1 FROM adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35))
BEGIN 
DELETE FROM adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35) 
END
GO


-- Remove Web Page & Web Page Fields FROM adapt_web_page

IF EXISTS (SELECT 1 FROM adapt_web_pages where adapt_web_page_id in (10,12,13,14,15,25,35))
BEGIN 
DELETE FROM adapt_web_pages where adapt_web_page_id in (10,12,13,14,15,25,35) 
END
GO

-- Remove Lookup Details for all lookup tables for PMT

IF EXISTS (select 1 from lookup_table_details where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C'))
BEGIN 
DELETE from lookup_table_details where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C')
END
GO

-- Remove Lookup Composite Mappings for all lookup tables for PMT

IF EXISTS (select 1 from lookup_table_details where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C'))
BEGIN 
DELETE from lookup_table_details where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C')
END
GO

-- Remove Lookup File Associations for all lookup tables for PMT

IF EXISTS (select 1 from lookup_table_file_association where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C'))
BEGIN 
DELETE from lookup_table_file_association where lookup_table_id in (select lookup_table_id from lookup_table_meta_info  where associated_file_level='C')
END
GO

-- Remove Lookup Tables for PMT

IF EXISTS (select 1 from lookup_table_meta_info  where associated_file_level='C')
BEGIN 
DELETE from lookup_table_meta_info  where associated_file_level='C'
END
GO

--------------------------------------------------------------------------------------------------------------------------------------------
-- TABLE DROP 
--------------------------------------

-- cft_special_mapping_attr_br_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'cft_special_mapping_attr_br_assoc')
BEGIN 
Drop TABLE cft_special_mapping_attr_br_assoc;
END;
GO 


-- child_file_template_approval_audit
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_approval_audit')
BEGIN 
Drop TABLE child_file_template_approval_audit;
END;
GO 


-- child_file_template_attr_br_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_attr_br_assoc')
BEGIN 
Drop TABLE child_file_template_attr_br_assoc;
END;
GO 


-- child_file_template_clone_info
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_clone_info')
BEGIN 
Drop TABLE child_file_template_clone_info;
END;
GO 

-- child_secondary_mapping_attr_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'child_secondary_mapping_attr_assoc')
BEGIN 
Drop TABLE child_secondary_mapping_attr_assoc;
END;
GO

-- ctls_node_br_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'ctls_node_br_assoc')
BEGIN 
Drop TABLE ctls_node_br_assoc;
END;
GO


-- ctls_node_dm_element_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'ctls_node_dm_element_assoc')
BEGIN 
Drop TABLE ctls_node_dm_element_assoc;
END;
GO


-- ctls_node_enum_value_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'ctls_node_enum_value_assoc')
BEGIN 
Drop TABLE ctls_node_enum_value_assoc;
END;
GO

-- child_file_template_attribute_association
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_attribute_association')
BEGIN 
Drop TABLE child_file_template_attribute_association;
END;
GO 

-- valid_value_types_834
IF EXISTS (SELECT * FROM sys.tables where name = 'valid_value_types_834')
BEGIN 
Drop TABLE valid_value_types_834;
END;
GO 

-- cftaa_834_valid_value_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'cftaa_834_valid_value_assoc')
BEGIN 
Drop TABLE cftaa_834_valid_value_assoc;
END;
GO 

-- child_file_template_attr_br_assoc_834
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_attr_br_assoc_834')
BEGIN 
Drop TABLE child_file_template_attr_br_assoc_834;
END;
GO 

-- child_file_template_attribute_association_834
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_attribute_association_834')
BEGIN 
Drop TABLE child_file_template_attribute_association_834;
END;
GO 


-- child_file_template_section_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_section_assoc')
BEGIN 
Drop TABLE child_file_template_section_assoc;
END;
GO 


-- child_file_template_version_audit
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_version_audit')
BEGIN 
Drop TABLE child_file_template_version_audit;
END;
GO


-- child_template_layout_schema_node_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'child_template_layout_schema_node_assoc')
BEGIN 
Drop TABLE child_template_layout_schema_node_assoc;
END;
GO


-- child_template_layout_schema_node_info
IF EXISTS (SELECT * FROM sys.tables where name = 'child_template_layout_schema_node_info')
BEGIN 
Drop TABLE child_template_layout_schema_node_info;
END;
GO

-- child_file_template_trading_partner_lob_assoc
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_trading_partner_lob_assoc')
BEGIN 
Drop TABLE child_file_template_trading_partner_lob_assoc;
END;
GO 

-- child_file_template_meta_info
IF EXISTS (SELECT * FROM sys.tables where name = 'child_file_template_meta_info')
BEGIN 
Drop TABLE child_file_template_meta_info;
END;
GO 


--------------------------------------
-- TABLE DROP END

