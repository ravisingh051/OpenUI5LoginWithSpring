use [idis-metainfo]
GO

/*
Update Log

Date        	Author          	Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-20   Divya Jain			ADAPT-7672:Not getting 'job Successful emails'

-- Table 
-- processing_system_events
*/

IF not exists (select 1 from [processing_system_events] where [event_id] = 15 and event_name='JOB_COMPLETED')
BEGIN

update processing_system_events  set event_name='JOB_COMPLETED' where [event_id] =15


END;
GO
