use [idis-metainfo]
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Richa Ashara
-- Create date:  10/19/2018 12:23:24 PM 
-- Description:	This Store Procedure create insert queries for migration  file from QC to QA
-- =============================================
/*
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2018-12-05  Richa Ashara		ADAPT-250-user-should-be-able-to-update-delete-the-cloned-section-at-file-level
2018-12-13  Richa Ashara		ADAPT-642- User should be able to configure connection/key with File
2019-09-03	Divya Jain			ADAPT-3157:Remove unused and redundant tables/columns from metainfo database and their references (if any)
*/

IF OBJECT_ID('dbo.USP_Export_File_Configuration_Queries') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Export_File_Configuration_Queries');
GO

/*
IF OBJECT_ID('dbo.USP_Export_File_Configuration_Queries') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_Export_File_Configuration_Queries AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_Export_File_Configuration_Queries]
	-- Add the parameters for the stored procedure here
	@ifile_id INT,
	@ifile_version INT
	--@insert_queries nvarchar(max) OUTPUT
	
			
AS
BEGIN

    Declare @new_file_id INT
    Declare @new_file_version INT
    Declare @new_file_record_id INT
    Declare @file_child_template_record_id INT
    Declare @file_child_template_id INT
    Declare @file_child_template_version INT
    Declare @file_record_id INT
    Declare @old_file_idis_ba_id INT
    Declare @old_file_trading_partner_platform_id INT
    Declare @old_file_format_supported_id INT
    Declare @insert_queries nvarchar(max)
    Declare @str_column_names nvarchar(max)
    declare @str_column_values nvarchar(max)
    Declare @where_clause nvarchar(max)
    Declare @old_cftsa_id INT
    Declare @old_cftaa_id INT
    Declare @old_rule_id INT
    Declare @old_rule_version INT
    declare @old_child_trading_partner_id INT
    declare @old_child_lob_id INT
   -- declare @old_cft_trading_partner_lob_assoc_id INT
     Declare @old_fsa_id INT
    Declare @old_faa_id INT
    Declare @old_file_rule_id INT
    Declare @old_file_rule_version INT
    declare @old_file_trading_partner_id INT
    declare @old_file_lob_id INT
    declare @old_file_trading_partner_lob_assoc_id INT
    Declare @old_trading_partner_contact_id INT
    declare @old_trading_partner_contact_tpp_assoc_id INT
    Declare @old_template_id INT
    declare @old_ntft_id INT
    declare @old_file_employer_assoc_id INT
    Declare @old_url_id INT
    Declare @old_idis_team_file_association_id INT
    --declare @old_enrichment_api_mapped_obj_file_assoc_id INT
    declare @old_lookup_table_id INT 
    declare @old_lookup_table_version INT
    declare @old_lookup_detail_id INT
    Declare @old_ltckm_id INT
    Declare @current_date_time datetime
    Declare @counter int = 1;
    Declare @clone_num int;


	SET NOCOUNT ON;

	IF OBJECT_ID('tempdb..#tmp_faa_lookup_id_map') IS NOT NULL BEGIN DROP TABLE #tmp_faa_lookup_id_map; END
	 Create Table #tmp_faa_lookup_id_map (faa_id INT Not Null,lookup_id INT Not Null, lookup_version INT not NULL)

	 SELECT @current_date_time = GETDATE()

	SELECT @file_record_id = record_id, @file_child_template_id = child_file_template_id,-- @file_child_template_version = child_file_template_version, @file_child_template_record_id =child_file_template_record_id,
	@old_file_idis_ba_id = file_idis_ba_id, @old_file_trading_partner_platform_id = trading_partner_platform_id, @old_file_format_supported_id = file_format_supported_id FROM [dbo].[file_meta_info] 
	where file_id = @ifile_id and file_version = @ifile_version

	SELECT @file_child_template_version = child_file_template_version, @file_child_template_record_id =child_file_template_record_id from  child_file_template_meta_info where child_file_template_id = @file_child_template_id
	and child_file_template_version in (select max(child_file_template_version) from child_file_template_meta_info where child_file_template_id = @file_child_template_id and is_active = 1 and approval_status_id = 3)
	
	SET @insert_queries =  ' IF OBJECT_ID(''tempdb..#tmp_notification_template_id_map'') IS NOT NULL BEGIN DROP TABLE #tmp_notification_template_id_map; END'
	SET @insert_queries =  @insert_queries + ' Create Table #tmp_notification_template_id_map (old_template_id INT Not Null,new_template_id INT Not Null)'
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;
	
	SET @insert_queries =  ' IF OBJECT_ID(''tempdb..#tmp_rule_id_map'') IS NOT NULL BEGIN DROP TABLE #tmp_rule_id_map; END'
	SET @insert_queries =  @insert_queries +  ' Create Table #tmp_rule_id_map (old_rule_id INT Not Null,new_rule_id INT Not Null)'
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;
	
	SET @insert_queries =  ' IF OBJECT_ID(''tempdb..#tmp_attribute_association'') IS NOT NULL BEGIN DROP TABLE #tmp_attribute_association; END'
	SET @insert_queries =  @insert_queries + ' Create Table #tmp_attribute_association (old_cftaa_id INT Not Null,new_cftaa_id INT Null)'
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;
	
	SET @insert_queries =  ' IF OBJECT_ID(''tempdb..#tmp_faa_id_map'') IS NOT NULL BEGIN DROP TABLE #tmp_faa_id_map; END'
	SET @insert_queries =  @insert_queries + ' Create Table #tmp_faa_id_map (old_faa_id INT Not Null,new_faa_id INT Not Null)'
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;

     SET @insert_queries =  ' IF OBJECT_ID(''tempdb..#tmp_lookup_id_map'') IS NOT NULL BEGIN DROP TABLE #tmp_lookup_id_map; END'
	SET @insert_queries =  @insert_queries + ' Create Table #tmp_lookup_id_map (old_lookup_id INT Not Null,new_lookup_id INT Not Null)'
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;

	
	SET @insert_queries = 'declare @child_record_id int=1 declare @child_file_template_id int = 1; select @child_record_id= ISNULL((max(child_file_template_record_id)+1),1) from [dbo].[child_file_template_meta_info];
	  select @child_file_template_id= ISNULL((max(child_file_template_id)+1),1) from [dbo].[child_file_template_meta_info] '
    print @insert_queries;
    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
    SET @counter = @counter + 1;
    
	SET @insert_queries = '  declare @cftsa_id int = 1; declare @cftaa_id int = 1; declare @rule_id int = 1; declare @cft_attr_br_assoc_id int=1; declare @child_trading_partner_id int = 1, @lob_id int = 1;'
     print @insert_queries;
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
     SET @counter = @counter + 1;

	SELECT @old_child_trading_partner_id = trading_partner_id, @old_child_lob_id = lob_id  FROM [dbo].[child_file_template_meta_info] where child_file_template_id = @file_child_template_id and child_file_template_version = @file_child_template_version and child_file_template_record_id = @file_child_template_record_id
	if(@old_child_trading_partner_id is NOT NULL AND @old_child_trading_partner_id > 0)
	BEGIN
    SET @where_clause = ' where trading_partner_id = ' + CAST( @old_child_trading_partner_id AS VARCHAR) 
    SET @str_column_names = NULL;
    SET @str_column_values = NULL;
     EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'trading_partner_info',@where_clause = @where_clause,@file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
     if(@str_column_values is NOT null AND @str_column_values <> '')
	BEGIN
    	   SET @insert_queries = 'select @child_trading_partner_id =  ISNULL((max(trading_partner_id)+1),1) from [dbo].[trading_partner_info];'
	   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_info] ON; '
	   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[trading_partner_info](trading_partner_id,'  + @str_column_names + ' ) values (@child_trading_partner_id, ' + @str_column_values + '); '
	   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_info] OFF; '
	   print @insert_queries
	  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
       SET @counter = @counter + 1;
	END
      
	   SET @where_clause = ' where lob_id = ' + CAST( @old_child_lob_id AS VARCHAR) 
	   SET @str_column_names = NULL;
	   SET @str_column_values = NULL;
	   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lob',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
	    if(@str_column_values is NOT null AND @str_column_values <> '')
	    BEGIN
		  SET @insert_queries = 'select @lob_id =  ISNULL((max(lob_id)+1),1) from [dbo].[lob];'
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lob] ON; '
		  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lob](lob_id,'  + @str_column_names + ' ) values (@lob_id, ' + @str_column_values + '); '
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lob] OFF; '
		  print @insert_queries
		  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		  SET @counter = @counter + 1;
	    END
    END
	 SET @where_clause = ' where child_file_template_id = ' + CAST( @file_child_template_id AS VARCHAR) + ' and child_file_template_version = ' + CAST( @file_child_template_version AS VARCHAR) + ' and child_file_template_record_id = ' +  CAST (@file_child_template_record_id AS VARCHAR)
      SET @str_column_names = NULL;
      SET @str_column_values = NULL;
      EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'child_file_template_meta_info',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
      if(@str_column_values is NOT null AND @str_column_values <> '')
	 BEGIN
	   SET @insert_queries =   ' SET IDENTITY_INSERT [dbo].[child_file_template_meta_info] ON;'
	   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[child_file_template_meta_info]( child_file_template_record_id, child_file_template_id, child_file_template_version,trading_partner_id,lob_id,' +
		   @str_column_names + ' ) values (  @child_record_id,@child_file_template_id,1,@child_trading_partner_id,@lob_id,' + @str_column_values + '); '

	    SET @insert_queries = @insert_queries + ' SET IDENTITY_INSERT [dbo].[child_file_template_meta_info] OFF;'
	   print @insert_queries
	   insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	   SET @counter = @counter + 1;
     END


     DECLARE child_file_template_section_assoc_cur CURSOR  LOCAL FOR SELECT  cftsa_id FROM [dbo].[child_file_template_section_assoc]  where child_file_template_record_id = @file_child_template_record_id
	 OPEN child_file_template_section_assoc_cur
	     FETCH NEXT FROM child_file_template_section_assoc_cur INTO @old_cftsa_id ;
	 	WHILE @@FETCH_STATUS = 0
	    BEGIN
	     
		    SET @where_clause = ' where cftsa_id= ' +  CAST( @old_cftsa_id AS VARCHAR) 
		    SET @str_column_names = NULL;
		    SET @str_column_values = NULL;
		    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'child_file_template_section_assoc',@where_clause = @where_clause,@file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
		   if(@str_column_values is NOT null AND @str_column_values <> '')
		   BEGIN
		    SET @insert_queries =  ' select @cftsa_id =  ISNULL((max(cftsa_id)+1),1) from [dbo].[child_file_template_section_assoc]; '
		    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] ON; '
		    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[child_file_template_section_assoc]( cftsa_id,child_file_template_record_id, child_file_template_id, child_file_template_version,' +
			    @str_column_names + ' ) values (  @cftsa_id, @child_record_id,@child_file_template_id,1,' + @str_column_values + '); '
	   
			  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_section_assoc] OFF;'
			  print @insert_queries;
			  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			  SET @counter = @counter + 1;
		   END
			
			
			  DECLARE child_file_template_attribute_association_cur CURSOR  LOCAL FOR SELECT  cftaa_id FROM [dbo].[child_file_template_attribute_association]  where cftsa_id = @old_cftsa_id
			  open child_file_template_attribute_association_cur
				 FETCH NEXT FROM child_file_template_attribute_association_cur INTO @old_cftaa_id ;
				 WHILE @@FETCH_STATUS = 0
				 BEGIN
		  
				   SET @where_clause = ' where cftaa_id= ' +  CAST( @old_cftaa_id AS VARCHAR) 
				   SET @str_column_names = NULL;
				   SET @str_column_values = NULL;
				    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'child_file_template_attribute_association',@where_clause = @where_clause,@file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
				     if(@str_column_values is NOT null AND @str_column_values <> '')
					BEGIN
					    SET @insert_queries =   ' select @cftaa_id =  ISNULL((max(cftaa_id)+1),1) from [dbo].[child_file_template_attribute_association]; '
					    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_attribute_association] ON; '
					  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[child_file_template_attribute_association](cftaa_id, cftsa_id,child_file_template_record_id, child_file_template_id,
					   child_file_template_version,' + @str_column_names + ' ) values (  @cftaa_id ,@cftsa_id, @child_record_id,@child_file_template_id,1,' + @str_column_values + '); '
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_attribute_association] OFF; '
					   print @insert_queries
					   insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
					   SET @counter = @counter + 1;

					SET @insert_queries = ' insert into #tmp_attribute_association(old_cftaa_id, new_cftaa_id) values(' +  CAST( @old_cftaa_id AS VARCHAR) +', @cftaa_id)'
				    print @insert_queries
				    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				    SET @counter = @counter + 1;

				    END
				   

				    -- For rule insertion
				    --if exists( SELECT business_rule_id from child_file_template_attr_br_assoc where cftaa_id = @old_cftaa_id)
				    --BEGIN
				    DECLARE child_file_template_rule_cur CURSOR LOCAL FOR SELECT business_rule_id, business_rule_version from child_file_template_attr_br_assoc where cftaa_id = @old_cftaa_id
				    OPEN child_file_template_rule_cur
				    FETCH NEXT FROM  child_file_template_rule_cur INTO @old_rule_id, @old_rule_version
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
					   
					   SET @where_clause = ' where drools_business_rule_id = ' + CAST( @old_rule_id AS VARCHAR) + ' and  drools_business_rule_version = ' +  CAST( @old_rule_version AS VARCHAR) 
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   print ' rule id ::: ' + CAST( @old_rule_id AS VARCHAR) + ' and  drools_business_rule_version = ' +  CAST( @old_rule_version AS VARCHAR) 
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'drools_business_rules_decision_table',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @rule_id =  ISNULL((max(drools_business_rule_id)+1),1) from [dbo].[drools_business_rules_decision_table];'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON; '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
						  print ' col names rules ::: ' + @str_column_names
						  SET @insert_queries =  'INSERT INTO [dbo].[drools_business_rules_decision_table](drools_business_rule_id, drools_business_rule_version, ' + @str_column_names + ' ) '
						  
						   print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
						  SET @insert_queries =' values (  @rule_id ,1,' + @str_column_values + ') ;'
						  print @insert_queries
						  --SELECT @json_text = drools_business_rule_ui_json_text from dbo].[drools_business_rules_decision_table] where drools_business_rule_id = @
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						   SET @counter = @counter + 1;
						   SET @insert_queries = ' select @json_text  = drools_business_rule_ui_json_text from '
						  SET @insert_queries =   ' SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF; '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
					   END

					
					   SET @where_clause = ' where business_rule_id = ' + CAST( @old_rule_id AS VARCHAR) + ' and  business_rule_version = ' +  CAST( @old_rule_version AS VARCHAR)  + ' and cftaa_id = ' +  CAST( @old_cftaa_id AS VARCHAR)
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'child_file_template_attr_br_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
					    SET @insert_queries = 'select @cft_attr_br_assoc_id =  ISNULL((max(cft_attr_br_assoc_id)+1),1) from [dbo].[child_file_template_attr_br_assoc];'
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_attr_br_assoc] ON; '
					   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[child_file_template_attr_br_assoc](cft_attr_br_assoc_id,business_rule_id, business_rule_version, cftaa_id,' + @str_column_names + ' ) values (@cft_attr_br_assoc_id,  @rule_id ,1,@cftaa_id,' + @str_column_values + '); '
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[child_file_template_attr_br_assoc] OFF; '
					   print @insert_queries
					   insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
					   SET @counter = @counter + 1;
					    END
					    FETCH NEXT FROM  child_file_template_rule_cur INTO @old_rule_id, @old_rule_version
					END
				   
				    CLOSE child_file_template_rule_cur
				    DEALLOCATE child_file_template_rule_cur
				-- END   
				FETCH NEXT FROM child_file_template_attribute_association_cur INTO @old_cftaa_id ;
				END
			  CLOSE child_file_template_attribute_association_cur
			  DEALLOCATE child_file_template_attribute_association_cur

		    FETCH NEXT FROM child_file_template_section_assoc_cur INTO @old_cftsa_id ;
	    END
	 CLOSE child_file_template_section_assoc_cur
	 DEALLOCATE child_file_template_section_assoc_cur
    ------------------- File templated related 
    SET @insert_queries = 'declare @record_id int=1 declare @file_id int = 1; select @record_id= ISNULL((max(record_id)+1),1) from [dbo].[file_meta_info];
	  select @file_id= ISNULL((max(file_id)+1),1) from [dbo].[file_id_generator] ;'

    
	print @insert_queries;
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	SET @counter = @counter + 1;

	 SET @insert_queries = '  declare @fsa_id int = 1; declare @faa_id int = 1; declare @file_rule_id int = 1; declare @file_attr_br_assoc_id int=1; declare @trading_partner_id int = 1;
						 declare @file_trading_partner_lob_assoc_id int = 1; declare  @trading_partner_platform_id int = 1; declare  @trading_partner_contact_id int = 1; declare @trading_partner_contact_tpp_assoc_id int = 1; 
						 declare @template_id int = 1; declare @file_notification_template_contact_assoc_id int = 1; declare @ntft_id int = 1; declare @file_employer_assoc_id int = 1; declare @file_format_supported_id int = 1;
						 declare @url_id int = 1; declare @idis_team_file_association_id int = 1; declare @lookup_record_id int = 1; declare @lookup_table_id INT = 1; 
						 declare @lookup_detail_id int = 1; declare @ltckm_id int = 1; declare @new_cftaa_id int = 1; declare @new_rule_id int = 1; declare  @idis_team_member_id int = 1; declare @file_clone_id int = 1;'

	 print @insert_queries;
	 insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
	 SET @counter = @counter + 1;


   -- 		    DECLARE file_notification_template_info_cur CURSOR  LOCAL FOR SELECT distinct template_id FROM [dbo].[file_notification_template_contact_assoc]  where file_identifier = @file_record_id --and trading_partner_contact_id = @old_trading_partner_contact_id
			--OPEN file_notification_template_info_cur 
			--  FETCH NEXT FROM file_notification_template_info_cur INTO @old_template_id ;
	 	--	  WHILE @@FETCH_STATUS = 0
			--  BEGIN
			----  print '--inside file_notification_template_info_cur loop'
			-- SET @where_clause = ' where template_id = ' + CAST( @old_template_id AS VARCHAR) 
			--	SET @str_column_names = NULL;
			--	SET @str_column_values = NULL;
			--	EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'notification_template_info',@where_clause = @where_clause,@file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			--  if(@str_column_values is NOT null AND @str_column_values <> '')
			--  BEGIN
			----   print '--inside file_notification_template_info_cur loop if ' 
			--	SET @insert_queries = 'select @template_id =  ISNULL((max(template_id)+1),1) from [dbo].[notification_template_info];'
			--	SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[notification_template_info] ON; '
			--	SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[notification_template_info](template_id,'  + @str_column_names + ' ) values (@template_id, ' + @str_column_values + '); '
			--	SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[notification_template_info] OFF; '
			--	print @insert_queries
			--	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			--	SET @counter = @counter + 1;
			--	SET @insert_queries = ' insert into #tmp_notification_template_id_map(old_template_id, new_template_id) values(' +  CAST( @old_template_id AS VARCHAR) +', @template_id)'
			--	print @insert_queries
			--	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			--	SET @counter = @counter + 1;
			--  END
			  
			--  SELECT @old_ntft_id = ntft_id FROM [dbo].[notification_template_file_type_assoc] where notification_template_id = @old_template_id
			--   SET @where_clause = ' where ntft_id = ' + CAST( @old_ntft_id AS VARCHAR) 
			--	SET @str_column_names = NULL;
			--	SET @str_column_values = NULL;
			--	EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'notification_template_file_type_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			--  if(@str_column_values is NOT null AND @str_column_values <> '')
			--  BEGIN
			--	SET @insert_queries = 'select @ntft_id =  ISNULL((max(ntft_id)+1),1) from [dbo].[notification_template_file_type_assoc];'
			--	SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[notification_template_file_type_assoc] ON; '
			--	SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[notification_template_file_type_assoc](ntft_id,notification_template_id,'  + @str_column_names + ' ) values (@ntft_id,@template_id,' + @str_column_values + '); '
			--	SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[notification_template_file_type_assoc] OFF; '
			--	print @insert_queries
			--	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			--	SET @counter = @counter + 1;
			--  END

			--   FETCH NEXT FROM file_notification_template_info_cur INTO @old_template_id ;
			-- END
			-- CLOSE file_notification_template_info_cur
			-- DEALLOCATE file_notification_template_info_cur

	    SELECT  @old_file_trading_partner_id = trading_partner_id FROM  [dbo].[trading_partner_platform_info]  where trading_partner_platform_id = @old_file_trading_partner_platform_id

  
	if(@old_file_trading_partner_id is NOT NULL AND @old_file_trading_partner_id > 0)
	BEGIN
    SET @where_clause = ' where trading_partner_platform_id = ' + CAST( @old_file_trading_partner_platform_id AS VARCHAR) 
    SET @str_column_names = NULL;
    SET @str_column_values = NULL;
    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'trading_partner_platform_info',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
     if(@str_column_values is NOT null AND @str_column_values <> '')
	    BEGIN
    		  SET @insert_queries = 'select @trading_partner_platform_id =  ISNULL((max(trading_partner_platform_id)+1),1) from [dbo].[trading_partner_platform_info];'
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_platform_info] ON; '
		  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[trading_partner_platform_info](trading_partner_platform_id,trading_partner_id,'  + @str_column_names + ' ) values (@trading_partner_platform_id,@trading_partner_id, ' + @str_column_values + '); '
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_platform_info] OFF; '
		  print @insert_queries
		  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		  SET @counter = @counter + 1;
		--   print ' -- inside if [trading_partner_platform_info]'
	    END	
		
		 DECLARE file_trading_partner_contact_cur CURSOR  LOCAL FOR SELECT  trading_partner_contact_id, trading_partner_contact_tpp_assoc_id FROM [dbo].[trading_partner_contact_tpp_assoc] where trading_partner_platform_id = @old_file_trading_partner_platform_id
	      OPEN file_trading_partner_contact_cur 
	      FETCH NEXT FROM file_trading_partner_contact_cur INTO @old_trading_partner_contact_id ,  @old_trading_partner_contact_tpp_assoc_id;
	 	WHILE @@FETCH_STATUS = 0
			  BEGIN
			--  PRINT ' -- inside file_trading_partner_contact_cur loop '
			  SET @where_clause = ' where trading_partner_contact_id = ' + CAST( @old_trading_partner_contact_id AS VARCHAR) 
			 SET @str_column_names = NULL;
			 SET @str_column_values = NULL;
			 EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'trading_partner_contact_info',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			 if(@str_column_values is NOT null AND @str_column_values <> '')
			  BEGIN
			   -- PRINT ' -- inside file_trading_partner_contact_cur loop  if condition'
    				SET @insert_queries = 'select @trading_partner_contact_id =  ISNULL((max(trading_partner_contact_id)+1),1) from [dbo].[trading_partner_contact_info];'
				SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_contact_info] ON; '
				SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[trading_partner_contact_info](trading_partner_contact_id,'  + @str_column_names + ' ) values (@trading_partner_contact_id,' + @str_column_values + '); '
				SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_contact_info] OFF; '
				 print @insert_queries
				 insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				 SET @counter = @counter + 1;
			  END
			  
			 SET @where_clause = ' where trading_partner_contact_tpp_assoc_id = ' + CAST( @old_trading_partner_contact_tpp_assoc_id AS VARCHAR) 
			 SET @str_column_names = NULL;
			 SET @str_column_values = NULL;
			 EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'trading_partner_contact_tpp_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			 if(@str_column_values is NOT null AND @str_column_values <> '')
				BEGIN
    				SET @insert_queries = 'select @trading_partner_contact_tpp_assoc_id =  ISNULL((max(trading_partner_contact_tpp_assoc_id)+1),1) from [dbo].[trading_partner_contact_tpp_assoc];'
				SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_contact_tpp_assoc] ON; '
				SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[trading_partner_contact_tpp_assoc](trading_partner_contact_tpp_assoc_id,trading_partner_contact_id,trading_partner_platform_id,'  + @str_column_names + ' ) values (@trading_partner_contact_tpp_assoc_id,@trading_partner_contact_id,@trading_partner_platform_id,' + @str_column_values + '); '
				SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_contact_tpp_assoc] OFF; '
				print @insert_queries
				insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				SET @counter = @counter + 1;
		     END


			 -- DECLARE file_notification_template_cur CURSOR  LOCAL FOR SELECT  template_id FROM [dbo].[file_notification_template_contact_assoc]  where file_identifier = @file_record_id and trading_partner_contact_id = @old_trading_partner_contact_id
			 -- OPEN file_notification_template_cur 
			 -- FETCH NEXT FROM file_notification_template_cur INTO @old_template_id ;
	 		--  WHILE @@FETCH_STATUS = 0
			 -- BEGIN
				--SET @where_clause = ' where template_id = ' + CAST( @old_template_id AS VARCHAR) +' and trading_partner_contact_id = ' + CAST( @old_trading_partner_contact_id AS VARCHAR)
				--SET @str_column_names = NULL;
				--SET @str_column_values = NULL;
				--EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_notification_template_contact_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			 -- if(@str_column_values is NOT null AND @str_column_values <> '')
			 -- BEGIN
			 --    SET @insert_queries = ' SELECT @template_id =  new_template_id FROM #tmp_notification_template_id_map where old_template_id = '+ CAST( @old_template_id AS VARCHAR)
				--SET @insert_queries = @insert_queries +'select @file_notification_template_contact_assoc_id =  ISNULL((max(file_notification_template_contact_assoc_id)+1),1) from [dbo].[file_notification_template_contact_assoc];'
				--SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_notification_template_contact_assoc] ON; '
				--SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_notification_template_contact_assoc](file_notification_template_contact_assoc_id,template_id,trading_partner_contact_id,'  + @str_column_names + ' ) values (@file_notification_template_contact_assoc_id,@template_id,@trading_partner_contact_id, ' + @str_column_values + '); '
				--SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_notification_template_contact_assoc] OFF; '
				--print @insert_queries
				--insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				--SET @counter = @counter + 1;
			 -- END

			 --FETCH NEXT FROM file_notification_template_cur INTO @old_template_id ;
			 --END
			 --CLOSE file_notification_template_cur
			 --DEALLOCATE file_notification_template_cur
		
		  FETCH NEXT FROM file_trading_partner_contact_cur INTO @old_trading_partner_contact_id ,  @old_trading_partner_contact_tpp_assoc_id;
		  END
		  CLOSE file_trading_partner_contact_cur
		  DEALLOCATE file_trading_partner_contact_cur
    END
	    

		 SELECT @old_file_lob_id = lob_id, @old_file_trading_partner_lob_assoc_id = file_trading_partner_lob_assoc_id,   @old_file_trading_partner_id = trading_partner_id  FROM [dbo].[file_trading_partner_lob_assoc]  where file_identifier = @file_record_id --  where trading_partner_id = @old_file_trading_partner_id

	   --IF(@old_child_lob_id <> @old_file_lob_id and @old_file_lob_id is not null and @old_file_lob_id > 0)
	   --BEGIN
		  --SET @where_clause = ' where lob_id = ' + CAST( @old_file_lob_id AS VARCHAR) 
		  --SET @str_column_names = NULL;
		  --SET @str_column_values = NULL;
		  --EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lob',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
		  -- if(@str_column_values is NOT null AND @str_column_values <> '')
		  -- BEGIN
			 --SET @insert_queries = 'select @lob_id =  ISNULL((max(lob_id)+1),1) from [dbo].[lob];'
			 --SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lob] ON; '
			 --SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lob](lob_id,'  + @str_column_names + ' ) values (@lob_id, ' + @str_column_values + '); '
			 --SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lob] OFF; '
			 --print @insert_queries
			 --insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			 --SET @counter = @counter + 1;
		  -- END
	   --END

	   --if(@old_file_trading_partner_id is not null and @old_file_trading_partner_id > 0 )
	   --BEGIN
	   --SET @where_clause = ' where trading_partner_id = ' + CAST( @old_file_trading_partner_id AS VARCHAR) 
	   --SET @str_column_names = NULL;
	   --SET @str_column_values = NULL;
	   --EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'trading_partner_info',@where_clause = @where_clause,@file_id = @ifile_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
	   -- if(@str_column_values is NOT null AND @str_column_values <> '')
		  -- BEGIN
    --			 SET @insert_queries = 'select @trading_partner_id =  ISNULL((max(trading_partner_id)+1),1) from [dbo].[trading_partner_info];'
			 --SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_info] ON; '
			 --SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[trading_partner_info](trading_partner_id,'  + @str_column_names + ' ) values (@trading_partner_id, ' + @str_column_values + '); '
			 --SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[trading_partner_info] OFF; '
			 --print @insert_queries
			 --insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			 --SET @counter = @counter + 1;
	   -- END
	--  END
  
	  --if(@old_file_idis_ba_id is not null and @old_file_idis_ba_id > 0 )
	  -- BEGIN
	  -- SET @where_clause = ' where idis_team_member_id = ' + CAST( @old_file_idis_ba_id AS VARCHAR) 
	  -- SET @str_column_names = NULL;
	  -- SET @str_column_values = NULL;
	  -- EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'idis_team_member',@where_clause = @where_clause,@file_id = @ifile_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
	  --  if(@str_column_values is NOT null AND @str_column_values <> '')
		 --  BEGIN
   -- 			 SET @insert_queries = 'select @idis_team_member_id =  ISNULL((max(idis_team_member_id)+1),1) from [dbo].[idis_team_member];'
			-- SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[idis_team_member] ON; '
			-- SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[idis_team_member](idis_team_member_id,'  + @str_column_names + ' ) values (@idis_team_member_id, ' + @str_column_values + '); '
			-- SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[idis_team_member] OFF; '
			-- print @insert_queries
			-- insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			-- SET @counter = @counter + 1;
	  --  END
	  --END
  
     
		  SET @where_clause = ' where file_format_supported_id = ' + CAST( @old_file_format_supported_id AS VARCHAR) 
		  SET @str_column_names = NULL;
		  SET @str_column_values = NULL;
		  EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_format_supported',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
		  if(@str_column_values is NOT null AND @str_column_values <> '')
		  BEGIN
			 SET @insert_queries = 'select @file_format_supported_id =  ISNULL((max(file_format_supported_id)+1),1) from [dbo].[file_format_supported];'
			 SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_format_supported] ON; '
			 SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_format_supported](file_format_supported_id,'  +
				    @str_column_names + ' ) values (@file_format_supported_id,' + @str_column_values + '); '
			 SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_format_supported] OFF; '
			 print @insert_queries
			 insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			 SET @counter = @counter + 1;
		  END



	   
	    SET @where_clause = ' where file_id = ' + CAST( @ifile_id AS VARCHAR)
	   SET @str_column_names = NULL;
	   SET @str_column_values = NULL;
	   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_id_generator',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
   
	   if(@str_column_values is NOT null AND @str_column_values <> '')
	    BEGIN
		  SET @insert_queries =   ' SET IDENTITY_INSERT [dbo].[file_id_generator] ON;'
		  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_id_generator]( file_id,' + @str_column_names + ' ) values (@file_id,' + @str_column_values + '); '
		  SET @insert_queries = @insert_queries + ' SET IDENTITY_INSERT [dbo].[file_id_generator] OFF;'
		  print @insert_queries
		  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		  SET @counter = @counter + 1;
	   END

    SET @where_clause = ' where file_id = ' + CAST( @ifile_id AS VARCHAR) + ' and file_version = ' + CAST( @ifile_version AS VARCHAR) + ' and record_id = ' +  CAST (@file_record_id AS VARCHAR)
    SET @str_column_names = NULL;
    SET @str_column_values = NULL;
    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_meta_info',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
   
    if(@str_column_values is NOT null AND @str_column_values <> '')
	BEGIN
	   if(@old_file_trading_partner_id is null or @old_file_trading_partner_id <= 0)
	   BEGIN
		  SET @insert_queries = 'SET  @trading_partner_platform_id = NULL;' ;
	   END
	   ELSE
	   BEGIN
		  SET @insert_queries = '';
	   END
	   if(@old_file_format_supported_id is null or @old_file_format_supported_id <= 0)
	   BEGIN
		  SET @insert_queries = 'SET  @idis_team_member_id = NULL;' ;
	   END
	   ELSE
	   BEGIN
		  SET @insert_queries = '';
	   END
	   -- if(@old_file_idis_ba_id is null or @old_file_idis_ba_id <= 0)
	   --BEGIN
		  --SET @insert_queries = 'SET  @idis_team_member_id = NULL;' ;
	   --END
	   --ELSE
	   --BEGIN
		  --SET @insert_queries = '';
	   --END
	   SET @insert_queries =   @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_meta_info] ON;'
	   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_meta_info](record_id, file_id,file_version,child_file_template_record_id, child_file_template_id, child_file_template_version,trading_partner_platform_id,file_format_supported_id,' +
		   @str_column_names + ' ) values (@record_id,@file_id,1,  @child_record_id,@child_file_template_id,1,@trading_partner_platform_id, @file_format_supported_id,' + @str_column_values + '); '

	    SET @insert_queries = @insert_queries + ' SET IDENTITY_INSERT [dbo].[file_meta_info] OFF;'
		print @insert_queries
		insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		SET @counter = @counter + 1;
    END

	    DECLARE file_clone_info_cur CURSOR  LOCAL FOR SELECT  clone_num FROM [dbo].[file_clone_info]  where file_identifier = @file_record_id 
			 OPEN file_clone_info_cur
			 FETCH NEXT FROM file_clone_info_cur INTO @clone_num ;
	 		 WHILE @@FETCH_STATUS = 0
			 BEGIN
    				 SET @where_clause = ' where file_identifier = ' +   CAST (@file_record_id AS VARCHAR) + ' and clone_num = ' +  CAST (@clone_num AS VARCHAR)
				SET @str_column_names = NULL;
				SET @str_column_values = NULL;
				EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_clone_info',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
   
				if(@str_column_values is NOT null AND @str_column_values <> '')
				 BEGIN
				    SET @insert_queries = 'select @file_clone_id =  ISNULL((max(file_clone_id)+1),1) from [dbo].[file_clone_info];'
				    SET @insert_queries =  @insert_queries  +  ' SET IDENTITY_INSERT [dbo].[file_clone_info] ON;'
				    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_clone_info]( file_clone_id,file_identifier,' + @str_column_names + ' ) values (@file_clone_id,@record_id,' + @str_column_values + '); '
				    SET @insert_queries = @insert_queries + ' SET IDENTITY_INSERT [dbo].[file_clone_info] OFF;'
				    print @insert_queries
				    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				    SET @counter = @counter + 1;
				END
			  FETCH NEXT FROM file_clone_info_cur INTO @clone_num;
		  END
		  CLOSE file_clone_info_cur
		  DEALLOCATE file_clone_info_cur

    	   SET @where_clause = ' where file_trading_partner_lob_assoc_id = ' + CAST( @old_file_trading_partner_lob_assoc_id AS VARCHAR) 
	   SET @str_column_names = NULL;
	   SET @str_column_values = NULL;
	   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_trading_partner_lob_assoc',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
	    if(@str_column_values is NOT null AND @str_column_values <> '')
	    BEGIN
		  SET @insert_queries = 'select @file_trading_partner_lob_assoc_id =  ISNULL((max(file_trading_partner_lob_assoc_id)+1),1) from [dbo].[file_trading_partner_lob_assoc];'
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_trading_partner_lob_assoc] ON; '
		  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_trading_partner_lob_assoc](file_trading_partner_lob_assoc_id,file_identifier,trading_partner_id,lob_id,'  +
			  @str_column_names + ' ) values (@file_trading_partner_lob_assoc_id,@record_id,@child_trading_partner_id,@lob_id,' + @str_column_values + '); '
		  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_trading_partner_lob_assoc] OFF; '
		  print @insert_queries
		  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		  SET @counter = @counter + 1;
    END    
	   DECLARE file_linked_urls_assoc_cur CURSOR  LOCAL FOR SELECT  url_id FROM [dbo].[file_linked_urls_assoc]  where file_identifier = @file_record_id 
			 OPEN file_linked_urls_assoc_cur
			 FETCH NEXT FROM file_linked_urls_assoc_cur INTO @old_url_id ;
	 		 WHILE @@FETCH_STATUS = 0
			 BEGIN
				SET @where_clause = ' where url_id = ' + CAST( @old_url_id AS VARCHAR) 
				SET @str_column_names = NULL;
				SET @str_column_values = NULL;
				EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_linked_urls_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
				if(@str_column_values is NOT null AND @str_column_values <> '')
				BEGIN
				    SET @insert_queries = 'select @url_id =  ISNULL((max(url_id)+1),1) from [dbo].[file_linked_urls_assoc];'
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_linked_urls_assoc] ON; '
				    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_linked_urls_assoc](url_id,file_identifier,'  +
						  @str_column_names + ' ) values (@url_id,@record_id,' + @str_column_values + '); '
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_linked_urls_assoc] OFF; '
				    print @insert_queries
				    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				    SET @counter = @counter + 1;
				END
				FETCH NEXT FROM file_linked_urls_assoc_cur INTO @old_file_employer_assoc_id;
		  END
		  CLOSE file_linked_urls_assoc_cur
		  DEALLOCATE file_linked_urls_assoc_cur


	   	   DECLARE file_idis_team_file_association_cur CURSOR  LOCAL FOR SELECT  idis_team_file_association_id FROM [dbo].[idis_team_file_association]  where file_identifier = @file_record_id 
			 OPEN file_idis_team_file_association_cur 
			 FETCH NEXT FROM file_idis_team_file_association_cur INTO @old_idis_team_file_association_id ;
	 		 WHILE @@FETCH_STATUS = 0
			 BEGIN
				SET @where_clause = ' where idis_team_file_association_id = ' + CAST( @old_idis_team_file_association_id AS VARCHAR) 
				SET @str_column_names = NULL;
				SET @str_column_values = NULL;
				EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'idis_team_file_association',@where_clause = @where_clause,@file_id = @ifile_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
				if(@str_column_values is NOT null AND @str_column_values <> '')
				BEGIN
				    SET @insert_queries = 'select @idis_team_file_association_id =  ISNULL((max(idis_team_file_association_id)+1),1) from [dbo].[idis_team_file_association];'
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[idis_team_file_association] ON; '
				    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[idis_team_file_association](idis_team_file_association_id,file_identifier,'  +
						  @str_column_names + ' ) values (@idis_team_file_association_id,@record_id,' + @str_column_values + '); '
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[idis_team_file_association] OFF; '
				    print @insert_queries
				    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				    SET @counter = @counter + 1;
				END
				FETCH NEXT FROM file_idis_team_file_association_cur INTO @old_file_employer_assoc_id;
		  END
		  CLOSE file_idis_team_file_association_cur
		  DEALLOCATE file_idis_team_file_association_cur

		  --DECLARE enrichment_api_mapped_obj_file_assoc_cur CURSOR  LOCAL FOR SELECT  enrichment_api_mapped_obj_file_assoc_id FROM [dbo].[enrichment_api_mapped_obj_file_assoc]  where file_identifier = @file_record_id 
		  --OPEN enrichment_api_mapped_obj_file_assoc_cur
		  --FETCH NEXT FROM enrichment_api_mapped_obj_file_assoc_cur INTO @old_enrichment_api_mapped_obj_file_assoc_id ;
	 	 -- WHILE @@FETCH_STATUS = 0
		  --BEGIN
			 --SET @where_clause = ' where enrichment_api_mapped_obj_file_assoc_id = ' + CAST( @old_enrichment_api_mapped_obj_file_assoc_id AS VARCHAR) 
			 --SET @str_column_names = NULL;
			 --SET @str_column_values = NULL;
			 --EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'enrichment_api_mapped_obj_file_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
			 --if(@str_column_values is NOT null AND @str_column_values <> '')
			 --BEGIN
				--SET @insert_queries = 'select @enrichment_api_mapped_obj_file_assoc_id =  ISNULL((max(enrichment_api_mapped_obj_file_assoc_id)+1),1) from [dbo].[enrichment_api_mapped_obj_file_assoc];'
				--SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[enrichment_api_mapped_obj_file_assoc] ON; '
				--SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[enrichment_api_mapped_obj_file_assoc](enrichment_api_mapped_obj_file_assoc_id,file_identifier,'  +
				--	   @str_column_names + ' ) values (@enrichment_api_mapped_obj_file_assoc_id,@record_id,' + @str_column_values + '); '
				--SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[enrichment_api_mapped_obj_file_assoc] OFF; '
				--print @insert_queries
				--insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
			 --    SET @counter = @counter + 1;
			 --END
			 --FETCH NEXT FROM enrichment_api_mapped_obj_file_assoc_cur INTO @old_file_employer_assoc_id;
	   --END
	   --CLOSE enrichment_api_mapped_obj_file_assoc_cur
	   --DEALLOCATE enrichment_api_mapped_obj_file_assoc_cur

	    DECLARE file_employer_assoc_cur CURSOR  LOCAL FOR SELECT  file_employer_assoc_id FROM [dbo].[file_employer_assoc]  where file_identifier = @file_record_id 
			 OPEN file_employer_assoc_cur 
			 FETCH NEXT FROM file_employer_assoc_cur INTO @old_file_employer_assoc_id ;
	 		 WHILE @@FETCH_STATUS = 0
			 BEGIN
				SET @where_clause = ' where file_employer_assoc_id = ' + CAST( @old_file_employer_assoc_id AS VARCHAR) 
				SET @str_column_names = NULL;
				SET @str_column_values = NULL;
				EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_employer_assoc',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
				if(@str_column_values is NOT null AND @str_column_values <> '')
				BEGIN
				    SET @insert_queries = 'select @file_employer_assoc_id =  ISNULL((max(file_employer_assoc_id)+1),1) from [dbo].[file_employer_assoc];'
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_employer_assoc] ON; '
				    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_employer_assoc](file_employer_assoc_id,file_identifier,'  +
						  @str_column_names + ' ) values (@file_employer_assoc_id,@record_id,' + @str_column_values + '); '
				    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_employer_assoc] OFF; '
				    print @insert_queries
				    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				    SET @counter = @counter + 1;
				END
				FETCH NEXT FROM file_employer_assoc_cur INTO @old_file_employer_assoc_id;
		  END
		  CLOSE file_employer_assoc_cur
		  DEALLOCATE file_employer_assoc_cur

    	  DECLARE file_template_section_assoc_cur CURSOR  LOCAL FOR SELECT  fsa_id FROM [dbo].[file_section_association]  where file_identifier = @file_record_id
	  OPEN file_template_section_assoc_cur
	     FETCH NEXT FROM file_template_section_assoc_cur INTO @old_fsa_id ;
	 	WHILE @@FETCH_STATUS = 0
	    BEGIN
	     
		    SET @where_clause = ' where fsa_id= ' +  CAST( @old_fsa_id AS VARCHAR) 
		    SET @str_column_names = NULL;
		    SET @str_column_values = NULL;
		    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_section_association',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
		   if(@str_column_values is NOT null AND @str_column_values <> '')
		   BEGIN
		    SET @insert_queries =  ' select @fsa_id =  ISNULL((max(fsa_id)+1),1) from [dbo].[file_section_association]; '
		    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_section_association] ON; '
		    SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_section_association]( fsa_id,file_identifier,' +  @str_column_names + ' ) values (  @fsa_id, @record_id,' + @str_column_values + '); '
	         SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_section_association] OFF;'
		    print @insert_queries;
		    insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
		    SET @counter = @counter + 1;
		   END
			
			
			  DECLARE file_template_attribute_association_cur CURSOR  LOCAL FOR SELECT  faa_id, cftaa_id FROM [dbo].[file_attribute_association]  where fsa_id = @old_fsa_id
			  open file_template_attribute_association_cur
				 FETCH NEXT FROM file_template_attribute_association_cur INTO @old_faa_id, @old_cftaa_id;
				 WHILE @@FETCH_STATUS = 0
				 BEGIN
				  
				   SET @where_clause = ' where faa_id = ' +  CAST( @old_faa_id AS VARCHAR) 
				   SET @str_column_names = NULL;
				   SET @str_column_values = NULL;
				    EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_attribute_association',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
				     if(@str_column_values is NOT null AND @str_column_values <> '')
					BEGIN
					    SET @insert_queries =   ' select @faa_id =  ISNULL((max(faa_id)+1),1) from [dbo].[file_attribute_association]; '
					    SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_attribute_association] ON; '
					   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_attribute_association](faa_id, fsa_id,file_identifier,' + @str_column_names + ' ) values (  @faa_id ,@fsa_id, @record_id, ' + @str_column_values + '); '
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_attribute_association] OFF; '

					   if(@old_cftaa_id IS NoT NULL AND @old_cftaa_id > 0)
					   BEGIN
						  SET @insert_queries = @insert_queries +   'update [dbo].[file_attribute_association] SET  cftaa_id = ( select  new_cftaa_id from #tmp_attribute_association where old_cftaa_id = '+ CAST( @old_cftaa_id AS VARCHAR) +' )'
						  + ' where   faa_id = @faa_id' 
					   END

					   SET @insert_queries = @insert_queries + ' insert into  #tmp_faa_id_map (old_faa_id ,new_faa_id) values( ' + CAST( @old_faa_id AS VARCHAR)  + ' , @faa_id  )'
					   print @insert_queries
					   insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				        SET @counter = @counter + 1;
				    END
				   

				    -- For rule insertion
				    DECLARE file_template_rule_cur CURSOR LOCAL FOR SELECT business_rule_id, business_rule_version from file_attr_br_assoc where faa_id = @old_faa_id
				    OPEN file_template_rule_cur
				    FETCH NEXT FROM  file_template_rule_cur INTO @old_file_rule_id, @old_file_rule_version
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
					   
					   SET @where_clause = ' where drools_business_rule_id = ' + CAST( @old_file_rule_id AS VARCHAR) + ' and  drools_business_rule_version = ' +  CAST( @old_file_rule_version AS VARCHAR) 
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'drools_business_rules_decision_table',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @file_rule_id =  ISNULL((max(drools_business_rule_id)+1),1) from [dbo].[drools_business_rules_decision_table];'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON; '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				            SET @counter = @counter + 1;
						  SET @insert_queries =  ' INSERT INTO [dbo].[drools_business_rules_decision_table](drools_business_rule_id, drools_business_rule_version, ' + @str_column_names + ')'
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				            SET @counter = @counter + 1;
						  SET @insert_queries =  '  values (  @file_rule_id ,1,' + @str_column_values + '); '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				            SET @counter = @counter + 1;
						  SET @insert_queries =  ' SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF; '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
				            SET @counter = @counter + 1;
						  
						  SET @insert_queries = ' insert into #tmp_rule_id_map(old_rule_id, new_rule_id) values(' +  CAST( @old_file_rule_id AS VARCHAR) +', @file_rule_id)'
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
					   END
					   				 
					   SET @where_clause = ' where business_rule_id = ' + CAST( @old_file_rule_id AS VARCHAR) + ' and  business_rule_version = ' +  CAST( @old_file_rule_version AS VARCHAR) + ' and faa_id = ' +  CAST( @old_faa_id AS VARCHAR)
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'file_attr_br_assoc',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
					   SET @insert_queries = 'select @file_attr_br_assoc_id =  ISNULL((max(file_attr_br_assoc_id)+1),1) from [dbo].[file_attr_br_assoc];'
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_attr_br_assoc] ON; '
					   SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[file_attr_br_assoc](file_attr_br_assoc_id,business_rule_id, business_rule_version, faa_id,' + @str_column_names + ' ) values (@file_attr_br_assoc_id,  @file_rule_id ,1,@faa_id,' + @str_column_values + '); '
					   SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[file_attr_br_assoc] OFF; '
					   print @insert_queries
					   insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
					   SET @counter = @counter + 1;
					    END
					    FETCH NEXT FROM  file_template_rule_cur INTO @old_file_rule_id, @old_file_rule_version
					END
				   
				    CLOSE file_template_rule_cur
				    DEALLOCATE file_template_rule_cur
				-- END 
			FETCH NEXT FROM file_template_attribute_association_cur INTO @old_faa_id, @old_cftaa_id;
			END
			  CLOSE file_template_attribute_association_cur
			  DEALLOCATE file_template_attribute_association_cur

		    FETCH NEXT FROM file_template_section_assoc_cur INTO @old_fsa_id ;
	    END
	 CLOSE file_template_section_assoc_cur
	 DEALLOCATE file_template_section_assoc_cur

	 insert into #tmp_faa_lookup_id_map (faa_id, lookup_id, lookup_version) (select faa.faa_id, lookup_table_id, lookup_table_version from lookup_table_file_association  ltfa inner join 
	 file_attribute_association faa on ltfa.faa_id = faa.faa_id WHERE faa.file_identifier = @file_record_id);

	    DECLARE file_lookup_table_cur CURSOR LOCAL FOR SELECT  distinct lookup_id, lookup_version from #tmp_faa_lookup_id_map  
				    OPEN file_lookup_table_cur
				    FETCH NEXT FROM  file_lookup_table_cur INTO @old_lookup_table_id, @old_lookup_table_version
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
					   SET @where_clause = ' where lookup_table_id = ' + CAST( @old_lookup_table_id AS VARCHAR) + ' and lookup_table_version = ' + CAST( @old_lookup_table_version AS VARCHAR)
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lookup_table_meta_info',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @lookup_table_id =  ISNULL((max(lookup_table_id)+1),1) from [dbo].[lookup_table_meta_info];'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON; '
						  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lookup_table_meta_info]( lookup_table_id, lookup_table_version,associated_file_level_id, ' + @str_column_names + ' ) values (  @lookup_table_id,1,@record_id,' + @str_column_values + '); '
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF; '
						  SET @insert_queries = @insert_queries + ' insert into  #tmp_lookup_id_map (old_lookup_id ,new_lookup_id ) values ( ' +CAST( @old_lookup_table_id AS VARCHAR) + ', @lookup_table_id) '
						  print  @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
					   END

					   Declare  file_lookup_table_details_cur CURSOR LOCAL FOR SELECT lookup_detail_id from lookup_table_details where lookup_table_id = @old_lookup_table_id and  lookup_table_version = @old_lookup_table_version
					    OPEN file_lookup_table_details_cur
					    FETCH NEXT FROM  file_lookup_table_details_cur INTO @old_lookup_detail_id
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
					   SET @where_clause = ' where lookup_detail_id = ' + CAST( @old_lookup_detail_id AS VARCHAR) 				   
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lookup_table_details',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @lookup_detail_id =  ISNULL((max(lookup_detail_id)+1),1) from [dbo].[lookup_table_details];'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_details] ON; '
						  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lookup_table_details]( lookup_detail_id,lookup_table_id, lookup_table_version, ' + @str_column_names + ' ) values ( @lookup_detail_id, @lookup_table_id,1,' + @str_column_values + '); '
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_details] OFF; '
						  print  @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
					   END
					    FETCH NEXT FROM  file_lookup_table_details_cur INTO @old_lookup_detail_id
					END
				   
				    CLOSE file_lookup_table_details_cur
				    DEALLOCATE file_lookup_table_details_cur

					  

					 DECLARE  file_lookup_table_composite_key_cur CURSOR LOCAL FOR SELECT ltckm_id, business_rule_id from lookup_table_composite_key_mapping where lookup_table_id = @old_lookup_table_id and  lookup_table_version = @old_lookup_table_version
					 OPEN file_lookup_table_composite_key_cur
					    FETCH NEXT FROM  file_lookup_table_composite_key_cur INTO @old_ltckm_id,@old_rule_id
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
					   SET @where_clause = ' where ltckm_id = ' + CAST( @old_ltckm_id AS VARCHAR) 				   
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lookup_table_composite_key_mapping',@where_clause = @where_clause, @file_id = @file_record_id,@str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @ltckm_id =  ISNULL((max(ltckm_id)+1),1) from [dbo].[lookup_table_composite_key_mapping];'
						  
						  IF(@old_rule_id IS NULL OR @old_rule_id = '')
							 SET @insert_queries = @insert_queries +  ' SET @new_rule_id = NULL; ' 
						  ELSE 
							   SET @insert_queries = @insert_queries +  'select @new_rule_id = new_rule_id from #tmp_rule_id_map where old_rule_id = ' + CAST( @old_rule_id AS VARCHAR) + ' ;'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_composite_key_mapping] ON; '

						  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lookup_table_composite_key_mapping]( ltckm_id,lookup_table_id, lookup_table_version,business_rule_id, ' + @str_column_names + ' ) values ( @ltckm_id, @lookup_table_id,1,@new_rule_id,' + @str_column_values + '); '
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_composite_key_mapping] OFF; '
						  print  @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
						  SET @counter = @counter + 1;
					   END
					    FETCH NEXT FROM  file_lookup_table_composite_key_cur INTO @old_ltckm_id,@old_rule_id
					END
				   
				    CLOSE file_lookup_table_composite_key_cur
				    DEALLOCATE file_lookup_table_composite_key_cur
				FETCH NEXT FROM  file_lookup_table_cur INTO @old_lookup_table_id, @old_lookup_table_version;
				END
				CLOSE file_lookup_table_cur
				DEALLOCATE file_lookup_table_cur

				  DECLARE file_attribute_lookup_table_cur CURSOR LOCAL FOR SELECT  distinct lookup_id, lookup_version, faa_id from #tmp_faa_lookup_id_map  
				    OPEN file_attribute_lookup_table_cur
				    FETCH NEXT FROM  file_attribute_lookup_table_cur INTO @old_lookup_table_id, @old_lookup_table_version, @old_faa_id
				     WHILE @@FETCH_STATUS = 0
				     BEGIN
				  SET @where_clause = ' where faa_id = ' + CAST( @old_faa_id AS VARCHAR) 	+ ' and lookup_table_id = '+ CAST( @old_lookup_table_id AS VARCHAR)	+ ' and lookup_table_version = ' +  CAST( @old_lookup_table_version AS VARCHAR)	   
					   SET @str_column_names = NULL;
					   SET @str_column_values = NULL;
					   EXEC [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names] @table_name = 'lookup_table_file_association',@where_clause = @where_clause, @file_id = @file_record_id, @str_col_name = @str_column_names OUTPUT,@str_col_value = @str_column_values OUTPUT
					   if(@str_column_values is NOT null AND @str_column_values <> '')
					   BEGIN
						  SET @insert_queries = 'select @lookup_record_id =  ISNULL((max(record_id)+1),1) from [dbo].[lookup_table_file_association];'
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_file_association] ON; '
						  SET @insert_queries = @insert_queries + 'INSERT INTO [dbo].[lookup_table_file_association](record_id, lookup_table_id, lookup_table_version,faa_id, ' + @str_column_names + ' ) values (  @lookup_record_id , (select new_lookup_id from  #tmp_lookup_id_map where old_lookup_id = 
						  '  +CAST( @old_lookup_table_id AS VARCHAR) + '),1, (select new_faa_id from  #tmp_faa_id_map where old_faa_id = '+  CAST( @old_faa_id AS VARCHAR)  +'  ),' + @str_column_values + '); '
						  SET @insert_queries = @insert_queries +  ' SET IDENTITY_INSERT [dbo].[lookup_table_file_association] OFF; '
						  print @insert_queries
						  insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)
					       SET @counter = @counter + 1;
					   END
					    FETCH NEXT FROM  file_attribute_lookup_table_cur INTO  @old_lookup_table_id, @old_lookup_table_version, @old_faa_id
					END
				   
				    CLOSE file_attribute_lookup_table_cur
				    DEALLOCATE file_attribute_lookup_table_cur

     SELECT @insert_queries
     SET @insert_queries = 'DROP TABLE #tmp_rule_id_map;  '
	SET @insert_queries = @insert_queries +' DROP TABLE #tmp_notification_template_id_map;  '
	SET @insert_queries = @insert_queries + 'DROP TABLE #tmp_attribute_association;  '
	SET @insert_queries = @insert_queries + 'DROP TABLE #tmp_faa_id_map;  '
	SET @insert_queries = @insert_queries + 'Drop table #tmp_lookup_id_map;  '
	print @insert_queries
	insert into file_export_queries(file_record_id, created_date, sequence, query) VALUES (@file_record_id, @current_date_time, @counter, @insert_queries)

END;
GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_Export_File_Configuration_Queries
	TO exec_proc;
GO

*/