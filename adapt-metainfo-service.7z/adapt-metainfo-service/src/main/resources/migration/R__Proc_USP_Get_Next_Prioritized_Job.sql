USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Get_Next_Prioritized_Job]    Script Date: 2/23/2018 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Filename:  USP_Get_Next_Prioritized_Job.sql
 
Parameters: 
@i_job_status,@i_source_instance,@i_pass_phrase

2019-01-03	Disha Shah	ADAPT-258: Created SP for picking next prioritized job and returning its details
2019-01-25	Disha Shah  ADAPT-1650: Merged Inbound & Outbound flow for getting mext prioritized job & fetching its details
2019-09-30  Divya Jain	ADAPT-7527: Implementation for Data Extraction Improvements - Engine
2019-11-22	Jinesh vora	ADAPT-8376 : Add Profile ID filed.

***********************************************
*/

IF OBJECT_ID('dbo.USP_Get_Next_Prioritized_Job') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Next_Prioritized_Job AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_Next_Prioritized_Job]
	(
		@i_job_status VARCHAR(20),
		@i_source_instance VARCHAR(20),
		@i_pass_phrase VARCHAR(20)
	) 
AS
BEGIN

SET NOCOUNT ON; 

DECLARE @RC INT;
DECLARE @picked_job_id INT = -1;
DECLARE @blackOutWindowStatus INT = -1;

----- Blackout window check ------
SELECT @blackOutWindowStatus = CASE WHEN EXISTS 
	(SELECT 1 FROM adapt_processing_blackout_info WHERE GETDATE() BETWEEN apbi_start_date_time AND apbi_end_date_time
		AND is_active=1)
	THEN 1 
	ELSE -1 
	END;
PRINT 'black out:'+CAST(@blackOutWindowStatus as varchar);
IF(@blackOutWindowStatus = 1) 
	RETURN;

BEGIN TRANSACTION JOB_PICK_TRAN;

BEGIN TRY
	-- Since this is updating job status, using table level lock
	EXEC @RC = sp_getapplock @Resource='job_details_prioritization', @LockMode='Exclusive', 
				@LockOwner='Transaction', @LockTimeout=15000;
	PRINT 'Lock Granted Immidiately:'+CAST(@RC as VARCHAR)
	
	SELECT TOP 1 @picked_job_id = JDP.job_id FROM job_details_prioritization JDP 
		INNER JOIN job_details JD ON JDP.job_id = JD.job_id
		WHERE JDP.job_status = @i_job_status AND JD.job_soft_deleted = 0
		AND JDP.is_active = 1 ORDER BY job_priority;
	
	UPDATE job_details_prioritization SET job_status = 'IN_PROGRESS', updated_by = @i_source_instance,   
		updated_date_time = GETDATE() WHERE job_id = @picked_job_id;
	
	COMMIT TRANSACTION JOB_PICK_TRAN;
	
	UPDATE job_details  SET job_status = 'IN_PROGRESS', job_actual_start_datetime = GETDATE() 
		WHERE job_id = @picked_job_id;

END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION JOB_PICK_TRAN;
END CATCH

-- Returning data related to the next job
select jd.job_id as jobId,
job_expected_start_datetime as jobExpectedStartDateTime,
fmi.file_processing_error_threshold_count as fileProcessingErrorThresholdCount,
fmi.file_min_record_count_allowed as fileMinRecordCountAllowed,
case when job_transmission_connection_id is null then cast(fmi.file_id as varchar(100))+'.txt' else fti.transmission_name end as fileTransmissionName,
--fti.transmission_name as fileTransmissionName,
ftmi.system_name as fileTypeName, 
	case 
	when fms.file_format_name in ('delimited','DELIMITED') then 'FILE_DELIMITED'
	when fms.file_format_name in ('fixed width','FIXED_WIDTH','FIXED WIDTH','fixed_width') then 'FILE_FIXED_WIDTH'
	when fms.file_format_name in ('xml','XML') then 'FILE_XML'
	else fms.file_format_name end as fileFormatName,
fms.file_format_row_delimiter as fileFormatRowDelimiter, 
fms.file_format_field_delimiter as fileFormatFieldDdelimiter, 
fms.file_format_escape_char as fileFormatEscapeChar, 
fms.file_format_segment_delimiter as fileFormatSegmentDelimiter,
jd.file_processing_priority as priority,
STUFF((SELECT distinct ',' + (CAST(cea.employer_id AS VARCHAR)+'::'+CAST(cea.client_id AS VARCHAR) +'::'+CAST(jd.test_cfg AS VARCHAR)) as er 
	from client_employer_assoc cea 
	join file_employer_assoc fea on cea.client_employer_assoc_id=fea.client_employer_assoc_id
	where fea.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as employerClientIdTestCfgs,
fmi.master_file_template_id as masterFileTemplateId,
fmi.master_file_template_version as masterFileTemplateVersion,
case when jd.file_data_extraction_mode='Full' then 1 else 0 end as fullOrChange,
case when (ftmi.direction = 'Inbound' AND fpm.file_processing_mode_id=8) OR 
       (ftmi.direction = 'Outbound' AND fpm.file_processing_mode_id=9) then 1 else 0 end as resultsMode,
fmi.file_max_record_count_allowed as fileMaxRecordCountAllowed,
case when fmi.file_processing_error_threshold_format ='Percentage Of Records' then 'PERCENTAGE'
when fmi.file_processing_error_threshold_format ='Number of Records' then 'COUNT'
else 'NONE' end as fileProcessingErrorThresholdFormat,
jd.file_identifier as fileIdentifier,
fmi.file_id as fileId,
fmi.file_version as fileVersion,
isNull(stuff((
	SELECT ','+ CAST(clone_num AS VARCHAR) FROM file_clone_info WHERE file_identifier = fmi.record_id FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'')
	, '')   as cloneNumberList,
fs.file_state_id as fileStateId,
fs.file_path as filePath,
fs.file_name as fileName,
fs.encrypted_private_key as fileStatePrivatekey,
isNull(
	(select cast(decryptbypassphrase(@i_pass_phrase,private_key) AS varchar(max)) 
		from master_auth_key_details where is_active = 1) , 
'')  as masterPrivateKey,
fs.new_file_name as newFileName,
ftmi.direction as direction,
STUFF((SELECT distinct ',' +fepa_criteria_unique_identifier as benefitPlanSubType 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='benefitPlanSubType'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id
       FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as PlanSubtypes,
(SELECT distinct fepa_criteria_unique_identifier as benefitPlanYear 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='benefitPlanYear'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id) as planYear,
(SELECT distinct fepa_criteria_unique_identifier as planAdditionFactor 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='planAdditionFactor'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id) as planAdditionFactor,
(SELECT distinct case when fepa_criteria_unique_identifier is null then null when fepa_criteria_unique_identifier = '' then job_expected_start_datetime else fepa_criteria_unique_identifier end as systemDate 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='systemDate'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id) as systemDate,
(SELECT distinct fepa_criteria_unique_identifier as lookBackPeriod 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='lookBackPeriod'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id) as lookBackPeriod,
(SELECT distinct fepa_criteria_unique_identifier as lookAheadPeriod 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='lookAheadPeriod'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id) as lookAheadPeriod,
STUFF((SELECT distinct ',' +fepa_criteria_unique_identifier as employerIds 
       from file_extraction_parameters_assoc fas
       join file_extraction_parameters_info fe on fe.fepi_id = fas.fepa_fepi_id
       join extraction_parameters ep on ep.ep_id = fas.fepa_ep_id and ep_standardized_name='employerId'
       where fas.is_active=1 and fe.file_identifier=fmi.record_id and fe.fepi_profile_id=fps.profile_id
       FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as extractionEmployerIds,
dstt.data_source_target_type_name as data_source_type,
dstt1.data_source_target_type_name as data_target_type,
fps.profile_id as profileId
from job_details jd
join file_meta_info fmi on fmi.record_id=jd.file_identifier
join data_source_target_type dstt on fmi.data_source_type_id=dstt.data_source_target_type_id
join data_source_target_type dstt1 on fmi.data_target_type_id=dstt1.data_source_target_type_id
join file_type_meta_info ftmi on ftmi.file_type_id=fmi.file_type_id
join file_format_supported fms on fms.file_format_supported_id=fmi.file_format_supported_id
join file_processing_schedule fps on jd.file_processing_schedule_id=fps.file_processing_schedule_id
join file_processing_recurrence fpr on fpr.file_processing_recurrence_id=fps.file_processing_recurrence_id
join file_processing_mode fpm on fpm.file_processing_mode_id=fpr.file_processing_mode_id
left join file_transmission_info fti on jd.job_transmission_connection_id=fti.file_transmission_connection_id
left join file_state fs on fs.job_id=jd.job_id and fs.file_status = @i_job_status
where jd.job_id = @picked_job_id;

END
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Next_Prioritized_Job TO exec_proc
GO

	
	
