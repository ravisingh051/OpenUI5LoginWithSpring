USE [idis-metainfo]
GO

/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
23-05-2019  Jinesh Vora	   	ADAPT-6085 : Adapt roles level1 to 7 - Issues to be addressed
Data Delete From Table - roles_idis_dbrd_actions_assoc 

*/


IF EXISTS (
  SELECT 1 FROM  [dbo].[roles_idis_dbrd_actions_assoc] WHERE role_action_assoc_id in(304,363,403,443))
BEGIN

DELETE FROM [roles_idis_dbrd_actions_assoc] WHERE [role_action_assoc_id] IN(304,363,403,443)

END;
GO
