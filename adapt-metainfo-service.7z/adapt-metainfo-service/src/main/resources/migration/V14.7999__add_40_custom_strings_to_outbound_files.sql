USE [idis-metainfo]
GO
/*
Filename:  V14.7999__add_40_custom_strings_to_outbound_files.sql

Update Log
Date         Author            Description
----------   ----------------    ----------------------------------------------------------
2019-10-11   Pravin Rajput		 ADAPT-7999 : Add 40 custom strings to outbound files 
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 1015 and attribute_name = 'Custom Defined31')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1015,'Custom Defined31','PRE-DEFINED :: Custom Defined31','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1016 and attribute_name = 'Custom Defined32')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1016,'Custom Defined32','PRE-DEFINED :: Custom Defined32','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1017 and attribute_name = 'Custom Defined33')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1017,'Custom Defined33','PRE-DEFINED :: Custom Defined33','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1018 and attribute_name = 'Custom Defined34')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1018,'Custom Defined34','PRE-DEFINED :: Custom Defined34','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1019 and attribute_name = 'Custom Defined35')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1019,'Custom Defined35','PRE-DEFINED :: Custom Defined35','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1020 and attribute_name = 'Custom Defined36')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1020,'Custom Defined36','PRE-DEFINED :: Custom Defined36','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1021 and attribute_name = 'Custom Defined37')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1021,'Custom Defined37','PRE-DEFINED :: Custom Defined37','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1022 and attribute_name = 'Custom Defined38')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1022,'Custom Defined38','PRE-DEFINED :: Custom Defined38','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1023 and attribute_name = 'Custom Defined39')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1023,'Custom Defined39','PRE-DEFINED :: Custom Defined39','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from attribute_dictionary where attribute_id = 1024 and attribute_name = 'Custom Defined40')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (1024,'Custom Defined40','PRE-DEFINED :: Custom Defined40','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4689 and file_type_id = 17 and attribute_id = 1015)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4689,17,1015,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined31',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4690 and file_type_id = 17 and attribute_id = 1016)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4690,17,1016,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined32',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4691 and file_type_id = 17 and attribute_id = 1017)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4691,17,1017,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined33',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4692 and file_type_id = 17 and attribute_id = 1018)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4692,17,1018,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined34',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4693 and file_type_id = 17 and attribute_id = 1019)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4693,17,1019,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined35',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4694 and file_type_id = 17 and attribute_id = 1020)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4694,17,1020,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined36',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4695 and file_type_id = 17 and attribute_id = 1021)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4695,17,1021,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined37',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4696 and file_type_id = 17 and attribute_id = 1022)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4696,17,1022,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined38',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4697 and file_type_id = 17 and attribute_id = 1023)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4697,17,1023,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined39',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4698 and file_type_id = 17 and attribute_id = 1024)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4698,17,1024,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'employee.customDefined40',12)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2153 and master_file_template_record_id = 18 and attribute_id = 1015)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2153,18,1,1015,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4689,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2154 and master_file_template_record_id = 18 and attribute_id = 1016)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2154,18,1,1016,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4690,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2155 and master_file_template_record_id = 18 and attribute_id = 1017)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2155,18,1,1017,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4691,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2156 and master_file_template_record_id = 18 and attribute_id = 1018)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2156,18,1,1018,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4692,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2157 and master_file_template_record_id = 18 and attribute_id = 1019)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2157,18,1,1019,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4693,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2158 and master_file_template_record_id = 18 and attribute_id = 1020)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2158,18,1,1020,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4694,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2159 and master_file_template_record_id = 18 and attribute_id = 1021)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2159,18,1,1021,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4695,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2160 and master_file_template_record_id = 18 and attribute_id = 1022)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2160,18,1,1022,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4696,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2161 and master_file_template_record_id = 18 and attribute_id = 1023)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2161,18,1,1023,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4697,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2162 and master_file_template_record_id = 18 and attribute_id = 1024)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2162,18,1,1024,'VARCHAR',0,NULL,NULL,78,'Pravin Rajput',getDate(),18,50,4698,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO