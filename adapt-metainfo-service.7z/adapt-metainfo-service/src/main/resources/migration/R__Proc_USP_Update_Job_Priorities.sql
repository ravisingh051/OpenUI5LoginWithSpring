USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Update_Job_Priorities]    Script Date: 2/23/2018 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Update_Job_Priorities') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Update_Job_Priorities AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Update_Job_Priorities]
	(
		@i_source_instance VARCHAR(20),
		@o_status INT OUT
	) 
AS
BEGIN

SET NOCOUNT ON; 

DECLARE @RC INT;
SET @o_status = -1;

BEGIN TRANSACTION AUDIT_TRAN;

BEGIN TRY
	-- Since this includes delete & insert operations, using table level lock
	EXEC @RC = sp_getapplock @Resource='job_details_prioritization', @LockMode='Exclusive', 
				@LockOwner='Transaction', @LockTimeout=15000;
	PRINT 'Lock Granted Immidiately:'+CAST(@RC as VARCHAR)

	DELETE FROM job_details_prioritization;

	INSERT INTO job_details_prioritization
		SELECT job_id ,job_status ,job_priority ,is_active ,created_by ,created_date_time ,updated_by ,updated_date_time 
		FROM job_details_prioritization_staging;

	DELETE FROM job_details_prioritization_staging;

	UPDATE job_prioritization_audit SET job_prioritization_status='COMPLETED' 
		WHERE job_prioritization_status = 'STARTED'
		AND source_instance = @i_source_instance;

	COMMIT TRANSACTION AUDIT_TRAN;
	
	SET @o_status = 1;

END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION AUDIT_TRAN;
END CATCH
END
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Update_Job_Priorities TO exec_proc
GO


