USE [idis-metainfo]
GO
-- =============================================
/*
-- Author:			Jinesh Vora
-- Create date:		05-08-2019 
-- ADAPT - 6906 : 	Clone data
-- TABLE 
-- child_file_template_clone_info 				-- CREATE
-- child_template_layout_schema_node_info		-- ALTER
-- child_file_template_attribute_associaton		-- ALTER 

*/
-- =============================================



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_clone_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_clone_info](
                [child_file_template_clone_id] [int] IDENTITY(1,1) NOT NULL,
                [child_file_template_record_id] [int] NOT NULL,
                [clone_num] [int] NOT NULL,
                [clone_name] [varchar](100) NOT NULL,
                [created_by] [varchar](50) NOT NULL,
                [created_date_time] [datetime] NOT NULL,
                [updated_by] [varchar](50) NULL,
                [updated_date_time] [datetime] NULL
CONSTRAINT [PK_cft_clone_info_id] PRIMARY KEY CLUSTERED 
(
                [child_file_template_clone_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

-- Add FK with child_file_template_meta_info
IF NOT EXISTS (
                                SELECT 1
                                FROM sys.foreign_keys c
                                WHERE name = 'FK_cftmi_K19_child_file_template_clone_info_K2'
                                                AND c.parent_object_id = OBJECT_ID('dbo.child_file_template_clone_info')
                                )
BEGIN
                ALTER TABLE [dbo].[child_file_template_clone_info]
                                WITH CHECK ADD CONSTRAINT [FK_cftmi_K19_child_file_template_clone_info_K2] FOREIGN KEY ([child_file_template_record_id]) REFERENCES [dbo].[child_file_template_meta_info]([child_file_template_record_id])

                ALTER TABLE [dbo].[child_file_template_clone_info] CHECK CONSTRAINT [FK_cftmi_K19_child_file_template_clone_info_K2]
END;
GO


-- Add clone_num into child_file_template_attribute_associaton Table

IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='child_file_template_attribute_association' and column_name ='clone_num' 
)
BEGIN
ALTER TABLE child_file_template_attribute_association ADD clone_num INT NOT NULL constraint DF_cftaa_set_clone_num_as_default default (0);

END;
GO

-- Add clone_num into child_template_layout_schema_node_info Table

IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='child_template_layout_schema_node_info' and column_name ='node_clone_num' 
)
BEGIN
ALTER TABLE child_template_layout_schema_node_info ADD node_clone_num INT NOT NULL constraint DF_ctlsni_set_clone_num_as_default default (0);

END;
GO
