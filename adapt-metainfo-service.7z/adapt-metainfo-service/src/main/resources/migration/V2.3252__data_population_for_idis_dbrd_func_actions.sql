use [idis-metainfo]
GO
/*
Filename:  V2.3252__data_population_for_idis_dbrd_func_actions.sql

Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-05-03    Valmik Pujara			ADAPT-3252 : User should be able to migrate Tooltips entered from Setup environment to other
*/
IF NOT EXISTS (
  SELECT 1 FROM  [dbo].[idis_dbrd_func_actions] WHERE action_id between 96 and 97)
BEGIN
SET IDENTITY_INSERT [dbo].[idis_dbrd_func_actions] ON
INSERT [dbo].[idis_dbrd_func_actions] ([action_id], [action_name], [functionality_id], [is_allowed_on_prod], [created_by], [created_date], [updated_by], [updated_date], [is_group_check_applicable]) VALUES (96, N'Export Tooltip', 18, 1, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL, 1)
INSERT [dbo].[idis_dbrd_func_actions] ([action_id], [action_name], [functionality_id], [is_allowed_on_prod], [created_by], [created_date], [updated_by], [updated_date], [is_group_check_applicable]) VALUES (97, N'Import Tooltip', 18, 1, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL, 1)
SET IDENTITY_INSERT [dbo].[idis_dbrd_func_actions] OFF
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM  [dbo].[roles_idis_dbrd_actions_assoc] WHERE role_action_assoc_id between 449 and 455)
BEGIN

SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (449, 7, 96, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (450, 8, 96, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (451, 9, 96, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (452, 10, 96, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (453, 11, 96, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (454, 10, 97, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
INSERT [dbo].[roles_idis_dbrd_actions_assoc] ([role_action_assoc_id], [role_id], [action_id], [created_by], [created_date], [updated_by], [updated_date]) VALUES (455, 11, 97, N'A1009747', CAST(N'2019-04-29 00:00:00.000' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF
END;
GO
