SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Richa Ashara
-- Create date:	18/09/2018
-- Description:	Deletes master template for given version
-- =============================================

/*
update log 
    Date		Author				Details
------------	-----------------	----------------------------------------------------------------------------------------
2019-10-15		Snehal Patel		ADAPT-7998 : Remove enumerated values and print display name.
*/
IF OBJECT_ID('dbo.USP_Master_File_Template_Deletion') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Master_File_Template_Deletion AS SELECT 1')
GO
ALTER PROCEDURE [dbo].[USP_Master_File_Template_Deletion]
	-- Add the parameters for the stored procedure here
	@iMasterTemplate_id INT, 
	@iMasterTemplate_version INT
AS
BEGIN

	   DECLARE @file_type_id int;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	   SET NOCOUNT ON;

    SELECT @file_type_id=[file_type_id] from [dbo].[master_file_template_meta_info] where [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version]=@iMasterTemplate_version

    DELETE FROM [dbo].[lookup_table_file_association]  where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_version)
									 and faa_id is NULL and is_active=1

    DELETE FROM [dbo].[lookup_table_composite_key_mapping]  where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_version)

    DELETE FROM [dbo].[lookup_table_details] where lookup_table_id in (select lookup_table_id from  lookup_table_meta_info where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_version)

    DELETE  from [dbo].[lookup_table_meta_info] where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_version

    select br.business_rule_id,br.mftaa_id into #rules FROM [dbo].[master_file_template_attr_br_assoc] br join [master_file_template_attribute_association] attr on br.mftaa_id=attr.mftaa_id where [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version]=@iMasterTemplate_version
 
    DELETE  FROM [dbo].[master_file_template_attr_br_assoc] where mftaa_id in(select mftaa_id FROM #rules)
	
    DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #rules)

    DELETE FROM [dbo].[mftaa_valid_value_assoc] where mftaa_id  in ( SELECT mftaa_id FROM [master_file_template_attribute_association] WHERE [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version] = @iMasterTemplate_version) 
	   AND [master_file_template_id] = @iMasterTemplate_id AND master_file_template_version=@iMasterTemplate_version
	   
	select mtlsni.mtlsni_id into #nodes from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi on mftmi.master_file_template_record_id=mtlsni.master_file_template_record_id
				where [master_file_template_id] = @iMasterTemplate_id AND [master_file_template_version] = @iMasterTemplate_version
	
	select business_rule_id  into #node_rules from mtls_node_br_assoc where mtlsni_id in (select mtlsni_id from #nodes)
	
	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #node_rules)
	
	DELETE FROM mtls_node_br_assoc where mtlsni_id in (select mtlsni_id from #nodes)
	
	DELETE FROM mtls_node_dm_element_assoc where mtlsni_id in (select mtlsni_id from #nodes)
	
	DELETE FROM master_template_layout_schema_node_assoc where mtlsni_id in (select mtlsni_id from #nodes)
	
	DELETE FROM master_template_layout_schema_node_info where mtlsni_id in (select mtlsni_id from #nodes)

    DELETE FROM [master_file_template_attribute_association]  WHERE [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version] = @iMasterTemplate_version

    DELETE FROM [dbo].[master_file_template_section_assoc] where [master_file_template_id]=@iMasterTemplate_id and master_file_template_version=@iMasterTemplate_version;

    DELETE FROM [dbo].[master_file_template_meta_info] where [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version]=@iMasterTemplate_version
	
END
GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 

GRANT EXECUTE ON dbo.USP_Master_File_Template_Deletion TO exec_proc

GO