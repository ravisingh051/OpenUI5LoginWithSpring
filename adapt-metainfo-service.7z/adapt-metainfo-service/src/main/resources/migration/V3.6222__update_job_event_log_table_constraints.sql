USE [idis-metainfo]
GO

IF EXISTS (
		SELECT 1
		FROM information_schema.columns where table_name='job_event_log' and column_name='jel_file_id' and is_nullable='NO')
BEGIN
ALTER TABLE [dbo].[job_event_log] alter column jel_file_id int null
END;
GO

IF EXISTS (
		SELECT 1
		FROM information_schema.columns where table_name='job_event_log' and column_name='jel_file_version' and is_nullable='NO')
BEGIN
ALTER TABLE [dbo].[job_event_log] alter column jel_file_version int null
END;
GO


