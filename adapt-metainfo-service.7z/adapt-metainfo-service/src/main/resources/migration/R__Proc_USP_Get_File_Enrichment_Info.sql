USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
26-06-2018	Divya Jain	CC-35722: Ability to process enrichment rules for inbound files
*/


IF OBJECT_ID('dbo.USP_Get_File_Enrichment_Info') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_File_Enrichment_Info AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_File_Enrichment_Info]
	(
		@i_file_identifier int
	) 
AS
BEGIN

SET NOCOUNT ON; 


if exists(select 1 from file_secondary_mapping_attr_assoc where fsmaa_file_identifier = @i_file_identifier)
begin
select secondary_data_api_mapped_obj_pojo_name,secondary_data_api_mapped_obj_endpoint from
secondary_data_api_mapped_obj where secondary_data_api_mapped_obj_is_active=1
end;


END
Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_File_Enrichment_Info TO exec_proc
GO

