use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-30   Divya Jain			ADAPT-7707 : Add template feature for File


*/

if not exists(select 1 from information_schema.columns where table_name='file_meta_info' and column_name='is_template')
begin
alter table file_meta_info add is_template bit NOT NULL CONSTRAINT DF_file_meta_info_is_template default(0)
end;
go



-- IX_File_Meta_Info_K2

IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K2] ON [dbo].[File_Meta_Info]
(
	[file_id]
)INCLUDE(record_id, file_type_id, master_file_template_id, master_file_template_version, file_version, file_name, file_status, is_active, approval_status_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO



-- IX_File_Meta_Info_K24_K25_K2

IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K24_K25_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K24_K25_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K24_K25_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K24_K25_K2] ON [dbo].[file_meta_info]
(
	[is_active] ASC,
	[approval_status_id] ASC,
	[file_id] ASC
)
INCLUDE ( 	[record_id],
	[file_version],
	[file_name],
	[file_status],
	[master_file_template_id],
	[master_file_template_version],
	[file_type_id]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO


-- IX_File_Meta_Info_K24_K25_K8_K2
IF EXISTS (SELECT 1
FROM sys.indexes AS i  
INNER JOIN sys.index_columns AS ic
    ON i.object_id = ic.object_id AND i.index_id = ic.index_id  
WHERE i.object_id = OBJECT_ID('[dbo].[File_Meta_Info]') and i.NAME='IX_File_Meta_Info_K24_K25_K8_K2'
and COL_NAME(ic.object_id,ic.column_id)='child_file_template_id')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K24_K25_K8_K2
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K24_K25_K8_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K24_K25_K8_K2] ON [dbo].[File_Meta_Info]
(
	[is_active],[approval_status_id],[file_version],[file_id]
)INCLUDE(record_id,file_Name,file_Status,master_file_template_id,master_file_template_version,file_type_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

-- IX_file_meta_info_K6
IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_file_meta_info_K6')
BEGIN
DROP INDEX File_Meta_Info.IX_file_meta_info_K6
END;
GO

-- IX_File_Meta_Info_K6_K7_K38

IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K6_K7_K38')
BEGIN
DROP INDEX File_Meta_Info.IX_File_Meta_Info_K6_K7_K38
END;
GO


-- lookup_table_file_association
-- IX_lookup_table_file_association_K6_K7 -- cftaa_id, is_active


IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K6_K7')
BEGIN
DROP INDEX lookup_table_file_association.IX_lookup_table_file_association_K6_K7
END;
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K7')
BEGIN
CREATE NONCLUSTERED INDEX [IX_lookup_table_file_association_K7] ON [dbo].[lookup_table_file_association]
(
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO

-------------------------- FK

-- FILE META INFO
IF EXISTS (
	SELECT *
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_NAME='FK_fmi_K38_cftmi_K15'
	)
BEGIN
alter table file_meta_info
drop constraint FK_fmi_K38_cftmi_K15
END;
GO


IF EXISTS (
	SELECT *
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_NAME='FK_fmi_K6_K7_cftmi_K1_K2'
	)
BEGIN
alter table file_meta_info
drop constraint FK_fmi_K6_K7_cftmi_K1_K2
END;
GO

---------------------------------- DK

IF EXISTS (
	SELECT * FROM dbo.sysobjects WHERE ID = OBJECT_ID(N'DF_config_promotion_audit_info_pmt_promoted')
	)
BEGIN
alter table config_promotion_audit_info
drop constraint DF_config_promotion_audit_info_pmt_promoted
END;
GO


----------------- COLUMN 

-- child_file_template_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_id' and is_nullable='NO')
BEGIN
ALTER TABLE file_meta_info alter column child_file_template_id int null
END;
GO

-- child_file_template_version
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_version' and is_nullable='NO')
BEGIN
ALTER TABLE file_meta_info alter column child_file_template_version int null
END;
GO

-- child_file_template_record_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_meta_info' and column_name ='child_file_template_record_id' and is_nullable='NO')
BEGIN
ALTER TABLE file_meta_info alter column child_file_template_record_id int null
END;
GO


-- lookup_table_file_association.cftaa_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='lookup_table_file_association' and column_name ='cftaa_id' and is_nullable='NO')
BEGIN
ALTER TABLE lookup_table_file_association alter column cftaa_id int null
END;
GO


-- file_attribute_association.cftaa_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_attribute_association' and column_name ='cftaa_id' and is_nullable='NO')
BEGIN
ALTER TABLE file_attribute_association alter column cftaa_id int null
END;
GO


-- config_promotion_audit_info.pmt_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='pmt_id' and is_nullable='NO')
BEGIN
ALTER TABLE config_promotion_audit_info alter column pmt_id int null
END;
GO


-- pmt_version
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='pmt_version' and is_nullable='NO')
BEGIN
ALTER TABLE config_promotion_audit_info alter column pmt_version int null
END;
GO

-- config_promotion_audit_info.was_pmt_promoted
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='config_promotion_audit_info' and column_name ='was_pmt_promoted' and is_nullable='NO')
BEGIN
ALTER TABLE config_promotion_audit_info alter column was_pmt_promoted bit null
END;
GO


-- 	file_layout_schema_node_info.ctlsni_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_layout_schema_node_info' and column_name ='ctlsni_id' and is_nullable='NO')
BEGIN
ALTER TABLE file_layout_schema_node_info alter column ctlsni_id int null
END;
GO

-- 	fls_node_enum_value_assoc.ctaeva_id
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='fls_node_enum_value_assoc' and column_name ='ctaeva_id' and is_nullable='NO')
BEGIN
ALTER TABLE fls_node_enum_value_assoc alter column ctaeva_id int null
END;
GO


-----------------------------------------------------------------------------------------------------------------------------


-- Remove Permission Mapping From roles_idis_dbrd_actions_assoc

IF EXISTS (SELECT 1 FROM roles_idis_dbrd_actions_assoc WHERE 
ACTION_ID IN (SELECT ACTION_ID FROM idis_dbrd_func_actions where functionality_id = 3))

BEGIN

DELETE FROM roles_idis_dbrd_actions_assoc WHERE 
ACTION_ID IN (SELECT ACTION_ID FROM idis_dbrd_func_actions where functionality_id = 3);

END;
GO


-- Remove Permission Mapping From idis_dbrd_func_actions

IF EXISTS (SELECT 1 FROM idis_dbrd_func_actions where functionality_id = 3)
BEGIN
DELETE FROM idis_dbrd_func_actions where functionality_id = 3
END;

GO


-- Remove Permission Mapping From idis_dbrd_func
IF EXISTS (select * from idis_dbrd_func where functionality_id = 3 and functionality_name = 'PMT Setup')
BEGIN
DELETE FROM idis_dbrd_func where functionality_id = 3 and functionality_name = 'PMT Setup'
END;
GO

-- Remove Tool Tips FROM adapt_web_page_fields

IF EXISTS (select 1 from tooltip_meta_info where tooltip_field_id in (select adapt_web_page_field_id from adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35)))
BEGIN 
DELETE FROM tooltip_meta_info where tooltip_field_id in (select adapt_web_page_field_id from adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35))
END
GO



-- Remove Web Page & Web Page Fields FROM adapt_web_page_fields

IF EXISTS (SELECT 1 FROM adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35))
BEGIN 
DELETE FROM adapt_web_page_fields where adapt_web_page_id in (10,12,13,14,15,25,35) 
END
GO


-- Remove Web Page & Web Page Fields FROM adapt_web_page

IF EXISTS (SELECT 1 FROM adapt_web_pages where adapt_web_page_id in (10,12,13,14,15,25,35))
BEGIN 
DELETE FROM adapt_web_pages where adapt_web_page_id in (10,12,13,14,15,25,35) 
END
GO
