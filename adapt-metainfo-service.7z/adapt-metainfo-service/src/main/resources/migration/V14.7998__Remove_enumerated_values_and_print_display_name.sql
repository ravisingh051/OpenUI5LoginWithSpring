use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------   	-------------------------------------------------------------------------------------------
2019-10-16   Snehal Patel		 	ADAPT-7998 : Remove enumerated values and print display name


-- Table Removed 
-- fls_node_enum_value_assoc
-- mtls_node_enum_value_assoc

-- Table Updated 
-- file_layout_schema_node_info
-- master_template_layout_schema_node_info
-- fls_node_br_assoc
-- drools_business_rules_decision_table
-- drools_business_rule_template
-- drools_business_rule_group
*/



--------------------------------------------------------------------------------------------------------------------------------------------
-- TABLE DROP 
--------------------------------------

-- fls_node_enum_value_assoc
IF EXISTS (SELECT 1 FROM sys.tables where name = 'fls_node_enum_value_assoc')
BEGIN 
EXEC sp_rename 'fls_node_enum_value_assoc', 'fls_node_enum_value_assoc_bkup'
END;
GO 

-- mtls_node_enum_value_assoc
IF EXISTS (SELECT 1 FROM sys.tables where name = 'mtls_node_enum_value_assoc')
BEGIN
EXEC sp_rename 'mtls_node_enum_value_assoc', 'mtls_node_enum_value_assoc_bkup'
END;
GO 


--Migration Script 

IF EXISTS (select 1 from file_layout_schema_node_info where mapped_column_type='Data Element And/Or Enumerated Values')
BEGIN 
update file_layout_schema_node_info set mapped_column_type='Data Element' where mapped_column_type='Data Element And/Or Enumerated Values'
END
GO


IF EXISTS (select 1 from master_template_layout_schema_node_info where mapped_column_type='Data Element And/Or Enumerated Values')
BEGIN 
update master_template_layout_schema_node_info set mapped_column_type='Data Element' where mapped_column_type='Data Element And/Or Enumerated Values'
END
GO


-- insert Hardcode & Print Display Name Rule Information  into tmp table 
IF OBJECT_ID('tempdb..#SCHEMA_GEN_RULE_TMP') IS NOT NULL 
BEGIN DROP TABLE #SCHEMA_GEN_RULE_TMP; END	
	
select fls.flsba_id ,dbTable.drools_business_rule_id INTO #SCHEMA_GEN_RULE_TMP from fls_node_br_assoc fls 
JOIN drools_business_rules_decision_table dbTable
	ON fls.business_rule_id = dbTable.drools_business_rule_id
JOIN drools_business_rule_group dGroup
	ON dGroup.drools_business_rule_group_id = dbTable.drools_business_rule_group_id
where dGroup.drools_business_rule_group_name in ('HardCode','PrintDisplayName');


--Remove HardCode & Print Display Name Rules.

delete from fls_node_br_assoc where flsba_id in (select flsba_id from #SCHEMA_GEN_RULE_TMP); 

delete from drools_business_rules_decision_table where drools_business_rule_id in (select drools_business_rule_id from #SCHEMA_GEN_RULE_TMP);



IF EXISTS (SELECT 1 FROM drools_business_rule_template WHERE drools_business_rule_template_name='PrintDisplayName')
BEGIN 
DELETE FROM drools_business_rule_template WHERE drools_business_rule_template_name='PrintDisplayName'
END
GO

--DELETE PrintDisplayName Rule Group 

IF EXISTS (SELECT 1 FROM drools_business_rule_group where drools_business_rule_group_name = 'PrintDisplayName')
BEGIN 
delete from drools_business_rule_group where drools_business_rule_group_name = 'PrintDisplayName'
END
GO
