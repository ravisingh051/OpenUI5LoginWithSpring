USE [idis-metainfo]
GO

/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
25-05-2019  Divya Jain	   ADAPT-6220 : Authorized User should be able to configure DataSet Writing Rule at File level
*/


if not exists(select 1 from [dbo].[drools_business_rule_pkg] where drools_business_rule_pkg_id = 17)
begin
SET IDENTITY_INSERT [dbo].[drools_business_rule_pkg] ON 
INSERT [dbo].[drools_business_rule_pkg] ([drools_business_rule_pkg_id], [drools_business_rule_pkg_version], [drools_br_pkg_file_type_id], [drools_br_pkg_name], [drools_br_pojo_name], [created_by], [created_date]) VALUES (17, 1, 17, N'com.alight.adapt.dataextraction.transaction.v1.models.view', N'TransactionDatasetView', N'Divya Jain', CAST(0x0000A90600000000 AS DateTime))
SET IDENTITY_INSERT [dbo].[drools_business_rule_pkg] OFF
end;
GO

if not exists(select 1 from [dbo].[drools_business_rule_pkg_file_type_assoc] where [drools_br_pkg_file_type_assoc_id] = 17)
begin
SET IDENTITY_INSERT [dbo].[drools_business_rule_pkg_file_type_assoc] ON 
INSERT [dbo].[drools_business_rule_pkg_file_type_assoc] ([drools_br_pkg_file_type_assoc_id], [drools_business_rule_pkg_id], [drools_business_rule_pkg_version], [drools_br_pkg_file_type_id], [is_active], [created_by], [created_date], [updated_by], [updated_date]) VALUES (17, 17, 1, 17, 1, N'Divya Jain', CAST(0x0000A9F700000000 AS DateTime), N'Divya Jain', CAST(0x0000A9F700000000 AS DateTime))
SET IDENTITY_INSERT [dbo].[drools_business_rule_pkg_file_type_assoc] OFF
end;
GO

