use [idis-metainfo]
go

if not exists(select 1 from adapt_env_config_info where adapt_env_id between 5 and 8)
begin
SET IDENTITY_INSERT [dbo].[adapt_env_config_info] ON 
INSERT [dbo].[adapt_env_config_info] ([adapt_env_id], [adapt_env_name], [adapt_env_abbreviation], [adapt_env_desc], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (5, N'QA2', N'QA2', N'Testing Environment 2', N'Divya Jain', getDate(), NULL, NULL)
INSERT [dbo].[adapt_env_config_info] ([adapt_env_id], [adapt_env_name], [adapt_env_abbreviation], [adapt_env_desc], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (6, N'QA3', N'QA3', N'Testing Environment 3', N'Divya Jain', getDate(), NULL, NULL)
INSERT [dbo].[adapt_env_config_info] ([adapt_env_id], [adapt_env_name], [adapt_env_abbreviation], [adapt_env_desc], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (7, N'QC2', N'QC2', N'Quality Check Environment 2', N'Divya Jain', getDate(), NULL, NULL)
INSERT [dbo].[adapt_env_config_info] ([adapt_env_id], [adapt_env_name], [adapt_env_abbreviation], [adapt_env_desc], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (8, N'QC3', N'QC3', N'Quality Check Environment 3', N'Divya Jain', getDate(), NULL, NULL)
SET IDENTITY_INSERT [dbo].[adapt_env_config_info] OFF
end;
go

