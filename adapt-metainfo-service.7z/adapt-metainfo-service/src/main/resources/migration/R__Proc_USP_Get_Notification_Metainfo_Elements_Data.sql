USE [idis-metainfo]
GO

IF OBJECT_ID('idis-metainfo..tmp_notif_table_data') IS NULL 
	BEGIN 
	Create table dbo.tmp_notif_table_data([{Analyst}] varchar(100)
           ,[{Trading_Partner}] varchar(100)
           ,[{Min_Record}] int
           ,[{Max_Record}] int
           ,[{Direction}]  varchar(100)
           ,[{File_Type}]  varchar(100)
           ,[{Website}] varchar(500)
           ,[{Assigned_Teams}] varchar(500)
           ,[{LOB}] varchar(100)
           ,[{Old_FIST_ID}] int
           ,[{Multi_Employer}]  varchar(10)
           ,[{Employer_Names}] varchar(1000)
           ,[{Client_IDs}] varchar(1000)
           ,[{Trading_Partner_Platform}]  varchar(1000)
           ,[{File_Format}]  varchar(150)
           ,[{File_Name}]  varchar(100)
           ,[{Transmission_Name}]  varchar(100)
           ,[{Threshold_Error_Format}]  varchar(100)
           ,[{Threshold_Errors}]  varchar(100)
           ,[{File_Status}]  varchar(100)
           ,[{Job_ID}] int
           ,[{File_Run_Date}] date
           ,[{ADaPT_ID}] int
           ,[{File_Version}] int
		   ,[{File_Identifier}] int
		   ,[{Profile}] varchar(50))
	END

if not exists(select 1 from information_schema.columns where table_name='tmp_notif_table_data' and column_name='{File_Identifier}')
begin
	alter table tmp_notif_table_data add [{File_Identifier}] [int] null
end;
GO
if not exists(select 1 from information_schema.columns where table_name='tmp_notif_table_data' and column_name='{Profile}')
begin
	alter table tmp_notif_table_data add [{Profile}] [varchar](50) null
end;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Notification_Metainfo_Elements_Data') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Notification_Metainfo_Elements_Data AS SELECT 1')
GO


/*
2018-08-29	Divya Jain	CC-34830: Get Notification Metainfo Elements Data By Job Id
2019-07-11  Jinesh Vora ADAPT-6816 : Notification emails are not coming Changed source of file transmission name table. Add file_transmission_info table
*/


ALTER Procedure [dbo].[USP_Get_Notification_Metainfo_Elements_Data]
	(
		@i_job_id int,
		@i_file_identifier int=null
	) 
AS
BEGIN

SET NOCOUNT ON; 

if(@i_job_id is null) 
begin
	IF exists(select 1 from tmp_notif_table_data where [{JOB_ID}] is null and [{File_Identifier}]=@i_file_identifier) 
	BEGIN DELETE from tmp_notif_table_data where [{JOB_ID}] is null and [{File_Identifier}]=@i_file_identifier; END
end
else
begin
	IF exists(select 1 from tmp_notif_table_data where [{JOB_ID}]=@i_job_id) 
	BEGIN DELETE from tmp_notif_table_data where [{JOB_ID}]=@i_job_id; END
end


INSERT INTO [dbo].[tmp_notif_table_data]
           ([{Analyst}]
           ,[{Trading_Partner}]
           ,[{Min_Record}]
           ,[{Max_Record}]
           ,[{Direction}]
           ,[{File_Type}]
           ,[{Website}]
           ,[{Assigned_Teams}]
           ,[{LOB}]
           ,[{Old_FIST_ID}]
           ,[{Multi_Employer}]
           ,[{Employer_Names}]
           ,[{Client_IDs}]
           ,[{Trading_Partner_Platform}]
           ,[{File_Format}]
           ,[{File_Name}]
           ,[{Transmission_Name}]
           ,[{Threshold_Error_Format}]
           ,[{Threshold_Errors}]
           ,[{File_Status}]
           ,[{Job_ID}]
           ,[{File_Run_Date}]
           ,[{ADaPT_ID}]
           ,[{File_Version}]
		   ,[{File_Identifier}]
		   ,[{Profile}])
select distinct
file_idis_ba_name as '{Analyst}',
STUFF((SELECT distinct ',' + (CAST(tpi.trading_partner_name AS VARCHAR)) as tps 
	from trading_partner_info tpi 
	join file_trading_partner_lob_assoc ftpla on ftpla.trading_partner_id=tpi.trading_partner_id
	where ftpla.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{Trading_Partner}',
file_min_record_count_allowed as '{Min_Record}',
file_max_record_count_allowed as '{Max_Record}',
direction as '{Direction}',
file_type_name as '{File_Type}',
STUFF((SELECT distinct ',' + (CAST(flua.file_associated_website AS VARCHAR)) as er 
	from file_linked_urls_assoc flua 
	where flua.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{Website}',
STUFF((SELECT distinct ',' + (CAST(it.idis_team_name AS VARCHAR)) as teams
	from idis_team it 
	join idis_team_file_association itfa on itfa.idis_team_id=it.idis_team_id
	where itfa.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{Assigned_Teams}',
STUFF((SELECT distinct ',' + (CAST(lob_name AS VARCHAR)) as lobs 
	from lob lob
	join file_trading_partner_lob_assoc ftpla on ftpla.lob_id=lob.lob_id
	where ftpla.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{LOB}',
old_file_id as '{Old_FIST_ID}',
case when is_multi_employer=1 then 'Yes' else 'No' end as '{Multi_Employer}',
STUFF((SELECT distinct ',' + (CAST(cea.employer_name AS VARCHAR)) as er 
	from client_employer_assoc cea 
	join file_employer_assoc fea on cea.client_employer_assoc_id=fea.client_employer_assoc_id
	where fea.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{Employer_Names}',
STUFF((SELECT distinct ',' + (CAST(cea.client_id AS VARCHAR)) as er 
	from client_employer_assoc cea 
	join file_employer_assoc fea on cea.client_employer_assoc_id=fea.client_employer_assoc_id
	where fea.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as '{Client_IDs}',
trading_partner_platform_name  as '{Trading_Partner_Platform}',
file_format_name as '{File_Format}',
file_name as '{File_Name}',
case when job_transmission_connection_id is null then cast(fmi.file_id as varchar(10))+'.txt' else fti.transmission_name end as '{Transmission_Name}',
file_processing_error_threshold_format as '{Threshold_Error_Format}',
file_processing_error_threshold_count as '{Threshold_Errors}',
file_status as '{File_Status}',
case when @i_job_id is null then NULL else job_id end as '{Job_ID}',
case when @i_job_id is null then NULL else job_actual_start_datetime end   as '{File_Run_Date}',
fmi.file_id as '{ADaPT_ID}',
fmi.file_version as '{File_Version}',
fmi.record_id as '{File_Identifier}',
pl.profile_name as '{Profile}'
from  file_meta_info fmi 
join file_type_meta_info ftmi on fmi.file_type_id=ftmi.file_type_id
join file_format_supported fms on fmi.file_format_supported_id=fms.file_format_supported_id
left join job_details jd on fmi.record_id=jd.file_identifier
left join file_processing_schedule fps on jd.file_processing_schedule_id = fps.file_processing_schedule_id
left join profiles pl on pl.profile_id = fps.profile_id
left join trading_partner_platform_info tppi on fmi.trading_partner_platform_id=tppi.trading_partner_platform_id
left join file_transmission_info fti on fti.file_transmission_connection_id = jd.job_transmission_connection_id
where case when @i_job_id is null then fmi.record_id else jd.job_id end =
	  case when @i_job_id is null then @i_file_identifier else @i_job_id end

Declare @TableName  [nvarchar](128)
Declare @ExecStr    nvarchar(max)
Declare @Where      nvarchar(max)
Set @TableName = 'tmp_notif_table_data'
--Enter Filtering If Exists
Set @Where = ''

IF OBJECT_ID('tempdb..#tmp_Col2Row') IS NOT NULL 
	BEGIN DROP TABLE #tmp_Col2Row; END
--Drop Table 

Create Table #tmp_Col2Row
(Field_Name nvarchar(128) Not Null
,Field_Value nvarchar(max) Null
)

Set @ExecStr = N' Insert Into #tmp_Col2Row (Field_Name , Field_Value) '
/*
/Select @ExecStr += (Select N'Select '''+C.name+''' ,Convert(nvarchar(max), case when '+quotename(C.name)+' is not NULL then '+quotename(C.name)+' else '' '' end ' + ') From ' + quotename(@TableName)+
		' where [{JOB_ID}]='+CAST(@i_job_id AS VARCHAR)+@Where+Char(10)+' Union All '
*/
Select @ExecStr += (Select N'Select '''+C.name+''' ,Convert(nvarchar(max),'+quotename(C.name) + ') From ' + @TableName
				 +case when @i_job_id is null then ' where [{JOB_ID}] is NULL and [{File_Identifier}] ='+CAST(@i_file_identifier AS VARCHAR)
					else ' where [{JOB_ID}]='+CAST(@i_job_id AS VARCHAR) end
				 +@Where+Char(10)+' Union All '
         from sys.columns as C
         where (C.object_id = object_id(@TableName)) 
         for xml path(''))
Select @ExecStr = Left(@ExecStr,Len(@ExecStr)-Len(' Union All '))
Print @ExecStr

Exec (@ExecStr)


Select * From #tmp_Col2Row


END
Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Notification_Metainfo_Elements_Data TO exec_proc
GO

