USE [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Rules_Master') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Rules_Master AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_Rules_Master]
	(
              @i_mft_id int,
              @i_mft_version int
       )
AS
BEGIN

SET NOCOUNT ON;
declare @masterFileId int;
declare @masterFileVersion int;

set @masterFileId=@i_mft_id;
set @masterFileVersion=@i_mft_version;

SELECT
DROOLS.drools_business_rule_id,
DROOLS.drools_business_rule_version,
DROOLS.drools_business_rule_drl_file_content,
DROOLS.is_current
FROM drools_business_rules_decision_table AS DROOLS
INNER JOIN drools_business_rule_group as dbrg ON dbrg.[drools_business_rule_group_id] = DROOLS.drools_business_rule_group_id
INNER JOIN master_file_template_attr_br_assoc AS MBR ON DROOLS.drools_business_rule_id=MBR.business_rule_id 
INNER JOIN master_file_template_attribute_association AS MFTAA ON MBR.mftaa_id = MFTAA.mftaa_id
WHERE MFTAA.master_file_template_id = @masterFileId AND MFTAA.master_file_template_version = @masterFileVersion


END 

GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Rules_Master TO exec_proc
GO

