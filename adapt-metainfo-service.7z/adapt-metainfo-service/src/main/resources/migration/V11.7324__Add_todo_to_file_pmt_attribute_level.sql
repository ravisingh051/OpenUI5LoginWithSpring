use [idis-metainfo]

---- Add column to_do to file and pmt attribute rows  -----------

if not exists(select 1 from information_schema.columns where table_name='file_attribute_association' and column_name='to_do')
BEGIN
ALTER TABLE [file_attribute_association] add to_do [bit] not null CONSTRAINT DF_file_attribute_association_to_do DEFAULT(0)
END;
GO

if not exists(select 1 from information_schema.columns where table_name='child_file_template_attribute_association' and column_name='to_do')
BEGIN
ALTER TABLE [child_file_template_attribute_association] add to_do [bit] not null CONSTRAINT DF_cft_attribute_association_to_do DEFAULT(0)
END;
GO

if exists(
select top 1 cftaa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join child_file_template_attr_br_assoc cftaba
 on dbrdt.drools_business_rule_id=cftaba.business_rule_id where is_draft is not null and is_draft=1)
begin
	 update cftaa set cftaa.to_do=a.to_do from child_file_template_attribute_association cftaa join
	(select distinct cftaa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join child_file_template_attr_br_assoc cftaba
	on dbrdt.drools_business_rule_id=cftaba.business_rule_id where is_draft is not null and is_draft=1)a
	on cftaa.cftaa_id=a.cftaa_id
end;
go

if exists(
select top 1 faa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join file_attr_br_assoc faba
 on dbrdt.drools_business_rule_id=faba.business_rule_id where is_draft is not null and is_draft=1)
begin
	 update faa set faa.to_do=a.to_do from file_attribute_association faa join
	(select distinct faa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join file_attr_br_assoc faba
	on dbrdt.drools_business_rule_id=faba.business_rule_id where is_draft is not null and is_draft=1)a
	on faa.faa_id=a.faa_id
end;
go

if exists(
select top 1 cftaa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join child_file_template_attr_br_assoc cftaba
 on dbrdt.drools_business_rule_id=cftaba.business_rule_id where is_draft is not null and is_draft=1)
begin
	 delete from child_file_template_attr_br_assoc where business_rule_id in (select cftaba.business_rule_id from drools_business_rules_decision_table dbrdt 
	 join child_file_template_attr_br_assoc cftaba on dbrdt.drools_business_rule_id=cftaba.business_rule_id where is_draft is not null and is_draft=1)
end;
go

if exists(
select top 1 faa_id,is_draft as to_do from drools_business_rules_decision_table dbrdt join file_attr_br_assoc faba
 on dbrdt.drools_business_rule_id=faba.business_rule_id where is_draft is not null and is_draft=1)
begin
	 delete from file_attr_br_assoc where business_rule_id in (select faba.business_rule_id from drools_business_rules_decision_table dbrdt 
	 join file_attr_br_assoc faba on dbrdt.drools_business_rule_id=faba.business_rule_id where is_draft is not null and is_draft=1)
end;
go

if exists(select 1 from information_schema.columns where table_name='drools_business_rules_decision_table' and column_name='to_do')
BEGIN
ALTER TABLE [drools_business_rules_decision_table] drop column is_draft
END;
GO

