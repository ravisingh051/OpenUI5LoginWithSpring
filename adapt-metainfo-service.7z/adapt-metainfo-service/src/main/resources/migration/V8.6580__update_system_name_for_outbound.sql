use [idis-metainfo]
GO

/*
Filename:  V8.6580__update_system_name_for_outbound.sql

Update Log
Date         Author            	Description
----------   ----------------   --------------------------------------------------------------------------------------------
2019-07-04   Divya Jain  		ADAPT-6580 : Create the milestone 9 (Send) skeleton and create the switches using factory concept
*/



if not exists(select 1 from file_type_meta_info where file_type_id in (2,17) and system_name='OUTBOUND_CORE_T')
begin
	update file_type_meta_info set system_name='OUTBOUND_CORE_T' where file_type_id in (2,17)
end;
GO

