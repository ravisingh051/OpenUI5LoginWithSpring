USE [idis-metainfo]

/*
--Update Log
--Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
--2019-06-29	Jinesh Vora		ADAPT-2835: Stepping Through a Row of Data - For outbound

-- Table Used 
-- child_file_template_attribute_association
-- file_attribute_association

*/
-- 1
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='child_file_template_attribute_association' and column_name ='test_data' 
)
BEGIN
ALTER TABLE child_file_template_attribute_association Add test_data varchar(1000);
END;

GO

-- 2 
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='file_attribute_association' and column_name ='test_data' 
)
BEGIN
ALTER TABLE file_attribute_association Add test_data varchar(1000);
END;

GO
