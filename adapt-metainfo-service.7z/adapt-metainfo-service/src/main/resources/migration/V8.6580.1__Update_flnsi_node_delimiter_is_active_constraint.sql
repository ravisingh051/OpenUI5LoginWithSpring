USE [idis-metainfo]
GO

/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-29   Divya Jain			ADAPT-6580 : Add default as active for the is_active field in Delimiter mapping

*/

-- Add is_active default Constraint DF_fls_node_delimiter_info_is_active
IF object_id('DF_fls_node_delimiter_info_is_active', 'D') IS NULL 
BEGIN
ALTER TABLE [dbo].[fls_node_delimiter_info] ADD CONSTRAINT [DF_fls_node_delimiter_info_is_active] DEFAULT (1) FOR is_active;
END;
GO

if exists(select 1 from [fls_node_delimiter_info] where is_active=0)
begin
update [fls_node_delimiter_info] set is_active=1 where is_active=0
end;
go

if exists(select 1 from information_schema.columns where table_name='fls_node_delimiter_info' and column_name='is_active' and is_nullable='YES')
begin
alter table [fls_node_delimiter_info] alter column is_active bit not null
end;
go
