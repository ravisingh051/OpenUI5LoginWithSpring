USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[Proc_USP_File_Template_Deletion]    Script Date: 09/17/2018 11:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Richa Ashara
-- Create date:	09/17/2018
-- Description:	Delete File template with given version
-- =============================================
/*
update log 
    Date			Author		  Details
------------	-----------------	 ----------------------------------------------------------------------------------------
2018-12-05	 Richa Ashara			ADAPT-250-user-should-be-able-to-update-delete-the-cloned-section-at-file-level
2018-12-18   Richa Ashara			ADAPT-642-User should be able to configure connection/key with File .
2018-12-19  Richa Ashara			ADAPT-291-User should be able to configure connection/key with File .
2018-01-04  Richa Ashara			ADAPT-1399-getting-error-message-while-accepting-new-pmt-changes (bug fix)
2019-10-14	Snehal Patel			ADAPT-7998 : Remove enumerated values and print display name.
2019-11-21	Jinesh Vora				ADAPT-8515 : System allowed discard draft even after job run for draft version
2019-11-26	Jinesh vora				ADAPT-6875
2020-01-13	Nilesh Jariya			ADAPT-8948: Remove advanced selection criteria
2020-03-03	Ravi Singh				ADPT-76: File Setup - Discard Draft functionality is not working
*/
IF OBJECT_ID('dbo.USP_File_Template_Deletion') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_File_Template_Deletion AS SELECT 1')
GO
ALTER PROCEDURE [dbo].[USP_File_Template_Deletion]
	-- Add the parameters for the stored procedure here
	 @iFile_id int,
	 @iFile_version int,
	 @file_type_id int
AS
BEGIN

BEGIN TRY
	BEGIN TRANSACTION  
	
    DECLARE @file_identifier_old INT;
   -- DECLARE @file_type_id INT;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT @file_identifier_old=record_id from [dbo].[file_meta_info] where [file_id] = @iFile_id and [file_version]=@iFile_version
 
    DELETE FROM [dbo].[lookup_table_file_association]  where lookup_table_id in (select lookup_table_id from  [dbo].[lookup_table_meta_info]  where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id and lookup_table_version=@iFile_version)

    DELETE FROM [dbo].[lookup_table_composite_key_mapping]   where lookup_table_id in (select lookup_table_id from  [dbo].[lookup_table_meta_info]  where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id and lookup_table_version=@iFile_version)

    DELETE FROM [dbo].[lookup_table_details]  where lookup_table_id in (select lookup_table_id from  [dbo].[lookup_table_meta_info]  where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id and lookup_table_version=@iFile_version)

    DELETE FROM  [dbo].[lookup_table_meta_info] where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id --and lookup_table_version=@iFile_version


    select br.business_rule_id,br.faa_id into #rules FROM [dbo].[file_attr_br_assoc] br join [file_attribute_association] attr on br.faa_id=attr.faa_id where attr.file_identifier =@file_identifier_old

    DELETE  FROM [dbo].[file_attr_br_assoc] where faa_id in(select faa_id FROM #rules)
	
    DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #rules)
	
	
	select flsni.flsni_id into #nodes from file_layout_schema_node_info flsni 
				where [file_identifier] = @file_identifier_old;
	
	select business_rule_id  into #node_rules from fls_node_br_assoc where flsni_id in (select flsni_id from #nodes)
	
	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #node_rules)
	
	DELETE FROM fls_node_br_assoc where flsni_id in (select flsni_id from #nodes)
	
	DELETE FROM fls_node_dm_element_assoc where flsni_id in (select flsni_id from #nodes)
	
	DELETE FROM file_layout_schema_node_assoc where flsni_id in (select flsni_id from #nodes)
	
	DELETE FROM file_layout_schema_node_info where flsni_id in (select flsni_id from #nodes)
	
	select business_rule_id  into #node_sp_rules from file_special_mapping_attr_br_assoc where file_identifier=@file_identifier_old
	
	DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select business_rule_id FROM #node_sp_rules)
	
	DELETE  FROM [file_special_mapping_attr_br_assoc]  where file_identifier=@file_identifier_old

	DELETE FROM fls_node_delimiter_info where file_identifier=@file_identifier_old

	select fepi.fepi_id into #ext from file_extraction_parameters_info fepi where [file_identifier] = @file_identifier_old;
	
	DELETE FROM file_linked_urls_assoc where file_identifier=@file_identifier_old
	
	--select fepba_br_id  into #ext_rules from file_ext_param_br_assoc fepba where fepba_fepi_id in (select fepi_id from #ext)

	--DELETE FROM file_ext_param_br_assoc where fepba_fepi_id in (select fepi_id from #ext);
	
	--DELETE  FROM [drools_business_rules_decision_table]  where drools_business_rule_id in (select fepba_br_id FROM #ext_rules)
	
	DELETE FROM file_extraction_parameters_assoc where fepa_fepi_id in (select fepi_id from #ext);

	DELETE FROM file_extraction_parameters_info where fepi_id in (select fepi_id from #ext);
	
	DELETE FROM [dbo].[file_secondary_mapping_attr_assoc] where [fsmaa_file_identifier] = @file_identifier_old
	
	DELETE FROM [dbo].[file_attribute_association] where [file_identifier] = @file_identifier_old

    DELETE FROM [dbo].[file_section_association] where [file_identifier] = @file_identifier_old

	DELETE FROM [dbo].[file_clone_info] where file_identifier = @file_identifier_old 

    
	DELETE FROM [dbo].[file_notification_template_contact_assoc] WHERE [file_identifier] = @file_identifier_old
   
	--DELETE FROM [dbo].[enrichment_api_mapped_obj_file_assoc] WHERE [file_identifier] = @file_identifier_old and is_active=1
   
	DELETE FROM [dbo].[idis_team_file_association] WHERE [file_identifier] = @file_identifier_old
   
	DELETE FROM [dbo].[file_trading_partner_lob_assoc] WHERE [file_identifier] = @file_identifier_old
   
	DELETE  FROM [file_employer_assoc] WHERE [file_identifier] = @file_identifier_old
	
	DELETE FROM [dbo].[file_transmission_info] where file_identifier = @file_identifier_old

	DELETE  FROM [dbo].[file_meta_info] WHERE [file_id] = @iFile_id AND [file_version] = @iFile_version

	-- Added 
	if exists (select 'X' from job_details where file_identifier =  @file_identifier_old and job_status <> 'SCHEDULED') -- @iFile_version
	BEGIN
		ROLLBACK;
	END;

	COMMIT TRANSACTION;
END TRY

BEGIN CATCH
	
	ROLLBACK;
	THROW

END CATCH


END
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.[USP_File_Template_Deletion] TO exec_proc
GO
