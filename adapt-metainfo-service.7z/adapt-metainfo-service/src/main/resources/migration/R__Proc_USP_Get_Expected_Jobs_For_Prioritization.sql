USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Get_Expected_Jobs_For_Prioritization]    Script Date: 2/23/2018 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.USP_Get_Expected_Jobs_For_Prioritization') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Expected_Jobs_For_Prioritization AS SELECT 1')
GO

ALTER Procedure [dbo].[USP_Get_Expected_Jobs_For_Prioritization]
	(
		@i_status varchar(50),
		@i_date date
	) 
AS
BEGIN

SET NOCOUNT ON; 

SELECT 
job_id as job_id,
fmi.is_SLA_mapped as is_sla_mapped,
fmi.file_id as file_id,
STUFF((SELECT distinct ',' + CAST(cea.employer_id AS VARCHAR) 
	from client_employer_assoc cea 
	join file_employer_assoc fea on cea.client_employer_assoc_id=fea.client_employer_assoc_id
	where fea.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as employer_ids,
ftpla.trading_partner_id as trading_partner_id,
fmi.file_type_id as file_type_id,
ftmi.direction,
jd.job_expected_start_datetime as expected_start_date,
jd.explicit_high_prioritization,
jd.explicit_low_prioritization,
jd.explicit_prioritization_date
FROM job_details jd
JOIN file_meta_info fmi ON fmi.record_id=jd.file_identifier
JOIN file_type_meta_info ftmi ON ftmi.file_type_id=fmi.file_type_id
JOIN file_trading_partner_lob_assoc ftpla ON ftpla.file_identifier=fmi.record_id
WHERE job_status=@i_status and  job_expected_start_datetime <= @i_date
AND jd.job_soft_deleted = 0
ORDER BY jd.job_creation_datetime;

END

Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Expected_Jobs_For_Prioritization TO exec_proc
GO

