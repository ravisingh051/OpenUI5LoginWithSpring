use [idis-metainfo]
GO

/*
Filename:  V7.6451.2__add_permission_approve_pmt_role_5.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-02   Shipra Maheshwari  ADAPT-6451 : Level 5 users should be able to approve/reject promotions(migrations)
*/

if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id =7 and action_id in (44,54,87) and [role_action_assoc_id] in (457,458,459))
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (457,7,44,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (458,7,54,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (459,7,87,'shipra maheshwari',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF 
END

if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id =8 and action_id in (44,87) and [role_action_assoc_id] in (460,461))
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (460,8,44,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (461,8,87,'shipra maheshwari',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF 
END

if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id =9 and action_id in (51,52,64,66,67,72,73) and [role_action_assoc_id] between 462 AND 468)
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (462,9,51,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (463,9,52,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (464,9,64,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (465,9,66,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (466,9,67,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (467,9,72,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (468,9,73,'shipra maheshwari',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF 
END

if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id =10 and action_id in (92,93) and [role_action_assoc_id] in (469,470))
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (469,10,92,'shipra maheshwari',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (470,10,93,'shipra maheshwari',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF 
END
GO
