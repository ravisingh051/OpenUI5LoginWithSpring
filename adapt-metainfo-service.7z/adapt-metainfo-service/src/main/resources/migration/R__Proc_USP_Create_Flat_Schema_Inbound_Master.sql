use [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Create_Flat_Schema_Inbound_Master]    Script Date: 3/14/2019 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Create_Flat_Schema_Inbound_Master') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Create_Flat_Schema_Inbound_Master AS SELECT 1')
GO
/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
31-05-2019  Divya Jain	   ADAPT-5862 : Populate inbound schema for new/edited Master's
*/

ALTER Procedure [dbo].[USP_Create_Flat_Schema_Inbound_Master]
	(
		@imaster_record_id INT,
		@oError_code INT OUT
	) 
AS

BEGIN

SET NOCOUNT ON; 

declare @mftsa_id int;
declare @parent_mtlsni_id int;
declare @template_id int;
declare @created_by varchar(50);
declare @created_date_time datetime;

if EXISTS(SELECT 1 FROM master_template_layout_schema_node_info WHERE master_file_template_record_id = @imaster_record_id)
	BEGIN
		 BEGIN TRANSACTION T1;
		 BEGIN TRY
			 DELETE FROM mtls_node_dm_element_assoc Where mtlsni_id in (SELECT mtlsni_id FROM master_template_layout_schema_node_info WHERE master_file_template_record_id = @imaster_record_id)
			 DELETE FROM master_template_layout_schema_node_assoc Where mtlsni_id in (SELECT mtlsni_id FROM master_template_layout_schema_node_info WHERE master_file_template_record_id = @imaster_record_id)
			 DELETE FROM master_template_layout_schema_node_info WHERE master_file_template_record_id = @imaster_record_id
			 COMMIT TRANSACTION T1;
			 SET @oError_code = 0;
			 print 'Existing Master data deleted successfully from flat schema...'
		 END TRY
		 BEGIN CATCH
			ROLLBACK TRANSACTION T1;
			SET @oError_code = -1;
			print 'Error while deleting existing Master data from flat schema...'
		END CATCH 
	END;
	
	BEGIN TRANSACTION T2
	BEGIN TRY 

	DECLARE cur CURSOR LOCAL FOR SELECT [mftsa_id],[template_section_id] FROM [dbo].[master_file_template_section_assoc] where 
	[master_file_template_record_id]=@imaster_record_id order by sequence asc;

	declare @rowPosition int=1;
			OPEN cur;

			FETCH NEXT FROM cur INTO @mftsa_id,@template_id;
			WHILE @@FETCH_STATUS = 0
				BEGIN
					INSERT INTO [dbo].[master_template_layout_schema_node_info] ([master_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
				[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
				[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[mapped_column_order]) 
				(select @imaster_record_id,'Section',section_display_name,1,1,1,@rowPosition,@rowPosition,NULL,1,NULL,section_name,@template_id,
				template_compliant_section_short_name,1,mftsa.created_by,mftsa.created_date_time,mftsa.sequence from master_file_template_section_assoc mftsa
				join template_sections ts on mftsa.template_section_id=ts.template_section_id where mftsa_id=@mftsa_id)

				select @parent_mtlsni_id=mtlsni_id,@created_by=created_by,@created_date_time=created_date_time
				from master_template_layout_schema_node_info where master_file_template_record_id=@imaster_record_id and
				mapped_template_section_id=@template_id

				declare @attrFlag bit=0;
				select top 1 @attrFlag=1 from master_file_template_attribute_association where mftsa_id=@mftsa_id 

				INSERT INTO [dbo].[master_template_layout_schema_node_assoc] ([mtlsni_id],[parent_mtlsni_id],[node_has_children],[created_by],[created_date_time]) 
				values(@parent_mtlsni_id,NULL,@attrFlag,@created_by,@created_date_time)

					if exists(select 1 from master_file_template_attribute_association where mftsa_id=@mftsa_id )
					begin
					--print 'exists'
					--end

					declare @mftaa_id int;
				declare @attribute_name varchar(max);
				declare @mtlsni_id int;
				DECLARE attrCur CURSOR LOCAL FOR SELECT [mftaa_id],
				case when application_compliant_attribute_name is not null then application_compliant_attribute_name else attribute_name end
				FROM [dbo].[master_file_template_attribute_association] mftaa join attribute_dictionary ad on mftaa.attribute_id=ad.attribute_id where 
				[master_file_template_record_id]=@imaster_record_id and mftsa_id=@mftsa_id
				order by attribute_row_position asc;
				OPEN attrCur;

					FETCH NEXT FROM attrCur INTO @mftaa_id,@attribute_name;
					WHILE @@FETCH_STATUS = 0
						BEGIN
					
						INSERT INTO [dbo].[master_template_layout_schema_node_info] ([master_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
						[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
						[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[node_max_size],[mapped_column_order]) 
						(select  @imaster_record_id,'Element',@attribute_name,
						adt.attribute_data_type_id,1,1,@rowPosition,@rowPosition,NULL,mftaa.is_mandatory,NULL,'Data Element And/Or Enumerated Values',
						NULL,mftsa.template_compliant_section_short_name,1,mftaa.created_by,mftaa.created_date_time,max_size_allowed,mftaa.attribute_row_position
						from [master_file_template_attribute_association] mftaa join attribute_dictionary ad on ad.attribute_id=mftaa.attribute_id
						join master_file_template_section_assoc mftsa on mftaa.mftsa_id=mftsa.mftsa_id
						left join attribute_data_types adt on adt.attribute_data_type_name=mftaa.data_type
						where mftaa_id=@mftaa_id)

						select @mtlsni_id=mtlsni_id,@created_by=created_by,@created_date_time=created_date_time 
						from master_template_layout_schema_node_info where master_file_template_record_id=@imaster_record_id and
						node_display_name=@attribute_name and node_row_position=@rowPosition
					
						INSERT INTO [dbo].[master_template_layout_schema_node_assoc] ([mtlsni_id],[parent_mtlsni_id],[node_has_children],[created_by],[created_date_time]) 
						values(@mtlsni_id,@parent_mtlsni_id,0,@created_by,@created_date_time)

						INSERT INTO [dbo].[mtls_node_dm_element_assoc]([mtlsni_id],[mftaa_id],[is_active],[created_by],[created_date_time]) 
						select @mtlsni_id,@mftaa_id,1,@created_by,@created_date_time from [master_file_template_attribute_association]
						where mftaa_id=@mftaa_id

--						select * from [master_file_template_attribute_association] where mftaa_id=@mftaa_id

						FETCH NEXT FROM attrCur INTO @mftaa_id,@attribute_name;
						END
					CLOSE attrCur 
					DEALLOCATE attrCur  
				END
				FETCH NEXT FROM cur INTO @mftsa_id,@template_id;
				select @rowPosition=@rowPosition+1;
			END
		CLOSE cur    
		DEALLOCATE cur
			COMMIT TRANSACTION T2;
			SET @oError_code = 0;
			print 'Master inserted successfully into flat schema...'
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION T2;
			SET @oError_code = -2;
			print 'Error while inserting Master data to flat schema...'
		END CATCH 

END;
GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Create_Flat_Schema_Inbound_Master TO exec_proc
GO
