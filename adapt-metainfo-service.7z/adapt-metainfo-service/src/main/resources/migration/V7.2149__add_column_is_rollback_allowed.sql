USE [idis-metainfo];

/*
Filename:  V8.2149__add_column_is_rollback_allowed.sql

Update Log

Date         Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-06-20  Disha Shah 		ADAPT-2194 : Ability to negate a file
*/

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'file_type_meta_info' and
column_name = 'is_rollback_allowed')
begin
    alter table file_type_meta_info add is_rollback_allowed bit not null constraint DF_file_type_meta_info_is_rollback_allowed default(0)
end
GO

if not exists(select 1 from sys.default_constraints where name like 'DF_file_type_meta_info_is_rollback_allowed')
begin
	alter table file_type_meta_info add constraint DF_file_type_meta_info_is_rollback_allowed default(0) for is_rollback_allowed;
end
go

if not exists(select 1 from file_type_meta_info where is_rollback_allowed = 1 and file_type_id in (5,6,7,8,9))
begin
	update file_type_meta_info set is_rollback_allowed=1 where file_type_id in (5,6,7,8,9);
end
GO

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'job_details' and
column_name = 'rollback_comments')
begin
    alter table job_details add rollback_comments varchar(1000) null
end
GO

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'job_details' and
column_name = 'rollback_initiated_by')
begin
    alter table job_details add rollback_initiated_by varchar(50) null
end
GO

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'job_details' and
column_name = 'rollback_initiated_date')
begin
    alter table job_details add rollback_initiated_date datetime null
end
GO

