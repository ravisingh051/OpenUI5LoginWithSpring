use [idis-metainfo]
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Richa Ashara
-- Create date:  10/19/2018 12:23:24 PM 
-- Description:	This Store Procedure clones attributes in file.
-- =============================================

/*
update log 
    Date			Author		  Details
------------	-----------------	 --------------------------------------------------------------------
2018-11-23	 Richa Ashara			ADAPT-250 - Insert query addded for table file_clone_info.
2019-08-27	 Divya Jain             ADAPT-7324: Removed is_draft column from drools_business_rules_decision_table and added to_do column in file_attribute_association.
2019-09-23   Nilesh Jariya          ADAPT-7554: PMT&File: Clone record does not display rule order comments
2019-09-30	 Divya Jain				ADAPT-7708: API - Remove the PMT APIs
*/


IF OBJECT_ID('dbo.USP_File_Attribute_Cloning') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_File_Attribute_Cloning AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_File_Attribute_Cloning]
	-- Add the parameters for the stored procedure here
	@ifile_identifier INT,
	@inum_of_clone INT,
	@icreated_by varchar(50),
	@oError_code int OUTPUT
				
AS
BEGIN

    Declare @counter int;
    Declare @start_counter int;
    Declare @faa_id int;
    Declare @attribute_id int;
    Declare @NewAttrId int;
    Declare @temp_count int;
	Declare @detailSectionName varchar(50);
    SET NOCOUNT ON;

    
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int, clone_num int)

	IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	CREATE TABLE #TEMP_DBRDT_OLDNEWKEY ( new_id int, old_id int ,rule_version int, clone_num int)

	-- check clone is allowed or not.
      if not exists(select 1 from [dbo].[file_meta_info] fmi INNER join [dbo].[file_type_meta_info] ftmi on
      fmi.file_type_id = ftmi.file_type_id   where is_clone_allowed = 1  and fmi.record_id = @ifile_identifier)
	 BEGIN
		set @oError_code=-2;
        GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
      END 

	 BEGIN TRANSACTION;
	 select @start_counter = (max(clone_num) +1) from file_attribute_association WHERE file_identifier =  @ifile_identifier;
	 
	 select @detailSectionName= 
		case when section_display_name is NULL then ts.section_name else section_display_name end  from file_section_association fsa 
		join template_sections ts on fsa.template_section_id=ts.template_section_id where file_compliant_section_short_name='D' and 
		file_identifier=@ifile_identifier 

	 print '@start_counter ::: ' +  CAST (@start_counter as VARCHAR)
	   --- get record count for rules ----

	   DECLARE @RULES_COUNT INT
       BEGIN TRY
		  SET @RULES_COUNT = (select count(1) from file_attribute_association faa
		  join  file_section_association fsa on fsa.fsa_id = faa.fsa_id
		  join file_attr_br_assoc faba on faa.faa_id=faba.faa_id
		  join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=faba.business_rule_id
		  where faa.[file_identifier] = @ifile_identifier and faa.clone_num = 0 and fsa.file_compliant_section_short_name = 'D'
		  )
	
		  if @RULES_COUNT>0
		  BEGIN
		  --select @RULES_COUNT
		  --Duplicating the Business Rules Association rows with same id and new versions
		  --- reseed the identity ----
		  DECLARE @NEW_DBRDT_RESEED INT
		  DECLARE @CURRENT_DBRDT_RESEED INT
		  DECLARE @NEW_DBRDT_INDENT INT
		    SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
			 SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+(@RULES_COUNT * @inum_of_clone) +5
			 DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
			 SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2
		   END;
		  
		  print ' identity reseed ....'
    	    SET @counter = @start_counter ;
	 
	   while(@counter <  (@inum_of_clone + @start_counter))
	   BEGIN
	   	  select   @temp_count = count(1) from #TEMP_DBRDT_OLDNEWKEY
		  if(@temp_count  is null or @temp_count < 0)
		  BEGIN
			 SET @temp_count = 0
		  end
		  
		  if @RULES_COUNT>0
		  BEGIN
			 INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version,clone_num)
			 (select @NEW_DBRDT_INDENT+@temp_count+Row_number() Over(Order by drools_business_rule_id)
			 , drools_business_rule_id,drools_business_rule_version,@counter from file_attribute_association faa
			 join  file_section_association fsa on fsa.fsa_id = faa.fsa_id
			 join file_attr_br_assoc faba on faa.faa_id=faba.faa_id join drools_business_rules_decision_table dbrdt 
			 on dbrdt.drools_business_rule_id=faba.business_rule_id and faba.business_rule_version = dbrdt.drools_business_rule_version
			 where faa.[file_identifier] =@ifile_identifier and faa.clone_num = 0 and fsa.file_compliant_section_short_name = 'D')
	
	   			--  select * from #TEMP_DBRDT_OLDNEWKEY
			 
			 SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
			 insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
			 drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
			 drools_business_rule_ui_json_text,created_by,created_date)
			 (select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
			 rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
			 drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY 
			 on drools_business_rule_id=old_id and clone_num = @counter)
			 SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF
		  END
	
	   DECLARE attrcur CURSOR LOCAL FOR SELECT [faa_id], [attribute_id] FROM [dbo].[file_attribute_association] faa  join  file_section_association fsa on fsa.fsa_id = faa.fsa_id 
					where faa.[file_identifier] = @ifile_identifier and clone_num=0 and fsa.file_compliant_section_short_name = 'D' order by faa.faa_id asc;
	   OPEN attrcur;
	   FETCH NEXT FROM attrcur INTO @faa_id, @attribute_id;
	   WHILE @@FETCH_STATUS = 0
	   BEGIN
		  INSERT INTO [dbo].[file_attribute_association]
								    ( [fsa_id]
									   ,[attribute_id]
									   ,[data_type]
									   ,[is_mandatory]
									   ,[attribute_size]
									   ,[attribute_row_position]
									   ,[attribute_start_position]
									   ,[attribute_end_position]
									   ,[is_inherited]
									   ,[file_identifier]
									   ,[created_by]
									   ,[created_date_time]
									   ,[updated_by]
									   ,[updated_date_time]
									   ,[file_format_compliant_attribute_name]
									   ,[clone_num]
									   ,[to_do])
							 (SELECT  [fsa_id]
								    ,[attribute_id]
								    ,[data_type]
								    ,[is_mandatory]
								    ,[attribute_size]
								    ,[attribute_row_position]
								    ,[attribute_start_position]
								    ,[attribute_end_position]
								    ,[is_inherited]
								    ,[file_identifier]
								    ,@iCreated_by
								    ,getDate()
								    ,NULL
								    ,NULL
								    ,[file_format_compliant_attribute_name]
								    , @counter 
									,[to_do] FROM [dbo].[file_attribute_association] WHERE
								    faa_id = @faa_id )

						  SELECT @NewAttrId=[faa_id] FROM dbo.file_attribute_association faa  join  file_section_association fsa on fsa.fsa_id = faa.fsa_id  WHERE  faa.[file_identifier] = @ifile_identifier 
									and clone_num = @counter and attribute_id = @attribute_id and fsa.file_compliant_section_short_name = 'D' 
						 
						  insert into #TEMP_OLDNEWKEY(new_id,old_id, clone_num) values(@NewAttrId,@faa_id, @counter)			
   
   						  INSERT INTO [idis-metainfo].[dbo].[file_attr_br_assoc]([faa_id],[business_rule_id],[business_rule_version],[rule_execution_sequence]
						  ,[created_by],[created_date_time],[rule_execution_comment])
						  (SELECT @NewAttrId,C.new_id,C.rule_version,D.rule_execution_sequence,@iCreated_by,GETDATE(),D.rule_execution_comment
						  FROM [idis-metainfo].[dbo].[file_attr_br_assoc] D INNER JOIN #TEMP_DBRDT_OLDNEWKEY C 
						  ON D.business_rule_id=C.old_id where D.faa_id = @faa_id and C.clone_num = @counter)	

		  FETCH NEXT FROM attrcur INTO @faa_id, @attribute_id;
		  END
		  CLOSE attrcur    
	     DEALLOCATE attrcur
		
	    insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,is_active,created_by,created_date_time)
	   (select ltfa.lookup_table_id, ltfa.lookup_table_version ,temp.new_id,mftaa_id,1,@iCreated_by,getDate()
	   from lookup_table_file_association ltfa  join #TEMP_OLDNEWKEY temp on faa_id=temp.old_id
	   join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
	   where associated_file_level='F' and associated_file_level_id=@ifile_identifier and is_active=1  and temp.clone_num = @counter)

	   INSERT INTO [dbo].[file_clone_info]
           ([file_identifier]
           ,[clone_num]
           ,[clone_name]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  
	   values(@ifile_identifier, @counter, CONCAT ('Clone ', CAST( @counter AS VARCHAR),' of ',@detailSectionName), @icreated_by, GETDATE(), NULL,NULL)

	   SET @counter = @counter + 1;
    END

    
	COMMIT TRANSACTION;
		SET @oError_code = 0;
	END TRY
	
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
	END CATCH 

	IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END

		END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @oError_code = -2)
			    BEGIN
			    print 'Error: attribute is not allowed for this file type ...'
			    RETURN -2
	    END
	   ELSE IF ( @oError_code <> 0)
		  BEGIN
		  print 'Error: Some Error occured while cloning attributes...'
		  RETURN -1
	   END
	   ELSE
		  BEGIN
		  print 'File attributes cloned Successfully... '
		  SET @oError_code=0
		  RETURN 0
	   END 
   
END;
GO
-- ============================================================================ 
 --Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_File_Attribute_Cloning
	TO exec_proc;
GO

