USE [idis-metainfo]
GO
/****** Object:  Table [dbo].[adapt_env_config_info]    Script Date: 4/29/2019 3:58:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_env_config_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_env_config_info](
	[adapt_env_id] [int] IDENTITY(1,1) NOT NULL,
	[adapt_env_name] [varchar](20) NOT NULL,
	[adapt_env_abbreviation] [varchar](5) NOT NULL,
	[adapt_env_desc] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL
 CONSTRAINT [PK_adapt_env_id] PRIMARY KEY CLUSTERED 
(
	[adapt_env_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[adapt_processing_blackout_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_processing_blackout_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_processing_blackout_info](
	[apbi_id ] [int] IDENTITY(1,1) NOT NULL,
	[apbi_start_date_time] [datetime] NOT NULL,
	[apbi_end_date_time] [datetime] NOT NULL,
	[apbi_description] [varchar](500) NULL,
	[apbi_msg_prior_display_days] [int] NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_adapt_processing_blackout_info_is_active]  DEFAULT ((1)),
	[apbi_platform] [int] NOT NULL CONSTRAINT [DF_adapt_processing_blackout_info_platform]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
	[is_used_for_display] [bit] NOT NULL CONSTRAINT [DF_adapt_processing_blackout_info_is_used_for_display]  DEFAULT ((1)),
 CONSTRAINT [PK_adapt_processing_blackout_info] PRIMARY KEY CLUSTERED 
(
	[apbi_id ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[adapt_separtor_types]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_separtor_types]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_separtor_types](
	[adapt_sep_type_id] [int] IDENTITY(1,1) NOT NULL,
	[adapt_sep_type_name] [varchar](50) NOT NULL,
	[adapt_sep_type_is_active] [bit] NOT NULL CONSTRAINT [DF_separator_is_active]  DEFAULT ((1)),
	[created_date_time] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [pk_adapt_separtor_types] PRIMARY KEY CLUSTERED 
(
	[adapt_sep_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[adapt_web_page_fields]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_web_page_fields]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_web_page_fields](
	[adapt_web_page_field_id] [int] IDENTITY(1,1) NOT NULL,
	[adapt_web_page_id] [int] NOT NULL,
	[adapt_web_page_field_name] [varchar](50) NOT NULL,
	[adapt_web_page_field_desc] [varchar](200) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_adapt_web_page_field_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_adapt_web_page_fields] PRIMARY KEY CLUSTERED 
(
	[adapt_web_page_field_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[adapt_web_pages]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_web_pages]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_web_pages](
	[adapt_web_page_id] [int] IDENTITY(1,1) NOT NULL,
	[adapt_web_pages_name] [varchar](50) NOT NULL,
	[adapt_web_pages_desc] [varchar](200) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_adapt_web_pages_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_adapt_web_pages] PRIMARY KEY CLUSTERED 
(
	[adapt_web_page_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[application_audit_log]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[application_audit_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[application_audit_log](
	[application_audit_log_id] [int] IDENTITY(1,1) NOT NULL,
	[service_end_point] [varchar](50) NULL,
	[request_start_time] [datetime] NULL,
	[request_end_time] [datetime] NULL,
	[service_request_params] [varchar](500) NULL,
	[service_HTTP_response_code] [int] NULL,
	[server_ip] [varchar](20) NULL,
	[created_datetime] [datetime] NULL,
 CONSTRAINT [PK_application_audit_log] PRIMARY KEY CLUSTERED 
(
	[application_audit_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[application_notification_log]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[application_notification_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[application_notification_log](
	[app_notification_log_id] [int] IDENTITY(1,1) NOT NULL,
	[app_notification_status] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
 CONSTRAINT [PK_application_notification_log] PRIMARY KEY CLUSTERED 
(
	[app_notification_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[approval_status]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[approval_status]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[approval_status](
	[approval_status_id] [int] IDENTITY(1,1) NOT NULL,
	[approval_status_name] [varchar](150) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [pk_approval_status] PRIMARY KEY CLUSTERED 
(
	[approval_status_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[attribute_data_types]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[attribute_data_types]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[attribute_data_types](
	[attribute_data_type_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute_data_type_name] [varchar](20) NOT NULL,
	[attribute_data_type_description] [varchar](100) NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_attribute_data_types] PRIMARY KEY CLUSTERED 
(
	[attribute_data_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[attribute_dictionary]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[attribute_dictionary]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[attribute_dictionary](
	[attribute_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute_name] [varchar](100) NOT NULL,
	[attribute_description] [varchar](2000) NULL,
	[default_data_type] [varchar](50) NOT NULL,
	[default_value] [varchar](200) NULL,
	[is_overridable] [bit] NULL,
	[attribute_size] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_attribute_dictionary] PRIMARY KEY CLUSTERED 
(
	[attribute_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_attribute_dictionary_K2] UNIQUE NONCLUSTERED 
(
	[attribute_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[attribute_logical_group]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[attribute_logical_group]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[attribute_logical_group](
	[attribute_logical_group_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute_logical_group_name] [varchar](150) NOT NULL,
	[group_description] [varchar](500) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [pk_attribute_logical_group] PRIMARY KEY CLUSTERED 
(
	[attribute_logical_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[cft_special_mapping_attr_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cft_special_mapping_attr_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[cft_special_mapping_attr_br_assoc](
	[csmaba_id] [int] IDENTITY(1,1) NOT NULL,
	[child_file_template_record_id] [int] NOT NULL,
	[business_rule_id] [int] NULL,
	[ftaa_id] [int] NULL,
	[attribute_usage_type] [varchar](50) NULL,
	[is_active] [bit] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_cft_special_mapping_attr_br_assoc] PRIMARY KEY CLUSTERED 
(
	[csmaba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_file_template_approval_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_approval_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_approval_audit](
	[child_file_template_approval_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[child_file_template_id] [int] NOT NULL,
	[approval_status_id] [int] NOT NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[requested_by] [varchar](50) NULL,
	[requester_comment] [varchar](200) NULL,
	[child_file_template_version] [int] NOT NULL,
	[child_file_template_record_id] [int] NOT NULL,
 CONSTRAINT [pk_child_file_template_approval_audit] PRIMARY KEY CLUSTERED 
(
	[child_file_template_approval_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_file_template_attr_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_attr_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_attr_br_assoc](
	[cft_attr_br_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[cftaa_id] [int] NOT NULL,
	[business_rule_id] [int] NULL,
	[business_rule_version] [int] NULL,
	[rule_execution_sequence] [int] NULL,
	[rule_execution_comment] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_child_file_template_attr_br_assoc] PRIMARY KEY CLUSTERED 
(
	[cft_attr_br_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_child_file_template_attr_br_assoc_K2_K3_K5] UNIQUE NONCLUSTERED 
(
	[cftaa_id] ASC,
	[business_rule_id] ASC,
	[rule_execution_sequence] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_file_template_attribute_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_attribute_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_attribute_association](
	[cftaa_id] [int] IDENTITY(1,1) NOT NULL,
	[child_file_template_id] [int] NOT NULL,
	[child_file_template_version] [int] NOT NULL,
	[attribute_id] [int] NOT NULL,
	[attribute_row_position] [int] NULL,
	[data_type] [varchar](50) NOT NULL,
	[is_mandatory] [bit] NOT NULL,
	[attribute_size] [int] NULL,
	[application_compliant_attribute_name] [varchar](50) NULL,
	[is_inherited] [bit] NOT NULL CONSTRAINT [DF_cftaa_is_inherited]  DEFAULT ((0)),
	[cftsa_id] [int] NOT NULL,
	[attribute_start_position] [int] NULL,
	[attribute_end_position] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[child_file_template_record_id] [int] NOT NULL,
	[mftaa_id] [int] NULL,
 CONSTRAINT [PK_child_file_template_attribute_association] PRIMARY KEY CLUSTERED 
(
	[cftaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_file_template_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_meta_info](
	[child_file_template_name] [varchar](50) NOT NULL,
	[child_file_template_description] [varchar](100) NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[lob_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[approval_status_id] [int] NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[child_file_template_layout] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[editor_comment] [varchar](200) NULL,
	[edited_by] [varchar](50) NULL,
	[child_file_template_id] [int] NOT NULL,
	[child_file_template_version] [int] NOT NULL,
	[child_file_template_record_id] [int] IDENTITY(1,1) NOT NULL,
	[master_file_template_record_id] [int] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[data_source_type_id] [int] NOT NULL,
	[data_target_type_id] [int] NOT NULL
 CONSTRAINT [PK_child_file_template_meta_info_record_id] PRIMARY KEY CLUSTERED 
(
	[child_file_template_record_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)ON [PRIMARY],
CONSTRAINT [UK_child_file_template_meta_info_id_version] UNIQUE NONCLUSTERED 
(
	[child_file_template_id] ASC,
	[child_file_template_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] )ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_file_template_section_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_section_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_section_assoc](
	[cftsa_id] [int] IDENTITY(1,1) NOT NULL,
	[template_section_id] [int] NOT NULL,
	[child_file_template_id] [int] NOT NULL,
	[child_file_template_version] [int] NOT NULL,
	[template_compliant_section_short_name] [varchar](20) NULL,
	[sequence] [smallint] NOT NULL,
	[is_madatory] [bit] NOT NULL DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[child_file_template_record_id] [int] NOT NULL,
	[section_display_name] [varchar](50) NULL
 CONSTRAINT [pk_child_file_template_attribute_section_assoc] PRIMARY KEY CLUSTERED 
(
	[cftsa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[child_file_template_version_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_version_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_file_template_version_audit](
	[child_template_id] [int] NOT NULL,
	[from_version] [int] NOT NULL,
	[to_version] [int] NOT NULL,
	[created_date] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[approval_status_id] [int] NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_secondary_mapping_attr_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_secondary_mapping_attr_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_secondary_mapping_attr_assoc](
	[csmaa_id] [int] IDENTITY(1,1) NOT NULL,
	[csmaa_child_file_template_record_id] [int] NOT NULL,
	[csmaa_cftaa_id] [int] NOT NULL,
	[csmaa_node_name] [varchar](50) NOT NULL,
	[csmaa_standardized_name] [varchar](150) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_child_secondary_mapping_attr_assoc] PRIMARY KEY CLUSTERED 
(
	[csmaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_template_layout_schema_node_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_template_layout_schema_node_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_template_layout_schema_node_assoc](
	[ctlsna_id] [int] IDENTITY(1,1) NOT NULL,
	[ctlsni_id] [int] NOT NULL,
	[parent_ctlsni_id] [int] NULL,
	[node_has_children] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_ctlsna_has_chilren]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_child_template_layout_schema_node_assoc] PRIMARY KEY CLUSTERED 
(
	[ctlsna_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[child_template_layout_schema_node_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[child_template_layout_schema_node_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[child_template_layout_schema_node_info](
	[ctlsni_id] [int] IDENTITY(1,1) NOT NULL,
	[mtlsni_id] [int] NULL,
	[child_file_template_record_id] [int] NOT NULL,
	[node_category] [varchar](50) NOT NULL,
	[node_display_name] [varchar](100) NOT NULL,
	[node_data_type_id] [int] NOT NULL,
	[node_min_count] [int] NULL,
	[node_max_count] [int] NULL,
	[node_ref_num] [int] NOT NULL,
	[node_row_position] [int] NOT NULL,
	[node_description] [varchar](500) NULL,
	[node_is_mandatory] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_ctlsni_is_mandatory]  DEFAULT ((0)),
	[node_cond_description] [varchar](500) NULL,
	[mapped_column_type] [varchar](50) NULL,
	[mapped_template_section_id] [int] NULL,
	[node_section_short_name] [char](1) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_ctlsni_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[node_max_size] [int] NULL,
	[node_min_size] [int] NULL,
	[mapped_column_order] [int] NULL,
	[mapped_column_start_position] [int] NULL,
	[mapped_column_end_position] [int] NULL
 CONSTRAINT [PK_child_template_layout_schema_node_info] PRIMARY KEY CLUSTERED 
(
	[ctlsni_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[client_employer_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[client_employer_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[client_employer_assoc](
	[client_employer_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[employer_id] [int] NULL,
	[client_id] [varchar](10) NULL,
	[employer_name] [varchar](100) NULL,
	[data_source_id] [int] NOT NULL,
	[last_updated_timestamp] [datetime] NOT NULL,
	[source_instance] [varchar](50) NOT NULL,
	[table_version] [int] NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_cea_is_active]  DEFAULT ((1)),
 CONSTRAINT [PK_client_employer_assoc2] PRIMARY KEY CLUSTERED 
(
	[client_employer_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_client_employer_assoc_K2_K3_K5] UNIQUE NONCLUSTERED 
(
	[employer_id] ASC,
	[client_id] ASC,
	[data_source_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[config_promotion_audit_details]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[config_promotion_audit_details]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[config_promotion_audit_details](
	[config_promotion_audit_detail_id] [int] IDENTITY(1,1) NOT NULL,
	[config_promotion_audit_id] [int] NOT NULL,
	[config_entity_name] [varchar](100) NOT NULL,
	[table_name] [varchar](100) NULL,
	[table_pk_id] [int] NULL,
	[table_is_insert] [int] NULL,
	[table_is_rolled_back] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[endpoint_name] [varchar](200) NULL,
	[is_multi] [bit] NULL,
	[previous_entity] [nvarchar](max) NULL
 CONSTRAINT [PK_config_promotion_audit_details] PRIMARY KEY CLUSTERED 
(
	[config_promotion_audit_detail_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[config_promotion_audit_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[config_promotion_audit_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[config_promotion_audit_info](
	[config_promotion_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[source_env_id] [int] NOT NULL,
	[target_env_id] [int] NOT NULL,
	[promotion_notes] [varchar](500) NULL,
	[promotion_status_id] [int] NOT NULL,
	[file_id] [int] NOT NULL,
	[file_version] [int] NOT NULL,
	[file_identifier] [int] NOT NULL,
	[was_pmt_promoted] [bit] NOT NULL CONSTRAINT [DF_config_promotion_audit_info_pmt_promoted]  DEFAULT ((1)),
	[pmt_id] [int] NULL,
	[pmt_version] [int] NULL,
	[was_master_promoted] [bit] NOT NULL CONSTRAINT [DF_config_promotion_audit_info_master_promoted]  DEFAULT ((0)),
	[master_id] [int] NULL,
	[master_version] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[approved_by] [varchar](50) NULL,
	[approved_date_time] [datetime] NULL,
 CONSTRAINT [PK_config_promotion_audit_info] PRIMARY KEY CLUSTERED 
(
	[config_promotion_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[config_promotion_status]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[config_promotion_status]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[config_promotion_status](
	[config_promotion_status_id] [int] IDENTITY(1,1) NOT NULL,
	[config_promotion_status_name] [varchar](20) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_config_promotion_status] PRIMARY KEY CLUSTERED 
(
	[config_promotion_status_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[ctls_node_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ctls_node_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ctls_node_br_assoc](
	[ctlsnba_id] [int] IDENTITY(1,1) NOT NULL,
	[ctlsni_id] [int] NOT NULL,
	[business_rule_id] [int] NOT NULL,
	[rule_execution_sequence] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[rule_execution_comment] [varchar](200) NULL,
 CONSTRAINT [PK_ctls_node_br_assoc] PRIMARY KEY CLUSTERED 
(
	[ctlsnba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[ctls_node_dm_element_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ctls_node_dm_element_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ctls_node_dm_element_assoc](
	[ctlsnda_id] [int] IDENTITY(1,1) NOT NULL,
	[ctlsni_id] [int] NOT NULL,
	[cftaa_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_ctlsda_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_ctls_node_dm_element_assoc] PRIMARY KEY CLUSTERED 
(
	[ctlsnda_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[ctls_node_enum_value_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ctls_node_enum_value_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ctls_node_enum_value_assoc](
	[ctaeva_id] [int] IDENTITY(1,1) NOT NULL,
	[ctlsni_id] [int] NOT NULL,
	[mtaeva_id] [int] NULL,
	[enum_value] [varchar](50) NOT NULL,
	[enum_value_description] [varchar](500) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_ctaeva_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL
 CONSTRAINT [PK_ctls_node_enum_value_assoc] PRIMARY KEY CLUSTERED 
(
	[ctaeva_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[data_source_target_type]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[data_source_target_type]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[data_source_target_type](
	[data_source_target_type_id] [int] IDENTITY(1,1) NOT NULL,
	[data_source_target_type_name] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_data_source_target_type_id] PRIMARY KEY CLUSTERED 
(
	[data_source_target_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[delivery_mechanism_type]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[delivery_mechanism_type]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[delivery_mechanism_type](
	[delivery_mechanism_type_id] [int] IDENTITY(1,1) NOT NULL,
	[delivery_mechanism_type_name] [varchar](100) NOT NULL,
	[delivery_mechanism_type_desc] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_delivery_mechanism_type] PRIMARY KEY CLUSTERED 
(
	[delivery_mechanism_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_delivery_mechanism_type_K2] UNIQUE NONCLUSTERED 
(
	[delivery_mechanism_type_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_business_rule_group]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rule_group]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_business_rule_group](
	[drools_business_rule_group_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_business_rule_group_name] [varchar](100) NOT NULL,
	[drools_business_rule_group_priority] [int] NOT NULL CONSTRAINT [DF_drools_business_rule_group_priority]  DEFAULT ((1)),
	[parent_group_id] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_drools_business_rule_group] PRIMARY KEY CLUSTERED 
(
	[drools_business_rule_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_drools_business_rule_group_K2] UNIQUE NONCLUSTERED 
(
	[drools_business_rule_group_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_business_rule_pkg]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rule_pkg]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_business_rule_pkg](
	[drools_business_rule_pkg_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_business_rule_pkg_version] [int] NOT NULL,
	[drools_br_pkg_file_type_id] [int] NOT NULL,
	[drools_br_pkg_name] [varchar](100) NOT NULL,
	[drools_br_pojo_name] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
 CONSTRAINT [PK_drools_business_rule_pkg] PRIMARY KEY CLUSTERED 
(
	[drools_business_rule_pkg_id] ASC,
	[drools_business_rule_pkg_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_business_rule_pkg_file_type_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rule_pkg_file_type_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_business_rule_pkg_file_type_assoc](
	[drools_br_pkg_file_type_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_business_rule_pkg_id] [int] NOT NULL,
	[drools_business_rule_pkg_version] [int] NOT NULL,
	[drools_br_pkg_file_type_id] [int] NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_drools_business_rule_pkg_file_type_assoc] PRIMARY KEY CLUSTERED 
(
	[drools_br_pkg_file_type_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_business_rule_template]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rule_template]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_business_rule_template](
	[drools_business_rule_template_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_business_rule_template_name] [varchar](100) NOT NULL,
	[drools_business_rule_template_group_id] [int] NOT NULL,
	[drools_business_rule_template_version] [int] NOT NULL,
	[drools_business_rule_tempalte_content] [text] NOT NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[approval_status_id] [int] NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_drools_business_rule_template] PRIMARY KEY CLUSTERED 
(
	[drools_business_rule_template_id] ASC,
	[drools_business_rule_template_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_business_rules_decision_table]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rules_decision_table]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_business_rules_decision_table](
	[drools_business_rule_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_business_rule_name] [varchar](100) NOT NULL,
	[drools_business_rule_group_id] [int] NOT NULL,
	[rule_group_hierarchy_string] [varchar](50) NULL,
	[drools_business_rule_version] [int] NOT NULL,
	[drools_business_rule_drl_file_content] [text] NULL,
	[drools_business_rule_ui_json_text] [text] NULL,
	[drools_business_rule_pre_drl_text] [text] NULL,
	[is_current] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
 CONSTRAINT [PK_drools_business_rules_decision_table] PRIMARY KEY CLUSTERED 
(
	[drools_business_rule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_data_format_functions]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_data_format_functions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_data_format_functions](
	[drools_data_format_function_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_data_format_id] [int] NOT NULL,
	[drools_data_format_function_name] [varchar](150) NOT NULL,
	[drools_data_format_function_value] [varchar](150) NULL,
	[drools_data_format_function_java_method_name] [varchar](250) NULL,
	[drools_data_format_function_helptext] [varchar](250) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_drools_data_format_function] PRIMARY KEY CLUSTERED 
(
	[drools_data_format_function_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[drools_data_formats]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[drools_data_formats]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[drools_data_formats](
	[drools_data_format_id] [int] IDENTITY(1,1) NOT NULL,
	[drools_data_format_name] [varchar](150) NOT NULL,
	[drools_data_format_description] [varchar](150) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_drools_data_format] PRIMARY KEY CLUSTERED 
(
	[drools_data_format_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[error_code]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[error_code]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[error_code](
	[error_code] [int] IDENTITY(1,1) NOT NULL,
	[error_message] [varchar](20) NULL,
	[error_description] [varchar](500) NULL,
	[error_type_id] [int] NOT NULL,
	[error_severity_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_error_code] PRIMARY KEY CLUSTERED 
(
	[error_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_error_code_K2] UNIQUE NONCLUSTERED 
(
	[error_message] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[error_log_application]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[error_log_application]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[error_log_application](
	[error_log_application_id] [int] IDENTITY(1,1) NOT NULL,
	[error_code] [int] NOT NULL,
	[error_message] [varchar](500) NULL,
	[error_type_id] [int] NOT NULL,
	[error_severity_id] [int] NOT NULL,
	[error_service_end_point] [varchar](20) NULL,
	[error_source_code_file] [varchar](50) NULL,
	[error_source_code_file_path] [varchar](200) NULL,
	[error_source_code_class] [varchar](200) NULL,
	[error_source_code_method] [varchar](200) NULL,
	[error_source_code_line] [int] NULL,
	[error_system_user_name] [varchar](50) NULL,
	[error_login_user_name] [varchar](50) NULL,
	[error_login_user_ip] [varchar](20) NULL,
	[error_origin_server_ip] [varchar](20) NULL,
	[error_date_time] [datetime] NULL,
 CONSTRAINT [PK_error_log_application] PRIMARY KEY CLUSTERED 
(
	[error_log_application_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[error_log_data_file_processing]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[error_log_data_file_processing](
	[error_log_file_processing_id] [int] IDENTITY(1,1) NOT NULL,
	[error_code] [int] NULL,
	[error_message] [varchar](500) NULL,
	[error_type_id] [int] NULL,
	[error_severity_id] [int] NULL,
	[error_data_file_job_id] [int] NULL,
	[error_data_file_expectation_id] [int] NULL,
	[error_data_file_id] [int] NULL,
	[error_data_file_version] [int] NULL,
	[error_data_file_path] [varchar](500) NULL,
	[error_data_file_has_format_issue] [bit] NULL,
	[error_data_file_line_no] [int] NULL,
	[error_data_file_attribute_name] [varchar](50) NULL,
	[error_data_file_attribute_value] [varchar](200) NULL,
	[error_data_file_has_lookup_table_error] [bit] NULL,
	[error_data_file_attribute_lookup_table_id] [int] NULL,
	[error_data_file_has_business_rule_error] [bit] NULL,
	[error_data_file_attribute_business_rule_id] [int] NULL,
	[error_system_user_name] [varchar](50) NULL,
	[error_execution_server_ip] [varchar](20) NULL,
	[error_date_time] [datetime] NULL,
 CONSTRAINT [PK_error_log_data_file_processing] PRIMARY KEY CLUSTERED 
(
	[error_log_file_processing_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[error_severity]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[error_severity]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[error_severity](
	[error_severity_id] [int] IDENTITY(1,1) NOT NULL,
	[error_severity_name] [varchar](20) NULL,
	[error_severity_description] [varchar](500) NULL,
	[error_severity_custom_code] [varchar](50) NULL,
	[triggers_abort] [varchar](20) NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_error_severity] PRIMARY KEY CLUSTERED 
(
	[error_severity_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_error_severity_K2] UNIQUE NONCLUSTERED 
(
	[error_severity_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[error_type]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[error_type]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[error_type](
	[error_type_id] [int] IDENTITY(1,1) NOT NULL,
	[error_type_name] [varchar](20) NULL,
 CONSTRAINT [PK_error_type] PRIMARY KEY CLUSTERED 
(
	[error_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_error_type_K2] UNIQUE NONCLUSTERED 
(
	[error_type_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[expectation_attempt_log]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[expectation_attempt_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[expectation_attempt_log](
	[expectation_log_id] [bigint] IDENTITY(1,1) NOT NULL,
	[expectation_id] [int] NOT NULL,
	[file_expectation_status] [varchar](50) NULL,
	[file_expectation_attempt_start_date_time] [datetime] NOT NULL,
	[file_expectation_attempt_end_date_time] [datetime] NOT NULL,
	[file_expectation_initiated_by_user] [varchar](50) NULL,
	[file_expectation_attempt_count] [tinyint] NULL,
	[file_expectation_attempt_log] [text] NULL,
	[created_by] [varchar](50) NULL,
	[updated_by] [varchar](50) NULL,
	[created_date] [datetime] NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_expectation_attempt_log] PRIMARY KEY CLUSTERED 
(
	[expectation_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[extraction_parameters]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[extraction_parameters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[extraction_parameters](
	[ep_id] [int] IDENTITY(1,1) NOT NULL,
	[ep_ept_id] [int] NOT NULL,
	[ep_name] [varchar](100) NOT NULL,
	[ep_attribute_id] [int] NULL,
	[ep_standardized_name] [varchar](100) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_ep_id] PRIMARY KEY CLUSTERED 
(
	[ep_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[extraction_parameters_types]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[extraction_parameters_types]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[extraction_parameters_types](
	[ept_id] [int] IDENTITY(1,1) NOT NULL,
	[ept_name] [varchar](50) NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_ept_id] PRIMARY KEY CLUSTERED 
(
	[ept_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[file_approval_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_approval_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_approval_audit](
	[file_approval_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[file_id] [int] NOT NULL,
	[approval_status_id] [int] NOT NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[requested_by] [varchar](50) NULL,
	[requester_comment] [varchar](200) NULL,
	[file_version] [int] NOT NULL,
	[file_identifier] [int] NOT NULL,
 CONSTRAINT [pk_file_approval_audit] PRIMARY KEY CLUSTERED 
(
	[file_approval_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[file_attr_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_attr_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_attr_br_assoc](
	[file_attr_br_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[faa_id] [int] NOT NULL,
	[business_rule_id] [int] NULL,
	[business_rule_version] [int] NULL,
	[rule_execution_sequence] [int] NULL,
	[rule_execution_comment] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[profile_id] [int] NULL,
 CONSTRAINT [PK_file_attr_br_assoc] PRIMARY KEY CLUSTERED 
(
	[file_attr_br_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_file_attr_br_assoc_K2_K3_K5] UNIQUE NONCLUSTERED 
(
	[faa_id] ASC,
	[business_rule_id] ASC,
	[rule_execution_sequence] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[file_attribute_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_attribute_association](
	[faa_id] [int] IDENTITY(1,1) NOT NULL,
	[fsa_id] [int] NULL,
	[attribute_id] [int] NOT NULL,
	[data_type] [varchar](20) NOT NULL,
	[is_mandatory] [bit] NULL,
	[attribute_size] [int] NULL,
	[attribute_row_position] [int] NULL,
	[attribute_start_position] [int] NULL,
	[attribute_end_position] [int] NULL,
	[is_inherited] [bit] NOT NULL CONSTRAINT [DF_faa_is_inherited]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_format_compliant_attribute_name] [varchar](50) NULL,
	[file_identifier] [int] NULL,
	[cftaa_id] [int] NULL,
	[clone_num] [int] NOT NULL CONSTRAINT [DF_file_attribute_association_clone_num]  DEFAULT ((0)),
 CONSTRAINT [PK_file_attribute_association] PRIMARY KEY CLUSTERED 
(
	[faa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[file_clone_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_clone_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_clone_info](
	[file_clone_id] [int] IDENTITY(1,1) NOT NULL,
	[file_identifier] [int] NOT NULL,
	[clone_num] [int] NOT NULL,
	[clone_name] [varchar](100) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_clone_id] PRIMARY KEY CLUSTERED 
(
	[file_clone_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_file_clone_info_K2_K3_K4] UNIQUE NONCLUSTERED 
(
	[file_identifier] ASC,
	[clone_name] ASC,
	[clone_num] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_employer_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_employer_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_employer_assoc](
	[file_employer_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[client_employer_assoc_id] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_file_employer_assoc] PRIMARY KEY CLUSTERED 
(
	[file_employer_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_export_queries]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_export_queries]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_export_queries](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[file_record_id] [int] NOT NULL,
	[created_date] [datetime] NOT NULL,
	[sequence] [int] NOT NULL,
	[query] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_file_export_queries] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[file_extraction_parameters_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_extraction_parameters_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_extraction_parameters_assoc](
	[fepa_id] [int] IDENTITY(1,1) NOT NULL,
	[fepa_fepi_id] [int] NOT NULL,
	[fepa_ep_id] [int] NULL,
	[fepa_criteria_unique_identifier] [varchar](200) NULL,
	[fepa_criteria_display_value] [varchar](200) NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_fepa_id] PRIMARY KEY CLUSTERED 
(
	[fepa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_extraction_parameters_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_extraction_parameters_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_extraction_parameters_info](
	[fepi_id] [int] IDENTITY(1,1) NOT NULL,
	[file_identifier] [int] NOT NULL,
	[fepi_profile_id] [int] NOT NULL,
	[fepi_is_adv_selection_criteria] [bit] NOT NULL,
	[fepi_is_change_criteria] [bit] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_fepi_id] PRIMARY KEY CLUSTERED 
(
	[fepi_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_format_supported]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_format_supported]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_format_supported](
	[file_format_supported_id] [int] IDENTITY(1,1) NOT NULL,
	[file_format_name] [varchar](20) NULL,
	[file_format_row_delimiter] [varchar](5) NULL,
	[file_format_field_delimiter] [varchar](5) NULL,
	[file_format_escape_char] [varchar](2) NULL,
	[file_format_segment_delimiter] [varchar](5) NULL,
	[file_has_header] [bit] NULL,
	[file_has_footer] [bit] NULL,
	[file_header_line_count] [int] NULL,
	[file_footer_line_count] [int] NULL,
	[file_lines_skip_count] [int] NULL DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_format_supported] PRIMARY KEY CLUSTERED 
(
	[file_format_supported_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_id_generator]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_id_generator]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_id_generator](
	[file_id] [int] IDENTITY(1,1) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_file_id_generator] PRIMARY KEY CLUSTERED 
(
	[file_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_layout_schema_node_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_layout_schema_node_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_layout_schema_node_assoc](
	[flsna_id] [int] IDENTITY(1,1) NOT NULL,
	[flsni_id] [int] NOT NULL,
	[parent_flsni_id] [int] NULL,
	[node_has_children] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_flsna_has_chilren]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_layout_schema_node_assoc] PRIMARY KEY CLUSTERED 
(
	[flsna_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_layout_schema_node_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_layout_schema_node_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_layout_schema_node_info](
	[flsni_id] [int] IDENTITY(1,1) NOT NULL,
	[ctlsni_id] [int] NULL,
	[file_identifier] [int] NOT NULL,
	[node_category] [varchar](50) NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_display_name] [varchar](100) NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_data_type_id] [int] NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_min_count] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_max_count] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_ref_num] [int] NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_row_position] [int] NOT NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_description] [varchar](500) NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_is_mandatory] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_flsni_is_mandatory]  DEFAULT ((0))
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_cond_description] [varchar](500) NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [mapped_column_type] [varchar](50) NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [mapped_template_section_id] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_section_short_name] [char](1) NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_flsni_is_active]  DEFAULT ((1))
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [created_date_time] [datetime] NOT NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [updated_date_time] [datetime] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_max_size] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_min_size] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [mapped_column_order] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [mapped_column_start_position] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [mapped_column_end_position] [int] NULL
ALTER TABLE [dbo].[file_layout_schema_node_info] ADD [node_clone_num] [int] NULL
 CONSTRAINT [PK_file_layout_schema_node_info] PRIMARY KEY CLUSTERED 
(
	[flsni_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_linked_urls_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_linked_urls_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_linked_urls_assoc](
	[url_id] [int] IDENTITY(1,1) NOT NULL,
	[file_name] [varchar](80) NULL,
	[file_associated_website] [varchar](250) NULL,
	[is_active] [bit] NOT NULL DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_file_linked_urls_assoc] PRIMARY KEY CLUSTERED 
(
	[url_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_meta_info](
	[record_id] [int] IDENTITY(1,1) NOT NULL,
	[file_id] [int] NOT NULL,
	[file_type_id] [int] NOT NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[child_file_template_id] [int] NULL,
	[child_file_template_version] [int] NOT NULL,
	[file_version] [int] NOT NULL,
	[file_name] [varchar](80) NULL,
	[is_multi_employer] [bit] NOT NULL CONSTRAINT [DF_file_meta_info_is_multi_employer]  DEFAULT ((0)),
	[file_status] [varchar](20) NULL,
	[old_file_id] [int] NULL,
	[archival_location] [varchar](250) NULL,
	[file_processing_error_threshold_count] [int] NULL,
	[file_min_record_count_allowed] [int] NULL,
	[file_idis_ba_id] [int] NULL,
	[file_transmission_name] [varchar](80) NULL,
	[file_format_supported_id] [int] NULL,
	[trading_partner_platform_id] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[approval_status_id] [int] NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[edited_by] [varchar](50) NULL,
	[editor_comment] [varchar](200) NULL,
	[append_file_run_date] [bit] NULL DEFAULT ((0)),
	[file_max_record_count_allowed] [int] NULL,
	[file_processing_error_threshold_format] [varchar](30) NOT NULL CONSTRAINT [DF_file_meta_info_error_format]  DEFAULT ('No Threshold'),
	[file_idis_ba_email_id] [varchar](100) NULL,
	[file_idis_ba_name] [varchar](50) NULL,
	[master_file_template_record_id] [int] NULL,
	[child_file_template_record_id] [int] NULL,
	[is_SLA_mapped] [bit] NOT NULL CONSTRAINT [DF_file_meta_info_SLA_mapped]  DEFAULT ((0)),
	[data_source_type_id] [int] NOT NULL,
	[data_target_type_id] [int] NOT NULL,
 CONSTRAINT [PK_file_meta_info] PRIMARY KEY CLUSTERED 
(
	[record_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_file_meta_info_K2_K8] UNIQUE NONCLUSTERED 
(
	[file_id] ASC,
	[file_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_notification_template_contact_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_notification_template_contact_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_notification_template_contact_assoc](
	[file_notification_template_contact_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[template_id] [int] NULL,
	[trading_partner_contact_type_id] [int] NULL,
	[trading_partner_contact_id] [int] NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_file_notification_template_contact_assoc_active]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[is_file_analyst] [bit] NULL,
	[idis_team_id] [int] NULL,
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_file_notification_template_contact_assoc] PRIMARY KEY CLUSTERED 
(
	[file_notification_template_contact_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_audit_log]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_audit_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_audit_log](
	[file_processing_audit_log_id] [int] IDENTITY(1,1) NOT NULL,
	[file_id] [int] NOT NULL,
	[file_version] [varchar](50) NULL,
	[job_id] [int] NULL,
	[expectation_id] [int] NULL,
	[processing_step_id] [int] NULL,
	[processing_step_start_time] [datetime] NULL,
	[processing_step_end_time] [datetime] NULL,
	[audit_message] [varchar](500) NULL,
	[created_datetime] [datetime] NULL,
 CONSTRAINT [PK_file_processing_audit_log] PRIMARY KEY CLUSTERED 
(
	[file_processing_audit_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_mode]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_mode]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_mode](
	[file_processing_mode_id] [int] IDENTITY(1,1) NOT NULL,
	[file_processing_mode_name] [varchar](50) NOT NULL,
	[file_processing_mode_desc] [varchar](100) NULL,
	[file_direction] [char](1) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_processing_mode] PRIMARY KEY CLUSTERED 
(
	[file_processing_mode_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_recurrence]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_recurrence]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_recurrence](
	[file_processing_recurrence_id] [int] IDENTITY(1,1) NOT NULL,
	[recurrence_type_id] [int] NOT NULL,
	[end_date_offset] [int] NULL,
	[weekly_is_monday] [bit] NULL,
	[weekly_is_tuesday] [bit] NULL,
	[weekly_is_wednesday] [bit] NULL,
	[weekly_is_thursday] [bit] NULL,
	[weekly_is_friday] [bit] NULL,
	[weekly_is_saturday] [bit] NULL,
	[weekly_is_sunday] [bit] NULL,
	[exception_rule_id] [int] NULL,
	[monthly_date] [int] NULL,
	[semi_monthly_and_date] [int] NULL,
	[create_begin_date_offset_manual] [bit] NULL,
	[create_begin_date_offset_auto] [bit] NULL,
	[begin_date_offset_date] [int] NULL,
	[file_processing_mode_id] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[is_soft_deleted] [bit] NOT NULL CONSTRAINT [DF_file_processing_recurrence_is_soft_deleted]  DEFAULT ((0)),
	[recurrence_exception_rule_id] [int] NULL,
	[paysite_id] [int] NULL,
 CONSTRAINT [PK_file_processing_recurrence] PRIMARY KEY CLUSTERED 
(
	[file_processing_recurrence_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_recurrence_dates]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_recurrence_dates]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_recurrence_dates](
	[file_processing_recurrence_date_id] [int] IDENTITY(1,1) NOT NULL,
	[file_processing_recurrence_id] [int] NOT NULL,
	[file_processing_recurrence_date] [int] NULL,
	[file_processing_recurrence_name] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_file_processing_recurrence_dates] PRIMARY KEY CLUSTERED 
(
	[file_processing_recurrence_date_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_schedule]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_schedule]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_schedule](
	[file_processing_schedule_id] [int] IDENTITY(1,1) NOT NULL,
	[file_processing_start_date] [datetime] NULL,
	[file_processing_next_scheduled_date] [datetime] NULL,
	[file_processing_recurrence_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_processing_end_date] [datetime] NULL,
	[file_processing_recurrence] [bit] NULL,
	[file_delivery_mechanism] [varchar](50) NOT NULL DEFAULT ('MoveIT'),
	[file_data_extraction_mode] [varchar](10) NULL CONSTRAINT [DF_file_processing_schedule_file_data_extraction_mode]  DEFAULT ('Full'),
	[profile_id] [int] NOT NULL,
	[is_soft_deleted] [bit] NOT NULL CONSTRAINT [DF_file_processing_schedule_is_soft_deleted]  DEFAULT ((0)),
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_file_processing_schedule] PRIMARY KEY CLUSTERED 
(
	[file_processing_schedule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_processing_schedule_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_schedule_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_processing_schedule_audit](
	[fps_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[file_processing_schedule_id] [int] NOT NULL,
	[fps_field_updated] [varchar](50) NOT NULL,
	[fps_field_value_old] [varchar](50) NULL,
	[fps_field_value_new] [varchar](50) NULL,
	[fps_field_updated_notes] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_file_processing_schedule_audit] PRIMARY KEY CLUSTERED 
(
	[fps_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_secondary_mapping_attr_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_secondary_mapping_attr_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_secondary_mapping_attr_assoc](
	[fsmaa_id] [int] IDENTITY(1,1) NOT NULL,
	[fsmaa_file_identifier] [int] NOT NULL,
	[fsmaa_faa_id] [int] NOT NULL,
	[fsmaa_node_name] [varchar](50) NOT NULL,
	[fsmaa_standardized_name] [varchar](150) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_secondary_mapping_attr_assoc] PRIMARY KEY CLUSTERED 
(
	[fsmaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_section_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_section_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_section_association](
	[fsa_id] [int] IDENTITY(1,1) NOT NULL,
	[template_section_id] [int] NOT NULL,
	[file_compliant_section_short_name] [varchar](20) NULL,
	[sequence] [smallint] NOT NULL,
	[is_madatory] [bit] NOT NULL DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_identifier] [int] NULL,
	[section_display_name] [varchar](50) NULL,
 CONSTRAINT [pk_file_section_association] PRIMARY KEY CLUSTERED 
(
	[fsa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_special_mapping_attr_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_special_mapping_attr_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_special_mapping_attr_br_assoc](
	[fsmaba_id] [int] IDENTITY(1,1) NOT NULL,
	[file_identifier] [int] NOT NULL,
	[business_rule_id] [int] NULL,
	[ftaa_id] [int] NULL,
	[attribute_usage_type] [varchar](50) NULL,
	[is_active] [bit] NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_special_mapping_attr_br_assoc] PRIMARY KEY CLUSTERED 
(
	[fsmaba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_state]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_state]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_state](
	[file_state_id] [int] IDENTITY(1,1) NOT NULL,
	[file_name] [varchar](50) NOT NULL,
	[trading_partner_id] [int] NULL,
	[file_path] [varchar](1000) NOT NULL,
	[file_archival_path] [varchar](1000) NOT NULL,
	[file_identifier] [int] NULL,
	[job_id] [int] NULL,
	[encrypted_private_key] [varbinary](max) NULL,
	[public_key] [varchar](max) NULL,
	[is_empty] [bit] NOT NULL CONSTRAINT [DF_file_state_is_empty]  DEFAULT ((0)),
	[is_duplicate] [bit] NOT NULL CONSTRAINT [DF_file_state_is_duplicate]  DEFAULT ((0)),
	[file_status] [varchar](20) NOT NULL,
	[new_file_name] [varchar](50) NOT NULL,
	[file_id] [int] NULL,
	[file_checksum] [varchar](200) NULL,
	[created_date_time] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [pk_file_state] PRIMARY KEY CLUSTERED 
(
	[file_state_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_state_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_state_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_state_audit](
	[file_state_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[file_state_id] [int] NOT NULL,
	[file_state_updated_by] [varchar](50) NOT NULL,
	[file_state_updated_date_time] [datetime] NOT NULL,
	[file_state_action_taken] [varchar](50) NOT NULL,
	[file_state_mapped_job_id] [int] NULL,
	[file_state_mapped_file_id] [int] NULL,
	[file_state_mapped_run_date] [datetime] NULL,
 CONSTRAINT [PK_file_state_audit] PRIMARY KEY CLUSTERED 
(
	[file_state_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_trading_partner_lob_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_trading_partner_lob_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_trading_partner_lob_assoc](
	[file_trading_partner_lob_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[lob_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_file_trading_partner_lob_assoc] PRIMARY KEY CLUSTERED 
(
	[file_trading_partner_lob_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_transmission_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_transmission_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_transmission_info](
	[file_transmission_connection_id] [int] IDENTITY(1,1) NOT NULL,
	[file_identifier] [int] NOT NULL,
	[adapt_env_id] [int] NOT NULL,
	[trading_partner_connection_id] [int] NOT NULL,
	[trading_partner_auth_key_id] [int] NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_file_transmission_info_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_file_transmission_connection_id] PRIMARY KEY CLUSTERED 
(
	[file_transmission_connection_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_file_transmission_info_K2_K3_K4] UNIQUE NONCLUSTERED 
(
	[file_identifier] ASC,
	[adapt_env_id] ASC,
	[trading_partner_connection_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_type_attribute_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_type_attribute_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_type_attribute_association](
	[ftaa_id] [int] IDENTITY(1,1) NOT NULL,
	[file_type_id] [int] NOT NULL,
	[attribute_id] [int] NOT NULL,
	[data_type] [varchar](20) NOT NULL,
	[is_mandatory] [bit] NULL,
	[default_value] [varchar](200) NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[file_type_attribute_association] ADD [standardized_name] [varchar](200) NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[file_type_attribute_association] ADD [created_by] [varchar](50) NULL
ALTER TABLE [dbo].[file_type_attribute_association] ADD [created_date_time] [datetime] NULL
ALTER TABLE [dbo].[file_type_attribute_association] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[file_type_attribute_association] ADD [updated_date_time] [datetime] NULL
ALTER TABLE [dbo].[file_type_attribute_association] ADD [attribute_logical_group_id] [int] NULL
 CONSTRAINT [PK_file_type_attribute_association] PRIMARY KEY CLUSTERED 
(
	[ftaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_type_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_type_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_type_meta_info](
	[file_type_id] [int] IDENTITY(1,1) NOT NULL,
	[file_type_name] [varchar](100) NOT NULL,
	[direction] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[system_name] [varchar](100) NULL,
	[is_clone_allowed] [bit] NOT NULL CONSTRAINT [DF_file_type_meta_info_is_clone_allowed]  DEFAULT ((0)),
 CONSTRAINT [PK_file_type_meta_info] PRIMARY KEY CLUSTERED 
(
	[file_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_file_type_meta_info_K2] UNIQUE NONCLUSTERED 
(
	[file_type_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[file_version_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_version_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_version_audit](
	[file_id] [int] NOT NULL,
	[from_version] [int] NOT NULL,
	[to_version] [int] NOT NULL,
	[created_date] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[approval_status_id] [int] NOT NULL,
	[file_version_audit_id] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_file_version_audit_id] PRIMARY KEY CLUSTERED 
(
	[file_version_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[fls_node_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[fls_node_br_assoc](
	[flsba_id] [int] IDENTITY(1,1) NOT NULL,
	[flsni_id] [int] NOT NULL,
	[business_rule_id] [int] NOT NULL,
	[rule_execution_sequence] [int] NOT NULL,
	[rule_execution_comment] [varchar](200) NULL,
	[is_active] [bit] NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[fls_node_br_assoc] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[fls_node_br_assoc] ADD [created_date_time] [datetime] NOT NULL
ALTER TABLE [dbo].[fls_node_br_assoc] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[fls_node_br_assoc] ADD [updated_date_time] [datetime] NULL
 CONSTRAINT [PK_fls_node_br_assoc] PRIMARY KEY CLUSTERED 
(
	[flsba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[fls_node_delimiter_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_delimiter_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[fls_node_delimiter_info](
	[flsndi_id] [int] IDENTITY(1,1) NOT NULL,
	[file_identifier] [int] NOT NULL,
	[node_name] [varchar](50) NOT NULL,
	[node_delimiter] [varchar](5) NULL,
	[is_active] [bit] NULL,
	[created_by] [varchar](50) NULL,
	[created_date_time] [datetime] NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[node_terminator] [varchar](5) NULL,
 CONSTRAINT [PK_fls_node_delimiter_info] PRIMARY KEY CLUSTERED 
(
	[flsndi_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[fls_node_dm_element_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_dm_element_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[fls_node_dm_element_assoc](
	[flsnda_id] [int] IDENTITY(1,1) NOT NULL,
	[flsni_id] [int] NOT NULL,
	[faa_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_flsnda_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_fls_node_dm_element_assoc] PRIMARY KEY CLUSTERED 
(
	[flsnda_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[fls_node_enum_value_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_enum_value_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[fls_node_enum_value_assoc](
	[faeva_id] [int] IDENTITY(1,1) NOT NULL,
	[flsni_id] [int] NOT NULL,
	[ctaeva_id] [int] NOT NULL,
	[enum_value] [varchar](50) NOT NULL,
	[enum_value_description] [varchar](500) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_faeva_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_fls_node_enum_value_assoc] PRIMARY KEY CLUSTERED 
(
	[faeva_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_data_source_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_data_source_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_data_source_info](
	[source_id] [int] IDENTITY(1,1) NOT NULL,
	[source_name] [varchar](50) NOT NULL,
	[source_description] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_idis_data_source_info] PRIMARY KEY CLUSTERED 
(
	[source_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_dbrd_func]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_dbrd_func]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_dbrd_func](
	[functionality_id] [int] IDENTITY(1,1) NOT NULL,
	[functionality_name] [varchar](50) NOT NULL,
	[functionality_desc] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_idis_dbrd_func] PRIMARY KEY CLUSTERED 
(
	[functionality_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_dbrd_func_actions]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_dbrd_func_actions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_dbrd_func_actions](
	[action_id] [int] IDENTITY(1,1) NOT NULL,
	[action_name] [varchar](50) NOT NULL,
	[functionality_id] [int] NOT NULL,
	[is_allowed_on_prod] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
	[is_group_check_applicable] [bit] NOT NULL CONSTRAINT [DF_idis_dbrd_func_actions_is_grp_chk_app]  DEFAULT ((0)),
 CONSTRAINT [PK_idis_dbrd_func_actions] PRIMARY KEY CLUSTERED 
(
	[action_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_priority_sequence]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_priority_sequence]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_priority_sequence](
	[idis_priority_sequence_id] [int] IDENTITY(1,1) NOT NULL,
	[idis_priority_sequence] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_idis_priority_sequence] PRIMARY KEY CLUSTERED 
(
	[idis_priority_sequence_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_team]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_team]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_team](
	[idis_team_id] [int] IDENTITY(1,1) NOT NULL,
	[idis_team_name] [varchar](40) NOT NULL,
	[idis_team_description] [varchar](200) NULL,
	[idis_team_common_email_id] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_idis_team] PRIMARY KEY CLUSTERED 
(
	[idis_team_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_idis_team_K2] UNIQUE NONCLUSTERED 
(
	[idis_team_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[idis_team_file_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[idis_team_file_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[idis_team_file_association](
	[idis_team_file_association_id] [int] IDENTITY(1,1) NOT NULL,
	[idis_team_id] [int] NOT NULL,
	[created_date] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[file_identifier] [int] NULL,
 CONSTRAINT [PK_idis_team_file_association] PRIMARY KEY CLUSTERED 
(
	[idis_team_file_association_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[INT_GROUP_TO_MESSAGE]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INT_GROUP_TO_MESSAGE]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[INT_GROUP_TO_MESSAGE](
	[GROUP_KEY] [char](36) NOT NULL,
	[MESSAGE_ID] [char](36) NOT NULL,
	[REGION] [varchar](100) NOT NULL,
 CONSTRAINT [GROUP_TO_MESSAGE_PK] PRIMARY KEY CLUSTERED 
(
	[GROUP_KEY] ASC,
	[MESSAGE_ID] ASC,
	[REGION] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[INT_MESSAGE]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INT_MESSAGE]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[INT_MESSAGE](
	[MESSAGE_ID] [char](36) NOT NULL,
	[REGION] [varchar](100) NOT NULL,
	[CREATED_DATE] [datetime] NOT NULL,
	[MESSAGE_BYTES] [image] NULL,
 CONSTRAINT [MESSAGE_PK] PRIMARY KEY CLUSTERED 
(
	[MESSAGE_ID] ASC,
	[REGION] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_INT_MESSAGE_K3] UNIQUE NONCLUSTERED 
(
	[CREATED_DATE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[INT_MESSAGE_GROUP]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INT_MESSAGE_GROUP]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[INT_MESSAGE_GROUP](
	[GROUP_KEY] [char](36) NOT NULL,
	[REGION] [varchar](100) NOT NULL,
	[MARKED] [bigint] NULL,
	[COMPLETE] [bigint] NULL,
	[LAST_RELEASED_SEQUENCE] [bigint] NULL,
	[CREATED_DATE] [datetime] NOT NULL,
	[UPDATED_DATE] [datetime] NULL DEFAULT (NULL),
 CONSTRAINT [MESSAGE_GROUP_PK] PRIMARY KEY CLUSTERED 
(
	[GROUP_KEY] ASC,
	[REGION] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[job_details]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[job_details]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[job_details](
	[job_id] [int] IDENTITY(1,1) NOT NULL,
	[job_creation_datetime] [datetime] NULL,
	[job_expected_start_datetime] [date] NULL,
	[job_actual_start_datetime] [datetime] NULL,
	[total_records_in_file] [int] NULL,
	[total_records_processed_adapt] [int] NULL,
	[total_records_processed_external] [int] NULL,
	[total_error_records] [int] NULL,
	[job_status] [varchar](50) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[job_details] ADD [job_status_notes] [varchar](200) NULL
ALTER TABLE [dbo].[job_details] ADD [file_processing_priority] [int] NULL
ALTER TABLE [dbo].[job_details] ADD [job_completion_datetime] [datetime] NULL
ALTER TABLE [dbo].[job_details] ADD [file_processing_schedule_id] [int] NULL
ALTER TABLE [dbo].[job_details] ADD [file_data_extraction_mode] [varchar](10) NOT NULL CONSTRAINT [DF_job_details_file_data_extraction_mode]  DEFAULT ('Full')
ALTER TABLE [dbo].[job_details] ADD [job_soft_deleted] [bit] NOT NULL CONSTRAINT [DF_job_details_soft_deleted]  DEFAULT ((0))
ALTER TABLE [dbo].[job_details] ADD [created_by] [varchar](50) NULL
ALTER TABLE [dbo].[job_details] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[job_details] ADD [updated_date] [datetime] NULL
ALTER TABLE [dbo].[job_details] ADD [job_file_full_path] [varchar](250) NULL DEFAULT ('')
ALTER TABLE [dbo].[job_details] ADD [job_reprioritization_notes] [varchar](500) NULL
ALTER TABLE [dbo].[job_details] ADD [total_warning_records] [int] NULL
SET ANSI_PADDING ON
ALTER TABLE [dbo].[job_details] ADD [job_status_details] [varchar](300) NULL
ALTER TABLE [dbo].[job_details] ADD [total_error_records_external] [int] NULL
ALTER TABLE [dbo].[job_details] ADD [total_ignored_records] [int] NULL
ALTER TABLE [dbo].[job_details] ADD [file_identifier] [int] NULL
ALTER TABLE [dbo].[job_details] ADD [test_cfg] [varchar](20) NULL
ALTER TABLE [dbo].[job_details] ADD [explicit_high_prioritization] [bit] NOT NULL CONSTRAINT [DF_job_details_explicit_high_prioritization]  DEFAULT ((0))
ALTER TABLE [dbo].[job_details] ADD [explicit_low_prioritization] [bit] NOT NULL CONSTRAINT [DF_job_details_explicit_low_prioritization]  DEFAULT ((0))
ALTER TABLE [dbo].[job_details] ADD [explicit_prioritization_date] [datetime] NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[job_details] ADD [test_cfg_config] [varchar](20) NULL
ALTER TABLE [dbo].[job_details] ADD [external_file_uploaded] [bit] NULL
 CONSTRAINT [PK_job_details] PRIMARY KEY CLUSTERED 
(
	[job_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[job_details_prioritization]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[job_details_prioritization]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[job_details_prioritization](
	[job_detail_prioritization_id] [bigint] IDENTITY(1,1) NOT NULL,
	[job_id] [int] NOT NULL,
	[job_status] [varchar](20) NOT NULL,
	[job_priority] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_job_details_prioritization_id] PRIMARY KEY CLUSTERED 
(
	[job_detail_prioritization_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[job_details_prioritization_staging]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[job_details_prioritization_staging]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[job_details_prioritization_staging](
	[job_detail_prioritization_staging_id] [bigint] IDENTITY(1,1) NOT NULL,
	[job_id] [int] NOT NULL,
	[job_status] [varchar](20) NOT NULL,
	[job_priority] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_job_details_prioritization_staging_id] PRIMARY KEY CLUSTERED 
(
	[job_detail_prioritization_staging_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[job_event_log]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[job_event_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[job_event_log](
	[jel_id] [int] IDENTITY(1,1) NOT NULL,
	[jel_time] [datetime] NOT NULL,
	[jel_file_id] [int] NOT NULL,
	[jel_file_version] [int] NOT NULL,
	[jel_job_id] [int] NOT NULL,
	[jel_client_id] [int] NOT NULL,
	[jel_resource_name] [varchar](50) NULL,
	[jel_resource_instance] [varchar] (50) NULL,
	[jel_resource_version]  [varchar] (50) NULL,
	[jel_host]  [varchar] (50) NULL,
	[jel_event_type] [varchar] (50) NULL,
	[jel_intn_ref_id] [varchar] (50) NULL,
	[jel_attribute_name] [varchar] (50) NULL,
	[jel_message] [varchar] (max) NULL,
	[jel_clone_number] [int] NULL,
	[jel_file_identifier] [int] NULL
 CONSTRAINT [PK_jel] PRIMARY KEY CLUSTERED 
(
	[jel_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[job_prioritization_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[job_prioritization_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[job_prioritization_audit](
	[job_prioritization_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[job_prioritization_status] [varchar](10) NOT NULL,
	[job_prioritization_start_time] [datetime] NOT NULL,
	[job_prioritization_end_time] [datetime] NULL,
	[source_instance] [varchar](20) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_job_prioritization_audit_id] PRIMARY KEY CLUSTERED 
(
	[job_prioritization_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[lob]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lob]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[lob](
	[lob_id] [int] IDENTITY(1,1) NOT NULL,
	[lob_name] [varchar](100) NOT NULL,
	[lob_description] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_lob_is_active]  DEFAULT ((1)),
	[unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_lob] PRIMARY KEY CLUSTERED 
(
	[lob_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[lookup_table_composite_key_mapping]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_composite_key_mapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[lookup_table_composite_key_mapping](
	[ltckm_id] [int] IDENTITY(1,1) NOT NULL,
	[lookup_table_id] [int] NOT NULL,
	[lookup_table_version] [int] NOT NULL,
	[ltckm_type] [varchar](20) NOT NULL,
	[ltckm_description] [varchar](500) NULL,
	[ltckm_order] [int] NULL,
	[datamart_element_id] [int] NULL,
	[business_rule_id] [int] NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_lookup_table_composite_key_mapping] PRIMARY KEY CLUSTERED 
(
	[ltckm_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[lookup_table_details]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_details]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[lookup_table_details](
	[lookup_detail_id] [int] IDENTITY(1,1) NOT NULL,
	[lookup_table_id] [int] NOT NULL,
	[lookup_table_version] [int] NOT NULL,
	[lookup_key] [varchar](512) NOT NULL,
	[lookup_value] [varchar](512) NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[lookup_table_details] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[lookup_table_details] ADD [created_date_time] [datetime] NOT NULL
 CONSTRAINT [PK_lookup_table_details] PRIMARY KEY CLUSTERED 
(
	[lookup_detail_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[lookup_table_file_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[lookup_table_file_association](
	[record_id] [int] IDENTITY(1,1) NOT NULL,
	[lookup_table_id] [int] NOT NULL,
	[lookup_table_version] [int] NOT NULL,
	[faa_id] [int] NULL,
	[mftaa_id] [int] NULL,
	[cftaa_id] [int] NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_lookup_table_file_association] PRIMARY KEY CLUSTERED 
(
	[record_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[lookup_table_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[lookup_table_meta_info](
	[lookup_table_id] [int] IDENTITY(1,1) NOT NULL,
	[lookup_table_name] [varchar](100) NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [lookup_key_description] [varchar](255) NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [associated_file_level] [varchar](10) NOT NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [associated_file_type_id] [int] NOT NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [created_date_time] [datetime] NOT NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [associated_file_level_id] [int] NULL
ALTER TABLE [dbo].[lookup_table_meta_info] ADD [lookup_table_version] [int] NULL
 CONSTRAINT [PK_lookup_table_meta_info] PRIMARY KEY CLUSTERED 
(
	[lookup_table_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_auth_key_details]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_auth_key_details]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_auth_key_details](
	[master_auth_key_id] [int] IDENTITY(1,1) NOT NULL,
	[master_key_name] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[expiration_date_time] [datetime] NULL,
	[is_active] [bit] NOT NULL,
	[private_key] [varbinary](max) NOT NULL,
	[public_key] [varchar](max) NOT NULL,
	[key_algorithm] [varchar](50) NOT NULL,
 CONSTRAINT [PK_master_auth_key_id] PRIMARY KEY CLUSTERED 
(
	[master_auth_key_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_file_template_attr_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_attr_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_file_template_attr_br_assoc](
	[mft_attr_br_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[mftaa_id] [int] NOT NULL,
	[business_rule_id] [int] NULL,
	[rule_execution_sequence] [int] NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_master_file_template_attr_br_assoc] PRIMARY KEY CLUSTERED 
(
	[mft_attr_br_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_master_file_template_attr_br_assoc_K2_K3_K5] UNIQUE NONCLUSTERED 
(
	[mftaa_id] ASC,
	[business_rule_id] ASC,
	[rule_execution_sequence] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_file_template_attribute_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_attribute_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_file_template_attribute_association](
	[mftaa_id] [int] IDENTITY(1,1) NOT NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[attribute_id] [int] NOT NULL,
	[data_type] [varchar](50) NOT NULL,
	[is_mandatory] [bit] NOT NULL CONSTRAINT [DF_mftaa_is_mandatory]  DEFAULT ((0)),
	[attribute_row_position] [int] NULL,
	[application_compliant_attribute_name] [varchar](50) NULL,
	[mftsa_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[master_file_template_record_id] [int] NOT NULL,
	[max_size_allowed] [int] NULL,
	[ftaa_id] [int] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_master_file_template_attribute_association] PRIMARY KEY CLUSTERED 
(
	[mftaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_file_template_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_file_template_meta_info](
	[master_file_template_name] [varchar](100) NOT NULL,
	[master_file_template_description] [varchar](255) NULL,
	[file_type_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[approval_status_id] [int] NULL,
	[approval_status_updated_by] [varchar](50) NULL,
	[approval_status_updated_date] [datetime] NULL,
	[approval_status_comment] [varchar](200) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[edited_by] [varchar](50) NULL,
	[editor_comment] [varchar](200) NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[master_file_template_record_id] [int] IDENTITY(1,1) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_master_file_template_meta_info_record_id] PRIMARY KEY CLUSTERED 
(
	[master_file_template_record_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_master_file_template_meta_info_id_version] UNIQUE NONCLUSTERED 
(
	[master_file_template_id] ASC,
	[master_file_template_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_file_template_section_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_section_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_file_template_section_assoc](
	[mftsa_id] [int] IDENTITY(1,1) NOT NULL,
	[template_section_id] [int] NOT NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[template_compliant_section_short_name] [varchar](20) NULL,
	[sequence] [smallint] NOT NULL,
	[is_madatory] [bit] NOT NULL DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[master_file_template_record_id] [int] NOT NULL,
	[section_display_name] [varchar](50) NULL,
	[section_standardized_name] [varchar](150) NULL,
 CONSTRAINT [pk_master_file_template_section_assoc] PRIMARY KEY CLUSTERED 
(
	[mftsa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_file_template_version_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_version_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_file_template_version_audit](
	[master_template_id] [int] NOT NULL,
	[from_version] [int] NOT NULL,
	[to_version] [int] NOT NULL,
	[created_date] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[approval_status_id] [int] NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_template_layout_schema_node_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_template_layout_schema_node_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_template_layout_schema_node_assoc](
	[mtlsna_id] [int] IDENTITY(1,1) NOT NULL,
	[mtlsni_id] [int] NOT NULL,
	[parent_mtlsni_id] [int] NULL,
	[node_has_children] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_mtlsna_has_chilren]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_master_template_layout_schema_node_assoc] PRIMARY KEY CLUSTERED 
(
	[mtlsna_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[master_template_layout_schema_node_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[master_template_layout_schema_node_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[master_template_layout_schema_node_info](
	[mtlsni_id] [int] IDENTITY(1,1) NOT NULL,
	[master_file_template_record_id] [int] NOT NULL,
	[node_category] [varchar](50) NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_display_name] [varchar](100) NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_data_type_id] [int] NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_min_count] [int] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_max_count] [int] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_ref_num] [int] NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_row_position] [int] NOT NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_description] [varchar](500) NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_is_mandatory] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_mtlsni_is_mandatory]  DEFAULT ((0))
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_cond_description] [varchar](500) NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [mapped_column_type] [varchar](50) NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [mapped_template_section_id] [int] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_section_short_name] [char](1) NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_mtlsni_is_active]  DEFAULT ((1))
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [created_date_time] [datetime] NOT NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [updated_date_time] [datetime] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_max_size] [int] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [node_min_size] [int] NULL
ALTER TABLE [dbo].[master_template_layout_schema_node_info] ADD [mapped_column_order] [int] NULL
 CONSTRAINT [PK_master_template_layout_schema_node_info] PRIMARY KEY CLUSTERED 
(
	[mtlsni_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[mftaa_valid_value_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[mftaa_valid_value_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[mftaa_valid_value_assoc](
	[mftaa_valid_value_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[master_file_template_id] [int] NOT NULL,
	[master_file_template_version] [int] NOT NULL,
	[mftaa_id] [int] NOT NULL,
	[valid_value_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_mftaa_valid_value_assoc] PRIMARY KEY CLUSTERED 
(
	[mftaa_valid_value_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[mtls_node_br_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[mtls_node_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[mtls_node_br_assoc](
	[mtlsnba_id] [int] IDENTITY(1,1) NOT NULL,
	[mtlsni_id] [int] NOT NULL,
	[business_rule_id] [int] NOT NULL,
	[rule_execution_sequence] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_mtls_node_br_assoc] PRIMARY KEY CLUSTERED 
(
	[mtlsnba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[mtls_node_dm_element_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[mtls_node_dm_element_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[mtls_node_dm_element_assoc](
	[mtlsda_id] [int] IDENTITY(1,1) NOT NULL,
	[mtlsni_id] [int] NOT NULL,
	[mftaa_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_mtlsda_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_mtls_node_dm_element_assoc] PRIMARY KEY CLUSTERED 
(
	[mtlsda_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[mtls_node_enum_value_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[mtls_node_enum_value_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[mtls_node_enum_value_assoc](
	[mtaeva_id] [int] IDENTITY(1,1) NOT NULL,
	[mtlsni_id] [int] NOT NULL,
	[enum_value] [varchar](50) NOT NULL,
	[enum_value_description] [varchar](500) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_CONSTRAINT_mtaeva_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_mtls_node_enum_value_assoc] PRIMARY KEY CLUSTERED 
(
	[mtaeva_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[notification_template_file_type_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_template_file_type_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[notification_template_file_type_assoc](
	[ntft_id] [int] IDENTITY(1,1) NOT NULL,
	[notification_template_id] [int] NOT NULL,
	[file_type_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_notification_template_file_type_assoc] PRIMARY KEY CLUSTERED 
(
	[ntft_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[notification_template_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_template_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[notification_template_info](
	[template_id] [int] IDENTITY(1,1) NOT NULL,
	[template_name] [varchar](80) NOT NULL,
	[event_id] [int] NOT NULL,
	[from_address] [varchar](80) NOT NULL,
	[file_type_assoc_mapping] [varchar](20) NOT NULL,
	[is_time_bound] [bit] NOT NULL DEFAULT ((0)),
	[time_to_wait] [time](7) NULL,
	[is_active] [bit] NOT NULL DEFAULT ((0)),
	[always_send_internal] [bit] NOT NULL DEFAULT ((0)),
	[always_send_external] [bit] NOT NULL DEFAULT ((0)),
	[internal_notification_text] [nvarchar](max) NULL,
	[external_notification_text] [nvarchar](max) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[unique_identifier] [varchar](50) NOT NULL
CONSTRAINT [PK_notification_template_info] PRIMARY KEY CLUSTERED 
(
	[template_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[notification_template_metainfo_elements]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_template_metainfo_elements]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[notification_template_metainfo_elements](
	[ntme_id] [int] IDENTITY(1,1) NOT NULL,
	[element_name] [varchar](80) NOT NULL,
	[default_value] [varchar](200) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[templatized_name] [varchar](100) NULL,
 CONSTRAINT [PK_notification_template_metainfo_elements] PRIMARY KEY CLUSTERED 
(
	[ntme_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_notification_template_metainfo_elements_K1] UNIQUE NONCLUSTERED 
(
	[element_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[priority_classification_types]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[priority_classification_types]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[priority_classification_types](
	[priority_class_type_id] [int] IDENTITY(1,1) NOT NULL,
	[priority_class_type_name] [varchar](50) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_priority_classification_types_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_priority_classification_types] PRIMARY KEY CLUSTERED 
(
	[priority_class_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[priority_order_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[priority_order_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[priority_order_info](
	[priority_info_id] [int] IDENTITY(1,1) NOT NULL,
	[priority_class_type_id] [int] NOT NULL,
	[priority_info_type_value] [varchar](100) NOT NULL,
	[priority_info_seq_num] [int] NULL,
	[priority_info_notes] [varchar](200) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_priority_order_info_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_priority_order_info] PRIMARY KEY CLUSTERED 
(
	[priority_info_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[processing_system_events]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[processing_system_events]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[processing_system_events](
	[event_id] [int] IDENTITY(1,1) NOT NULL,
	[event_name] [varchar](80) NOT NULL,
	[event_description] [varchar](200) NULL,
	[file_direction] [varchar](1) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL
 CONSTRAINT [PK_processing_system_events] PRIMARY KEY CLUSTERED 
(
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[profiles]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[profiles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[profiles](
	[profile_id] [int] IDENTITY(1,1) NOT NULL,
	[profile_name] [varchar](50) NOT NULL,
	[profile_desc] [varchar](100) NULL,
	[for_production] [bit] NOT NULL CONSTRAINT [DF_profiles_for_production]  DEFAULT ((0)),
	[file_direction] [char](1) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_profile_active]  DEFAULT ((1))
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[profiles] ADD [unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [pk_profiles] PRIMARY KEY CLUSTERED 
(
	[profile_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[recurrence_exception_rules]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[recurrence_exception_rules]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[recurrence_exception_rules](
	[recurrence_exception_rule_id] [int] IDENTITY(1,1) NOT NULL,
	[recurrence_exception_rule_name] [varchar](70) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_recurrence_exception_rules] PRIMARY KEY CLUSTERED 
(
	[recurrence_exception_rule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[recurrence_type]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[recurrence_type]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[recurrence_type](
	[recurrence_type_id] [int] IDENTITY(1,1) NOT NULL,
	[recurrence_type_name] [varchar](70) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_recurrence_type] PRIMARY KEY CLUSTERED 
(
	[recurrence_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[roles]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[roles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[roles](
	[role_id] [int] IDENTITY(1,1) NOT NULL,
	[role_name] [varchar](50) NOT NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[roles] ADD [role_desc] [varchar](500) NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[roles] ADD [group_name] [varchar](100) NULL
ALTER TABLE [dbo].[roles] ADD [created_by] [varchar](50) NOT NULL
ALTER TABLE [dbo].[roles] ADD [created_date] [datetime] NOT NULL
ALTER TABLE [dbo].[roles] ADD [updated_by] [varchar](50) NULL
ALTER TABLE [dbo].[roles] ADD [updated_date] [datetime] NULL
 CONSTRAINT [PK_roles] PRIMARY KEY CLUSTERED 
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[roles_idis_dbrd_actions_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[roles_idis_dbrd_actions_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[roles_idis_dbrd_actions_assoc](
	[role_action_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[role_id] [int] NOT NULL,
	[action_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date] [datetime] NULL,
 CONSTRAINT [PK_roles_idis_dbrd_actions_assoc] PRIMARY KEY CLUSTERED 
(
	[role_action_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[secondary_data_api_mapped_obj]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[secondary_data_api_mapped_obj]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[secondary_data_api_mapped_obj](
	[secondary_data_api_mapped_obj_id] [int] IDENTITY(1,1) NOT NULL,
	[secondary_data_api_mapped_obj_version] [int] NOT NULL,
	[secondary_data_api_mapped_obj_pkg_name] [varchar](100) NOT NULL,
	[secondary_data_api_mapped_obj_pojo_name] [varchar](50) NOT NULL,
	[secondary_data_api_mapped_obj_endpoint] [varchar](500) NOT NULL,
	[secondary_data_api_mapped_obj_is_active] [bit] NOT NULL CONSTRAINT [DF_secondary_data_api_mapped_obj_is_active]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date] [datetime] NOT NULL,
 CONSTRAINT [PK_secondary_data_api_mapped_obj] PRIMARY KEY CLUSTERED 
(
	[secondary_data_api_mapped_obj_id] ASC,
	[secondary_data_api_mapped_obj_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[template_sections]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[template_sections]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[template_sections](
	[template_section_id] [int] IDENTITY(1,1) NOT NULL,
	[section_name] [varchar](150) NOT NULL,
	[section_description] [varchar](500) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [pk_template_section_id] PRIMARY KEY CLUSTERED 
(
	[template_section_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tooltip_meta_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tooltip_meta_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tooltip_meta_info](
	[tooltip_id] [int] IDENTITY(1,1) NOT NULL,
	[tooltip_field_id] [int] NOT NULL,
	[tooltip_desc] [varchar](500) NOT NULL,
	[tooltip_is_display] [bit] NOT NULL CONSTRAINT [DF_tooltip_is_display]  DEFAULT ((0)),
	[tooltip_read_more_link] [varchar](200) NULL,
	[tooltip_language_code] [varchar](5) NOT NULL CONSTRAINT [DF_tooltip_lang_code]  DEFAULT ('EN'),
	[created_by] [varchar](50) NOT NULL,
	[updated_by] [varchar](50) NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_date_time] [datetime] NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[tooltip_meta_info] ADD [unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_tooltip_meta_info] PRIMARY KEY CLUSTERED 
(
	[tooltip_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_auth_key_details]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_auth_key_details]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_auth_key_details](
	[trading_partner_auth_key_details_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_auth_key_info_id] [int] NOT NULL,
	[is_public_key] [bit] NULL,
	[is_encrypted] [bit] NULL,
	[trading_partner_auth_key] [varchar](max) NOT NULL,
	[trading_partner_auth_key_algorithm] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_trading_partner_auth_key_details_id] PRIMARY KEY CLUSTERED 
(
	[trading_partner_auth_key_details_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_auth_key_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_auth_key_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_auth_key_info](
	[trading_partner_auth_key_info_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[trading_partner_platform_id] [int] NULL,
	[direction] [varchar](1) NOT NULL,
	[trading_partner_auth_key_name] [varchar](50) NOT NULL,
	[trading_partner_auth_key_desc] [varchar](200) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_is_active]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_trading_partner_auth_key_info_id] PRIMARY KEY CLUSTERED 
(
	[trading_partner_auth_key_info_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_connection_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_connection_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_connection_info](
	[trading_partner_connection_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[trading_partner_platform_id] [int] NULL,
	[tpci_delivery_mechanism_type_id] [int] NOT NULL,
	[tpci_transfer_protocol_id] [int] NOT NULL,
	[tpci_server_host] [varchar](50) NULL,
	[tpci_server_port] [int] NULL,
	[tpci_username] [varchar](50) NOT NULL,
	[tpci_password] [varbinary](max) NULL,
	[tpci_is_active] [bit] NULL CONSTRAINT [DF_tpci_is_active]  DEFAULT ((0)),
	[tpci_storage_path] [varchar](150) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[tpci_adapt_env_id] [int] NOT NULL,
	[tpci_contact_id] [int] NULL,
	[unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_trading_partner_connection_info] PRIMARY KEY CLUSTERED 
(
	[trading_partner_connection_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_contact_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_contact_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_contact_info](
	[trading_partner_contact_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_contact_title] [varchar](20) NULL,
	[trading_partner_contact_first_name] [varchar](50) NULL,
	[trading_partner_contact_last_name] [varchar](50) NULL,
	[trading_partner_contact_email] [varchar](50) NULL,
	[trading_partner_contact_phone] [varchar](16) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[trading_partner_contact_phone_ext] [varchar](10) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_trading_partner_contact_info_K13]  DEFAULT ((0)),
	[trading_partner_contact_type_id] [int] NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[trading_partner_contact_info] ADD [unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_trading_partner_contact_info] PRIMARY KEY CLUSTERED 
(
	[trading_partner_contact_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_contact_tpp_assoc]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_contact_tpp_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_contact_tpp_assoc](
	[trading_partner_contact_tpp_assoc_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_platform_id] [int] NOT NULL,
	[trading_partner_contact_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_trading_partner_contact_tpp_assoc_K4]  DEFAULT ((1)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_trading_partner_contact_tpp_assoc] PRIMARY KEY CLUSTERED 
(
	[trading_partner_contact_tpp_assoc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_trading_partner_contact_tpp_assoc_K2_K3] UNIQUE NONCLUSTERED 
(
	[trading_partner_platform_id] ASC,
	[trading_partner_contact_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_contact_type]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_contact_type]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_contact_type](
	[trading_partner_contact_type_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_contact_type_name] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_trading_partner_contact_type] PRIMARY KEY CLUSTERED 
(
	[trading_partner_contact_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_info](
	[trading_partner_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_name] [varchar](100) NOT NULL,
	[trading_partner_description] [varchar](200) NULL,
	[trading_partner_type] [varchar](50) NOT NULL,
	[trading_partner_is_consenting] [bit] NOT NULL CONSTRAINT [DF_trading_partner_info_trading_partner_is_consenting]  DEFAULT ((1)),
	[trading_partner_employer_id] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[active] [bit] NOT NULL CONSTRAINT [DF_trading_partner_info_active]  DEFAULT ((1))
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[trading_partner_info] ADD [unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_trading_partner_info] PRIMARY KEY CLUSTERED 
(
	[trading_partner_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_lob_association]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_lob_association]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_lob_association](
	[trading_partner_lob_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[lob_id] [int] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
 CONSTRAINT [PK_trading_partner_lob_association] PRIMARY KEY CLUSTERED 
(
	[trading_partner_lob_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[trading_partner_platform_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_platform_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[trading_partner_platform_info](
	[trading_partner_platform_id] [int] IDENTITY(1,1) NOT NULL,
	[trading_partner_id] [int] NOT NULL,
	[trading_partner_platform_name] [varchar](100) NOT NULL,
	[trading_partner_platform_desc] [varchar](200) NULL,
	[is_active] [bit] NOT NULL CONSTRAINT [DF_TPPI_IS_ACTIVE]  DEFAULT ((0)),
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[unique_identifier] [varchar](50) NOT NULL
 CONSTRAINT [PK_trading_partner_platform_info] PRIMARY KEY CLUSTERED 
(
	[trading_partner_platform_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[transfer_protocol_info]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[transfer_protocol_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[transfer_protocol_info](
	[transfer_protocol_id] [int] IDENTITY(1,1) NOT NULL,
	[transfer_protocol_name] [varchar](10) NOT NULL,
	[transfer_protocol_desc] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_transfer_protocol_info] PRIMARY KEY CLUSTERED 
(
	[transfer_protocol_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_transfer_protocol_info_K2] UNIQUE NONCLUSTERED 
(
	[transfer_protocol_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[upload_file_audit]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[upload_file_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[upload_file_audit](
	[upload_file_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[job_id] [int] NOT NULL,
	[uploaded_by] [varchar](50) NOT NULL,
	[uploaded_date] [datetime] NOT NULL,
	[upload_file_name] [varchar](50) NOT NULL,
	[file_storage_path] [varchar](100) NOT NULL,
 CONSTRAINT [PK_upload_file_audit] PRIMARY KEY CLUSTERED 
(
	[upload_file_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[valid_value_groups]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[valid_value_groups]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[valid_value_groups](
	[valid_value_group_id] [int] IDENTITY(1,1) NOT NULL,
	[valid_value_group_name] [varchar](50) NOT NULL,
	[valid_value_group_desc] [varchar](100) NULL,
	[validation_type_id] [int] NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_valid_value_groups] PRIMARY KEY CLUSTERED 
(
	[valid_value_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_valid_value_groups_K4_K2] UNIQUE NONCLUSTERED 
(
	[validation_type_id] ASC,
	[valid_value_group_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[valid_values]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[valid_values]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[valid_values](
	[valid_value_id] [int] IDENTITY(1,1) NOT NULL,
	[valid_value_name] [varchar](50) NOT NULL,
	[valid_value_desc] [varchar](100) NULL,
	[valid_value_group_id] [int] NULL,
	[is_active] [bit] NOT NULL,
	[valid_value_standardized_name] [varchar](50) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_valid_values] PRIMARY KEY CLUSTERED 
(
	[valid_value_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_valid_values_K4_K2] UNIQUE NONCLUSTERED 
(
	[valid_value_group_id] ASC,
	[valid_value_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[validation_types]    Script Date: 4/29/2019 3:58:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[validation_types]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[validation_types](
	[validation_type_id] [int] IDENTITY(1,1) NOT NULL,
	[validation_type_name] [varchar](50) NOT NULL,
	[validation_type_desc] [varchar](100) NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_validation_types] PRIMARY KEY CLUSTERED 
(
	[validation_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_validation_types_K2] UNIQUE NONCLUSTERED 
(
	[validation_type_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_ctlsnba_rule_seq]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ctls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_ctlsnba_rule_seq]  DEFAULT ((0)) FOR [rule_execution_sequence]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_ctlsnba_is_active]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ctls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_ctlsnba_is_active]  DEFAULT ((1)) FOR [is_active]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_flsba_rule_seq]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[fls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_flsba_rule_seq]  DEFAULT ((0)) FOR [rule_execution_sequence]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_flsba_is_active]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[fls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_flsba_is_active]  DEFAULT ((1)) FOR [is_active]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_job_details_prioritization_is_active]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[job_details_prioritization] ADD  CONSTRAINT [DF_job_details_prioritization_is_active]  DEFAULT ((1)) FOR [is_active]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_job_details_prioritization_staging_is_active]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[job_details_prioritization_staging] ADD  CONSTRAINT [DF_job_details_prioritization_staging_is_active]  DEFAULT ((1)) FOR [is_active]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_mtlsnba_rule_seq]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[mtls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_mtlsnba_rule_seq]  DEFAULT ((0)) FOR [rule_execution_sequence]
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_CONSTRAINT_mtlsnba_is_active]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[mtls_node_br_assoc] ADD  CONSTRAINT [DF_CONSTRAINT_mtlsnba_is_active]  DEFAULT ((1)) FOR [is_active]
END

GO
