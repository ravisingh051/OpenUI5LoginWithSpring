use [idis-metainfo]

---- User should be able to see renamed word for "Promotion" as "Migration"  -----------

if not exists(select 1 from config_promotion_status where config_promotion_status_id = 4 and config_promotion_status_name = 'Migration Initiated')
BEGIN
	update config_promotion_status set config_promotion_status_name = 'Migration Initiated' where config_promotion_status_id = 4
END;
GO
if not exists(select 1 from config_promotion_status where config_promotion_status_id = 5 and config_promotion_status_name = 'Migration Completed')
BEGIN
	update config_promotion_status set config_promotion_status_name = 'Migration Completed' where config_promotion_status_id = 5
END;
GO
if not exists(select 1 from config_promotion_status where config_promotion_status_id = 6 and config_promotion_status_name = 'Migration Failed')
BEGIN
	update config_promotion_status set config_promotion_status_name = 'Migration Failed' where config_promotion_status_id = 6
END;
GO

if not exists(select 1 from [dbo].[adapt_web_pages] where adapt_web_page_id = 28 and [adapt_web_pages_name] = 'New file setup-Migration')
BEGIN
update [adapt_web_pages] set [adapt_web_pages_name] = 'New file setup-Migration', [adapt_web_pages_desc] = 'New file setup-Migration' where adapt_web_page_id = 28
END;
GO
if not exists(select 1 from [dbo].[adapt_web_pages] where adapt_web_page_id = 38 and [adapt_web_pages_name] = 'Approve Migration')
BEGIN
update [adapt_web_pages] set [adapt_web_pages_name] = 'Approve Migration', [adapt_web_pages_desc] = 'Approve Migration' where adapt_web_page_id = 38
END;
GO


if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 177 and [adapt_web_page_field_name] = 'Last Migrated')
BEGIN	
update [dbo].[adapt_web_page_fields] set [adapt_web_page_field_name] = 'Last Migrated', [adapt_web_page_field_desc] = 'Last Migrated' where adapt_web_page_field_id = 177
END;
GO

if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 178 and [adapt_web_page_field_name] = 'Last Migration Comments')
BEGIN	
update [dbo].[adapt_web_page_fields] set [adapt_web_page_field_name] = 'Last Migration Comments', [adapt_web_page_field_desc] = 'Last Migration Comments' where adapt_web_page_field_id = 178
END;
GO

if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 181 and [adapt_web_page_field_name] = 'Migration Comments')
BEGIN	
update [dbo].[adapt_web_page_fields] set [adapt_web_page_field_name] = 'Migration Comments', [adapt_web_page_field_desc] = 'Migration Comments' where adapt_web_page_field_id = 181
END;
GO

if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 239 and [adapt_web_page_field_name] = 'Migration Comments')
BEGIN	
update [dbo].[adapt_web_page_fields] set [adapt_web_page_field_name] = 'Migration Comments', [adapt_web_page_field_desc] = 'Migration Comments' where adapt_web_page_field_id = 239
END;
GO

if not exists(select 1 from [dbo].[adapt_web_page_fields] where adapt_web_page_field_id = 273 and [adapt_web_page_field_name] = 'Last Migration Ver')
BEGIN	
update [dbo].[adapt_web_page_fields] set [adapt_web_page_field_name] = 'Last Migration Ver', [adapt_web_page_field_desc] = 'Last Migration Ver' where adapt_web_page_field_id = 273

END;
GO