use [idis-metainfo]
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Richa Ashara
-- Create date:  11/26/2018 11:00:00 PM 
-- Description:	This Store Procedure Deletes already cloned attributes in file.
/*
update log 
    Date			Author		  Details
------------	-----------------	 ----------------------------------------------------------------------------------------
2019-11-21	Jinesh Vora				ADAPT-8515 : System allowed discard draft even after job run for draft version
*/
-- =============================================

IF OBJECT_ID('dbo.USP_File_clone_deletion') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_File_clone_deletion AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_File_clone_deletion]
	-- Add the parameters for the stored procedure here
	@ifile_identifier INT,
	@iclone_num INT,
	@oError_code int OUTPUT
				
AS
BEGIN

BEGIN TRY
	BEGIN TRANSACTION  
	
    SET NOCOUNT ON;

	IF OBJECT_ID('tempdb..#TEMP_DBRDT') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT; END
	CREATE TABLE #TEMP_DBRDT ( rule_id int, rule_version int)

	if (@iclone_num <= 0 )
	 BEGIN
		set @oError_code=-3;
        GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
      END 


	-- check clone number is exist or not.
      if not exists(select 1 from [dbo].[file_attribute_association]  where file_identifier = @ifile_identifier and clone_num = @iclone_num)
	 BEGIN
		set @oError_code=-2;
        GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
      END 

	 BEGIN TRANSACTION;
        BEGIN TRY
		  
	  INSERT into #TEMP_DBRDT (rule_id, rule_version)
			 (select drools_business_rule_id,drools_business_rule_version from file_attribute_association faa
			 join  file_section_association fsa on fsa.fsa_id = faa.fsa_id
			 join file_attr_br_assoc faba on faa.faa_id=faba.faa_id join drools_business_rules_decision_table dbrdt 
			 on dbrdt.drools_business_rule_id=faba.business_rule_id and faba.business_rule_version = dbrdt.drools_business_rule_version
			 where faa.[file_identifier] =@ifile_identifier and faa.clone_num = @iclone_num and fsa.file_compliant_section_short_name = 'D')

	 
	   delete from file_attr_br_assoc where faa_id in (SELECT faa_id from file_attribute_association faa inner join  file_section_association fsa on fsa.fsa_id = faa.fsa_id
	   where faa.clone_num = @iclone_num and faa.file_identifier = @ifile_identifier and fsa.file_compliant_section_short_name = 'D')

	   delete rules from drools_business_rules_decision_table rules inner join  #TEMP_DBRDT temp  on temp.rule_id = rules.drools_business_rule_id and temp.rule_version = rules.drools_business_rule_version 
	
	   DELETE from lookup_table_file_association where faa_id in (SELECT faa_id from file_attribute_association faa inner join  file_section_association fsa on fsa.fsa_id = faa.fsa_id
	   where faa.clone_num = @iclone_num and faa.file_identifier = @ifile_identifier and fsa.file_compliant_section_short_name = 'D')

	   DELETE FROM [dbo].[file_secondary_mapping_attr_assoc] where fsmaa_faa_id in (select faa_id from file_attribute_association  faa
			 join  file_section_association fsa on fsa.fsa_id = faa.fsa_id  where faa.[file_identifier] =@ifile_identifier
			  and faa.clone_num = @iclone_num and fsa.file_compliant_section_short_name = 'D')
	   
	   delete from file_attribute_association where faa_id in (select faa_id from file_attribute_association  faa
			 join  file_section_association fsa on fsa.fsa_id = faa.fsa_id  where faa.[file_identifier] =@ifile_identifier
			  and faa.clone_num = @iclone_num and fsa.file_compliant_section_short_name = 'D')

	   delete from file_clone_info where file_identifier = @ifile_identifier and clone_num = @iclone_num


	COMMIT TRANSACTION;
		SET @oError_code = 0;
	END TRY
	
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
	END CATCH 

	IF OBJECT_ID('tempdb..#TEMP_DBRDT') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT; END
	
		END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @oError_code = -2)
			    BEGIN
			    print 'Error: given clone number is not exists for this file ...'
			    RETURN -2
	    END
	   ELSE IF ( @oError_code = -3)
			 BEGIN
			 print 'Error: you can not delete attributes with given clone number...'
			 RETURN -1
	   END
	   ELSE IF ( @oError_code <> 0)
		  BEGIN
		  print 'Error: Some Error occured while deleting cloned attributes...'
		  RETURN -1
	   END
	   ELSE
		  BEGIN
		  print 'File cloned attributes deleted Successfully... '
		  SET @oError_code=0
		  RETURN 0
	   END 

COMMIT TRANSACTION;
END TRY

BEGIN CATCH
	
	ROLLBACK;
	THROW

END CATCH
 
  
END;
GO
-- ============================================================================ 
 --Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_File_clone_deletion
	TO exec_proc;
GO