use [idis-metainfo]
GO

/*
Filename:  V10.7064__update_processing_system_events_for_Dataset_Delivered_event.sql

Update Log
Date         Author            	Description
----------   ----------------   --------------------------------------------------------------------------------------------
2019-08-01   Jinesh Vora  		ADAPT-7064 : User should receive notification for the Outbound File Events - Dataset Delivered
*/

if EXISTS (SELECT 1 FROM processing_system_events where event_id=2 and event_name = 'Outbound File Delivered')
BEGIN
Update processing_system_events  SET event_name = 'DATASET_DELIVERED',event_description = 'Dataset Delivered',updated_by = 'Jinesh vora',updated_date_time = getdate() where event_id = 2 and event_name='Outbound File Delivered';
END;
GO
