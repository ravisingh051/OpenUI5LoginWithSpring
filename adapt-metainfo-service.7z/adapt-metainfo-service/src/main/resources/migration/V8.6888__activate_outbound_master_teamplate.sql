use [idis-metainfo]
GO

/*
Filename:  V8.6888__activate_outbound_master_teamplate.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-17   Divya Jain  		ADAPT-6888 : Activate Master Template for Outbound
*/



if not exists(select 1 from master_file_template_meta_info where is_active=1 and master_file_template_record_id=18)
begin
update master_file_template_meta_info set is_active=1 where is_active=1 and master_file_template_record_id=18
end;
GO

if not exists(select 1 from master_file_template_meta_info where is_active=0 and master_file_template_record_id in (2,17))
begin
update master_file_template_meta_info set is_active=0 where is_active=0 and master_file_template_record_id in (2,17)
end;
GO

