use [idis-metainfo]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[adapt_env_config_info]') AND name = N'IX_adapt_env_config_info_K3')
BEGIN
CREATE NONCLUSTERED INDEX [IX_adapt_env_config_info_K3] ON [dbo].adapt_env_config_info
(
	[adapt_env_abbreviation] ASC
)INCLUDE([adapt_env_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[application_audit_log]') AND name = N'IX_application_audit_log_K2_K6_K8')
CREATE NONCLUSTERED INDEX [IX_application_audit_log_K2_K6_K8] ON [dbo].[application_audit_log]
(
	[service_end_point] ASC,
	[service_HTTP_response_code] ASC,
	[created_datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[application_audit_log]') AND name = N'IX_application_audit_log_K6_K8')
CREATE NONCLUSTERED INDEX [IX_application_audit_log_K6_K8] ON [dbo].[application_audit_log]
(
	[service_HTTP_response_code] ASC,
	[created_datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[attribute_dictionary]') AND name = N'IX_attribute_association_K1_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_attribute_association_K1_K2] ON [dbo].[attribute_dictionary]
(
	attribute_id
)
INCLUDE(attribute_name)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[attribute_data_types]') AND name = N'IX_attribute_data_types_K1_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_attribute_data_types_K1_K2] ON [dbo].[attribute_data_types]
(
	attribute_data_type_id,attribute_data_type_name
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[attribute_dictionary]') AND name = N'IX_attribute_dictionary_K4_K2')
CREATE NONCLUSTERED INDEX [IX_attribute_dictionary_K4_K2] ON [dbo].[attribute_dictionary]
(
	[default_data_type] ASC,
	[attribute_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_attribute_association]') AND name = N'IX_child_file_template_attribute_association_K2_K3_K11_K1_K4')
CREATE NONCLUSTERED INDEX [IX_child_file_template_attribute_association_K2_K3_K11_K1_K4] ON [dbo].[child_file_template_attribute_association]
(
	[child_file_template_id] ASC, [child_file_template_version] ASC, [cftsa_id] ASC
)INCLUDE([cftaa_id],[attribute_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_attribute_association]') AND name = N'IX_child_file_template_attribute_association_K4')
CREATE NONCLUSTERED INDEX [IX_child_file_template_attribute_association_K4] ON [dbo].[child_file_template_attribute_association]
(
	[attribute_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K1_K6')
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K1_K6] ON [dbo].[child_file_template_meta_info]
(
	[child_file_template_id] ASC,
	[child_file_template_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_master_file_template_id]     ******/


SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K4')
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K4] ON [dbo].[child_file_template_meta_info]
(
	[master_file_template_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K7_k8')
BEGIN
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K7_k8] ON [dbo].[child_file_template_meta_info]
(
	[is_active],[approval_status_id]
)INCLUDE(child_file_template_name, master_file_template_id, master_file_template_version, trading_partner_id, child_file_template_id, child_file_template_version)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K7_k8_K18')
BEGIN
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K7_k8_K18] ON [dbo].[child_file_template_meta_info]
(
	[is_active],[approval_status_id],[child_file_template_version]
)INCLUDE(child_file_template_name, master_file_template_id, master_file_template_version, trading_partner_id, child_file_template_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K17_K18')
BEGIN
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K17_K18] ON [dbo].[child_file_template_meta_info]
(
	[child_file_template_id] ASC,[child_file_template_version]
)INCLUDE([child_file_template_record_id],[child_File_Template_Name],[trading_partner_id],[lob_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[child_file_template_meta_info]') AND name = N'IX_child_file_template_meta_info_K19')
BEGIN
CREATE NONCLUSTERED INDEX [IX_child_file_template_meta_info_K19] ON [dbo].[child_file_template_meta_info]
(
	[child_file_template_record_id]
)INCLUDE([child_file_template_id],[child_file_template_version],[child_File_Template_Name],[trading_partner_id],[lob_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[config_promotion_audit_info]') AND name = N'IX_config_promotion_audit_info_K6_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_config_promotion_audit_info_K6_K2] ON [dbo].config_promotion_audit_info
(
	[file_id] ASC,[source_env_id] ASC
)INCLUDE(config_promotion_audit_id,file_version,updated_date_time,promotion_notes,target_env_id,promotion_status_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rule_group]') AND name = N'IX_drools_business_rule_group_K3')
CREATE NONCLUSTERED INDEX [IX_drools_business_rule_group_K3] ON [dbo].[drools_business_rule_group]
(
	[parent_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rules_decision_table]') AND name = N'IX_drools_business_rules_decision_table_K1_K5_K4')
CREATE NONCLUSTERED INDEX [IX_drools_business_rules_decision_table_K1_K5_K4] ON [dbo].[drools_business_rules_decision_table]
(
	[drools_business_rule_id] ASC,
	[drools_business_rule_version] ASC,
	[rule_group_hierarchy_string] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rules_decision_table]') AND name = N'IX_drools_business_rules_decision_table_K3')
CREATE NONCLUSTERED INDEX [IX_drools_business_rules_decision_table_K3] ON [dbo].[drools_business_rules_decision_table]
(
	[drools_business_rule_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[drools_business_rules_decision_table]') AND name = N'IX_drools_business_rules_decision_table_K4')
CREATE NONCLUSTERED INDEX [IX_drools_business_rules_decision_table_K4] ON [dbo].[drools_business_rules_decision_table]
(
	[rule_group_hierarchy_string] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_application]') AND name = N'IX_error_log_application_K2_K16')
CREATE NONCLUSTERED INDEX [IX_error_log_application_K2_K16] ON [dbo].[error_log_application]
(
	[error_code] ASC,
	[error_date_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_application]') AND name = N'IX_error_log_application_K4_K16')
CREATE NONCLUSTERED INDEX [IX_error_log_application_K4_K16] ON [dbo].[error_log_application]
(
	[error_type_id] ASC,
	[error_date_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_application]') AND name = N'IX_error_log_application_K5_K16')
CREATE NONCLUSTERED INDEX [IX_error_log_application_K5_K16] ON [dbo].[error_log_application]
(
	[error_severity_id] ASC,
	[error_date_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_application]') AND name = N'IX_error_log_application_K15')
CREATE NONCLUSTERED INDEX [IX_error_log_application_K15] ON [dbo].[error_log_application]
(
	[error_origin_server_ip] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K2')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K2] ON [dbo].[error_log_data_file_processing]
(
	[error_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K4')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K4] ON [dbo].[error_log_data_file_processing]
(
	[error_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K5')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K5] ON [dbo].[error_log_data_file_processing]
(
	[error_severity_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K6')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K6] ON [dbo].[error_log_data_file_processing]
(
	[error_data_file_job_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K7')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K7] ON [dbo].[error_log_data_file_processing]
(
	[error_data_file_expectation_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[error_log_data_file_processing]') AND name = N'IX_error_log_data_file_processing_K8_K9')
CREATE NONCLUSTERED INDEX [IX_error_log_data_file_processing_K8_K9] ON [dbo].[error_log_data_file_processing]
(
	[error_data_file_id] ASC,
	[error_data_file_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attr_br_assoc]') AND name = N'IX_file_attr_br_assoc_K3_K4_K2_K5')
CREATE NONCLUSTERED INDEX [IX_file_attr_br_assoc_K3_K4_K2_K5] ON [dbo].[file_attr_br_assoc]
(
	[business_rule_id]ASC, [business_rule_version] ASC
)INCLUDE([faa_id], [rule_execution_sequence])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K1_K3')
BEGIN
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K1_K3] ON [dbo].[file_attribute_association]
(
	faa_id
)
INCLUDE(attribute_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K3')
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K3] ON [dbo].[file_attribute_association]
(
	[fsa_id] ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K5')
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K5] ON [dbo].[file_attribute_association]
(
	[attribute_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K26_K9')
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K26_K9] ON [dbo].[file_attribute_association]
(
	[file_identifier] ASC,
	[is_mandatory] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K26_K11')
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K26_K11] ON [dbo].[file_attribute_association]
(
	[file_identifier] ASC,
	[attribute_row_position] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_attribute_association]') AND name = N'IX_file_attribute_association_K26_K13')
CREATE NONCLUSTERED INDEX [IX_file_attribute_association_K26_K13] ON [dbo].[file_attribute_association]
(
	[file_identifier] ASC,
	[attribute_end_position] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_layout_schema_node_assoc]') AND name = N'IX_file_layout_schema_node_assoc_K2_K3')
BEGIN
CREATE NONCLUSTERED INDEX [IX_file_layout_schema_node_assoc_K2_K3] ON [dbo].[file_layout_schema_node_assoc]
(
	[flsni_id]
)
INCLUDE ([parent_flsni_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON


IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_layout_schema_node_info]') AND name = N'IX_file_layout_schema_node_info_K3_K16')
BEGIN
CREATE NONCLUSTERED INDEX [IX_file_layout_schema_node_info_K3_K16] ON [dbo].[file_layout_schema_node_info]
(
	[file_identifier],[node_section_short_name]
)
INCLUDE ([flsni_id],[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_layout_schema_node_info]') AND name = N'IX_file_layout_schema_node_info_K3_K16_K10')
BEGIN
CREATE NONCLUSTERED INDEX [IX_file_layout_schema_node_info_K3_K16_K10] ON [dbo].[file_layout_schema_node_info]
(
	[file_identifier],[node_section_short_name],[node_row_position]
)
INCLUDE ([flsni_id],[node_category],[node_display_name],[node_data_type_id],[node_ref_num],[node_description],
[node_is_mandatory],[node_cond_description],[mapped_column_type])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K2] ON [dbo].[File_Meta_Info]
(
	[file_id]
)INCLUDE(record_id, file_type_id, master_file_template_id, master_file_template_version, child_file_template_id, child_file_template_version, file_version, file_name, file_status, is_active, approval_status_id, child_file_template_record_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K2_k8')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K2_k8] ON [dbo].[File_Meta_Info]
(
	[file_id],[file_version]
)INCLUDE(record_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_meta_info]') AND name = N'IX_file_meta_info_K3')
CREATE NONCLUSTERED INDEX [IX_file_meta_info_K3] ON [dbo].[file_meta_info]
(
	[file_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_meta_info]') AND name = N'IX_file_meta_info_K4')
CREATE NONCLUSTERED INDEX [IX_file_meta_info_K4] ON [dbo].[file_meta_info]
(
	[master_file_template_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K4_K5')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K4_K5] ON [dbo].[File_Meta_Info]
(
	[master_file_template_id],[master_file_template_version]
)INCLUDE(record_id,file_id,file_version)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_meta_info]') AND name = N'IX_file_meta_info_K6')
CREATE NONCLUSTERED INDEX [IX_file_meta_info_K6] ON [dbo].[file_meta_info]
(
	[child_file_template_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[File_Meta_Info]') AND name = N'IX_File_Meta_Info_K24_K25_K8_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_File_Meta_Info_K24_K25_K8_K2] ON [dbo].[File_Meta_Info]
(
	[is_active],[approval_status_id],[file_version],[file_id]
)INCLUDE(record_id,file_Name,file_Status,child_file_template_id,child_file_template_version,child_file_template_record_id,master_file_template_id,master_file_template_version,file_type_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_meta_info]') AND name = N'IX_file_meta_info_K27')
CREATE NONCLUSTERED INDEX [IX_file_meta_info_K27] ON [dbo].[file_meta_info]
(
	[file_format_supported_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_audit_log]') AND name = N'IX_file_processing_audit_log_K2_K3')
CREATE NONCLUSTERED INDEX [IX_file_processing_audit_log_K2_K3] ON [dbo].[file_processing_audit_log]
(
	[file_id] ASC,
	[file_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_audit_log]') AND name = N'IX_file_processing_audit_log_K4')
CREATE NONCLUSTERED INDEX [IX_file_processing_audit_log_K4] ON [dbo].[file_processing_audit_log]
(
	[job_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


GO



SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_audit_log]') AND name = N'IX_file_processing_audit_log_K4_K6')
CREATE NONCLUSTERED INDEX [IX_file_processing_audit_log_K4_K6] ON [dbo].[file_processing_audit_log]
(
	[job_id] ASC,
	[processing_step_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_processing_audit_log]') AND name = N'IX_file_processing_audit_log_K5')
CREATE NONCLUSTERED INDEX [IX_file_processing_audit_log_K5] ON [dbo].[file_processing_audit_log]
(
	[expectation_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_trading_partner_lob_assoc]') AND name = N'IX_file_trading_partner_lob_assoc_K2_K3')
CREATE NONCLUSTERED INDEX [IX_file_trading_partner_lob_assoc_K2_K3] ON [dbo].[file_trading_partner_lob_assoc]
(
	[trading_partner_id] ASC,
	[lob_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_type_meta_info]') AND name = N'IX_file_type_meta_info_K1_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_file_type_meta_info_K1_K2] ON [dbo].[file_type_meta_info]
(
	[file_type_id] ASC
)INCLUDE([file_type_name],[direction])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[file_type_meta_info]') AND name = N'IX_file_type_meta_info_K3')
CREATE NONCLUSTERED INDEX [IX_file_type_meta_info_K3] ON [dbo].[file_type_meta_info]
(
	[direction] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_dm_element_assoc]') AND name = N'IX_fls_node_dm_element_assoc_K2_K4')
BEGIN
CREATE NONCLUSTERED INDEX [IX_fls_node_dm_element_assoc_K2_K4] ON [dbo].[fls_node_dm_element_assoc]
(
	flsni_id,is_active
)
INCLUDE(faa_id)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[fls_node_enum_value_assoc]') AND name = N'IX_fls_node_enum_value_assoc_K6')
BEGIN
CREATE NONCLUSTERED INDEX [IX_fls_node_enum_value_assoc_K6] ON [dbo].[fls_node_enum_value_assoc]
(
	[is_active]
)
INCLUDE ([flsni_id],[enum_value])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[idis_team_file_association]') AND name = N'IX_idis_team_file_association_K5')
CREATE NONCLUSTERED INDEX [IX_idis_team_file_association_K5] ON [dbo].[idis_team_file_association]
(
	[file_identifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_details]') AND name = N'IX_job_details_K4')
CREATE NONCLUSTERED INDEX [IX_job_details_K4] ON [dbo].[job_details]
(
	[job_creation_datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_details]') AND name = N'IX_job_details_K5_K11_K13')
CREATE NONCLUSTERED INDEX [IX_job_details_K5_K11_K13] ON [dbo].[job_details]
(
	[job_expected_start_datetime] ASC,
	[job_status] ASC,
	[file_processing_priority] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_details]') AND name = N'IX_job_details_K13')
CREATE NONCLUSTERED INDEX [IX_job_details_K13] ON [dbo].[job_details]
(
	[file_processing_priority] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_details]') AND name = N'IX_job_details_K27')
CREATE NONCLUSTERED INDEX [IX_job_details_K27] ON [dbo].[job_details]
(
	[file_identifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lob]') AND name = N'IX_lob_K1_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_lob_K1_K2] ON [dbo].[lob]
(
	[lob_id] ASC
)INCLUDE([lob_name])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K4_K7')
CREATE NONCLUSTERED INDEX [IX_lookup_table_file_association_K4_K7] ON [dbo].[lookup_table_file_association]
(
	[faa_id] ASC,
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K5_K7')
CREATE NONCLUSTERED INDEX [IX_lookup_table_file_association_K5_K7] ON [dbo].[lookup_table_file_association]
(
	[mftaa_id] ASC,
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[lookup_table_file_association]') AND name = N'IX_lookup_table_file_association_K6_K7')
CREATE NONCLUSTERED INDEX [IX_lookup_table_file_association_K6_K7] ON [dbo].[lookup_table_file_association]
(
	[cftaa_id] ASC,
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_attribute_association]') AND name = N'IX_master_file_template_attribute_association_K2_K3')
CREATE NONCLUSTERED INDEX [IX_master_file_template_attribute_association_K2_K3] ON [dbo].[master_file_template_attribute_association]
(
	[master_file_template_id] ASC,
	[master_file_template_version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_attribute_association]') AND name = N'IX_master_file_template_attribute_association_K4')
CREATE NONCLUSTERED INDEX [IX_master_file_template_attribute_association_K4] ON [dbo].[master_file_template_attribute_association]
(
	[attribute_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON


IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_meta_info]') AND name = N'IX_master_file_template_meta_info_K3')
BEGIN
CREATE NONCLUSTERED INDEX [IX_master_file_template_meta_info_K3] ON [dbo].[master_file_template_meta_info]
(
	[file_type_id]
)INCLUDE([master_file_template_name],[master_file_template_id],[master_file_template_version])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_meta_info]') AND name = N'IX_master_file_template_meta_info_K4')
CREATE NONCLUSTERED INDEX [IX_master_file_template_meta_info_K4] ON [dbo].[master_file_template_meta_info]
(
	[file_type_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[master_file_template_meta_info]') AND name = N'IX_master_file_template_meta_info_K13_K14')
BEGIN
CREATE NONCLUSTERED INDEX [IX_master_file_template_meta_info_K13_K14] ON [dbo].[master_file_template_meta_info]
(
	[master_file_template_id] ASC,[master_file_template_version]
)INCLUDE([master_file_template_name])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO





SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_info]') AND name = N'IX_trading_partner_info_K1_K2')
BEGIN
CREATE NONCLUSTERED INDEX [IX_trading_partner_info_K1_K2] ON [dbo].[trading_partner_info]
(
	[trading_partner_id] ASC
)INCLUDE([trading_Partner_Name])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_info]') AND name = N'IX_trading_partner_info_K1_K2_K11')
CREATE NONCLUSTERED INDEX [IX_trading_partner_info_K1_K2_K11] ON [dbo].[trading_partner_info]
(
	[trading_partner_name] ASC,
	[active] asc
)INCLUDE([trading_partner_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_info]') AND name = N'IX_trading_partner_info_K2')
CREATE NONCLUSTERED INDEX [IX_trading_partner_info_K2] ON [dbo].[trading_partner_info]
(
	[trading_partner_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[trading_partner_info]') AND name = N'IX_trading_partner_info_K4')
CREATE NONCLUSTERED INDEX [IX_trading_partner_info_K4] ON [dbo].[trading_partner_info]
(
	[trading_partner_type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
