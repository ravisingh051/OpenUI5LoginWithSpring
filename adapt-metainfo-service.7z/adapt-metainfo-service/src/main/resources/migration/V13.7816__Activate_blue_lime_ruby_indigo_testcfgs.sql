USE [idis-metainfo]
GO

/*
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-10-07	Divya Jain		ADAPT-7816: Setup of Parallel Testing Environment

*/

if exists(select 1 from information_schema.tables where table_name='testcfg_lookup')
begin
	if exists(select 1 from testcfg_lookup where lookup_value in ('BLUE','RUBY','LIME','INDIGO'))	
	begin
		update testcfg_lookup set is_active=1 where lookup_value in ('BLUE','RUBY','LIME','INDIGO')
	end
end
GO

