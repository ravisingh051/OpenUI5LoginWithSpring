use [idis-metainfo]
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Divya Jain
-- Create date:  12/08/2019 11:00:00 PM 
-- Description:	This Store Procedure Deletes already cloned attributes in PMT.
-- =============================================

/*
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
*/


IF OBJECT_ID('dbo.USP_PMT_clone_deletion') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_PMT_clone_deletion');
GO

/*
IF OBJECT_ID('dbo.USP_PMT_clone_deletion') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_PMT_clone_deletion AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_PMT_clone_deletion]
	-- Add the parameters for the stored procedure here
	@ipmt_record_id INT,
	@iclone_num INT,
	@oError_code int OUTPUT
				
AS
BEGIN


    SET NOCOUNT ON;

	IF OBJECT_ID('tempdb..#TEMP_DBRDT') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT; END
	CREATE TABLE #TEMP_DBRDT ( rule_id int, rule_version int)

	if (@iclone_num <= 0 )
	 BEGIN
		set @oError_code=-3;
        GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
      END 


	-- check clone number is exist or not.
      if not exists(select 1 from [dbo].[child_file_template_attribute_association]  where child_file_template_record_id = @ipmt_record_id and clone_num = @iclone_num)
	 BEGIN
		set @oError_code=-2;
        GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
      END 

	 BEGIN TRANSACTION;
        BEGIN TRY
		  
	  INSERT into #TEMP_DBRDT (rule_id, rule_version)
			 (select drools_business_rule_id,drools_business_rule_version from child_file_template_attribute_association cftaa
			 join  child_file_template_section_assoc cftsa on cftsa.cftsa_id = cftaa.cftsa_id
			 join child_file_template_attr_br_assoc cftaba on cftaa.cftaa_id=cftaba.cftaa_id join drools_business_rules_decision_table dbrdt 
			 on dbrdt.drools_business_rule_id=cftaba.business_rule_id and cftaba.business_rule_version = dbrdt.drools_business_rule_version
			 where cftaa.[child_file_template_record_id] =@ipmt_record_id and cftaa.clone_num = @iclone_num 
			 and cftsa.template_compliant_section_short_name = 'D')

	 
	   delete from child_file_template_attr_br_assoc where cftaa_id in (SELECT cftaa_id from child_file_template_attribute_association cftaa inner join  child_file_template_section_assoc cftsa on cftsa.cftsa_id = cftaa.cftsa_id
	   where cftaa.clone_num = @iclone_num and cftaa.[child_file_template_record_id] =@ipmt_record_id 
	   and cftsa.template_compliant_section_short_name = 'D')

	   delete rules from drools_business_rules_decision_table rules inner join  #TEMP_DBRDT temp  on temp.rule_id = rules.drools_business_rule_id and temp.rule_version = rules.drools_business_rule_version 
	
	   DELETE from lookup_table_file_association where faa_id is null and cftaa_id in (SELECT cftaa_id from child_file_template_attribute_association cftaa 
				inner join  child_file_template_section_assoc cftsa on cftsa.cftsa_id = cftaa.cftsa_id
	   where cftaa.clone_num = @iclone_num and cftaa.[child_file_template_record_id] =@ipmt_record_id 
	   and cftsa.template_compliant_section_short_name = 'D')

	   DELETE FROM [dbo].[file_secondary_mapping_attr_assoc] where fsmaa_faa_id in (select cftaa_id from child_file_template_attribute_association  cftaa
			 join  child_file_template_section_assoc cftsa on cftsa.cftsa_id = cftaa.cftsa_id  where cftaa.[child_file_template_record_id] =@ipmt_record_id
			  and cftaa.clone_num = @iclone_num and cftsa.template_compliant_section_short_name = 'D')
	   
	   delete from child_file_template_attribute_association where cftaa_id in (select cftaa_id from child_file_template_attribute_association  cftaa
			 join  child_file_template_section_assoc cftsa on cftsa.cftsa_id = cftaa.cftsa_id  where cftaa.[child_file_template_record_id] =@ipmt_record_id
			  and cftaa.clone_num = @iclone_num and cftsa.template_compliant_section_short_name = 'D')

	   delete from child_file_template_clone_info  where [child_file_template_record_id] =@ipmt_record_id and clone_num = @iclone_num


	COMMIT TRANSACTION;
		SET @oError_code = 0;
	END TRY
	
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
	END CATCH 

	IF OBJECT_ID('tempdb..#TEMP_DBRDT') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT; END
	
		END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @oError_code = -2)
			    BEGIN
			    print 'Error: given clone number is not exists for this PMT ...'
			    RETURN -2
	    END
	   ELSE IF ( @oError_code = -3)
			 BEGIN
			 print 'Error: you can not delete attributes with given clone number...'
			 RETURN -1
	   END
	   ELSE IF ( @oError_code <> 0)
		  BEGIN
		  print 'Error: Some Error occured while deleting cloned attributes...'
		  RETURN -1
	   END
	   ELSE
		  BEGIN
		  print 'PMT cloned attributes deleted Successfully... '
		  SET @oError_code=0
		  RETURN 0
	   END 
   
END;
GO
-- ============================================================================ 
 --Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_PMT_clone_deletion
	TO exec_proc;
GO

*/