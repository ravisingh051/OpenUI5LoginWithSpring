USE [idis-metainfo]
GO

/*
Update Log	
----------  -----------    ---------------------------------------------------------------------------------------
01-07-2019  Divya Jain	   ADAPT-6608 : User is able to configure for "Outbound SLA missed" is displayed in Notification System Event Dropdown 

*/

USE [idis-metainfo]

if exists(select * from processing_system_events where event_id=4)
begin
	if exists (select * from notification_template_info where event_id =4)
	begin
		if exists (select * from file_notification_template_contact_assoc where template_id in 
		(select template_id from notification_template_info where event_id =4))
		begin
			delete from file_notification_template_contact_assoc where template_id in 
			(select template_id from notification_template_info where event_id =4)
		end;
		delete from notification_template_info where event_id =4
	end;
	delete from processing_system_events where event_id=4
end;
GO

