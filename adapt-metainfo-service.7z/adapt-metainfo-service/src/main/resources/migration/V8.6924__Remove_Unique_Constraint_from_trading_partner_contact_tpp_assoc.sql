USE [idis-metainfo]
GO

/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-24   Jinesh vora			ADAPT-6924 : User is not getting platform values in edit mode it should display all the trading platform linked with trading partner 

*/

-- Remove UNIQUE Constraint UK_trading_partner_contact_assoc_K2_K3
IF EXISTS (
	SELECT *
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_NAME='UK_trading_partner_contact_assoc_K2_K3'
	)
BEGIN
ALTER TABLE [dbo].[trading_partner_contact_assoc] DROP CONSTRAINT [UK_trading_partner_contact_assoc_K2_K3]
END;
GO
