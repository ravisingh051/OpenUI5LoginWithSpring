use [idis-metainfo]
GO
/*
Filename:  V2.2043__data_population_for_config_promotion_status.sql

Update Log

Date        	Author          		Description
----------   ------------    -------------------------------------------------------------------------------------------
2019-05-03   Mayur Tanna		ADAPT-2043 : user-would-like-promotion-feature-to-vary-behavior-based-on-the-environments
*/
--- ADAPT-2043 starts
IF NOT EXISTS (SELECT 1 from config_promotion_status where config_promotion_status_id = 8)
BEGIN
SET IDENTITY_INSERT [dbo].[config_promotion_status] ON
INSERT [dbo].[config_promotion_status] ([config_promotion_status_id], [config_promotion_status_name], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (8, N'Auto Approved', N'Mayur Tanna', CAST(N'2019-04-26T16:59:41.293' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[config_promotion_status] OFF
END;
GO
--- ADAPT-2043 ends