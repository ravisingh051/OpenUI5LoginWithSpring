use [idis-metainfo]

GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Richa Ashara
-- Create date:  10/18/2018 12:23:24 PM 
-- Description:	This Store Procedure returns comma separated value of columns as well as comma sparated column names.
-- =============================================
/*
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2018-12-13  Richa Ashara		ADAPT-642- User should be able to configure connection/key with File
*/
IF OBJECT_ID('dbo.USP_Split_By_Comma_Separated_Values_And_Column_Names') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_Split_By_Comma_Separated_Values_And_Column_Names AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_Split_By_Comma_Separated_Values_And_Column_Names]
	-- Add the parameters for the stored procedure here
	@table_name varchar(100),
	@where_clause nvarchar(max),
	@file_id INT,
	@str_col_name nvarchar(max) OUTPUT,
	@str_col_value nvarchar(max) OUTPUT
	
			
AS
BEGIN
	
	Declare @ExecStr    nvarchar(max)
	Declare @pk_column varchar(200)

	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELstgT statements.
	SET NOCOUNT ON;

	IF OBJECT_ID('tempdb..#tmp_Col2Row') IS NOT NULL 
	BEGIN DROP TABLE #tmp_Col2Row; END

	Create Table #tmp_Col2Row
	   (Field_Name nvarchar(128) Not Null
	   ,Field_Value nvarchar(max) Null
	   )

	Set @ExecStr = N' Insert Into #tmp_Col2Row (Field_Name , Field_Value) '

   -- print @ExecStr 
    Select @ExecStr += (Select N'Select  distinct '''+C.name+''' ,Convert(nvarchar(max),'+quotename(C.name) + ') From ' + @table_name+ ' ' +@where_clause+Char(10)+' Union All '
		   from sys.columns as C
		   where C.name not in ('file_id','file_version','updated_by','updated_date_time',
		   'file_identifier','record_id','drools_business_rule_version','drools_business_rule_id', 'business_rule_id','business_rule_version','trading_partner_id',
		    'lob_id','fsa_id','faa_id', 'trading_partner_platform_id','trading_partner_contact_id','template_id', 'notification_template_id', 'file_notification_template_contact_assoc_id','ntft_id',
		   'file_format_supported_id', 'lookup_table_id','lookup_table_version', 'file_idis_ba_id',  'associated_file_level_id', 'file_clone_id', 'file_transmission_connection_id', 'file_transmission_auth_key_id') and
		    (C.object_id = object_id(@table_name)) 
		   for xml path(''))
    Select @ExecStr = Left(@ExecStr,Len(@ExecStr)-Len(' Union All '))
   -- Print @ExecStr

    Exec (@ExecStr)

    SELECT @pk_column =column_name FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS TC INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KU ON TC.CONSTRAINT_TYPE = 'PRIMARY KEY' AND
			 TC.CONSTRAINT_NAME = KU.CONSTRAINT_NAME AND KU.table_name= @table_name ORDER BY KU.TABLE_NAME, KU.ORDINAL_POSITION;

    delete from #tmp_Col2Row where Field_Name = @pk_column

    UPDATE  #tmp_Col2Row set Field_Value = REPLACE (Field_Value, '''', '''''') 
    
    update #tmp_Col2Row set Field_Value = (Field_Value + '_i_' +  CAST (@file_id AS NVARCHAR(max))) where Field_Name LIKE '%name' 
    and Field_Name not in ( 'file_format_name', 'drools_business_rule_name', 'file_format_compliant_attribute_name','file_compliant_section_short_name', 'section_display_name', 'file_idis_ba_name', 'file_idis_ba_email_id',
    'idis_team_member_email_id', 'idis_team_member_first_name', 'idis_team_member_last_name', 'transmission_name', 'lookup_table_name') 
    and Field_Value not in ('', ' ') and Field_Value is NOT NULL
  
    SELECT @str_col_value = COALESCE(@str_col_value + ''',''', '') + ISNULL( CAST(Field_Value AS nvarchar(max)), 'NULL') FROM   #tmp_Col2Row order by Field_Name 
    SET @str_col_value = CONCAT('''', @str_col_value, '''')
    SET @str_col_value = REPLACE(@str_col_value, '''NULL''', 'NULL')
   
    select @str_col_name = COALESCE(@str_col_name +',','') + Field_name from #tmp_Col2Row order by Field_Name
   
	
END;
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_Split_By_Comma_Separated_Values_And_Column_Names
	TO exec_proc;
GO