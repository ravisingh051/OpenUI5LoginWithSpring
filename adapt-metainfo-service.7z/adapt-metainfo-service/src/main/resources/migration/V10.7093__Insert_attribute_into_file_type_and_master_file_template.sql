use [idis-metainfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
07-08-2019  Jinesh Vora	   ADAPT-7093 : Update logic for Attribute related to Termination indicator in SPs/Views
Table Name 
-- file_type_attribute_association
-- master_file_template_attribute_association

*/

-- INSERT Into file_type_attribute_association
IF not exists(SELECT 1 FROM [dbo].[file_type_attribute_association] WHERE ftaa_id in (4656,4657 ))
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON;

INSERT [dbo].[file_type_attribute_association] ([ftaa_id], [file_type_id], [attribute_id], [data_type], [is_mandatory], [default_value], [standardized_name], [created_by], [created_date_time], [updated_by], [updated_date_time], [attribute_logical_group_id]) VALUES (4656, 2, 238, N'INTEGER', 1, NULL, N'electStatus', N'Jinesh Vora', CAST(N'2019-08-05T17:51:57.913' AS DateTime), NULL, NULL, 12)
INSERT [dbo].[file_type_attribute_association] ([ftaa_id], [file_type_id], [attribute_id], [data_type], [is_mandatory], [default_value], [standardized_name], [created_by], [created_date_time], [updated_by], [updated_date_time], [attribute_logical_group_id]) VALUES (4657, 17, 238, N'INTEGER', 1, NULL, N'electStatus', N'Jinesh Vora', CAST(N'2019-08-05T17:51:57.913' AS DateTime), NULL, NULL, 12)

SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF;
END
GO

-- Insert into master_file_template_attribute_association
IF not exists(SELECT 1 FROM [dbo].[master_file_template_attribute_association] WHERE mftaa_id in (2119,2120,2121))
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON;

INSERT INTO [dbo].[master_file_template_attribute_association]
([mftaa_id],[master_file_template_id],[master_file_template_version],[attribute_id],[data_type],[is_mandatory],[attribute_row_position],[application_compliant_attribute_name],[mftsa_id],[created_by],[created_date_time],[master_file_template_record_id],[max_size_allowed],[ftaa_id],[updated_by],[updated_date_time])
VALUES (2119,2,1,238,'INTEGER',1,NULL,NULL,13,'Jinesh Vora',getdate(),2,NULL,4656,NULL,NULL)

INSERT INTO [dbo].[master_file_template_attribute_association]
([mftaa_id],[master_file_template_id],[master_file_template_version],[attribute_id],[data_type],[is_mandatory],[attribute_row_position],[application_compliant_attribute_name],[mftsa_id],[created_by],[created_date_time],[master_file_template_record_id],[max_size_allowed],[ftaa_id],[updated_by],[updated_date_time])
VALUES (2120,17,1,238,'INTEGER',1,NULL,NULL,58,'Jinesh Vora',getdate(),17,NULL,4656,NULL,NULL)

INSERT INTO [dbo].[master_file_template_attribute_association]
([mftaa_id],[master_file_template_id],[master_file_template_version],[attribute_id],[data_type],[is_mandatory],[attribute_row_position],[application_compliant_attribute_name],[mftsa_id],[created_by],[created_date_time],[master_file_template_record_id],[max_size_allowed],[ftaa_id],[updated_by],[updated_date_time])
VALUES (2121,18,1,238,'INTEGER',1,NULL,NULL,79,'Jinesh Vora',getdate(),18,NULL,4657,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF;
END
GO

