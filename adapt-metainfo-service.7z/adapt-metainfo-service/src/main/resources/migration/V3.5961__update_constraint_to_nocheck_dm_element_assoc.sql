USE [idis-metainfo]
GO

IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsda_K3_cftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_dm_element_assoc] DROP CONSTRAINT [FK_ctlsda_K3_cftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ctlsda_K3_cftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.ctls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[ctls_node_dm_element_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_ctlsda_K3_cftaa_K1] FOREIGN KEY([cftaa_id])
REFERENCES [dbo].[child_file_template_attribute_association] (cftaa_id)
ALTER TABLE [dbo].[ctls_node_dm_element_assoc] NOCHECK CONSTRAINT [FK_ctlsda_K3_cftaa_K1]
END;
GO

IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsda_K3_mftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_dm_element_assoc] DROP CONSTRAINT [FK_mtlsda_K3_mftaa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_mtlsda_K3_mftaa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.mtls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[mtls_node_dm_element_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_mtlsda_K3_mftaa_K1] FOREIGN KEY([mftaa_id])
REFERENCES [dbo].[master_file_template_attribute_association] (mftaa_id)
ALTER TABLE [dbo].[mtls_node_dm_element_assoc] NOCHECK CONSTRAINT [FK_mtlsda_K3_mftaa_K1]
END;
GO

IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsda_K3_faa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_dm_element_assoc] DROP CONSTRAINT [FK_flsda_K3_faa_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_flsda_K3_faa_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.fls_node_dm_element_assoc')
	)
BEGIN
ALTER TABLE [dbo].[fls_node_dm_element_assoc]  WITH NOCHECK ADD  CONSTRAINT [FK_flsda_K3_faa_K1] FOREIGN KEY([faa_id])
REFERENCES [dbo].[file_attribute_association] (faa_id)
ALTER TABLE [dbo].[fls_node_dm_element_assoc] NOCHECK CONSTRAINT [FK_flsda_K3_faa_K1]
END;
GO

