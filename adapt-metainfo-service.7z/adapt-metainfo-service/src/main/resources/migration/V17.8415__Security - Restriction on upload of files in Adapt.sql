USE [idis-metainfo]
GO

/*
Date        Author          		Description
----------  ------------    		-------------------------------------------------------------------------------------------
2019-11-28	Shipra Maheshwari		ADAPT-8415: Security - Restriction on upload of files in Adapt

Table Name 
-- adapt_configuration
-- adapt_file_upload_attempts

*/

/****** Object:  Table [dbo].[adapt_configuration]    Script Date: 11/28/2019 5:37:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_configuration]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_configuration](
	[adapt_configuration_id] [int] IDENTITY(1,1) NOT NULL,
	[adapt_configuration_key] [varchar](50) NOT NULL,
	[adapt_configuration_value] [varchar](50) NOT NULL,
	[is_active] [bit] NOT NULL CONSTRAINT  DF_adapt_configuration_is_active DEFAULT (1)
 CONSTRAINT [adapt_configuration_id] PRIMARY KEY CLUSTERED 
(
	[adapt_configuration_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[adapt_file_upload_attempts]    Script Date: 11/28/2019 5:39:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[adapt_file_upload_attempts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[adapt_file_upload_attempts](
	[adapt_file_upload_attempt_id] [int] IDENTITY(1,1) NOT NULL,	
	[username] [varchar](50) NOT NULL,
	[uploaded_event] varchar (50) NOT NULL,
	[last_uploaded_datetime] [datetime] NOT NULL	
  CONSTRAINT [adapt_file_upload_attempt_id] PRIMARY KEY CLUSTERED 
(
	[adapt_file_upload_attempt_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO


if not exists (select 1 from adapt_configuration where adapt_configuration_id between 1 and 12)
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_configuration] ON 
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (1,'Lookup Tables File Extension','csv');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (2,'Lookup Tables File Mime-Type','text/csv');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (3,'Lookup Tables File Upload Frequency','5/10');

INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (4,'Outbound Key File Extension','asc');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (5,'Outbound Key File Mime-Type','text/plain');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (6,'Outbound Key File Upload Frequency','5/10');

INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (7,'Tooltip File Extension','json');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (8,'Tooltip File Mime-Type','application/json');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (9,'Tooltip File Upload Frequency','20/10');

INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (10,'Dashboard File Extension','txt,csv,pgp');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (11,'Dashboard File Mime-Type','text/plain,text/csv,application/pgp-encrypted');
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value)
values (12,'Dashboard File Upload Frequency','20/10');

SET IDENTITY_INSERT [dbo].[adapt_configuration] OFF 
END
GO
