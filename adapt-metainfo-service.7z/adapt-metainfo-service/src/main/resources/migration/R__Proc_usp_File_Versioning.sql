USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[Proc_File_Versioning]    Script Date: 3/8/2018 7:20:19 PM  Author: Richa Ashara   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Filename:  Proc_File_Versioning.sql
 
Parameters: 
@iFile_id

2018-05-28	Divya Jain	CC-34384: Removing column file_storage_path from table file_meta_info and references from Stored Procedures
2018-12-05	 Richa Ashara	 ADAPT-250-user-should-be-able-to-update-delete-the-cloned-section-at-file-level 
2018-12-12	 Richa Ashara	  ADAPT-642-user-should-be-able-to-configure-connection-key-with-file
2018-12-19  Richa Ashara		ADAPT-291-User should be able to configure connection/key with File .
2018-12-26	Richa Ashara	ADAPT-307: User should be able to view the Last updated information for PMT/File Templates & Job Schedule
2019-01-17	Divya Jain		ADAPT-1364-User should be able to see additional Employee & Person attributes as part of Alight existing values in rule editor
2019-02-36	Divya Jain		ADAPT-1779: User should be able to select Testcfg while configuring the file
2019-02-27	Divya Jain		ADAPT-2526: Add "Source Type" and "Target Type" to File Setup
2019-03-18	Divya Jain		ADAPT-2717: User should be able to edit Trading Partner & LOB while copying the file
2019-04-05	Nilesh Jariya	ADAPT-3417: Rule Order notes do not save
2019-06-25	Divya Jain		ADAPT-6510: USP_Get_Dynamic_Schema_Attribute- values under 'columnOrder' are NULL
2019-07-08	Divya Jain		ADAPT-2779: Removed copiedTransmissionName
2019-08-27  Bhaumik Sathvara ADAPT-7324: Removed is_draft column from drools_business_rules_decision_table and added to_do column in file_attribute_association.
2019-09-12 Ravi Singh ADAPT-7601: Outbound file- Specify delimiter screen- Duplicate entries are displayed for an copied file
2019-09-12	Snehal Patel	ADAPT-2993 : Column names in tables - Characters are missing - misspelled - Example foreign key - DB - High - Beyond Phase 2.
2019-09-30	 Divya Jain		ADAPT-7708: API - Remove the PMT APIs
2019-10-14	Snehal Patel	ADAPT-7998: Remove enumerated values and print display name.
2019-10-17	Shipra Maheshwari	ADAPT-8065: Copy file- Trading partner, LOB and old fist id fields should be blank
2019-10-18	Shipra Maheshwari   ADAPT-8254: Use as template checkbox gets unchecked for newer versions of file templates
2020-01-13	Nilesh Jariya	ADAPT-8948: Remove advanced selection criteria


***********************************************
*/
IF OBJECT_ID('dbo.Proc_File_Versioning') IS NULL
EXEC('CREATE PROCEDURE dbo.Proc_File_Versioning AS SELECT 1')
GO



ALTER procedure [dbo].[Proc_File_Versioning]
   @iFile_id int,
   @iFile_old_version int,
   @iCreated_by varchar(50),
   @isRestored_versioning bit = 0,
   @isCopyOfFile  bit = 0,
   @copiedFileName varchar(80) = null,
   --@is_sync_of_pmt bit = 0,
   @copiedAnalystName varchar(100) =null,
   @copiedTpId int =null,
   @copiedLobId int =null,
   @oError_code int OUTPUT,
   @oFile_identifier int = 0 OUTPUT
   AS 
   BEGIN
   
   
  DECLARE @Error_code INT;
	SET @Error_code=0;

	 
	  if(@isRestored_versioning is null)
	  BEGIN
		 set @isRestored_versioning = 0
	  END

	  if(@isCopyOfFile is null)
	  BEGIN
		set @isCopyOfFile = 0 
	  END
 
	if(@isCopyOfFile is null)
	BEGIN
		set @copiedTpId = null
		set @copiedLobId = null
	END

	-- check if is this for file copying file and file name and file trasmission name are not there.
    if(@isCopyOfFile = 1)
    BEGIN
     if(@copiedFileName is null or @copiedFileName = '')
	   BEGIN
		  set @Error_code=-3;
		  GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	   END
     -- check unique ness for file trasmission name and file name
	if EXISTS ( select 1 from [dbo].[file_meta_info] where file_name = @copiedFileName)
	BEGIN
	   set @Error_code=-4;
	   GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	END
    END
	-- Check if a parallel process has not already initiated  a file edit and created a draft
	ELSE if(@isRestored_versioning = 0)
	BEGIN
	    if exists(select 1 from [dbo].[file_meta_info] where [file_id] = @iFile_id and [approval_status_id] in (1,2))
	    BEGIN
		  set @Error_code=-2;
		  GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	   END 
     END

	
   BEGIN TRANSACTION;

	DECLARE @faa_id INT;
	DECLARE @fsa_id INT;
	DECLARE @fsa_id_FK INT;
	DECLARE @attribute_id INT;
	DECLARE @NewAttrId INT;
	DECLARE @NewFileSectionId INT;
	DECLARE @new_file_version INT;
	DECLARE @counter int;
	DECLARE @total_row int;
	DECLARE @parent_fsa_id int;
	DECLARE @new_fsa_id int;
	DECLARE @template_section_id int;
	DECLARE @inserted TABLE ([ID] INT, [old_id] INT,[counter] INT);
	DECLARE @old_fsa_id INT;
	--DECLARE @iFile_old_version INT;
	DECLARE @file_type_id INT;
	DECLARE @file_supported_id INT;
	declare @file_identifier INT;
	declare @file_identifier_old INT;
	DECLARE @iFile_max_version int;
	DECLARE @iFile_max_version_status int;
	DECLARE @IdentityValue AS TABLE(ID INT);
	Declare @new_file_id int;
	--Declare @child_file_template_id int;
	--Declare @child_file_template_version int;
	--Declare @child_file_template_identifier int;
	--Declare @file_transmission_connection_id int;
	declare @new_file_format_supported int;
	Declare @oldTpId int =null;
    Declare @oldLobId int =null;
	SET @Error_code=0;


	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int)
	
	IF OBJECT_ID('idis-metainfo.dbo.TEMP_VERSION_RULE_OLDNEWKEY') IS NULL 
	BEGIN
	CREATE TABLE [idis-metainfo].dbo.TEMP_VERSION_RULE_OLDNEWKEY (file_id int, new_id int, old_id int ,rule_version int)
	END;

	IF OBJECT_ID('idis-metainfo.dbo.TEMP_VERSION_RULE_OLDNEWKEY') IS NOT NULL 
	BEGIN
	delete from [idis-metainfo].dbo.TEMP_VERSION_RULE_OLDNEWKEY where file_id=@iFile_id
	END;

	
	BEGIN TRY 
	
	SELECT @iFile_max_version =  [file_version], @iFile_max_version_status =  [approval_status_id], @file_type_id = [file_type_id], @file_supported_id=file_format_supported_id
	from [file_meta_info] where [file_id] = @iFile_id and file_version in (select MAX([file_version]) from [file_meta_info] where file_id = @iFile_id )

	--- Get a new file version according to flag and selected feature...
	IF(@isRestored_versioning = 1 AND @iFile_max_version_status in (1,2))
	BEGIN
		print ' -- deleteion SP....'
		--IF(@iFile_old_version = @iFile_max_version)
		--BEGIN
		--	SET @iFile_old_version = @iFile_max_version - 1;
		--END
	   EXEC [dbo].[USP_File_Template_Deletion] @iFile_id = @iFile_id,@iFile_version = @iFile_max_version,@file_type_id = @file_type_id
	   SET @new_file_version= @iFile_max_version;
	  -- SET @iFile_old_version = (@iFile_max_version - 1)
	END 
	ELSE IF(@isCopyOfFile = 1)
	BEGIN
		SET @new_file_version= 1;
	END
	ELSE
	BEGIN
	 SET @new_file_version= @iFile_max_version+1;
	END


	SELECT @file_identifier_old=record_id ,@oldTpId=ftpla.trading_partner_id,@oldLobId=ftpla.lob_id
	    from [dbo].[file_meta_info] fmi join [dbo].[file_trading_partner_lob_assoc] ftpla on
		fmi.record_id=ftpla.file_identifier
		where [file_id] = @iFile_id and [file_version]=@iFile_old_version

	IF(@isCopyOfFile = 1)
	BEGIN
	    insert into file_id_generator( created_by, created_date_time)  OUTPUT Inserted.file_id INTO @IdentityValue VALUES( @iCreated_by, GETDATE())
		select @new_file_id = id from @IdentityValue
	END;

	
	BEGIN
	SELECT @new_file_format_supported=MAX([file_format_supported_id])+1 from [dbo].[file_format_supported]
	DBCC CHECKIDENT ('file_format_supported', RESEED, @new_file_format_supported)
	SET IDENTITY_INSERT [dbo].[file_format_supported] ON;
	INSERT INTO [dbo].[file_format_supported]
           ([file_format_supported_id]
		   ,[file_format_name]
           ,[file_format_row_delimiter]
           ,[file_format_field_delimiter]
           ,[file_format_escape_char]
           ,[file_format_segment_delimiter]
           ,[file_has_header]
           ,[file_has_footer]
           ,[file_header_line_count]
           ,[file_footer_line_count]
           ,[file_lines_skip_count]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
     SELECT
           @new_file_format_supported
		   ,file_format_name
           ,file_format_row_delimiter
           ,file_format_field_delimiter
           ,file_format_escape_char
           ,file_format_segment_delimiter
           ,file_has_header
           ,file_has_footer
           ,file_header_line_count
           ,file_footer_line_count
           ,file_lines_skip_count
           ,@iCreated_by
           ,getDate()
           ,@iCreated_by
           ,getDate() from file_format_supported where file_format_supported_id=@file_supported_id;
	SET IDENTITY_INSERT [dbo].[file_format_supported] OFF;
		

		-- Duplicating the file meta info row with same file id and new version 
		 
		INSERT INTO [dbo].[file_meta_info]
		 ([file_id]
		  ,[file_type_id]
		  ,[master_file_template_id]
		  ,[master_file_template_version]
		  ,[file_version]
		  ,[file_name]
		  ,[is_multi_employer]
		  ,[file_status]
		  ,[old_file_id]
		  ,[archival_location]
		  ,[file_processing_error_threshold_count]
		  ,[file_min_record_count_allowed]
		  ,[file_format_supported_id]
		  ,[trading_partner_platform_id]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time]
		  ,[is_active]
		  ,[approval_status_id]
		  ,[approval_status_updated_by]
		  ,[approval_status_updated_date]
		  ,[approval_status_comment]
		  ,[append_file_run_date]
		  ,[file_max_record_count_allowed]
		  ,[file_processing_error_threshold_format]
		  ,[file_idis_ba_name]
		  ,[file_idis_ba_email_id]
		  ,[master_file_template_record_id]
		  ,[is_SLA_mapped]
		  ,[data_source_type_id]
		  ,[data_target_type_id]
		  ,[is_template])
		(SELECT (CASE when @isCopyOfFile = 1  THEN @new_file_id ELSE [file_id] END)  as file_id
		  ,[file_type_id]
		  ,[master_file_template_id]
		  ,[master_file_template_version]
		  ,@new_file_version
		  ,(CASE when @isCopyOfFile = 1  THEN  @copiedFileName ELSE [file_name] END) as [file_name]
		  ,[is_multi_employer]
		  ,[file_status]
		  ,NULL
		  ,[archival_location]
		  ,[file_processing_error_threshold_count]
		  ,[file_min_record_count_allowed]
		  ,@new_file_format_supported
		  ,case when (@isCopyOfFile=1 and @oldTpId=@copiedTpId) then [trading_partner_platform_id] else NULL end
		  ,@iCreated_by
		  ,getDate()
		 ,@iCreated_by
		  ,getDate()
		  ,0
		  ,1
		  ,NULL
		  ,NULL
		  ,NULL
		  ,[append_file_run_date]
		  ,[file_max_record_count_allowed]
		  ,[file_processing_error_threshold_format]
		  ,(CASE when @isCopyOfFile = 1  THEN  @iCreated_by ELSE [file_idis_ba_name] END) as [file_idis_ba_name]
		  ,(CASE when @isCopyOfFile = 1  THEN  @copiedAnalystName ELSE [file_idis_ba_email_id] END) as [file_idis_ba_email_id]
		  ,[master_file_template_record_id]
		  ,[is_SLA_mapped]
		  ,[data_source_type_id]
		  ,[data_target_type_id]
		  ,(CASE when @isCopyOfFile = 1 THEN 0 ELSE [is_template] END)		  
		  FROM [dbo].[file_meta_info] WHERE [file_id] = @iFile_id AND [file_version] = @iFile_old_version)
	
		 
	  if(@isCopyOfFile = 1)
	  BEGIN
		select @file_identifier = record_id  FROM [dbo].[file_meta_info] WHERE [file_id] = @new_file_id AND [file_version] = @new_file_version;
		 SET @oFile_identifier = @file_identifier
	  END
	  ELSE
	  BEGIN
		 select @file_identifier = record_id  FROM [dbo].[file_meta_info] WHERE [file_id] = @iFile_id AND [file_version] = @new_file_version;
		 SET @oFile_identifier = @file_identifier
	  END
	  		 
		INSERT INTO [dbo].[file_employer_assoc] 
		([file_identifier]
			,[client_employer_assoc_id]
			,[created_by]
			,[created_date_time]
			,[updated_by]
			,[updated_date_time]
			)
		(SELECT 
			@file_identifier
			,[client_employer_assoc_id]
			,@iCreated_by
			,getDate()
			,@iCreated_by
			,getDate()
		FROM [file_employer_assoc] WHERE [file_identifier] = @file_identifier_old)

			
		INSERT INTO [dbo].[file_linked_urls_assoc] 
		([file_identifier]
			,[file_name]
			,[file_associated_website]
			,[is_active]
			,[created_by]
			,[created_date_time]
			,[updated_by]
			,[updated_date_time]
		)
		(SELECT @file_identifier
			,[file_name]
			,[file_associated_website]
			,[is_active]
			,@iCreated_by
			,getDate()
			,@iCreated_by
			,getDate()
			 FROM [dbo].[file_linked_urls_assoc] WHERE [file_identifier] = @file_identifier_old)

		INSERT INTO [dbo].[file_trading_partner_lob_assoc]
		(	[trading_partner_id]
			,[lob_id]
			,[file_identifier]
			,[created_by]
			,[created_date_time]
			,[updated_by]
			,[updated_date_time]
		)
		(SELECT case when @isCopyOfFile=1 then @copiedTpId else trading_partner_id end
			,case when @isCopyOfFile=1 then @copiedLobId else lob_id end
			,@file_identifier
			,@iCreated_by
			,getDate()
			,@iCreated_by
			,getDate() FROM [dbo].[file_trading_partner_lob_assoc] WHERE [file_identifier] = @file_identifier_old)
				
		INSERT INTO [dbo].[idis_team_file_association]
		([idis_team_id]
			,[file_identifier]
			,[created_date]
			,[created_by]
		)
		(SELECT [idis_team_id]
			,@file_identifier
			,getDate()
			,@iCreated_by FROM [dbo].[idis_team_file_association] WHERE [file_identifier] = @file_identifier_old) 

		/* ADAPT-2717 - User should be able to edit Trading Partner & LOB while copying the file */	
		if(@isCopyOfFile=0)
		begin
			INSERT INTO [dbo].[file_notification_template_contact_assoc]
			([template_id]
			,[trading_partner_contact_type_id]
			,[trading_partner_contact_id]
			,[file_identifier]
			,[is_active]
			,[created_date_time]
			,[created_by]
			,[updated_date_time]
			,[updated_by]
			,[is_file_analyst]
			,[idis_team_id]
			)
			(SELECT [template_id]
			,[trading_partner_contact_type_id]
			,[trading_partner_contact_id]
			,@file_identifier
			,[is_active]
			,getDate()
			,@iCreated_by
			,getDate()
			,@iCreated_by
			,[is_file_analyst]
			,[idis_team_id]
			FROM [dbo].[file_notification_template_contact_assoc] WHERE [file_identifier] = @file_identifier_old)
		
		
			-- ADAPT-642 - User should be able to configure connection/key with File. 
			INSERT INTO [dbo].[file_transmission_info] 
			([file_identifier],[adapt_env_id],[trading_partner_connection_id],[trading_partner_auth_key_id],[is_active]
			,[created_by],[created_date_time],[updated_by],[updated_date_time],[transmission_name],[path],[set_as_default])
			(SELECT @file_identifier,[adapt_env_id],[trading_partner_connection_id],[trading_partner_auth_key_id],[is_active]
			,@iCreated_by,GETDATE(),NULL,NULL,[transmission_name],[path],[set_as_default]
			from [dbo].[file_transmission_info]   where [file_identifier] = @file_identifier_old)
		end
		
		-- inserting in audit table to maintain the version history with ids 
		print 'Data auditing'
		INSERT INTO [dbo].[file_version_audit]
				([file_id]
				,[from_version]
				,[to_version]
				,[created_date]
				,[created_by]
				,[approval_status_id])
			VALUES
				((CASE when @isCopyOfFile = 1  THEN @new_file_id ELSE @iFile_id END)
				,@iFile_old_version
				,@new_file_version
				,GETDATE()
				,@iCreated_by
				,1)	


		BEGIN

			-- Versioning for cloned attribures.
			INSERT INTO [dbo].[file_clone_info]
			([file_identifier]
			,[clone_num]
			,[clone_name]
			,[created_by]
			,[created_date_time]
			,[updated_by]
			,[updated_date_time]
			)
			(SELECT @file_identifier
			,[clone_num]
			,[clone_name]
			,@iCreated_by
			,GETDATE()
			,@iCreated_by
			,GETDATE() from [dbo].[file_clone_info] where file_identifier = @file_identifier_old)
			  
--- get record count for rules ----
DECLARE @RULES_COUNT INT
SET @RULES_COUNT = (select count(1) from file_attribute_association faa
join file_attr_br_assoc faba on faa.faa_id=faba.faa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=faba.business_rule_id
where faa.[file_identifier] = @file_identifier_old
)
+
(select count(1) from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='F' and ltmi.associated_file_level_id=@file_identifier_old AND ltmi.lookup_table_version = @iFile_old_version
and ltmi.associated_file_type_id=@file_type_id
)


--select 'done till rule count'


if @RULES_COUNT>0
BEGIN
--Duplicating the Business Rules Association rows with same id and new versions
--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2


INSERT into TEMP_VERSION_RULE_OLDNEWKEY (file_id,new_id,old_id,rule_version)
(select @iFile_id,@NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version+1 from (
select drools_business_rule_id,drools_business_rule_version from file_attribute_association faa
join file_attr_br_assoc faba on faa.faa_id=faba.faa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=faba.business_rule_id
where faa.[file_identifier] = @file_identifier_old
union
select drools_business_rule_id,drools_business_rule_version from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='F' and ltmi.associated_file_level_id=@file_identifier_old AND ltmi.lookup_table_version = @iFile_old_version
and ltmi.associated_file_type_id=@file_type_id
) a)

SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join TEMP_VERSION_RULE_OLDNEWKEY
on drools_business_rule_id=old_id and file_id=@iFile_id)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

END;


select 'done till rule copying...'			  

	SET @counter = 1;

    DECLARE cur CURSOR LOCAL FOR SELECT [fsa_id],[template_section_id] FROM [dbo].[file_section_association] where [file_identifier] = @file_identifier_old;
  
		OPEN cur;

		FETCH NEXT FROM cur INTO @fsa_id,@template_section_id;
		WHILE @@FETCH_STATUS = 0
		BEGIN

			/** Inserting data into section assoc table for new Version */
			INSERT INTO [dbo].[file_section_association]
				([template_section_id]
			  ,[file_compliant_section_short_name]
			  ,[file_identifier]
			  ,[sequence]
			  ,[section_display_name]
			  ,[is_mandatory]
			  ,[created_by]
			  ,[created_date_time]
			  ,[updated_by]
			  ,[updated_date_time])
			  OUTPUT INSERTED.[fsa_id],@fsa_id,@counter INTO @inserted([ID],[old_id],[counter])
		(SELECT [template_section_id]
			  ,[file_compliant_section_short_name]
			  ,@file_identifier
			  ,[sequence]
			  ,[section_display_name]
			  ,[is_mandatory]
			  ,@iCreated_by
			  ,getDate()
			  ,@iCreated_by
			  ,getDate() FROM [dbo].[file_section_association] WHERE [fsa_id] = @fsa_id)

			  
			  SET  @counter = @counter + 1;
		
			SELECT @NewFileSectionId = [fsa_id] FROM [dbo].[file_section_association] WHERE [file_identifier] = @file_identifier;
			
			DECLARE attrcur CURSOR LOCAL FOR SELECT [fsa_id],[faa_id],[attribute_id] FROM [dbo].[file_attribute_association] where [file_identifier] = @file_identifier_old and fsa_id=@fsa_id;
							OPEN attrcur;

							FETCH NEXT FROM attrcur INTO @fsa_id_FK,@faa_id,@attribute_id;
							WHILE @@FETCH_STATUS = 0
							BEGIN
							
								
								INSERT INTO [dbo].[file_attribute_association]
								([fsa_id]
								  ,[attribute_id]
								  ,[data_type]
								  ,[is_mandatory]
								  ,[attribute_size]
								  ,[attribute_row_position]
								  ,[attribute_start_position]
								  ,[attribute_end_position]
								  ,[is_inherited]
								  ,[file_identifier]
								  ,[created_by]
								  ,[created_date_time]
								  ,[updated_by]
								  ,[updated_date_time]
								  ,[file_format_compliant_attribute_name]
								  ,[clone_num]
								  ,[to_do])
						(SELECT @NewFileSectionId
							  ,[attribute_id]
							  ,[data_type]
							  ,[is_mandatory]
							  ,[attribute_size]
							  ,[attribute_row_position]
							  ,[attribute_start_position]
							  ,[attribute_end_position]
							  ,[is_inherited]
							  ,@file_identifier
							  ,@iCreated_by
							  ,getDate()
							  ,@iCreated_by
							  ,getDate()
							  ,[file_format_compliant_attribute_name]
							  ,[clone_num], [to_do] FROM [dbo].[file_attribute_association] WHERE
							 [file_identifier] = @file_identifier_old and fsa_id=@fsa_id_FK and faa_id=@faa_id and attribute_id=@attribute_id)
									
						              
							SELECT @NewAttrId=[faa_id]
									FROM dbo.file_attribute_association WHERE fsa_id=@NewFileSectionId and attribute_id=@attribute_id and [file_identifier] = @file_identifier;
							
							insert into #TEMP_OLDNEWKEY(new_id,old_id) values(@NewAttrId,@faa_id)							
																
									INSERT INTO [idis-metainfo].[dbo].[file_attr_br_assoc]([faa_id],[business_rule_id],[business_rule_version],[rule_execution_sequence]
									,[created_by],[created_date_time],[updated_by], [updated_date_time],[profile_id],[rule_execution_comment])
									(SELECT @NewAttrId,C.new_id,C.rule_version,D.rule_execution_sequence,@iCreated_by,GETDATE(),@iCreated_by,GETDATE(),profile_id,rule_execution_comment 
									FROM [idis-metainfo].[dbo].[file_attr_br_assoc] D INNER JOIN TEMP_VERSION_RULE_OLDNEWKEY C 
									ON D.business_rule_id=C.old_id  and C.file_id=@iFile_id where D.faa_id = @faa_id)									
	
									
									FETCH NEXT FROM attrcur INTO @fsa_id_FK,@faa_id,@attribute_id;
						END
						CLOSE attrcur    
						DEALLOCATE attrcur
				
			FETCH NEXT FROM cur INTO @fsa_id,@template_section_id;
		END
		CLOSE cur    
		DEALLOCATE cur

INSERT INTO [dbo].[file_secondary_mapping_attr_assoc]
		([fsmaa_file_identifier]
		,[fsmaa_faa_id]
		,[fsmaa_node_name]
		,[fsmaa_standardized_name]
		,[created_date_time]
		,[created_by]
		,[updated_date_time]
		,[updated_by]
		)
		(SELECT @file_identifier
		,temp.new_id
		,[fsmaa_node_name]
		,[fsmaa_standardized_name]
		,getDate()
		,@iCreated_by
		,getDate()
		,@iCreated_by
			FROM [dbo].[file_secondary_mapping_attr_assoc] 
			join #TEMP_OLDNEWKEY temp on temp.old_id=fsmaa_faa_id
			WHERE [fsmaa_file_identifier] = @file_identifier_old)
			
--select 'done till attribute copying...'			  
		
		SET @counter = 1
		SELECT @total_row = COUNT(1) from @inserted
		WHILE(@counter <= @total_row )
			BEGIN
				SELECT @new_fsa_id = ID, @old_fsa_id = old_id from @inserted where [counter] = @counter
				SET @counter = @counter+ 1;	
			END
			
									DECLARE @NEW_LTMI_RESEED INT
									DECLARE @CURRENT_LTMI_RESEED INT
									DECLARE @NEW_LTMI_INDENT INT
									SET @CURRENT_LTMI_RESEED=(SELECT IDENT_CURRENT( 'lookup_table_meta_info' ) AS A)
									SET @NEW_LTMI_RESEED =@CURRENT_LTMI_RESEED+5
									DBCC CHECKIDENT ('lookup_table_meta_info', RESEED, @NEW_LTMI_RESEED)
									SET @NEW_LTMI_INDENT=@CURRENT_LTMI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END
									CREATE TABLE #TEMP_LT_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_LT_OLDNEWKEY (new_id,old_id) (select @NEW_LTMI_INDENT+Row_number() Over(Order by lookup_table_id),lookup_table_id
									from lookup_table_meta_info where associated_file_level='F' and associated_file_level_id=@file_identifier_old 
									and associated_file_type_id=@file_type_id)
									
									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON 
									insert into lookup_table_meta_info(lookup_table_id,lookup_table_name,lookup_key_description,lookup_table_version,associated_file_level,associated_file_level_id,
									associated_file_type_id,created_by,created_date_time)
									(select new_id,lookup_table_name,lookup_key_description,1,associated_file_level,@file_identifier, associated_file_type_id,@iCreated_by,getDate()
									from lookup_table_meta_info join #TEMP_LT_OLDNEWKEY temp on lookup_table_id=old_id
									where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id)
									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF

									insert into lookup_table_details (lookup_table_id,lookup_table_version,lookup_key,lookup_value,created_by,created_date_time)
									(select temp.new_id,1,lookup_key,lookup_value,@iCreated_by,getDate() from lookup_table_details ltd
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltd.lookup_table_id and ltmi.lookup_table_version=ltd.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY temp on ltmi.lookup_table_id=temp.old_id
									where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id )

									insert into lookup_table_composite_key_mapping(lookup_table_id,lookup_table_version,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,business_rule_id,
									created_by,created_date_time, updated_by, updated_date_time)(select templt.new_id,1 ,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,
									case when business_rule_id is NULL then NULL when business_rule_id is NOT NULL then temp.new_id end,
									@iCreated_by,getDate(), @iCreated_by,getDate() from lookup_table_composite_key_mapping ltckm LEFT OUTER JOIN TEMP_VERSION_RULE_OLDNEWKEY temp on temp.old_id=business_rule_id
									 and temp.file_id=@iFile_id
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltckm.lookup_table_id and ltmi.lookup_table_version=ltckm.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id )

									insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,is_active,created_by,created_date_time, updated_by, updated_date_time)
									(select templt.new_id,1 ,temp.new_id,mftaa_id,1,@iCreated_by,getDate(),@iCreated_by,getDate()
									from lookup_table_file_association ltfa  join #TEMP_OLDNEWKEY temp on faa_id=temp.old_id
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='F' and associated_file_level_id=@file_identifier_old and associated_file_type_id=@file_type_id and is_active=1)

select 'done till lookup table copying...'			  

		IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END

								
				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
			
									DECLARE @NEW_FLSNI_RESEED INT
									DECLARE @CURRENT_FLSNI_RESEED INT
									DECLARE @NEW_FLSNI_INDENT INT
									SET @CURRENT_FLSNI_RESEED=(SELECT IDENT_CURRENT( 'file_layout_schema_node_info' ) AS A)
									SET @NEW_FLSNI_RESEED =@CURRENT_FLSNI_RESEED+5 + (select count(1) from file_layout_schema_node_info where file_identifier=@file_identifier
											 and is_active=1)
									DBCC CHECKIDENT ('file_layout_schema_node_info', RESEED, @NEW_FLSNI_RESEED)
									SET @NEW_FLSNI_INDENT=@CURRENT_FLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_FLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_FLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_FLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_FLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_FLSNI_INDENT+Row_number() Over(Order by flsni_id),flsni_id
									from file_layout_schema_node_info flsni join file_meta_info fmi 
									on flsni.file_identifier=fmi.record_id where 
									fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and flsni.is_active=1)

									--select '##TEMP_FLSNI_OLDNEWKEY'
									--select * from #TEMP_FLSNI_OLDNEWKEY
									
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] ON 
									INSERT INTO [dbo].[file_layout_schema_node_info]([flsni_id],[file_identifier],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num])
									SELECT new_id,@file_identifier,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@iCreated_by,getDate()
									,@iCreated_by,getDate(),[node_max_size],[node_min_size],[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num]
									FROM file_layout_schema_node_info flsni 
									join #TEMP_FLSNI_OLDNEWKEY on flsni.flsni_id=old_id
									join file_meta_info fmi on flsni.file_identifier=fmi.record_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and flsni.is_active=1
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] OFF
									
									--select '[file_layout_schema_node_info]'

									INSERT INTO [dbo].[file_layout_schema_node_assoc]([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time], [updated_by], [updated_date_time])
									SELECT a.new_id,
									case when parent_flsni_id is NULL then NULL else b.new_id end,
									node_has_children,@iCreated_by,getDate(),@iCreated_by,getDate() from [file_layout_schema_node_assoc] flsna
									join file_layout_schema_node_info flsni on flsni.flsni_id=flsna.flsni_id
									join file_meta_info fmi on flsni.file_identifier=fmi.record_id
									join #TEMP_FLSNI_OLDNEWKEY a on flsni.flsni_id=a.old_id left outer join #TEMP_FLSNI_OLDNEWKEY b on flsna.parent_flsni_id=b.old_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and flsni.is_active=1

									--select '[file_layout_schema_node_assoc]'
									
									
									INSERT INTO [dbo].[fls_node_dm_element_assoc]([flsni_id],[faa_id],[is_active],[created_by],[created_date_time], [updated_by], [updated_date_time])
									SELECT a.new_id,b.new_id,flsnda.is_active,@iCreated_by,getDate(),@iCreated_by,getDate() from fls_node_dm_element_assoc flsnda 
									join file_layout_schema_node_info flsni on flsni.flsni_id=flsnda.flsni_id
									join file_meta_info fmi on flsni.file_identifier=fmi.record_id 
									join #TEMP_OLDNEWKEY b on faa_id=b.old_id
									join #TEMP_FLSNI_OLDNEWKEY a on flsni.flsni_id=a.old_id 
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and flsni.is_active=1 
									

									--select '[[[fls_node_dm_element_assoc]]]'



			--- get record count for rules ----
	SET @RULES_COUNT = (select count(1) from fls_node_br_assoc flsnba
	join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=flsnba.business_rule_id
	join file_layout_schema_node_info flsni on flsni.flsni_id=flsnba.flsni_id
	join file_meta_info fmi on flsni.file_identifier=fmi.record_id
	where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version and flsni.is_active=1
	)


	select 'done till rule count'


	if @RULES_COUNT>0
	BEGIN
	--Duplicating the Business Rules Association rows with same id and new versions
	--- reseed the identity ----
	SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
	SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
	DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
	SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2


	INSERT into TEMP_VERSION_RULE_OLDNEWKEY (file_id,new_id,old_id,rule_version)
	(select @iFile_id,@NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
	,drools_business_rule_id,drools_business_rule_version+1 from (
	select drools_business_rule_id,drools_business_rule_version from fls_node_br_assoc flsnba
	join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=flsnba.business_rule_id
	join file_layout_schema_node_info flsni on flsni.flsni_id=flsnba.flsni_id
	join file_meta_info fmi on flsni.file_identifier=fmi.record_id
	where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version and flsni.is_active=1 
	and drools_business_rule_id not in (select old_id from TEMP_VERSION_RULE_OLDNEWKEY where  file_id=@iFile_id)
	) a)


	SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
	insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
	drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
	drools_business_rule_ui_json_text,created_by,created_date)
	(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
	rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
	drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join TEMP_VERSION_RULE_OLDNEWKEY
	on drools_business_rule_id=old_id  and file_id=@iFile_id where new_id not in (select drools_business_rule_id from drools_business_rules_decision_table))
	SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

	END;


--select 'done till rule copying...'			  


									
									INSERT INTO [dbo].[fls_node_br_assoc]([flsni_id],[business_rule_id],[rule_execution_sequence],[rule_execution_comment],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,rule_execution_comment,1,@iCreated_by,getDate(),@iCreated_by,getDate() from fls_node_br_assoc flsnba 
									join file_layout_schema_node_info flsni on flsni.flsni_id=flsnba.flsni_id
									join file_meta_info fmi on flsni.file_identifier=fmi.record_id
									join TEMP_VERSION_RULE_OLDNEWKEY b on flsnba.business_rule_id=b.old_id  and b.file_id=@iFile_id
									join #TEMP_FLSNI_OLDNEWKEY a on flsni.flsni_id=a.old_id where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and flsni.is_active=1  and flsnba.is_active=1  
									

									
									INSERT INTO [dbo].[fls_node_delimiter_info]([file_identifier],[node_name],[node_delimiter],[node_terminator],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT @file_identifier,node_name,node_delimiter,node_terminator,1,@iCreated_by,getDate(),@iCreated_by,getDate() from fls_node_delimiter_info fndi 
									where fndi.file_identifier=@file_identifier_old and fndi.is_active=1




		--- get record count for rules ----
SET @RULES_COUNT = (select count(1) from file_special_mapping_attr_br_assoc fsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=fsmaba.business_rule_id
where fsmaba.[file_identifier] = @file_identifier_old and fsmaba.is_active=1 and dbrdt.drools_business_rule_id not in (
select faba.business_rule_id from file_attribute_association faa
join file_attr_br_assoc faba on faa.faa_id=faba.faa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=faba.business_rule_id
where faa.[file_identifier] = @file_identifier
union
select ltckm.business_rule_id from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='F' and ltmi.associated_file_level_id=@file_identifier and ltmi.associated_file_type_id=@file_type_id
union
select flsnba.business_rule_id from fls_node_br_assoc flsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=flsnba.business_rule_id
join file_layout_schema_node_info flsni on flsni.flsni_id=flsnba.flsni_id
join file_meta_info fmi on flsni.file_identifier=fmi.record_id
where fmi.record_id=@file_identifier and flsni.is_active=1
) )


--select 'done till rule count'


if @RULES_COUNT>0
BEGIN
--Duplicating the Business Rules Association rows with same id and new versions
--- reseed the identity ----
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2


INSERT into TEMP_VERSION_RULE_OLDNEWKEY (file_id, new_id,old_id,rule_version)
(select @iFile_id,@NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version+1 from (
select drools_business_rule_id,drools_business_rule_version  from file_special_mapping_attr_br_assoc fsmaba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=fsmaba.business_rule_id
where fsmaba.[file_identifier] = @file_identifier_old and fsmaba.is_active=1 and dbrdt.drools_business_rule_id not in (
select faba.business_rule_id from file_attribute_association faa
join file_attr_br_assoc faba on faa.faa_id=faba.faa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=faba.business_rule_id
where faa.[file_identifier] = @file_identifier
union
select ltckm.business_rule_id from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='F' and ltmi.associated_file_level_id=@file_identifier and ltmi.associated_file_type_id=@file_type_id
union
select flsnba.business_rule_id from fls_node_br_assoc flsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=flsnba.business_rule_id
join file_layout_schema_node_info flsni on flsni.flsni_id=flsnba.flsni_id
join file_meta_info fmi on flsni.file_identifier=fmi.record_id
where fmi.record_id=@file_identifier and flsni.is_active=1
--union
--select fepba_br_id from file_ext_param_br_assoc fepba
--join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=fepba.fepba_br_id and fepba.is_active=1
--join file_extraction_parameters_info fepi on fepi.fepi_id=fepba.fepba_fepi_id and fepi.is_active=1
--where fepi.file_identifier=@file_identifier
) ) a where drools_business_rule_id not in (select old_id from TEMP_VERSION_RULE_OLDNEWKEY  where file_id=@iFile_id))


SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join TEMP_VERSION_RULE_OLDNEWKEY
on drools_business_rule_id=old_id  and file_id=@iFile_id where new_id not in (select drools_business_rule_id from drools_business_rules_decision_table))
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

END;
			

									INSERT INTO [dbo].[file_special_mapping_attr_br_assoc] ([file_identifier],[business_rule_id],[ftaa_id],[attribute_usage_type],[is_active],[created_by],[created_date_time])
									(SELECT @file_identifier, new_id, ftaa_id,attribute_usage_type,1,@iCreated_by,getDate() from file_special_mapping_attr_br_assoc fsmaba 
									left join TEMP_VERSION_RULE_OLDNEWKEY a on fsmaba.business_rule_id=a.old_id  and a.file_id=@iFile_id
									where fsmaba.is_active=1 and fsmaba.file_identifier=@file_identifier_old)
									
	
			
--select 'done till dynamic schema copying...'			  
				------------------------------------------------------------------------------------------------
				----------------------------------------- Extraction Parameters ---------------------------------------
				------------------------------------------------------------------------------------------------
			
									DECLARE @NEW_FEPI_RESEED INT
									DECLARE @CURRENT_FEPI_RESEED INT
									DECLARE @NEW_FEPI_IDENT INT
									SET @CURRENT_FEPI_RESEED=(SELECT IDENT_CURRENT( 'file_extraction_parameters_info' ) AS A)
									SET @NEW_FEPI_RESEED =@CURRENT_FEPI_RESEED+5
									DBCC CHECKIDENT ('file_extraction_parameters_info', RESEED, @NEW_FEPI_RESEED)
									SET @NEW_FEPI_IDENT=@CURRENT_FEPI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_FEPI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_FEPI_OLDNEWKEY; END
									CREATE TABLE #TEMP_FEPI_OLDNEWKEY ( new_id int, old_id int)


									select @NEW_FEPI_IDENT+Row_number() Over(Order by fepi_id),fepi_id
									from file_extraction_parameters_info fepi join file_meta_info fmi 
									on fepi.file_identifier=fmi.record_id where 
									fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1

									INSERT into #TEMP_FEPI_OLDNEWKEY (new_id,old_id) (select @NEW_FEPI_IDENT+Row_number() Over(Order by fepi_id),fepi_id
									from file_extraction_parameters_info fepi join file_meta_info fmi 
									on fepi.file_identifier=fmi.record_id where 
									fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1)
									
									select 'data dumped to #TEMP_FEPI_OLDNEWKEY'

									SELECT new_id,@file_identifier,fepi_profile_id ,fepi_is_adv_selection_criteria ,fepi_is_change_criteria ,fepi.is_active ,
									@iCreated_by,getDate()
									FROM file_extraction_parameters_info fepi join #TEMP_FEPI_OLDNEWKEY on fepi.fepi_id=old_id
									join file_meta_info fmi on fepi.file_identifier=fmi.record_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1

									SET IDENTITY_INSERT [dbo].[file_extraction_parameters_info] ON 
									INSERT INTO [dbo].[file_extraction_parameters_info](fepi_id ,file_identifier ,fepi_profile_id ,fepi_is_adv_selection_criteria ,fepi_is_change_criteria ,is_active ,
									created_by ,created_date_time, updated_by, updated_date_time)
									SELECT new_id,@file_identifier,fepi_profile_id ,fepi_is_adv_selection_criteria ,fepi_is_change_criteria ,fepi.is_active ,@iCreated_by,getDate(),@iCreated_by,getDate()
									FROM file_extraction_parameters_info fepi join #TEMP_FEPI_OLDNEWKEY on fepi.fepi_id=old_id
									join file_meta_info fmi on fepi.file_identifier=fmi.record_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1
									SET IDENTITY_INSERT [dbo].[file_extraction_parameters_info] OFF

									select 'data dumped to [file_extraction_parameters_info]'

									SELECT new_id, fepa.fepa_ep_id, fepa.fepa_criteria_unique_identifier, fepa.fepa_criteria_display_value, fepa.is_active,@iCreated_by,getDate() 
									from [file_extraction_parameters_assoc] fepa
									join file_extraction_parameters_info fepi on fepi.fepi_id = fepa.fepa_fepi_id
									join file_meta_info fmi on fepi.file_identifier=fmi.record_id
									join #TEMP_FEPI_OLDNEWKEY a on fepa.fepa_fepi_id=a.old_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1
									
									INSERT INTO [dbo].[file_extraction_parameters_assoc](fepa_fepi_id ,fepa_ep_id ,fepa_criteria_unique_identifier ,fepa_criteria_display_value ,is_active ,created_by ,created_date_time, updated_by, updated_date_time)
									SELECT new_id, fepa.fepa_ep_id, fepa.fepa_criteria_unique_identifier, fepa.fepa_criteria_display_value, fepa.is_active,@iCreated_by,getDate(),@iCreated_by,getDate()  
									from [file_extraction_parameters_assoc] fepa
									join file_extraction_parameters_info fepi on fepi.fepi_id = fepa.fepa_fepi_id
									join file_meta_info fmi on fepi.file_identifier=fmi.record_id
									join #TEMP_FEPI_OLDNEWKEY a on fepa.fepa_fepi_id=a.old_id
									where fmi.file_id=@iFile_id AND fmi.file_version = @iFile_old_version
									and fepi.is_active=1

									select 'data dumped to [file_extraction_parameters_assoc]'
									
									--INSERT INTO [dbo].[file_ext_param_br_assoc] ([fepba_fepi_id],[fepba_ep_id],[fepba_br_id],[is_active],[created_by],[created_date_time],[profile_id])
									--(SELECT a.new_id,fepba_ep_id, b.new_id,1,@iCreated_by,getDate(),profile_id from file_ext_param_br_assoc fepba 
									--join #TEMP_FEPI_OLDNEWKEY a on fepba.fepba_fepi_id=a.old_id
									--join TEMP_VERSION_RULE_OLDNEWKEY b on fepba.fepba_br_id=b.old_id  and b.file_id=@iFile_id
									--where fepba.is_active=1)
									
									--select 'data dumped to [file_ext_param_br_assoc]'
									
--select 'done till extractor copying...'
	END			  	
	END
	COMMIT TRANSACTION;
		SET @oError_code = 0;
		SET @Error_code = 0;
	END TRY
	
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
		SET @Error_code= -1;
	END CATCH 
	
	

	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END

	
	 END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @Error_code = -2)
			BEGIN
			print 'Error: A draft has already been created for the file. A new draft cannot be created...'
			SET @oError_code=@Error_code
			RETURN -2
		END
		ELSE IF ( @Error_code = -3)
			BEGIN
			print 'Error:  File name or file transmission name can not be null or blank...'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE IF ( @Error_code = -4)
			BEGIN
			print 'Error:  File name must be unique...'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE IF ( @Error_code = -5)
			BEGIN
			print 'Error:  File transmission name must be unique...'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE IF ( @Error_code <> 0)
			BEGIN
			print 'Error: Some Error occured while creating a version'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE
			BEGIN
			print 'File Version created Successfully... '
			SET @oError_code=0
			RETURN 0
		END 
 END;

   
GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.[Proc_File_Versioning] TO exec_proc
GO
