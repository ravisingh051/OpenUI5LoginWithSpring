use [idis-metainfo]

if not exists(select 1 from master_file_template_section_assoc where master_file_template_record_id=18 and section_display_name='Election' and mftsa_id=79)
begin
update master_file_template_section_assoc set section_display_name='Election' where master_file_template_record_id=18 and mftsa_id=79
end;
GO
