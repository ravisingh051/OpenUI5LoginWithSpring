use [idis-metainfo]
GO


/*
Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-30   Divya Jain			ADAPT-7707 : Update rules for using the template
*/


-- add Action for 'Use As Template' for File Setup 
if not exists (select 1 from idis_dbrd_func_actions where functionality_id =5 and action_name=N'Use As Template' and action_id=98)
BEGIN
SET IDENTITY_INSERT [dbo].[idis_dbrd_func_actions] ON
INSERT [dbo].[idis_dbrd_func_actions] ([action_id], [action_name], [functionality_id], [is_allowed_on_prod], [created_by], [created_date], [updated_by], [updated_date], [is_group_check_applicable]) VALUES (98, N'Use As Template', 5, 1, N'Dattu Dave', getDate(), NULL, NULL, 0)
SET IDENTITY_INSERT [dbo].[idis_dbrd_func_actions] OFF
END
GO

-- add Role Level 6 and 7 for Action 'Use As Template'
if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id in (10, 11) and action_id =98 and role_action_assoc_id in(471,472))
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (471,10,98,N'Dattu Dave',getDate(),NULL,NULL);
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (472,11,98,N'Dattu Dave',getDate(),NULL,NULL);
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF
END
GO

--add web page filed 'Use As Template' for 'New file setup-Basic Configuration'
if not exists (select 1 from adapt_web_page_fields where adapt_web_page_id = 16 and adapt_web_page_field_name ='Use As Template' and  adapt_web_page_field_id=277)
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_web_page_fields] ON
INSERT [dbo].[adapt_web_page_fields]([adapt_web_page_field_id], [adapt_web_page_id] , [adapt_web_page_field_name], [adapt_web_page_field_desc], [is_active], [created_by], [updated_by], [created_date_time], [updated_date_time]) VALUES (277, 16, N'Use As Template', N'Use As Template', 1, N'Dattu Dave',NULL,getDate(),NULL)
SET IDENTITY_INSERT [dbo].[adapt_web_page_fields] OFF
END
GO

