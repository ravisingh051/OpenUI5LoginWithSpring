use [idis-metainfo]
GO

/*
Filename:  V10.7059__update_processing_system_events_for_Dataset Delivery Failed_event.sql

Update Log
Date         Author            	Description
----------   ----------------   --------------------------------------------------------------------------------------------
2019-08-01   Jinesh Vora  		ADAPT-7059 : User should receive notification for Dataset Delivery Failed
-- Table 
-- job_event_log
-- processing_system_events


*/

if EXISTS (SELECT 1 FROM processing_system_events where event_id=14 and event_name = 'TRANSMISSION_RE-TRIES_FAILURE')
BEGIN
Update processing_system_events  SET event_name = 'DATASET_DELIVERY_FAILED',event_description = 'Dataset Delivery Failed',updated_by = 'Jinesh vora',updated_date_time = getdate() where event_id = 14 and event_name='TRANSMISSION_RE-TRIES_FAILURE';
END;
GO

-- Add node column into job_event_log table
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='job_event_log' and column_name ='jel_node' 
)
BEGIN
ALTER TABLE job_event_log Add jel_node varchar(100);
END;
GO

-- Update node values for existing inbound files with 'Default'
if not exists(select 1 from job_event_log where jel_node is null)
BEGIN
Update job_event_log SET jel_node = 'Default' where jel_node is null;
END;
GO

