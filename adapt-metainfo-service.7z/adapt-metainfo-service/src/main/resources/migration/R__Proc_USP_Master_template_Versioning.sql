USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[Proc_Master_template_Versioning]    Script Date: 2/22/2018 4:30:47 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.Proc_Master_template_Versioning') IS NULL
EXEC('CREATE PROCEDURE dbo.Proc_Master_template_Versioning AS SELECT 1')
GO

/*
Filename:  Proc_Master_template_Versioning.sql
 
This procedue is used when updates are made to the master/child templates and files
Parameters: 
@iMasterTemplate_id - Master template Id
@iMasterTemplate_old_version - Master template version
@iCreated_by - username, who creates version for audit 
@isRestored_versioning - is old version restoring flag
 
*********************************************************************************************************

Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2018-12-26	Richa Ashara	ADAPT-307: User should be able to view the Last updated information for PMT/File Templates & Job Schedule
2019-06-25	Divya Jain		ADAPT-6510: USP_Get_Dynamic_Schema_Attribute- values under 'columnOrder' are NULL
2019-09-12	Snehal Patel	ADAPT-2993 : Column names in tables - Characters are missing - misspelled - Example foreign key - DB - High - Beyond Phase 2.
2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs
2019-10-15	Snehal Patel	ADAPT-7998: Remove enumerated values and print display name
*/

IF OBJECT_ID('dbo.Proc_Master_template_Versioning') IS NULL
EXEC('CREATE PROCEDURE dbo.Proc_Master_template_Versioning AS SELECT 1')
GO

ALTER procedure [dbo].[Proc_Master_template_Versioning]
   @iMasterTemplate_id int,
   @iMasterTemplate_old_version int,
   @iCreated_by varchar(50),
   @isRestored_versioning bit,
   @oError_code int OUTPUT
   AS 
   BEGIN


	DECLARE @NewMasterId INT;
	DECLARE @NewMasterRecordId INT;
	DECLARE @Error_code INT;
	DECLARE @mftaa_id INT;
	DECLARE @mftsa_id INT;
	DECLARE @mftsa_id_FK INT;
	DECLARE @attribute_id INT;
	DECLARE @NewAttrId INT;
	DECLARE @NewTemplateSectionId INT;
	DECLARE @template_section_id INT;
	DECLARE @parent_mftsa_id INT;
	DECLARE @new_mftsa_id INT;
	DECLARE @counter INT;
	DECLARE @total_row INT;
	DECLARE @inserted TABLE ([ID] INT, [old_id] INT,[counter] INT);
	DECLARE @old_mftsa_id INT;
	DECLARE @file_type_id INT;
	DECLARE @iMasterTemplate_new_version int
	DECLARE @iMasterTemplate_max_version int;
	DECLARE @iMasterTemplate_max_version_status int;
	
	SET @Error_code=0;
	
	-- Check if a parallel process has not already initiated  a file edit and created a draft
	if(@isRestored_versioning = 0)
	BEGIN
	    if exists(select 1 from [dbo].[master_file_template_meta_info] where [master_file_template_id] = @iMasterTemplate_id and [approval_status_id] in (1,2))
	    BEGIN
		    set @Error_code=-2;
		  GOTO END_FOR_ERROR_EXISTS_PENDING_VERSION
	   END 
    END	
	
	BEGIN TRANSACTION; 

	--SELECT @iMasterTemplate_new_version=MAX([master_file_template_version])+1 from [dbo].[master_file_template_meta_info]
	--where [master_file_template_id]=@iMasterTemplate_id

	SELECT @iMasterTemplate_max_version_status = [approval_status_id], @iMasterTemplate_max_version = [master_file_template_version] from [dbo].[master_file_template_meta_info]
	where [master_file_template_id]=@iMasterTemplate_id  and  master_file_template_version in (select  max(master_file_template_version) from [dbo].[master_file_template_meta_info]
	where [master_file_template_id]=@iMasterTemplate_id )

	    IF(@isRestored_versioning = 1 AND @iMasterTemplate_max_version_status in (1,2))
	BEGIN
	   EXEC [dbo].[USP_Master_File_Template_Deletion] @iMasterTemplate_id = @iMasterTemplate_id,@iMasterTemplate_version = @iMasterTemplate_max_version
	   SET @iMasterTemplate_new_version = @iMasterTemplate_max_version
	END
	ELSE
	BEGIN
	 SET @iMasterTemplate_new_version = @iMasterTemplate_max_version + 1
	END

	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int)
	
	IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	CREATE TABLE #TEMP_DBRDT_OLDNEWKEY ( new_id int, old_id int ,rule_version int)

	BEGIN TRY 
	
		BEGIN
		/* Duplicating the master meta info row with same master id and new version */
		--SET IDENTITY_INSERT [dbo].[master_file_template_meta_info] ON;
		INSERT INTO [dbo].[master_file_template_meta_info]
           ([master_file_template_id],[master_file_template_name],[master_file_template_description],[file_type_id],[master_file_template_version]
           ,[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time],[approval_status_id])
           (SELECT [master_file_template_id],[master_file_template_name],[master_file_template_description],[file_type_id]
          ,@iMasterTemplate_new_version,0, @iCreated_by,getDate(),@iCreated_by,getDate(),1 FROM [dbo].[master_file_template_meta_info] where [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version]=@iMasterTemplate_old_version)
		--SET IDENTITY_INSERT [dbo].[master_file_template_meta_info] OFF
		END;
		

		--SELECT @file_type_id=[file_type_id] from [dbo].[master_file_template_meta_info] where [master_file_template_id]=@iMasterTemplate_id and [master_file_template_version]=@iMasterTemplate_old_version
		SELECT @file_type_id=[file_type_id],@NewMasterRecordId=master_file_template_record_id 
		from [dbo].[master_file_template_meta_info] where [master_file_template_id]=@iMasterTemplate_id and 
		[master_file_template_version]=@iMasterTemplate_new_version

			
			--- get record count for rules ----
DECLARE @RULES_COUNT INT
SET @RULES_COUNT = (select count(1) from master_file_template_attribute_association mftaa
join master_file_template_attr_br_assoc mftaba on mftaa.mftaa_id=mftaba.mftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mftaba.business_rule_id
where mftaa.[master_file_template_id] = @iMasterTemplate_id AND mftaa.[master_file_template_version] = @iMasterTemplate_old_version
)+
(select count(1) from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='M' and ltmi.associated_file_level_id=@iMasterTemplate_id AND ltmi.lookup_table_version = @iMasterTemplate_old_version
and ltmi.associated_file_type_id=@file_type_id
)+
(select count(1) from mtls_node_br_assoc mtlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
where mftmi.master_file_template_id=@iMasterTemplate_id AND mftmi.master_file_template_version = @iMasterTemplate_old_version and mtlsni.is_active=1
)



if @RULES_COUNT>0
BEGIN
--Duplicating the Business Rules Association rows with same id and new versions
--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2

INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version)
(select @NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version+1 from (
select drools_business_rule_id,drools_business_rule_version from master_file_template_attribute_association mftaa
join master_file_template_attr_br_assoc mftaba on mftaa.mftaa_id=mftaba.mftaa_id
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mftaba.business_rule_id
where mftaa.[master_file_template_id] = @iMasterTemplate_id AND mftaa.[master_file_template_version] = @iMasterTemplate_old_version
union
select drools_business_rule_id,drools_business_rule_version from lookup_table_composite_key_mapping ltckm
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=ltckm.business_rule_id
join lookup_table_meta_info ltmi on ltckm.lookup_table_id=ltmi.lookup_table_id and ltckm.lookup_table_version=ltmi.lookup_table_version
where ltmi.associated_file_level='M' and ltmi.associated_file_level_id=@iMasterTemplate_id AND ltmi.lookup_table_version = @iMasterTemplate_old_version
and ltmi.associated_file_type_id=@file_type_id
union
select drools_business_rule_id,drools_business_rule_version from mtls_node_br_assoc mtlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
where mftmi.master_file_template_id=@iMasterTemplate_id AND mftmi.master_file_template_version = @iMasterTemplate_old_version and mtlsni.is_active=1
) a)


SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [
](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@iCreated_by,getDate() from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY
on drools_business_rule_id=old_id)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF

END;
		
		/* inserting in audit table to maintain the version history with ids */
		INSERT INTO [dbo].[master_file_template_version_audit]
               ([master_template_id]
               ,[from_version]
               ,[to_version]
               ,[created_date]
               ,[created_by]
               ,[approval_status_id])
         VALUES
               (@iMasterTemplate_id
               ,@iMasterTemplate_old_version
               ,@iMasterTemplate_new_version
               ,GETDATE()
               ,'versioning'
               ,1)	
       SET @counter = 1;


    DECLARE cur CURSOR LOCAL FOR SELECT [mftsa_id],[template_section_id] FROM [dbo].[master_file_template_section_assoc] where [master_file_template_id]=@iMasterTemplate_id and master_file_template_version=@iMasterTemplate_old_version;
		OPEN cur;

		FETCH NEXT FROM cur INTO @mftsa_id,@template_section_id;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			INSERT INTO [dbo].[master_file_template_section_assoc]
           ([template_section_id]
           ,[master_file_template_id]
		   ,[master_file_template_record_id]
           ,[master_file_template_version]
           ,[template_compliant_section_short_name]
		   ,[section_display_name]
           --,[parent_mftsa_id]
           ,[sequence]
           ,[is_mandatory]
           --,[is_repeatable]
          -- ,[max_repeat_count]
           --,[section_delimiter]
		 ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
			OUTPUT INSERTED.[mftsa_id],@mftsa_id,@counter INTO @inserted([ID],[old_id],[counter])
           (SELECT [template_section_id]
		      ,[master_file_template_id]
			  ,@NewMasterRecordId
		      ,@iMasterTemplate_new_version
		      ,[template_compliant_section_short_name]
			  ,[section_display_name]
		     -- ,0
		      ,[sequence]
		      ,[is_mandatory]
		     -- ,[is_repeatable]
		     -- ,[max_repeat_count]
		     -- ,[section_delimiter]
		       ,@iCreated_by
		      ,getDate()
		      ,@iCreated_by
		      ,getDate()
		  FROM [dbo].[master_file_template_section_assoc] where mftsa_id=@mftsa_id)

		   SET  @counter = @counter + 1;
		        
      SELECT @NewTemplateSectionId=[mftsa_id]
			FROM dbo.master_file_template_section_assoc WHERE template_section_id=@template_section_id and master_file_template_id=@iMasterTemplate_id and master_file_template_version=@iMasterTemplate_new_version;		
							
							DECLARE attrcur CURSOR LOCAL FOR SELECT [mftsa_id],[mftaa_id],[attribute_id] FROM [dbo].[master_file_template_attribute_association] where [master_file_template_id]=@iMasterTemplate_id and master_file_template_version=@iMasterTemplate_old_version and mftsa_id=@mftsa_id;
							OPEN attrcur;

							FETCH NEXT FROM attrcur INTO @mftsa_id_FK,@mftaa_id,@attribute_id;
							WHILE @@FETCH_STATUS = 0
							BEGIN
							
								INSERT INTO [dbo].[master_file_template_attribute_association]
				           ([master_file_template_id]
				           ,[master_file_template_version]
				           ,[attribute_id]
				           ,[data_type]
				           ,[is_mandatory]
				           --,[attribute_size]
				           --,[attribute_start_position]
				           --,[attribute_end_position]
				           ,[attribute_row_position]
				           ,[application_compliant_attribute_name]
				           --,[is_hardcoded]
				           --,[default_value]
				           ,[mftsa_id]
				           --,[needs_lookup_table]
						   ,[ftaa_id]
						   ,[master_file_template_record_id]
						   ,[max_size_allowed]
				           ,[created_by]
				           ,[created_date_time]
						   ,[updated_by]
						   ,[updated_date_time])
	    					
				           (SELECT [master_file_template_id]
						      ,@iMasterTemplate_new_version
						      ,[attribute_id]
						      ,[data_type]
						      ,[is_mandatory]
						      --,[attribute_size]
						      --,[attribute_start_position]
						      --,[attribute_end_position]
						      ,[attribute_row_position]
						      ,[application_compliant_attribute_name]
						      --,[is_hardcoded]
						      --,[default_value]
						      ,@NewTemplateSectionId
						      --,[needs_lookup_table]
							  ,[ftaa_id]
							  ,@NewMasterRecordId
							  ,[max_size_allowed]
						      ,@iCreated_by
						      ,getDate()
							  ,@iCreated_by
						      ,getDate()
						  FROM [dbo].[master_file_template_attribute_association] where mftsa_id=@mftsa_id_FK and mftaa_id=@mftaa_id and attribute_id=@attribute_id)
						              
							SELECT @NewAttrId=[mftaa_id]
									FROM dbo.master_file_template_attribute_association WHERE mftsa_id=@NewTemplateSectionId and attribute_id=@attribute_id and master_file_template_id=@iMasterTemplate_id and master_file_template_version=@iMasterTemplate_new_version;

							insert into #TEMP_OLDNEWKEY(new_id,old_id) values(@NewAttrId,@mftaa_id)
							
							INSERT INTO [dbo].[mftaa_valid_value_assoc]([master_file_template_id],[master_file_template_version]
						           ,[mftaa_id],[valid_value_id],[is_active],[created_by],[created_date_time])
						           (SELECT @iMasterTemplate_id,@iMasterTemplate_new_version,@NewAttrId
						            ,[valid_value_id],1,@iCreated_by,getDate()
						            FROM [dbo].[mftaa_valid_value_assoc] where mftaa_id=@mftaa_id AND [master_file_template_id] = @iMasterTemplate_id AND master_file_template_version=@iMasterTemplate_old_version
									AND is_active=1)
								
									
									INSERT INTO [idis-metainfo].[dbo].[master_file_template_attr_br_assoc]([mftaa_id],[business_rule_id],[rule_execution_sequence]
									,[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									(SELECT @NewAttrId,C.new_id,D.rule_execution_sequence,1,@iCreated_by,GETDATE(),@iCreated_by,GETDATE()
									FROM [idis-metainfo].[dbo].[master_file_template_attr_br_assoc] D INNER JOIN #TEMP_DBRDT_OLDNEWKEY C 
									ON D.business_rule_id=C.old_id where D.mftaa_id = @mftaa_id and is_active=1)
									
														
									FETCH NEXT FROM attrcur INTO @mftsa_id_FK,@mftaa_id,@attribute_id;
						END
						CLOSE attrcur    
						DEALLOCATE attrcur

			
			FETCH NEXT FROM cur INTO @mftsa_id,@template_section_id;
		END
		CLOSE cur    
		DEALLOCATE cur
		SELECT * from @inserted;

		SET @counter = 1
		SELECT @total_row = COUNT(1) from @inserted
		WHILE(@counter <= @total_row )
			BEGIN
							
				SELECT @new_mftsa_id = ID, @old_mftsa_id = old_id from @inserted where [counter] = @counter
				SELECT @new_mftsa_id,@old_mftsa_id, @counter;
				/*
				UPDATE [dbo].[master_file_template_section_assoc] SET parent_mftsa_id = ISNULL( 
					(SELECT [ID] from @inserted WHERE [old_id] in (select  parent_mftsa_id from [dbo].[Master_file_template_section_assoc] 
					where mftsa_id = @old_mftsa_id)), 0) where [mftsa_id] = @new_mftsa_id and master_file_template_version = @iMasterTemplate_new_version;
				*/
				SET @counter = @counter+ 1;	
			END
			
				------------------------------------------------------------------------------------------------
				----------------------------------------- LOOKUP -----------------------------------------------
				------------------------------------------------------------------------------------------------
				
									DECLARE @NEW_LTMI_RESEED INT
									DECLARE @CURRENT_LTMI_RESEED INT
									DECLARE @NEW_LTMI_INDENT INT
									SET @CURRENT_LTMI_RESEED=(SELECT IDENT_CURRENT( 'lookup_table_meta_info' ) AS A)
									SET @NEW_LTMI_RESEED =@CURRENT_LTMI_RESEED+5
									DBCC CHECKIDENT ('lookup_table_meta_info', RESEED, @NEW_LTMI_RESEED)
									SET @NEW_LTMI_INDENT=@CURRENT_LTMI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END
									CREATE TABLE #TEMP_LT_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_LT_OLDNEWKEY (new_id,old_id) (select @NEW_LTMI_INDENT+Row_number() Over(Order by lookup_table_id),lookup_table_id
									from lookup_table_meta_info where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id 
									and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_old_version)

									--select * from #TEMP_LT_OLDNEWKEY

									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] ON 
									insert into lookup_table_meta_info(lookup_table_id,lookup_table_name,lookup_key_description,lookup_table_version,associated_file_level,associated_file_level_id,
									associated_file_type_id,created_by,created_date_time)
									(select new_id,lookup_table_name,lookup_key_description,@iMasterTemplate_new_version,associated_file_level,associated_file_level_id, associated_file_type_id,@iCreated_by,getDate()
									from lookup_table_meta_info join #TEMP_LT_OLDNEWKEY temp on lookup_table_id=old_id
									where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and lookup_table_version=@iMasterTemplate_old_version)
									SET IDENTITY_INSERT [dbo].[lookup_table_meta_info] OFF

									insert into lookup_table_details (lookup_table_id,lookup_table_version,lookup_key,lookup_value,created_by,created_date_time)
									(select temp.new_id,@iMasterTemplate_new_version ,lookup_key,lookup_value,@iCreated_by,getDate() from lookup_table_details ltd
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltd.lookup_table_id and ltmi.lookup_table_version=ltd.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY temp on ltmi.lookup_table_id=temp.old_id
									where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iMasterTemplate_old_version)

									insert into lookup_table_composite_key_mapping(lookup_table_id,lookup_table_version,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,business_rule_id,
									created_by,created_date_time,updated_by,updated_date_time)(select templt.new_id,@iMasterTemplate_new_version ,ltckm_type,ltckm_description,ltckm_order,datamart_element_id,
									case when business_rule_id is NULL then NULL when business_rule_id is NOT NULL then temp.new_id end,
									@iCreated_by,getDate(),@iCreated_by,getDate() from lookup_table_composite_key_mapping ltckm LEFT OUTER JOIN #TEMP_DBRDT_OLDNEWKEY temp on temp.old_id=business_rule_id
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltckm.lookup_table_id and ltmi.lookup_table_version=ltckm.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iMasterTemplate_old_version)

									insert into lookup_table_file_association (lookup_table_id,lookup_table_version,faa_id,mftaa_id,is_active,created_by,created_date_time,updated_by,updated_date_time)
									(select templt.new_id,@iMasterTemplate_new_version ,NULL,temp.new_id,1,@iCreated_by,getDate(),@iCreated_by,getDate()
									from lookup_table_file_association ltfa  join #TEMP_OLDNEWKEY temp on mftaa_id=temp.old_id
									join lookup_table_meta_info ltmi on ltmi.lookup_table_id=ltfa.lookup_table_id and ltmi.lookup_table_version=ltfa.lookup_table_version
									 join #TEMP_LT_OLDNEWKEY templt on ltmi.lookup_table_id=templt.old_id
									where associated_file_level='M' and associated_file_level_id=@iMasterTemplate_id and associated_file_type_id=@file_type_id and ltmi.lookup_table_version=@iMasterTemplate_old_version
									 and faa_id is NULL and is_active=1)

				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
									
				if exists(select 1 from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi on mftmi.master_file_template_record_id=mtlsni.master_file_template_record_id
				where [master_file_template_id] = @iMasterTemplate_id AND [master_file_template_version] = @iMasterTemplate_old_version)
				BEGIN

				DECLARE @MTLSNI_COUNT INT
				select @MTLSNI_COUNT= count(1) from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi on mftmi.master_file_template_record_id=mtlsni.master_file_template_record_id
				where [master_file_template_id] = @iMasterTemplate_id AND [master_file_template_version] = @iMasterTemplate_old_version and mtlsni.is_active=1
							

									DECLARE @NEW_MTLSNI_RESEED INT
									DECLARE @CURRENT_MTLSNI_RESEED INT
									DECLARE @NEW_MTLSNI_INDENT INT
									SET @CURRENT_MTLSNI_RESEED=(SELECT IDENT_CURRENT( 'master_template_layout_schema_node_info' ) AS A)
									SET @NEW_MTLSNI_RESEED =@CURRENT_MTLSNI_RESEED+@MTLSNI_COUNT+5
									DBCC CHECKIDENT ('master_template_layout_schema_node_info', RESEED, @NEW_MTLSNI_RESEED)
									SET @NEW_MTLSNI_INDENT=@CURRENT_MTLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_MTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_MTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_MTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_MTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_MTLSNI_INDENT+Row_number() Over(Order by mtlsni_id),mtlsni_id
									from master_template_layout_schema_node_info mtlsni join master_file_template_meta_info mftmi 
									on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id where 
									mftmi.master_file_template_id=@iMasterTemplate_id AND mftmi.master_file_template_version = @iMasterTemplate_old_version
									and mtlsni.is_active=1)
									
									SET IDENTITY_INSERT [dbo].[master_template_layout_schema_node_info] ON 
									INSERT INTO [dbo].[master_template_layout_schema_node_info]([mtlsni_id],[master_file_template_record_id],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[mapped_column_order])
									SELECT new_id,@NewMasterRecordId,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@iCreated_by,getDate()
									,@iCreated_by,getDate(),[node_max_size],[node_min_size],[mapped_column_order] FROM master_template_layout_schema_node_info mtlsni 
									join #TEMP_MTLSNI_OLDNEWKEY on mtlsni.mtlsni_id=old_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									where mftmi.master_file_template_id=@iMasterTemplate_id AND mftmi.master_file_template_version = @iMasterTemplate_old_version
									and mtlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[master_template_layout_schema_node_info] OFF
									
									INSERT INTO [dbo].[master_template_layout_schema_node_assoc]([mtlsni_id],[parent_mtlsni_id],[node_has_children],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,
									case when parent_mtlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@iCreated_by,getDate(),@iCreated_by,getDate() from [master_template_layout_schema_node_assoc] mtlsna
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsna.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									join #TEMP_MTLSNI_OLDNEWKEY a on mtlsna.mtlsni_id=a.old_id 
									left outer join #TEMP_MTLSNI_OLDNEWKEY b on mtlsna.parent_mtlsni_id=b.old_id
									where mftmi.master_file_template_id=@iMasterTemplate_id AND mftmi.master_file_template_version = @iMasterTemplate_old_version
									and mtlsni.is_active=1
									
									INSERT INTO [dbo].[mtls_node_dm_element_assoc]([mtlsni_id],[mftaa_id],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,1,@iCreated_by,getDate(),@iCreated_by,getDate() from mtls_node_dm_element_assoc mtlsnda 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnda.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id 
									join #TEMP_OLDNEWKEY b on mftaa_id=b.old_id
									join #TEMP_MTLSNI_OLDNEWKEY a on mtlsnda.mtlsni_id=a.old_id where mftmi.master_file_template_id=@iMasterTemplate_id
									AND mftmi.master_file_template_version = @iMasterTemplate_old_version and mtlsni.is_active=1 and mtlsnda.is_active=1      
									
									INSERT INTO [dbo].[mtls_node_br_assoc]([mtlsni_id],[business_rule_id],[rule_execution_sequence],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,1,@iCreated_by,getDate(),@iCreated_by,getDate() from mtls_node_br_assoc mtlsnba 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
									join master_file_template_meta_info mftmi on mtlsni.master_file_template_record_id=mftmi.master_file_template_record_id
									join #TEMP_DBRDT_OLDNEWKEY b on mtlsnba.business_rule_id=b.old_id
									join #TEMP_MTLSNI_OLDNEWKEY a on mtlsnba.mtlsni_id=a.old_id where mftmi.master_file_template_id=@iMasterTemplate_id 
									AND mftmi.master_file_template_version = @iMasterTemplate_old_version and mtlsni.is_active=1  and mtlsnba.is_active=1  
				
				END;

		COMMIT TRANSACTION;
		SET @oError_code = 0;
		SET @Error_code = 0;
	END TRY
	
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		SET @oError_code = -1;
		SET @Error_code = -1;
	END CATCH 

	
	IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END

	IF OBJECT_ID('tempdb..#TEMP_LT_NEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	
	IF OBJECT_ID('tempdb..#TEMP_MTLSNI_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_MTLSNI_OLDNEWKEY; END
	
	END_FOR_ERROR_EXISTS_PENDING_VERSION:
		IF ( @Error_code = -2)
			BEGIN
			print 'Error: A draft has already been created for the Master File Template. A new draft cannot be created'
			SET @oError_code=@Error_code
			RETURN -2
		END
		ELSE IF ( @Error_code <> 0)
			BEGIN
			print 'Error: Some Error occured while creating a version'
			SET @oError_code=@Error_code
			RETURN -1
		END
		ELSE
			BEGIN
			print 'Master File Template Version created Successfully... '
			SET @oError_code=0
			RETURN 0
		END 
			
			
END

GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 

GRANT EXECUTE ON dbo.Proc_Master_template_Versioning TO exec_proc

GO
