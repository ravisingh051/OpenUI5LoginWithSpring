use [idis-metainfo]
GO

/*
Update Log

Date        	Author          	Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-08-20   Jinesh vora		ADAPT-7063 System should send notification for the system event "Job Successful"

-- Table 
-- processing_system_events
*/

IF not exists (select 1 from [processing_system_events] where [event_id] = 15)
BEGIN

SET IDENTITY_INSERT [dbo].[processing_system_events] ON 
INSERT into processing_system_events ([event_id], [event_name], [event_description], [file_direction], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES  (15,'Job Successful','Job Successful','B','Jinesh vora',getdate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[processing_system_events] OFF 

END;
GO
