/****** Object:  Table [dbo].[file_ext_param_br_assoc]    Script Date: 07/15/2019 ******/
USE [idis-metainfo]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_ext_param_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_ext_param_br_assoc](
	[fepba_id] [int] IDENTITY(1,1) NOT NULL,
	[fepba_fepi_id] [int] NOT NULL,
	[fepba_ep_id] [int] NOT NULL,
	[fepba_br_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
 CONSTRAINT [PK_fepba_id] PRIMARY KEY CLUSTERED 
(
	[fepba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepba_K2_fepi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[file_ext_param_br_assoc]
		WITH CHECK ADD CONSTRAINT [FK_fepba_K2_fepi_K1] FOREIGN KEY ([fepba_fepi_id]) REFERENCES [dbo].[file_extraction_parameters_info]([fepi_id])

	ALTER TABLE [dbo].[file_ext_param_br_assoc] CHECK CONSTRAINT [FK_fepba_K2_fepi_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepba_K3_ep_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[file_ext_param_br_assoc]
		WITH CHECK ADD CONSTRAINT [FK_fepba_K3_ep_K1] FOREIGN KEY ([fepba_ep_id]) REFERENCES [dbo].[extraction_parameters]([ep_id])

	ALTER TABLE [dbo].[file_ext_param_br_assoc] CHECK CONSTRAINT [FK_fepba_K3_ep_K1]
END;
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_fepba_K4_dbr_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[file_ext_param_br_assoc]
		WITH CHECK ADD CONSTRAINT [FK_fepba_K4_dbr_K1] FOREIGN KEY ([fepba_br_id]) REFERENCES [dbo].[drools_business_rules_decision_table]([drools_business_rule_id])

	ALTER TABLE [dbo].[file_ext_param_br_assoc] CHECK CONSTRAINT [FK_fepba_K4_dbr_K1]
END;
GO

