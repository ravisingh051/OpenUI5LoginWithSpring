USE [idis-metainfo]
GO
/*
Filename:  V16.8445_Implement_changes_to_REST_and_DB_layers_for_Header_and_Trailer_functionality_for_Outbound.sql

Update Log
Date         Author            	Description
----------   ----------------   -----------------------------------------------------------------------------------------------
2019-11-15   Pravin Rajput		ADAPT-8445 : Implement changes to REST and DB layers for Header and Trailer functionality for Outbound
*/

/*
DB Entry for Header -- header
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 2035 and attribute_name = 'Header Custom Defined')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2035,'Header Custom Defined','PRE-DEFINED :: Header Custom Defined','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4779 and file_type_id = 17 and attribute_id = 2035)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4779,17,2035,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'headerCustomDefined',NULL)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2243 and master_file_template_record_id = 18 and attribute_id = 2035)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2243,18,1,2035,'VARCHAR',0,NULL,NULL,77,'Pravin Rajput',getDate(),18,50,4779,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO

/*
DB Entry for Trailer -- trailer
*/

if not exists (select 1 from attribute_dictionary where attribute_id = 2036 and attribute_name = 'Trailer Custom Defined')
BEGIN
SET IDENTITY_INSERT [dbo].[attribute_dictionary] ON 
INSERT INTO [dbo].[attribute_dictionary]
			([attribute_id]
		   ,[attribute_name]
           ,[attribute_description]
           ,[default_data_type]
           ,[default_value]
           ,[is_overridable]
		   ,[attribute_size]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time])
  		    VALUES
           (2036,'Trailer Custom Defined','PRE-DEFINED :: Trailer Custom Defined','VARCHAR',NULL,1,100,'Pravin Rajput',getDate(),NULL,NULL)
SET IDENTITY_INSERT [dbo].[attribute_dictionary] OFF 
END
GO

if not exists (select 1 from file_type_attribute_association where ftaa_id = 4780 and file_type_id = 17 and attribute_id = 2036)
BEGIN
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] ON 
INSERT INTO [dbo].[file_type_attribute_association]
           ([ftaa_id]
		   ,[file_type_id]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[default_value]
           ,[created_by]
           ,[created_date_time]
           ,[updated_by]
           ,[updated_date_time]
           ,[standardized_name]
           ,[attribute_logical_group_id])
  		    VALUES
           (4780,17,2036,'VARCHAR',0,NULL,'Pravin Rajput',getDate(),NULL,NULL,'trailerCustomDefined',NULL)
SET IDENTITY_INSERT [dbo].[file_type_attribute_association] OFF 
END
GO

if not exists (select 1 from master_file_template_attribute_association where mftaa_id = 2244 and master_file_template_record_id = 18 and attribute_id = 2036)
BEGIN
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] ON 
INSERT INTO [dbo].[master_file_template_attribute_association]
           ([mftaa_id]
		   ,[master_file_template_id]
           ,[master_file_template_version]
           ,[attribute_id]
           ,[data_type]
           ,[is_mandatory]
           ,[attribute_row_position]
           ,[application_compliant_attribute_name]
           ,[mftsa_id]
           ,[created_by]
           ,[created_date_time]
           ,[master_file_template_record_id]
           ,[max_size_allowed]
           ,[ftaa_id]
           ,[updated_by]
           ,[updated_date_time])
     VALUES (2244,18,1,2036,'VARCHAR',0,NULL,NULL,91,'Pravin Rajput',getDate(),18,50,4780,NULL,NULL)
SET IDENTITY_INSERT [dbo].[master_file_template_attribute_association] OFF 
END
GO