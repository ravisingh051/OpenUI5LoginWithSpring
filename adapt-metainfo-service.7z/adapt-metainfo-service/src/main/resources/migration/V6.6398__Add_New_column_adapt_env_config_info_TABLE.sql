/*
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-06-14	Jinesh vora		ADAPT-6398: Addition of new coulum in adapt_env_config_info Table & default data popultion for the same column 
*/
-- check if the column is already exists in table:
use [idis-metainfo]

IF NOT EXISTS (
		SELECT 1
		FROM information_schema.columns where table_name='adapt_env_config_info' and column_name='allowed_migration_env_ids' and is_nullable='YES')
BEGIN
ALTER TABLE [dbo].[adapt_env_config_info] ADD allowed_migration_env_ids varchar(50) DEFAULT NULL;
END;
GO

-- Default Data Population 
IF EXISTS (SELECT 1 FROM [dbo].[adapt_env_config_info] where adapt_env_id in (1,2,3) and allowed_migration_env_ids is null)
BEGIN
Update [dbo].[adapt_env_config_info] SET allowed_migration_env_ids = '5,6' where adapt_env_id = 1 and adapt_env_name ='QA';
Update [dbo].[adapt_env_config_info] SET allowed_migration_env_ids = '7' where adapt_env_id = 2 and adapt_env_name ='QC';
Update [dbo].[adapt_env_config_info] SET allowed_migration_env_ids = '4,2,7' where adapt_env_id = 3 and adapt_env_name ='Setup';
END;

GO
