use [idis-metainfo]
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		Disha Shah
-- Create date:  02/19/2019 11:00:00 PM 
-- Description:	This Store Procedure Creates an entry in file_id_generator with given file id
-- =============================================

IF OBJECT_ID('dbo.USP_Generate_Custom_File_Id') IS NULL
	EXEC ('CREATE PROCEDURE dbo.USP_Generate_Custom_File_Id AS SELECT 1');
GO
ALTER PROCEDURE [dbo].[USP_Generate_Custom_File_Id]
	-- Add the parameters for the stored procedure here
	@ifile_identifier INT = NULL,
	@icreated_by VARCHAR(50),
	@ofileId INT OUT
				
AS
BEGIN

-- If no file_id is provided, auto-generate one and return that
IF(@ifile_identifier IS NULL)
BEGIN
	INSERT INTO FILE_ID_GENERATOR(created_by, created_date_time) VALUES (@icreated_by, GETDATE());
	SET @ofileId = SCOPE_IDENTITY();
END

-- If given file_id already exists in db, return the same
ELSE IF EXISTS(SELECT 1 FROM FILE_ID_GENERATOR WHERE file_id = @ifile_identifier)
BEGIN
	SET @ofileId = @ifile_identifier;
END

-- If given file_id does not already exist, insert it.
ELSE
BEGIN
	SET IDENTITY_INSERT FILE_ID_GENERATOR ON;
	INSERT INTO FILE_ID_GENERATOR(file_id, created_by, created_date_time) VALUES (@ifile_identifier, @icreated_by, GETDATE());
	SET IDENTITY_INSERT FILE_ID_GENERATOR OFF;
	SET @ofileId = @ifile_identifier;
END    
   
END;
GO
-- ============================================================================ 
 --Set permissions 
-- ============================================================================ 
GRANT EXECUTE
	ON dbo.USP_Generate_Custom_File_Id
	TO exec_proc;
GO


