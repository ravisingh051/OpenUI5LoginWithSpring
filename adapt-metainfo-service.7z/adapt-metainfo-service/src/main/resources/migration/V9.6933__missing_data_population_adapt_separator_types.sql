use [idis-metainfo]

---- data Population for adapt_separtor_types  -----------
if not exists(select 1 from [dbo].[adapt_separtor_types])
begin
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] ON 
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (1, N'*', 1, CAST(N'2019-05-10 14:17:44.603' AS DateTime), N'Divya Jain', NULL, NULL)
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (2, N'~', 1, CAST(N'2019-05-10 14:17:44.607' AS DateTime), N'Divya Jain', NULL, NULL)
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (3, N'>', 1, CAST(N'2019-05-10 14:17:44.607' AS DateTime), N'Divya Jain', NULL, NULL)
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (4, N'<', 1, CAST(N'2019-05-10 14:17:44.607' AS DateTime), N'Divya Jain', NULL, NULL)
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (5, N':', 1, CAST(N'2019-05-10 14:17:44.607' AS DateTime), N'Divya Jain', NULL, NULL)
INSERT INTO [dbo].[adapt_separtor_types] ([adapt_sep_type_id], [adapt_sep_type_name], [adapt_sep_type_is_active], [created_date_time], [created_by], [updated_by], [updated_date_time]) VALUES (6, N'^', 1, CAST(N'2019-05-10 14:17:44.607' AS DateTime), N'Divya Jain', NULL, NULL)
SET IDENTITY_INSERT [dbo].[adapt_separtor_types] OFF
end;
go

