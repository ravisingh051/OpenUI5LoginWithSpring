USE [idis-metainfo]
GO

--Update Log
--Date			Author          Description
----------		------------    -------------------------------------------------------------------------------------------
--2019-07-11	Jinesh Vora		ADAPT-2835: Stepping Through a Row of Data
--2019-09-30	Divya Jain		ADAPT-7708: API - Remove the PMT APIs


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Get_PMT_LUT_Value') IS NOT NULL
	EXEC ('DROP PROCEDURE dbo.USP_Get_PMT_LUT_Value');
GO

/*
IF OBJECT_ID('dbo.USP_Get_PMT_LUT_Value') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_PMT_LUT_Value AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Get_PMT_LUT_Value]
	(
               @i_record_identifier int
       )
AS
BEGIN

SET NOCOUNT ON;

select
	LTMI.lookup_table_id,
	LTMI.lookup_table_version,
	LTD.lookup_key,
	LTD.lookup_value,
	LTMI.lookup_table_name 
from lookup_table_meta_info LTMI
INNER JOIN lookup_table_details LTD 
	ON LTMI.lookup_table_id=LTD.lookup_table_id 
	AND LTMI.lookup_table_version=LTD.lookup_table_version
INNER JOIN child_file_template_meta_info cftmi 
	ON LTMI.associated_file_level_id=cftmi.child_file_template_id 
	AND LTMI.lookup_table_version=cftmi.child_file_template_version 
INNER JOIN master_file_template_meta_info mftmi 
	ON mftmi.master_file_template_record_id = cftmi.master_file_template_record_id
	AND LTMI.associated_file_type_id=mftmi.file_type_id

where LTMI.associated_file_level_id=cftmi.child_file_template_id  
and LTMI.associated_file_level = 'C'
AND cftmi.child_file_template_record_id =@i_record_identifier ;

END 
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.[USP_Get_PMT_LUT_Value] TO exec_proc
GO
*/