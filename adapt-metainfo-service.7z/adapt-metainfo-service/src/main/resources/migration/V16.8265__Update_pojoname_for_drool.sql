use [idis-metainfo]
GO


/*

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-11-09   Nishit Charania	 ADAPT-8265 : Rules generation changes for View Removal
*/

-------- Update TransactionDatasetView to TransactionDataset --------
if exists (select 1 from [drools_business_rule_pkg] where [drools_business_rule_pkg_id] = 17 and [drools_br_pojo_name] = 'TransactionDatasetView')
BEGIN
	UPDATE [drools_business_rule_pkg]
	set 
		[drools_br_pkg_name] = 'com.alight.adapt.dataextraction.transaction.v1.models',
		[drools_br_pojo_name] = 'TransactionDataset'  
	WHERE [drools_business_rule_pkg_id] = 17 and [drools_br_pojo_name] = 'TransactionDatasetView';
END
GO