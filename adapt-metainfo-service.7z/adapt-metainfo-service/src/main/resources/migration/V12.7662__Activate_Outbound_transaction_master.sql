use [idis-metainfo]

/*
Filename:  V12.7662__Activate_Outbound_transaction_master.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-18   Divya Jain  		ADAPT-7662 : Outbound Transaction Template NOT Appearing In Master List 
*/


if exists(select 1 from master_file_template_meta_info where master_file_template_record_id=18 and is_active=0)
begin
	update master_file_template_meta_info set is_active=1 where master_file_template_record_id=18
end;
go

