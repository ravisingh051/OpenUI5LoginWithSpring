USE [idis-metainfo]

/*
--Update Log
--Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
--2019-07-09	Jinesh Vora		ADAPT-6737: Move the Termination Indicator to Advanced Selection Criteria

-- Table Used 
-- extraction_parameters
-- extraction_parameters_types

*/

-- Insert Record in extraction_parameters_types For Advanced Selection Criteria
IF NOT EXISTS (
  SELECT 1 from extraction_parameters_types where ept_id = 4
)
BEGIN
SET IDENTITY_INSERT [dbo].[extraction_parameters_types] ON 
INSERT INTO [dbo].[extraction_parameters_types] ([ept_id], [ept_name], [is_active], [created_by], [created_date_time], [updated_by], [updated_date_time])
VALUES (4, N'Advanced Selection Criteria', 1, N'Jinesh Vora', CAST(N'2019-07-09T18:57:10.807' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[extraction_parameters_types] OFF
END

-- Update extraction_parameters Table For Parameter Value Coverage Termination Indicator
IF EXISTS (
  SELECT 1 from extraction_parameters where ep_name = 'Coverage Termination Indicator' and ep_ept_id = 2
)
BEGIN
Update extraction_parameters 
SET ep_ept_id = 4 where ep_name = 'Coverage Termination Indicator'
END
GO

