use [idis-metainfo]
GO

/*
Update Log

Date        	Author          	Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-16   Jinesh vora			ADAPT-6651 : System should generate DRLs for all extraction criteria
2019-07-16   Jinesh vora			ADAPT-6869 : System should generate DRLs for all extraction criteria - Create a separate table for mapping extraction parameters to attributes
2019-08-12	 Jinesh vora			ADAPT-6869 : System should generate DRLs for all extraction criteria - Add file_ext_param_br_assoc table with constraint 

-- Table 
-- drools_business_rule_group_name
-- file_ext_param_br_assoc
*/

IF EXISTS (SELECT 1 FROM drools_business_rule_group where drools_business_rule_group_name = 'SelectionCriteria' and drools_business_rule_group_id = 7)
BEGIN
Update drools_business_rule_group SET drools_business_rule_group_name = 'AdditionalSelectionCriteria',updated_by='Jinesh Vora',updated_date=getdate() where drools_business_rule_group_name = 'SelectionCriteria' and drools_business_rule_group_id = 7;
END


if not exists (select 1 from drools_business_rule_group where drools_business_rule_group_id = 11)
BEGIN
SET IDENTITY_INSERT [dbo].[drools_business_rule_group] ON 

INSERT INTO [dbo].drools_business_rule_group (drools_business_rule_group_id,drools_business_rule_group_name,parent_group_id,created_by,created_date,updated_by,updated_date,drools_business_rule_group_priority) VALUES 
(11,'AdvancedSelectionCriteria',NULL,'Jinesh Vora',getdate(),NULL,NULL,1);

SET IDENTITY_INSERT [dbo].[drools_business_rule_group] OFF 
END
GO

-- ADAPT - 6869 : Create a separate table for mapping extraction parameters to attributes
USE [idis-metainfo]
GO

USE [idis-metainfo]
GO

/*
Update Log

Date        	Author          	Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-16   Jinesh vora			ADAPT-6651 : System should generate DRLs for all extraction criteria - Create a new table for storing extraction param rule assoc
*/


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[extraction_parameters_attr_assoc]') AND type in (N'U'))
BEGIN

CREATE TABLE  [dbo].[extraction_parameters_attr_assoc]
(
[epaa_id] [int] IDENTITY(1,1) not null,-- PK,
[epaa_ep_id] [int] not null, --(FK to ep_id from extraction_parameters),
[epaa_attribute_id] [int] not null,-- (FK to ep_id from attribute_dictionary),
[created_by] [varchar](50) not null,
[created_date_time] datetime not null,
[updated_by] [varchar](50) null,
[updated_date_time] datetime null,

CONSTRAINT [PK_epaa_id] PRIMARY KEY CLUSTERED 
(
	[epaa_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

END
GO
SET ANSI_PADDING OFF
GO

-- 1 FK with table extraction_parameters
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_epaa_K2_ep_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.extraction_parameters_attr_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[extraction_parameters_attr_assoc]
		WITH CHECK ADD CONSTRAINT [FK_epaa_K2_ep_K1] FOREIGN KEY ([epaa_ep_id]) REFERENCES [dbo].[extraction_parameters]([ep_id])

	ALTER TABLE [dbo].[extraction_parameters_attr_assoc] CHECK CONSTRAINT [FK_epaa_K2_ep_K1]
END;
GO

-- 2 FK with TABLE : attribute_dictionary
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_epaa_K3_ad_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.extraction_parameters_attr_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[extraction_parameters_attr_assoc]
		WITH CHECK ADD CONSTRAINT [FK_epaa_K3_ad_K1] FOREIGN KEY ([epaa_attribute_id]) REFERENCES [dbo].[attribute_dictionary]([attribute_id])

	ALTER TABLE [dbo].[extraction_parameters_attr_assoc] CHECK CONSTRAINT [FK_epaa_K3_ad_K1]
END;
GO


-- Migration Script 
if not exists (select 1 from extraction_parameters_attr_assoc where epaa_id between 1 AND 44)
BEGIN

SET IDENTITY_INSERT [dbo].[extraction_parameters_attr_assoc] ON 

INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (1, 1, 180, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.637' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (2, 2, 185, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.637' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (3, 3, 184, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.640' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (4, 4, 200, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.640' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (5, 5, 97, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (6, 6, 98, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (7, 7, 178, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (8, 8, 99, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (9, 9, 49, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (10, 10, 10, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.643' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (11, 12, 14, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (12, 13, 181, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (13, 14, 253, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (14, 15, 25, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (15, 16, 220, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (16, 17, 1, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (17, 18, 219, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (18, 19, 8, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (19, 20, 100, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.647' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (20, 21, 101, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (21, 22, 102, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (22, 23, 103, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (23, 24, 104, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (24, 25, 13, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (25, 26, 201, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (26, 27, 50, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (27, 28, 11, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (28, 29, 5, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (29, 30, 120, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (30, 31, 7, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (31, 32, 72, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.650' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (32, 33, 105, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (33, 34, 51, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (34, 35, 106, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (35, 36, 95, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (36, 37, 96, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (37, 38, 40, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (38, 39, 116, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (39, 40, 71, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (40, 41, 94, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (41, 42, 181, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (42, 42, 189, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (43, 42, 348, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
INSERT [dbo].[extraction_parameters_attr_assoc] ([epaa_id], [epaa_ep_id], [epaa_attribute_id], [created_by], [created_date_time], [updated_by], [updated_date_time]) VALUES (44, 42, 351, N'Jinesh vora', CAST(N'2019-07-17T14:59:53.653' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[extraction_parameters_attr_assoc] OFF

END
GO

-- Remove CONSTRAINT 
IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_ep_K2_ad_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.extraction_parameters')
		)
BEGIN
	ALTER TABLE extraction_parameters DROP CONSTRAINT FK_ep_K2_ad_K1;
END;
GO

-- Remove Column Named ep_attribute_id
IF EXISTS (select 1 from INFORMATION_SCHEMA.columns where table_name = 'extraction_parameters' and column_name = 'ep_attribute_id')
begin
	ALTER TABLE extraction_parameters DROP COLUMN ep_attribute_id;    
end
GO


-- Table : file_ext_param_br_assoc 
USE [idis-metainfo] 
GO

/****** Object:  Table [dbo].[file_ext_param_br_assoc]    Script Date: 8/8/2019 1:33:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[file_ext_param_br_assoc]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[file_ext_param_br_assoc](
	[fepba_id] [int] IDENTITY(1,1) NOT NULL,
	[fepba_fepi_id] [int] NOT NULL,
	[fepba_ep_id] [int] NOT NULL,
	[fepba_br_id] [int] NOT NULL,
	[is_active] [bit] NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[profile_id] [int] NULL,
 CONSTRAINT [PK_fepba_id] PRIMARY KEY CLUSTERED 
(
	[fepba_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

-- 1
-- Add FK with file_ext_param_br_assoc Table
IF NOT EXISTS (
                                SELECT 1
                                FROM sys.foreign_keys c
                                WHERE name = 'FK_fepba_K2_fepi_K1'
                                                AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
                                )
BEGIN
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fepba_K2_fepi_K1] FOREIGN KEY([fepba_fepi_id]) REFERENCES [dbo].[file_extraction_parameters_info] ([fepi_id])
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  CHECK CONSTRAINT [FK_fepba_K2_fepi_K1] 
END;
GO

-- 2 Add FK with file_ext_param_br_assoc Table
IF NOT EXISTS (
                                SELECT 1
                                FROM sys.foreign_keys c
                                WHERE name = 'FK_fepba_K3_ep_K1'
                                                AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
                                )
BEGIN
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fepba_K3_ep_K1] FOREIGN KEY([fepba_ep_id]) REFERENCES [dbo].[extraction_parameters] ([ep_id])
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  CHECK CONSTRAINT [FK_fepba_K3_ep_K1] 
END;
GO

-- 3  Add FK with file_ext_param_br_assoc Table
IF NOT EXISTS (
                                SELECT 1
                                FROM sys.foreign_keys c
                                WHERE name = 'FK_fepba_K4_dbr_K1'
                                                AND c.parent_object_id = OBJECT_ID('dbo.file_ext_param_br_assoc')
                                )
BEGIN
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  WITH CHECK ADD  CONSTRAINT [FK_fepba_K4_dbr_K1] FOREIGN KEY([fepba_br_id]) REFERENCES [dbo].[drools_business_rules_decision_table] ([drools_business_rule_id])
				ALTER TABLE [dbo].[file_ext_param_br_assoc]  CHECK CONSTRAINT [FK_fepba_K4_dbr_K1] 
END;
GO

