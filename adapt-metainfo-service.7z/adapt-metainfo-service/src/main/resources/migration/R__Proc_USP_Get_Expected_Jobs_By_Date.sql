USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Get_Expected_Jobs_By_Date]    Script Date: 2/23/2018 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Get_Expected_Jobs_By_Date') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Expected_Jobs_By_Date AS SELECT 1')
GO



/*
11-06-2018	Divya Jain	CC-34665: Updated to get masterFileTemplateId,masterFileTemplateVersion
21-06-2018	Divya Jain	CC-35092: Updated to get fullChangeIndicator
21-06-2018	Divya Jain	CC-35095: Updated to get fileProcessingMode
2018-07-20	Divya Jain	CC-33757: User should be able to select multiple employers & set the TestCfg value in the File Template
2018-08-07	Divya Jain	CC-32796: User should be able to specify the error threshold for a file
2019-02-36	Divya Jain		ADAPT-1779: User should be able to select Testcfg while configuring the file
*/

IF OBJECT_ID('dbo.USP_Get_Expected_Jobs_By_Date') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Get_Expected_Jobs_By_Date AS SELECT 1')
GO

ALTER Procedure [dbo].[USP_Get_Expected_Jobs_By_Date]
	(
		@i_date date
	) 
AS
BEGIN

SET NOCOUNT ON; 
declare @inputDate date;
set @inputDate=@i_date;

select job_id as jobId,
job_expected_start_datetime as jobExpectedStartDateTime,
fmi.file_processing_error_threshold_count as fileProcessingErrorThresholdCount,
fmi.file_min_record_count_allowed as fileMinRecordCountAllowed,
case when job_transmission_connection_id is null then cast(fmi.file_id as varchar(100))+'.txt' else fti.transmission_name end as fileTransmissionName,
--fti.transmission_name as fileTransmissionName,
ftmi.system_name as fileTypeName, 
	case 
	when fms.file_format_name in ('delimited','DELIMITED') then 'FILE_DELIMITED'
	when fms.file_format_name in ('fixed width','FIXED_WIDTH','FIXED WIDTH','fixed_width') then 'FILE_FIXED_WIDTH'
	when fms.file_format_name in ('xml','XML') then 'FILE_XML'
	else fms.file_format_name end as fileFormatName,
fms.file_format_row_delimiter as fileFormatRowDelimiter, 
fms.file_format_field_delimiter as fileFormatFieldDdelimiter, 
fms.file_format_escape_char as fileFormatEscapeChar, 
fms.file_format_segment_delimiter as fileFormatSegmentDelimiter,
jd.file_processing_priority as priority,
STUFF((SELECT distinct ',' + (CAST(cea.employer_id AS VARCHAR)+'::'+CAST(cea.client_id AS VARCHAR)) as er 
	from client_employer_assoc cea 
	join file_employer_assoc fea on cea.client_employer_assoc_id=fea.client_employer_assoc_id
	where fea.file_identifier=fmi.record_id
	FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'') as employerIds,
fmi.master_file_template_id as masterFileTemplateId,
fmi.master_file_template_version as masterFileTemplateVersion,
case when jd.file_data_extraction_mode='Full' then 1 else 0 end as fullOrChange,
case when fpm.file_processing_mode_id=8 then 1 else 0 end as resultsMode ,
jd.test_cfg as testCfgConfig,
fmi.file_max_record_count_allowed as fileMaxRecordCountAllowed,
case when fmi.file_processing_error_threshold_format ='Percentage Of Records' then 'PERCENTAGE'
when fmi.file_processing_error_threshold_format ='Number of Records' then 'COUNT'
else 'NONE' end as fileProcessingErrorThresholdFormat,
jd.file_identifier as fileIdentifier,
fmi.file_id as fileId,
fmi.file_version as fileVersion,
isNull(stuff((
	SELECT ','+ CAST(clone_num AS VARCHAR) FROM file_clone_info WHERE file_identifier = fmi.record_id FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,1,'')
	, '')	as cloneNumberList 
from job_details jd
join file_meta_info fmi on fmi.record_id=jd.file_identifier
join file_type_meta_info ftmi on ftmi.file_type_id=fmi.file_type_id
join file_format_supported fms on fms.file_format_supported_id=fmi.file_format_supported_id
join file_processing_schedule fps on jd.file_processing_schedule_id=fps.file_processing_schedule_id
join file_processing_recurrence fpr on fpr.file_processing_recurrence_id=fps.file_processing_recurrence_id
join file_processing_mode fpm on fpm.file_processing_mode_id=fpr.file_processing_mode_id
left join file_transmission_info fti on jd.job_transmission_connection_id=fti.file_transmission_connection_id
where job_status='SCHEDULED' and  job_expected_start_datetime=@inputDate

END

Go

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Get_Expected_Jobs_By_Date TO exec_proc
GO


