use [idis-metainfo]
GO

SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_event_log]') AND name = N'IX_job_event_log_K5_K11')
BEGIN
CREATE NONCLUSTERED INDEX [IX_job_event_log_K5_K11] ON [dbo].job_event_log
(
	[jel_job_id] ASC,[jel_event_type]
)INCLUDE([jel_intn_ref_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[job_event_log]') AND name = N'IX_job_event_log_K5_K12')
BEGIN
CREATE NONCLUSTERED INDEX [IX_job_event_log_K5_K12] ON [dbo].job_event_log
(
	[jel_job_id] ASC,[jel_intn_ref_id] ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END;
GO

