USE [idis-metainfo]
GO



/****** Object:  StoredProcedure [dbo].[USP_Inherit_Master_To_File]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Divya Jain
-- Create date: 24-Sep-2019
-- Description:	Stored Procedure to inherit a File directly from master
-- =============================================
/*
Update Log
Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-09-24  Divya Jain		ADAPT-7707: As an authorized user, I should be able to create File from Master Template and able to copy the file which is marked as Template so that I can reuse the configuration of a file as we don’t need PMTs anymore.
2019-10-10	Snehal Patel	ADAPT-7993 : Newly created inbound file- delimited- All the values under mapped column are inherited and displayed.
2019-10-14	Divya Jain		ADAPT-7995: System display confirmation pop up even though no rule aligned to that attribute 
2019-10-14	Divya Jain		ADAPT-7992: Max length column does not display on attribute detail section
2019-10-14	Snehal Patel	ADAPT-7998: Remove enumerated values and print display name.
*/
IF OBJECT_ID('dbo.USP_Inherit_Master_To_File') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Inherit_Master_To_File AS SELECT 1')
GO

ALTER PROCEDURE [dbo].[USP_Inherit_Master_To_File]
	-- Add the parameters for the stored procedure here
	@MASTER_FILE_TEMPLATE_RECORD_ID INT,
	@FILE_TEMPLATE_ID INT,
	@CREATED_BY VARCHAR(50)
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	
	DECLARE @file_type_id INT;
	DECLARE @record_id INT;
	

	select @record_id=@FILE_TEMPLATE_ID;
	

	SELECT @file_type_id=[file_type_id] from [dbo].[master_file_template_meta_info] mftmi
		where [master_file_template_record_id]=@MASTER_FILE_TEMPLATE_RECORD_ID

    ----count of ----
	DECLARE @NEW_RECORDS_COUNT INT
	SET @NEW_RECORDS_COUNT = (SELECT count(1) FROM [master_file_template_section_assoc] where [master_file_template_record_id]=@MASTER_FILE_TEMPLATE_RECORD_ID)

	----retriving current identity number-----
	DECLARE @CURRENT_ID INT
	SET @CURRENT_ID = 0
	SET @CURRENT_ID = (SELECT IDENT_CURRENT( 'file_section_association' ) AS A)

	----update the identity number for new records, have a buffer of 5 records to avoid error-----
	DECLARE @NEW_RESEED INT
	SET @NEW_RESEED = @CURRENT_ID+@NEW_RECORDS_COUNT+5
	DBCC CHECKIDENT ('file_section_association', RESEED, @NEW_RESEED)


	DECLARE @NEW_IDENT INT
	SET @NEW_IDENT = @CURRENT_ID + 2;
	
	---------------------------------------------------
	IF OBJECT_ID('tempdb..#TEMP_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_OLDNEWKEY; END
	CREATE TABLE #TEMP_OLDNEWKEY ( new_id int, old_id int )

	INSERT INTO #TEMP_OLDNEWKEY
	SELECT  @NEW_IDENT+Row_number() Over(Order by B.mftsa_id) ,B.mftsa_id	
	FROM
		[master_file_template_section_assoc] B
		WHERE B.[master_file_template_record_id]=@MASTER_FILE_TEMPLATE_RECORD_ID

	---------------------------------------------------

	SET IDENTITY_INSERT [dbo].[file_section_association] ON

	INSERT INTO [dbo].[file_section_association] 
		( [fsa_id]
		  ,[template_section_id]
		  ,[file_identifier]
		  ,[file_compliant_section_short_name]
		  --,[parent_fsa_id]
		  ,[section_display_name]
		  ,[sequence]
		  ,[is_mandatory]
		  --,[is_repeatable]
		  --,[max_repeat_count]
		  --,[section_delimiter]
		  ,[created_by]
		  ,[created_date_time]
		  ,[updated_by]
		  ,[updated_date_time] )
	( SELECT 
		@NEW_IDENT+Row_number() Over(Order by B.mftsa_id) AS [fsa_id]
		,B.[template_section_id]
		,@record_id AS [file_identifier]
		,B.[template_compliant_section_short_name] AS [file_compliant_section_short_name]
		--,NULL
		,B.[section_display_name]
		,B.[sequence]
		,0
		--,0
		--,0
		--,NULL
		,@CREATED_BY
		,B.[created_date_time]
		,B.[updated_by]
		,B.[updated_date_time]
	FROM
	[master_file_template_section_assoc] B
	WHERE B.[master_file_template_record_id]=@MASTER_FILE_TEMPLATE_RECORD_ID)
	
	SET IDENTITY_INSERT [dbo].[file_section_association] OFF


	-----------------------------------------------------------
	IF OBJECT_ID('tempdb..#TEMP_FTAA') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_FTAA; END
	
	-------------------------------------------------------------
	--Inherit Lookup Table Associations

	SELECT top 0 [faa_id],[mftaa_id]
	INTO #TEMP_FTAA  FROM [lookup_table_file_association];
	--ALTER TABLE #TEMP_FTAA ADD [needs_lookup_table] bit null;
	

	--insert into tmp table for the right order
	SELECT 
		@record_id AS [file_identifier],
		A.[attribute_id],
		A.[data_type],
		A.[is_mandatory],
		NULL as attribute_row_position,
		NULL as attribute_start_position,
		NULL as attribute_end_position,
		--A.[needs_lookup_table],
		@CREATED_BY as created_by,
		A.[application_compliant_attribute_name],
		GETDATE() AS [created_date_time],
		--0 AS [is_hardcoded],
		--NULL AS [default_value],
		B.new_id AS [fsa_id], A.mftaa_id, 
		case when A.max_size_allowed is NULL then AD.[attribute_size] else A.max_size_allowed end as attribute_size,
		1 AS [is_inherited], 0 as to_do
		,0 as clone_num 		-- ADAPT - 6906
	INTO #FILE_ATTR_TMP
	FROM 
		[master_file_template_attribute_association] A
		INNER JOIN #TEMP_OLDNEWKEY B ON A.mftsa_id = B.old_id
		INNER JOIN [attribute_dictionary] AD ON A.attribute_id=AD.attribute_id
	WHERE A.[master_file_template_record_id]=@MASTER_FILE_TEMPLATE_RECORD_ID
	order by A.attribute_row_position asc


	MERGE [file_attribute_association] AS TARGET
	USING (
		select * from #FILE_ATTR_TMP) AS SOURCE
	ON 1=0
	WHEN NOT MATCHED THEN
		INSERT ([file_identifier]
		,[attribute_id]
		,[data_type]
		,[is_mandatory]
		,[attribute_row_position]
		,[attribute_start_position]
		,[attribute_end_position]
		--,[needs_lookup_table]
		,[created_by]
		,[created_date_time]
		--,[is_hardcoded]
		--,[default_value]
		,[fsa_id]
		,[attribute_size]
		,[is_inherited]
		,[file_format_compliant_attribute_name]
		,[updated_by]
		,[updated_date_time]
		,[clone_num]
		,[to_do])
	VALUES (
		SOURCE.[file_identifier],
		SOURCE.[attribute_id],
		SOURCE.[data_type],
		SOURCE.[is_mandatory],
		SOURCE.[attribute_row_position],
		SOURCE.[attribute_start_position],
		SOURCE.[attribute_end_position],
		--SOURCE.[needs_lookup_table],
		@CREATED_BY,
		GETDATE(),
		--SOURCE.[is_hardcoded],
		--SOURCE.[default_value],
		SOURCE.[fsa_id],
		SOURCE.[attribute_size],
		SOURCE.[is_inherited],
		SOURCE.[application_compliant_attribute_name],
		@CREATED_BY,
		GETDATE(),
		SOURCE.[clone_num],		-- ADAPT - 6906
		SOURCE.[to_do] 
		)
	OUTPUT INSERTED.[faa_id], SOURCE.mftaa_id INTO #TEMP_FTAA;
	
		

-----------------------------------------------------------
--Inherit  Business Rules Associations
--- get record count for rules ----
DECLARE @RULES_COUNT INT
select @RULES_COUNT= count(1) from mtls_node_br_assoc mtlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id and mtlsni.is_active=1
where mtlsni.master_file_template_record_id=@MASTER_FILE_TEMPLATE_RECORD_ID


--- reseed the identity ----
DECLARE @NEW_DBRDT_RESEED INT
DECLARE @CURRENT_DBRDT_RESEED INT
DECLARE @NEW_DBRDT_INDENT INT
SET @CURRENT_DBRDT_RESEED=(SELECT IDENT_CURRENT( 'drools_business_rules_decision_table' ) AS A)
SET @NEW_DBRDT_RESEED =@CURRENT_DBRDT_RESEED+@RULES_COUNT+5
DBCC CHECKIDENT ('drools_business_rules_decision_table', RESEED, @NEW_DBRDT_RESEED)
SET @NEW_DBRDT_INDENT=@CURRENT_DBRDT_RESEED+2

IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END
	CREATE TABLE #TEMP_DBRDT_OLDNEWKEY ( new_id int, old_id int ,rule_version int)

INSERT into #TEMP_DBRDT_OLDNEWKEY (new_id,old_id,rule_version)
(select @NEW_DBRDT_INDENT+Row_number() Over(Order by drools_business_rule_id)
,drools_business_rule_id,drools_business_rule_version from (
select drools_business_rule_id,drools_business_rule_version from mtls_node_br_assoc mtlsnba
join drools_business_rules_decision_table dbrdt on dbrdt.drools_business_rule_id=mtlsnba.business_rule_id
join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id and mtlsni.is_active=1
where mtlsni.master_file_template_record_id=@MASTER_FILE_TEMPLATE_RECORD_ID
) a)


SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] ON
insert into [drools_business_rules_decision_table](drools_business_rule_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
drools_business_rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,created_by,created_date)
(select new_id,drools_business_rule_name,drools_business_rule_group_id,rule_group_hierarchy_string,
rule_version,drools_business_rule_drl_file_content,is_current,drools_business_rule_pre_drl_text,
drools_business_rule_ui_json_text,@CREATED_BY,getDate() from [drools_business_rules_decision_table] join #TEMP_DBRDT_OLDNEWKEY
on drools_business_rule_id=old_id)
SET IDENTITY_INSERT [dbo].[drools_business_rules_decision_table] OFF


				------------------------------------------------------------------------------------------------
				----------------------------------------- DYNAMIC SCHEMA ---------------------------------------
				------------------------------------------------------------------------------------------------
				
				if exists(select 1 from master_template_layout_schema_node_info mtlsni where [master_file_template_record_id] = @MASTER_FILE_TEMPLATE_RECORD_ID and is_active=1)
				BEGIN

				DECLARE @MTLSNI_COUNT INT
				select @MTLSNI_COUNT= count(1) from master_template_layout_schema_node_info mtlsni where [master_file_template_record_id] = @MASTER_FILE_TEMPLATE_RECORD_ID
				and mtlsni.is_active=1
				
				
									DECLARE @NEW_FLSNI_RESEED INT=0
									DECLARE @CURRENT_FLSNI_RESEED INT=0
									DECLARE @NEW_FLSNI_INDENT INT=0
									SET @CURRENT_FLSNI_RESEED =(SELECT IDENT_CURRENT( 'file_layout_schema_node_info' ) AS A)
									SET @CURRENT_FLSNI_RESEED = case when @CURRENT_FLSNI_RESEED is NULL then 0 else @CURRENT_FLSNI_RESEED end;
									SET @NEW_FLSNI_RESEED =@CURRENT_FLSNI_RESEED+@MTLSNI_COUNT+5
									DBCC CHECKIDENT ('file_layout_schema_node_info', RESEED, @NEW_FLSNI_RESEED)
									SET @NEW_FLSNI_INDENT=@CURRENT_FLSNI_RESEED+2

									IF OBJECT_ID('tempdb..#TEMP_MTLSNI_OLDNEWKEY') IS NOT NULL 
									BEGIN DROP TABLE #TEMP_MTLSNI_OLDNEWKEY; END
									CREATE TABLE #TEMP_MTLSNI_OLDNEWKEY ( new_id int, old_id int)

									INSERT into #TEMP_MTLSNI_OLDNEWKEY (new_id,old_id) (select @NEW_FLSNI_INDENT+Row_number() Over(Order by mtlsni_id),mtlsni_id
									from master_template_layout_schema_node_info mtlsni where [master_file_template_record_id] = @MASTER_FILE_TEMPLATE_RECORD_ID
									and mtlsni.is_active=1)

									
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] ON 
									INSERT INTO [dbo].[file_layout_schema_node_info]([flsni_id],[file_identifier],[node_category],[node_display_name],[node_data_type_id],
									[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
									[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time]
									,[node_max_size],[node_min_size],[node_clone_num])
									SELECT new_id,@record_id,[node_category],[node_display_name],[node_data_type_id],[node_min_count],[node_max_count],[node_ref_num],[node_row_position],
									[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],[mapped_template_section_id],[node_section_short_name],1,@CREATED_BY,getDate()
									,@CREATED_BY,getDate(),[node_max_size],[node_min_size],0 FROM master_template_layout_schema_node_info mtlsni 
									join #TEMP_MTLSNI_OLDNEWKEY on mtlsni.mtlsni_id=old_id
									where [master_file_template_record_id] = @MASTER_FILE_TEMPLATE_RECORD_ID
									and mtlsni.is_active=1
									SET IDENTITY_INSERT [dbo].[file_layout_schema_node_info] OFF
									
									INSERT INTO [dbo].[file_layout_schema_node_assoc]([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time], [updated_by],[updated_date_time])
									SELECT a.new_id,
									case when parent_mtlsni_id is NULL then NULL else b.new_id end,
									node_has_children,@CREATED_BY,getDate(),@CREATED_BY,getDate() from [master_template_layout_schema_node_assoc] mtlsna
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsna.mtlsni_id
									join #TEMP_MTLSNI_OLDNEWKEY a on mtlsna.mtlsni_id=old_id left outer join #TEMP_MTLSNI_OLDNEWKEY b on mtlsna.parent_mtlsni_id=b.old_id
									where mtlsni.master_file_template_record_id=@MASTER_FILE_TEMPLATE_RECORD_ID
									and mtlsni.is_active=1
									
									INSERT INTO [dbo].[fls_node_dm_element_assoc]([flsni_id],[faa_id],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT new_id,faa.faa_id,mtlsnda.is_active,@CREATED_BY,getDate(),@CREATED_BY,getDate() from mtls_node_dm_element_assoc mtlsnda 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnda.mtlsni_id
									join master_file_template_attribute_association mftaa on mftaa.mftaa_id=mtlsnda.mftaa_id
									join master_file_template_section_assoc mftsa on mftsa.mftsa_id=mftaa.mftsa_id
									join file_attribute_association faa on faa.attribute_id=mftaa.attribute_id and faa.file_identifier=@record_id
									join file_section_association fsa on faa.fsa_id=fsa.fsa_id and fsa.template_section_id=mftsa.template_section_id and fsa.file_identifier=@record_id
									join #TEMP_MTLSNI_OLDNEWKEY on mtlsnda.mtlsni_id=old_id 
									where mtlsni.master_file_template_record_id=@MASTER_FILE_TEMPLATE_RECORD_ID
									and mtlsni.is_active=1     
									
									INSERT INTO [dbo].[fls_node_br_assoc]([flsni_id],[business_rule_id],[rule_execution_sequence],[rule_execution_comment],[is_active],[created_by],[created_date_time],[updated_by],[updated_date_time])
									SELECT a.new_id,b.new_id,rule_execution_sequence,null,1,@CREATED_BY,getDate(),@CREATED_BY,getDate() from mtls_node_br_assoc mtlsnba 
									join master_template_layout_schema_node_info mtlsni on mtlsni.mtlsni_id=mtlsnba.mtlsni_id
									join #TEMP_DBRDT_OLDNEWKEY b on mtlsnba.business_rule_id=b.old_id
									join #TEMP_MTLSNI_OLDNEWKEY a on mtlsnba.mtlsni_id=a.old_id where mtlsni.master_file_template_record_id=@MASTER_FILE_TEMPLATE_RECORD_ID
									and mtlsni.is_active=1  and mtlsnba.is_active=1  
			
			
									
				END;

IF OBJECT_ID('tempdb..#TEMP_DBRDT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_DBRDT_OLDNEWKEY; END

IF OBJECT_ID('tempdb..#TEMP_LT_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_LT_OLDNEWKEY; END

	IF OBJECT_ID('tempdb..#TEMP_MTLSNI_OLDNEWKEY') IS NOT NULL 
	BEGIN DROP TABLE #TEMP_MTLSNI_OLDNEWKEY; END
	
END



GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Inherit_Master_To_File TO exec_proc
GO


