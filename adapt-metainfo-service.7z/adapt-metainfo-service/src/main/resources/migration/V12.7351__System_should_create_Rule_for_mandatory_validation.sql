use [idis-metainfo]
GO

/*
Update Log

Date        	Author          	Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-09-11   Nilesh Jariya		 ADAPT-7351 System should create Rule for mandatory validation - new rule group for schema mandatory validation

-- Table 
-- drools_business_rule_group_name
*/

if not exists (select 1 from drools_business_rule_group where drools_business_rule_group_id = 13)
BEGIN
SET IDENTITY_INSERT [dbo].[drools_business_rule_group] ON 

INSERT INTO [dbo].drools_business_rule_group (drools_business_rule_group_id,drools_business_rule_group_name,parent_group_id,created_by,created_date,updated_by,updated_date,drools_business_rule_group_priority) VALUES 
(13,'SchemaValidation',NULL,'Nilesh Jariya',getdate(),NULL,NULL,1);

SET IDENTITY_INSERT [dbo].[drools_business_rule_group] OFF 
END
GO
