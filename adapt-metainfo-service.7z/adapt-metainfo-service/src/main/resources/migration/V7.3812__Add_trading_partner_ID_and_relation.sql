USE [idis-metainfo]

/*
--Update Log
--Date        Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
--2019-06-29	Jinesh Vora		ADAPT-3812: Disassociate Trading Partner Platform from Contact

-- Table Used 
-- trading_partner_contact_tpp_assoc
-- trading_partner_platform_info

*/
-- 1
IF NOT EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_contact_tpp_assoc' and column_name ='trading_partner_id' 
)
BEGIN
ALTER TABLE trading_partner_contact_tpp_assoc Add trading_partner_id int;
END;

GO

-- 2
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_contact_tpp_assoc' and column_name ='trading_partner_platform_id' 
)
BEGIN
ALTER TABLE [trading_partner_contact_tpp_assoc] ALTER COLUMN [trading_partner_platform_id] [int] NULL;
END;
GO

-- 3
IF EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpcta_K2_trading_partner_platform_info_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_contact_tpp_assoc')
		)
BEGIN
		ALTER TABLE trading_partner_contact_tpp_assoc
			NOCHECK CONSTRAINT FK_tpcta_K2_trading_partner_platform_info_K1;
END;
GO
-- Migration Script 
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_contact_tpp_assoc' and column_name ='trading_partner_id' 
)
BEGIN
Update  tpc 
set tpc.trading_partner_id = tpci.trading_partner_id
FROM
trading_partner_platform_info tpci JOIN 
trading_partner_contact_tpp_assoc tpc 
on tpc.trading_partner_platform_id = tpci.trading_partner_platform_id 
WHERE tpc.trading_partner_id is null;
END;
GO

-- Altet Table
IF EXISTS (SELECT 1 FROM information_schema.columns where table_name='trading_partner_contact_tpp_assoc' and column_name ='trading_partner_id' 
)
BEGIN
ALTER TABLE trading_partner_contact_tpp_assoc 
ALTER COLUMN [trading_partner_id] [int] NOT NULL;
END;


-- 4
IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tpcta_K9_tpi_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.trading_partner_contact_tpp_assoc')
		)
BEGIN
	ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc]
		WITH CHECK ADD CONSTRAINT [FK_tpcta_K9_tpi_K1] FOREIGN KEY ([trading_partner_id]) REFERENCES [dbo].[trading_partner_info]([trading_partner_id])

	ALTER TABLE [dbo].[trading_partner_contact_tpp_assoc] CHECK CONSTRAINT [FK_tpcta_K9_tpi_K1]
END;
GO


