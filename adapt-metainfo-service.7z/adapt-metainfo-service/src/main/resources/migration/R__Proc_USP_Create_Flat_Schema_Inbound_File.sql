use [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Create_Flat_Schema_Inbound_File]    Script Date: 3/14/2019 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Create_Flat_Schema_Inbound_File') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Create_Flat_Schema_Inbound_File AS SELECT 1')
GO
/*
Update Log	
----------  ------------    ---------------------------------------------------------------------------------------
14-03-2019  Richa Ashara	   ADAPT-2720 : Populate schema for inbound File's
*/

ALTER Procedure [dbo].[USP_Create_Flat_Schema_Inbound_File]
	(
		@file_identifier INT,
		@oError_code INT OUT
	) 
AS

BEGIN

SET NOCOUNT ON; 

declare @fsa_id int;
declare @parent_flsni_id int;
declare @template_id int;
declare @created_by varchar(50);
declare @created_date_time datetime;



	SET @oError_code = 0;
	
	if EXISTS(SELECT 1 FROM file_layout_schema_node_info WHERE file_identifier = @file_identifier)
	BEGIN
		 BEGIN TRANSACTION T1;
		 BEGIN TRY
			 DELETE FROM fls_node_dm_element_assoc Where flsni_id in (SELECT flsni_id FROM file_layout_schema_node_info WHERE file_identifier = @file_identifier)
			 DELETE FROM file_layout_schema_node_assoc Where flsni_id in (SELECT flsni_id FROM file_layout_schema_node_info WHERE file_identifier = @file_identifier)
			 DELETE FROM file_layout_schema_node_info WHERE file_identifier = @file_identifier
			 COMMIT TRANSACTION T1;
			 SET @oError_code = 0;
			 print 'Existing file identifier deleted successfully flat schema...'
		 END TRY
		 BEGIN CATCH
			ROLLBACK TRANSACTION T1;
			SET @oError_code = -1;
			print 'Error while deleting existing file identifier from flat schema...'
		END CATCH 
	END;
	
	BEGIN TRANSACTION T2
	BEGIN TRY 
		DECLARE cur CURSOR LOCAL FOR SELECT [fsa_id],[template_section_id] FROM [dbo].[file_section_association] where 
		[file_identifier]=@file_identifier order by sequence asc;

			declare @rowPosition int=1;
			OPEN cur;

			FETCH NEXT FROM cur INTO @fsa_id,@template_id;
			WHILE @@FETCH_STATUS = 0
				BEGIN
					INSERT INTO [dbo].[file_layout_schema_node_info] ([file_identifier],[node_category],[node_display_name],[node_data_type_id],
					[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
					[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],
					[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num]) 
					(select @file_identifier,'Section',
					case when section_display_name is NULL then ts.section_name else section_display_name end,
					1,1,1,@rowPosition,@rowPosition,NULL,1,NULL,section_name,@template_id,
					file_compliant_section_short_name,1,fsa.created_by,fsa.created_date_time,fsa.sequence,NULL,NULL,0 from file_section_association fsa
					join template_sections ts on fsa.template_section_id=ts.template_section_id where fsa_id=@fsa_id)

					select @parent_flsni_id=flsni_id,@created_by=created_by,@created_date_time=created_date_time
					from file_layout_schema_node_info where file_identifier=@file_identifier and
					mapped_template_section_id=@template_id

					declare @attrFlag bit=0;
					select top 1 @attrFlag=1 from file_attribute_association where fsa_id=@fsa_id 

					INSERT INTO [dbo].[file_layout_schema_node_assoc] ([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time]) 
					values(@parent_flsni_id,NULL,@attrFlag,@created_by,@created_date_time)

					if exists(select 1 from file_attribute_association where fsa_id=@fsa_id )
					begin
					--print 'exists'
					--end

					declare @faa_id int;
					declare @attribute_name varchar(max);
					declare @flsni_id int;
					declare @clone_num int;
					DECLARE attrCur CURSOR LOCAL FOR SELECT [faa_id],
					case when file_format_compliant_attribute_name is not null then file_format_compliant_attribute_name else attribute_name end
					,faa.clone_num
					FROM [dbo].[file_attribute_association] faa join attribute_dictionary ad on faa.attribute_id=ad.attribute_id where 
					[file_identifier]=@file_identifier and fsa_id=@fsa_id
					order by attribute_row_position asc;
					OPEN attrCur;

						FETCH NEXT FROM attrCur INTO @faa_id,@attribute_name,@clone_num;
						WHILE @@FETCH_STATUS = 0
							BEGIN
						
							INSERT INTO [dbo].[file_layout_schema_node_info] ([file_identifier],[node_category],[node_display_name],[node_data_type_id],
							[node_min_count],[node_max_count],[node_ref_num],[node_row_position],[node_description],[node_is_mandatory],[node_cond_description],[mapped_column_type],
							[mapped_template_section_id],[node_section_short_name],[is_active],[created_by],[created_date_time],[node_max_size],
							[mapped_column_order],[mapped_column_start_position],[mapped_column_end_position],[node_clone_num]) 
							(select  @file_identifier,'Element',
							case when file_format_compliant_attribute_name is null then @attribute_name else file_format_compliant_attribute_name end,
							adt.attribute_data_type_id,1,1,@rowPosition,@rowPosition,NULL,faa.is_mandatory,NULL,'Data Element And/Or Enumerated Values',
							NULL,fsa.file_compliant_section_short_name,1,faa.created_by,faa.created_date_time,faa.attribute_size,
							faa.attribute_row_position,faa.attribute_start_position,faa.attribute_end_position,faa.clone_num
							from [file_attribute_association] faa join attribute_dictionary ad on ad.attribute_id=faa.attribute_id
							join file_section_association fsa on faa.fsa_id=fsa.fsa_id
							left join attribute_data_types adt on adt.attribute_data_type_name=faa.data_type
							where faa_id=@faa_id)

							select @flsni_id=flsni_id,@created_by=created_by,@created_date_time=created_date_time 
							from file_layout_schema_node_info where file_identifier=@file_identifier and
							node_display_name=@attribute_name and node_row_position=@rowPosition and node_clone_num=@clone_num
						
							INSERT INTO [dbo].[file_layout_schema_node_assoc] ([flsni_id],[parent_flsni_id],[node_has_children],[created_by],[created_date_time]) 
							values(@flsni_id,@parent_flsni_id,0,@created_by,@created_date_time)

							INSERT INTO [dbo].[fls_node_dm_element_assoc]([flsni_id],[faa_id],[is_active],[created_by],[created_date_time]) 
							select @flsni_id,@faa_id,1,@created_by,@created_date_time from [file_attribute_association]
							where faa_id=@faa_id

	--						select * from [file_attribute_association] where faa_id=@faa_id

							FETCH NEXT FROM attrCur INTO @faa_id,@attribute_name,@clone_num;
							END
						CLOSE attrCur 
						DEALLOCATE attrCur  
					END
					FETCH NEXT FROM cur INTO @fsa_id,@template_id;
					select @rowPosition=@rowPosition+1;
				END
			CLOSE cur    
			DEALLOCATE cur
			COMMIT TRANSACTION T2;
			SET @oError_code = 0;
			print 'file identifier inserted successfully into flat schema...'
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION T2;
			SET @oError_code = -2;
			print 'Error while inserting data to flat schema...'
		END CATCH 
		
END;
GO
-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Create_Flat_Schema_Inbound_File TO exec_proc
GO

