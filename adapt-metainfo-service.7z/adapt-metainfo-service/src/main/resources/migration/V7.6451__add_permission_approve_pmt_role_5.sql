use [idis-metainfo]
GO

/*
Filename:  V7.6451__add_permission_approve_pmt_role_5.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-06-25   Shipra Maheshwari  ADAPT-6451 : Level 5 users should be able to approve/reject promotions(migrations)
*/


if not exists (select 1 from roles_idis_dbrd_actions_assoc where role_id =9 and action_id=32)
BEGIN
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] ON 
INSERT INTO [dbo].[roles_idis_dbrd_actions_assoc]([role_action_assoc_id],[role_id],[action_id],[created_by],[created_date],[updated_by],[updated_date])  VALUES (456,9,32,'shipra maheshwari',getDate(),NULL,NULL); 
SET IDENTITY_INSERT [dbo].[roles_idis_dbrd_actions_assoc] OFF 
END
GO
