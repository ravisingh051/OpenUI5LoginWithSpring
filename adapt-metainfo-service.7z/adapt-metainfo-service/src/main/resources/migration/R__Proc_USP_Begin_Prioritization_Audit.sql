USE [idis-metainfo]
GO
/****** Object:  StoredProcedure [dbo].[USP_Begin_Prioritization_Audit]    Script Date: 2/23/2018 2:30:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.USP_Begin_Prioritization_Audit') IS NULL
EXEC('CREATE PROCEDURE dbo.USP_Begin_Prioritization_Audit AS SELECT 1')
GO


ALTER Procedure [dbo].[USP_Begin_Prioritization_Audit]
	(
		@i_source_instance VARCHAR(20),
		@o_status INT OUT
	) 
AS
BEGIN

SET NOCOUNT ON; 

DECLARE @RC INT;
SET @o_status = -1;

BEGIN TRANSACTION AUDIT_TRAN;

BEGIN TRY
	-- Since this is insert operation, using table level lock
	EXEC @RC = sp_getapplock @Resource='job_prioritization_audit', @LockMode='Exclusive', 
				@LockOwner='Transaction', @LockTimeout=15000;
	PRINT 'Lock Granted Immidiately:'+CAST(@RC as VARCHAR)

	IF EXISTS(SELECT 1 FROM job_prioritization_audit WHERE job_prioritization_status = 'STARTED')
		SET @o_status = -1;
	ELSE
	BEGIN
		INSERT INTO job_prioritization_audit VALUES('STARTED', GETDATE(), NULL, @i_source_instance, GETDATE(), NULL, NULL);
		SET @o_status = 1;
	END

	COMMIT TRANSACTION AUDIT_TRAN;
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION AUDIT_TRAN;
END CATCH
END
GO

-- ============================================================================ 
-- Set permissions 
-- ============================================================================ 
GRANT EXECUTE ON dbo.USP_Begin_Prioritization_Audit TO exec_proc
GO


