USE [idis-metainfo]
GO

/*
Date        Author          		Description
----------  ------------    		-------------------------------------------------------------------------------------------
2019-11-28	Valmik Pujara		ADAPT-8416: Security - Restriction on login attempts in Adapt

Table Name 
-- user_attempts
-- login_audit


*/

/****** Object:  Table [dbo].[user_attempts]    Script Date: 11/28/2019 5:37:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[user_attempts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[user_attempts](
	[user_attempts_id] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](50) NOT NULL,
	[attempts] [int] NOT NULL,
	[last_modified] [datetime] NOT NULL 
	CONSTRAINT [user_attempts_id] PRIMARY KEY CLUSTERED 
(
	[user_attempts_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[login_audit]    Script Date: 11/28/2019 5:37:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[login_audit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[login_audit](
	[login_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](50) NOT NULL,
	[created_datetime] [datetime] NOT NULL,
	[event_name] [varchar](50) NOT NULL,
	[ip_address] [varchar](50) NULL CONSTRAINT  DF_login_audit_is_logged_in_successfully DEFAULT (1)	
	CONSTRAINT [login_audit_id] PRIMARY KEY CLUSTERED 
(
	[login_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO


if not exists (select 1 from adapt_configuration where adapt_configuration_id between 13 and 14)
BEGIN
SET IDENTITY_INSERT [dbo].[adapt_configuration] ON 

INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value,is_active)
values (13,'Login Failure Attempts','6',1);
INSERT INTO [dbo].[adapt_configuration] (adapt_configuration_id,adapt_configuration_key,adapt_configuration_value,is_active)
values (14,'User Attempts Cron Minutes','30',1);

SET IDENTITY_INSERT [dbo].[adapt_configuration] OFF 
END
GO