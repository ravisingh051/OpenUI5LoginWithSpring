USE [idis-metainfo];

/*
Filename:  V2.3177__add_column_tpci_external_server_path.sql

Update Log

Date         Author          Description
----------  ------------    -------------------------------------------------------------------------------------------
2019-04-25   Ravi Singh 		ADAPT-3177 : User should be able to configure Connection (MoveIT/3rd Party) for Outbound
*/

if not exists (select 1 from INFORMATION_SCHEMA.columns where table_name = 'trading_partner_connection_info' and
column_name = 'tpci_external_server_path')

begin
    alter table trading_partner_connection_info add tpci_external_server_path varchar(150) null
end
GO
