use [idis-metainfo]
GO

/*
Filename:  V7.879__add_termination_ind_adv_selection_criteria_outbound.sql

Update Log

Date        	Author          		Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-06-25   Bhaumik Sathvara		ADAPT-879 : User would like to setup Termination Indicator as Advance selection criteria for outbound files
*/

if not exists (select 1 from extraction_parameters where ep_standardized_name = 'terminationInd')
BEGIN
	SET IDENTITY_INSERT [dbo].[extraction_parameters] ON
	insert into extraction_parameters(ep_id,ep_ept_id, ep_name, ep_attribute_id, ep_standardized_name,
	created_by, created_date_time)
	values(42, 2, 'Coverage Termination Indicator', 8, 'terminationInd', 'Bhaumik Sathvara', GETDATE())

	SET IDENTITY_INSERT [dbo].[extraction_parameters] OFF

END
GO