use [idis-metainfo]
GO

/*
Filename:  V8.293__add_transmission_audit_table.sql

Update Log
Date         Author            Description
----------   ----------------    -------------------------------------------------------------------------------------------
2019-07-04   Divya Jain  		ADAPT-293 : Ability to upload an outbound file to a partner location (including MoveIT folder or remote server)
*/



USE [idis-metainfo]
GO
/****** Object:  Table [dbo].[transmission_audit_info]   */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[transmission_audit_info]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[transmission_audit_info](
	[transmission_audit_id] [int] IDENTITY(1,1) NOT NULL,
	[job_id] [INT] NOt NULL,
	[transmission_archive_path] [varchar](1000) NOT NULL,
	[transmission_status] [varchar](50) NOT NULL,
	[transmission_source_instance] [varchar](50) NOT NULL,
	[created_by] [varchar](50) NOT NULL,
	[created_date_time] [datetime] NOT NULL,
	[updated_by] [varchar](50) NULL,
	[updated_date_time] [datetime] NULL,
	[transmission_retry_count] [INT] NOT NULL
 CONSTRAINT [PK_transmission_audit_info_K1] PRIMARY KEY CLUSTERED 
(
	[transmission_audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY])
END
GO
SET ANSI_PADDING OFF
GO


IF NOT EXISTS (
		SELECT 1
		FROM sys.foreign_keys c
		WHERE name = 'FK_tai_K2_job_details_K1'
			AND c.parent_object_id = OBJECT_ID('dbo.transmission_audit_info')
	)
BEGIN
ALTER TABLE [dbo].[transmission_audit_info]  WITH CHECK ADD  CONSTRAINT [FK_tai_K2_job_details_K1] FOREIGN KEY([job_id])
REFERENCES [dbo].[job_details] ([job_id])
ALTER TABLE [dbo].[transmission_audit_info] CHECK CONSTRAINT [FK_tai_K2_job_details_K1]
END;
GO


