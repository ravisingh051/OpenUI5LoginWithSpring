use [idis-metainfo]

---- tooltip data Population for outbound file  -----------

if exists(select 1 from adapt_web_pages where adapt_web_page_id = 14 and adapt_web_pages_name = 'Create new PMT-Attribues list')
BEGIN
UPDATE [dbo].[adapt_web_pages] SET adapt_web_pages_name = 'Create new PMT-Attribute list', adapt_web_pages_desc = 'Create new PMT-Attribute list' where adapt_web_page_id = 14 and adapt_web_pages_name = 'Create new PMT-Attribues list'
END;
GO

if exists(select 1 from adapt_web_pages where adapt_web_page_id = 18 and adapt_web_pages_name = 'New file setup-Attribues list')
BEGIN
UPDATE [dbo].[adapt_web_pages] SET adapt_web_pages_name = 'New file setup-Attribute list', adapt_web_pages_desc = 'New file setup-Attribute list' where adapt_web_page_id = 18 and adapt_web_pages_name = 'New file setup-Attribues list'
END;
GO
