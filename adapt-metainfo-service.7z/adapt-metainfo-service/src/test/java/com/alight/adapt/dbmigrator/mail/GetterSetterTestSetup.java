package com.alight.adapt.dbmigrator.mail;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetterSetterTestSetup {

  /**
   * Generic method to setup gettter and setter for a model/entity class.
   * 
   * @param obj
   *          obj of the class to be checked for.
   * @throws IllegalAccessException
   *           Illegal Access Exception.
   * @throws IllegalArgumentException
   *           Illegal Argument Exception.
   * @throws InvocationTargetException
   *           Invocation Target Exception.
   */
  public void invokeGettersAndSetters(Object obj)
      throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    Method[] methods = obj.getClass().getMethods();
    for (Method method : methods) {
      if (method.getName().startsWith("get") || method.getName().startsWith("is")) {
        method.invoke(obj);
      }
      if (method.getName().startsWith("set")) {
        Class paramClass = method.getParameters()[0].getType();
        if (paramClass.equals(String.class)) {
          String objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, "test");
        } else if (paramClass.equals(Double.class)) {
          Double objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, 1.00d);
        } else if (paramClass.equals(Float.class)) {
          Float objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, 1.00f);
        } else if (paramClass.equals(Boolean.class)) {
          Boolean objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, true);
        } else if (paramClass.equals(Integer.class)) {
          Integer objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, 1);
        } else if (paramClass.equals(Byte.class)) {
          Byte objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, Byte.valueOf((byte) 1));
        } else if (paramClass.equals(int.class)) {
          method.invoke(obj, 1);
        } else if (paramClass.equals(byte.class)) {
          method.invoke(obj, (byte) 1);
        } else if (paramClass.equals(java.sql.Date.class)) {
          method.invoke(obj, (java.sql.Date) (null));
          method.invoke(obj, new java.sql.Date(new java.util.Date().getTime()));
        } else if (paramClass.equals(java.util.Date.class)) {
          method.invoke(obj, (java.util.Date) (null));
          method.invoke(obj, new java.util.Date(new java.util.Date().getTime()));
        } else if (paramClass.equals(java.sql.Timestamp.class)) {
          method.invoke(obj, (java.sql.Timestamp) (null));
          method.invoke(obj, new java.sql.Timestamp(new java.util.Date().getTime()));
        } else if (paramClass.equals(java.sql.Time.class)) {
          method.invoke(obj, new java.sql.Time(new java.util.Date().getTime()));
          method.invoke(obj, (java.sql.Time) (null));
        } else if (paramClass.equals(BigDecimal.class)) {
          BigDecimal objVal = null;
          method.invoke(obj, objVal);
          method.invoke(obj, new BigDecimal("0.0"));
        } else if (paramClass.equals(Map.class)) {
          method.invoke(obj, new HashMap<>());
        } else if (paramClass.equals(Date.class)) {
          method.invoke(obj, new Date());
        }
      }
      if (method.getName().equalsIgnoreCase("toString")) {
        method.invoke(obj);
      }

      for (Method getterMethod : methods) {
        if (getterMethod.getName().startsWith("get") || getterMethod.getName().startsWith("is")
            && getterMethod.getName().contains(method.getName().replaceAll("set", ""))) {
          getterMethod.invoke(obj);
        }
      }

    }

  }

}
