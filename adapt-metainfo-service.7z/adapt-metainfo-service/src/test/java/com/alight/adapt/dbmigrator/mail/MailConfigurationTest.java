package com.alight.adapt.dbmigrator.mail;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { MailConfiguration.class })
@TestPropertySource("classpath:application-test.properties")
public class MailConfigurationTest {

  private static final Logger LOGGER = LoggerFactory.getLogger(MailConfiguration.class);

  @Autowired
  MailConfiguration mailConfiguration;

  @Test
  public void invokeGetterAndSetters() throws InstantiationException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    GetterSetterTestSetup getSets = new GetterSetterTestSetup();
    getSets.invokeGettersAndSetters(new MailConfiguration());

    assertEquals("test2@alight.com", mailConfiguration.getTo());
    assertEquals("test1@alight.com", mailConfiguration.getFrom());
  }

}
