package com.alight.adapt.dbmigrator.mail;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { MailBuilder.class })
public class MailBuilderTest {

  @Autowired
  MailBuilder builder;

  @MockBean
  MailConfiguration mailConfiguration;

  private static final Logger LOGGER = LoggerFactory.getLogger(MailBuilderTest.class);

  @Test
  public void sendMessage() {
    final Mail mail = new Mail();
    mail.setTo("test1@adapt.com");
    mail.setFrom("test2@adapt.com");
    mail.setSubject("Test Subject");
    mail.setContent("This is test email");

    Mockito.when(mailConfiguration.getTo()).thenReturn("test1@adapt.com");
    Mockito.when(mailConfiguration.getFrom()).thenReturn("test2@adapt.com");

    Mail output = builder.build("Test Subject", "This is test email");

    assertEquals(mail.getSubject(), output.getSubject());
    assertEquals(mail.getContent(), output.getContent());
    assertEquals(mail.getTo(), output.getTo());
    assertEquals(mail.getFrom(), output.getFrom());
    assertEquals(mail.getTo(), mailConfiguration.getTo());
    assertEquals(mail.getFrom(), mailConfiguration.getFrom());
  }

}
