package com.alight.adapt.dbmigrator.mail;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { EmailSender.class })
public class EmailSenderTest {

  @Autowired
  EmailSender sender;

  @MockBean
  JavaMailSender emailSender;

  private static final Logger LOGGER = LoggerFactory.getLogger(EmailSenderTest.class);

  @Test
  public void sendMessage() {
    final Mail mail = new Mail();
    mail.setTo("test1@adapt.com");
    mail.setFrom("test2@adapt.com");
    mail.setSubject("Test Subject");
    mail.setContent("This is test email");

    doNothing().when(emailSender).send(any(SimpleMailMessage.class));

    sender.sendMessage(mail);
  }

}
