package com.alight.adapt.dbmigrator.runner;

import static org.mockito.Mockito.doNothing;

import org.flywaydb.core.Flyway;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { MetainfoMigrationRunner.class })
@TestPropertySource("classpath:application-test.properties")
public class BaseMigrationRunnerTest {

  @Autowired
  MetainfoMigrationRunner runner;

  @MockBean
  Flyway flyway;

  private static final Logger LOGGER = LoggerFactory.getLogger(BaseMigrationRunnerTest.class);

  @Test
  public void testRunMigration() {
    doNothing().when(flyway).setBaselineOnMigrate(false);
    doNothing().when(flyway).setSchemas("dbo");
    doNothing().when(flyway).setOutOfOrder(true);

    runner.runMigration();
  }

}
