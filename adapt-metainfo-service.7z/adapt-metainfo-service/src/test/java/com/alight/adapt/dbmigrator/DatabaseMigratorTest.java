package com.alight.adapt.dbmigrator;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import com.alight.adapt.dbmigrator.mail.EmailSender;
import com.alight.adapt.dbmigrator.mail.MailBuilder;
import com.alight.adapt.dbmigrator.runner.BaseMigrationRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DatabaseMigrator.class })
@TestPropertySource("classpath:application-test.properties")
public class DatabaseMigratorTest {

  @Autowired
  private DatabaseMigrator app;

  @MockBean
  BaseMigrationRunner metainfoMigrationRunner;

  @MockBean
  EmailSender emailSender;

  @MockBean
  MailBuilder mailBuilder;

  private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseMigratorTest.class);

  @Test
  public void testRunMigration() {

    doNothing().when(emailSender).sendMessage(any());
    doNothing().when(metainfoMigrationRunner).runMigration();

    app.runMigration();
  }

  @Test
  public void testRunMigrationFail() {

    doNothing().when(emailSender).sendMessage(any());
    doThrow(new RuntimeException()).when(metainfoMigrationRunner).runMigration();

    app.runMigration();
  }

}
