package com.alight.adapt.dbmigrator.mail;

import java.lang.reflect.InvocationTargetException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { Mail.class })
public class MailTest {

  private static final Logger LOGGER = LoggerFactory.getLogger(Mail.class);

  @Test
  public void invokeGetterAndSetters() throws InstantiationException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    GetterSetterTestSetup getSets = new GetterSetterTestSetup();
    getSets.invokeGettersAndSetters(new Mail());
  }

}
