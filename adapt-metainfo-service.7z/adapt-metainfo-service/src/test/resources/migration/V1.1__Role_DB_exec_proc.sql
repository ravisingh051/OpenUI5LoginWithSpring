use [master]
GO
-- User
IF NOT EXISTS(SELECT * FROM sys.server_principals WHERE name = N'idisApp') 
CREATE LOGIN [idisApp] WITH PASSWORD=N'AW5Pw0rd!', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO


USE [idis-metainfo];
GO

/*
Filename: Role_DB_exec_proc.sql

This function adds the exec_proc role to the database.

Update Log
----------  ------------    ---------------------------------------------------
2018-06-19  Divya Jain     CC-35053: Refactoring database repository for Flyway integration
*/


IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'exec_proc' AND Type = 'R') BEGIN
       CREATE ROLE [exec_proc];
END

IF(is_rolemember('exec_proc', 'idisApp') = 0)
BEGIN
       ALTER ROLE [exec_proc] ADD MEMBER [idisApp];
END


GO

