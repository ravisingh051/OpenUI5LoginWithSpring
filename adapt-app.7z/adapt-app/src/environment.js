(function (window) {
    window.__env = window.__env || {};
    window.__env.endpoint = 'https://localhost:12020';
}(this));