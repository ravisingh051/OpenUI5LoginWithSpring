import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ShowLinkBasedOnEmpAccessDirective } from "./show-link-based-on-emp-access.directive";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ShowLinkBasedOnEmpAccessDirective],
  exports: [ShowLinkBasedOnEmpAccessDirective]
})
export class ShowLinkBasedOnEmpAccessModule { }
