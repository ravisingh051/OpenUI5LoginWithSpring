import { Directive, Input, TemplateRef, ViewContainerRef } from "@angular/core";
import { EMPLOYER_GROUPS } from "../components/login/login.constant";

@Directive({
  selector: "[appShowLinkBasedOnEmpAccess]",
  exportAs: "appShowLinkBasedOnEmpAccess"
})
export class ShowLinkBasedOnEmpAccessDirective {
  /* istanbul ignore next */
  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef
  ) { }
  /* istanbul ignore next */
  isHaveAccess(clientIds: Array<string>) {
    const clientIdsStr = localStorage.getItem(EMPLOYER_GROUPS);
    const parsedClientIds = JSON.parse(clientIdsStr);

    let foundMatch = false;
    for (let ci = 0; ci < clientIds.length; ci++) {
      foundMatch = false;
      for (let id = 0; id < parsedClientIds.length; id++) {
        if (parsedClientIds[id].includes(clientIds[ci])) {
          foundMatch = true;
          break;
        }
      }

      if (!foundMatch) {
        return false;
      }
    }
    return foundMatch;
  }

  @Input()
  set appShowLinkBasedOnEmpAccess(clientIds: Array<string>) {
    /* istanbul ignore next */
    if (!clientIds || !clientIds.length) {
      return;
    }
    /* istanbul ignore next */
    this.viewContainer.clear();
    /* istanbul ignore next */
    if (this.isHaveAccess(clientIds)) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    }
  }

}
