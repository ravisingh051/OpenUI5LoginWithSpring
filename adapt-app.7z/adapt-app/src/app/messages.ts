/*
 * error.ts
 *
 */
"use strict";

export const iDISErrorMessages = {
    /* error messages */
    USERNAME_PASSWORD_INVALID: "Username or Password Invalid",
};
