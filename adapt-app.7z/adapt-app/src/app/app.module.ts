import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule, Injector } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { DropdownModule } from "primeng/primeng";
import { CalendarModule } from "primeng/primeng";
import { TabViewModule } from "primeng/primeng";
import { DataTableModule, SharedModule } from "primeng/primeng";
import { MultiSelectModule } from "primeng/primeng";
import { OverlayPanelModule } from "primeng/primeng";
import { DialogModule } from "primeng/primeng";
import { CheckboxModule } from "primeng/primeng";
import { RadioButtonModule } from "primeng/primeng";
import { PickListModule } from "primeng/primeng";
import { PanelModule } from "primeng/primeng";
import { AccordionModule } from "primeng/primeng";
import { CustomFormsModule } from "ng2-validation";
import { MenuModule } from "primeng/components/menu/menu";

import { AppComponent } from "./app.component";
import { EnvServiceProvider } from "./env.service.provider";
import { AlSidebarComponent } from "./components/al-sidebar/al-sidebar.component";
import { AlHeaderComponent } from "./components/al-header/al-header.component";
import { AlDashboardComponent } from "./components/al-dashboard/al-dashboard.component";
import { routing } from "./app.routing";
import { AlWidgetMenuComponent } from "./components/al-widget-menu/al-widget-menu";

import { FileSetupModule } from "./components/file-setup/file-setup.module";
import { JobsSchduleModule } from "./components/job-setup/job-setup.module";
import { SidebarModule } from "./components/al-sidebar/al-sidebar-module";

import { AlViewScheduleComponent } from "./components/al-view-schedule/al-view-schedule.component";
import { AlFooterComponent } from "./components/al-footer/al-footer.component";


import { AlMssDashboardComponent } from "./components/al-mss-dashboard/al-mss-dashboard.component";
import { TooltipModule } from "primeng/primeng";
import { CommonsComponentModule } from "./components/commons/commons.module";
import { LoginComponent } from "./components/login/login.component";
import { LoginService } from "./components/login/login.service";
import { ConfirmDialogModule } from "primeng/components/confirmdialog/confirmdialog";

import { AuthConfig, AuthHttp } from "angular2-jwt";
import { TOKEN_NAME } from "./components/login/login.constant";
import { AuthGuard } from "./services/guards/auth-guard.service";
import { RescheduleService } from "./services/common/reschedule";
import "./rxjs-operators";
import { NgxPermissionsModule } from "ngx-permissions";
import { RouterDetailsService } from "./services/common/router.details";
import { ToolTipUtilService } from "./services/common/toolTipUtil";
import { AppUtility } from "./sharedModules/al-popover/utility";
import { AlPopOverModule } from "./sharedModules/al-popover/al-popover.module";
import { ShowLinkBasedOnEmpAccessModule } from "./show-link-based-on-emp-access/show-link-based-on-emp-access.module";
import { CanDeactivateGuard } from "./services/guards/can-deactivate-guard.service";
import { ConfirmationService } from "primeng/components/common/api";
import { Router } from "@angular/router";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { TokenInterceptor } from "./http_intercepters/token.interceptor";
import { SessionTimeOutMsg } from "./services/common/sessionTimeOut";


@NgModule({
  declarations: [
    AppComponent,
    AlHeaderComponent,
    AlDashboardComponent,
    AlWidgetMenuComponent,
    AlViewScheduleComponent,
    AlFooterComponent,
    AlMssDashboardComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    routing,
    ToastModule.forRoot(),
    DropdownModule,
    CalendarModule,
    TabViewModule,
    DataTableModule,
    SharedModule,
    MultiSelectModule,
    OverlayPanelModule,
    DialogModule,
    CheckboxModule,
    RadioButtonModule,
    PickListModule,
    PanelModule,
    FileSetupModule,
    TooltipModule,
    SidebarModule,
    JobsSchduleModule,
    CommonsComponentModule,
    AccordionModule,
    MenuModule,
    ConfirmDialogModule,
    AlPopOverModule,
    NgxPermissionsModule.forRoot(),
    ShowLinkBasedOnEmpAccessModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    SessionTimeOutMsg,
    AuthGuard,
    LoginService,
    RescheduleService,
    RouterDetailsService,
    ToolTipUtilService,
    AppUtility,
    ConfirmationService,
    CanDeactivateGuard,
    EnvServiceProvider
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }