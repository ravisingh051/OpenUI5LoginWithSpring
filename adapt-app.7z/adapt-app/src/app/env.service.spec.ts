import { TestBed, inject } from "@angular/core/testing";

import { ApiEnvService } from "./env.service";

describe("ApiEnvService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiEnvService]
    });
  });

  it("should be created", inject([ApiEnvService], (service: ApiEnvService) => {
    expect(service).toBeTruthy();
  }));
});
