// custom-option.ts
import { ToastOptions } from "ng2-toastr";

export class CustomOption extends ToastOptions {
    toastLife = 3000;
}