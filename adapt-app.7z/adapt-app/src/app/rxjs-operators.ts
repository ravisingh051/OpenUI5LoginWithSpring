// Observable class extensions
import "rxjs/add/observable/of";

// Observable operators
import "rxjs/add/operator/take";
import "rxjs/add/operator/map";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";