import { TestBed, async } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { Router, RouterOutlet } from "@angular/router";
import { AppComponent } from "./app.component";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { LoginService } from "./components/login/login.service";
import { BehaviorSubject } from "rxjs";
import { Observable } from "rxjs/Observable";
import { RouterDetailsService } from "./services/common/router.details";
import { Browser } from "protractor";
import { BrowserModule } from "@angular/platform-browser";
import { AlFooterComponent } from "./components/al-footer/al-footer.component";
import { AlHeaderComponent } from "./components/al-header/al-header.component";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, DebugElement } from "@angular/core";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AppComponent", () => {
  let fixture;
  let component;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        HttpClientTestingModule,
        RouterTestingModule,
        ToastModule
      ],
      declarations: [
        AppComponent,
        AlHeaderComponent,
        AlFooterComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        ToastsManager,
        ToastOptions,
        { provide: LoginService, useClass: FakeLoginService },
        { provide: RouterDetailsService, useClass: FakeLoginService }
      ]
    }).compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.debugElement.componentInstance;
    fixture.detectChanges();
  });

  it("should create the app", async(() => {
    expect(component).toBeTruthy();
  }));
});

export class FakeLoginService {
  events: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>("User");
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>("User");

  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }

  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }
}
