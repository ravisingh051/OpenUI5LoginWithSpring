"use strict";

export const MAX_CHARS_DESCRIPTION = 2000; // max characters for description and comments fields
export const MAX_CHARS_TITLE = 150; // max characters for name and label fields

export const DEFAULT_UNIT_OF_MEASURE = {
    abbr: "EA", label: "Each"
};


export const RECURRENCE_TYPE = [
    { label: "Choose One", value: "" },
    { label: "Day - Every Week", value: "dayEveryWeek" },
    { label: "Day - Every Other Week", value: "dayEveryOtherWeek" },
    { label: "Day - First Day of Month", value: "dayFirstDayOfMonth" },
    { label: "Day - Last Date of Month", value: "dayLastDateOfMonth" },
    { label: "Semi Monthly", value: "semiMonthly" },
    { label: "Monthly", value: "monthly" },
    { label: "Custom", value: "custom" },
    { label: "Pay Site", value: "paySite" }
];

export const DURATION = [
    { label: "Second", value: "Second" },
    { label: "Minute", value: "Minute" },
    { label: "Hour", value: "Hour" },
    { label: "Day", value: "Day" },
    { label: "Week", value: "Week" },
    { label: "Month", value: "Month" },
    { label: "Year", value: "Year" }
];
export const DATA_TYPES = [
    { label: "Choose One", value: "" },
    { label: "Bit", value: "bit" },
    { label: "Date", value: "date" },
    { label: "Double", value: "double" },
    { label: "Integer", value: "integer" },
    { label: "String", value: "varchar" }
];

export const MONTH = [
    { label: "Choose One", value: "" },
    { label: "1", value: "1" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "5", value: "5" },
    { label: "6", value: "6" },
    { label: "7", value: "7" },
    { label: "8", value: "8" },
    { label: "9", value: "9" },
    { label: "10", value: "10" },
    { label: "11", value: "11" },
    { label: "12", value: "12" },
    { label: "13", value: "13" },
    { label: "14", value: "14" },
    { label: "15", value: "15" },
    { label: "16", value: "16" },
    { label: "17", value: "17" },
    { label: "18", value: "18" },
    { label: "19", value: "19" },
    { label: "20", value: "20" },
    { label: "21", value: "21" },
    { label: "22", value: "22" },
    { label: "23", value: "23" },
    { label: "24", value: "24" },
    { label: "25", value: "25" },
    { label: "26", value: "26" },
    { label: "27", value: "27" },
    { label: "28", value: "28" },
    { label: "29", value: "29" },
    { label: "30", value: "30" },
    { label: "31", value: "31" }
];

export const EXCEPTION = [
    { label: "Choose One", value: "" },
    { label: "If Saturday then Friday, If Sunday then Monday", value: "0" },
    { label: "If Saturday/Sunday then Friday", value: "1" },
    { label: "If Saturday/Sunday then Monday", value: "2" },
];

export const WEEKDAYS = [
    { label: "Monday", value: 1 },
    { label: "Tuesday", value: 2 },
    { label: "Wednesday", value: 3 },
    { label: "Thursday", value: 4 },
    { label: "Friday", value: 5 },
    { label: "Saturday", value: 6 },
    { label: "Sunday", value: 0 },
];

export const PModeOutbound = [
    { label: "Choose One", value: "" },
    { label: "Extract, Convert, Send To Partner And Then Archive", value: "0" },
    { label: "Extract Only And Then Archive", value: "1" },
    { label: "Extract And Convert And Then Archive", value: "2" },
];

export const PModeInbound = [
    { label: "Choose One", value: "" },
    { label: "Up To CHG Format", value: "0" },
    { label: "Up To Suspense Process", value: "1" },
    { label: "Complete Processing", value: "2" },
];

export const VALIDATION_MSG = "You don't have permission to see the content. Your role doesn't permit to access the page/content . Please contact administrator.";

export const TOAST_SETTING = {
    toastLife: 20000,
    showCloseButton: true,
    dismiss: false
};

export const confAcceptLabel = "Yes";
export const confRejectLabel = "No";
export const confMessage = "Are you sure you want to move away from the current page without saving the data?";