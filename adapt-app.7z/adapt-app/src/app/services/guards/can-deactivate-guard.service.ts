import { Injectable } from "@angular/core";
import { Location } from "@angular/common";
import { CanDeactivate, Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { ConfirmationService } from "primeng/components/common/api";
import { Observer } from "rxjs";
import {TOKEN_NAME } from "../../components/login/login.constant";

export interface CanComponentDeactivate {
    canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable()
export class CanDeactivateGuard implements CanDeactivate<CanComponentDeactivate> {
    constructor(
        private confirmationService: ConfirmationService,
        private readonly location: Location,
        private readonly router: Router
    ) { }
    canDeactivate(component: CanComponentDeactivate, currentRoute: ActivatedRouteSnapshot) {
        if (component["redirectFlag"] && localStorage[TOKEN_NAME]) {
            return Observable.create((observer: Observer<boolean>) => {
                this.confirmationService.confirm({
                    message: component["confMessage"],
                    accept: () => {
                        observer.next(true);
                        observer.complete();
                    },
                    reject: () => {
                        const currentUrlTree = this.router.createUrlTree([], currentRoute);
                        const currentUrl = currentUrlTree.toString();
                        this.location.go(currentUrl);
                        observer.next(false);
                        observer.complete();
                        return false;
                    }
                });
            });
        } else {
            return true;
        }
    }
}