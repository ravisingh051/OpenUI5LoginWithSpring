import { Injectable } from "@angular/core";
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { TOKEN_NAME } from "../../components/login/login.constant";
import { LoginService } from "../../components/login/login.service";
import { Observable } from "rxjs/Observable";


@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private loginService: LoginService) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.loginService.isLoggedIn
      .take(1)
      .map((isLoggedIn: boolean) => {
        const token = localStorage.getItem(TOKEN_NAME);
        if (token === null || token === undefined) {
          this.loginService.loggedIn.next(false);
          this.router.navigate(["/login"]);
          return false;
        } else if (this.tokenNotExpired(TOKEN_NAME, token)) {
          this.loginService.setUserDataOnPageRefersh();
          return true;
        } else {
          this.loginService.logout();
          this.router.navigate(["login"], { queryParams: { redirectTo: state.url } });
          return false;
        }
      });
  }

  tokenNotExpired(tokenName, token) {
    return localStorage.getItem(tokenName) === token ? true : false;
  }

}
