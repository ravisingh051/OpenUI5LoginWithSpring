import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable()
export class SessionTimeOutMsg {

  private _route = new BehaviorSubject(null);
  getSessionMsg = this._route.asObservable();

  constructor() { }

  updateMsg(routes: any) {
    this._route.next(routes);
  }

}