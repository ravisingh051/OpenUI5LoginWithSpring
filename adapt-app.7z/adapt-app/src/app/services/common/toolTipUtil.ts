import { Injectable } from "@angular/core";
import { Subject } from "rxjs/Subject";
import { ApiEnvService } from "../../env.service";
import { AuthHttp } from "angular2-jwt";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class ToolTipUtilService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;

  getPageAndFieldsDetails(adaptWebPageID): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/TooDetails/toolTipPageDetails?adaptWebPageID=" + adaptWebPageID);
  }
}