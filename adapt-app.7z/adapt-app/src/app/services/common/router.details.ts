import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable()
export class RouterDetailsService {

  private _route = new BehaviorSubject({});
  getRouteDetails = this._route.asObservable();

  constructor() { }

  updateRoute(routes: any) {
    this._route.next(routes);
  }

}