import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";

@Injectable()
export class RescheduleService {
  fileStateObject: Object;
  private fileIDSource = new BehaviorSubject<any>([]); // Test Data [1010,1,2020,null,"/dashboard",1538332200000]
  /* expected Object Details :
  [
    1010:fileId,
    1:fileVersion,
    2020:fileProcessingScheduleId,
    null:If need to change whole recurrence, provide jobId if need to change only single Job,
    "/dashboard": from page you comming to redirect after saving data,
    1538332200000:jobScheduleDate
  ]
  */

  currentMessage = this.fileIDSource.asObservable();

  constructor() { }

  changeFileId(obj) {
    this.fileIDSource.next(obj);
  }

  setFileStateObj(obj: Object) {
    this.fileStateObject = obj;
  }

  getFileStateObj() {
    return this.fileStateObject;
  }

}