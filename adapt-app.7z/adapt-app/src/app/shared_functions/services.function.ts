import { Observable } from "rxjs/Observable";
/*istanbul ignore next */
export function extractData(res: any) {
    return res || {};
}
/*istanbul ignore next */
export function handleError(error: any) {
    let message = `Error Status Code ${error.status} at ${error.url}`;
    return Observable.throw(message);
}