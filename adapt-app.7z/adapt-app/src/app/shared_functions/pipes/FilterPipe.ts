import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "FilterPipe",
})
export class FilterPipe implements PipeTransform {
    transform(value: any, input: string, searchableList: any) {
        if (input) {
            if (searchableList !== "filterDate") {
                input = input.toString().toLowerCase();
            }
            return value.filter(function (el: any) {
                let isTrue = false;
                if (searchableList === "fileIdInput") {
                    if (el.fileId !== null) {
                        if (el.fileId.toString().toLowerCase().indexOf(input) > -1) {
                            isTrue = true;
                        }
                        if (isTrue) {
                            return el;
                        }
                    }
                }
                if (searchableList === "Trading Partner") {
                    if (el.tradingPartner !== null) {
                        if (el.tradingPartner.toString().toLowerCase() === input) {
                            return el;
                        }
                    }
                }
                if (searchableList === "LOB") {
                    if (el.lob !== null) {
                        if (el.lob.toString().toLowerCase() === input) {
                            return el;
                        }
                    }
                }
                if (searchableList === "filterDate") {
                    let minDate = Number(input[0]);
                    let maxDate = Number(input[1]);
                    let scDate = Number(el.scheduleDate);
                    if (scDate >= minDate && scDate <= maxDate) {
                        return el;
                    }
                }
                /*for (var k in searchableList) {
                    if (el[searchableList[k]] !== null) {
                        if (el[searchableList[k]].toString().toLowerCase().indexOf(input) > -1) {
                            isTrue = true;
                        }
                        if (isTrue) {
                            return el
                        }
                    }
                }*/
            });
        }
        return value;
    }
}