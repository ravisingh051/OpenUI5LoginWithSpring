import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AlDashboardComponent } from "./components/al-dashboard/al-dashboard.component";
import { AlViewScheduleComponent } from "./components/al-view-schedule/al-view-schedule.component";
// import {AlJobScheduledListComponent} from "./components/job-setup/al-job-scheduled-list/al-job-scheduled-list.component";
import { CommonsComponent } from "./components/commons/commons.component";
import { AlMssDashboardComponent } from "./components/al-mss-dashboard/al-mss-dashboard.component";
import { LoginComponent } from "./components/login/login.component";
import { AuthGuard } from "./services/guards/auth-guard.service";

const appRoutes: Routes = [
  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "dashboard",
    component: AlDashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "file-setup",
    loadChildren: "app/components/file-setup/file-setup.module#FileSetupModule"
  },
  {
    path: "new-job-schedule",
    loadChildren: "app/components/job-setup/job-setup.module#JobsSchduleModule"
  },
  {
    path: "view-schedule",
    component: AlViewScheduleComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "commons",
    loadChildren: "app/components/commons/commons.module#CommonsComponentModule"
  },
  {
    path: "mss-dashboard",
    component: AlMssDashboardComponent,
    canActivate: [AuthGuard]
  }

];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);

