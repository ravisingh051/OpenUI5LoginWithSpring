"use strict";

export const AppConfig = {
  API_ENDPOINT: "http://localhost",
  SITE_TITLE: "ADaPT",
  APP_PROTOCOL: "https",
  APP_PORT: ":12020",
  X_Auth_Token: null
};


export const dashboardConfig = {
  recordInterval$: 5000
};