import { Injectable } from "@angular/core";

@Injectable()

export class ApiEnvService {

  // API url
  public endpoint = "";

  constructor() {
  }

}