import { ApiEnvService } from "./env.service";

export const EnvServiceFactory = () => {
  const env = new ApiEnvService();

  const browserWindow = window || {};
  const browserWindowEnv = browserWindow["__env"] || {};

  for (const key in browserWindowEnv) {
    if (browserWindowEnv.hasOwnProperty(key)) {
      env[key] = window["__env"][key];
    }
  }
  return env;
};

export const EnvServiceProvider = {
  provide: ApiEnvService,
  useFactory: EnvServiceFactory,
  deps: [],
};