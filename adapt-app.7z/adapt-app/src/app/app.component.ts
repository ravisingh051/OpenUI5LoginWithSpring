import { Component, ViewContainerRef } from "@angular/core";
import { CustomOption } from "./toster.options";
import { ToastsManager } from "ng2-toastr";
import { LoginService } from "./components/login/login.service";
import { Observable } from "rxjs/Observable";
import { Router, ActivatedRoute, NavigationEnd } from "@angular/router";
import { RouterDetailsService } from "./services/common/router.details";
import { VALIDATION_MSG } from "./global";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})

export class AppComponent {
  private previousUrl: string = undefined;
  private currentUrl: string = undefined;

  isLoggedIn$: Observable<boolean>;
  constructor(
    public toastr: ToastsManager, vcr: ViewContainerRef,
    private loginService: LoginService,
    private router: Router,
    private routerDetailsService: RouterDetailsService
  ) {
    this.toastr.setRootViewContainerRef(vcr);
    this.currentUrl = this.router.url;
    /*istanbul ignore next */
    router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
        this.routerDetailsService.updateRoute({
          "currentUrl": this.currentUrl,
          "previousUrl": this.previousUrl
        });

      };
    });
  };

  ngOnInit() {
    this.isLoggedIn$ = this.loginService.isLoggedIn;
    window["validationMsg"] = VALIDATION_MSG;
  }


}
