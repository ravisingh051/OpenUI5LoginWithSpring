import { async, ComponentFixture, TestBed, fakeAsync } from "@angular/core/testing";
import { MenuModule } from "primeng/components/menu/menu";
import { MenuItem } from "primeng/components/common/api";
import { AlHeaderComponent } from "./al-header.component";
import { LoginService } from "../login/login.service";
import { Router, ActivatedRoute, RouterModule, Routes } from "@angular/router";
import { AppConfig } from "../../app.config";
import { NgxPermissionsModule } from "ngx-permissions";
import { RouterTestingModule } from "@angular/router/testing";
import { By } from "@angular/platform-browser";
import { BehaviorSubject, Observable } from "rxjs";
import { LoginComponent } from "../login/login.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [

  {
    path: "",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "dashboard",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "file-setup",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "new-job-schedule",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "commons",
    redirectTo: "/login",
    pathMatch: "full"
  },
  {
    path: "login",
    component: AlHeaderComponent
  }
];
const routerMock = {
  navigate: jasmine.createSpy("navigate")
};
const fakeActivatedRoute = {
  snapshot: { data: {} }
} as ActivatedRoute;

describe("AlHeaderComponent", () => {
  let component: AlHeaderComponent;
  let fixture: ComponentFixture<AlHeaderComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MenuModule,
        HttpClientTestingModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes(routes),
        NgxPermissionsModule.forRoot()
      ],
      declarations: [AlHeaderComponent],
      providers: [
        { provide: LoginService, useClass: FakeLoginService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute }
      ]
    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create component", () => {
    expect(component).toBeTruthy();
  });



  it("should click on logout button", () => {
    let openUserMenu = fixture.debugElement.query(By.css(".al-user-nav"));
    openUserMenu.nativeElement.click();
    let menuList = fixture.debugElement.query(By.css(".ui-menu-list"));
    let logoutElement = menuList.queryAll(By.css("a"))[1];
    logoutElement.nativeElement.click();

  });

  it("ngOnInit", () => {
    component.ngOnInit();
  });
  it("Environment Coverage", () => {
    component.setupHeaderStyle("qa1");
    component.setupHeaderStyle("qc1");
    component.setupHeaderStyle("setup");
    component.setupHeaderStyle("adapt");
  });

  it("Check document click for handleClick function", () => {
    document.body.click();
  });

  it("Navbar not minimized", () => {
    document.body.classList.remove("mini-navbar");
    component.navBarMinimize();
  });

  it("Navbar minimized", () => {
    document.body.classList.add("mini-navbar");
    component.navBarMinimize();
  });

});
export class FakeLoginService {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>("User");
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>("User");

  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }

  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }
}