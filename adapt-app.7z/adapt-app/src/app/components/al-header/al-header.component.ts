import { Component, OnInit, ElementRef, Output } from "@angular/core";
import { Router } from "@angular/router";
import { LoginService } from "../login/login.service";
import { Observable } from "rxjs/Observable";
import { MenuItem } from "primeng/components/common/api";
import { AppConfig } from "../../app.config";

@Component({
  selector: "al-header",
  templateUrl: "./al-header.component.html",
  styleUrls: ["./al-header.component.scss"],
  host: {
    "(document:click)": "handleClick($event)",
  },
})
export class AlHeaderComponent implements OnInit {
  elementRef: any;
  show_menu: boolean = false;
  show_noticification: boolean;
  isAuthenticated: boolean;
  isLoggedIn$: Observable<boolean>;
  profileName: string;
  displayName: string;
  appconfig = AppConfig;
  envText;
  envClass;
  winLocation: string = window.location.href;
  // winLocation: string = "https://adapt.alight.com/";
  // header User Menu
  menuItems: MenuItem[];

  constructor(myElement: ElementRef, private router: Router, private loginService: LoginService) { this.elementRef = myElement; }


  ngOnInit() {
    this.isLoggedIn$ = this.loginService.isLoggedIn;

    this.loginService.getDisplayName.subscribe((value) => {
      this.displayName = value;
    });

    this.loginService.getProfileName.subscribe((value) => {
      this.profileName = value;
    });

    this.menuItems = [
      { label: this.profileName, icon: "fa fa-user" },
      {
        label: "Log Out", icon: "fa fa-sign-out", command: (event) => {
          this.logout();
        }
      }
    ];
    let _winLoc = this.winLocation.split("//");
    _winLoc = _winLoc[1].split(".");
    this.setupHeaderStyle(_winLoc[0]);
  }

  setupHeaderStyle(_url) {
    switch (_url) {
      case "qa1":
      case "qa2":
      case "qa3":
        this.envText = "QA ENVIRONMENT";
        this.envClass = "qaEnv";
        break;
      case "qc1":
      case "qc2":
      case "qc3":
        this.envText = "QC ENVIRONMENT";
        this.envClass = "qcEnv";
        break;
      case "setup":
        this.envText = "SETUP ENVIRONMENT";
        this.envClass = "setupEnv";
        break;
      case "adapt":
        this.envText = "PRODUCTION ENVIRONMENT";
        this.envClass = "prodEnv";
        break;
      default:
        this.envText = "Local ENVIRONMENT";
        this.envClass = "qaEnv";
    };
  }

  navBarMinimize() {
    if (document.querySelector("body").className.indexOf("mini-navbar") === -1) {
      document.querySelector("body").classList.add("mini-navbar");
    } else {
      this.show_menu = false;
      document.querySelector("body").classList.remove("mini-navbar");
    }
  }

  handleClick(event) {
    let clickedComponent = event.target;
    let inside = false;
    do {
      if (clickedComponent === this.elementRef.nativeElement) {
        inside = true;
      }
      clickedComponent = clickedComponent.parentNode;
    } while (clickedComponent);
    if (inside) {
    } else {
      this.show_menu = false;
    }
  };

  logout() {
    this.loginService.logout();
    this.router.navigate(["/"]);
  }

  updateMenuItem() {
    this.menuItems[0].label = this.profileName;
  }

}
