import { Component, OnInit, ElementRef } from "@angular/core";

@Component({
  selector: "al-widget-menu",
  templateUrl: "./al-widget-menu.html",
  styleUrls: ["./al-widget-menu.scss"],
  host: {
    "(document:click)": "handleClick($event)",
  },
})
export class AlWidgetMenuComponent implements OnInit {
  elementRef: any;
  show_menu: boolean = false;
  constructor(myElement: ElementRef) { this.elementRef = myElement; }

  ngOnInit() {
  }
  handleClick(event) {
    let clickedComponent = event.target;
    let inside = false;
    do {
      if (clickedComponent === this.elementRef.nativeElement) {
        inside = true;
      }
      clickedComponent = clickedComponent.parentNode;
    } while (clickedComponent);
    if (inside) {
    } else {
      this.show_menu = false;
    }
  };
}
