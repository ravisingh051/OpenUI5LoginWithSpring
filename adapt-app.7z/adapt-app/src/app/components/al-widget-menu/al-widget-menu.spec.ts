import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlWidgetMenuComponent } from "./al-widget-menu";
import { By } from "@angular/platform-browser";
import { ElementRef } from "@angular/core";


export class MockElementRef extends ElementRef {
  constructor() { super(null); }
}

describe("AlWidgetMenuComponent", () => {

  let component: AlWidgetMenuComponent;
  let fixture: ComponentFixture<AlWidgetMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AlWidgetMenuComponent],
      providers: [
        { provide: ElementRef }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlWidgetMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("Execute handleClick() function", () => {
    document.body.click();
  });

  it("Execute handleClick() function with element Ref", () => {
    component.elementRef.nativeElement.click();
  });

});
