import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { Routes } from "@angular/router";

import { AlMssDashboardComponent } from "./al-mss-dashboard.component";
import { AlSidebarComponent } from "../al-sidebar/al-sidebar.component";


const routes: Routes = [
  {
    path: "dashboard",
    component: AlMssDashboardComponent
  },
  {
    path: "commons",
    component: AlMssDashboardComponent
  }
];

describe("AlMssDashboardComponent", () => {
  let component: AlMssDashboardComponent;
  let fixture: ComponentFixture<AlMssDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes(routes)],
      declarations: [ AlMssDashboardComponent, AlSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlMssDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
