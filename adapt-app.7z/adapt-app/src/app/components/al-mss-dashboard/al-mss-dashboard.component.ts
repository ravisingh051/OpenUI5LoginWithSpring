import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-al-mss-dashboard",
  templateUrl: "./al-mss-dashboard.component.html",
  styleUrls: ["./al-mss-dashboard.component.css"]
})
export class AlMssDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
