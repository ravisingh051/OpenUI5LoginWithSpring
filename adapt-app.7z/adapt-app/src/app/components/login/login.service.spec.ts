import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";

import { LoginService } from "./login.service";
import { TOKEN_NAME } from "../login/login.constant";
import { ApiEnvService } from "../../env.service";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: LoginService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                LoginService,
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                ToastsManager,
                ApiEnvService,
                NgxRolesStore,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: ToastOptions, useClass: MockDataService }
            ],
            imports: [
                RouterTestingModule,
                ToastModule,
                HttpClientTestingModule
            ]
        });

    }));

    it("login", async(inject([LoginService], (contactService) => {
        let response = require("../../../assets/test-data/notification-get-all-templete.json");
        let formData = {
            "username": "usertest",
            "password": "Password"
        };
        contactService.login(formData).subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

});

class MockDataService {

}