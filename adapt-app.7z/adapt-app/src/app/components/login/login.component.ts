import { Component, OnInit } from "@angular/core";
import { LoginService } from "./login.service";
import { Router } from "@angular/router";
import { NgxPermissionsService } from "ngx-permissions";
import { SessionTimeOutMsg } from "../../services/common/sessionTimeOut";
import { JwtHelper } from "angular2-jwt";
import { CURRENT_USER } from "./login.constant";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit {

  model = new UserModel("", "");
  loginFailed = false;
  btnClicked = false;
  loginFailedMessage = "";
  jwtHelper: JwtHelper = new JwtHelper();

  constructor(private loginService: LoginService, private router: Router, private sessionTimeOutMsg: SessionTimeOutMsg, private permissionsService: NgxPermissionsService) {
    localStorage.clear();
  }

  ngOnInit() {
    this.loginFailed = false;
    this.loginFailedMessage = "";

    this.sessionTimeOutMsg.getSessionMsg.subscribe((obj) => this.loginFailedMessage = obj);
  }

  onLogin() {
    this.sessionTimeOutMsg.updateMsg("");
    this.btnClicked = true;
    this.loginService.login(this.model).subscribe(result => {
      this.loginService.storeTokenAndUserData(result.access_token, result.refresh_token).subscribe(res => {
        let resultPermissions = res.data.permissions;
        let resultGroups = res.data.clientGroups;
        const decodedToken = this.jwtHelper.decodeToken(result.access_token);
        if (resultPermissions.length > 0) {
          this.permissionsService.loadPermissions(resultPermissions);
          this.loginService.setEmployerGroups(resultGroups);
          this.loginService.loggedIn.next(true);
          let currentUser = { profileName: decodedToken.display_name, displayName: decodedToken.given_name, permissions: resultPermissions, mail: decodedToken.mail };
          localStorage.setItem(CURRENT_USER, JSON.stringify(currentUser));
          this.loginService.profileName.next(decodedToken.display_name);
          this.loginService.displayName.next(decodedToken.given_name);

          this.router.navigate(["/dashboard"]);
        } else {
          this.loginFailed = true;
          this.loginFailedMessage = "Invalid username or password entered. Please check and retry.";
        }
      });
      this.btnClicked = false;
    }, /* istanbul ignore next */ error => {
      let _msg = error.error;
      this.loginFailed = true;
      if (_msg.message === "Bad credentials") {
        this.loginFailedMessage = "Invalid username or password entered. Please check and retry.";
      } else {
        this.loginFailedMessage = _msg.message;
      }
      this.btnClicked = false;
    });
  }
}


export class UserModel {

  constructor(
    public username: string,
    public password: string
  ) { }

}
