import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { FormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { Observable } from "rxjs/Observable";

import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";

import { LoginComponent } from "./login.component";
import { LoginService } from "./login.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { SessionTimeOutMsg } from "../../services/common/sessionTimeOut";
import { Component } from "@angular/core";
import { JwtHelper } from "angular2-jwt";
import { BehaviorSubject } from "rxjs";

describe("LoginComponent", () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let jwtHelper: JwtHelper = new JwtHelper();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        RouterTestingModule,
        NgxPermissionsModule,
        HttpClientTestingModule
      ],
      declarations: [LoginComponent],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: LoginService, useClass: MockDataService },
        { provide: SessionTimeOutMsg, useClass: SessionTimeOutMsg },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should onLogin", () => {
    let result = {
      "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiaWRpc3Jlc291cmNlaWQiXSwicm9sZSI6IkxldmVsNyIsIm1haWwiOiJzaGl2YW5nLm1vZGkuMkBhbGlnaHQuY29tIiwidXNlcl9uYW1lIjoiYWgwMTU0NDY3Iiwic2NvcGUiOlsicmVhZCIsIndyaXRlIl0sImV4cCI6MTU3OTg1MzMwOCwiZGlzcGxheV9uYW1lIjoiU2hpdmFuZyBNb2RpIiwiZ2l2ZW5fbmFtZSI6IlNoaXZhbmciLCJqdGkiOiJleUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKaGRXUWlPbHNpYVdScGMzSmxjMjkxY21ObGFXUWlYU3dpY205c1pTSTZJa3hsZG1Wc055SXNJbTFoYVd3aU9pSnphR2wyWVc1bkxtMXZaR2t1TWtCaGJHbG5hSFF1WTI5dElpd2lkWE5sY2w5dVlXMWxJam9pWVdnd01UVTBORFkzSWl3aWMyTnZjR1VpT2xzaWNtVmhaQ0lzSW5keWFYUmxJbDBzSW1WNGNDSTZNVFUzT1RnMU16TXdPQ3dpWkdsemNHeGhlVjl1WVcxbElqb2lVMmhwZG1GdVp5Qk5iMlJwSWl3aVoybDJaVzVmYm1GdFpTSTZJbE5vYVhaaGJtY2lMQ0pxZEdraU9pSTJOemRsWkdaaE1TMWtZVFV6TFRSbE1EVXRPV0kzT0MwMU56WXlOemMxTkRJelpEWWlMQ0pqYkdsbGJuUmZhV1FpT2lKcFpHbHpRMnhwWlc1MEluMC53ZTFlNkVfaE1jR0FQZVd4NTFnZkpNeHdwdHVVZ1hzeXBETmZfamgwWW1VIiwiY2xpZW50X2lkIjoiaWRpc0NsaWVudCJ9.TWMqKSfVJagjkRWDDefeFRCdaxTBtY9vK-bjqrRVjQM",
      "token_type": "bearer",
      "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiaWRpc3Jlc291cmNlaWQiXSwicm9sZSI6IkxldmVsNyIsIm1haWwiOiJzaGl2YW5nLm1vZGkuMkBhbGlnaHQuY29tIiwidXNlcl9uYW1lIjoiYWgwMTU0NDY3Iiwic2NvcGUiOlsicmVhZCIsIndyaXRlIl0sImF0aSI6ImV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpoZFdRaU9sc2lhV1JwYzNKbGMyOTFjbU5sYVdRaVhTd2ljbTlzWlNJNklreGxkbVZzTnlJc0ltMWhhV3dpT2lKemFHbDJZVzVuTG0xdlpHa3VNa0JoYkdsbmFIUXVZMjl0SWl3aWRYTmxjbDl1WVcxbElqb2lZV2d3TVRVME5EWTNJaXdpYzJOdmNHVWlPbHNpY21WaFpDSXNJbmR5YVhSbElsMHNJbVY0Y0NJNk1UVTNPVGcxTXpNd09Dd2laR2x6Y0d4aGVWOXVZVzFsSWpvaVUyaHBkbUZ1WnlCTmIyUnBJaXdpWjJsMlpXNWZibUZ0WlNJNklsTm9hWFpoYm1jaUxDSnFkR2tpT2lJMk56ZGxaR1poTVMxa1lUVXpMVFJsTURVdE9XSTNPQzAxTnpZeU56YzFOREl6WkRZaUxDSmpiR2xsYm5SZmFXUWlPaUpwWkdselEyeHBaVzUwSW4wLndlMWU2RV9oTWNHQVBlV3g1MWdmSk14d3B0dVVnWHN5cEROZl9qaDBZbVUiLCJleHAiOjE1Nzk4NTM2MDgsImRpc3BsYXlfbmFtZSI6IlNoaXZhbmcgTW9kaSIsImdpdmVuX25hbWUiOiJTaGl2YW5nIiwianRpIjoiNTljYTY5OTktMTkwNC00ZDg3LWIxYzMtNjJiYmY4NGEyOGI1IiwiY2xpZW50X2lkIjoiaWRpc0NsaWVudCJ9.t4VQWOAobMWoYkKGIrOjDx5Ek1CZtyzQBUatjYWYe4U",
      "expires_in": 899,
      "scope": "read write"
    };
    this.jwtHelper = {
      decodeToken: function () { return result;  }
  };

    component.onLogin();
  });
});


class MockDataService {

  // loginService methods
  // =============================

  login(): Observable<any> {
    let response = {
      "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiaWRpc3Jlc291cmNlaWQiXSwicm9sZSI6IkxldmVsNyIsIm1haWwiOiJzaGl2YW5nLm1vZGkuMkBhbGlnaHQuY29tIiwidXNlcl9uYW1lIjoiYWgwMTU0NDY3Iiwic2NvcGUiOlsicmVhZCIsIndyaXRlIl0sImV4cCI6MTU3OTg1MzMwOCwiZGlzcGxheV9uYW1lIjoiU2hpdmFuZyBNb2RpIiwiZ2l2ZW5fbmFtZSI6IlNoaXZhbmciLCJqdGkiOiJleUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKaGRXUWlPbHNpYVdScGMzSmxjMjkxY21ObGFXUWlYU3dpY205c1pTSTZJa3hsZG1Wc055SXNJbTFoYVd3aU9pSnphR2wyWVc1bkxtMXZaR2t1TWtCaGJHbG5hSFF1WTI5dElpd2lkWE5sY2w5dVlXMWxJam9pWVdnd01UVTBORFkzSWl3aWMyTnZjR1VpT2xzaWNtVmhaQ0lzSW5keWFYUmxJbDBzSW1WNGNDSTZNVFUzT1RnMU16TXdPQ3dpWkdsemNHeGhlVjl1WVcxbElqb2lVMmhwZG1GdVp5Qk5iMlJwSWl3aVoybDJaVzVmYm1GdFpTSTZJbE5vYVhaaGJtY2lMQ0pxZEdraU9pSTJOemRsWkdaaE1TMWtZVFV6TFRSbE1EVXRPV0kzT0MwMU56WXlOemMxTkRJelpEWWlMQ0pqYkdsbGJuUmZhV1FpT2lKcFpHbHpRMnhwWlc1MEluMC53ZTFlNkVfaE1jR0FQZVd4NTFnZkpNeHdwdHVVZ1hzeXBETmZfamgwWW1VIiwiY2xpZW50X2lkIjoiaWRpc0NsaWVudCJ9.TWMqKSfVJagjkRWDDefeFRCdaxTBtY9vK-bjqrRVjQM",
      "token_type": "bearer",
      "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiaWRpc3Jlc291cmNlaWQiXSwicm9sZSI6IkxldmVsNyIsIm1haWwiOiJzaGl2YW5nLm1vZGkuMkBhbGlnaHQuY29tIiwidXNlcl9uYW1lIjoiYWgwMTU0NDY3Iiwic2NvcGUiOlsicmVhZCIsIndyaXRlIl0sImF0aSI6ImV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpoZFdRaU9sc2lhV1JwYzNKbGMyOTFjbU5sYVdRaVhTd2ljbTlzWlNJNklreGxkbVZzTnlJc0ltMWhhV3dpT2lKemFHbDJZVzVuTG0xdlpHa3VNa0JoYkdsbmFIUXVZMjl0SWl3aWRYTmxjbDl1WVcxbElqb2lZV2d3TVRVME5EWTNJaXdpYzJOdmNHVWlPbHNpY21WaFpDSXNJbmR5YVhSbElsMHNJbVY0Y0NJNk1UVTNPVGcxTXpNd09Dd2laR2x6Y0d4aGVWOXVZVzFsSWpvaVUyaHBkbUZ1WnlCTmIyUnBJaXdpWjJsMlpXNWZibUZ0WlNJNklsTm9hWFpoYm1jaUxDSnFkR2tpT2lJMk56ZGxaR1poTVMxa1lUVXpMVFJsTURVdE9XSTNPQzAxTnpZeU56YzFOREl6WkRZaUxDSmpiR2xsYm5SZmFXUWlPaUpwWkdselEyeHBaVzUwSW4wLndlMWU2RV9oTWNHQVBlV3g1MWdmSk14d3B0dVVnWHN5cEROZl9qaDBZbVUiLCJleHAiOjE1Nzk4NTM2MDgsImRpc3BsYXlfbmFtZSI6IlNoaXZhbmcgTW9kaSIsImdpdmVuX25hbWUiOiJTaGl2YW5nIiwianRpIjoiNTljYTY5OTktMTkwNC00ZDg3LWIxYzMtNjJiYmY4NGEyOGI1IiwiY2xpZW50X2lkIjoiaWRpc0NsaWVudCJ9.t4VQWOAobMWoYkKGIrOjDx5Ek1CZtyzQBUatjYWYe4U",
      "permissions": "check"
    };
    return (Observable.of(response));
  }
  setEmployerGroups(): Observable<any> {
    let response = {
      data: {
        clientGroups : []
      }
    };
    return (Observable.of(response));
  }
  storeTokenAndUserData(token): Observable<any> {
    let response = {
      "error": false,
      "data": {
        "permissions": [
          "123",
          "456"
        ],
        "clientGroups": [
          "grp1",
          "grp2"
        ]
      }
    };
    return (Observable.of(response));
  }

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>(null);

}
