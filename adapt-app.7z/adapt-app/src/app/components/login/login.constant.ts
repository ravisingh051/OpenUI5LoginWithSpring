export const TOKEN_AUTH_USERNAME = "idisClient";
export const TOKEN_AUTH_PASSWORD = "idisAlight100";
export const TOKEN_NAME = "access_token";
export const REFRESH_TOKEN_NAME = "refresh_token";
export const CURRENT_USER = "";
export const EMPLOYER_GROUPS = "employer_groups";