import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../shared_functions/services.function";
import { TOKEN_AUTH_PASSWORD, TOKEN_AUTH_USERNAME, TOKEN_NAME, CURRENT_USER, EMPLOYER_GROUPS, REFRESH_TOKEN_NAME } from "./login.constant";
import { JwtHelper, AuthHttp } from "angular2-jwt";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Router } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { NgxPermissionsService } from "ngx-permissions";
import { ApiEnvService } from "../../env.service";
import { TOAST_SETTING } from "../../global";
import { ToastsManager } from "ng2-toastr";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class LoginService {

  constructor(private http: HttpClient, private router: Router, private permissionsService: NgxPermissionsService,
     private apiEnvService: ApiEnvService, private authHttp: HttpClient, public toastr: ToastsManager) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  jwtHelper: JwtHelper = new JwtHelper();
  logoutUrl = this.apiEnvService.endpoint + "/api/adapt/logout";
  permissionsUrl = this.apiEnvService.endpoint + "/groups-permissions";
  accessToken: string;
  serviceMappingURL = this.apiEnvEndpoint + "/oauth/token";
  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  mail: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  employerGroups = [];
  resultPermissions: any = [];
  resultGroups: any = [];
  employerIDs = [];

  /* istanbul ignore next */
  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }
  /* istanbul ignore next */
  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }
  /* istanbul ignore next */
  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }
  /* istanbul ignore next */
  public get getMail(): Observable<string> {
    return this.mail.asObservable();
  }

  login(formData): Observable<any> {
    const body = "username=" + encodeURIComponent(formData.username.toLowerCase()) + "&password=" + encodeURIComponent(formData.password) + "&grant_type=password";
    const headers = new HttpHeaders()
          .append("Content-Type", "application/x-www-form-urlencoded")
          .append("Authorization", "Basic " + btoa(TOKEN_AUTH_USERNAME + ":" + TOKEN_AUTH_PASSWORD));

    return this.http.post(this.serviceMappingURL, body, { headers });
  }

  refreshToken(): Observable<any> {
    const body = "refresh_token=" + localStorage.getItem(REFRESH_TOKEN_NAME) + "&grant_type=refresh_token";
    const headers = new HttpHeaders()
          .append("Content-Type", "application/x-www-form-urlencoded")
          .append("Authorization", "Basic " + btoa(TOKEN_AUTH_USERNAME + ":" + TOKEN_AUTH_PASSWORD));

    return this.http.post(this.serviceMappingURL, body, { headers });
  }

  /* istanbul ignore next */
  storeTokenAndUserData(accessToken: string, refreshToken: string) {
    const decodedToken = this.jwtHelper.decodeToken(accessToken);
    this.accessToken = accessToken;
    localStorage.setItem(TOKEN_NAME, accessToken);
    localStorage.setItem(REFRESH_TOKEN_NAME, refreshToken);
    const role = decodedToken.role;
    const body = "role=" + role;
    const headers = new HttpHeaders()
          .append("Content-Type", "application/x-www-form-urlencoded");
    return this.http.post(this.permissionsUrl, body, { headers }).map(extractData).catch(handleError);
  }
  /* istanbul ignore next */
  setUserDataOnPageRefersh() {
    let permissions = [];
    this.loggedIn.next(true);
    let currentUser = JSON.parse(localStorage.getItem(CURRENT_USER));
    this.profileName.next(currentUser.profileName);
    this.displayName.next(currentUser.displayName);
    this.mail.next(currentUser.mail);
    let getPermission = this.permissionsService.getPermissions();
    if (Object.keys(getPermission).length === 0 && getPermission.constructor === Object) {
      this.permissionsService.flushPermissions();
      this.permissionsService.loadPermissions(currentUser.permissions);
    }
    this.employerGroups = JSON.parse(localStorage.getItem(EMPLOYER_GROUPS));
  }
  /* istanbul ignore next */
  logout() {
    this.accessToken = null;
    localStorage.removeItem(CURRENT_USER);
    localStorage.removeItem(EMPLOYER_GROUPS);
    this.loggedIn.next(false);
    this.profileName.next(null);
    this.displayName.next(null);
    this.mail.next(null);
    this.permissionsService.flushPermissions();

    const token = localStorage.getItem(TOKEN_NAME);
    localStorage.removeItem(TOKEN_NAME);
    localStorage.removeItem(REFRESH_TOKEN_NAME);

    const headers = new HttpHeaders()
        .append("Content-Type", "application/json")
        .append("Authorization", "bearer " + token);

    const obj = {};
    this.http.post(this.logoutUrl, obj, {headers}).subscribe(res => {
    });
  }

  /**
   * Set given employer groups  in localstorage.
   *
   * @param employerGroups List of employer groups that have access of various pages.
   */
  /* istanbul ignore next */
  setEmployerGroups(employerGroups: Array<String>) {
    this.employerGroups = employerGroups;
this.employerGroups.forEach((employerGroup) => {
/* Spliting employer id from employer group adapt_qc_client_12345*/
this.employerIDs.push(employerGroup.split("_")[3]);
});
    localStorage.setItem(EMPLOYER_GROUPS, JSON.stringify(employerGroups));
  }

  /**
   * Check is Employer have access by given client ids.
   *
   * @param clientIds Array of client ids
   */
  /* istanbul ignore next */
  isEmployerHaveAccess(clientIds: Array<string>) {
    let foundMatch = false;
    for (let ci = 0; ci < clientIds.length; ci++) {
      foundMatch = false;
      for (let id = 0; id < this.employerGroups.length; id++) {
        if (this.employerGroups[id].includes(clientIds[ci])) {
          foundMatch = true;
          break;
        }
      }

      if (!foundMatch) {
        return false;
      }
    }
    return foundMatch;
  }

  /* istanbul ignore next */
  isMigrationAccess(clientIds: Array<string>) {
    let foundMatch = false;
    for (let ci = 0; ci < clientIds.length; ci++) {
      foundMatch = false;
      for (let id = 0; id < this.employerGroups.length; id++) {
        if (clientIds[ci].includes(this.employerIDs[id] + "::")) {
          foundMatch = true;
          break;
        }
      }

      if (!foundMatch) {
        return false;
      }
    }
    return foundMatch;
  }
}

export class User {
  profileName: string;
  displayName: string;
  mail: string;
  permissions: string[];
}
