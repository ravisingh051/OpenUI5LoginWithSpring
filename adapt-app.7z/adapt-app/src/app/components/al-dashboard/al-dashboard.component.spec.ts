
import { async, ComponentFixture, TestBed, inject, tick, fakeAsync } from "@angular/core/testing";
import { BrowserModule, By } from "@angular/platform-browser";
import { ElementRef } from "@angular/core";
import { AlDashboardComponent } from "./al-dashboard.component";
import { DatePipe, CommonModule } from "@angular/common";
import { CalendarModule } from "primeng/components/calendar/calendar";
import { TabViewModule } from "primeng/components/tabview/tabview";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { MultiSelectModule } from "primeng/components/multiselect/multiselect";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { DropdownModule, ConfirmDialogModule, AutoCompleteModule, AutoComplete } from "primeng/primeng";
import { TooltipModule } from "primeng/components/tooltip/tooltip";
import { AlDashboardService } from "./al-dashboard.services";
import { AppConfig, dashboardConfig } from "../../app.config";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { NgForm, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService, NgxPermissionsModule, NgxPermissionsAllowStubDirective, NgxPermissionsStore } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { RescheduleService } from "../../services/common/reschedule";
import { Router, ActivatedRoute, RouterModule } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { CURRENT_USER } from "../login/login.constant";
import { FileSetupService } from "../file-setup/al-file-setup-services/file-setup.service";
import { ApiEnvService } from "../../env.service";
import { ExcelService } from "./al-dashboard-export-services/al-dashboard.export.services";
import { AlSidebarComponent } from "../al-sidebar/al-sidebar.component";
import { JobSetupServices } from "../job-setup/al-job-setup-services/job-setup.service";
import "rxjs/Rx";
import "rxjs/add/operator/toPromise";
import { ToastModule, ToastOptions } from "ng2-toastr";
import { AuthConfig, AuthHttp } from "angular2-jwt";
import { TOKEN_NAME } from "../login/login.constant";
import { fakeActivatedRoute } from "../../common-test/common";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { TimerObservable } from "rxjs/observable/TimerObservable";
import { AlHeldFilesService } from "../commons/al-held-files/al-held-files/al-held-files.service";
import { ToolTipUtilService } from "../../services/common/toolTipUtil";
// import { AlPopOverComponent } from "../../sharedModules/al-popover/al-popover";
import { AppUtility } from "../../sharedModules/al-popover/utility";
import { AlPopOverModule } from "../../sharedModules/al-popover/al-popover.module";
import { AccordionModule } from "primeng/components/accordion/accordion";
import { ShowLinkBasedOnEmpAccessDirective } from "../../show-link-based-on-emp-access/show-link-based-on-emp-access.directive";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { HttpResponse, HttpEventType } from "@angular/common/http";

let fakeLogin = "{\"profileName\":\"Shivang Modi\",\"displayName\":\"Shivang\",\"permissions\":[\"Dashboard\",\"ViewFile\",\"ViewErrors\",\"ViewArchieve\",\"ClientContacts\",\"NegateFile\",\"ChangePriority\",\"AddNotes\",\"ViewSchedule\",\"ViewMasterList\",\"ViewMasterTemplate\",\"AddMasterTemplate\",\"EditMasterTemplate\",\"DeleteMasterTemplate\",\"ApproveMasterTemplate\",\"ViewChildList\",\"ViewFileList\",\"ViewFileSetup\",\"AddFileSetup\",\"EditFileSetup\",\"DeleteFileSetup\",\"ApproveFileSetup\",\"ViewJobSchedules\",\"AddJobSchedule\",\"EditJobSchedule\",\"DeleteJobSchedule\",\"ViewTradingPartners\",\"AddTradingPartner\",\"EditTradingPartner\",\"DeleteTradingPartner\",\"ViewLookupTable\",\"AddLookupTable\",\"EditLookupTable\",\"DeleteLookupTable\",\"ViewContacts\",\"AddContact\",\"EditContact\",\"DeleteContact\",\"ViewLOB\",\"AddLOB\",\"EditLOB\",\"DeleteLOB\",\"ViewTemplates\",\"UpdateTemplate\",\"TestNotification\",\"TurnOffNotifications\",\"ViewPromotions\",\"RequestForPromotion\",\"ApprovePromotion\",\"SubmitManually\",\"ReTransmit\",\"FileDetails\",\"ChangeSchedule\",\"ChangeFileOwner\"],\"mail\":\"shivang.modi.2@alight.com\"}";
let ngxPermission;
let _dTable;

describe("Dashboard Component", () => {
    let component: AlDashboardComponent;
    let fixture: ComponentFixture<AlDashboardComponent>;
    let ngxPermission: NgxPermissionsService;
    let dashboardService: AlDashboardService;
    let heldFilesService: AlHeldFilesService;
    let toastService: ToastsManager;

    beforeEach(async(() => {
        TestBed.overrideComponent(AlDashboardComponent, {
            set: {
                providers: [
                    { provide: AlDashboardService, useClass: FakeDashboardService },
                    { provide: JobSetupServices, useClass: FakeDashboardService },
                    { provide: AlHeldFilesService, useClass: FakeAlHeldFilesService }
                ]
            }
        });
        TestBed.configureTestingModule({
            imports: [
                BrowserModule,
                FormsModule,
                ReactiveFormsModule,
                CommonModule,
                TooltipModule,
                DialogModule,
                OverlayPanelModule,
                MultiSelectModule,
                DataTableModule,
                TabViewModule,
                AccordionModule,
                DropdownModule,
                RouterModule,
                RouterTestingModule,
                AutoCompleteModule,
                CalendarModule,
                NgxPermissionsModule,
                ConfirmDialogModule,
                ToastModule.forRoot(),
                NgxPermissionsModule.forRoot(),
                BrowserAnimationsModule,
                TooltipModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [
                AlSidebarComponent,
                AlDashboardComponent,
                // AlPopOverComponent,
                NgxPermissionsAllowStubDirective,
                ShowLinkBasedOnEmpAccessDirective
            ],
            providers: [
                // more providers
                AutoComplete,
                ToastsManager,
                ToastOptions,
                ApiEnvService,
                { provide: ToolTipUtilService, useClass: FakeToolTip },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: ActivatedRoute, useValue: fakeActivatedRoute },
                { provide: ElementRef },
                FileSetupService,
                RescheduleService,
                ExcelService,
                ConfirmationService,
                AppUtility,
                NgxPermissionsService,
                NgxPermissionsStore,
                { provide: AlDashboardService, useClass: FakeDashboardService },
                { provide: JobSetupServices, useClass: FakeDashboardService },
                { provide: AlHeldFilesService, useClass: FakeAlHeldFilesService },
                // { provide: ConfirmationService, useClass: FakeConfirmationservice },
            ]
        }).compileComponents();
    }));
    beforeEach(() => {
        toastService = TestBed.get(ToastsManager);
        spyOn(toastService, "success").and.returnValue(Promise.resolve());
        spyOn(toastService, "error").and.returnValue(Promise.resolve());
        localStorage.setItem("", fakeLogin);
        fixture = TestBed.createComponent(AlDashboardComponent);
        component = fixture.componentInstance;
        ngxPermission = TestBed.get(NgxPermissionsService);
        ngxPermission.addPermission("Dashboard-Dashboard page");
        dashboardService = fixture.debugElement.injector.get(AlDashboardService);
        heldFilesService = fixture.debugElement.injector.get(AlHeldFilesService);
        ngxPermission.addPermission("Dashboard-Dashboard page");
        ngxPermission.addPermission("accessDenied");
        ngxPermission.addPermission("Dashboard-Search Jobs");
        ngxPermission.addPermission("Dashboard-Export Jobs List");
        ngxPermission.addPermission("Dashboard-View file configuration");
        ngxPermission.addPermission("Dashboard-JOB ID");
        ngxPermission.addPermission("Dashboard-Job Status -POPUP");
        ngxPermission.addPermission("FileDetails");
        ngxPermission.addPermission("ViewErrors");
        ngxPermission.addPermission("NegateFile");
        ngxPermission.addPermission("ChangeSchedule");
        ngxPermission.addPermission("Dashboard-Upload Input File");
        ngxPermission.addPermission("Dashboard-Download Error Logs");
        ngxPermission.addPermission("AddNotes");
        ngxPermission.addPermission("Dashboard-Reschedule");
        ngxPermission.addPermission("Dashboard-Download Inbound File");
        ngxPermission.addPermission("Dashboard-Change Priority");
        ngxPermission.addPermission("ChangeSchedule");
        ngxPermission.addPermission("Retransmit");
        ngxPermission.addPermission("ViewArchive");
        ngxPermission.addPermission("SubmitManually");
        ngxPermission.addPermission("EditFileSetup");
        ngxPermission.addPermission("ViewFileSetup");
        ngxPermission.addPermission("ChangePriority");
        ngxPermission.addPermission("ClientContacts");
    });
    afterEach(() => {
        localStorage.removeItem("");
    });
    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should ngOnInit", () => {
        component.ngOnInit();
    });
    it("filterTodayRecords", () => {
        component.dashbrdData = [];
        component.dashbrdData = [
            {
                "fileId": 297,
                "jobId": 1518,
                "employerNames": "GKN",
                "teamName": "CBA Implementation Team",
                "tradingPartner": "Nilkamal_Traders",
                "lob": "LOB 1_updated",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 6,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 5,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1097,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Nilkamal_Traders/LOB 1_updated/297",
                "jobReprioritizationNotes": "",
                "recordId": 900,
                "totalRecordsProcessedAdapt": 6,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 6,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1504,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 10941,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1083,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1506,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 10941,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1085,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1511,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 3,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1090,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            }];
        component.filterTodaysRecords();
    });
    it("should exportAsExcelFile", () => {
        component.exportFilterData = [
            {
                "fileId": 297,
                "jobId": 1518,
                "employerNames": "GKN",
                "teamName": "CBA Implementation Team",
                "tradingPartner": "Nilkamal_Traders",
                "lob": "LOB 1_updated",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 6,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 5,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1097,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Nilkamal_Traders/LOB 1_updated/297",
                "jobReprioritizationNotes": "",
                "recordId": 900,
                "totalRecordsProcessedAdapt": 6,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 6,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1504,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 10941,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1083,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1506,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 10941,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1085,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 301,
                "jobId": 1511,
                "employerNames": "CSC & Affiliates / DXC Technology",
                "teamName": "Cobalt",
                "tradingPartner": "Test TP11",
                "lob": "lob",
                "fileDirection": "Inbound",
                "totalRecordsInFile": 3,
                "jobScheduleDate": 1542652200000,
                "fileVersion": 4,
                "oldFileId": null,
                "jobStatus": "IN_PROGRESS",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1090,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP11/lob/301",
                "jobReprioritizationNotes": "",
                "recordId": 959,
                "totalRecordsProcessedAdapt": 0,
                "totalRecordsProcessedExternal": 0,
                "totalErrorRecords": 0,
                "totalWarningRecords": 0,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "retransmit": false,
                "sentManually": true
            }];
        component.exportAsExcelFile();
    });
    it("should checkStatus", () => {
        component.dashbrdData = [
            {
                "fileId": 13,
                "jobId": 1647,
                "employerNames": "Brady Corporation",
                "teamName": "Blue",
                "tradingPartner": "Test TP1 July02",
                "lob": "Test LOB1 July02_1",
                "fileDirection": "Inbound",
                "totalRecordsInFile": null,
                "jobScheduleDate": 1551765600000,
                "fileVersion": 13,
                "oldFileId": null,
                "jobStatus": "SCHEDULED",
                "fileProcessingPriority": 5,
                "fileProcessingScheduleId": 1213,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Test TP1 July02/null/Test LOB1 July02_1/13",
                "jobReprioritizationNotes": "",
                "recordId": 1784,
                "totalRecordsProcessedAdapt": null,
                "totalRecordsProcessedExternal": null,
                "totalErrorRecords": null,
                "totalWarningRecords": null,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "jobQueue": "NA",
                "fileStateId": null,
                "fileName": null,
                "slaMapped": "No",
                "jobActualStartDateTime": null,
                "jobCompletionDateTime": null,
                "actualRunTime": 0,
                "retransmit": false,
                "sentManually": true
            },
            {
                "fileId": 728,
                "jobId": 2892,
                "employerNames": "Brady Corporation",
                "teamName": "ACA ER Reporting",
                "tradingPartner": "Brady Corp._Brad Corp.",
                "lob": "Employer Interface Files1",
                "fileDirection": "Inbound",
                "totalRecordsInFile": null,
                "jobScheduleDate": 1551679200000,
                "fileVersion": 3,
                "oldFileId": 61245,
                "jobStatus": "SCHEDULED",
                "fileProcessingPriority": null,
                "fileProcessingScheduleId": 2236,
                "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//Brady Corp./null/Employer Interface Files1/728",
                "jobReprioritizationNotes": "",
                "recordId": 1728,
                "totalRecordsProcessedAdapt": null,
                "totalRecordsProcessedExternal": null,
                "totalErrorRecords": null,
                "totalWarningRecords": null,
                "totalIgnoreRecords": 0,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": 0,
                "fileStatus": "Active",
                "jobQueue": "NA",
                "fileStateId": null,
                "fileName": null,
                "slaMapped": "No",
                "jobActualStartDateTime": null,
                "jobCompletionDateTime": null,
                "actualRunTime": 0,
                "retransmit": false,
                "sentManually": true
            }
        ];
        let dbLiveData = {
            "1647": {
                "fileStateId": null,
                "jobStatus": "SCHEDULED",
                "totalRecordsInFile": null,
                "totalRecordsProcessedAdapt": null,
                "totalRecordsProcessedExternal": null,
                "totalErrorRecords": null,
                "totalWarningRecords": null,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": null,
                "totalIgnoreRecords": null,
                "fileName": null
            },
            "2892": {
                "fileStateId": null,
                "jobStatus": "SCHEDULED",
                "totalRecordsInFile": null,
                "totalRecordsProcessedAdapt": null,
                "totalRecordsProcessedExternal": null,
                "totalErrorRecords": null,
                "totalWarningRecords": null,
                "jobStatusDetails": null,
                "totalErrorRecordsExternal": null,
                "totalIgnoreRecords": null,
                "fileName": null
            }
        };
        component.checkStatus(dbLiveData);
    });
    it("should singleJobRescUpdate()", () => {
        component.singleJobRescUpdate();
        component.table = component.dashBoardTable;
        _dTable = component.dashBoardTable;
    });
    it("should getInitialTd()", () => {
        component.getInitialTd(1561628356252);
    });



    it("should on uploadKeyFile", () => {
        let e = {
            preventDefault: () => {

            },
            target: {
                files: [{ name: "test.text" }, { name: "test21.png" }]
            }
        };
        component.uploadFile(e);
    });
    it("should on uploadKeyFile", () => {
        let e = {
            preventDefault: () => {

            },
            target: {
                files: []
            }
        };
        component.getFile(e);
    });
    it("Should showDashboardAction method", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        let rowData = {};
        let selRowIndex = 0;
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.showDashboardAction(event, rowData, overlayPanel);
        });
        btnNextStep.click();

    });
    it("Should showClientContactModel method", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        let rowData = {};
        let selRowIndex = 0;
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.showClientContactModel(overlayPanel);
        });
        btnNextStep.click();
    });
    it("Should showClientContactModel method error", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        let rowData = {};
        let selRowIndex = 0;
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        spyOn(dashboardService, "getClientContact").and.returnValue(Observable.throw("No Data"));
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.showClientContactModel(overlayPanel);
        });
        btnNextStep.click();
    });
    it("showRetransmitModel fn", () => {
        let form = <NgForm>{
            resetForm: function () { }
        };
        component.showRetransmitModel(form);
    });
    it("addRetransmitNote fn", () => {
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                notes: "test Some"
            }
        };
        component.addRetransmitNote(form);
        spyOn(dashboardService, "retransmitFile").and.returnValue(Observable.throw("No Data"));
        component.addRetransmitNote(form);
    });
    it("addSentManually fn", () => {
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                notes: "test Some"
            }
        };
        component.addSentManually(form);
    });
    it("getBlackoutWindowStatus fn error response", () => {
        spyOn(dashboardService, "getBlackoutWindowStatus").and.returnValue(Observable.throw("No Data"));
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                notes: "test Some"
            }
        };
        component.getBlackoutWindowStatus();
    });
    it("should goReschPage ele showFileDetailsModel method", () => {
        component.goReschPage();
        component.reschRadio = ["1", "2", "3"];
        component.goReschPage();
        component.reschRadio = ["2", "3"];
        component.goReschPage();
        component.showFileDetailsModel();
        spyOn(dashboardService, "getFileSetupByFileId").and.returnValue(Observable.throw("No Data"));
        component.showFileDetailsModel();
    });
    it("should showJobScheduleList", () => {
        let navigateSpy = spyOn((<any>component).router, "navigate");
        component.showJobScheduleList();
        component.currentRowData.fileId = undefined;
        expect(navigateSpy).toHaveBeenCalledWith(["/view-all-schedules", component.currentRowData.fileId]);
    });
    it("Should populateEmployerName showFPRDialog method showUploadFileModel", () => {
        component.populateEmployerName();
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        let rowData = {};
        component.goToJobSchedule(rowData);
        rowData["fileDirection"] = "Outbound";
        component.showFPRDialog(e, rowData);
        let jobid = "824";
        component.showUploadFileModel(jobid, overlayPanel);
    });
    it("saveFile fn", () => {
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                notes: "test Some"
            }
        };
        component.saveFile(form);
        let spyOnSaveFile = spyOn(dashboardService, "saveFile").and.returnValue(Observable.throw("No Data"));
        component.saveFile(form);
        let opts = { status: 500, body: {
            "error": true,
            "message": "FILE_TRANSMISSION_NAME_MISMATCH"
        }, headers: null, url: null, merge: null };
        let httpResponse = new HttpResponse(opts);
        spyOnSaveFile.and.returnValue(Observable.throw(httpResponse));
        component.saveFile(form);
    });
    it("cancelFileUpload fn if", () => {
        let form = <NgForm>{
            resetForm: function () { },
        };
        component.uploadFileNameModel = { "test": "test" };
        component.cancelFileUpload(form);
    });
    it("Should downloadErrorsLogs method", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        let rowData = {};
        let selRowIndex = 0;
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.downloadErrorsLogs(overlayPanel);
        });
        btnNextStep.click();
    });
    it("Should onFilter method", () => {
        const e = {
            filteredValue: ["1", "2"]
        };
        component.onFilter(e);
    });
    // it("Should removeJob method", () => {
    //     const e = {
    //         filteredValue: "check"
    //     };
    //     let table = {
    //         reset: () => {
    //         },
    //     }
    //     component.removeJob();
    // });
    it("should and displayToolTipText()", () => {
        component.dashBoardToolTip = {
            "File status": {
                "tooltipDesc": "File status description",
                "readMoreLink": "http://www.google.com"
            }
        };
        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "File status", "bottom");
            component.hideToolTipText(event);
            component.hideToolTipText(event);
        });
        btnNextStep.click();
        component.resetToolTipData(event);
    });
    it("Should downloadErrorsLogs method", () => {
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.downloadErrorsLogs(overlayPanel);
        });
        btnNextStep.click();
    });
    it("Should hideToolTipText method", () => {
        const e = {
            filteredValue: "check"
        };
        component.hideToolTipText(e);
    });
    it("Should onClickRemoveJob method", () => {
        let overlayPanel = {
            toggle: (e) => { },
            hide: (el) => { }
        };
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.onClickRemoveJob(overlayPanel);
        });
        btnNextStep.click();
    });
    it("Should downloadErrorsLogs method", () => {
        component.cancelJobRemove();
    });
    it("showReprioritizeModel fn if", () => {
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                notes: "test Some"
            }
        };
        component.showReprioritizeModel(form);
    });
    it("addReprioritizeNote fn if", () => {
        let form = <NgForm>{
            resetForm: function () { },
            value: {
                "priority": "test Some",
                "notes": "notes"
            }
        };
        component.addReprioritizeNote(form);
    });
    it("Should downloadInboundFile()", () => {
        let overlaypanel = {
            toggle: (e) => {
            },
            hide: () => {
            }
        };
        component.downloadInboundFile(overlaypanel);
    });

    it("Should downloadOutboundFile method", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };
        spyOn(heldFilesService, "downloadOutboundFile").and.returnValue(Observable.throw("No Data"));
        component.downloadOutboundFile(overlayPanel);
    });

    it("showJobDetails ", () => {
        let rowData = {
            fileProcessingStartDate: 1542652200000,
            fileProcessingEndDate: 1542652200000
        };
        component.showJobDetails(rowData);
    });

    it("getSelected() ", () => {
        let rowData = {
            jobStatus: "ROLLBACK_INITIATED"
        };
        component.getSelected(rowData);
    });
    it("addRollbackNote() ", () => {
        let rollbackForm = <NgForm>{
            "value": {
                "notes": "abc",
            },
            resetForm: () => null
        };
        component.currentRowData = {
            "fileId": 123,
            "fileVersion": 1,
            "jobId": 456
        };
        component.addRollbackNote(rollbackForm);
        component.showRollbackModel(rollbackForm);
    });
    it("reTransmitFile() ", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: (el) => {

            }
        };

        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.reTransmitFile(overlayPanel);
        });
        btnNextStep.click();
    });



});

export class FakeAlHeldFilesService {
    downloadInboundFile(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    downloadOutboundFile(sendData): Observable<any> {
        let response = require("../../../assets/test-data/blank.json");
        return Observable.of(response);
    }
}
export class FakeConfirmationservice {
    accept() {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
export class FakeDashboardService {
    public fileName: string;
    getDashboadData(fromDt, toDt, fileStatus, filterFileId): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-details.json");
        return Observable.of(response);
    }

    getJobScheduleStatus(jobIds): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-job-status.json");
        return Observable.of(response);
    }

    // Get list of Inactive Blackout Window Record
    getBlackoutWindowStatus(): Observable<any> {
        let response = require("../../../assets/test-data/blackout-message-notification.json");
        return Observable.of(response);
    }

    getClientContact(fileId): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    updateOnlyJobSchedule(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    retransmitFile(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    getFileSetupByFileId(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    saveFile(sendData, id): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    removeJob(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    downloadErrorsLogs(sendData): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-client-contact-list.json");
        return Observable.of(response);
    }
    getJobAssociatedWithTransmission(sendData): Observable<any> {
        let response = require("../../../assets/test-data/blank.json");
        return Observable.of(response);
    }
    rollbackFile(sendData): Observable<any> {
        let response = require("../../../assets/test-data/blank.json");
        return Observable.of(response);
    }
    reTransmitFile() {
        let response = require("../../../assets/test-data/dashboard-re-transmission.json");
        return Observable.of(response);
    }

    getFileExtractionData(recordId, profileId): Observable<any> {
        let response = require("../../../assets/test-data/dashboard-fileProgressReport.json");
        return Observable.of(response);
    }
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}