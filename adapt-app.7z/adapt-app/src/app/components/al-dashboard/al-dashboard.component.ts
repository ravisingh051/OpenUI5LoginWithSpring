import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { DatePipe } from "@angular/common";
import { CalendarModule } from "primeng/components/calendar/calendar";
import { TabViewModule } from "primeng/components/tabview/tabview";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { MultiSelectModule } from "primeng/components/multiselect/multiselect";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { TooltipModule } from "primeng/components/tooltip/tooltip";
import { AlDashboardService } from "../al-dashboard/al-dashboard.services";
import { AppConfig, dashboardConfig } from "../../app.config";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { NgForm } from "@angular/forms";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { RescheduleService } from "../../services/common/reschedule";
import { Router, ActivatedRoute } from "@angular/router";
import { CURRENT_USER } from "../login/login.constant";
import { FileSetupService } from "../file-setup/al-file-setup-services/file-setup.service";
import { ExcelService } from "../al-dashboard/al-dashboard-export-services/al-dashboard.export.services";
import { ToolTipUtilService } from "../../services/common/toolTipUtil";
import "rxjs/Rx";
import { JobSetupServices } from "../job-setup/al-job-setup-services/job-setup.service";
import { AlHeldFilesService } from "../commons/al-held-files/al-held-files/al-held-files.service";
import { Subscription } from "rxjs/Subscription";
import { TOAST_SETTING } from "../../global";
import * as moment from "moment-timezone";


@Component({
  selector: "app-al-dashboard",
  templateUrl: "./al-dashboard.component.html",
  styleUrls: ["./al-dashboard.component.scss"],
  providers: [AlDashboardService, ConfirmationService, FileSetupService, ExcelService, JobSetupServices, AlHeldFilesService]
})
export class AlDashboardComponent implements OnInit, OnDestroy {


  blackoutWinStatus: boolean = false;
  blackoutWinData: any = [];
  appConfig = AppConfig;
  dashboardConfig = dashboardConfig;
  mydata: any = [];
  title = "app";
  dashbrdData: any;
  clientContactData: any;
  dataLoader: boolean;
  clientContactModel: boolean;
  retransmitModel: boolean;
  rollbackModel: boolean;
  currentRowData: any = {};
  currentTradingPartner: any;
  retransmitNoteData: any = {};
  retransmit: boolean;
  setManuallyModel: boolean;
  hasRetransmitPermission: boolean = false;
  hasSubmitManuallyPermission: boolean = false;
  hasEditFileSetUpPermission: boolean = false;
  hasViewFileSetUpPermission: boolean = false;

  //  Reschedule
  rscId: number;
  fileVersion: number;
  fileScId: number;
  rescheduleDialog: boolean;
  reschRadio: any[];
  rescValid: boolean;
  jobScheduleDate: Date;
  jobId: null;

  //  Dashboard Filter
  filterFD: Date = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY HH:mm:ss"));
  filterTD: Date = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY HH:mm:ss"));
  fltDatMsg: boolean;
  fltDatMsgStr: string;
  minDateStartDate: Date;
  //  Filter Dropdowns
  @ViewChild("dbFileProgress") dashBoardTable: DataTable;
  filterData: any = [];
  advanceFilter: boolean = true;
  selePriority: any;
  filterSts: any = [
    { label: "All", value: null },
    { label: "Failed", value: "FAILED" },
    { label: "In Progress", value: "IN_PROGRESS" },
    { label: "Completed", value: "COMPLETED" },
    { label: "Not Started", value: "SCHEDULED" },
    { label: "Rollback Initiated", value: "ROLLBACK_INITIATED" },
    { label: "Rolled Back", value: "ROLLED_BACK" },
    { label: "Rollback Failed", value: "ROLLBACK_FAILED" },
    { label: "Transmission Failed", value: "TRANSMISSION_FAILED" },
    { label: "Transmission Successful", value: "TRANSMISSION_SUCCESSFUL" },
  ];
  filterIdisId: any;
  filterJobId: any;
  filterEmp: any;
  filterTeam: any;
  filterTp: any;
  filterLob: any;
  filterAnalyst: any;
  filterDir: any;
  filterLstDat: any;
  fStsModel; fIdisIdModel; fJobIdModel; fEmpModel; fTeamModel; fTpModel; fLobModel; fAnalystModel; fDirModel; fLstDatModel;

  //  Get Status of JobSchedule for every record
  getDashboardRecords: any;
  getRecordStatus: any;
  private subscription: Subscription = new Subscription();
  getStatusOfRecoreds: any = [];
  exportData: any = [];
  exportFilterData: any = [];
  count: any;
  /* ToolTip display OnMouse Over */
  dashBoardToolTip: any = [];
  tooltipResult: any;
  pageID: number = 23;

  showJobRemoveDialogue: boolean = false;
  isClickedOnJobRemove: boolean = false;
  jobRemoveNotes: string;
  isJobRemoving: boolean = false;
  getDashboardDataSubscription: Subscription;

  @ViewChild("dbFileProgress") table: DataTable;

  reprioritizeModel: boolean = false;
  reprioritizeForm: any = {};
  reprioritizeNotes;
  priorityList = ["Send to Top", "Send to Bottom"];
  explicitHighPprioritization = false;
  explicitLowPrioritization = false;

  clientId: Array<string>;
  isFileUploaded: boolean = false;
  isFileInbound: boolean = false;

  selectedRowData: any;
  jobDetailsModel: boolean = false;

  fileProcessingStartDate: any;
  fileProcessingEndDate: any;
  centralTimeZone: string = " CT";
  jobRunDate: any;
  filterFileId: number;

  constructor(
    private dashboardService: AlDashboardService,
    public toastr: ToastsManager,
    private confirmationService: ConfirmationService,
    private permissionsService: NgxPermissionsService,
    private RescheduleService: RescheduleService,
    private router: Router,
    private route: ActivatedRoute,
    private fileSetupService: FileSetupService,
    private excelService: ExcelService,
    private toolTipUtils: ToolTipUtilService,
    private jobSetupService: JobSetupServices,
    private heldFilesService: AlHeldFilesService
  ) {
    this.dataLoader = true;
  }
  ngOnInit() {
    let currentUser = JSON.parse(localStorage.getItem(CURRENT_USER));

    localStorage.setItem(CURRENT_USER, JSON.stringify(currentUser));
    let employees = [];
    currentUser = { profileName: currentUser.profileName, displayName: currentUser.displayName, permissions: currentUser.permissions, employeeList: employees };

    this.minDateStartDate = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY HH:mm:ss"));
    /* this.filterFD = this.getInitialTd(this.filterTD); */
    Promise.all([this.permissionsService.hasPermission("Dashboard-Retransmitt")])
      .then(([permission]) => {
        this.hasRetransmitPermission = permission;
      }).catch(/* istanbul ignore next */() => {
        this.hasRetransmitPermission = false;
      });
    Promise.all([this.permissionsService.hasPermission("SubmitManually")])
      .then(([permission]) => {
        this.hasSubmitManuallyPermission = permission;
      }).catch(/* istanbul ignore next */() => {
        this.hasSubmitManuallyPermission = false;
      });

    Promise.all([this.permissionsService.hasPermission("File Setup-Edit File")])
      .then(([permission]) => {
        this.hasEditFileSetUpPermission = permission;
      }).catch(/* istanbul ignore next */() => {
        this.hasEditFileSetUpPermission = false;
      });
    Promise.all([this.permissionsService.hasPermission("File Setup-View All File list")])
      .then(([permission]) => {
        this.hasViewFileSetUpPermission = permission;
      }).catch(/* istanbul ignore next */() => {
        this.hasViewFileSetUpPermission = false;
      });

    this.getBlackoutWindowStatus();
    this.getDashboardData();
    this.getToolTipTextDetails();

    /**
     * To refresh table data on every 5 minute.
     */
    this.getDashboardDataSubscription = Observable.interval(this.dashboardConfig.recordInterval$ * 60).subscribe(x => {
      this.getDashboardData();
    });
  }

  getDashboardData() {
    this.dashboardService.getDashboadData(this.formatDate(this.filterFD), this.formatDate(this.filterTD), this.fileStatus, this.filterFileId).subscribe(res => {
      this.dashbrdData = res.data;
      this.populateFilterDropDown();
      this.dataLoader = false;
      this.filterTodaysRecords();
      this.count = this.dashbrdData.length;
      this.exportFilterData = this.dashbrdData;
    });
  }

  filterTodaysRecords() {
    this.getStatusOfRecoreds = [];
    for (let dbData$ of this.dashbrdData) {
      if (dbData$.jobStatus === "SCHEDULED" || dbData$.jobStatus === "IN_PROGRESS") {
        this.getStatusOfRecoreds.push(dbData$.jobId);
      }
    }
    if (this.getStatusOfRecoreds.length > 0) {
      this.getRecordStatus = Observable.interval(this.dashboardConfig.recordInterval$ * 24).subscribe(/* istanbul ignore next */dbLiveData$ => {
        this.dashboardService.getJobScheduleStatus(this.getStatusOfRecoreds).subscribe(jobSchRes => {
          this.checkStatus(jobSchRes.data);
        });
      });
      this.subscription.add(this.getRecordStatus);
    }
    else {
      if (this.getRecordStatus !== undefined) {
        this.getRecordStatus.unsubscribe();
      }
    }
  }

  formatRunDate(inputFormat) {
    let date;
    let d = new Date(inputFormat);
    date = [this.pad(d.getMonth() + 1), this.pad(d.getDate()), d.getFullYear()].join("/");
    return date;
  }

  EXCEL_EXTENSION = ".xlsx";

  exportAsExcelFile() {
    this.exportData = [];
    if (this.exportFilterData != null && this.exportFilterData.length > 0) {
      let d = new Date();
      let date = [this.pad(d.getMonth() + 1), this.pad(d.getDate())].join("");
      let year = d.getFullYear().toString().substr(-2);
      let fileName = "ADaPT-Dashboard-" + date + year + "-" + d.getTime() + this.EXCEL_EXTENSION;
      for (let job of this.exportFilterData) {
        let runDate = this.formatRunDate(job.jobScheduleDate);
        let jobData = {
          "File ID": job.fileId,
          "Job Id": job.jobId,
          "Status": job.jobStatus,
          "Run Date": runDate + this.centralTimeZone,
          "Employer Name": job.employerNames,
          "Interface Group": job.teamName,
          "Trading Partner": job.tradingPartner,
          "LOB": job.lob,
          "File Type": job.fileDirection,
          "File Status": job.fileStatus,
          "File Subject to SLA": job.slaMapped,
          "Actual Start Time": job.jobActualStartDateTime ? job.jobActualStartDateTime : "Unavailable",
          "Actual End Time": job.jobCompletionDateTime ? job.jobCompletionDateTime : "Unavailable",
          "Actual File Run Time": job.actualRunTime,
          "File Analyst": job.analystName,
          "Job Scheduled By": job.jobCreatedBy,
          "Job Scheduled On": this.formatRunDate(job.jobCreationDateTime) + this.centralTimeZone,
          "Profile": job.profileName,
          "Recurrence": job.recurrenceType,
          "File Version": job.fileVersion,
          "Full/Changes File": job.fileDataExtractionMode,
          "Schedule Start Date": this.formatRunDate(job.fileProcessingStartDate) + this.centralTimeZone,
          "Schedule End Date": this.formatRunDate(job.fileProcessingEndDate) + this.centralTimeZone,
          "Processing Mode": job.fileProcessingMode,
          "TestCfg": job.testCfg
        };
        this.exportData.push(jobData);
      }
      this.excelService.exportAsExcelFile(this.exportData, fileName);
    }
  }
  btnClicked: boolean = false;
  /* istanbul ignore next */
  filterDashboard(table: DataTable) {
    this.btnClicked = true;
    if (this.getRecordStatus !== undefined) {
      this.getRecordStatus.unsubscribe();
    }
    if (this.filterFD !== undefined && this.filterTD !== undefined) {
      let _fd = this.filterFD.getTime();
      let _td = this.filterTD.getTime();
      if (_fd <= _td) {
        this.fltDatMsg = false;
        this.dashboardService.getDashboadData(this.formatDate(this.filterFD), this.formatDate(this.filterTD), this.fileStatus, this.filterFileId).subscribe(res => {
          if (!res.error) {
            this.dashbrdData = res.data;
            this.filterTodaysRecords();
            this.filterOnOff(table);
            this.populateFilterDropDown();
            this.count = this.dashbrdData.length;
            this.exportFilterData = this.dashbrdData;
            this.btnClicked = false;
          } /*istanbul ignore next*/  else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        }, /*istanbul ignore next*/ error => {
          this.toastr.error("Server Error Getting Dashboard Data.", "Oops!", TOAST_SETTING);
        });
      }
      else {
        this.fltDatMsgStr = "From Date required less than To Date";
        this.fltDatMsg = true;
        this.btnClicked = false;
      }
    }
    else {
      this.fltDatMsgStr = "Please select From Date and To Date";
      this.fltDatMsg = true;
    }

  }

  getInitialTd(_d) {
    let _date = new Date(_d);
    let tzOff = _date.getTimezoneOffset() * 60 * 1000,
      t = _date.getTime(),
      d = new Date(),
      tzOff2;
    t += (1000 * 60 * 60 * 24) * -6;
    d.setTime(t);
    d.setHours(0, 0, 0, 0);
    tzOff2 = d.getTimezoneOffset() * 60 * 1000;
    if (tzOff !== tzOff2) {
      let diff = tzOff2 - tzOff;
      t += diff;
      d.setTime(t);
      d.setHours(0, 0, 0, 0);
    }
    return d;
  }
  getBlackoutWindowStatus() {
    this.dashboardService.getBlackoutWindowStatus().subscribe(res => {
      if (!res.error) {
        this.blackoutWinStatus = true;
        this.blackoutWinData = res.data;
      } /*istanbul ignore next*/ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /*istanbul ignore next*/ error => {
      this.toastr.error("Server Error in fetching active Blackout Window(s).", "Oops!", TOAST_SETTING);
    });
  }

  checkStatus(dbLiveData) {
    for (let i = 0; i < this.dashbrdData.length; i++) {
      if (dbLiveData[this.dashbrdData[i].jobId] !== undefined) {
        this.dashbrdData[i]["jobStatus"] = dbLiveData[this.dashbrdData[i].jobId].jobStatus;
        this.dashbrdData[i]["totalRecordsInFile"] = dbLiveData[this.dashbrdData[i].jobId].totalRecordsInFile;
        this.dashbrdData[i]["totalRecordsProcessedAdapt"] = dbLiveData[this.dashbrdData[i].jobId].totalRecordsProcessedAdapt;
        this.dashbrdData[i]["totalRecordsProcessedExternal"] = dbLiveData[this.dashbrdData[i].jobId].totalRecordsProcessedExternal;
        this.dashbrdData[i]["totalErrorRecords"] = dbLiveData[this.dashbrdData[i].jobId].totalErrorRecords;
        this.dashbrdData[i]["totalWarningRecords"] = dbLiveData[this.dashbrdData[i].jobId].totalWarningRecords;
        this.dashbrdData[i]["totalIgnoreRecords"] = dbLiveData[this.dashbrdData[i].jobId].totalIgnoreRecords == null ? 0 : dbLiveData[this.dashbrdData[i].jobId].totalIgnoreRecords;
        this.dashbrdData[i]["jobStatusDetails"] = dbLiveData[this.dashbrdData[i].jobId].jobStatusDetails;

      }
    }
    let _getStatusOfRecoreds = [];
    for (let j = 0; j < this.getStatusOfRecoreds.length; j++) {
      if (dbLiveData[this.getStatusOfRecoreds[j]] !== undefined && dbLiveData[this.getStatusOfRecoreds[j]].jobStatus !== undefined && dbLiveData[this.getStatusOfRecoreds[j]].jobStatus !== "COMPLETED" && dbLiveData[this.getStatusOfRecoreds[j]].jobStatus !== "COMPLETED (during blackout period)") {
        _getStatusOfRecoreds.push(this.getStatusOfRecoreds[j]);
      }
    }
    this.getStatusOfRecoreds = _getStatusOfRecoreds;
    if (this.getStatusOfRecoreds.length === 0) {
      if (this.getRecordStatus !== undefined) {
        this.getRecordStatus.unsubscribe();
      }
    }



    /*----------------------------------------------------------------------------------------------------
    ###############  DO NOT REMOVE THIS CODE  #######################
    This code is required once backend will ready for display status progress for job schedule
    This code block will be reuiqred for future story.
    ------------------------------------------------------------------------------------------------------

    if (this.dashbrdData !== undefined) {
      for (let i = 0; i < this.dashbrdData.length; i++) {
        let jobId = this.dashbrdData[i].jobId;
        if (dbLiveData[jobId] !== undefined) {
          this.dashbrdData[i]['status'] = dbLiveData[jobId];
          let progress = '0%';
          let _jobStatus = this.dashbrdData[i].jobStatus.toLowerCase();
		      let _conditions = ["error", "failed", "errors"];
          let checkStatus = _conditions.some(el => _jobStatus.includes(el));
          if(checkStatus == true){
            this.dashbrdData[i]['status'].progress = "0%";
            this.dashbrdData[i]['status'].statusResult = 'completed';
            this.dashbrdData[i]['status'].isError = true;
            this.dashbrdData[i]['status'].statusCode = 1;
          }
          else {
          if (dbLiveData[jobId].totalRecords != null && dbLiveData[jobId].totalRecords !== 0 && this.dashbrdData[i].totalRecords == null) {
            this.dashbrdData[i].totalRecords = dbLiveData[jobId].totalRecords;
          }

            if (this.dashbrdData[i].totalRecords != null && this.dashbrdData[i].totalRecords !== 0) {
              progress = Math.round(((dbLiveData[jobId].processRecords + dbLiveData[jobId].errorRecords) * 100) / this.dashbrdData[i].totalRecords) + '%';
            }
            let statusResult = progress == '100%' ? 'completed' : 'inprogress';
            let isError = false;
            if (dbLiveData[jobId].errorRecords > 0 && progress == '100%') {
              isError = true;
            }
            if(progress == "0%"){
              statusResult = "notStarted"
            }
            this.dashbrdData[i]['status'].progress = progress;
            this.dashbrdData[i]['status'].statusResult = statusResult;
            this.dashbrdData[i]['status'].isError = isError;
            this.dashbrdData[i]['status'].statusCode = 4;
            if(statusResult ==  "inprogress"){
              this.dashbrdData[i]['status'].statusCode = 2;
            }
            if(statusResult ==  "completed"){
              this.dashbrdData[i]['status'].statusCode = 3;
            }
            if(statusResult ==  "notStarted"){
              this.dashbrdData[i]['status'].statusCode = 4;
            }
            if(statusResult ==  "completed" && dbLiveData[jobId].errorRecords !== 0){
              this.dashbrdData[i]['status'].statusCode = 1;
            }
          }
        }
      }
    }
    */
  }

  showDashboardAction(event, rowData, overlaypanel) {
    this.retransmit = rowData.retransmit;
    this.currentRowData = rowData;
    this.currentTradingPartner = rowData.tradingPartner;
    this.rescValid = false;
    this.reschRadio = undefined;
    this.rscId = rowData.fileId;
    this.fileVersion = rowData.fileVersion;
    this.fileScId = rowData.fileProcessingScheduleId;
    this.jobScheduleDate = rowData.jobScheduleDate;
    this.jobId = rowData.jobId;
    this.clientId = [rowData.clientId];
    this.isFileUploaded = rowData.externalFileUploaded;
    this.isFileInbound = rowData.fileDirection;
    overlaypanel.toggle(event);
  }
  /* istanbul ignore next */
  reschedulePopup(overlaypanel: OverlayPanel, table: DataTable) {
    overlaypanel.hide();
    this.rescheduleDialog = true;
  }

  showClientContactModel(overlaypanel) {
    overlaypanel.hide();
    if (this.currentRowData !== undefined) {
      this.dashboardService.getClientContact(this.currentRowData.fileId).subscribe(res => {
        if (!res.error) {
          if (res.data !== null) {
            this.clientContactData = res.data;
            this.clientContactModel = true;
          }
        } /*istanbul ignore next*/ else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, /*istanbul ignore next*/ error => {
        this.toastr.error("Server Error in Getting Client Contact List.", "Oops!", TOAST_SETTING);
      });
    }
  }

  showRetransmitModel(retransmitForm: NgForm) {
    retransmitForm.resetForm();
    this.retransmitModel = true;
  }

  showRollbackModel(rollbackForm: NgForm) {
    rollbackForm.resetForm();
    this.rollbackModel = true;
  }

  addRetransmitNote(retransmitForm: NgForm) {
    let sendData = {
      "fileId": this.currentRowData.fileId,
      "fileVersion": this.currentRowData.fileVersion,
      "notes": retransmitForm.value.notes,
      "jobId": this.currentRowData.jobId
    };

    this.dashboardService.retransmitFile(sendData).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Retransmit File Process Started Successfully", "Success!");
      } /*istanbul ignore next*/ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /*istanbul ignore next*/ error => {
      this.toastr.error("Server Error in Retransmit File Process.", "Oops!", TOAST_SETTING);
    });
    this.retransmitModel = false;
  }

  addRollbackNote(rollbackForm: NgForm) {
    let sendData = {
      "fileId": this.currentRowData.fileId,
      "fileVersion": this.currentRowData.fileVersion,
      "notes": rollbackForm.value.notes,
      "jobId": this.currentRowData.jobId
    };

    this.dashboardService.rollbackFile(sendData).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Rollback Started Successfully", "Success!");
      } /*istanbul ignore next*/ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /*istanbul ignore next*/ error => {
      this.toastr.error("Server Error in Rollback Process.", "Oops!", TOAST_SETTING);
    });
    this.rollbackModel = false;
    rollbackForm.reset;
  }

  addSentManually(sentManuallyForm: NgForm) {
    this.setManuallyModel = false;
    this.confirmationService.confirm({
      message: "Are You Sure to Update Job Status to Manual Send?",
      accept: /*istanbul ignore next*/() => {
        let sendData = {
          "jobId": this.currentRowData.jobId,
          "notes": sentManuallyForm.value.notes
        };
        this.dashboardService.sentManually(sendData).subscribe(res => {
          if (!res.error) {
            this.toastr.success("Job Status Updated Successfully", "Success!");
            this.currentRowData.jobStatus = res.jobStatus;
            this.currentRowData.sentManually = false;
          } /*istanbul ignore next*/ else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        }, /*istanbul ignore next*/ error => {
          this.toastr.error("Server Error in updating Job Status.", "Oops!", TOAST_SETTING);
        });
      }, reject: () => {
        this.setManuallyModel = true;
      }
    });
  }

  singleJobReschedule: boolean;
  goReschPage() {
    if (this.reschRadio === undefined) {
      this.rescValid = true;
      return false;
    }
    let _jobId;
    if (this.reschRadio[0] === "1") {
      this.rescheduleDialog = false;
      this.singleJobReschedule = true;
      this.singleJobRescDate = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY HH:mm:ss"));
      this.singleJobRescError = false;
      return false;
    }
    else {
      _jobId = null;
    }
    let obj = [
      this.rscId, this.fileVersion, this.fileScId, _jobId, "/dashboard", this.jobScheduleDate
    ];
    this.RescheduleService.changeFileId(obj);
    this.rescheduleDialog = false;
    this.router.navigate(["/edit-job-schedule"]);
  }
  populateFilterDropDown() {
    this.filterIdisId = [{ label: "All", value: null }];
    this.filterJobId = [{ label: "All", value: null }];
    this.filterEmp = [{ label: "All", value: null }];
    this.filterTeam = [{ label: "All", value: null }];
    this.filterTp = [{ label: "All", value: null }];
    this.filterLob = [{ label: "All", value: null }];
    this.filterAnalyst = [{ label: "All", value: null }];
    this.filterDir = [{ label: "All", value: null }];
    this.filterLstDat = [{ label: "All", value: null }];
    let _filterIdisId: any = [];
    let _filterJobId: any = [];
    let _filterEmp: any = [];
    let _filterTeam: any = [];
    let _filterTp: any = [];
    let _filterLob: any = [];
    let _filterAnalyst: any = [];
    let _filterDir: any = [];
    let _filterLstDat = [];
    if (this.dashbrdData !== null) {
      for (let i = 0; i < this.dashbrdData.length; i++) {

        if (_filterIdisId.indexOf(this.dashbrdData[i].fileId) === -1) {
          _filterIdisId.push(this.dashbrdData[i].fileId);
        }
        if (_filterJobId.indexOf(this.dashbrdData[i].jobId) === -1) {
          _filterJobId.push(this.dashbrdData[i].jobId);
        }
        if (_filterEmp.indexOf(this.dashbrdData[i].employerNames) === -1) {
          _filterEmp.push(this.dashbrdData[i].employerNames);
        }
        if (_filterTeam.indexOf(this.dashbrdData[i].teamName) === -1) {
          _filterTeam.push(this.dashbrdData[i].teamName);
        }
        if (_filterTp.indexOf(this.dashbrdData[i].tradingPartner) === -1) {
          _filterTp.push(this.dashbrdData[i].tradingPartner);
        }
        if (_filterLob.indexOf(this.dashbrdData[i].lob) === -1) {
          _filterLob.push(this.dashbrdData[i].lob);
        }
        if (_filterAnalyst.indexOf(this.dashbrdData[i].analystName) === -1) {
          _filterAnalyst.push(this.dashbrdData[i].analystName);
        }
        if (_filterLstDat.indexOf(this.dashbrdData[i].jobScheduleDate) === -1) {
          _filterLstDat.push(this.dashbrdData[i].jobScheduleDate);
        }
      };
    }
    for (let value of _filterIdisId) {
      this.filterIdisId.push({ label: value, value: value });
    }
    for (let value of _filterJobId) {
      this.filterJobId.push({ label: value, value: value });
    }
    for (let value of _filterEmp) {
      this.filterEmp.push({ label: value, value: value });
    }
    for (let value of _filterTeam) {
      this.filterTeam.push({ label: value, value: value });
    }
    for (let value of _filterTp) {
      this.filterTp.push({ label: value, value: value });
    }
    for (let value of _filterLob) {
      this.filterLob.push({ label: value, value: value });
    }
    for (let value of _filterAnalyst) {
      this.filterAnalyst.push({ label: value, value: value });
    }
    for (let value of _filterDir) {
      this.filterDir.push({ label: value, value: value });
    }
    for (let value of _filterLstDat) {
      let dateLabel = this.convertDDMMYY(value);
      this.filterLstDat.push({ label: dateLabel, value: value });
    }
  }

  /* istanbul ignore next */
  filterOnOff(table: DataTable) {
    table.reset();
    this.fStsModel = null;
    this.fIdisIdModel = null;
    this.fJobIdModel = null;
    this.fEmpModel = null;
    this.fTeamModel = null;
    this.fTpModel = null;
    this.fLobModel = null;
    this.fAnalystModel = null;
    this.fDirModel = null;
    this.fLstDatModel = null;
    //  this.advanceFilter = !this.advanceFilter;
  }

  formatDate(inputFormat) {
    let date;
    let d = new Date(inputFormat);
    date = [this.pad(d.getMonth() + 1), this.pad(d.getDate()), d.getFullYear()].join("/");
    return this.convertDateFormate(date);
  }
  pad(s) { return (s < 10) ? "0" + s : s; }
  convertDateFormate(_dt) {
    let _d = _dt;
    _d = _d.split("/");
    return _d[2] + "-" + _d[0] + "-" + _d[1];
  }
  convertDDMMYY(_dt) {
    let date;
    let d = new Date(_dt);
    date = [this.pad(d.getMonth() + 1), this.pad(d.getDate()), d.getFullYear()].join("/");
    return date;
  }

  showFileDetailsModel() {
    this.dashboardService.getFileSetupByFileId(this.currentRowData.fileId).subscribe(res => {
      if (!res.error) {
        if (res.data !== null) {
          if (this.hasEditFileSetUpPermission) {
            this.router.navigate(["/create", res.data.recordId, res.data.fileVersion, 0]);
          } else if (this.hasViewFileSetUpPermission) {
            this.router.navigate(["/create", res.data.recordId, res.data.fileVersion, 0, "view"]);
          } /*istanbul ignore next*/ else {
            this.toastr.error("Insufficient Permission.", "Oops!", TOAST_SETTING);
          }
        }
      } /*istanbul ignore next*/ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /*istanbul ignore next*/ error => {
      this.toastr.error("Server Error in Fetching File Details.", "Oops!", TOAST_SETTING);
    });
  }

  showJobScheduleList() {
    this.router.navigate(["/view-all-schedules", this.currentRowData.fileId]);
  }

  //  Employer Name
  employerName: any = [];
  populateEmployerName() {
    let currentUser = JSON.parse(localStorage.getItem(CURRENT_USER));
    if (currentUser.employeeList !== undefined) {
      for (let empObj of currentUser.employeeList) {
        this.employerName[empObj.erId] = empObj.erName;
      }
    }
  }

  //  Edit Schedule
  goToJobSchedule(rowData) {
    let obj = [
      rowData.fileId,
      rowData.fileVersion,
      rowData.fileProcessingScheduleId,
      null,
      "/dashboard",
      rowData.jobScheduleDate
    ];
    this.RescheduleService.changeFileId(obj);
    this.router.navigate(["/edit-job-schedule"]);
  }

  //  Job Reschedule Update for single instance
  singleJobRescDate: Date;
  singleJobRescError: boolean = false;
  singleJobRescUpdate() {
    let date;
    let d = new Date(this.singleJobRescDate);
    date = [this.pad(d.getDate()), this.pad(d.getMonth() + 1), d.getFullYear()].join("/");
    if (this.singleJobRescDate === undefined) {
      this.singleJobRescError = true;
      return false;
    }
    else {
      let sendData = {
        "jobId": this.jobId,
        "scheduleDate": date,
        "startDate": this.formatDate(this.filterFD),
        "endDate": this.formatDate(this.filterTD)
      };
      /*istanbul ignore next*/
      this.dashboardService.updateOnlyJobSchedule(sendData).subscribe(res => {
        if (!res.error) {
          this.dashbrdData = res.data;
          this.singleJobRescError = false;
          this.singleJobReschedule = false;
          this.filterDashboard(this.dashBoardTable);
          this.toastr.success("Job rescheduled successfully.", "Success!");
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error Getting Dashboard Data.", "Oops!", TOAST_SETTING);
      });
    }
  }

  ngOnDestroy() {
    if (this.getRecordStatus !== undefined) {
      this.getRecordStatus.unsubscribe();
    }
    if (this.getDashboardDataSubscription) {
      this.getDashboardDataSubscription.unsubscribe();
    }
    this.subscription.unsubscribe();
  }


  //  File Progress Report
  FPRDialog: boolean = false;
  selFPRData: any = [];
  selCriLoader: boolean;
  showFPRDialog(e, rowData) {
    this.selFPRData = rowData;
    this.FPRDialog = true;
    this.selCriLoader = true;
    if (this.selFPRData.fileDirection === "Outbound" && rowData.jobStatusDetails != null) {
      let _jobStatusDetails = rowData.jobStatusDetails;
      let _prepareString = "";
      let _resArray = _jobStatusDetails.split(",");
      for (let obj of _resArray) {
        let _label = obj.split(":");
        if (_label[0].trim() === "Errors") {
          _prepareString = _prepareString + "<span><strong>Error Rows in File :</strong> " + _label[1] + "</span>";
        } else if (_label[0].trim() === "Ignore") {
          _prepareString = _prepareString + "<span class='wrning'><strong>Ignore Rows in File :</strong> " + _label[1] + "</span>";
        } else if (_label[0].trim() === "Warning") {
          _prepareString = _prepareString + "<span class='wrning'><strong>Warning Rows in File :</strong> " + _label[1] + "</span>";
        } else {
          _prepareString = _prepareString + "<span class='node'><strong>Total " + _label[0] + " in the output :</strong> " + _label[1] + "</span>";
        }
      }
      this.selFPRData.FPRFooterText = _prepareString;
    } else {
      let _FPRFooter = "<span><strong>" + rowData.jobStatusDetails + "</span>";
      _FPRFooter = _FPRFooter.replace(/,/g, "</span><span><strong>");
      _FPRFooter = _FPRFooter.replace(/:/g, ": </strong>");
      this.selFPRData.FPRFooterText = _FPRFooter;
    }
    if (this.selFPRData.fileDirection !== "Outbound") {
      return false;
    }

    this.dashboardService.getFileExtractionData(rowData.recordId, rowData.profileId).subscribe(res => {
      this.selFPRData.terminationInd = null;
      this.selFPRData.benefitPlanSubType = null;
      this.selFPRData.employerName = null;
      this.selFPRData.planAdditionFactor = null;
      this.selFPRData.lookAheadPeriod = null;
      this.selFPRData.lookBackPeriod = null;
      this.selFPRData.systemDate = null;
      this.selCriLoader = false;
      for (let data of res.data) {
        switch (data.standardName) {
          case "terminationInd":
            this.selFPRData.terminationInd = data.displayValues;
            break;
          case "benefitPlanSubType":
            this.selFPRData.benefitPlanSubType = data.displayValues;
            break;
          case "employerId":
            this.selFPRData.employerName = data.displayValues;
            break;
          case "lookAheadPeriod":
            this.selFPRData.lookAheadPeriod = data.displayValues;
            break;
          case "lookBackPeriod":
            this.selFPRData.lookBackPeriod = data.displayValues;
            break;
          case "planAdditionFactor":
            this.selFPRData.planAdditionFactor = data.displayValues;
            break;
          case "systemDate":
            if (data.displayValues.trim() !== "") {
              this.selFPRData.systemDate = this.formatRunDate(data.displayValues.trim());
              this.selFPRData.defaultDate = false;
            } else {
              this.selFPRData.systemDate = moment.tz(new Date(), "America/Chicago").format("MM/DD/YYYY");
              this.selFPRData.defaultDate = true;
            }
            this.selFPRData.systemDate += this.centralTimeZone;
            break;
        }
      }
    });
  }


  uploadFileModel: boolean = false;
  isAssociated: boolean = false;
  showUploadFileModel(jobId, actionItems) {
    this.isAssociated = false;
    actionItems.hide();
    this.dashboardService.getJobAssociatedWithTransmission(this.jobId).subscribe(res => {
      this.isAssociated = res.data;
    });
    this.uploadFileModel = true;
    this.uploadFileNameModel = undefined;
    this.jobId = jobId;
    this.transBtnClicked = false;
  }

  uploadFileNameModel: any;
  isFileValid: any = true;
  transNameModel: any;
  transBtnClicked: boolean;
  saveFile(form: NgForm) {
    this.transBtnClicked = true;
    if (this.isFileValid) {
      let formData = new FormData();
      let file;
      if (this.uploadFileNameModel === undefined) {
        this.toastr.error("Please select file to upload!", "Oops!", TOAST_SETTING);
        this.transBtnClicked = false;
        return false;
      } else {
        file = this.uploadFileNameModel;
      }
      formData.append("file", file, file.name);
      this.dashboardService.saveFile(formData, this.jobId).subscribe(res => {
        if (!res.error) {
          this.uploadFileModel = false;
          this.isFileUploaded = true;
          this.currentRowData.externalFileUploaded = true;
          this.toastr.success("File Uploaded Successfully!");
          form.resetForm();
        }
        else {
          this.toastr.error("Error while uploading a file!", "Oops!", TOAST_SETTING);
        }
        this.transBtnClicked = false;
      }, error => {
        let errorMsg = error.error.message;
        if (errorMsg === "FILE_TRANSMISSION_NAME_MISMATCH") {
          this.toastr.error("Your file has not been uploaded because file name does not match with the transmission name specified in the job configuration.", "Oops!", TOAST_SETTING);
        } else if (errorMsg === "FILE_UPLOAD_ERROR") {
          this.toastr.error("Invalid File Upload!", "Oops!", TOAST_SETTING);
        }
        else {
          this.toastr.error("Error while uploading a file!", "Oops!", TOAST_SETTING);
        }
        this.transBtnClicked = false;
      });
    } else {
      this.toastr.error("Please select file to upload!", "Error!", TOAST_SETTING);
      this.transBtnClicked = false;
    }

  }

  cancelFileUpload(form: NgForm) {
    this.uploadFileModel = false;
    form.resetForm();
  }

  uploadFile(event) {

    let file = this.getFile(event);
    if (file != null) {
      this.uploadFileNameModel = this.getFile(event);
    }
  }

  getFile(event) {
    event.preventDefault();
    let fileList = event.target.files;
    if (fileList.length > 0) {
      let file = fileList[0];
      let validFormats = ["csv", "CSV", "txt", "TXT", "pgp", "PGP"];
      let value = file.name, ext = value.substring(value.lastIndexOf(".") + 1).toLowerCase();
      if (validFormats.indexOf(ext) === -1) {
        this.toastr.error("Please upload the valid file format", "Error!", TOAST_SETTING);
        event.target.value = "";
        this.isFileValid = false;
        this.transBtnClicked = false;
      } else {
        this.isFileValid = true;
        return file;
      }
    }
  }


  downloadErrorsLogs(overlaypanel) {
    overlaypanel.hide();
    this.dashboardService.downloadErrorsLogs(this.currentRowData.jobId, this.currentRowData.fileId, this.currentRowData.jobStatus);
  }

  fileStatus: string = "All";
  fileStatusList = [{
    "label": "All",
    "value": "All"
  }, {
    "label": "Active",
    "value": "Active"
  }, {
    "label": "Inactive",
    "value": "Inactive"
  }, {
    "label": "Training",
    "value": "Training"
  }];


  onFilter(event) {
    this.exportFilterData = event.filteredValue;
    this.count = this.exportFilterData.length;
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.dashBoardToolTip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.dashBoardToolTip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
    //  this.dynamicPopover.title = null;
    //  this.popOverheading.nativeElement.innerHTML = popoverTitle;
    //  overlaypanel.toggle(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  onClickRemoveJob(overlaypanel) {
    overlaypanel.hide();
    this.showJobRemoveDialogue = true;
  }
  /* istanbul ignore next */
  removeJob() {
    this.isClickedOnJobRemove = false;
    this.isJobRemoving = true;

    const jobDetailsObj = {
      fileIdentifier: this.currentRowData.recordId,
      jobId: this.currentRowData.jobId,
      jobStatusNotes: this.jobRemoveNotes
    };

    this.jobSetupService.removeJob(jobDetailsObj).subscribe(res => {
      if (!res.error) {
        this.isJobRemoving = false;
        this.showJobRemoveDialogue = false;
        this.jobRemoveNotes = null;
        this.filterOnOff(this.table);
        this.getDashboardData();
        this.toastr.success("Job removed successfully!");
      }
      else {
        this.isJobRemoving = false;
        this.showJobRemoveDialogue = false;
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.isJobRemoving = false;
      this.showJobRemoveDialogue = false;
      this.toastr.error("Error while removing job!", "Oops!", TOAST_SETTING);
    });
  }

  cancelJobRemove() {
    this.showJobRemoveDialogue = false;
    this.isClickedOnJobRemove = false;
    this.jobRemoveNotes = null;
  }

  downloadInboundFile(overlaypanel) {
    overlaypanel.hide();
    this.heldFilesService.downloadInboundFile(this.currentRowData.fileStateId, this.currentRowData.fileName, true);
  }

  showReprioritizeModel(reprioritizeForm: NgForm) {
    reprioritizeForm.resetForm();
    this.reprioritizeModel = true;
    this.pageID = 24;
    this.getToolTipTextDetails();
  }

  addReprioritizeNote(reprioritizeForm: NgForm) {
    this.reprioritizeModel = false;
    this.explicitHighPprioritization = false;
    this.explicitLowPrioritization = false;
    if ((reprioritizeForm.value.priority !== "" && reprioritizeForm.value.priority != null) && (reprioritizeForm.value.notes !== "" && reprioritizeForm.value.notes != null)) {
      this.confirmationService.confirm({
        message: "Are you sure that you want to change priority?",
        accept: /* istanbul ignore next */ () => {

          if (reprioritizeForm.value.priority === "Send to Top") {
            this.explicitHighPprioritization = true;
            this.explicitLowPrioritization = false;
          } else if (reprioritizeForm.value.priority === "Send to Bottom") {
            this.explicitHighPprioritization = false;
            this.explicitLowPrioritization = true;
          }
          let sendData = {
            "jobId": this.currentRowData.jobId,
            "notes": reprioritizeForm.value.notes.toString(),
            "explicitHighPprioritization": this.explicitHighPprioritization,
            "explicitLowPrioritization": this.explicitLowPrioritization,
            "fileProcessingScheduleId": this.currentRowData.fileProcessingScheduleId
          };
          this.dashboardService.rePrioritize(sendData).subscribe(res => {
            if (!res.error) {
              this.toastr.success("File Processing Priority Changed Successfully", "Success!");
              this.filterDashboard(this.dashBoardTable);
            } else {
              this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            }
          }, error => {
            this.toastr.error("Server Error in Change Priority.", "Oops!", TOAST_SETTING);
          });
        }, reject: () => {
          this.reprioritizeModel = true;
        }
      });
    } else {
      this.reprioritizeModel = true;
    }
  }
  resetToolTipData(event) {
    this.pageID = 23;
    this.getToolTipTextDetails();
  }

  showJobDetails(rowData: any) {
    this.fileProcessingStartDate = null;
    this.fileProcessingEndDate = null;

    if (rowData.fileProcessingStartDate) {
      this.fileProcessingStartDate = new Date(rowData.fileProcessingStartDate).getTime();
    }

    if (rowData.fileProcessingEndDate) {
      this.fileProcessingEndDate = new Date(rowData.fileProcessingEndDate).getTime();
    }
    this.jobRunDate = moment.tz(rowData.jobScheduleDate, "America/Chicago").format("MM/DD/YYYY HH:mm:ss");
    if (rowData.fileDirection === "Inbound") {
      rowData.customTransName = rowData.fileId + ".txt";
    } else {
      rowData.customTransName = rowData.fileId + "_" + rowData.jobId + "_" + moment.tz(rowData.jobScheduleDate, "America/Chicago").format("YYYYMMDD") + "_" + moment.tz(rowData.jobScheduleDate, "America/Chicago").format("HHmmss") + ".txt";
    }

    this.selectedRowData = rowData;
    this.jobDetailsModel = true;
  }

  getSelected(rowData) {
    return rowData.jobStatus === "ROLLBACK_INITIATED" || rowData.jobStatus === "ROLLD_BACK" || rowData.jobStatus === "ROLLBACK_FAILED" ? "highlightRow" : "";
  }

  downloadOutboundFile(overlaypanel) {
    let outboundFileName = this.currentRowData.fileId + "_" + this.currentRowData.jobId;
    overlaypanel.hide();
    this.heldFilesService.downloadOutboundFile(this.currentRowData.fileStateId, outboundFileName);
  }

  /**
   * To re-transmit outbound file.
   * @param overlaypanel Action menu reference.
   */
  reTransmitFile(overlaypanel) {
    overlaypanel.hide();
    const reTransmitFileDto = {
      jobId: this.currentRowData.jobId
    };

    this.dashboardService.reTransmitFile(reTransmitFileDto).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Re-Transmission successful", "Success!");
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server error in transmission.", "Oops!", TOAST_SETTING);
    });
  }
}