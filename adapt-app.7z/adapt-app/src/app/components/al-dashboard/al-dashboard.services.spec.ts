import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { AlDashboardService } from "./al-dashboard.services";
import { TOKEN_NAME } from "./../login/login.constant";
import { ApiEnvService } from "../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlDashboardService", () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AlDashboardService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  }));

  it("getDashboadData", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/dashboard-details.json");

    contactService.getDashboadData({}).subscribe((res) => {
      expect(res.data.length).toBe(1);
    });
  })));

  it("getJobScheduleStatus", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/dashboard-job-status.json");

    contactService.getJobScheduleStatus({}).subscribe((res) => {
    });
  })));
  it("getBlackoutWindowStatus", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.getBlackoutWindowStatus({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("getClientContact", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.getClientContact({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("retransmitFile", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.retransmitFile({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("sentManually", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.sentManually({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("getFileSetupByFileId", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.getFileSetupByFileId({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("showJobScheduleListByFileId", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.showJobScheduleListByFileId({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("updateOnlyJobSchedule", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.updateOnlyJobSchedule({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("saveFile", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.saveFile({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("handleError", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.handleError();
  })));
  it("downloadFile", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.downloadFile();
  })));
  it("downloadErrorsLogs", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");
    let jobId, fileId, jobStatus;
    jobId = 1511;
    fileId = 301;
    jobStatus = "IN_PROGRESS";
    contactService.downloadErrorsLogs(jobId, fileId, jobStatus);
  })));
  it("rePrioritize", async(inject([AlDashboardService], (contactService) => {
    let response = require("../../../assets/test-data/blackout-message-notification.json");

    contactService.rePrioritize({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
});