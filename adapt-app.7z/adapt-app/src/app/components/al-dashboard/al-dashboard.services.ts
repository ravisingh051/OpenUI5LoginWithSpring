import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../env.service";
import { Observable } from "rxjs";
import "rxjs/add/operator/toPromise";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class AlDashboardService {

    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }
    apiEnvEndpoint = this.apiEnvService.endpoint;

    getDashboadData(fromDt, toDt, fileStatus, fileId): Observable<any> {
        if (fileId === undefined) {
            return this.http.get(this.apiEnvEndpoint + "/Dashboard/details?startDate=" + fromDt + "&endDate=" + toDt + "&fileStatus=" + fileStatus).map(extractData).catch(handleError);
        } else {
            return this.http.get(this.apiEnvEndpoint + "/Dashboard/details?startDate=" + fromDt + "&endDate=" + toDt + "&fileStatus=" + fileStatus + "&fileId=" + fileId).map(extractData).catch(handleError);
        }
    }
    getJobScheduleStatus(jobIds): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/getJobStatus", jobIds).map(extractData).catch(handleError);
    }

    // Get list of active blackout windows
    getBlackoutWindowStatus(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/adapt/blackoutWindows?isActive=true")
            .map(extractData).catch(handleError);
    }

    getClientContact(fileId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/Dashboard/getClientContacts?fileId=" + fileId)
            .map(extractData).catch(handleError);
    }

    retransmitFile(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/retransmitOutputFile", data)
            .map(extractData).catch(handleError);
    }

    rollbackFile(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/rollbackFile", data)
            .map(extractData).catch(handleError);
    }

    sentManually(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/sentManually", data)
            .map(extractData).catch(handleError);
    }

    getFileSetupByFileId(fileId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/FileSetup/getByFileIdGenerator?fileId=" + fileId)
            .map(extractData).catch(handleError);
    }

    showJobScheduleListByFileId(fileId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/JobSchedule/getSchedule?fileId=" + fileId);
    }

    updateOnlyJobSchedule(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/updateOnlyJobSchedule", data)
            .map(extractData).catch(handleError);
    }

    saveFile(fileObject, jobId): Observable<any> {
        let headers: HttpHeaders = new HttpHeaders();
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/saveFile?jobId=" + jobId, fileObject, {headers: headers});
    }

    fileName;
    downloadErrorsLogs(jobId, fileId, jobStatus) {
        let headers = new HttpHeaders({
            "Content-Type": "text/csv"
        });
        return this.http.get(this.apiEnvEndpoint + "/Dashboard/downloadErrorCSV?jobId=" + jobId + "&fileId=" + fileId + "&fileStatus=" + jobStatus, { headers: headers, observe: "response", responseType: "blob"})
            .toPromise()
            .then(res => {
                let _headers = res.headers;
                let contentDisposition = _headers.get("content-disposition");
                let _getName = contentDisposition.split("\"");
                this.fileName = _getName[_getName.length - 2];
                if (res && res["body"]) {
                    this.downloadFile(res["body"]);
                }
            })
            .catch(this.handleError);
    }

    handleError(error) {
        console.log("error--  " + error);
    }
    downloadFile(data) {
        if (navigator.msSaveBlob) { // IE 10+
            let blob = new Blob([data], {
                "type": "text/csv;charset=utf8;"
            });
            navigator.msSaveBlob(blob, this.fileName);
        }
        else {
            let blob = new Blob([data], { type: "text/csv;charset=utf-8;" });
            let dwldLink = document.createElement("a");
            let url = URL.createObjectURL(blob);
            let isSafariBrowser = navigator.userAgent.indexOf("Safari") !== -1 && navigator.userAgent.indexOf("Chrome") === -1;
            if (isSafariBrowser) {  // if Safari open in new window to save file with random filename.
                dwldLink.setAttribute("target", "_blank");
            }
            dwldLink.setAttribute("href", url);
            dwldLink.setAttribute("download", this.fileName);
            dwldLink.style.visibility = "hidden";
            document.body.appendChild(dwldLink);
            dwldLink.click();
            document.body.removeChild(dwldLink);
        }
    }

    rePrioritize(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/Dashboard/rePrioritize", data)
            .map(extractData).catch(handleError);
    }

    getJobAssociatedWithTransmission(jobId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/Dashboard/getJobAssociatedWithTransmission?jobId=" + jobId);
    }

    getFileExtractionData(fileIdentifier, profileId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/api/adapt/files/extraction/data/" + fileIdentifier + "/" + profileId);
    }

    reTransmitFile(reTransmitFileDto): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/api/adapt/files/reTransmit", reTransmitFileDto)
            .map(extractData).catch(handleError);
    }
}