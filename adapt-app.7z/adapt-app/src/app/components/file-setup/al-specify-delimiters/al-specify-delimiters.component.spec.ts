import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlSpecifyDelimitersComponent } from "./al-specify-delimiters.component";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, ConfirmDialogModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { ConfirmationService } from "primeng/components/common/api";
import { DatePipe } from "@angular/common";
import { TemplateRef, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { RescheduleService } from "../../../services/common/reschedule";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { SpecifyDelimitersService } from "../al-file-setup-services/al-specify-delimiters-service";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";


describe("AlSpecifyDelimitersComponent", () => {
  let component: AlSpecifyDelimitersComponent;
  let fixture: ComponentFixture<AlSpecifyDelimitersComponent>;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlSpecifyDelimitersComponent, {
      set: {
        providers: [
          { provide: SpecifyDelimitersService, useClass: MockDataService },
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        ConfirmDialogModule,
        DialogModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlSpecifyDelimitersComponent, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        ConfirmationService,
        RescheduleService,
        { provide: SpecifyDelimitersService, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: USE_PERMISSIONS_STORE },
        { provide: ToolTipUtilService, useClass: FakeToolTip }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlSpecifyDelimitersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should create", () => {
    component.saveSpecDel();
    component.specClose();
  });
  it("should and displayToolTipText()", () => {
    component.delimeterToolTip = {
      "Data Layout": {
        "tooltipDesc": "Data Layout description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Data Layout", "bottom");
    });
    component.hideToolTipText(event);
    btnNextStep.click();
  });
});

class MockDataService {
  getDelimiterAndTerminator(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-specify-delimiters/findDelimiterAndTerminator.json");
    return (Observable.of(response));
  }
  saveFileNodeDelimiter(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-specify-delimiters/byFileIdentifier.json");
    return (Observable.of(response));
  }
  getFileNodeDelimiter(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-specify-delimiters/findDelimiterAndTerminator.json");
    return (Observable.of(response));
  }
}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}