import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { SpecifyDelimitersService } from "../al-file-setup-services/al-specify-delimiters-service";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../global";

@Component({
  selector: "al-specify-delimiters",
  templateUrl: "./al-specify-delimiters.component.html",
  styleUrls: ["./al-specify-delimiters.component.scss"],
  providers: [SpecifyDelimitersService]
})
export class AlSpecifyDelimitersComponent implements OnInit {

  specDelData: any = {};
  delimiterAndTerminator: any = {};
  @Input() fileIdentifier;
  @Input() viewOnly;

  delimeterToolTip: any = [];
  tooltipResult: any;
  pageID: number = 30;

  constructor(
    private specifyDelimiters: SpecifyDelimitersService,
    public toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService
  ) { }

  ngOnInit() {
    this.specifyDelimiters.getFileNodeDelimiter(this.fileIdentifier).subscribe((res) => {
      if (!res.error) {
        this.specDelData.specDelTableData = res.data;
      }
    });

    /* this.specDelData.delimiter = [
       {"label": "NA","value": null},
       {"label": "*","value": "*"},
       {"label": "~","value": "~"},
       {"label": ">","value": ">"},
       {"label": "<","value": "<"},
       {"label": ":","value": ":"},
       {"label": "^","value": "^"},
       {"label": "|","value": "|"},
       {"label": ",","value": ","}
     ];
     this.specDelData.terminator = [
       {"label": "NA","value": null},
       {"label": "*","value": "*"},
       {"label": "~","value": "~"},
       {"label": ">","value": ">"},
       {"label": "<","value": "<"},
       {"label": ":","value": ":"},
       {"label": "^","value": "^"},
       {"label": "|","value": "|"},
       {"label": ",","value": ","}
     ];*/

    this.getDelimiterAndterminator();
    this.getToolTipTextDetails();
  }

  getDelimiterAndterminator() {
    this.specifyDelimiters.getDelimiterAndTerminator().subscribe((res) => {
      if (!res.error) {
        this.delimiterAndTerminator = res.data;
        this.populateDelimiterAndterminator();
      }
    });
  }

  populateDelimiterAndterminator() {
    let _delimiters = [];
    if (this.delimiterAndTerminator.length !== 0) {
      for (let obj of this.delimiterAndTerminator) {
        _delimiters.push({
          "label": obj.adaptSepTypeName,
          "value": obj.adaptSepTypeName
        });
      }
      this.specDelData.delimiter = _delimiters;
      this.specDelData.delimiter.unshift({ label: "NA", valule: null });
      this.specDelData.terminator = _delimiters;
    }
  }

  btnClicked: boolean = false;
  saveSpecDel() {
    if (this.specDelData.specDelTableData.length === 0) {
      this.toastr.error("No delimiters configuration available to save.", "Oops!", TOAST_SETTING);
      return false;
    }
    this.btnClicked = true;
    for (let obj of this.specDelData.specDelTableData) {
      if (obj.nodeDelimiter || obj.nodeTerminator) {
        obj.active = true;
      } else {
        obj.active = false;
      }
    }
    this.specifyDelimiters.saveFileNodeDelimiter(this.specDelData.specDelTableData).subscribe((res) => {
      if (!res.error) {
        this.toastr.success("Delimiters configuration saved successfully.", "Success!");
        this.onSpecDelClose.emit("false");
      }
    });
  }

  @Output() onSpecDelClose = new EventEmitter();
  specClose() {
    this.onSpecDelClose.emit("false");
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.delimeterToolTip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.delimeterToolTip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }


}