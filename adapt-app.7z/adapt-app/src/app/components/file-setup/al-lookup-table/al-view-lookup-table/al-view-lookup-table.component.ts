import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { AlLookupTableService } from "../../al-file-setup-services/al-lookup-table.service";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { NgForm } from "@angular/forms";
import { DataTable } from "primeng/components/datatable/datatable";
import { Angular2Csv } from "angular2-csv/Angular2-csv";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ConfirmationService } from "primeng/components/common/api";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-view-lookup-table",
  templateUrl: "./al-view-lookup-table.component.html",
  styleUrls: ["./al-view-lookup-table.component.scss"],
  providers: [AlLookupTableService, ConfirmationService]
})

export class AlViewLookupTableComponent implements OnInit {
  @Input() lookupTableData;
  @Input() viewMode;
  @Input() templateId;
  @Input() templateType;
  @Input() fileTypeId;
  @Input() version;
  @Input() status;

  lookupViewModel: any = {};
  tableLoading: boolean = false;
  tableRow: number = 0;
  viewLookUpTotalRec: number;
  ruleEditorData: any = [];
  selAction: string;
  selRowData: any = [];
  selRowIndex: number = 0;
  dataElementDialog: boolean;
  radioDE: string = "attribute";
  dataEDValidation: boolean = false;
  attributeList: any = [];
  @Output() goToLutFn = new EventEmitter();
  @Output() updateLutListData = new EventEmitter();
  @Output() updateDate = new EventEmitter;
  @ViewChild("keyValueFile") keyValueFile: any;

  removelookupKeyId: number;
  lookupTableId: number;
  page: number = 0;
  size: number = 10;
  isPagingReq: boolean = false;

  acceptLabel: string = "Yes";
  rejectLabel: string = "No";

  lookupEditTooltip: any = [];
  tooltipResult: any;
  pageID: number = 0;

  constructor(
    private route: ActivatedRoute,
    private lookupService: AlLookupTableService,
    private confirmationService: ConfirmationService,
    public toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService) {
  }

  ngOnInit() {
    this.lookupViewModel.lookupId = this.lookupTableData.lookupTableId;
    this.lookupViewModel.lookuptableKeyValues = [];
    this.tableLoading = true;
    this.callOnInit();
    this.pageID = 17;
    this.getToolTipTextDetails();
    if (!this.viewMode) {
      this.subscribeFormChanges();
    }
  }

  callOnInit() {
    this.getLookupTableKeyValue();
    this.lookupViewModel.isHardCode = false;
    this.lookupService.getAttributes(this.templateId, this.templateType, this.fileTypeId, this.version).subscribe(res => {
      if (!res.error) {
        this.attributeList = res.data;
        for (let attrLabel of this.attributeList) {
          attrLabel.label = attrLabel.attributeName;
          attrLabel.value = attrLabel.attributeId;
          attrLabel.attrAssocId = attrLabel.attrAssocId;
        }
        this.attributeList.unshift({
          label: "Please Select",
          value: null,
          attrAssocId: null
        });
        if (!this.viewMode) {
          this.subscribeAddLookupKeyVal();
        }
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in fetching Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  getLookupTableKeyValue() {
    this.lookupService.getDetails(this.lookupViewModel.lookupId, this.page, this.size).subscribe(res => {
      if (!res.error) {
        this.lookupViewModel.lookupTableInfo = res.lookupKeyValues.content[0].lookupTableInfo;
        this.lookupViewModel.compositeKeyMappingList = res.lookupTableDTO.compositeKeyMappingList;
        this.lookupViewModel.tableName = this.lookupViewModel.lookupTableInfo.lookupTableName;
        this.lookupViewModel.tableDesc = this.lookupViewModel.lookupTableInfo.lookupKeyDescription;
        this.lookupViewModel.lastUpdatedBy = this.lookupViewModel.lookupTableInfo.createdDateTime;
        this.lookupViewModel.lookupTableVersion = this.lookupViewModel.lookupTableInfo.lookupTableVersion;
        if (this.lookupViewModel.compositeKeyMappingList.length === 0) {
          this.ruleEditorData = [];
          this.addRuleEditorData(0);
          this.ruleEditorData[0].dataIndex = "dataIndex_0";
          this.lookupViewModel.isHardCode = false;
        } else {

          this.prepareDataForEdit(this.lookupViewModel.compositeKeyMappingList);
          this.lookupViewModel.isHardCode = true;
        }
        if (res.lookupKeyValues.content[0].lookupKey != null && res.lookupKeyValues.content[0].lookupValue != null) {
          this.lookupViewModel.lookuptableKeyValues = res.lookupKeyValues.content;
          this.viewLookUpTotalRec = res.lookupKeyValues.totalElements;
        }
        if (res.lookupKeyValues.totalElements > this.size) {
          this.isPagingReq = true;
          this.viewLookUpTotalRec = res.lookupKeyValues.totalElements;
        }
        else {
          this.isPagingReq = false;
        }
        this.tableLoading = false;
      }
      else {
        this.lookupViewModel.lookuptableKeyValues = [];
        this.tableLoading = false;
      }
    }, error => {
      this.toastr.error("Server Error in fetching Lookup tables key value.", "Oops!", TOAST_SETTING);
    });
  }

  getEditableValue(event, dt: DataTable) {
    if (event.data.lookupKey !== "" && event.data.lookupValue !== "") {
      if (event.data.lookupKey.length > 500 || event.data.lookupValue.length > 500) {
        this.toastr.error("Lookup key and value length can not be more than 500 character.", "Oops!", TOAST_SETTING);
        event.data.lookupKey = this.lookupViewModel.lookupDefaultKey;
        event.data.lookupValue = this.lookupViewModel.lookupDefaultVal;
        return false;
      }
      let data: any = {
        "lookupDetailId": event.data.lookupDetailId,
        "lookupKey": event.data.lookupKey,
        "lookupValue": event.data.lookupValue
      };
      this.lookupService.updateLookupTableDetails(data, this.lookupViewModel.lookupId).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Updated successfully.", "Success!");
          this.getLookupTableKeyValue();
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          this.getLookupTableKeyValue();
        }
      }, error => {
        this.toastr.error("Server Error in updating the lookup key and value.", "Oops!", TOAST_SETTING);
      });
    }
    else {
      this.toastr.error("Lookup Key and Value cannot be blank", "Oops! Cannot Update!", TOAST_SETTING);
      event.data.lookupKey = this.lookupViewModel.lookupDefaultKey;
      event.data.lookupValue = this.lookupViewModel.lookupDefaultVal;
      dt.reset();
    }
  }

  convertDateFormate(_dt) {
    let _d = _dt;
    _d = _d.split("/");
    return _d[1] + "/" + _d[0] + "/" + _d[2];
  }

  getDefaultValue(event) {
    this.lookupViewModel.lookupDefaultKey = event.data.lookupKey;
    this.lookupViewModel.lookupDefaultVal = event.data.lookupValue;
  }

  exportCSV() {
    let _dt = this.lookupViewModel.lookupTableInfo.createdDateTime; // expected response = createdDateTime : "15/03/2018 10:21:52.743 GMT"
    let CreatedDateVal = "";
    if (_dt !== "") {
      _dt = _dt.split(" ");
      _dt = _dt[0];
      CreatedDateVal = this.convertDateFormate(_dt);
    }
    this.lookupService.export(this.lookupViewModel.lookupId).subscribe(res => {
      if (!res.error) {

        let data: any = [];

        data.push(
          {
            "lookupTableNamekey": "Lookup Table Name",
            "lookupTableNameVal": this.lookupViewModel.lookupTableInfo.lookupTableName
          },
          {
            "VersionK": "Version",
            "VersionV": this.lookupViewModel.lookupTableInfo.lookupTableVersion
          },
          {
            "CreatedByKey": "Created By",
            "CreatedByVal": this.lookupViewModel.lookupTableInfo.createdBy
          },
          {
            "CreatedDatekey": "Created Date",
            "CreatedDateVal": CreatedDateVal
          },
          {},
          {
            "colHeader1": "Key Value",
            "colHeader2": "Lookup Value"
          }
        );
        res.data.filter(obj => {
          data.push({
            "lookupKey": obj.lookupKey,
            "lookupValue": obj.lookupValue
          });
        });
        let options = {
          fieldSeparator: ",",
          quoteStrings: "",
          decimalseparator: ".",
          showLabels: false,
          showTitle: false,
          useBom: true
        };
        new Angular2Csv(data, "LUT_" + this.lookupViewModel.lookupTableInfo.lookupTableName, options);
      }
      else {

      }
    }, error => {
      this.toastr.error("Server Error in fetching Lookup tables key value.", "Oops!", TOAST_SETTING);
    });
  }

  addLookupTableKeyValue(form: NgForm) {
    this.tableLoading = true;
    let validValue = true;
    /*if (this.lookupViewModel.lookupKey.trim(" ") == "" || this.lookupViewModel.keyValue.trim(" ") == "") {
      validValue = false;
      this.lookupViewModel.lookupKey = this.lookupViewModel.lookupKey.trim() == '' ? '' : this.lookupViewModel.lookupKey;
      this.lookupViewModel.keyValue = this.lookupViewModel.keyValue.trim() == '' ? '' : this.lookupViewModel.keyValue;

    }
    if (validValue == false) {
      this.toastr.error("Please enter valid value.", 'Oops!');
      return false;
    }*/
    let data: any = {
      "lookupKey": this.lookupViewModel.lookupKey,
      "lookupValue": this.lookupViewModel.keyValue
    };
    let lookupId = this.lookupViewModel.lookupId;
    this.lookupService.addLookupTableDetails(data, lookupId, this.page, this.size).subscribe(res => {
      if (!res.error) {
        this.updateDate.emit(res.data.fileMetaInfo);
        form.resetForm();
        this.lookupViewModel.lookuptableKeyValues = [];
        this.lookupViewModel.lookuptableKeyValues = res.data.lookupTable.content;
        this.toastr.success("Key and Value added successfully.", "Success!");
        this.pushRedirectFlagFn(false);
        this.subscribeAddLookupKeyVal();
        if (res.data.lookupTable.totalElements > this.size) {
          this.isPagingReq = true;
          this.viewLookUpTotalRec = res.data.lookupTable.totalElements;
        }
        else {
          this.viewLookUpTotalRec = 0;
          this.isPagingReq = false;
        }
        this.tableLoading = false;

        // this.getLookupTableKeyValue();

      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.tableLoading = false;
      }
    }, error => {
      this.toastr.error("Server Error in saving Lookup table key value.", "Oops!", TOAST_SETTING);
      this.tableLoading = false;
    });
  }

  validateDuplicateKeyValue(data) {
    let result = false;
    this.lookupViewModel.lookuptableKeyValues.forEach(lookuptable => {
      if (lookuptable.lookupKey === data.lookupKey || lookuptable.lookupValue === data.lookupValue) {
        result = true;
      }
    });
    return result;
  }

  updateLookupTableInfo() {
    let validValue = true;
    if (this.lookupViewModel.tableName.trim(" ") === "") {
      this.lookupViewModel.tableName = "";
      this.toastr.error("Please Enter Valid Value", "Oops!", TOAST_SETTING);
      return false;
    }
    if (this.ruleEditorData.length > 1) {
      let _checkValidValue = this.ruleEditorData.filter((obj) => obj.attributeDictionary == null || obj.attributeName === "Please Select" || obj.attributeDictionary.attributeId == null);
      if (_checkValidValue.length > 0) {
        this.toastr.error("Please select attribute", "Oops!", TOAST_SETTING);
        validValue = false;
      }
    } else {
      if (this.ruleEditorData.length === 1 && (this.ruleEditorData[0].attributeDictionary == null || this.ruleEditorData[0].attributeDictionary.attributeId == null)) {
        this.ruleEditorData = [];
      }
    }
    if (validValue === false) {
      return false;
    }
    for (let i = 0; i < this.ruleEditorData.length; i++) {
      this.ruleEditorData[i].ltckmOrder = i + 1;
    }
    let data: any = {
      "lookupTableMetaInfo": {
        "lookupTableName": this.lookupViewModel.tableName,
        "lookupTableId": this.lookupViewModel.lookupId,
        "lookupKeyDescription": this.lookupViewModel.tableDesc,
        "lookupTableVersion": this.lookupViewModel.lookupTableVersion,
        "associatedFileLevelId": this.lookupTableData.associatedFileLevelId,
        "associatedFileLevel": this.lookupTableData.associatedFileLevel,
        "associatedFileTypeId": this.lookupTableData.associatedFileTypeId
      },
      "compositeKeyMappingList": this.ruleEditorData
    };

    let refMode = null;
    let lookupTableId;
    let lookupTableName;
    let refId;
    let refVersion;
    let lookupAttrs = [];

    if (this.lookupViewModel !== undefined && this.lookupViewModel.lookupTableInfo != null && this.lookupViewModel.lookupTableInfo !== undefined) {
      if (this.lookupViewModel.lookupTableInfo.associatedFileLevel === "F") {
        refMode = "file";
      }
      lookupTableId = this.lookupViewModel.lookupTableInfo.lookupTableId;
      lookupTableName = this.lookupViewModel.lookupTableInfo.lookupTableName;
      refId = this.lookupViewModel.lookupTableInfo.associatedFileLevelId;
      refVersion = this.lookupViewModel.lookupTableInfo.lookupTableVersion;
    }

    this.lookupService.getLookupTableFileAssociationsByFileDetails(lookupTableId, refId, refVersion, refMode).subscribe(res => {
      if (!res.error) {
        if (res.data.length > 0) {

          res.data.forEach((lookFileAssociation, index) => {
            lookupAttrs.push(lookFileAssociation.lookupTableFileAssociationDetailsDTO.attributeName);
          });

          let confMsg = "This LUT is associated with Attribute(s) '" + lookupAttrs + "'. If composite key is changed, then LUT needs to be associated again. Are you sure you want to change the composite key?";
          this.acceptLabel = "Ok";
          this.rejectLabel = "Cancel";
          this.confirmationService.confirm({
            message: confMsg,
            accept: () => {
              this.acceptLabel = "Yes";
              this.rejectLabel = "No";
              this.updateLookupTableDetails(data);
            },
            reject: () => {
              this.acceptLabel = "Yes";
              this.rejectLabel = "No";
              if (this.ruleEditorData.length === 0) {
                this.addRuleEditorData(0);
              }
            }
          });
        } else {
          this.updateLookupTableDetails(data);
        }
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Fetching Lookup Table File Association List.", "Oops!", TOAST_SETTING);
    });

  }

  updateLookupTableDetails(data) {
    this.lookupService.update(data).subscribe(res => {
      if (!res.error) {
        this.updateDate.emit(res.data.fileMetaInfo);
        this.updateLutListData.emit(res.data.updatedLookupTableMetaInfo);
        this.toastr.success("Table description updated successfully.", "Success!");
        this.pushRedirectFlagFn(false);
        this.subscribeFormChanges();
        if (this.ruleEditorData.length === 0) {
          this.addRuleEditorData(0);
        }
      } else {
        if (this.ruleEditorData.length === 0) {
          this.addRuleEditorData(0);
        }
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in updating the lookup table.", "Oops!", TOAST_SETTING);
    });
  }
  uploadFile(event) {
    let file = this.getFile(event);
    if (file == null) {
      this.keyValueFile.nativeElement.value = "";
    } else {
      this.lookupViewModel.keyValueFile = this.getFile(event);
    }
  }

  getFile(event) {
    event.preventDefault();
    let fileList = event.target.files;
    if (fileList.length > 0) {
      let file = fileList[0];
      let validFormats = ["csv", "CSV"];
      let value = file.name, ext = value.substring(value.lastIndexOf(".") + 1).toLowerCase();
      if (validFormats.indexOf(ext) === -1)
        this.toastr.error("Please upload the valid file format", "Error!", TOAST_SETTING);
      else
        return file;
    }
  }

  uploadFileKeyValue() {
    this.isPagingReq = false;
    this.viewLookUpTotalRec = 0;
    if (this.lookupViewModel.keyValueFile == null) {
      this.toastr.error("Please select a file to import", "Error!", TOAST_SETTING);
      return;
    } else if (this.lookupViewModel.keyValueFile.size === 0) {
      this.toastr.error("Blank file can not be imported", "Error!", TOAST_SETTING);
      return;
    }
    let formData = new FormData();
    let file = this.lookupViewModel.keyValueFile;
    formData.append("file", file);
    this.lookupService.importKeyValues(this.lookupViewModel.lookupId, formData, 0, this.size).subscribe(res => {
      if (!res.error) {

        this.updateDate.emit(res.data.fileMetaInfo);

        this.tableLoading = true;
        this.tableRow = 0;
        this.keyValueFile.nativeElement.value = null;
        this.lookupViewModel.keyValueFile = null;
        this.lookupViewModel.lookuptableKeyValues = res.data.list.content;
        if (res.data.list.totalElements > this.size) {
          this.isPagingReq = true;
          this.viewLookUpTotalRec = res.data.list.totalElements;
        }
        else {
          this.isPagingReq = false;
        }
        this.toastr.success("File imported successfully", "Success!");
        this.tableLoading = false;
      }
      else {
        this.toastr.error(res.message, "Error!", TOAST_SETTING);
      }
    }, error => {
      let errorMsg = error.error.message;
      if (errorMsg === "FILE_UPLOAD_ERROR") {
        this.toastr.error("Invalid File Upload!", "Oops!", TOAST_SETTING);
      }
    });
  }

  viewLookUpPaginate(event) {
    this.tableLoading = true;
    this.tableRow = event.page * event.rows;
    this.page = event.page;
    this.size = event.rows;
    this.lookupViewModel.lookuptableKeyValues = [];
    this.lookupService.getDetails(this.lookupViewModel.lookupId, event.page, event.rows).subscribe(res => {
      if (!res.error) {
        if (res.lookupKeyValues.content[0].lookupKey != null && res.lookupKeyValues.content[0].lookupValue != null) {
          this.lookupViewModel.lookuptableKeyValues = res.lookupKeyValues.content;
          this.viewLookUpTotalRec = res.lookupKeyValues.totalElements;
        }
      }
      else {
        this.lookupViewModel.lookuptableKeyValues = [];
      }
      this.tableLoading = false;
    }, error => {
      this.toastr.error("Server Error in fetching Lookup tables key value.", "Oops!", TOAST_SETTING);
      this.tableLoading = false;
    });
  }

  addRuleEditorData(selRowIndex) {
    let indx = selRowIndex;
    if (this.selAction === "false") {
      indx++;
    }
    let dataElementValue1 = "";
    let dataElementValue = "";
    let keyType = "";
    if (this.radioDE === "attribute") {
      dataElementValue1 = "Rule (-)";
      keyType = "Attribute";
    }
    let ele = {

      "dataElement": this.radioDE,
      "dataElementValue": dataElementValue1,
      "ltckmType": keyType,
      "attributeDictionary": { "attributeId": null },
      "businessRuleId": null,
      "ltckmOrder": (this.selRowIndex + 1),
      "isRuleExist": ""
    };
    let mydata = this.ruleEditorData[1];
    let test = [...this.ruleEditorData];
    this.ruleEditorData = [];
    test.splice(indx, 0, ele);
    this.ruleEditorData = [...test];
  }

  actionMenu(e, overlaypanel: OverlayPanel, rowData, selRowIndex) {
    overlaypanel.toggle(e);
    this.selRowData = rowData;
    this.dataEDValidation = false;
    this.selRowIndex = selRowIndex;
  }

  removeRow() {
    if (this.ruleEditorData.length === 1) {
      let ele = this.ruleEditorData[0];
      if (ele.attributeDictionary == null || ele.attributeDictionary.attributeId == null) {
        this.toastr.error("Default row from list cannot be removed.", "Oops!", TOAST_SETTING);
        this.lookupViewModel.isHardCode = false;
        return;
      } else {
        this.ruleEditorData.splice(this.selRowIndex, 1);
        this.ruleEditorData = [...this.ruleEditorData];
        this.addNewRow(0);
        this.prepareDescription();
      }
    } else {
      this.ruleEditorData.splice(this.selRowIndex, 1);
      this.ruleEditorData = [...this.ruleEditorData];
      this.prepareDescription();

    }
    this.checkLutDes();
  }
  checkLutDes() {
    if (this.ruleEditorData.length === 0) {
      this.lookupViewModel.isHardCode = false;
    } else if (this.ruleEditorData.length === 1 && this.ruleEditorData[0].attributeDictionary.attributeId == null) {
      this.lookupViewModel.isHardCode = false;
    }
  }

  rowActionItem(action, overlaypanel: OverlayPanel) {
    this.lookupViewModel.isHardCode = true;
    overlaypanel.hide();
    this.selAction = action;
    if (action === "null") {
      this.removeRow();
    }
    else {
      this.addNewRow(this.selRowIndex);
    }
  }

  addNewRow(selIndex) {
    if (this.radioDE === "") {
      this.dataEDValidation = true;
    }
    else {
      this.dataEDValidation = false;
      this.addRuleEditorData(selIndex);
    }
  }

  updateValue(elem, index, label) {
    this.lookupViewModel.isHardCode = true;
    this.ruleEditorData[index].attributeDictionary = {};
    this.ruleEditorData[index].attributeDictionary.attributeId = Number(elem.value);
    if (elem.value !== null) {
      let _attr = this.attributeList.filter((obj) => obj.attributeId === elem.value);
      let _attrAssocId = _attr[0].attrAssocId;
      this.ruleEditorData[index].attributeName = _attr[0].attributeName;
      this.prepareDescription();
      this.lookupService.isRuleExistForDataElement(_attrAssocId, this.templateType).subscribe(res => {
        if (!res.error) {
          this.ruleEditorData[index].isRuleExist = res.data;
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in getting Attribute Rule Status", "Oops!", TOAST_SETTING);
      });
    }
    else {
      this.ruleEditorData[index].attributeName = "Please Select";
      this.prepareDescription();
      this.ruleEditorData[index].isRuleExist = "";
    }
  }

  prepareDescription() {
    let desc = "";
    for (let i = 0; i < this.ruleEditorData.length; i++) {
      if (this.ruleEditorData[i].attributeDictionary !== null && this.ruleEditorData[i].attributeId !== 0 && this.ruleEditorData[i].attributeName != null && this.ruleEditorData[i].attributeName !== "Please Select") {
        desc += this.ruleEditorData[i].attributeName.trim() + "|";
      }
    }

    this.lookupViewModel.tableDesc = desc.substring(0, desc.length - 1);
  }

  prepareDataForEdit(compositeKeyMappingList) {
    this.ruleEditorData = [];
    let dataElementValue1 = "";
    let attributeName = null;
    let attributeDictionary = {};
    for (let i = 0; i < compositeKeyMappingList.length; i++) {
      if (compositeKeyMappingList[i].ltckmType === "Attribute") {
        dataElementValue1 = "Rule (-)";
        this.radioDE = "attribute";
        attributeDictionary = compositeKeyMappingList[i].attributeDictionary;
        attributeName = compositeKeyMappingList[i].attributeDictionary.attributeName;
      }
      let ele = {
        "dataIndex": "dataIndex_" + (i + 1),
        "dataElement": this.radioDE,
        "dataElementValue": dataElementValue1,
        "ltckmType": compositeKeyMappingList[i].ltckmType,
        "attributeDictionary": attributeDictionary,
        "businessRuleId": null,
        "ltckmOrder": (i + 1),
        "attributeName": attributeName,
        "isRuleExist": compositeKeyMappingList[i].ruleExist
      };
      this.ruleEditorData.splice(i, 0, ele);
    }
  }

  trackRow(index, obj) {
    return index;
  }

  goToLutTab() {
    this.goToLutFn.emit();
  }

  vieEditKeyValFn(e, overlaypanel: OverlayPanel, rowData, selRowIndex) {
    overlaypanel.toggle(e);
    this.removelookupKeyId = rowData.lookupDetailId;
    this.lookupTableId = rowData.lookupTableInfo.lookupTableId;
  }

  removeKeyVal(overlaypanel: OverlayPanel) {
    this.tableLoading = true;
    overlaypanel.hide();
    this.lookupService.removelookupKey(this.removelookupKeyId, this.lookupTableId, this.page, this.size).subscribe(res => {
      if (!res.error) {

        this.updateDate.emit(res.data.fileMetaInfo);

        this.lookupViewModel.lookuptableKeyValues = [];
        res.data = res.data.lookupTables;
        this.lookupViewModel.lookuptableKeyValues = res.data.content;
        if (res.data.totalElements > this.size) {
          this.isPagingReq = true;
          this.viewLookUpTotalRec = res.data.totalElements;
        }
        else {
          this.viewLookUpTotalRec = 0;
          this.isPagingReq = false;
        }
        if (res.data.first === false && res.data.last === true && res.data.totalElements !== 0 && res.data.content.length === 0) {
          this.tableLoading = true;
          let event = {
            "first": res.data.totalElements - res.data.size,
            "page": res.data.number - 1,
            "pageCount": res.data.totalPages,
            "rows": res.data.size,
          };
          this.viewLookUpPaginate(event);
        }
        this.toastr.success("Lookup key Removed Successfully.", "Success!");
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.tableLoading = false;
    }, error => {
      this.toastr.error("Server Error in Removing Lookup Table.", "Oops!", TOAST_SETTING);
    });

  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.lookupEditTooltip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.lookupEditTooltip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }



  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @ViewChild("updateLookuptbl") updateLookuptbl;
  pageForm: any;
  @Output() pushRedirectFlag = new EventEmitter();
  subscribeFormChanges() {
    this.pageForm = this.updateLookuptbl.valueChanges.subscribe(
      result => {
        if (this.updateLookuptbl.form.dirty) {
          this.redirectFlag = true;
          this.pushRedirectFlag.emit(true);
          this.pageForm.unsubscribe();
        }
      }
    );
  }


  @ViewChild("addLookupKeyVal") addLookupKeyVal;
  pageForm2: any;
  subscribeAddLookupKeyVal() {
    this.pageForm2 = this.addLookupKeyVal.valueChanges.subscribe(
      result => {
        if (this.addLookupKeyVal.form.dirty) {
          this.redirectFlag = true;
          this.pushRedirectFlag.emit(true);
          this.pageForm2.unsubscribe();
        }
      }
    );
  }

  pushRedirectFlagFn(flag) {
    this.redirectFlag = flag;
    this.pushRedirectFlag.emit(flag);
  }

}