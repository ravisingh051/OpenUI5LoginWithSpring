import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlLookupTableService } from "../al-file-setup-services/al-lookup-table.service";

import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, Router, ActivatedRoute } from "@angular/router";
import { AlLookupTableComponent } from "./al-lookup-table.component";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";


describe("AlLookupTableComponent", () => {
    let component: AlLookupTableComponent;
    let fixture: ComponentFixture<AlLookupTableComponent>;
    let toastService, alNotificationsService;

    beforeEach(async(() => {
        TestBed.overrideComponent(AlLookupTableComponent, {
            set: {
                providers: [
                    ConfirmationService,
                    { provide: AlLookupTableService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService },
                    { provide: Observable, useClass: MockDataService },
                    { provide: ToolTipUtilService, useClass: FakeToolTip }
                ]
            }
        });
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule,
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlLookupTableComponent, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: AlLookupTableService, useClass: MockDataService },
                { provide: ConfirmationService, useClass: MockDataService },
                // { provide: ToastsManager, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: Observable, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService },
                { provide: Router, useClass: MockDataService },
                { provide: ActivatedRoute, useClass: MockDataService }

            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlLookupTableComponent);
            component = fixture.debugElement.componentInstance;
            // fixture.detectChanges();
            component.pageForm = {
                unsubscribe: () => null
            };
            component.addLookuptbl = document.createElement("form");
            component.addLookuptbl = {
                reset: () => null,
                resetForm: () => null,
                unsubscribe: () => null,
                valueChanges: Observable.create(observer => {
                    observer.next(42);
                    observer.complete();
                    observer.error();
                    return () => true;
                }),
                value: {
                    email: "",
                    ext: null,
                    firstName: "",
                    isContactActiveModelEdit: false,
                    lastName: "",
                    phone: "+09283882992",
                    title: null
                },
                form: {
                    dirty: true
                }
            };
            fixture.detectChanges();
        });
        toastService = TestBed.get(ToastsManager);
    }));

    it("should be logging user", async(() => {
        spyOn(toastService, "error").and.returnValue(Promise.resolve());
        component.ngOnInit();
    }));

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should getToolTipTextDetails for file", () => {
        component.parentType = "file";
        component.getToolTipTextDetails();
    });


    it("test addLookupTable()", () => {
        expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
        component.lookupModel = {
            "tableName": " ",
            "createdBy": "Ankur Aggarwal",
            "createdDateTime": "18/02/2019 13:05:03.420 GMT",
            "lookupTableId": 17912,
            "lookupTableName": "SanityLookUp",
            "lookupKeyDescription": "EIN Month",
            "lookupTableVersion": 1,
            "composite": false,
            "associatedFileLevel": "F",
            "associatedFileLevelId": 1779,
            "associatedFileTypeId": 7
        };
        let validForm = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                templateIds: "",
                templateId: "",
                active: false,
            }
        };
        component.addLookupTable(validForm);
    });
    it("test addLookupTable() for ruleEditorData", () => {
        expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
        component.lookupModel = {
            "tableName": "Check the table name"
        };
        let validForm = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                templateIds: "",
                templateId: "",
                active: false,
            }
        };
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": ""
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": ""
            }
        ];
        component.addLookupTable(validForm);
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": "",
                "attributeName": "Dummy Name"
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": "",
                "attributeName": "Dummy Name"
            }
        ];
        component.addLookupTable(validForm);
        component.ruleEditorData = [];
        component.addLookupTable(validForm);
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": "",
                "attributeName": "Dummy Name"
            }
        ];
        component.addLookupTable(validForm);
    });
    it("should btnReset", () => {
        let validForm = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                fileTypeAssocMapping: "Multiple",
                timeToWait: "",
                templateId: "",
                active: false,
            }
        };
        component.btnReset(validForm);
    });
    it("edit updateValue if", () => {
        let elm = {
            "attributeId": 0,
            "attributeDescription": "PRE-DEFINED :: Custom Date1",
            "attributeName": "Custom Date1",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213979,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null,
            "value": 0
        };
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": "",
                "attributeName": "Custom Date1"
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": "",
                "attributeName": "Dummy Name"
            }
        ];
        component.attributeList = [{
            "attributeId": 0,
            "attributeDescription": "PRE-DEFINED :: Custom Date1",
            "attributeName": "Custom Date1",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213979,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        },
        {
            "attributeId": 765,
            "attributeDescription": "PRE-DEFINED :: Custom Date6",
            "attributeName": "Custom Date6",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213980,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        }];
        component.updateValue(elm, 0, "Custom Date1");
    });
    it("edit updateValue else", () => {
        let elm = {
            "value": null
        };
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": "",
                "attributeName": "Custom Date1"
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": "0"
                },
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": "",
                "attributeName": "Dummy Name"
            }
        ];
        component.attributeList = [{
            "attributeId": 0,
            "attributeDescription": "PRE-DEFINED :: Custom Date1",
            "attributeName": "Custom Date1",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213979,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        },
        {
            "attributeId": 765,
            "attributeDescription": "PRE-DEFINED :: Custom Date6",
            "attributeName": "Custom Date6",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213980,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        }];
        component.updateValue(elm, 0, "Custom Date1");
    });
    it("edit prepareDescription else", () => {
        let elm = {
            "value": null
        };
        component.lookupModel.isHardCode = true;
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": {
                    "attributeId": 0
                },
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": "",
                "attributeName": "Custom Date1"
            }
        ];
        component.attributeList = [{
            "attributeId": 0,
            "attributeDescription": "PRE-DEFINED :: Custom Date1",
            "attributeName": "Custom Date1",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213979,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        },
        {
            "attributeId": 765,
            "attributeDescription": "PRE-DEFINED :: Custom Date6",
            "attributeName": "Custom Date6",
            "attributeSize": null,
            "defaultDataType": "DATE",
            "defaultValue": null,
            "isOverridable": true,
            "attrAssocId": 213980,
            "fileTypeAttrAssocId": null,
            "standardizedName": null,
            "templateAssocId": null,
            "extractionStandardizedName": null,
            "faaId": null
        }];
        component.prepareDescription();
    });
    it("should removeSelectedLookupTable() for \"C\" ", () => {
        component.removeLookupTableId = 0;
        component.templateId = 0;
        component.templateType = "C";
        component.fileTypeId = 0;
        component.version = 0;
        component.removeSelectedLookupTable();
    });
    it("should removeSelectedLookupTable() for \"F\" ", () => {
        component.removeLookupTableId = 0;
        component.templateId = 0;
        component.templateType = "F";
        component.fileTypeId = 0;
        component.version = 0;
        component.removeSelectedLookupTable();
    });
    it("should goToLutFn() and goToNextTabFn() and updateLutListData()", () => {
        let confirmService = fixture.debugElement.injector.get(ConfirmationService);
        spyOn(confirmService, "confirm").and.callFake((params: any) => {
            params.accept();
        });
        component.goToLutFn();
        component.goToNextTabFn();
        component.updateLutListData();
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        let rowData = {};
        let selRowIndex = 0;
        const btnNextStep = document.createElement("button");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            // fixture.componentInstance.onClickNextStep(event);
            component.actionMenu(event, overlayPanel, rowData, selRowIndex);
        });
        btnNextStep.click();
        fixture.detectChanges();

        component.rowActionItem("true", overlayPanel);
        fixture.detectChanges();
    });
    it("should and rowActionItem() else ", () => {
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        component.rowActionItem("null", overlayPanel);
        fixture.detectChanges();
    });
    it("should and displayToolTipText()", () => {
        component.toolTipLookup = {
            "Look up table name": {
                "tooltipDesc": "Look up table name description",
                "readMoreLink": "http://www.google.com"
            }
        };
        fixture.detectChanges();

        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "Look up table name", "bottom");
            fixture.detectChanges();
            component.hideToolTipText(event);
            fixture.detectChanges();
            component.updateDate(event);
        });
        btnNextStep.click();
        fixture.detectChanges();


    });
    it("should viewEditLutFn() \"F\" ", () => {
        const e = {};
        let overlayPanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        component.templateType = "F";
        fixture.detectChanges();
        component.removeLutRow(overlayPanel);
        fixture.detectChanges();
    });
    it("should removeRow() ", () => {
        component.ruleEditorData = [
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 1,
                "isRuleExist": ""
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": ""
            },
            {
                "dataIndex": "dataIndex_0",
                "dataElement": "",
                "dataElementValue": "",
                "ltckmType": "",
                "attributeDictionary": null,
                "businessRuleId": null,
                "ltckmOrder": 2,
                "isRuleExist": ""
            }
        ];
        fixture.detectChanges();
        component.removeRow();
    });
});


class MockDataService {
    getAttributes() {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
        return (Observable.of(response));
    }
    getLookupTables() {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/getLookupTables.json");
        return (Observable.of(response));
    }
    create() {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/create.json");
        return (Observable.of(response));
    }
    isRuleExistForDataElement(id, data) {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/create.json");
        return (Observable.of(response));
    }
    remove(removeLookupTableId, templateId, templateType, fileTypeId, version) {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/remove.json");
        return (Observable.of(response));
    }
    getLookupTableFileAssociationsByFileDetails(removeLookupTableId, templateId, version, refMode) {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-lookup-table/getLookupTableFileAssociationsByChildOrFileDetails.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }
    success() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}