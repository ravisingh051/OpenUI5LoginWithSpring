import { Component, OnInit, ViewChild, ViewEncapsulation, Input, Output, EventEmitter } from "@angular/core";
import { AlLookupTableService } from "../al-file-setup-services/al-lookup-table.service";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { NgForm } from "@angular/forms";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { AlViewLookupTableComponent } from "./al-view-lookup-table/al-view-lookup-table.component";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { TOAST_SETTING, confAcceptLabel, confRejectLabel, confMessage } from "../../../global";
import { ConfirmationService } from "primeng/components/common/api";

@Component({
  selector: "al-lookup-table",
  templateUrl: "./al-lookup-table.component.html",
  styleUrls: ["./al-lookup-table.component.scss"],
  providers: [AlLookupTableService],
  encapsulation: ViewEncapsulation.None
})
export class AlLookupTableComponent {
  lookupModel: any = {};
  tableDataLoading: boolean = true;
  btnClicked: boolean = false;
  attributeList: any = [];
  ruleEditorData: any = [];
  selAction: string;
  selRowData: any = [];
  selRowIndex: number = 0;
  radioDE: string = "attribute";
  dataEDValidation: boolean = false;

  @Input() templateId;
  @Input() templateType;
  @Input() fileTypeId;
  @Input() version;
  @Input() viewMode;
  @Input() status;
  @Input() editFormRecordVersion;
  @Input() isFirstDraft;
  @Input() isWaitingForApproval;
  @Input() isNewVersionCreated;
  @Input() parentType;
  @ViewChild("dt") dt: DataTable;
  @ViewChild("AlViewLookupTableComponent") AlViewLut;
  lutViewChild: boolean = false;
  lookUpChildRowData: any = [];
  removeLookupTableId: number;
  lookupTableName: string;
  @Output() updateLUTList = new EventEmitter;
  /* ToolTip display Click */
  toolTipLookup: any = [];
  tooltipResult: any;
  fileLookupPageID: number = 17;
  @Output() updateDateAndUpdateBy = new EventEmitter;
  @Output("tabLoader") tabLoader = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();

  constructor(
    private lookupService: AlLookupTableService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private toolTipUtils: ToolTipUtilService,
    private confirmationService: ConfirmationService
  ) { }

  ngOnInit() {
    this.loadAttributes();
    this.getLookupTables();
    this.getToolTipTextDetails();
  }

  loadAttributes() {
    if (this.lutViewChild === true) {
      this.lutViewChild = false;
    }
    this.attributeList = [];
    this.ruleEditorData = [];
    this.lookupModel.tableName = "";
    this.checkLutDes();
    this.lookupService.getAttributes(this.templateId, this.templateType, this.fileTypeId, this.version).subscribe(res => {
      if (!res.error) {
        this.attributeList = res.data;
        for (let attrLabel of this.attributeList) {
          attrLabel.label = attrLabel.attributeName;
          attrLabel.value = attrLabel.attributeId;
          attrLabel.attrAssocId = attrLabel.attrAssocId;
        }
        this.attributeList.unshift({
          label: "Please Select",
          value: null,
          attrAssocId: null
        });
        this.addRuleEditorData(0);
        this.ruleEditorData[0].dataIndex = "dataIndex_0";
        this.tabLoader.emit(false);
        if (!this.viewMode) {
          this.subscribeFormChanges();
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in fetching Attribute List.", "Oops!", TOAST_SETTING);
    });
  }


  addLookupTable(form: NgForm) {
    this.pushRedirectFlagFn(false);
    this.btnClicked = true;
    let validValue = true;
    if (this.lookupModel.tableName.trim(" ") === "") {
      this.lookupModel.tableName = "";
      this.btnClicked = false;
      this.toastr.error("Please Enter Valid Value", "Oops!", TOAST_SETTING);
      return false;
    }
    if (this.ruleEditorData.length > 1) {
      let _checkValidValue = this.ruleEditorData.filter((obj) => obj.attributeDictionary === null || obj.attributeName === "Please Select" || obj.attributeDictionary.attributeId === null);
      if (_checkValidValue.length > 0) {
        this.toastr.error("Please select attribute", "Oops!", TOAST_SETTING);
        validValue = false;
      }
    } else {
      if (this.ruleEditorData[0].attributeDictionary === null) {
        this.ruleEditorData = [];
      }
    }
    if (validValue === false) {
      this.btnClicked = false;
      return false;
    }

    for (let i = 0; i < this.ruleEditorData.length; i++) {
      this.ruleEditorData[i].ltckmOrder = i + 1;
    }
    let data: any = {
      "lookupTableMetaInfo": {
        "lookupTableName": this.lookupModel.tableName,
        "lookupKeyDescription": this.lookupModel.tableDesc,
        "associatedFileLevelId": this.templateId,
        "associatedFileLevel": this.templateType,
        "associatedFileTypeId": this.fileTypeId,
        "lookupTableVersion": this.version
      },
      "compositeKeyMappingList": this.ruleEditorData
    };
    this.lookupService.create(data).subscribe(res => {
      if (!res.error) {
        this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
        this.toastr.success("Lookup Table Added Successfully.", "Success!");
        this.ruleEditorData = [];
        this.addNewRow(0);
        this.getLookupTables("save", res.data.updatedLookupTableMetaInfo);
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        if (this.ruleEditorData.length === 0) {
          this.addNewRow(0);
        }
      }
      this.btnClicked = false;
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in adding Lookup table.", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
    });
  }

  getLookupTables(save?, data?) {

    this.tableDataLoading = true;
    this.lookupService.getLookupTables(this.templateId, this.templateType, this.fileTypeId, this.version).subscribe(res => {
      if (!res.error) {
        this.lookupModel.lookuptable = res.data;
        this.tableDataLoading = false;
        if (save === "save") {
          this.dt.reset();
          this.lookupModel.tableName = "";
          this.lookupModel.isHardCode = false;
          this.lutViewChildFn(data);
        }
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in fetching Lookup tables list.", "Oops!", TOAST_SETTING);
    });
  }

  btnReset(form: NgForm) {
    this.ruleEditorData = [];
    this.addNewRow(0);
    this.lookupModel.isHardCode = false;
    form.resetForm();
  }

  btnCancel() {
    this.router.navigate(["/file-setup"]);
  }

  addRuleEditorData(selRowIndex) {
    let indx = selRowIndex;
    if (this.selAction === "false") {
      indx++;
    }
    let dataElementValue1 = "";
    let dataElementValue = "";
    let keyType = "";
    if (this.radioDE === "attribute") {
      dataElementValue1 = "Rule (-)";
      keyType = "Attribute";
    }
    let ele = {
      "dataIndex": "dataIndex_" + (this.selRowIndex + 1),
      "dataElement": this.radioDE,
      "dataElementValue": dataElementValue1,
      "ltckmType": keyType,
      "attributeDictionary": null,
      "businessRuleId": null,
      "ltckmOrder": (this.selRowIndex + 1),
      "isRuleExist": ""
    };
    this.ruleEditorData.splice(indx, 0, ele);
    this.prepareDescription();
  }

  removeRow() {
    let ele = this.ruleEditorData[0];
    if (this.ruleEditorData.length === 1) {
      if (ele.attributeDictionary === null || ele.attributeDictionary.attributeId === null) {
        this.toastr.error("Default row from list cannot be removed.", "Oops!", TOAST_SETTING);
        return;
      } else {
        this.ruleEditorData.splice(this.selRowIndex, 1);
        this.addNewRow(0);
      }
    } else {
      this.ruleEditorData.splice(this.selRowIndex, 1);
      this.prepareDescription();
    }
    this.checkLutDes();
  }
  checkLutDes() {
    if (this.ruleEditorData.length === 0) {
      this.lookupModel.isHardCode = false;
    } else if (this.ruleEditorData.length === 1 && this.ruleEditorData[0].attributeDictionary === null) {
      this.lookupModel.isHardCode = false;
    }
  }

  actionMenu(e, overlaypanel, rowData, selRowIndex) {
    overlaypanel.toggle(e);
    this.selRowData = rowData;
    this.dataEDValidation = false;
    this.selRowIndex = selRowIndex;
  }

  rowActionItem(action, overlaypanel) {
    this.lookupModel.isHardCode = true;
    overlaypanel.hide();
    this.selAction = action;
    if (action === "null") {
      this.removeRow();
    } else {
      this.addNewRow(this.selRowIndex);
    }
  }
  addNewRow(selIndex) {
    if (this.radioDE === "") {
      this.dataEDValidation = true;
    }
    else {
      this.dataEDValidation = false;
      this.addRuleEditorData(selIndex);
    }
  }

  updateValue(elem, index, label) {
    this.addLookuptbl.control.markAsDirty();
    this.lookupModel.isHardCode = true;
    this.ruleEditorData[index].attributeDictionary = {};
    this.ruleEditorData[index].attributeDictionary.attributeId = Number(elem.value);
    if (elem.value !== null) {
      let _attr = this.attributeList.filter((obj) => obj.attributeId === elem.value);
      let _attrAssocId = _attr[0].attrAssocId;
      this.ruleEditorData[index].attributeName = _attr[0].attributeName;
      this.prepareDescription();
      this.lookupService.isRuleExistForDataElement(_attrAssocId, this.templateType).subscribe(res => {
        if (!res.error) {
          this.ruleEditorData[index].isRuleExist = res.data;
        } /* istanbul ignore next */ else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, /* istanbul ignore next */ error => {
        this.toastr.error("Server Error in getting Attribute Rule Status", "Oops!", TOAST_SETTING);
      });
    }
    else {
      this.ruleEditorData[index].attributeName = "Please Select";
      this.prepareDescription();
      this.ruleEditorData[index].isRuleExist = "";
    }

  }

  prepareDescription() {
    let desc = "";
    for (let i = 0; i < this.ruleEditorData.length; i++) {
      if (this.ruleEditorData[i].attributeDictionary !== null && this.ruleEditorData[i].attributeId !== 0 && this.ruleEditorData[i].attributeName != null && this.ruleEditorData[i].attributeName !== "Please Select") {
        desc += this.ruleEditorData[i].attributeName.trim() + "|";
      }
    }
    if (this.ruleEditorData.length === 1 && this.ruleEditorData[0].attributeDictionary !== null) {
      if (this.ruleEditorData[0].attributeDictionary.attributeId === 0) {
        this.lookupModel.isHardCode = false;
      }
    }
    this.lookupModel.tableDesc = desc.substring(0, desc.length - 1);
  }

  lutViewChildFn(rowData) {
    if (this.redirectFlag) {
      this.confirmationService.confirm({
        message: this.confMessage,
        accept: () => {
          this.lookupModel.tableName = "";
          this.lookupModel.tableDesc = "";
          this.ruleEditorData = [];
          this.addNewRow(0);
          this.lookupModel.desc;
          this.lookUpChildRowData = rowData;
          this.lutViewChild = true;
          this.redirectFlag = false;
          this.pushRedirectFlag.emit(false);
          if (!this.viewMode) {
            this.pageForm.unsubscribe();
          }
        }
      });
    } else {
      this.lookupModel.tableName = "";
      this.lookupModel.tableDesc = "";
      this.ruleEditorData = [];
      this.addNewRow(0);
      this.lookupModel.desc;
      this.lookUpChildRowData = rowData;
      this.lutViewChild = true;
      this.redirectFlag = false;
      this.pushRedirectFlag.emit(false);
      if (!this.viewMode) {
        this.pageForm.unsubscribe();
      }
    }
  }

  goToLutFn() {
    if (this.redirectFlag) {
      this.confirmationService.confirm({
        message: this.confMessage,
        accept: () => {
          this.lutViewChild = false;
          this.pushRedirectFlagFn(false);
          setTimeout(() => {
            this.subscribeFormChanges();
          }, 500);
        }
      });
    } else {
      this.lutViewChild = false;
      this.pushRedirectFlagFn(false);
      if (!this.viewMode) {
        setTimeout(() => {
          this.subscribeFormChanges();
        }, 500);
      }
    }

  }
  goToNextTabFn() {
    this.pageNavigation.emit();
  }

  viewEditLutFn(e, overlaypanel, rowData, selRowIndex) {
    overlaypanel.toggle(e);
    this.removeLookupTableId = rowData[selRowIndex].lookupTableId;
    this.lookupTableName = rowData[selRowIndex].lookupTableName;
  }
  removeLutRow(overlaypanel) {
    overlaypanel.hide();
    let refMode;
    if (this.templateType === "F") {
      refMode = "file";
    }

    this.lookupService.getLookupTableFileAssociationsByFileDetails(this.removeLookupTableId, this.templateId, this.version, refMode).subscribe(res => {
      if (!res.error) {
        if (res.data.length > 0) {
          let lookupAttrs = [];
          res.data.forEach((lookFileAssociation, index) => {
            lookupAttrs.push(lookFileAssociation.lookupTableFileAssociationDetailsDTO.attributeName);
          });

          this.toastr.error("The LUT '" + this.lookupTableName + "' cannot be deleted because it has been associated to the Attribute(s) '" + lookupAttrs + "'.", "Oops!", TOAST_SETTING);
        } else {
          this.removeSelectedLookupTable();
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in Fetching Lookup Table File Association List.", "Oops!", TOAST_SETTING);
    });

  }

  removeSelectedLookupTable() {
    this.lookupService.remove(this.removeLookupTableId, this.templateId, this.templateType, this.fileTypeId, this.version).subscribe(res => {
      if (!res.error) {
        this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
        this.toastr.success("The LUT '" + this.lookupTableName + "' has been deleted successfully.", "Success!");
        this.lookupModel.lookuptable = res.data.lookupTableMetaInfo;
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in Removing Lookup Table.", "Oops!", TOAST_SETTING);
    });
  }
  updateLutListData() {
    this.getLookupTables();
  }

  getToolTipTextDetails() {
    if (this.parentType === "file") {
      this.toolTipUtils.getPageAndFieldsDetails(this.fileLookupPageID).subscribe(res => {
        this.toolTipLookup = res.data;
      });
    }
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipLookup[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }
  updateDate(event) {
    this.updateDateAndUpdateBy.emit(event);
  }


  // subscribe for user changes
  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @ViewChild("addLookuptbl") addLookuptbl;
  pageForm: any;
  @Output() pushRedirectFlag = new EventEmitter();
  subscribeFormChanges() {
    this.pageForm = this.addLookuptbl.valueChanges.subscribe(
      result => {
        if (this.addLookuptbl.form.dirty) {
          this.redirectFlag = true;
          this.pushRedirectFlag.emit(true);
          this.pageForm.unsubscribe();
        }
      }
    );
  }

  pushRedirectFlagFn(flag) {
    this.redirectFlag = flag;
    this.pushRedirectFlag.emit(flag);
  }

  // Save data before navigate to other page
  acceptLabel = confAcceptLabel;
  rejectLabel = confRejectLabel;
  confMessage = confMessage;



}