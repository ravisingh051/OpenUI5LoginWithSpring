import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { FileSetupRedirect } from "./al-file-setup-redirect";
import { TOKEN_NAME } from "../../login/login.constant";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: FileSetupRedirect", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                FileSetupRedirect,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("changeRoute ", async(inject([FileSetupRedirect], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.changeRoute();
    })));

});