import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";


@Injectable()
export class AlRuleEditorService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });
  serviceMappingURL = this.apiEnvEndpoint + "/Rules";

  getAllRuleTemplates(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/templates/").map(extractData).catch(handleError);
  }

  getSecondaryDataAtrributes(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/files/secondaryDataAttributes");
  }

  getDropDownOptions(endpoint): Observable<any> {
    return this.http.get(this.serviceMappingURL + endpoint, { headers: this.defaultHeaders }).map(extractData).catch(handleError);
  }

  saveRules(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/saveAttributeRules", data, { headers: this.defaultHeaders })
      .map(extractData).catch(handleError);
  }

  createDrlString(data): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/Drl/generate", data, { headers: this.defaultHeaders })
      .map(extractData).catch(handleError);
  }

  ruleSteppingTest(data): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/Drl/ruleSteppingTest", data, { headers: this.defaultHeaders })
      .map(extractData).catch(handleError);
  }

  getHistoryDataAtrributes(id): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/file/getAllHistoryAttributes?recordId=" + id + "&sectionId=D")
    .map(extractData).catch(handleError);
  }

}
