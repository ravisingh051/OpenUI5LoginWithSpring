import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlExtractionParametersService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/api/adapt/extractionParameter/";

  getActivatedOutboundProfiles(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getActivatedOutboundProfiles");
  }


  getProfileData(recordId, profileId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/api/adapt/fileExtraction/getFileExtractionByFileIdentifierAndProfileId?fileIdentifier=" + recordId + "&profileId=" + profileId);
  }


  getEmployerDetails(recordId): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getEmployerDetails?fileIdentifier=" + recordId);
  }

  getPlanSubtypeDetails(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getPlanSubtypeDetails");
  }

  create(data): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/api/adapt/fileExtraction/create", data);
  }

  checkProfile(recordId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/api/adapt/fileExtraction/getFileExtractionProfileCountByFileIdentifier?fileIdentifier=" + recordId);

  }

  // get subType list for Extraction Tab
  getSelectionCriteriaDatasetByRecordId(id): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getSelectionCriteriaDatasetByRecordId?fileIdentifier=" + id);
  }



}
