import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { AlExtractionParametersService } from "./al-extraction-parameters.service";
import { TOKEN_NAME } from "../../login/login.constant";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlExtractionParametersService", () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AlExtractionParametersService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  }));

  it("getActivatedOutboundProfiles", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getActivatedOutboundProfiles.json");
    contactService.getActivatedOutboundProfiles({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("getProfileData", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getProfileData.json");
    contactService.getProfileData({}).subscribe((res) => {
    });
  })));
  it("getEmployerDetails", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getEmployerDetails.json");
    contactService.getEmployerDetails({}).subscribe((res) => {
    });
  })));
  it("getPlanSubtypeDetails", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getActivatedOutboundProfiles.json");
    contactService.getPlanSubtypeDetails({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("create", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getActivatedOutboundProfiles.json");
    contactService.create({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("checkProfile", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getActivatedOutboundProfiles.json");
    contactService.checkProfile({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("getSelectionCriteriaDatasetByRecordId", async(inject([AlExtractionParametersService], (contactService) => {
    let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-extraction-parameters/getSelectionCriteriaDatasetByRecordId.json");
    contactService.getSelectionCriteriaDatasetByRecordId({}).subscribe((res) => {
    });
  })));

});