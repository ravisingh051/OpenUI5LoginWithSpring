import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlLookupTableService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });
  serviceMappingURL = this.apiEnvEndpoint + "/lookupTables";
  serviceMappingURLFile = this.apiEnvEndpoint + "/file/lookupTables";
  serviceFileAssociationMappingURL = this.apiEnvEndpoint + "/lookupTablesFileAssociation";

  // To get list of look up tables.
  getLookupTables(templateId, templateType, fileTypeId, version): Observable<any> {
    return this.http.get(this.serviceMappingURLFile + "/" + templateId + "?templateType=" + templateType + "&fileTypeId=" + fileTypeId + "&version=" + version);
  }

  // To get look up table by id.
  getLookupTableById(lookupTableId): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/getLookupTableById/" + lookupTableId);
  }

  // Create look up table - Json should contain associatedFileLevelId : templateId, associatedFileLevel : templateType, associatedFileTypeId : fileTypeId
  create(data): Observable<any> {
    return this.http.post(this.serviceMappingURLFile + "/create", data);
  }

  // Update look up table - Json should contain associatedFileLevelId : templateId, associatedFileLevel : templateType, associatedFileTypeId : fileTypeId
  update(data): Observable<any> {
    return this.http.put(this.serviceMappingURLFile + "/update", data);
  }

  // To get details list of look up tables.
  getDetails(lookupTableId, page, size): Observable<any> {
    return this.http.get(this.serviceMappingURLFile + "/details/" + lookupTableId + "?page=" + page + "&size=" + size);
  }

  // Add look up table key value
  addLookupTableDetails(data, lookupTableId, page, size): Observable<any> {
    return this.http.post(this.serviceMappingURLFile + "/addLookupTableDetails/" + lookupTableId + "?page=" + page + "&size=" + size, data);
  }

  // Update look up table key value
  updateLookupTableDetails(data, lookupTableId): Observable<any> {
    return this.http.put(this.serviceMappingURLFile + "/updateLookupTableDetails/" + lookupTableId, data);
  }
  // Get attributes for composite look up table.
  getAttributes(templateId, templateType, fileTypeId, version): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/getAttributes/" + templateId + "?templateType=" + templateType + "&fileTypeId=" + fileTypeId + "&version=" + version);
  }

  // Import csv file
  importKeyValues(lookupTableId, fileObject, page, size): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders();
    return this.http.post(this.serviceMappingURLFile + "/importKeyValues/" + lookupTableId + "?page=" + page + "&size=" + size, fileObject, { headers: headers });
  }

  // Export csv file
  export(lookupTableId): Observable<any> {
    return this.http.get(this.serviceMappingURLFile + "/export/" + lookupTableId);
  }

  // Remove Lookup Table
  remove(lookupTableId, templateId, templateType, fileTypeId, version): Observable<any> {
    return this.http.delete(this.serviceMappingURLFile + "/removeTable/" + lookupTableId + "?templateId=" + templateId + "&templateType=" + templateType + "&fileTypeId=" + fileTypeId + "&version=" + version);
  }

  // Remove Lookup KeyValue
  removelookupKey(lookupKeyId, lookupTableId, page, size): Observable<any> {
    return this.http.delete(this.serviceMappingURLFile + "/removeKey/" + lookupKeyId + "?lookupTableId=" + lookupTableId + "&page=" + page + "&size=" + size);
  }

  // Get Lookup Table Rule Status
  isRuleExistForDataElement(attrAssocId, templateType): Observable<any> {
    return this.http.get(this.serviceMappingURLFile + "/checkRule/" + attrAssocId + "?templateType=" + templateType);
  }

  // Get Lookup Table File Association By File Details
  getLookupTableFileAssociationsByFileDetails(lookupId, refId, refVersion, refMode): Observable<any> {
    return this.http.get(this.serviceFileAssociationMappingURL + "/lookupTableFileAssociationDetails/" + "?lookupId=" + lookupId + "&refId=" + refId + "&refVersion=" + refVersion + "&refMode=" + refMode);
  }

}
