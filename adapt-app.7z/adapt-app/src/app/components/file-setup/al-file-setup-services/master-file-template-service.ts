import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class MasterFileTemplateService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/MasterTemplate/";
  defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });

  getAllMasterFiles(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "details");
  }
  deleteMasterFile(id): Observable<any> {
    return this.http.get(this.serviceMappingURL + "delete?masterFileTemplateId=" + id);
  }

  getFileType(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/FileType/details");
  }

  masterTemplateCreate(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "create", data);
  }

  editMasterFile(id, version, viewOnly): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getById?masterFileTemplateId=" + id + "&masterFileTemplateVer=" + version + "&viewOnly=" + viewOnly);
  }

  updateMasterTemplate(data, id): Observable<any> {
    return this.http.post(this.serviceMappingURL + "edit?masterFileTemplateId=" + id, data);
  }


  // For Attribute
  getAttributeList(dataType): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/addAtrribute?dataType=" + dataType);
  }

  // For Attribute
  getAllAttributes(fileTypeId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/addAllAtrributes?fileTypeId=" + fileTypeId);
  }

  getAllMasterAttributes(templateId, version, fileTypeId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/getAllMasterAtrributes?fileTypeId=" + fileTypeId + "&templateId=" + templateId + "&version=" + version);
  }

  getAttributeMappingRules(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/Rules/details")
      .map(extractData).catch(handleError);
  }

  createAttributeMapping(data): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/MasterAttributeMapping/create", data)
      .map(extractData).catch(handleError);
  }

  removeAttribute(id): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/MasterAttributeMapping/remove?mftaaId=" + id)
      .map(extractData).catch(handleError);
  }

  /*getMasterAttribute(id){
    return this.http.get('/MasterAttributeMapping/getAttributes?masterFileTemplateId=' + id)
    .map(extractData).catch(handleError);
  }*/

  updateMasterAttribute(data, id): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/MasterAttributeMapping/update?mftaaId=" + id, data)
      .map(extractData).catch(handleError);
  }
  updateStatus(data, id): Observable<any> {
    return this.http.post(this.serviceMappingURL + "updatestatus?statusid=" + id, data).map(extractData).catch(handleError);
  }

  getCurrentStatus(id): Observable<any> {
    return this.http.get(this.serviceMappingURL + "currentstatus?id=" + id).map(extractData).catch(handleError);
  }

  getMasterVersionHistory(id): Observable<any> {
    return this.http.get(this.serviceMappingURL + "versionhistory?id=" + id).map(extractData).catch(handleError);
  }

  // For All Standarized Attribute List
  getAttributeStandarizedNameListByFileTypeId(fileTypeId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/getAttributeStandarizedNameListByFileTypeId?fileTypeId=" + fileTypeId);
  }

  getPackageInfoByFileTypeId(fileTypeId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/PackageInfo/package?fileTypeId=" + fileTypeId);
  }
  // For Save click on Attributes pages for the Approved Template.
  updateMasterTemplateAndAttributeMapping(currentSectionMappingData): Observable<any> {
    return this.http.post(this.serviceMappingURL + "updateTemplateAndAttributes", currentSectionMappingData).map(extractData).catch(handleError);
  }

  createDraft(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "createDraft", data);
  }
}
