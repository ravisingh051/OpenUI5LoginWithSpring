import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { Observable } from "rxjs/Observable";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class FileSetupService {

    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }

    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/FileSetup";

    getFiles(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/details");
    }
    editFiles(id, version, viewOnly, fetchAttr, selCloneId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getById?recordId=" + id + "&fileTemplateVer=" + version + "&viewOnly=" + viewOnly + "&fetchAttr=" + fetchAttr + "&cloneNumber=" + selCloneId);
    }
    updateFiles(data, id): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/edit?recordId=" + id, data);
    }

    deleteFiles(id): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/delete?recordId=" + id);
    }

    getMasterTemplate(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterTemplate/details");
    }
    createFile(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/create", data);
    }
    getAttributeList(dataType): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/addAtrribute?dataType=" + dataType);
    }
    getAttributeMappingRules(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/Rules/details");
    }
    getTradingPartnerDetails(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartner/details/list");
    }
    getEmployerDetails(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/employers");
    }
    getTradingPartnerPlatform(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartnerPlatform/details");
    }
    // Get Tranding Partner
    getTradingPartner(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartner/details");
    }
    getTradingPartnerPlatformById(erId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartnerPlatform/selectedEmployerDetails?erId=" + erId);
    }
    getAssignedTeam(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/Team/details");
    }
    getTeamMemberDetails(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TeamMember/teamMemberDetails");
    }
    removeAttribute(id, recordId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/remove?faaId=" + id + "&recordId=" + recordId);
    }

    updateFileAttribute(data, id): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/AttributeMapping/edit?faaId=" + id, data);
    }

    getMasterTplDetail(id, version, viewOnly): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterTemplate/getById?masterFileTemplateId=" + id + "&masterFileTemplateVer=" + version + "&viewOnly=" + viewOnly);
    }

    getPendingScheduledJobsByFileId(id): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/JobSchedule/getPendingScheduledJobsByFileId?fileId=" + id)
            .map(extractData).catch(handleError);
    }

    synchronizeFile(id, version): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/FileSetup/syncKieProject?fileId=" + id + "&fileVersion=" + version)
            .map(extractData).catch(handleError);
    }

    updateStatus(data, id, isUserHaveAccess): Observable<any> {
        if (isUserHaveAccess) {
            return this.http.post(this.serviceMappingURL + "/approve?statusid=" + id, data).map(extractData).catch(handleError);
        } else {
            return this.http.post(this.serviceMappingURL + "/updatestatus?statusid=" + id, data).map(extractData).catch(handleError);
        }
    }

    getCurrentStatus(id): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/currentstatus?id=" + id).map(extractData).catch(handleError);
    }

    getFileVersionHistory(id): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/versionhistory?id=" + id).map(extractData).catch(handleError);
    }

    testAnalyst(analystName): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getLDAPUserByFilter?filter=" + analystName).map(extractData).catch(handleError);
    }

    // For Attribute
    getAllAttributes(id): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/addAllAtrributes?fileTypeId=" + id);
    }

    getAllFileAttributes(fileIdentifier, version, fileTypeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/getAllFileAtrributes?fileTypeId=" + fileTypeId + "&fileIdentifier=" + fileIdentifier + "&version=" + version);
    }

    getAllOutboundFileAttributes(fileIdentifier, version, fileTypeId): Observable<any>  {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/file/outboundFileAtrributesByGroup?fileTypeId=" + fileTypeId + "&fileIdentifier=" + fileIdentifier + "&version=" + version)
        .map(extractData).catch(handleError);
    }

    getOutboundFileAttributes(fileIdentifier): Observable<any>  {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/file/outboundFileAtrributes?recordId=" + fileIdentifier + "&sectionId=D")
        .map(extractData).catch(handleError);
    }

    getAllMasterAttributes(templateId, version, fileTypeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/getAllMasterAtrributes?fileTypeId=" + fileTypeId + "&templateId=" + templateId + "&version=" + version);
    }

    // For All Standarized Attribute List
    getAttributeStandarizedNameListByFileTypeId(fileTypeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeMapping/getAttributeStandarizedNameListByFileTypeId?fileTypeId=" + fileTypeId);
    }

    getPackageInfoByFileTypeId(fileTypeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/PackageInfo/package?fileTypeId=" + fileTypeId);
    }

    getDSGPackageInfo(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/PackageInfo/schemaGenerationPackage")
        .map(extractData).catch(handleError);
    }

    // For Save click on Attributes pages for the Approved Template.
    createDraft(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/createDraft", data);
    }

    getAllIdisRulePrioritySequence(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/idisRulePriority/getAllIdisRulePrioritySequence");
    }

    getTradingPartnerPlatformsByTPId(tradingPartnerId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartner/getPlatformsByTPId?tradingPartnerId=" + tradingPartnerId);
    }

    getFileEmployerAssoc(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/ClientEmployer/details");
    }

    getFileVersionDetails(id): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/api/adapt/file/" + id + "/versionHistory");
    }

    restoreTemplate(fileId, version): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/api/adapt/file/fileId/" + fileId + "/version/" + version + "/restore", null);
    }



    getDynamicSchemaGeneration(recordId, sectionId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getSchema?recordId=" + recordId + "&sectionId=" + sectionId);
    }

    getAttrMappingData(recordId, sectionId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getSectionwiseAttributeMapping?recordId=" + recordId + "&sectionId=" + sectionId);
    }

    getMappedColumns(id): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getMappedColumns?id=" + id);
    }

    saveMappedColumns(recordId, data, version, isElementAssoUpdated): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/fileOutbound/updateMappedColumns/?recordId=" + recordId + "&isElementAssoUpdated=" + isElementAssoUpdated, data);
    }

    getChildrenAttr(recordId, sectionId, parentId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getAttributeMappingByParentId?recordId=" + recordId + "&sectionId=" + sectionId + "&parentId=" + parentId);
    }

    // getLookupTables
    getLookupTables(templateId, templateType, fileTypeId, version): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/lookupTables/" + templateId + "?templateType=" + templateType + "&fileTypeId=" + fileTypeId + "&version=" + version);
    }
    cloneRecords(fileId, cloneFactor): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/" + fileId + "?cloneFactor=" + cloneFactor, "");
    }

    saveCloneRecords(data, cloneNum): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/AttributeMapping/edit?cloneNum=" + cloneNum, data);
    }

    deleteClone(recordId, cloneNum): Observable<any> {
        return this.http.delete(this.serviceMappingURL + "/" + recordId + "/clone/" + cloneNum);
    }

    getFileVersion(fileId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/" + fileId);
    }

    copyConfig(fileId, version, data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/" + fileId + "/v/" + version, data);
    }

    deleteFileDraft(fileId): Observable<any> {
        return this.http.delete(this.serviceMappingURL + "/" + fileId);
    }

    getAllPromotions(fileId: number): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/promotions/" + fileId);
    }

    savePromotions(promotionObj): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/promotions/save", promotionObj);
    }

    withdrawPromotionRequest(promotionObj: Object): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/promotions/withdraw", promotionObj);
    }

    getSectionwiseDynamicSchema(recordId, sectionId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getSectionwiseDynamicSchema?recordId=" + recordId + "&sectionId=" + sectionId);
    }
    getDynamicSchemaByParentId(recordId, sectionId, nodeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getDynamicSchemaByParentId?recordId=" + recordId + "&sectionId=" + sectionId + "&parentId=" + nodeId);
    }

    updateMappedDynamicSchemaColumns(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/fileOutbound/updateMappedDynamicSchemaColumns", data);
    }

    // Save SectionDisplayName
    updateFileSection(sectionDisplayName, fsaId, fileIdentifier): Observable<any> {
        return this.http.put(this.apiEnvEndpoint + "/AttributeMapping/updateFileSection?sectionDisplayName=" + sectionDisplayName
            + "&fsaId=" + fsaId + "&fileIdentifier=" + fileIdentifier, null);
    }

    getFileVersionBasedEnvironment(fileId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getFileVersions/" + fileId);
    }

    getDataTypes(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeDataTypes/details");
    }
    saveMappedDynamicSchemaColumns(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/fileOutbound/schema", data);
    }

    deleteAttrRow(id, recordId, sectionId): Observable<any> {
        return this.http.delete(this.apiEnvEndpoint + "/fileOutbound/schema/" + id + "?recordId=" + recordId + "&sectionId=" + sectionId);
    }

    // Services for outbound
    getAttributeListOutbound(recordId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/fileOutbound/getAttributeList?id=" + recordId);
    }
    getMapColDropDown(recordId, selSection): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/FileSetup/Sections?recordId=" + recordId + "&sectionShortName=" + selSection);
    }
    saveMappedColumnAttr(id, data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/fileOutbound/schema/" + id + "/mapping", data);
    }
    getDraftRuleCount(id): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getDraftRuleById?recordId=" + id);
    }

    markAsTodo(attributeAssociation): Observable<any> {
        return this.http.put(this.apiEnvEndpoint + "/AttributeMapping/markAsTodo", attributeAssociation);
    }

    getMasterFileDetails(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterTemplate/active/details");
    }
}
