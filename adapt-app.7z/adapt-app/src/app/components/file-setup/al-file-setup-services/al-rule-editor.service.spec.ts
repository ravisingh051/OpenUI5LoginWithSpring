import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { AlRuleEditorService } from "./al-rule-editor.service";
import { TOKEN_NAME } from "../../login/login.constant";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlRuleEditorService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                AlRuleEditorService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getAllRuleTemplates", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAllRuleTemplates({}).subscribe((res) => {
        });
    })));

    it("getSecondaryDataAtrributes", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getSecondaryDataAtrributes({}).subscribe((res) => {
        });
    })));

    it("getDropDownOptions", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getDropDownOptions({}).subscribe((res) => {
        });
    })));

    it("saveRules", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.saveRules({}).subscribe((res) => {
        });
    })));

    it("createDrlString", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.createDrlString({}).subscribe((res) => {
        });
    })));

    it("ruleSteppingTest", async(inject([AlRuleEditorService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.ruleSteppingTest({}).subscribe((res) => {
        });
    })));

});