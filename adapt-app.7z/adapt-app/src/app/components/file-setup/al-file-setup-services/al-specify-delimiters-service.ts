import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../env.service";
import { Observable } from "rxjs/Observable";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class SpecifyDelimitersService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/fileNodeDelimiter/";
  defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });

  getFileNodeDelimiter(id): Observable<any> {
    return this.http.get(this.serviceMappingURL + "byFileIdentifier?fileIdentifier=" + id);
  }
  saveFileNodeDelimiter(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "save", data);
  }

  getDelimiterAndTerminator(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "findDelimiterAndTerminator");
  }
}