import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { TOKEN_NAME } from "../../login/login.constant";
import { AlLookupTableService } from "./al-lookup-table.service";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlLookupTableService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                AlLookupTableService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getLookupTables", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.getLookupTables({}).subscribe((res) => {
        });
    })));

    it("getLookupTableById", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.getLookupTableById({}).subscribe((res) => {
        });
    })));

    it("update", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.update({}).subscribe((res) => {
        });
    })));

    it("getDetails", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.getDetails({}).subscribe((res) => {
        });
    })));

    it("addLookupTableDetails", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.addLookupTableDetails({}).subscribe((res) => {
        });
    })));

    it("getAttributes", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.getAttributes({}).subscribe((res) => {
        });
    })));

    it("importKeyValues", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.importKeyValues({}).subscribe((res) => {
        });
    })));

    it("export", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.export({}).subscribe((res) => {
        });
    })));

    it("remove", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.remove({}).subscribe((res) => {
        });
    })));

    it("removelookupKey", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.removelookupKey({}).subscribe((res) => {
        });
    })));

    it("isRuleExistForDataElement", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.isRuleExistForDataElement({}).subscribe((res) => {
        });
    })));

    it("getLookupTableFileAssociationsByFileDetails", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.getLookupTableFileAssociationsByFileDetails({}).subscribe((res) => {
        });
    })));

    it("create", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.create({}).subscribe((res) => {
        });
    })));

    it("updateLookupTableDetails", async(inject([AlLookupTableService], (contactService) => {
        let response = require("../../../../assets/test-data/file-setup/al-file-setup-services/al-lookup-table/getLookupTables.json");
        contactService.updateLookupTableDetails({}).subscribe((res) => {
        });
    })));

});