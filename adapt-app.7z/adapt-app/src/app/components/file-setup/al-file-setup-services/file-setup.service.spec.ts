import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { FileSetupService } from "./file-setup.service";
import { TOKEN_NAME } from "../../login/login.constant";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: FileSetupService", () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        FileSetupService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  }));

  it("getFiles", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getFiles({}).subscribe((res) => {
    });
  })));

  it("editFiles", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.editFiles({}).subscribe((res) => {
    });
  })));

  it("updateFiles", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.updateFiles({}).subscribe((res) => {
    });
  })));

  it("deleteFiles", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.deleteFiles({}).subscribe((res) => {
    });
  })));


  it("getMasterTemplate", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getMasterTemplate({}).subscribe((res) => {
    });
  })));

  it("createFile", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.createFile({}).subscribe((res) => {
    });
  })));

  it("getAttributeList", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAttributeList({}).subscribe((res) => {
    });
  })));

  it("getAttributeMappingRules", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAttributeMappingRules({}).subscribe((res) => {
    });
  })));

  it("getTradingPartnerDetails", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getTradingPartnerDetails({}).subscribe((res) => {
    });
  })));

  it("getEmployerDetails", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getEmployerDetails({}).subscribe((res) => {
    });
  })));

  it("getTradingPartnerPlatform", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getTradingPartnerPlatform({}).subscribe((res) => {
    });
  })));

  it("getTradingPartnerPlatformById", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getTradingPartnerPlatformById({}).subscribe((res) => {
    });
  })));

  it("getAssignedTeam", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAssignedTeam({}).subscribe((res) => {
    });
  })));

  it("getTeamMemberDetails", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getTeamMemberDetails({}).subscribe((res) => {
    });
  })));

  it("removeAttribute", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.removeAttribute({}).subscribe((res) => {
    });
  })));

  it("updateFileAttribute", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.updateFileAttribute({}).subscribe((res) => {
    });
  })));

  it("getMasterTplDetail", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getMasterTplDetail({}).subscribe((res) => {
    });
  })));


  it("getPendingScheduledJobsByFileId", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getPendingScheduledJobsByFileId({}).subscribe((res) => {
    });
  })));

  it("synchronizeFile", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.synchronizeFile({}).subscribe((res) => {
    });
  })));

  it("updateStatus", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.updateStatus({}).subscribe((res) => {
    });
  })));

  it("getCurrentStatus", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getCurrentStatus({}).subscribe((res) => {
    });
  })));

  it("getFileVersionHistory", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getFileVersionHistory({}).subscribe((res) => {
    });
  })));

  it("testAnalyst", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.testAnalyst({}).subscribe((res) => {
    });
  })));

  it("getAllAttributes", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllAttributes({}).subscribe((res) => {
    });
  })));

  it("getAllFileAttributes", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllFileAttributes({}).subscribe((res) => {
    });
  })));

  it("getAllOutboundFileAttributes", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllOutboundFileAttributes({}).subscribe((res) => {
    });
  })));

  it("getAllMasterAttributes", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllMasterAttributes({}).subscribe((res) => {
    });
  })));

  it("getAttributeStandarizedNameListByFileTypeId", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAttributeStandarizedNameListByFileTypeId({}).subscribe((res) => {
    });
  })));

  it("getPackageInfoByFileTypeId", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getPackageInfoByFileTypeId({}).subscribe((res) => {
    });
  })));

  it("createDraft", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.createDraft({}).subscribe((res) => {
    });
  })));

  it("getAllIdisRulePrioritySequence", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllIdisRulePrioritySequence({}).subscribe((res) => {
    });
  })));

  it("getTradingPartnerPlatformsByTPId", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getTradingPartnerPlatformsByTPId({}).subscribe((res) => {
    });
  })));

  it("getFileEmployerAssoc", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getFileEmployerAssoc({}).subscribe((res) => {
    });
  })));

  it("getFileVersionDetails", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getFileVersionDetails({}).subscribe((res) => {
    });
  })));

  it("restoreTemplate", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.restoreTemplate({}).subscribe((res) => {
    });
  })));

  it("getDynamicSchemaGeneration", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getDynamicSchemaGeneration({}).subscribe((res) => {
    });
  })));

  it("getAttrMappingData", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAttrMappingData({}).subscribe((res) => {
    });
  })));

  it("getMappedColumns", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getMappedColumns({}).subscribe((res) => {
    });
  })));

  it("saveMappedColumns", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.saveMappedColumns({}).subscribe((res) => {
    });
  })));

  it("getChildrenAttr", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getChildrenAttr({}).subscribe((res) => {
    });
  })));

  it("getLookupTables", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getLookupTables({}).subscribe((res) => {
    });
  })));

  it("cloneRecords", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.cloneRecords({}).subscribe((res) => {
    });
  })));

  it("saveCloneRecords", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.saveCloneRecords({}).subscribe((res) => {
    });
  })));

  it("deleteClone", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.deleteClone({}).subscribe((res) => {
    });
  })));

  it("getFileVersion", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getFileVersion({}).subscribe((res) => {
    });
  })));

  it("copyConfig", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.copyConfig({}).subscribe((res) => {
    });
  })));


  it("deleteFileDraft", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.deleteFileDraft({}).subscribe((res) => {
    });
  })));


  it("getAllPromotions", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getAllPromotions({}).subscribe((res) => {
    });
  })));

  it("savePromotions", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.savePromotions({}).subscribe((res) => {
    });
  })));

  it("getSectionwiseDynamicSchema", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getSectionwiseDynamicSchema({}).subscribe((res) => {
    });
  })));

  it("getDynamicSchemaByParentId", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.getDynamicSchemaByParentId({}).subscribe((res) => {
    });
  })));

  it("updateMappedDynamicSchemaColumns", async(inject([FileSetupService], (contactService) => {
    let response = require("../../../../assets/test-data/blank.json");
    contactService.updateMappedDynamicSchemaColumns({}).subscribe((res) => {
    });
  })));

});