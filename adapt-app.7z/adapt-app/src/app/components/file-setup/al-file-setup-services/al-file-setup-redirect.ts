import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable()
export class FileSetupRedirect {

  private _route = new BehaviorSubject("F");
  defaultRoute = this._route.asObservable();

  constructor() { }

  changeRoute(message: string) {
    this._route.next(message);
  }

}