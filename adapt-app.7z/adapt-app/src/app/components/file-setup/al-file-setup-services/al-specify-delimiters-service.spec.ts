import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { SpecifyDelimitersService } from "./al-specify-delimiters-service";
import { TOKEN_NAME } from "../../login/login.constant";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: SpecifyDelimitersService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                SpecifyDelimitersService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getFileNodeDelimiter", async(inject([SpecifyDelimitersService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getFileNodeDelimiter({}).subscribe((res) => {
        });
    })));

    it("saveFileNodeDelimiter", async(inject([SpecifyDelimitersService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.saveFileNodeDelimiter({}).subscribe((res) => {
        });
    })));

    it("getDelimiterAndTerminator", async(inject([SpecifyDelimitersService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getDelimiterAndTerminator({}).subscribe((res) => {
        });
    })));

});