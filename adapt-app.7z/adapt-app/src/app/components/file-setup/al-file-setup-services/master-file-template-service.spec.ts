import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { MasterFileTemplateService } from "./master-file-template-service";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: MasterFileTemplateService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                MasterFileTemplateService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getAllMasterFiles", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAllMasterFiles({}).subscribe((res) => {
        });
    })));

    it("deleteMasterFile", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.deleteMasterFile({}).subscribe((res) => {
        });
    })));

    it("getFileType", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getFileType({}).subscribe((res) => {
        });
    })));

    it("masterTemplateCreate", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.masterTemplateCreate({}).subscribe((res) => {
        });
    })));

    it("editMasterFile", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.editMasterFile({}).subscribe((res) => {
        });
    })));

    it("updateMasterTemplate", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.updateMasterTemplate({}).subscribe((res) => {
        });
    })));

    it("getAttributeList", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAttributeList({}).subscribe((res) => {
        });
    })));

    it("getAllAttributes", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAllAttributes({}).subscribe((res) => {
        });
    })));

    it("getAllMasterAttributes", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAllMasterAttributes({}).subscribe((res) => {
        });
    })));

    it("getAttributeMappingRules", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAttributeMappingRules({}).subscribe((res) => {
        });
    })));

    it("createAttributeMapping", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.createAttributeMapping({}).subscribe((res) => {
        });
    })));

    it("removeAttribute", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.removeAttribute({}).subscribe((res) => {
        });
    })));

    it("updateMasterAttribute", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.updateMasterAttribute({}).subscribe((res) => {
        });
    })));

    it("updateStatus", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.updateStatus({}).subscribe((res) => {
        });
    })));

    it("getCurrentStatus", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getCurrentStatus({}).subscribe((res) => {
        });
    })));

    it("getMasterVersionHistory", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getMasterVersionHistory({}).subscribe((res) => {
        });
    })));

    it("getAllgetAttributeStandarizedNameListByFileTypeIdMasterFiles", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getAttributeStandarizedNameListByFileTypeId({}).subscribe((res) => {
        });
    })));

    it("getPackageInfoByFileTypeId", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.getPackageInfoByFileTypeId({}).subscribe((res) => {
        });
    })));

    it("updateMasterTemplateAndAttributeMapping", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.updateMasterTemplateAndAttributeMapping({}).subscribe((res) => {
        });
    })));

    it("createDraft", async(inject([MasterFileTemplateService], (contactService) => {
        let response = require("../../../../assets/test-data/blank.json");
        contactService.createDraft({}).subscribe((res) => {
        });
    })));

});