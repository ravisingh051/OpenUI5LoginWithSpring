import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from "@angular/core";
import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { TOAST_SETTING } from "../../../global";
import { NgxPermissionsService } from "ngx-permissions";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "al-promotions",
  templateUrl: "./al-promotions.component.html",
  styleUrls: ["./al-promotions.component.css"]
})
export class AlPromotionsComponent implements OnInit {
  promotionList = [];
  promotionNote;
  isClickedOnPromotionAdd: boolean = false;
  showPromotionDialogue: boolean = false;
  tableDataLoading: boolean = false;
  alertOnPromoteSameVersionFile: boolean = false;
  @Output("tabLoader") tabLoader = new EventEmitter();
  @Input() metaInfo;
  @Input() viewOnly;
  disableSaveBtn: boolean = false;
  isHereByClickedOnPromotion: boolean = false;

  promotionTooltip: any = [];
  tooltipResult: any;
  pageID: number = 28;

  constructor(private fileSetupService: FileSetupService,
    private toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService,
    private permissionsService: NgxPermissionsService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.isHereByClickedOnPromotion = Number(params["tab"]) === 10 ? true : false;
    });
    this.getAllPromotions();
    this.getToolTipTextDetails();
  }

  getAllPromotions() {
    this.tabLoader.emit(true);
    this.tableDataLoading = true;
    this.fileSetupService.getAllPromotions(this.metaInfo.fileIdGenerator.fileId).subscribe(res => {
      if (!res.error) {
        this.promotionList = res.data;
        this.tableDataLoading = false;
        this.tabLoader.emit(false);
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Promotions.", "Oops!", TOAST_SETTING);
    });
  }

  promotion: any;
  alertMessage: string;
  onClickPromote() {
    if (this.selectedRowData.configPromotionStatusName === "Pending Approval" || this.selectedRowData.configPromotionStatusId === 1) {
      this.alertOnPromoteSameVersionFile = true;
      this.alertMessage = "There is a promotion request pending for the same file and target environment. Please approve/reject the previous request first.";
    } else {
      this.promotion = this.selectedRowData;
      if (this.metaInfo.fileStatus === "Training" && this.promotion.targetEnvAbbrName === this.promotion.promotionTrainigInvalidEnvironment) {
        this.alertOnPromoteSameVersionFile = true;
        this.alertMessage = "Training files can never be promoted to production environment.";
      } else {
        this.showPromotionDialogue = true;
      }

    }
  }

  savePromotion() {
    this.disableSaveBtn = true;
    const promoteObj = {
      targetEnv: {
        id: this.promotion.targetEnvId,
        name: this.promotion.targetEnvName,
        abbreviation: this.promotion.targetEnvAbbrName
      },
      sourceEnv: {
        id: null
      },
      promotionNotes: this.promotionNote,
      promotionStatus: {
        configPromotionStatusId: 1 // Id of config_promotion_status table for 'Pending Approval' status
      },
      fileId: this.metaInfo.fileIdGenerator.fileId,
      fileVersion: this.metaInfo.fileVersion,
      fileIdentifier: this.metaInfo.recordId,
      wasMasterPromoted: false,
      masterId: this.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateId,
      masterVersion: this.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateVersion
    };

    this.fileSetupService.savePromotions(promoteObj).subscribe(res => {
      if (!res.error) {
        this.closeDialogue();
        this.promotionList = res.data;
        this.toastr.success("Migration added successfully.", "Success!");
      } /* istanbul ignore next */ else {
        this.closeDialogue();
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.disableSaveBtn = false;
    }, /* istanbul ignore next */ error => {
      this.closeDialogue();
      this.toastr.error("Server Error in saving Promotions.", "Oops!", TOAST_SETTING);
      this.disableSaveBtn = false;
    });
  }

  onClickCancel() {
    this.showPromotionDialogue = false;
    this.promotionNote = null;
    this.isClickedOnPromotionAdd = false;
  }

  closeDialogue() {
    this.showPromotionDialogue = false;
    this.promotionNote = null;
    this.isClickedOnPromotionAdd = false;
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.promotionTooltip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.promotionTooltip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  actionPannel: OverlayPanel;
  selectedRowData: any;
  rowAction(event, overlaypanel, rowData) {
    this.actionPannel = overlaypanel;
    this.actionPannel.toggle(event);
    this.selectedRowData = rowData;
  }

  withdrawPromotionRequest() {
    const obj = {
      configPromotionAuditId: this.selectedRowData.configPromotionAuditId,
      fileId: this.metaInfo.fileIdGenerator.fileId
    };

    this.fileSetupService.withdrawPromotionRequest(obj).subscribe(res => {
      if (!res.error) {
        this.actionPannel.hide();
        this.promotionList = res.data;
        this.toastr.success("Promotion withdrawn successfully", "Success!");
      }
      else {
        this.actionPannel.hide();
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.actionPannel.hide();
      this.toastr.error("Server error in withdrawing promotion request.", "Oops!", TOAST_SETTING);
      this.disableSaveBtn = false;
    });
  }
}
