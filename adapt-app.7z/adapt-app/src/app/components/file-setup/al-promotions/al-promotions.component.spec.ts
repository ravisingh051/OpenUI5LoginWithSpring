import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlPromotionsComponent } from "./al-promotions.component";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, ConfirmDialogModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { ConfirmationService } from "primeng/components/common/api";
import { DatePipe } from "@angular/common";
import { TemplateRef, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { RescheduleService } from "../../../services/common/reschedule";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

let metaInfo;

describe("AlPromotionsComponent", () => {
  let component: AlPromotionsComponent;
  let fixture: ComponentFixture<AlPromotionsComponent>;
  let filesetupService;
  function populateData() {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/metaInfo.json");
    metaInfo = response.data;
    return metaInfo;
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        ConfirmDialogModule,
        DialogModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlPromotionsComponent, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        ConfirmationService,
        RescheduleService,
        { provide: FileSetupService, useClass: MockDataService },
        { provide: USE_PERMISSIONS_STORE },
        { provide: ToolTipUtilService, useClass: FakeToolTip },
        { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1, version: 1, tab: 10 }) } }
      ]
    });
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(AlPromotionsComponent);
      component = fixture.debugElement.componentInstance;
      component.metaInfo = populateData();
      filesetupService = fixture.debugElement.injector.get(FileSetupService);
      fixture.detectChanges();
    });
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should onInit error", () => {
    spyOn(filesetupService, "getAllPromotions").and.returnValue(Observable.throw("No Data"));
    component.ngOnInit();
  });
  it("should onClickPromote", () => {
    let rowData = require("../../../../assets/test-data/file-setup/al-promotions/get.json");
    component.promotion = require("../../../../assets/test-data/file-setup/al-promotions/get.json");
    component.selectedRowData = "Pending Approval";
    component.onClickPromote();
  });

  it("should savePromotion", () => {
    let response = require("../../../../assets/test-data/file-setup/al-promotions/get.json");
    let OverlayPanel = {
      hide: () => { },
      toggle: (el) => { }
    };
    component.selectedRowData = { configPromotionAuditId: 1 };
    component.rowAction(event, OverlayPanel, component.selectedRowData);
    component.promotion = response.data[0];
    component.savePromotion();
    spyOn(filesetupService, "savePromotions").and.returnValue(Observable.throw("No Data"));
    component.savePromotion();
    component.withdrawPromotionRequest();
    spyOn(filesetupService, "withdrawPromotionRequest").and.returnValue(Observable.throw("No Data"));
    component.withdrawPromotionRequest();
  });

  it("should onClickCancel", () => {
    component.onClickCancel();
  });

  it("should promoteAgain", () => {
    let row = {
      fileVersion: 12
    };
  });
  it("should promoteAgain else", () => {
    let row = {
      fileVersion: 11
    };
  });
  it("should and displayToolTipText()", () => {
    component.promotionTooltip = {
      "Promotion Comments": {
        "tooltipDesc": "Promotion Comments description",
        "readMoreLink": "http://www.google.com"
      }
    };
    fixture.detectChanges();
    let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));


    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Promotion Comments", "bottom");
      fixture.detectChanges();
      component.hideToolTipText(event);
      fixture.detectChanges();
      component.hideToolTipText(event);
    });
    btnNextStep.click();
    fixture.detectChanges();
  });
});

class MockDataService {
  getAllPromotions(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-promotions/get.json");
    return (Observable.of(response));
  }
  getPageAndFieldsDetails(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-promotions/toolTipPageDetails.json");
    return (Observable.of(response));
  }
  savePromotions(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-promotions/toolTipPageDetails.json");
    return (Observable.of(response));
  }
  withdrawPromotionRequest(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-promotions/toolTipPageDetails.json");
    return (Observable.of(response));
  }
}
export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
