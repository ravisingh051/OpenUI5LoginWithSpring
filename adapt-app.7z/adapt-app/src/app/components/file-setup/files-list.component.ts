import { Component, OnInit } from "@angular/core";

@Component({
  selector: "al-file-setup",
  templateUrl: "./files-list.component.html",
  styleUrls: ["./files-list.component.scss"],
})
export class FilesListComponent implements OnInit {
  constructor() { }

    ngOnInit() {
    }
}
