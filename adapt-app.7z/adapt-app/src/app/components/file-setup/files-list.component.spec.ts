import { async, ComponentFixture, TestBed } from "@angular/core/testing";

// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { FilesListComponent } from "./files-list.component";
import { FilesSetupSidebarComponent } from "./sidebar/al-file-setup-sidebar";
import { FilesSetupListComponent } from "../file-setup/al-file-setup-list/al-file-setup-list.component";
import { FileSetupService } from "./al-file-setup-services/file-setup.service";
import { ToolTipUtilService } from "../../services/common/toolTipUtil";
import { FileSetupRedirect } from "./al-file-setup-services/al-file-setup-redirect";
import { RouterDetailsService } from "../../services/common/router.details";
import { LoginService } from "./../login/login.service";
import { ApiEnvService } from "../../env.service";

// VENDOR IMPORTS
// =========================
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { ShowLinkBasedOnEmpAccessDirective } from "./../../show-link-based-on-emp-access/show-link-based-on-emp-access.directive";

// COMPONENT
// =========================
import { AlPopOverModule } from "./../../sharedModules/al-popover/al-popover.module";
import { TOKEN_NAME } from "./../login/login.constant";
import { AppUtility } from "../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [];

describe("FilesListComponent", () => {
  let component: FilesListComponent;
  let fixture: ComponentFixture<FilesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        RouterTestingModule.withRoutes(routes),
        RouterModule.forRoot(routes, { useHash: true }),
        NgxPermissionsModule,
        ToastModule,
        HttpClientTestingModule
      ],
      declarations: [FilesListComponent, FilesSetupListComponent, FilesSetupSidebarComponent, ShowLinkBasedOnEmpAccessDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ApiEnvService,
        ToastsManager,
        RouterDetailsService,
        LoginService,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        { provide: FileSetupService, useClass: MockDataService },
        { provide: FileSetupRedirect, useClass: MockDataService },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilesListComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});

class MockDataService {
  getFiles(): Observable<any> {
    let response = {
      data: {
        value: true
      }
    };
    return (Observable.of(response));
  }
}
