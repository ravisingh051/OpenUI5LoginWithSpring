import { Component, OnInit, ViewChild } from "@angular/core";
import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { ToastsManager } from "ng2-toastr";
import { Router, ActivatedRoute } from "@angular/router";
import { MasterFileTemplateService } from "../al-file-setup-services/master-file-template-service";
import { NgxPermissionsService } from "ngx-permissions";
import { ConfirmationService } from "primeng/components/common/api";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { RouterDetailsService } from "../../../services/common/router.details";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { LoginService } from "../../login/login.service";
import { NgForm } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { LobService } from "../../commons/al-lob/al-lob-services/lob.service";
import { TOAST_SETTING } from "../../../global";
import { ExcelDownloadService } from "./al-file-setup-export-services/al-file-setup.export.services";

@Component({
  selector: "al-file-setup-list",
  templateUrl: "./al-file-setup-list.component.html",
  styleUrls: ["./al-file-setup-list.component.scss"],
  providers: [MasterFileTemplateService, ConfirmationService, ToolTipUtilService, LobService, ExcelDownloadService]
})
export class FilesSetupListComponent implements OnInit {

  files: any = [];
  exportMasterData: any = [];
  exportFileData: any = [];
  masterFiles: any = [];
  selectedRowId: any;
  latestRecordId: any;
  latestVersion: any;
  selectedFileId: any;
  version: any;
  approvalStatus: any;
  rClientName: any;
  markAsTemplate: any;
  fileList: any = {};
  selectedPanel: any;
  mfDataLoader: boolean;
  fDataLoader: boolean;
  tab_0: boolean = false;
  tab_1: boolean = false;

  acceptLabel: string = "Yes";
  rejectLabel: string = "No";

  analystName: string = "";
  analystEmail: string = "";

  /* ToolTip display OnMouse Over */
  masterTemplateToolTipTex: any = [];
  fileTemplateToolTipTex: any = [];
  tooltipResult: any;
  masterTemplatePageID: number = 9;
  filePageID: number = 11;
  clientId: Array<string> = [];
  activeVersion: any;

  tradingPtnrList: Array<any> = [];
  lobList: Array<any> = [];
  sourceTradingPartnerName: string;
  sourceLobName: string;

  constructor(
    private fileSetupService: FileSetupService,
    public toastr: ToastsManager,
    private masterFileService: MasterFileTemplateService,
    private router: Router,
    private permissionsService: NgxPermissionsService,
    private confirmationService: ConfirmationService,
    private FileSetupRedirect: FileSetupRedirect,
    private routerDetailsService: RouterDetailsService,
    private loginService: LoginService,
    private excelDownloadService: ExcelDownloadService,
    private toolTipUtils: ToolTipUtilService,
    private lobService: LobService
  ) {
    this.mfDataLoader = true;
    this.fDataLoader = true;
  }

  fileRedirect: string;
  $routes: any = {};


  ngOnInit() {
    let getTabRole_0 = this.permissionsService.getPermission("Master File Setup-View All Master list");
    let getTabRole_1 = this.permissionsService.getPermission("File Setup-View All File list");
    if (getTabRole_0 !== undefined) {
      this.tab_0 = true;
    }
    else if (getTabRole_1 !== undefined) {
      this.tab_1 = true;
    }
    this.getToolTipTextDetails(this.masterTemplatePageID);
    this.getToolTipTextDetails(this.filePageID);
    this.getAllFiles();
    this.getAllMasterFiles();

    this.loginService.getMail.subscribe((value) => {
      this.analystEmail = value;
    });

    this.routerDetailsService.getRouteDetails.subscribe((routes) => {
      this.$routes = routes;
    });
    this.FileSetupRedirect.defaultRoute.subscribe($route => {
      this.fileRedirect = $route;
      this.setSelectedTab();
    });
  }

  setSelectedTab() {
    this.tab_0 = false;
    this.tab_1 = true;
    this.selectedTabIndex = 1;
  }

  getAllFiles() {
    this.fDataLoader = true;
    this.fileSetupService.getFiles().subscribe(res => {
      if (!res.error) {
        this.files = res.data;
        for (let rData of res.data) {
          rData["tpData"] = rData.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerName;
          rData["lobData"] = rData.fileTradingPartnerLobAssoc[0].lob.lobName;
          if (rData.fileVersion === 1 && !rData.active && (rData.approvalStatus === 1 || rData.approvalStatus === 2)) {
            rData["activeVersion"] = 0;
          } else {
            rData["activeVersion"] = rData.fileVersion;
          }
          let clientName = rData.clientName;
          if (clientName !== null && clientName !== undefined) {
            rData["clientNameOld"] = rData.clientName;
            rData["clientName"] = clientName.substring(2, clientName.length).replace(/,@@/g, ", ");
          }
        }
        this.exportFileData = this.files;
        this.setFileFilter();
      }
      this.fDataLoader = false;
    }, error => {
      this.toastr.error("Server Error in getting file list.", "Oops!", TOAST_SETTING);
    });
  }
  getAllMasterFiles() {
    this.mfDataLoader = true;
    this.masterFileService.getAllMasterFiles().subscribe(res => {
      if (!res.error) {
        this.masterFiles = res.data;
      }
      this.exportMasterData = this.masterFiles;
      this.setMTFilter();
      this.mfDataLoader = false;
    }, error => {
      this.toastr.error("Server Error in getting file list.", "Oops!", TOAST_SETTING);
    });
  }

  //  Edit Master file - versioning change
  editMasterFile(overlaypanel) {
    overlaypanel.hide();
    if (this.approvalStatus === 3) {
      this.confirmationService.confirm({
        message: "Edit template will add a draft version for this template, click Yes if you want to continue with adding the draft version? Click No if you do not want to create draft version, and then use 'View template' action",
        accept: () => {
          let mftData = {
            "masterFileTemplateVersion": this.version,
            "masterFileTemplateId": this.selectedRowId,
            "fileTypeMetaInfo": {
              "fileTypeName": this.fileList.SelectedRowData.fileTypeMetaInfo.fileTypeName
            }
          };
          this.masterFileService.createDraft(mftData).subscribe(res => {
            if (!res.error) {
              let data = this.fileList.SelectedRowData;
              this.router.navigate(["/master", this.selectedRowId, this.version + 1]);
            }
          });
        },
        reject: () => {
          // this.btnClicked=false;
          return false;
        }
      });
    } else {
      this.selectedPanel.toggle(this.fileList.selectedRowEvent);
      let data = this.fileList.SelectedRowData;
      this.router.navigate(["/master", this.selectedRowId, this.version]);
    }
  }
  // View Master File
  viewMasterFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    let data = this.fileList.SelectedRowData;
    this.router.navigate(["/master", this.selectedRowId, this.version, "view"]);
  }

  approveMasterFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    let data = this.fileList.SelectedRowData;
    this.router.navigate(["/master", this.selectedRowId, this.version]);
  }

  removeMasterFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    this.masterFileService.deleteMasterFile(this.selectedRowId).subscribe(res => {
      if (!res.error) {
        this.getAllMasterFiles();
      }
    }, error => {
      this.toastr.error("Server Error in removing master file.", "Oops!", TOAST_SETTING);
    });
  }
  editFile(overlaypanel) {
    overlaypanel.hide();
    if (this.approvalStatus === 3) {
      this.fileList.SelectedRowData;
      this.confirmationService.confirm({
        message: "Edit template will add a draft version for this template, click Yes if you want to continue with adding the draft version? Click No if you do not want to create draft version, and then use 'View template' action",
        accept: () => {
          let cftData = {
            "fileVersion": this.version,
            "fileIdGenerator": {
              "fileId": this.selectedFileId
            }
          };
          this.fileSetupService.createDraft(cftData).subscribe(res => {
            if (!res.error) {
              let data = this.fileList.SelectedRowData;
              this.router.navigate(["/create", res.data, this.version + 1, 0]);
            }
          }, error => {
            let errorMsg = error.error.message;
            let draftCreated = "DRAFT_CREATED";
            if (errorMsg === draftCreated) {
              this.toastr.error("The file you are trying to edit is already in draft mode. This could be because another user is editing the same file. Please refresh the page and try again.", "Oops!", TOAST_SETTING);
            }
            else {
              this.toastr.error(errorMsg, "Oops!", TOAST_SETTING);
            }
          });

        },
        reject: () => {
          // this.btnClicked=false;
          return false;
        }
      });
    } else {
      this.selectedPanel.toggle(this.fileList.selectedRowEvent);
      let data = this.fileList.SelectedRowData;
      this.router.navigate(["/create", this.latestRecordId, this.latestVersion, 0]);
    }
  }
  viewFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    let data = this.fileList.SelectedRowData;
    this.router.navigate(["/create", this.selectedRowId, this.version, 0, "view"]);
  }
  approveFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    let data = this.fileList.SelectedRowData;
    this.router.navigate(["/create", this.selectedRowId, this.version, 9]);
  }

  rowActions(event, rowData, index, overlaypanel: OverlayPanel) {
    const cids = rowData.clientId.split(",");
    this.clientId = cids;
    overlaypanel.toggle(event);
    this.fileList.selectedRowEvent = event;
    this.selectedPanel = overlaypanel;
    this.selectedRowId = rowData.recordId;
    this.latestRecordId = rowData.latestRecordId;
    this.latestVersion = rowData.latestFileVersion;
    this.selectedFileId = rowData.fileIdGenerator.fileId;
    this.version = rowData.fileVersion;
    this.rClientName = rowData.clientName;
    this.markAsTemplate = rowData.isTemplate;
    if (rowData.currentApprovalStatus !== 0) {
      this.approvalStatus = rowData.currentApprovalStatus;
    } else {
      this.approvalStatus = rowData.approvalStatus;
    }
    this.fileList.SelectedRowData = rowData;
  }

  rowActionMaster(event, rowData, index, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.fileList.selectedRowEvent = event;
    this.selectedPanel = overlaypanel;
    this.selectedRowId = rowData.masterFileTemplateId;

    this.version = rowData.masterFileTemplateVersion;
    if (rowData.currentApprovalStatus !== 0) {
      this.approvalStatus = rowData.currentApprovalStatus;
    }
    else {
      this.approvalStatus = rowData.approvalStatus;
    }
    this.fileList.SelectedRowData = rowData;
  }

  fileVersion: boolean = false;
  versionTitle: string = "";
  versionTplName: string;
  versionData: any = [];

  viewVersion(overlaypanel: OverlayPanel) {
    this.versionData = [];
    let selVersionData: any = this.fileList.SelectedRowData;
    this.versionTitle = "File";
    this.versionTplName = selVersionData.fileName;
    this.fileSetupService.getFileVersionDetails(selVersionData.fileIdGenerator.fileId).subscribe(res => {
      if (!res.error) {
        if (selVersionData.currentApprovalStatus !== 0) {
          this.versionData = res.data;
        }
        else {
          if (res.data.length > 0) {
            res.data.shift();
          }
          this.versionData = res.data;
        }
        this.fileVersion = true;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error getting version details.", "Oops!", TOAST_SETTING);
    });
    overlaypanel.hide();

  }
  versionRData: any;
  viewTemplateFn(event, rData, viewTemplate: OverlayPanel) {
    viewTemplate.show(event);
    this.versionRData = rData;
  }

  navigateToPage(viewTemplate: OverlayPanel) {
    viewTemplate.hide();
    this.router.navigate(["/create", this.versionRData.recordId, this.versionRData.fileVersion, 0, "view"]);
  }

  versionLoader: boolean = false;
  restoreTemplate(viewTemplate: OverlayPanel) {
    viewTemplate.hide();
    let tmpVersion = this.versionRData.fileVersion;

    this.confirmationService.confirm({
      message: "Are you sure that you want to restore the version " + tmpVersion + " approved on " + this.versionRData.approvedDate + "? If you click on 'yes', then System will restore all configuration for the template and template will be in Draft mode. If you don't want to restore, click on 'No'.",
      accept: () => {
        this.versionLoader = true;
        this.restoreFile();
      },
      reject: () => {
        return false;
      }
    });
  }

  restoreFile() {
    this.fileSetupService.restoreTemplate(this.versionRData.fileId, this.versionRData.fileVersion).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Version has been restored successfully !");
        this.router.navigate(["/create", res.data.recordId, res.data.fileVersion, 0]);
      }
      else {
        this.versionLoader = false;
        this.fileVersion = false;
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.versionLoader = false;
      this.fileVersion = false;
      this.toastr.error("Server Error to restore the version.", "Oops!", TOAST_SETTING);
    });
  }


  // File Table Filter Function : START
  fileFilter: any = {};
  fileModel: any = {};
  setFileFilter() {
    let _fileFilter = {};
    if (this.files !== null) {
      _fileFilter["id"] = [];
      _fileFilter["isTemplate"] = [];
      _fileFilter["fileName"] = [];
      _fileFilter["mftName"] = [];
      _fileFilter["fileType"] = [];
      _fileFilter["tp"] = [];
      _fileFilter["lob"] = [];
      _fileFilter["analystName"] = [];
      _fileFilter["interfaceGroup"] = [];
      _fileFilter["status"] = [];
      _fileFilter["aStatus"] = [];
      _fileFilter["clientName"] = [];

      for (let i = 0; i < this.files.length; i++) {
        if (_fileFilter["id"].indexOf(this.files[i].fileIdGenerator.fileId) === -1) {
          _fileFilter["id"].push(this.files[i].fileIdGenerator.fileId);
        }

        if (_fileFilter["isTemplate"].indexOf(this.files[i].isTemplate) === -1) {
          _fileFilter["isTemplate"].push(this.files[i].isTemplate);
        }

        if (_fileFilter["fileName"].indexOf(this.files[i].fileName) === -1) {
          _fileFilter["fileName"].push(this.files[i].fileName);
        }

        if (_fileFilter["mftName"].indexOf(this.files[i].masterFileTemplateMetaInfo.masterFileTemplateName) === -1) {
          _fileFilter["mftName"].push(this.files[i].masterFileTemplateMetaInfo.masterFileTemplateName);
        }

        if (_fileFilter["fileType"].indexOf(this.files[i].fileTypeMetaInfo.fileTypeName) === -1) {
          _fileFilter["fileType"].push(this.files[i].fileTypeMetaInfo.fileTypeName);
        }
        if (_fileFilter["tp"].indexOf(this.files[i].tpData) === -1) {
          _fileFilter["tp"].push(this.files[i].tpData);
        }
        if (_fileFilter["lob"].indexOf(this.files[i].lobData) === -1) {
          _fileFilter["lob"].push(this.files[i].lobData);
        }
        if (_fileFilter["analystName"].indexOf(this.files[i].analystName) === -1) {
          _fileFilter["analystName"].push(this.files[i].analystName);
        }
        if (_fileFilter["interfaceGroup"].indexOf(this.files[i].interfaceGroup) === -1) {
          _fileFilter["interfaceGroup"].push(this.files[i].interfaceGroup);
        }
        if (_fileFilter["status"].indexOf(this.files[i].fileStatus) === -1) {
          _fileFilter["status"].push(this.files[i].fileStatus);
        }
        if (_fileFilter["aStatus"].indexOf(this.files[i].currentApprovalStatus) === -1) {
          _fileFilter["aStatus"].push(this.files[i].currentApprovalStatus);
        }

        if (this.files[i].clientNameOld !== null && this.files[i].clientNameOld !== undefined) {
          let clientNames = this.getFilteredClientNames(this.files[i].clientNameOld);
          for (let j = 0; j < clientNames.length; j++) {
            if (_fileFilter["clientName"].indexOf(clientNames[j]) === -1) {
              _fileFilter["clientName"].push(clientNames[j]);
            }
          }
        }

      }
    }

    this.fileFilter.id = [{ label: "All", value: null }];
    for (let value of _fileFilter["id"].sort((a, b) => a - b)) {
      this.fileFilter.id.push({ label: value, value: value });
    }

    this.fileFilter.isTemplate = [{ label: "All", value: null }];
    for (let value of _fileFilter["isTemplate"].sort((a, b) => a - b)) {
      let _lable = value === true ? "Yes" : "No";
      this.fileFilter.isTemplate.push({ label: _lable, value: value });
    }

    this.fileFilter.fileName = [{ label: "All", value: null }];
    for (let value of _fileFilter["fileName"].sort()) {
      this.fileFilter.fileName.push({ label: value, value: value });
    }
    this.fileFilter.mftName = [{ label: "All", value: null }];
    for (let value of _fileFilter["mftName"].sort()) {
      this.fileFilter.mftName.push({ label: value, value: value });
    }
    this.fileFilter.fileType = [{ label: "All", value: null }];
    for (let value of _fileFilter["fileType"].sort()) {
      this.fileFilter.fileType.push({ label: value, value: value });
    }
    this.fileFilter.tp = [{ label: "All", value: null }];
    for (let value of _fileFilter["tp"].sort()) {
      this.fileFilter.tp.push({ label: value, value: value });
    }
    this.fileFilter.lob = [{ label: "All", value: null }];
    for (let value of _fileFilter["lob"].sort()) {


      this.fileFilter.lob.push({ label: value, value: value });
    }
    this.fileFilter.analystName = [{ label: "All", value: null }];
    for (let value of _fileFilter["analystName"].sort()) {
      this.fileFilter.analystName.push({ label: value, value: value });
    }
    this.fileFilter.interfaceGroup = [{ label: "All", value: null }];
    for (let value of _fileFilter["interfaceGroup"].sort()) {
      this.fileFilter.interfaceGroup.push({ label: value, value: value });
    }
    this.fileFilter.status = [{ label: "All", value: null }];
    for (let value of _fileFilter["status"].sort()) {
      this.fileFilter.status.push({ label: value, value: value });
    }
    this.fileFilter.aStatus = [{ label: "All", value: null }];
    for (let value of _fileFilter["aStatus"].sort()) {
      let _label;
      if (value === 1) { _label = "Draft"; }
      else if (value === 2) { _label = "Pending Approval"; }
      else if (value === 0) { _label = "Approved"; }
      this.fileFilter.aStatus.push({ label: _label, value: value });
    }
    this.fileFilter.clientName = [{ label: "All", value: null }];
    for (let value of _fileFilter["clientName"].sort()) {
      this.fileFilter.clientName.push({ label: value, value: value });
    }
  }

  // Master Template Table Filter Function : START
  mtFilter: any = {};
  mtModel: any = {};
  setMTFilter() {
    let _mtFilter = {};
    if (this.masterFiles !== null) {
      _mtFilter["id"] = [];
      _mtFilter["mfTemplate"] = [];
      _mtFilter["fileType"] = [];
      _mtFilter["direction"] = [];
      _mtFilter["mtVersion"] = [];
      _mtFilter["status"] = [];
      for (let i = 0; i < this.masterFiles.length; i++) {
        if (_mtFilter["id"].indexOf(this.masterFiles[i].masterFileTemplateId) === -1) {
          _mtFilter["id"].push(this.masterFiles[i].masterFileTemplateId);
        }
        if (_mtFilter["mfTemplate"].indexOf(this.masterFiles[i].masterFileTemplateName) === -1) {
          _mtFilter["mfTemplate"].push(this.masterFiles[i].masterFileTemplateName);
        }
        if (_mtFilter["fileType"].indexOf(this.masterFiles[i].fileTypeMetaInfo.fileTypeName) === -1) {
          _mtFilter["fileType"].push(this.masterFiles[i].fileTypeMetaInfo.fileTypeName);
        }
        if (_mtFilter["direction"].indexOf(this.masterFiles[i].fileTypeMetaInfo.direction) === -1) {
          _mtFilter["direction"].push(this.masterFiles[i].fileTypeMetaInfo.direction);
        }
        if (_mtFilter["mtVersion"].indexOf(this.masterFiles[i].masterFileTemplateVersion) === -1) {
          _mtFilter["mtVersion"].push(this.masterFiles[i].masterFileTemplateVersion);
        }
        if (_mtFilter["status"].indexOf(this.masterFiles[i].currentApprovalStatus) === -1) {
          _mtFilter["status"].push(this.masterFiles[i].currentApprovalStatus);
        }
      }
    }

    this.mtFilter.id = [{ label: "All", value: null }];
    for (let value of _mtFilter["id"].sort((a, b) => a - b)) {
      this.mtFilter.id.push({ label: value, value: value });
    }
    this.mtFilter.mfTemplate = [{ label: "All", value: null }];
    for (let value of _mtFilter["mfTemplate"].sort()) {
      this.mtFilter.mfTemplate.push({ label: value, value: value });
    }
    this.mtFilter.fileType = [{ label: "All", value: null }];
    for (let value of _mtFilter["fileType"].sort()) {
      this.mtFilter.fileType.push({ label: value, value: value });
    }
    this.mtFilter.direction = [{ label: "All", value: null }];
    for (let value of _mtFilter["direction"].sort((a, b) => a - b)) {
      this.mtFilter.direction.push({ label: value, value: value });
    }
    this.mtFilter.mtVersion = [{ label: "All", value: null }];
    for (let value of _mtFilter["mtVersion"].sort((a, b) => a - b)) {
      let _label = value;
      if (value === 0) { _label = "-"; }
      this.mtFilter.mtVersion.push({ label: _label, value: value });
    }
    this.mtFilter.status = [{ label: "All", value: null }];
    for (let value of _mtFilter["status"].sort()) {
      let _label;
      if (value === 1) { _label = "Draft"; }
      else if (value === 2) { _label = "Pending Approval"; }
      else if (value === 0) { _label = "Approved"; }
      this.mtFilter.status.push({ label: _label, value: value });
    }
  }
  // Master Template Table Filter Function : END
  getFilteredClientNames(clientNames) {
    let clientList = clientNames.substring(2, clientNames.length).split(",@@");
    return clientList;
  }
  // File Table Filter Function : END

  getToolTipTextDetails(pageID) {
    if (pageID === this.masterTemplatePageID) {
      this.toolTipUtils.getPageAndFieldsDetails(pageID).subscribe(res => {
        this.masterTemplateToolTipTex = res.data;
      });
    }
    if (pageID === this.filePageID) {
      this.toolTipUtils.getPageAndFieldsDetails(pageID).subscribe(res => {
        this.fileTemplateToolTipTex = res.data;
      });
    }
  }

  copyConfDialog: boolean;
  copyConfElm: any = {};
  copyConfClicked: boolean;
  copyConfLoader: boolean;
  copyConf(overlaypanel: OverlayPanel) {
    overlaypanel.hide();
    this.copyConfDialog = true;
    this.copyConfLoader = true;
    this.getAllTraPtnrAndLob();
    this.getFileVersion();
  }

  getAllTraPtnrAndLob() {
    Observable.forkJoin(
      this.lobService.getLOBList(),
      this.fileSetupService.getTradingPartner()
    ).subscribe(data => {
      this.tradingPtnrList = [];
      this.lobList = [];

      const listOfLobs = data[0].data;
      for (const obj of listOfLobs) {
        this.lobList.push({ label: obj.lobName, value: obj.lobId });
      }
      this.lobList.unshift({
        "label": "Choose One",
        "value": null
      });

      if (data[1].data.length !== 0) {
        for (let obj of data[1].data) {
          if (obj.active) {
            this.tradingPtnrList.push({ label: obj.tradingPartnerName, value: obj.tradingPartnerId });
          }
        }
      };
      this.tradingPtnrList.unshift({
        "label": "Choose One",
        "value": null
      });

      this.copyConfElm.tradingPartnerId = null;
      this.copyConfElm.lobId = null;
      this.copyConfLoader = false;
    });
  }

  fileVersions: any = [];
  getFileVersion() {
    this.fileVersions = [];
    this.fileSetupService.getFileVersion(this.fileList.SelectedRowData.fileIdGenerator.fileId).subscribe(res => {
      if (!res.error) {
        let i = 0;
        for (let _ver of res.data) {
          if (i === (res.data.length - 1)) {
            let _status = "";
            if (_ver.approvalStatus === 1) {
              _status = " - Draft";
            } else if (_ver.approvalStatus === 2) {
              _status = " - Pending Approval";
            }
            _ver.label = _ver.fileVersion + _status;
          } else {
            _ver.label = _ver.fileVersion;
          }
          _ver.value = _ver.fileVersion;
          i++;
        }
        this.fileVersions = res.data.reverse();
        this.copyConfElm.fileVersion = this.fileVersions[0].fileVersion;
        this.setcopyConfData();
      }
    }, error => {
      this.toastr.error("Server Error getting file version.", "Oops!", TOAST_SETTING);
    });
  }

  selFileVersionData: any = {};
  setcopyConfData() {
    let _selFileVersionData = this.fileVersions.filter((obj) => obj.fileVersion === this.copyConfElm.fileVersion);
    this.selFileVersionData = _selFileVersionData[0];
    this.copyConfElm.fileDescription = this.selFileVersionData.fileName;
    // this.copyConfElm.transmissionName = this.selFileVersionData.fileTransmissionName;
    this.sourceTradingPartnerName = this.selFileVersionData.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerName;
    this.sourceLobName = this.selFileVersionData.fileTradingPartnerLobAssoc[0].lob.lobName;
    this.copyConfElm.tradingPartnerId = null;
    this.copyConfElm.lobId = null;
  }

  copyConfSubmit(form: NgForm) {
    this.copyConfClicked = true;
    let data = {
      "fileName": form.value.fileDescription,
      // "transmissionName": form.value.transName,
      "analystEmail": this.analystEmail,
      "tradingPartnerId": form.value.tradingPartnerId,
      "lobId": form.value.lobId
    };

    this.fileSetupService.copyConfig(this.fileList.SelectedRowData.fileIdGenerator.fileId, form.value.fileVersion, data).subscribe(res => {
      if (!res.error) {
        if (form.value.redirectToCopy === true) {
          this.router.navigate(["/create/", res.data.recordId, res.data.fileVersion, 0]);
        } else {
          let _files = res.data;
          _files["tpData"] = _files.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerName;
          _files["lobData"] = _files.fileTradingPartnerLobAssoc[0].lob.lobName;
          if (_files.fileVersion === 1 && !_files.active && (_files.approvalStatus === 1 || _files.approvalStatus === 2)) {
            _files["activeVersion"] = 0;
          } else {
            _files["activeVersion"] = _files.fileVersion;
          }
          this.files.push(_files);
          this.files = [...this.files];
          this.setFileFilter();
          this.toastr.success("File copied successfully!");
        }
        this.copyConfDialog = false;
        this.copyConfClicked = false;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.copyConfClicked = false;
      }
    }, error => {
      this.toastr.error("Server Error getting file version.", "Oops!", TOAST_SETTING);
    });
  }

  selectedTabIndex: number = 0;

  setActiveTabIndex(e) {
    this.selectedTabIndex = e.index;
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    if (this.selectedTabIndex === 0) {
      this.tooltipResult = this.masterTemplateToolTipTex[value];
    } else if (this.selectedTabIndex === 1) {
      this.tooltipResult = this.fileTemplateToolTipTex[value];
    }
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // function to delete draft version of file
  deleteFileDraft() {
    let rowData = this.fileList.SelectedRowData;
    let fileId = rowData.fileIdGenerator.fileId;
    let activeVersion = rowData.activeVersion;

    // if activeVersion is 0, delete file entry
    let cnfMessage = null;
    if (activeVersion === 0) {
      cnfMessage = "Discard Draft will result in removing this file permanently. Do you wish to continue with this action?"
        + " Click Yes, if you want to permanently delete this file or Click No, if you want to retain this draft and cancel this action.";
    } else {
      cnfMessage = "Discarding Draft action will remove draft version of this file permanently and file will be restored back to active approved status. "
        + "Are you sure you want to continue with this action? Click Yes, if you want to permanently delete the draft' . Click No, if you want to cancel this action.";
    }
    this.confirmDeleteFileDraft(fileId, cnfMessage, activeVersion);
  }

  confirmDeleteFileDraft(fileId: number, cnfMessage: string, activeVersion: number) {
    this.confirmationService.confirm({
      message: cnfMessage,
      accept: () => {
        this.fileSetupService.deleteFileDraft(fileId).subscribe(res => {
          if (!res.error) {
            this.performFileSuccessActions(activeVersion, fileId);
          } else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        }, error => {
          this.toastr.error("This draft already has a job associated with it and hence it cannot be discarded.", "Oops!", TOAST_SETTING);
        });
      },
      reject: () => {
        return false;
      }
    });
  }

  // show success message and update table if file is deleted successfully
  performFileSuccessActions(activeVersion: number, fileId: number) {
    if (activeVersion === 0) {
      this.toastr.success("Draft version for file " + fileId + " has been discarded and since file had no previous version available, complete file has been discarded.");
      let fileIndex = this.findSelectedFileIndex();
      this.files = this.files.filter((val, i) => i !== fileIndex);
    } else {
      this.toastr.success("Draft version for file " + fileId + " has been discarded and file status have been brought back to Approved with previous file version.");
      this.fileList.SelectedRowData.currentApprovalStatus = 0;
    }
  }

  // get index of currently selected file
  findSelectedFileIndex(): number {
    return this.files.indexOf(this.fileList.SelectedRowData);
  }

  promoteFile() {
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    let data = this.fileList.SelectedRowData;
    this.router.navigate(["/create", this.selectedRowId, this.version, 10]);
  }

  // Create File from master
  createFile(overlaypanel: OverlayPanel) {
    overlaypanel.hide();
    this.selectedPanel.toggle(this.fileList.selectedRowEvent);
    this.router.navigate(["/create", this.selectedRowId]);
  }

  EXCEL_EXTENSION = ".xlsx";
  exportAsExcelFileforFile() {
    let exportFileDataToExcel: any = [];
    if (this.exportFileData != null && this.exportFileData.length > 0) {
      let d = new Date();
      let date = [this.pad(d.getMonth() + 1), this.pad(d.getDate())].join("");
      let year = d.getFullYear().toString().substr(-2);
      let fileName = "ADaPT-FileSetup-File" + date + year + "-" + d.getTime() + this.EXCEL_EXTENSION;
      for (let file of this.exportFileData) {
        status = this.getStatus(file.currentApprovalStatus);
        let fileData = {
          "File ID": file.fileIdGenerator.fileId,
          "Template": file.isTemplate,
          "File Description": file.fileName,
          "Master File Template": file.mftName,
          "File Type": file.fileTypeMetaInfo.fileTypeName,
          "Trading Partner": file.tpData,
          "LOB": file.lobData,
          "Employer Name": file.clientName,
          "Analyst": file.analystName,
          "Interface Group": file.interfaceGroup,
          "File Status": file.fileStatus,
          "Current Approval Status": status
        };
        exportFileDataToExcel.push(fileData);
      }
      this.excelDownloadService.exportAsExcelFile(exportFileDataToExcel, fileName);
    }
  }
  exportAsExcelFileforMaster() {
    let exportMasterDatatoExcel: any = [];
    if (this.exportMasterData != null && this.exportMasterData.length > 0) {
      let d = new Date();
      let date = [this.pad(d.getMonth() + 1), this.pad(d.getDate())].join("");
      let year = d.getFullYear().toString().substr(-2);
      let fileName = "ADaPT-FileSetup-Master" + date + year + "-" + d.getTime() + this.EXCEL_EXTENSION;
      for (let masterData of this.exportMasterData) {
        status = this.getStatus(masterData.currentApprovalStatus);
        let data = {
          "ID": masterData.masterFileTemplateId,
          "Template Name": masterData.masterFileTemplateName,
          "File Type": masterData.fileTypeMetaInfo.fileTypeName,
          "Direction": masterData.fileTypeMetaInfo.direction,
          "Active Version": masterData.masterFileTemplateVersion,
          "Current Status ": status
        };
        exportMasterDatatoExcel.push(data);
      }
      this.excelDownloadService.exportAsExcelFile(exportMasterDatatoExcel, fileName);
    }
  }
  pad(s) { return (s < 10) ? "0" + s : s; }
  convertDateFormate(_dt) {
    let _d = _dt;
    _d = _d.split("/");
    return _d[2] + "-" + _d[0] + "-" + _d[1];
  }
  getStatus(data) {
    if (data === 1) { status = "Draft"; }
    else if (data === 2) { status = "Pending Approval"; }
    else if (data === 0) { status = "Approved"; }
    return status;
  }
  onMasterFilter(event) {
    this.exportMasterData = event.filteredValue;
  }
  onFileFilter(event) {
    this.exportFileData = event.filteredValue;
  }
}



