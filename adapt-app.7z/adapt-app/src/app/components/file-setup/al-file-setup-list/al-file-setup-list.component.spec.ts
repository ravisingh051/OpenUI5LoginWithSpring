import { async, ComponentFixture, TestBed, inject } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { TOKEN_NAME } from "../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule, Router, ActivatedRoute } from "@angular/router";
import { APP_BASE_HREF, Location, CommonModule } from "@angular/common";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";

import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { LoginService } from "../../login/login.service";
import { MasterFileTemplateService } from "../al-file-setup-services/master-file-template-service";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { RouterDetailsService } from "../../../services/common/router.details";
import { FilesSetupListComponent } from "./al-file-setup-list.component";
import { ShowLinkBasedOnEmpAccessDirective } from "../../../show-link-based-on-emp-access/show-link-based-on-emp-access.directive";
import { LobService } from "../../commons/al-lob/al-lob-services/lob.service";
import { ExcelDownloadService } from "./al-file-setup-export-services/al-file-setup.export.services";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [
  {
    path: "file-setup",
    component: FilesSetupListComponent
  },
  {
    path: "create",
    component: FilesSetupListComponent
  }
];

describe("FilesSetupListComponent", () => {
  let component: FilesSetupListComponent;
  let fixture: ComponentFixture<FilesSetupListComponent>;
  let toastService, fileSetupService, masterFileService;
  let overlaypanel: OverlayPanel;
  let ngxPermission;
  let location: Location;
  const mockRouter = {
    navigate: jasmine.createSpy("navigate")
  };
  const fakeActivatedRoute = {
    snapshot: { data: {} }
  };

  beforeEach(() => {
    TestBed.overrideComponent(FilesSetupListComponent, {
      set: {
        providers: [
          { provide: FileSetupService, useClass: MockDataService },
          { provide: MasterFileTemplateService, useClass: MockDataService },
          // { provide: FileSetupRedirect, useClass: MockDataService },
          //  { provide: RouterDetailsService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        BrowserAnimationsModule,
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        RouterTestingModule.withRoutes(routes),
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [FilesSetupListComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective, ShowLinkBasedOnEmpAccessDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        AppUtility,
        LoginService,
        ApiEnvService,
        ExcelDownloadService,
        RouterDetailsService,
        FileSetupRedirect,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        { provide: FileSetupService, useClass: MockDataService },
        { provide: LobService, useClass: MockDataService },
        { provide: MasterFileTemplateService, useClass: MockDataService },
        // { provide: FileSetupRedirect, useClass: MockDataService },
        // { provide: RouterDetailsService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: Observable, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService },
        {
          provide: APP_BASE_HREF, useValue: "/"
        },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        // { provide: Router, useValue: mockRouter },

      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(FilesSetupListComponent);
    component = fixture.componentInstance;
    toastService = TestBed.get(ToastsManager);

    ngxPermission = TestBed.get(NgxPermissionsService);
    ngxPermission.addPermission("Master File Setup-View All Master list");
    ngxPermission.addPermission("File Setup-View All File list");

    fileSetupService = fixture.debugElement.injector.get(FileSetupService);
    masterFileService = fixture.debugElement.injector.get(MasterFileTemplateService);

    component.$routes = { "previousUrl": "/file/create" };
    component.$routes.previousUrl.split("/");
    component.setSelectedTab();

    // fixture.detectChanges();

  });

  const $event = {};
  let globalOverlay = <OverlayPanel>{
    toggle: (e) => {
    },
    hide: () => {
    },
    show: (e) => {
    }
  };
  it("should create", () => {
    component.$routes = {
      "previousUrl": "/file/create",
    };
    component.$routes.previousUrl.split("/");
    // fixture.detectChanges();
    expect(component).toBeTruthy();
  });


  it("should be logging user", async(() => {
    component.ngOnInit();
    fixture.detectChanges();
  }));



  it("should be setSelectedTab F", () => {
    component.$routes = {
      "previousUrl": "/file/create",
    };
    component.$routes.previousUrl.split("/");
    component.fileRedirect = "F";
    component.setSelectedTab();

  });

  let masterRowData;
  it("rowActionMaster", () => {
    masterRowData = {
      "masterFileTemplateName": "Inbound Census Master",
      "masterFileTemplateId": 1,
      "masterFileTemplateVersion": 1,
      "fileTypeMetaInfo": {
        "fileTypeName": "Inbound Census",
        "direction": "Inbound"
      },
      "masterFileTemplateRecordId": 1,
      "currentApprovalStatus": 0
    };
    component.rowActionMaster($event, masterRowData, 0, globalOverlay);

  });

  let fileRowData;
  it("rowActions()", () => {

    fileRowData = {
      "recordId": 1784,
      "fileIdGenerator": {
        "fileId": 13
      },
      "fileName": "newfile",
      "fileTypeMetaInfo": {
        "fileTypeName": "Inbound Census",
        "direction": "Inbound"
      },
      "fileVersion": 13,
      "isActive": true,
      "fileStatus": "Active",
      "approvalStatus": 3,
      "fileTradingPartnerLobAssoc": [
        {
          "tradingPartnerInfo": {
            "tradingPartnerName": "Test TP1 July02"
          },
          "lob": {
            "lobName": "Test LOB1 July02_1"
          }
        }
      ],
      "currentApprovalStatus": 1,
      "clientId": "02871",
      "analystName": "Divya",
      "interfaceGroup": "Multiple",
      "clientName": "Brady Corporation",
      "latestRecordId": 3037,
      "latestFileVersion": 14,
      "isTemplate": false,
      "masterFileTemplateMetaInfo": {
        "masterFileTemplateName": "Inbound Census Master",
        "masterFileTemplateId": 1,
        "masterFileTemplateVersion": 1,
        "masterFileTemplateRecordId": 1,
        "fileTypeMetaInfo": {
          "fileTypeName": "Inbound Census",
          "direction": "Inbound"
        }
      },
      "tpData": "Test TP1 July02",
      "lobData": "Test LOB1 July02_1",
      "activeVersion": 13,
      "clientNameOld": "@@Brady Corporation"
    };
    component.rowActions($event, fileRowData, 0, globalOverlay);

  });


  it("viewVersion()", () => {
    component.fileList.SelectedRowData = fileRowData;
    component.viewVersion(globalOverlay);
  });

  it("viewTemplateFn()", () => {
    component.viewTemplateFn($event, fileRowData, globalOverlay);
  });

  it("restoreTemplate()", () => {
    component.versionRData = fileRowData;
    component.selectedPanel = globalOverlay;
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
      params.reject();
    });
    component.selectedRowId = 1;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.viewFile();
    expect(navigateSpy).toHaveBeenCalledWith(["/create", component.selectedRowId, component.version, 0, "view"]);
    component.restoreTemplate(globalOverlay);
  });

  it("navigateToPage()", () => {
    component.versionRData = fileRowData;
    component.navigateToPage(globalOverlay);
  });

  it("onMasterFilter()", () => {
    component.onMasterFilter($event);
  });

  it("onFileFilter()", () => {
    component.onFileFilter($event);
    let _form = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        firstName: "",
        redirectToCopy: true,
        fileVersion: 0
      }
    };
    component.fileList.SelectedRowData = fileRowData;
    component.copyConfSubmit(_form);
  });


  it("copyConfSubmit()", () => {
    component.fileList.SelectedRowData = fileRowData;
    let _form2 = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        firstName: "",
        redirectToCopy: false,
        fileVersion: 0
      }
    };
    component.copyConfSubmit(_form2);
  });

  let data = 2;
  it("getStatus()", () => {
    component.getStatus(data);
  });




  it("createFile()", () => {
    const e = {};
    component.selectedPanel = globalOverlay;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.selectedRowId = 1;
    component.createFile(globalOverlay);
    expect(navigateSpy).toHaveBeenCalledWith(["/create", component.selectedRowId]);
  });

  it("promoteFile()", () => {
    const e = {};
    component.selectedPanel = globalOverlay;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.selectedRowId = 1;
    component.version = 0;
    component.promoteFile();
    expect(navigateSpy).toHaveBeenCalledWith(["/create", component.selectedRowId, component.version, 10]);
  });

  it("performFileSuccessActions()", () => {
    component.performFileSuccessActions(0, 13);
  });

  it("confirmDeleteFileDraft()", () => {
    component.fileList.SelectedRowData = fileRowData;
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
      params.reject();
    });
    component.confirmDeleteFileDraft(13, "delete", 0);
  });

  it("deleteFileDraft()", () => {
    component.fileList.SelectedRowData = fileRowData;
    component.deleteFileDraft();
  });


  it("should be editMasterFile user 2 ", () => {

    component.fileList.SelectedRowData = masterRowData;
    component.approvalStatus = 3;
    component.selectedRowId = 1;
    component.version = 0;
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
      params.reject();
    });
    component.editMasterFile(globalOverlay);
  });


  it("should be editMasterFile user 3", () => {
    component.selectedPanel = globalOverlay;
    component.approvalStatus = 2;
    component.selectedRowId = undefined;
    component.version = undefined;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.editMasterFile(globalOverlay);
    expect(navigateSpy).toHaveBeenCalledWith(["/master", component.selectedRowId, component.version]);
  });

  it("should be viewMasterFile user 4", () => {
    component.selectedPanel = globalOverlay;
    component.selectedRowId = 0;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.viewMasterFile();
    expect(navigateSpy).toHaveBeenCalledWith(["/master", component.selectedRowId, undefined, "view"]);
  });

  it("should be viewMasterFile user 5", () => {
    const e = {};
    component.selectedPanel = globalOverlay;
    component.selectedRowId = 0;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.approveMasterFile();
    expect(navigateSpy).toHaveBeenCalledWith(["/master", component.selectedRowId, undefined]);
  });

  it("should be viewMasterFile user 11", () => {
    component.selectedPanel = globalOverlay;
    component.removeMasterFile();
  });


  it("editFile() If", () => {
    component.approvalStatus = 3;
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
      params.reject();
    });
    component.editFile(globalOverlay);
  });


  it("editFile() Else & approveFile()", () => {
    component.selectedPanel = globalOverlay;
    component.approvalStatus = 2;
    component.selectedRowId = 1;
    component.version = 1;
    component.fileList.SelectedRowData = fileRowData;
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.editFile(globalOverlay);
    expect(navigateSpy).toHaveBeenCalledWith(["/create", undefined, undefined, 0]);
    component.approveFile();
  });


  it("copyConf", () => {
    component.fileList.SelectedRowData = fileRowData;
    component.copyConf(globalOverlay);
  });


  it("should and displayToolTipText()", () => {
    component.fileTemplateToolTipTex = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });

  it("should and displayToolTipText() Master", () => {
    component.selectedTabIndex = 0;
    component.masterTemplateToolTipTex = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });


  it("setActiveTabIndex()", () => {
    let e = {
      index: 0
    };
    component.setActiveTabIndex(e);
  });

  it("restoreFile() 1", () => {
    component.versionRData = fileRowData;

    let restoreTemplate = fixture.debugElement.injector.get(FileSetupService);
    spyOn(restoreTemplate, "restoreTemplate").and.returnValue(Observable.throw("error"));
    component.restoreFile();

  });

  it("restoreFile() & exportAsExcelFileforFile()", () => {
    component.versionRData = fileRowData;
    let restoreTemplate = fixture.debugElement.injector.get(FileSetupService);
    spyOn(restoreTemplate, "restoreTemplate").and.returnValue(Observable.of({ "error": true }));
    component.restoreFile();

    component.exportFileData = [{
      "fileIdGenerator": {
        "fileId": 1
      },
      "isTemplate": true,
      "fileName": "abc",
      "mftName": "xyz",
      "fileTypeMetaInfo": {
        "fileTypeName": "inbound"
      },
      "tpData": [],
      "lobData": [],
      "clientName": [],
      "analystName": "Dharam Mali",
      "interfaceGroup": null,
      "fileStatus": 1,
      "status": 1
    }];
    component.exportAsExcelFileforFile();

    component.exportMasterData = [{
      "masterFileTemplateId": 1,
      "masterFileTemplateName": "abc",
      "fileTypeMetaInfo": {
        "fileTypeName": "Dharam Mali",
        "direction": "inbound"
      },
      "masterFileTemplateVersion": 1,
      "status": 1
    }];
    component.exportAsExcelFileforMaster();
    let _dt = "01/01/1987";
    component.convertDateFormate(_dt);
    component.getStatus(1);
    component.getStatus(0);
  });





});


class MockDataService {
  getToolTipTextDetails(id): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
    return (Observable.of(response));
  }
  getAllFiles(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-file-setup-list/getAllFiles.json");
    return (Observable.of(response));
  }
  getFiles(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-file-setup-list/getAllFiles.json");
    return (Observable.of(response));
  }

  getAllChildFiles(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
    return (Observable.of(response));
  }

  getChildFiles(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
    return (Observable.of(response));
  }
  getAllMasterFiles(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
    return (Observable.of(response));
  }
  getLOBList(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-lookup-table/getAttributes.json");
    return (Observable.of(response));
  }
  subscribe() {
    let response;
    response = { "previousUrl": "/child/create" };
    return (Observable.of(response));
  }

  getRouteDetails(): Observable<any> {
    let response;
    response = { "previousUrl": "/child/create" };
    return (Observable.of(response));
  }
  defaultRoute(): Observable<any> {
    let response;
    response = true;
    const routes = {
      version: "dashboard",
      id: "123"
    };
    return (Observable.of(routes));
  }
  createDraft() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }
  deleteFiles() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }
  deleteMasterFile() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }
  getFileVersionDetails() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }

  getFileVersion() {
    let response;
    response = { "error": false, "data": [{ "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.677 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "10/14/19 03:05 CT", "recordId": 3705, "archivalLocation": "/apps/Benefits/adapt/qa/files/archive/null/11173", "fileName": "Test ACA GKN- File as template-COPIED", "fileProcessingErrorThresholdCount": 0, "fileStatus": "Active", "fileVersion": 1, "oldFileId": null, "isActive": false, "tradingPartnerName": null, "lobName": null, "employerName": null, "employerIds": [], "fileAssociatedWebsite": null, "isMultiEmployer": false, "fileIdGenerator": { "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.673 GMT", "fileId": 11178 }, "fileTypeMetaInfo": { "createdBy": "Divya Jain", "createdDateTime": "27/09/2018 05:46:57.997 GMT", "updatedBy": null, "updatedDateTime": null, "fileTypeId": 5, "direction": "Inbound", "fileTypeName": "Inbound ACA: FTE Data File", "active": true, "cloneAllowed": true }, "masterFileTemplateRecordId": 5, "masterFileTemplateMetaInfo": { "createdBy": "Divya Jain", "createdDateTime": "27/09/2018 05:48:31.087 GMT", "masterFileTemplateRecordId": 5, "masterFileTemplateId": 5, "masterFileTemplateDescription": "Inbound ACA: FTE Data File Master", "masterFileTemplateName": "Inbound ACA: FTE Data File Master", "masterFileTemplateVersion": 1, "approvalStatusUpdatedBy": "Divya Jain", "approvalStatusComment": "Pre-configured", "approvalStatusUpdatedDate": "2018-09-27T05:48:31.087+0000", "approvalStatus": 3, "editedBy": null, "editorComment": null, "fileTypeMetaInfo": { "createdBy": "Divya Jain", "createdDateTime": "27/09/2018 05:46:57.997 GMT", "updatedBy": null, "updatedDateTime": null, "fileTypeId": 5, "direction": "Inbound", "fileTypeName": "Inbound ACA: FTE Data File", "active": true, "cloneAllowed": true }, "currentApprovalStatus": null, "active": true }, "fileFormatSupported": { "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.677 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "14/10/2019 08:01:36.677 GMT", "fileFormatSupportedId": 3295, "fileFooterLineCount": null, "fileFormatEscapeChar": null, "fileFormatFieldDelimiter": ",", "fileFormatName": "DELIMITED", "fileFormatRowDelimiter": "\n", "fileFormatSegmentDelimiter": null, "fileHasFooter": true, "fileHasHeader": true, "fileHeaderLineCount": null, "fileLinesSkipCount": null }, "appendFileRunDate": false, "approvalStatusUpdatedBy": null, "approvalStatusComment": null, "approvalStatusUpdatedDate": null, "approvalStatus": 1, "editedBy": null, "editorComment": null, "currentApprovalStatus": null, "tradingPartnerPlatformInfo": null, "fileMinRecordCountAllowed": null, "fileMaxRecordCountAllowed": null, "fileProcessingErrorThresholdFormat": "No Threshold", "analystEmail": "jay.avatani@alight.com", "analystName": "Jay Avatani", "slaMapped": false, "dataSourceTypeId": 1, "dataTargetTypeId": 2, "isTemplate": false, "fileEmployerAssoc": [{ "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.677 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "14/10/2019 08:01:36.677 GMT", "fileEmployerAssocId": 9293, "clientEmployerAssocId": 51 }], "idisTeamFileAssociation": [{ "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.677 GMT", "idisTeamFileAssociationId": 6866, "idisTeam": { "createdBy": "A0752604", "createdDateTime": "28/06/2018 08:54:07.693 GMT", "updatedBy": "A0752604", "updatedDateTime": "28/06/2018 08:54:07.693 GMT", "idisTeamId": 22, "idisTeamName": "Client Exchange", "idisTeamDescription": null, "idisTeamCommonEmailId": "adapt_qa@yahoo.com" } }], "fileTradingPartnerLobAssoc": [{ "createdBy": "Jay Avatani", "createdDateTime": "14/10/2019 08:01:36.677 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "14/10/2019 08:01:36.677 GMT", "fileTradingPartnerLobAssocId": 5127, "tradingPartnerInfo": { "createdBy": "Ankur Aggarwal", "createdDateTime": "28/09/2018 04:55:57.973 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "11/01/2019 08:37:54.590 GMT", "tradingPartnerId": 100, "tradingPartnerDescription": null, "tradingPartnerName": "abcljljj", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "01/11/19 02:37 CT", "uniqueIdentifier": "9DDAEB00-BCF7-4C87-B7AF-74BBC253E1D9" }, "lob": { "createdBy": "Ankur Aggarwal", "createdDateTime": "28/09/2018 09:26:48.990 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "28/09/2018 09:26:48.990 GMT", "lobId": 48, "lobDescription": null, "uniqueIdentifier": "70FE79B9-4BC8-4A8E-80A4-E76AD1BC3E7C", "lastUpdatedDateTime": "09/28/18 04:26 CT", "size": 0, "lobName": "lob36488", "active": true } }] }] };
    return (Observable.of(response));
  }

  getTradingPartner() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }
  restoreTemplate() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }

  deleteFileDraft() {
    let response;
    response = require("../../../../assets/test-data/blank.json");
    return (Observable.of(response));
  }

  copyConfig() {
    let response;
    response = { "error": false, "data": { "recordId": 3737, "fileIdGenerator": { "fileId": 11203 }, "fileName": "MD - Copy One", "fileTypeMetaInfo": { "fileTypeName": "Inbound Census", "direction": "Inbound" }, "fileVersion": 1, "isActive": false, "fileStatus": "Active", "approvalStatus": 1, "fileTradingPartnerLobAssoc": [{ "tradingPartnerInfo": { "tradingPartnerName": "0 - Orac_1" }, "lob": { "lobName": "Test LOB1 July02_1" } }], "currentApprovalStatus": 1, "clientId": "16571", "analystName": "Dharam Mali", "interfaceGroup": "Client Exchange", "clientName": "Aaron's Inc.", "latestRecordId": 3737, "latestFileVersion": 1, "isTemplate": false, "masterFileTemplateMetaInfo": { "masterFileTemplateName": "Inbound Census Master", "masterFileTemplateId": 1, "masterFileTemplateVersion": 1, "masterFileTemplateRecordId": 1, "fileTypeMetaInfo": { "fileTypeName": "Inbound Census", "direction": "Inbound" } } } };
    return (Observable.of(response));
  }
  confirm() {
    return true;
  }


  error() {
    return false;
  }
  success() {
    return true;
  }
  activePromotionTab() {
    return true;
  }
}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAngetToolTipTextDetailsdFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}