import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { TreeNode } from "primeng/primeng";
import { AlFileBasicConfiguration } from "./al-file-setup/al-file-basic-configuration/al-file-basic-configuration";
import { FilesListComponent } from "./files-list.component";
import { routing } from "./file-setup-routing";
import { TabViewModule } from "primeng/components/tabview/tabview";
import { ListboxModule } from "primeng/components/listbox/listbox";
import { DataTableModule } from "primeng/components/datatable/datatable";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { ButtonModule } from "primeng/components/button/button";
import { PaginatorModule } from "primeng/components/paginator/paginator";
import { CheckboxModule } from "primeng/components/checkbox/checkbox";
import { PickListModule } from "primeng/components/picklist/picklist";
import { PanelModule } from "primeng/components/panel/panel";
import { StepsModule } from "primeng//components/steps/steps";
import { AccordionModule } from "primeng/components/accordion/accordion";
import { Accordion, AccordionGroup } from "./accordion-custom";
import { FilesSetupListComponent } from "./al-file-setup-list/al-file-setup-list.component";
import { FilesSetupSidebarComponent } from "./sidebar/al-file-setup-sidebar";
import { AutoCompleteModule } from "primeng/components/autocomplete/autocomplete";
import { DropdownModule } from "primeng/components/dropdown/dropdown";
import { CustomFormsModule } from "ng2-validation";
import { ConfirmDialogModule } from "primeng/components/confirmdialog/confirmdialog";
import { AlNotificationComponent } from "./al-file-setup/al-notification/al-notification.component";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { NgxPermissionsModule } from "ngx-permissions";
import { CalendarModule } from "primeng/primeng";
// import { AlCustomValuesComponent } from "./al-file-setup/al-custom-values/al-custom-values.component";
import { AlRuleEditorComponent } from "./al-rule-editor/al-rule-editor.component";
import { TooltipModule } from "primeng/components/tooltip/tooltip";
import { AlLookupTableComponent } from "./al-lookup-table/al-lookup-table.component";
import { AlViewLookupTableComponent } from "./al-lookup-table/al-view-lookup-table/al-view-lookup-table.component";
import { AlMasterTemplateComponent } from "./al-master-template/al-master-template.component";
import { AlAttributeListComponent } from "./al-master-template/al-attribute-list/al-attribute-list.component";
import { AlBasicConfMaster } from "./al-master-template/al-basic-configuration/al-basic-configuration.component";
import { ALDropdownModule } from "./al-dropdown";
import { AlFileAttributeMappingComponent } from "./al-file-setup/al-file-attribute-mapping/al-file-attribute-mapping.component";
import { AlFileSetupComponent } from "./al-file-setup/al-file-setup.component";
import { AlFileApprovalComponent } from "./al-file-setup/al-file-approval/al-file-approval.component";
import { AlAttributeListOutboundComponent } from "./al-master-template/al-attribute-list-outbound/al-attribute-list-outbound.component";
import { FileSetupRedirect } from "./al-file-setup-services/al-file-setup-redirect";
import { AlExtractionParametersComponent } from "./al-file-setup/al-extraction-parameters/al-extraction-parameters.component";
import { AlBasicSelectionCriteriaComponent } from "./al-file-setup/al-extraction-parameters/al-basic-selection-criteria/al-basic-selection-criteria.component";
import { AlDynamicSchemaGenerationComponent } from "./al-master-template/al-dynamic-schema-generation/al-dynamic-schema-generation.component";
import { TreeTableModule } from "./al-treetable/treetable";
import { AlAttributeMapping834Component } from "./al-master-template/al-attribute-mapping-834/al-attribute-mapping-834.component";
import { AlDynamicSchemaGenerationFileComponent } from "./al-file-setup/al-dynamic-schema-generation-file/al-dynamic-schema-generation-file.component";
import { AlSpecifyDelimitersComponent } from "./al-specify-delimiters/al-specify-delimiters.component";
import { AlConnectionKeyComponent } from "./al-file-setup/al-connection-key/al-connection-key.component";
import { AlPromotionsComponent } from "./al-promotions/al-promotions.component";
import { AlPopOverModule } from "../../sharedModules/al-popover/al-popover.module";
import { FileSetupService } from "./al-file-setup-services/file-setup.service";
import { ShowLinkBasedOnEmpAccessModule } from "../../show-link-based-on-emp-access/show-link-based-on-emp-access.module";
import { AlAttributeMappingOutboundFile } from "./al-file-setup/al-attribute-mapping-outbound-file/al-attribute-mapping-outbound-file";

@NgModule({
  imports: [
    CommonModule,
    routing,
    TabViewModule,
    DataTableModule,
    OverlayPanelModule,
    DialogModule,
    PickListModule,
    PanelModule,
    ButtonModule,
    ListboxModule,
    FormsModule,
    AutoCompleteModule,
    DropdownModule,
    CustomFormsModule,
    PaginatorModule,
    StepsModule,
    CheckboxModule,
    AccordionModule,
    ConfirmDialogModule,
    TooltipModule,
    ALDropdownModule,
    CalendarModule,
    TreeTableModule,
    AlPopOverModule,
    NgxPermissionsModule.forRoot(),
    ShowLinkBasedOnEmpAccessModule
  ],
  declarations: [
    AlFileBasicConfiguration,
    FilesListComponent,
    FilesSetupListComponent,
    FilesSetupSidebarComponent,
    Accordion,
    AccordionGroup,
    AlNotificationComponent,
    AlRuleEditorComponent,
    // SpecialFileConfig834Component,
    AlLookupTableComponent,
    AlViewLookupTableComponent,
    AlMasterTemplateComponent,
    AlAttributeListComponent,
    AlBasicConfMaster,
    AlFileAttributeMappingComponent,
    AlFileSetupComponent,
    AlFileApprovalComponent,
    AlAttributeListOutboundComponent,
    AlExtractionParametersComponent,
    AlBasicSelectionCriteriaComponent,
    AlDynamicSchemaGenerationComponent,
    AlAttributeMapping834Component,
    AlDynamicSchemaGenerationFileComponent,
    AlSpecifyDelimitersComponent,
    AlConnectionKeyComponent,
    AlPromotionsComponent,
    AlAttributeMappingOutboundFile
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [
    AuthGuard,
    FileSetupRedirect,
    FileSetupService
  ]
})
export class FileSetupModule { }
