import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AlFileSetupComponent } from "./al-file-setup/al-file-setup.component";
import { FilesSetupListComponent } from "./al-file-setup-list/al-file-setup-list.component";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { AlMasterTemplateComponent } from "./al-master-template/al-master-template.component";
import { CanDeactivateGuard } from "../../services/guards/can-deactivate-guard.service";

const appRoutes: Routes = [
    {
        path: "file-setup",
        component: FilesSetupListComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "create/:id/:version/:tab/:view",
        component: AlFileSetupComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "create/:id/:version/:tab",
        component: AlFileSetupComponent,
        canActivate: [AuthGuard],
        canDeactivate: [CanDeactivateGuard]
    },
    {
        path: "create",
        component: AlFileSetupComponent,
        canActivate: [AuthGuard],
        canDeactivate: [CanDeactivateGuard]
    },
    {
        path: "master/:id/:version",
        component: AlMasterTemplateComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "create/:MTFileTemplateId",
        component: AlFileSetupComponent,
        canActivate: [AuthGuard],
        canDeactivate: [CanDeactivateGuard]
    },
];

export const routing: ModuleWithProviders = RouterModule.forChild(appRoutes);