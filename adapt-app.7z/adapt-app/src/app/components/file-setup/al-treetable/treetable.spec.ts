import { TestBed, ComponentFixture } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import {
  ALTreeTable, TTBody, TTScrollableView, TTSortableColumn, TTSortIcon, TTResizableColumn, TTReorderableColumn, TTSelectableRow, TTSelectableRowDblClick, TTContextMenuRow
  , TreeTableToggler, TTCheckbox, TTHeaderCheckbox, TTEditableColumn, TreeTableCellEditor
} from "./treetable";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { combineAll } from "rxjs/operator/combineAll";
import { Component, ElementRef } from "@angular/core";

describe("TreeTable", () => {

  let treetable: ALTreeTable;
  let fixture: ComponentFixture<ALTreeTable>;

  let ttBody: TTBody;
  let fixture1: ComponentFixture<TTBody>;

  let reeTableToggler: TreeTableToggler;
  let fixture2: ComponentFixture<TreeTableToggler>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule
      ],
      declarations: [
        ALTreeTable, TTBody, TTScrollableView, TTSortableColumn, TTSortIcon, TTResizableColumn, TTReorderableColumn, TTSelectableRow, TTSelectableRowDblClick, TTContextMenuRow, TreeTableToggler, TTCheckbox, TTHeaderCheckbox, TTEditableColumn, TreeTableCellEditor
      ],
      providers: [
        ALTreeTable
      ]
    });

    fixture = TestBed.createComponent(ALTreeTable);
    treetable = fixture.componentInstance;
    // fixture2 = TestBed.createComponent(TTScrollableView);
    // ttScrollableView = fixture2.componentInstance;
    // fixture1 = TestBed.createComponent(TTBody);
    // ttBody = fixture1.componentInstance;
  });
  it("should create", () => {
    expect(treetable).toBeTruthy();
  });
  it("should ngoninit", () => {
    treetable.ngOnInit();
  });
  it("should ngoninit if", () => {
    treetable.lazy = true;
    treetable.ngOnInit();
  });
  it("should ngoninit if", () => {
    let response = require("../../../../assets/test-data/file-setup/treetable/template.json");
    response.data[0] = {
      "getType": () => {
        return "caption";
      },
    };
    response.data[1] = {
      "getType": () => {
        return "header";
      },
    };
    response.data[2] = {
      "getType": () => {
        return "body";
      },
    };
    response.data[3] = {
      "getType": () => {
        return "footer";
      },
    };
    response.data[4] = {
      "getType": () => {
        return "summary";
      },
    };
    response.data[5] = {
      "getType": () => {
        return "colgroup";
      },
    };
    response.data[6] = {
      "getType": () => {
        return "emptymessage";
      },
    };
    response.data[7] = {
      "getType": () => {
        return "paginatorleft";
      },
    };
    response.data[8] = {
      "getType": () => {
        return "paginatorright";
      },
    };
    response.data[9] = {
      "getType": () => {
        return "frozenheader";
      },
    };
    response.data[10] = {
      "getType": () => {
        return "frozenbody";
      },
    };
    response.data[11] = {
      "getType": () => {
        return "frozenfooter";
      },
    };
    response.data[12] = {
      "getType": () => {
        return "frozencolgroup";
      },
    };
    treetable.templates = response.data;
    treetable.ngAfterContentInit();
  });
  it("get set _value", () => {
    treetable.value = [{ parent: null }];
    treetable.sortMode = "single";
    treetable.sortField = "check";
  });
  it("get set _selection", () => {
    treetable.selection = [{ parent: null }];
  });
  it("get set _multiSortMeta", () => {
    treetable.sortMode = "multiple";
    treetable.multiSortMeta = [];
  });
  it("get set updateSerializedValue", () => {
    treetable.paginator = true;
    treetable.updateSerializedValue();
  });
  it("get set _sortOrder", () => {
    treetable.sortOrder = 2;
  });

  it("updateSelectionKeys fun", () => {
    treetable.selection = true;
    treetable.dataKey = "data";
    treetable.updateSelectionKeys();
  });
  it("onPageChange fun", () => {
    let e = {
      first: "",
      rows: ""
    };
    treetable.onPageChange(e);
    treetable.lazy = true;
    treetable.onPageChange(e);
  });
  it("sort fun", () => {
    let e = {
      originalEvent: {
        metaKey: ""
      }
    };
    treetable.sort(e);
  });
  it("sort fun", () => {
    let e = {
      originalEvent: {
        metaKey: ""
      },
      field: "sort"
    };
    treetable.sortMode = "multiple";
    treetable.sort(e);
  });
  it("sortSingle fun", () => {
    treetable.lazy = true;
    treetable.sortSingle();
  });
  it("sortSingle fun", () => {
    treetable.lazy = true;
    treetable.sortSingle();
  });
  it("sortMultipleNodes fun", () => {
    let nodes = [];
    treetable.customSort = true;
    treetable.sortMultipleNodes(nodes);
  });
  it("isEmpty fun", () => {
    treetable.isEmpty();
  });
  it("sortNodes fun", () => {
    let nodes = [{ value: "123" }];
    treetable.customSort = true;
    treetable.sortNodes(nodes);
  });
  it("sortNodes fun false", () => {
    let nodes = [{ value: "123" }];
    treetable.customSort = false;
    treetable.sortNodes(nodes);
  });
  it("sortMultiple fun", () => {
    treetable.lazy = false;
    treetable.sortMultiple();
  });
  // xit("sortNodes fun false", () => {
  //   let nodes = [{ value: "123" }];
  //   treetable.customSort = false;
  //   treetable.value = [{ parent: "1" }, { parent: "2" }, { parent: "3" }, { parent: "4" }, { parent: "5" }];
  //   treetable.sortMultipleNodes(nodes);
  // });
  it("sortNodes fun true", () => {
    let nodes = [{ value: "123" }];
    treetable.customSort = true;
    treetable.sortMultipleNodes(nodes);
  });
});
