import { SelectItem } from "primeng/primeng";

export interface SelectItemGroup {
    label: string;
    value?: any;
    items: SelectItem[];
}