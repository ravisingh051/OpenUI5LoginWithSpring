import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { NgForm } from "@angular/forms";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";
import { ToastsManager } from "ng2-toastr";
import { Router, ActivatedRoute } from "@angular/router";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-basic-configuration-master",
  templateUrl: "./al-basic-configuration.component.html",
  styleUrls: ["./al-basic-configuration.component.scss"]
})
export class AlBasicConfMaster implements OnInit {

  fileType: number;
  tplName: string;
  dirInbound: boolean;
  dirOutbound: boolean;
  selMasterTpl: number;
  selMasterTplVersion: number;
  tplData: any;

  constructor(
    private masterTplService: AlMasterTemplateService,
    private toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  @Output() tabLoader = new EventEmitter();
  @Output() pushMetaInfo = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.selMasterTpl = params["id"];
      this.selMasterTplVersion = params["version"];
    });
    this.masterTplService.getMasterTemplateById(this.selMasterTpl, this.selMasterTplVersion, true).subscribe(res => {
      if (!res.error) {
        this.tplData = res.data;
        this.pushMetaInfo.emit(this.tplData);
        this.tplName = this.tplData.masterFileTemplateName;
        this.fileType = this.tplData.fileTypeMetaInfo.fileTypeName;
        let _dir = this.tplData.fileTypeMetaInfo.direction.toLowerCase();
        this.dirInbound = _dir === "inbound" ? true : false;
        this.dirOutbound = _dir === "outbound" ? true : false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.tabLoader.emit(false);
    }, /* istanbul ignore next */ error => {
      this.tabLoader.emit(false);
      this.toastr.error("Server Error in getting Master Template File Details.", "Oops!", TOAST_SETTING);
    });
  }

  pageNavigationFn() {
    if (this.tplData.fileTypeMetaInfo.direction === "Inbound") {
      this.pageNavigation.emit("attrInbound");
    } else if (this.tplData.fileTypeMetaInfo.direction === "Outbound") {
      this.pageNavigation.emit("attrOutbound");
    }
  }



}