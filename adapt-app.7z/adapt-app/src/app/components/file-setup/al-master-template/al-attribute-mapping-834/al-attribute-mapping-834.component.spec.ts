import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";

import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, Router, ActivatedRoute } from "@angular/router";
import { AlAttributeMapping834Component } from "./al-attribute-mapping-834.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { RouterDetailsService } from "../../../../services/common/router.details";
import { HttpClientTestingModule } from "@angular/common/http/testing";


let metaInfo;

describe("AlAttributeMapping834Component", () => {
  let component: AlAttributeMapping834Component;
  let fixture: ComponentFixture<AlAttributeMapping834Component>;
  let toastService;
  let ngxPermission;

  function populateData() {
    metaInfo = {
      "masterFileTemplateName": "Outbound Transaction 834 Master 5010",
      "masterFileTemplateId": 2,
      "masterFileTemplateVersion": 1,
      "fileTypeMetaInfo": {
        "fileTypeName": "Outbound Transaction 834",
        "direction": "Outbound"
      },
      "masterFileTemplateRecordId": 2,
      "currentApprovalStatus": null
    };
    return metaInfo;
  }

  beforeEach(async(() => {
    TestBed.overrideComponent(AlAttributeMapping834Component, {
      set: {
        providers: [
          { provide: AlMasterTemplateService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        RouterTestingModule,
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlAttributeMapping834Component, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        AppUtility,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        { provide: AlMasterTemplateService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: MockDataService },
        // { provide: ToastsManager, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: Observable, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService },
        { provide: Router, useClass: MockDataService },
        { provide: RouterDetailsService, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1 }) } }

      ]
    });
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(AlAttributeMapping834Component);
      component = fixture.debugElement.componentInstance;

      ngxPermission = TestBed.get(NgxPermissionsService);
      ngxPermission.addPermission("Master File Setup-Edit Template");
      component.treeTableData = [
        {
          "data": {
            "id": 1,
            "referenceId": 2,
            "category": "Section",
            "dataType": "NODE",
            "displayName": "Header",
            "parentId": null,
            "description": null,
            "mandatory": true,
            "mappedColumn": null,
            "conditionalDescription": null,
            "selMappedColumnSource": null,
            "attributeName": null,
            "attributeAssocId": null,
            "mappedColumnId": null,
            "hasChildren": true,
            "recordId": null,
            "ftaaId": null,
            "mappedColumnDetailsList": null,
            "lookupTableFileAssociations": null,
            "fileAttrBrAssocs": null
          },
          "leaf": true
        }
      ];
      component.metaInfo = populateData();
      fixture.detectChanges();
    });


    toastService = TestBed.get(ToastsManager);
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should be logging user", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  }));
  it("should loadNodes()", () => {
    let e = {};
    component.loadNodes(e);
  });
  it("should onNodeExpand() IF", () => {
    let e = {
      "node": {
        "children": []
      }
    };
    component.onNodeExpand(e);
  });
  it("should onNodeExpand() Else", () => {
    let e = {
      "node": {
        "data": {
          "id": 1
        },
        "expanded": false,
        "leaf": true,
        "togglerLoader": false
      }
    };
    component.onNodeExpand(e);
  });
  it("should enableEditMode() If", () => {
    component.rowEditFlag = true;
    let rowNode = {};
    component.enableEditMode(rowNode);
  });
  it("should enableEditMode() Else, action(), resetRowData()", () => {
    component.rowEditFlag = false;
    let rowNode = {
      "node": {
        "children": [
          {
            "data": {
              "id": 2,
              "referenceId": 3,
              "category": "Loop",
              "dataType": "NODE",
              "displayName": "Loop",
              "parentId": 1,
              "description": "Header Loop",
              "mandatory": true,
              "mappedColumn": "Not Applicable",
              "conditionalDescription": null,
              "selMappedColumnSource": null,
              "attributeName": null,
              "attributeAssocId": null,
              "mappedColumnId": null,
              "hasChildren": true,
              "recordId": null,
              "ftaaId": null,
              "mappedColumnDetailsList": null,
              "lookupTableFileAssociations": null,
              "fileAttrBrAssocs": null
            },
            "leaf": true
          }
        ],
        "data": {
          "id": 1,
          "referenceId": 2,
          "category": "Section",
          "dataType": "NODE",
          "displayName": "Header",
          "parentId": null,
          "description": null,
          "mandatory": true,
          "mappedColumn": null,
          "conditionalDescription": null,
          "selMappedColumnSource": null,
          "attributeName": null,
          "attributeAssocId": null,
          "mappedColumnId": null,
          "hasChildren": true,
          "recordId": null,
          "ftaaId": null,
          "mappedColumnDetailsList": null,
          "lookupTableFileAssociations": null,
          "fileAttrBrAssocs": null
        },
        "expanded": false,
        "leaf": true,
        "togglerLoader": false
      }
    };
    component.enableEditMode(rowNode);
    let e = {};
    let actionItems = {
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    component.action(e, rowNode, 0, actionItems);
    component.resetRowData();
  });
  it("should nextStep()", () => {
    component.activeIndex = 0;
    component.nextStep();
    component.activeIndex = 1;
    component.nextStep();
    component.activeIndex = 2;
    component.nextStep();
  });

  it("should showMapColDialog() IF", () => {
    let event = {
      stopPropagation: (e) => {
      },
    };
    let rowNode = {
      "node": {
        "data": {
        }
      }
    };
    component.showMapColDialog(event, rowNode);
    component.addMapColData();
  });

  it("should showMapColDialog() Else", () => {
    let event = {
      stopPropagation: (e) => {
      },
    };
    let rowNode = {
      "node": {
        "data": {
          "mappedColFlag": true,
          "mappedColumnDetailsList": []
        }
      }
    };
    component.showMapColDialog(event, rowNode);
  });
  it("should addMapColData()", () => {
    component.mapColData = {
      node: {
        data: {}
      }
    };
    component.addMapColData();
  });

  it("should addSelDataEle(), saveEnuValForm(), addSelDataEle(), addSelDataEle(), removeEle()", () => {
    component.validValues = {
      "selSource": "1",
      "dataEleList": [
        {
          "label": "Address Preference",
          "value": 631,
          "description": "Preference1 Id"
        },
        {
          "label": "Adjusted Salary3",
          "value": 602,
          "description": "Adjusted Salary3"
        },
        {
          "label": "Annual Commission / Bonus",
          "value": 526,
          "description": "Annual Commision/Bonus"
        },
        {
          "label": "Annual Salary",
          "value": 524,
          "description": "Annual Salary"
        }
      ],
      "selDataEle": [526, 602],
      "enuValKey": "d",
      "enuValVal": "d"
    };
    component.mapColData = {
      "level": 3,
      "node": {
        "data": {
          "id": 4,
          "referenceId": 5,
          "category": "Element",
          "dataType": "NUMBER",
          "displayName": "ISA01",
          "parentId": 3,
          "description": "Authorization Information Qualifier",
          "mandatory": true,
          "mappedColumn": "Data Element And/Or Enumerated Values",
          "conditionalDescription": "test",
          "selMappedColumnSource": null,
          "attributeName": null,
          "attributeAssocId": null,
          "mappedColumnId": null,
          "hasChildren": false,
          "recordId": null,
          "ftaaId": null,
          "mappedColumnDetailsList": [
            {
              "id": 4332,
              "nodeId": 4,
              "name": "00",
              "description": "No Authorization Information Present (No Meaningful Information in I02)",
              "source": "Enumerated Value",
              "isActive": true,
              "attributeAssocId": null,
              "oldAttributeAssocId": null,
              "parentIdIfInheritedEnum": null,
              "recordId": null,
              "ftaaId": null
            },
            {
              "id": 4333,
              "nodeId": 4,
              "name": "03",
              "description": "Additional Data Identification",
              "source": "Enumerated Value",
              "isActive": true,
              "attributeAssocId": null,
              "oldAttributeAssocId": null,
              "parentIdIfInheritedEnum": null,
              "recordId": null,
              "ftaaId": null
            }
          ],
          "lookupTableFileAssociations": null,
          "fileAttrBrAssocs": null,
          "mappedColFlag": true,
          "oldData": "{\"id\":4,\"referenceId\":5,\"category\":\"Element\",\"dataType\":\"NUMBER\",\"displayName\":\"ISA01\",\"parentId\":3,\"description\":\"Authorization Information Qualifier\",\"mandatory\":true,\"mappedColumn\":\"Data Element And/Or Enumerated Values\",\"conditionalDescription\":\"test\",\"selMappedColumnSource\":null,\"attributeName\":null,\"attributeAssocId\":null,\"mappedColumnId\":null,\"hasChildren\":false,\"recordId\":null,\"ftaaId\":null,\"mappedColumnDetailsList\":[{\"id\":4332,\"nodeId\":4,\"name\":\"00\",\"description\":\"No Authorization Information Present (No Meaningful Information in I02)\",\"source\":\"Enumerated Value\",\"isActive\":true,\"attributeAssocId\":null,\"oldAttributeAssocId\":null,\"parentIdIfInheritedEnum\":null,\"recordId\":null,\"ftaaId\":null},{\"id\":4333,\"nodeId\":4,\"name\":\"03\",\"description\":\"Additional Data Identification\",\"source\":\"Enumerated Value\",\"isActive\":true,\"attributeAssocId\":null,\"oldAttributeAssocId\":null,\"parentIdIfInheritedEnum\":null,\"recordId\":null,\"ftaaId\":null}],\"lookupTableFileAssociations\":null,\"fileAttrBrAssocs\":null,\"mappedColFlag\":true}"
        },
        "expanded": false,
        "leaf": true,
        "togglerLoader": false
      }
    };
    component.mapColTableData = [
      {
        "id": 4332,
        "nodeId": 4,
        "name": "00",
        "description": "No Authorization Information Present (No Meaningful Information in I02)",
        "source": "Enumerated Value",
        "isActive": true,
        "attributeAssocId": null,
        "oldAttributeAssocId": null,
        "parentIdIfInheritedEnum": null,
        "recordId": null,
        "ftaaId": null
      },
      {
        "id": 4333,
        "nodeId": 4,
        "name": "03",
        "description": "Additional Data Identification",
        "source": "Enumerated Value",
        "isActive": true,
        "attributeAssocId": null,
        "oldAttributeAssocId": null,
        "parentIdIfInheritedEnum": null,
        "recordId": null,
        "ftaaId": null
      }
    ];
    component.addSelDataEle();

    let saveEnuValForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        firstName: ""
      }
    };
    component.saveEnuValForm(saveEnuValForm);

    component.validValues.selDataEle = [];
    component.addSelDataEle();

    let rowNode = component.mapColData;
    let e = {};
    let actionItems = {
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    component.action(e, rowNode, 0, actionItems);



    component.saveRowData();

    component.removeEle({}, 0);

  });

  it("should addCondDes()", () => {
    let event = {
      stopPropagation: (e) => { }
    };
    let rowNode = {
      "node": {
        "data": {
          "conditionalDescription": "abc"
        }
      }
    };
    component.mapColData = {
      "node": {
        "data": {
          "conditionalDescription": ""
        }
      }
    };

    component.$conditionalDescription = "abc";
    component.addCondDes();
    component.cancelCondDes();
    component.showMandatoryDialog(event, rowNode);
  });



});


class MockDataService {
  getMapColDropDown() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/getMapColDropDown.json");
    return (Observable.of(response));
  }
  getAttributeListOutbound() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/getAttributeList.json");
    return (Observable.of(response));
  }
  getAttrMappingData() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/loadNodes.json");
    return (Observable.of(response));
  }
  getChildrenAttr() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/onNodeExpand.json");
    return (Observable.of(response));
  }
  getMappedColumns() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/showMapColDialog.json");
    return (Observable.of(response));
  }
  saveAttrMappingRow() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-mapping-834/showMapColDialog.json");
    return (Observable.of(response));
  }

  error() {
    return false;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}
class MockActivatedRoute extends ActivatedRoute {
  constructor() {
    super();
    this.params = Observable.of({ id: 555, version: 0 });
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }

}