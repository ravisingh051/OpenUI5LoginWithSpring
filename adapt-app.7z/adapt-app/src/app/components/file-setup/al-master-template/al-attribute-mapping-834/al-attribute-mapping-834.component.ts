import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";
import { MenuItem } from "primeng/components/common/api";
import { TreeTableModule } from "../../al-treetable/treetable";
import { TreeNode } from "primeng/primeng";
import { PickListModule } from "primeng/primeng";
import { NgForm } from "@angular/forms";
import { NgxPermissionsService } from "ngx-permissions";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-attribute-mapping-834",
  templateUrl: "./al-attribute-mapping-834.component.html",
  styleUrls: ["./al-attribute-mapping-834.component.scss"]
})
export class AlAttributeMapping834Component implements OnInit {

  constructor(
    private masterTplService: AlMasterTemplateService,
    private toastr: ToastsManager,
    private permissionsService: NgxPermissionsService
  ) { }

  @Input() metaInfo: any;
  @Output() tabLoader = new EventEmitter();
  activeIndex: number = 0;
  items: MenuItem[];
  treeTableData: any = {};
  filesCol: any[];
  selSection: string = "H";
  btnClicked: boolean;
  permission: boolean = false;
  // Row Edit
  mapColDropDown: any = {};
  mapColAllOption: any = {};

  ngOnInit() {
    this.items = [{
      label: "Header",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: "Detail Row",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: "Trailer",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 2;
      }
    }];
    this.getMapColDropDown();



    this.mapColDropDown["other"] = [
      { "label": "Please Select", "value": null },
      { "label": "Not Applicable", "value": "Not Applicable" },
      { "label": "Data Element And/Or Enumerated Values", "value": "Data Element And/Or Enumerated Values" }
    ];
    this.getAttributeList();
    let hasPermission = this.permissionsService.getPermission("Master File Setup-Edit Template");
    if (hasPermission !== undefined) {
      this.permission = true;
    }
  }

  getMapColDropDown() {
    this.mapColDropDown["node"] = [
      { "label": "Please Select", "value": null },
      { "value": "Not Applicable", "label": "Not Applicable" }
    ];
    this.masterTplService.getMapColDropDown(this.metaInfo.masterFileTemplateRecordId).subscribe(res => {
      if (!res.error) {
        this.mapColAllOption = res.data;
        for (let _mValue of res.data) {
          this.mapColDropDown.node.push({
            "label": _mValue.sectionDisplayName,
            "value": _mValue.sectionDisplayName
          });
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting mapped column.", "Oops!", TOAST_SETTING);
    });
  }

  getAttrMappingData() {
    this.tabLoader.emit(true);
    this.btnClicked = true;
    this.masterTplService.getAttrMappingData(this.metaInfo.masterFileTemplateRecordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.treeTableData = res.data;
        this.btnClicked = false;
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  nextStep() {
    this.activeIndex++;
    if (this.activeIndex === 1) {
      this.selSection = "D";
    } else if (this.activeIndex === 2) {
      this.selSection = "T";
    }
    if (this.activeIndex <= 2) {
      this.getAttrMappingData();
    }
  }

  actionItems: OverlayPanel;
  action(e, rowNode, rowIndex, actionItems) {
    this.actionItems = actionItems;
    this.mapColData = rowNode;
    this.actionItems.toggle(e);
  }

  mapColDialog: boolean = false;
  mapColTableData: any;
  mapColData: any = {};
  showMapColDialog(event, rowNode) {
    this.mapColData = rowNode;
    this.validValues.selSource = "1";
    this.mapColTableData = [];
    if (this.mapColData.node.data["mappedColFlag"] === undefined || this.mapColData.node.data["mappedColFlag"] === false) {
      this.mapColData.node.data["mappedColFlag"] = true;
      this.masterTplService.getMappedColumns(this.mapColData.node.data.id).subscribe(res => {
        if (!res.error) {
          this.mapColTableData = res.data;
          this.mapColData.node.data["mappedColumnDetailsList"] = res.data;
          this.populateDataElement();
        } /* istanbul ignore next */ else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, /* istanbul ignore next */ error => {
        this.toastr.error("Server Error in getting Mapped Column Data.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.mapColTableData = this.mapColData.node.data.mappedColumnDetailsList;
      this.populateDataElement();
    }
    this.mapColDialog = true;
    event.stopPropagation();
  }

  populateDataElement() {
    let _tempDataList = [];
    for (let elm of this.rowAttrList) {
      let _check = this.mapColTableData.filter((_elm) => _elm.attributeAssocId === elm.value);
      if (_check.length === 0) {
        _tempDataList.push(elm);
      }
    }
    this.validValues.dataEleList = _tempDataList;
    this.validValues.selDataEle = [];
  }

  validValues: any = {};
  addSelDataEle() {
    if (this.validValues.selDataEle === undefined || this.validValues.selDataEle.length === 0) {
      this.toastr.error("Please select Attribute.", "Oops!", TOAST_SETTING);
      return false;
    }
    let _mapColTableData = [];
    for (let i = 0; i < this.validValues.selDataEle.length; i++) {
      let _selElId = this.validValues.selDataEle[i];
      let _selEl = this.validValues.dataEleList.filter((obj) => obj.value === _selElId);
      _mapColTableData.push({
        "nodeId": this.mapColData.node.data.id,
        "name": _selEl[0].label,
        "description": _selEl[0].description,
        "source": "Data Element",
        "attributeAssocId": _selEl[0].value,
        "parentIdIfInheritedEnum": null,
        "isActive": true
      });
    }
    if (_mapColTableData.length > 0) {
      this.mapColTableData = [...this.mapColTableData, ..._mapColTableData];
      this.populateDataElement();
    }
  }

  saveEnuValForm(saveEnuValForm: NgForm) {
    let _mapColTableData = [];
    _mapColTableData.push({
      "nodeId": this.mapColData.node.data.id,
      "name": this.validValues.enuValKey,
      "description": this.validValues.enuValVal,
      "source": "Enumerated value",
      "attributeAssocId": null,
      "parentIdIfInheritedEnum": null,
      "isActive": true
    });
    this.mapColTableData = [...this.mapColTableData, ..._mapColTableData];
    saveEnuValForm.resetForm();
  }

  removeEle(rowData, rowIndex) {
    this.mapColTableData.splice(rowIndex, 1);
    this.mapColTableData = [...this.mapColTableData];
    this.populateDataElement();
  }

  rowAttrList: any;
  getAttributeList() {
    this.masterTplService.getAttributeListOutbound(this.metaInfo.masterFileTemplateRecordId).subscribe(res => {
      if (!res.error) {
        let _dataList = [];
        for (let dList of res.data) {
          _dataList.push({
            "label": dList.attributeName,
            "value": dList.mftaaId,
            "description": dList.description
          });
        }
        this.rowAttrList = _dataList;
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  addMapColData() {
    if (this.mapColTableData !== undefined) {
      this.mapColData.node.data["mappedColumnDetailsList"] = this.mapColTableData;
    } else {
      this.mapColData.node.data["mappedColumnDetailsList"] = [];
    }
    this.mapColDialog = false;
  }

  onNodeExpand(event) {
    let _nodeData = event.node;
    if (_nodeData.children !== undefined) {
      return false;
    }
    _nodeData["children"] = [];
    _nodeData["togglerLoader"] = true;
    this.masterTplService.getChildrenAttr(this.metaInfo.masterFileTemplateRecordId, this.selSection, _nodeData.data.id).subscribe(res => {
      if (!res.error) {
        _nodeData["children"] = res.data;
        this.treeTableData = [...this.treeTableData];
        _nodeData["togglerLoader"] = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  loadNodes(event) {
    this.btnClicked = true;
    this.tabLoader.emit(true);
    this.masterTplService.getAttrMappingData(this.metaInfo.masterFileTemplateRecordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.treeTableData = res.data;
        this.btnClicked = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  mandatoryDialog: boolean = false;
  $conditionalDescription: string;
  showMandatoryDialog(event, rowNode) {
    this.mandatoryDialog = true;
    this.mapColData = rowNode;
    this.$conditionalDescription = rowNode.node.data.conditionalDescription;
    event.stopPropagation();
  }

  addCondDes() {
    this.mandatoryDialog = false;
  }

  cancelCondDes() {
    this.mapColData.node.data.conditionalDescription = this.$conditionalDescription;
    this.mandatoryDialog = false;
  }

  rowEditFlag: boolean = false;
  enableEditMode(rowNode) {
    if (this.rowEditFlag === true) {
      return false;
    }
    this.mapColData = rowNode;
    this.mapColData.node.data["oldData"] = JSON.stringify(this.mapColData.node.data);
    if (this.mapColData.node.data.description === null) {
      this.mapColData.node.data.description = "";
    }
    this.mapColData.node["editMode"] = true;
    this.rowEditFlag = true;

  }

  resetRowData() {
    if (this.mapColData.node["editMode"] === true) {
      this.mapColData.node["editMode"] = false;
      this.rowEditFlag = false;
      this.mapColData.node.data = JSON.parse(this.mapColData.node.data["oldData"]);
      this.mapColData.node.data["oldData"] = null;
    }
    this.actionItems.hide();
  }

  saveRowData() {
    let mappedColumnConfiguration: boolean = false;
    let _obj = {
      masterTemplateLayoutSchemaNodeInfo: {
        "mtlsniId": this.mapColData.node.data.id,
        "recordId": this.metaInfo.masterFileTemplateRecordId,
        "nodeDescription": this.mapColData.node.data.description,
        "mappedColumnType": this.mapColData.node.data.mappedColumn,
      },
      mappedColumnDetailsList: []
    };
    if (this.mapColData.node.data.conditionalDescription !== null) {
      _obj.masterTemplateLayoutSchemaNodeInfo["nodeCondDescription"] = this.mapColData.node.data.conditionalDescription;
    }
    if (this.mapColData.node.data.mappedColumn !== "Not Applicable" && this.mapColData.node.data.mappedColumnDetailsList !== undefined) {
      if (this.mapColData.node.data.mappedColumnDetailsList.length > 0) {
        mappedColumnConfiguration = true;
        for (let _mapObj of this.mapColData.node.data.mappedColumnDetailsList) {
          if (_mapObj.source.toLowerCase() === "enumerated value") {
            _obj["mappedColumnDetailsList"].push({
              description: _mapObj.description,
              isActive: true,
              name: _mapObj.name,
              nodeId: _mapObj.nodeId,
              source: "Enumerated Value",
            });
          } else {
            _obj["mappedColumnDetailsList"].push({
              attributeAssocId: _mapObj.attributeAssocId,
              isActive: true,
              nodeId: _mapObj.nodeId,
              source: "Data Element"
            });
          }
        }
      } else {
        this.toastr.error("Atleast one Data Element Or Enumerated Value required", "Oops!", TOAST_SETTING);
        this.actionItems.hide();
        return false;
      }
    }
    if (this.mapColData.node.data.mappedColumn === "Not Applicable") {
      mappedColumnConfiguration = true;
    }
    if (this.mapColData.node.data.dataType.toLowerCase() === "node" && (this.mapColData.node.data.mappedColumn === "Not Applicable" || this.mapColData.node.data.mappedColumn === null)) {
      _obj.masterTemplateLayoutSchemaNodeInfo["mappedColumnType"] = "Not Applicable";
      _obj.masterTemplateLayoutSchemaNodeInfo["mappedTemplateSectionId"] = null;
    } else if (this.mapColData.node.data.dataType.toLowerCase() === "node" && (this.mapColData.node.data.mappedColumn !== "Not Applicable" && this.mapColData.node.data.mappedColumn !== null)) {
      let _mpCData = this.mapColAllOption.filter((obj) => this.mapColData.node.data.mappedColumn === obj.sectionDisplayName);
      _obj.masterTemplateLayoutSchemaNodeInfo["mappedColumnType"] = _mpCData[0].sectionDisplayName;
      _obj.masterTemplateLayoutSchemaNodeInfo["mappedTemplateSectionId"] = _mpCData[0].templateSectionId;
    }
    this.masterTplService.saveAttrMappingRow(_obj, mappedColumnConfiguration).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Successfully saved values for " + this.mapColData.node.data.displayName + " !", "Success!");
        this.actionItems.hide();
        this.mapColData.node["editMode"] = false;
        this.rowEditFlag = false;
        this.mapColData.node.data["oldData"] = null;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in saving Mapped Column Data.", "Oops!", TOAST_SETTING);
    });
  }

}

