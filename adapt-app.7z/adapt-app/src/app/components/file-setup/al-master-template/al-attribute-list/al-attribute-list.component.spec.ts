import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";

import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, Router, ActivatedRoute } from "@angular/router";
import { AlAttributeListComponent } from "./al-attribute-list.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { RouterDetailsService } from "../../../../services/common/router.details";
import { HttpClientTestingModule } from "@angular/common/http/testing";


let metaInfo;

describe("AlAttributeListComponent", () => {
    let component: AlAttributeListComponent;
    let fixture: ComponentFixture<AlAttributeListComponent>;
    let toastService;

    function populateData() {
        metaInfo = {
            "masterFileTemplateName": "Inbound Census Master",
            "masterFileTemplateId": 1,
            "masterFileTemplateVersion": 1,
            "fileTypeMetaInfo": {
                "fileTypeName": "Inbound Census",
                "direction": "Inbound"
            },
            "masterFileTemplateRecordId": 1,
            "currentApprovalStatus": null
        };
        return metaInfo;
    }

    beforeEach(async(() => {
        TestBed.overrideComponent(AlAttributeListComponent, {
            set: {
                providers: [
                    { provide: AlMasterTemplateService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService },
                    { provide: Observable, useClass: MockDataService },
                    { provide: ToolTipUtilService, useClass: FakeToolTip }
                ]
            }
        });
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule,
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlAttributeListComponent, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: AlMasterTemplateService, useClass: MockDataService },
                { provide: ConfirmationService, useClass: MockDataService },
                // { provide: ToastsManager, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: Observable, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService },
                { provide: Router, useClass: MockDataService },
                { provide: RouterDetailsService, useClass: MockDataService },
                { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1 }) } }

            ]
        });
        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlAttributeListComponent);
            component = fixture.debugElement.componentInstance;
            component.metaInfo = populateData();
            fixture.detectChanges();
        });
        toastService = TestBed.get(ToastsManager);
    }));

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should be logging user", async(() => {
        spyOn(toastService, "error").and.returnValue(Promise.resolve());
        component.ngOnInit();
    }));
    it("should showValidValue()", () => {
        let RowData = {
            "dataElementId": 874,
            "dataElement": "COBRA Reason",
            "dataType": "VARCHAR",
            "maxLength": 50,
            "mandatory": false,
            "validationType": 1,
            "validationValues": "Resignation,Involuntary Termination,Layoff,Severance Continuation,Medicare / Retirement / Term,Death of Employee,Gross Misconduct,Military,Loss After Chapter 11 Bankruptcy,COBRA + 11 Month Disability Extension,COBRA + 13 Month Disability Extension,Other - Non - Cobra",
            "attributeRowPosition": 40,
            "sectionName": "Detail",
            "updatedValidVal": [
                "Resignation",
                "Involuntary Termination",
                "Layoff",
                "Severance Continuation",
                "Medicare / Retirement / Term",
                "Death of Employee",
                "Gross Misconduct",
                "Military",
                "Loss After Chapter 11 Bankruptcy",
                "COBRA + 11 Month Disability Extension",
                "COBRA + 13 Month Disability Extension",
                "Other - Non - Cobra"
            ]
        };
        component.showValidValue(RowData);
    });


});


class MockDataService {
    getAttributeList() {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribue-list/getAttributeList.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }
    success() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}
class MockActivatedRoute extends ActivatedRoute {
    constructor() {
        super();
        this.params = Observable.of({ id: 555, version: 0 });
    }
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}