import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-attribute-list-master",
  templateUrl: "./al-attribute-list.component.html",
  styleUrls: ["./al-attribute-list.component.scss"]
})
export class AlAttributeListComponent implements OnInit {
  @Input() metaInfo: any;

  constructor(
    private masterTplService: AlMasterTemplateService,
    private toastr: ToastsManager
  ) { }

  @Output() tabLoader = new EventEmitter();
  attrListData: any[];
  ngOnInit() {
    this.masterTplService.getAttributeList(this.metaInfo.masterFileTemplateId, this.metaInfo.masterFileTemplateVersion).subscribe(res => {
      if (!res.error) {
        this.attrListData = res.data.Detail;
        this.formatValidValues();
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.tabLoader.emit(false);
      }
    }, /* istanbul ignore next */ error => {
      this.tabLoader.emit(false);
      this.toastr.error("Server Error in getting Master Template File Details.", "Oops!", TOAST_SETTING);
    });
  }

  formatValidValues() {
    for (let attr of this.attrListData) {
      let _tempValidVal = [];
      if (attr.validationType === 2) {
        let _validVal = attr.validationValues.split(" OR ");
        for (let i = 0; i < _validVal.length; i++) {
          if (attr.dataType === "DATE") {
            _tempValidVal.push("DateFormat(\"" + _validVal[i] + "\")");
            /* istanbul ignore next */
            if (i !== _validVal.length - 1) {
              _tempValidVal.push(" OR ");
            }
          }
          if (attr.dataType !== "DATE") {
            _tempValidVal.push("FORMAT(\"" + _validVal[i] + "\")");
            if (i !== _validVal.length - 1) {
              _tempValidVal.push(" OR ");
            }
          }
        }
      }
      if (attr.validationType === 1) {
        let _validVal = attr.validationValues.split(",");
        for (let i = 0; i < _validVal.length; i++) {
          _tempValidVal.push(_validVal[i]);
        }
      }
      attr.updatedValidVal = _tempValidVal;
    }
    this.tabLoader.emit(false);
  }

  validValuesData: any;
  showValidValueDialog: boolean = false;
  dataElement: string = "";
  first: number = 0;

  showValidValue(RowData) {
    this.validValuesData = [];
    this.showValidValueDialog = true;
    this.dataElement = RowData.dataElement;
    this.first = 0;
    this.validValuesData = JSON.parse(JSON.stringify(RowData.updatedValidVal));
  }
}
