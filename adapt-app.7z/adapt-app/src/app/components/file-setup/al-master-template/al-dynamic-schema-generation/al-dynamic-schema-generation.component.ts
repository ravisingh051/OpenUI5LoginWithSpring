import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";
import { MenuItem } from "primeng/components/common/api";
import { TreeTableModule } from "../../al-treetable/treetable";
import { TreeNode } from "primeng/primeng";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-dynamic-schema-generation",
  templateUrl: "./al-dynamic-schema-generation.component.html",
  styleUrls: ["./al-dynamic-schema-generation.component.scss"],
  providers: [ConfirmationService]
})
export class AlDynamicSchemaGenerationComponent implements OnInit {

  constructor(
    private masterTplService: AlMasterTemplateService,
    private toastr: ToastsManager,
    private confirmationService: ConfirmationService,
    private permissionsService: NgxPermissionsService
  ) { }

  @Input() metaInfo: any;
  @Output() tabLoader = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();
  activeIndex: number = 0;
  items: MenuItem[];
  treeTableData: any = [];
  filesCol: any[];
  selSection: string = "H";
  btnClicked: boolean;
  permission: boolean = false;
  ngOnInit() {
    this.items = [{
      label: "Header",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: "Detail Row",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: "Trailer",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 2;
      }
    }];

    this.filesCol = [
      { field: "category", header: "Category", width: "30%" },
      { field: "dataType", header: "Data Type", width: "22%" },
      { field: "displayName", header: "Display Name", width: "22%" },
      { field: "minOccurance", header: "Min Occurrence", width: "13%" },
      { field: "maxOccurance", header: "Max Occurrence", width: "13%" }
    ];

    this.getDataTypes();
    let hasPermission = this.permissionsService.getPermission("Master File Setup-Edit Template");
    if (hasPermission !== undefined) {
      this.permission = true;
    }
  }

  /* Get DataType List */
  dataTypeList: any = [{ "label": "Please Select", "value": null }];
  dataTypes: any;
  getDataTypes() {
    this.masterTplService.getDataTypes().subscribe(res => {
      if (!res.error) {
        this.dataTypes = [...res.data];
        for (let _list of res.data) {
          this.dataTypeList.push({
            "label": _list.attributeDataTypeName,
            "value": _list.attributeDataTypeName
          });
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Data Types.", "Oops!", TOAST_SETTING);
    });
  }

  /* Get Save Ddata */
  getDynamicSchemaGeneration() {
    this.tabLoader.emit(true);
    this.btnClicked = true;
    this.masterTplService.getSectionwiseDynamicSchema(this.metaInfo.masterFileTemplateId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.rowEditFlag = false;
        this.tabLoader.emit(false);
        if (res.data.length !== 0) {
          this.treeTableData = res.data;
        } /* istanbul ignore next */  else {
          if (this.permission) {
            this.pushNewRow(null);
          } else {
            this.treeTableData = [];
          }
        }
        this.btnClicked = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });


  }

  /* Blank row new Object */
  newRowObj() {
    return {
      "data": {
        "id": null,
        "referenceId": null,
        "category": "",
        "dataType": null,
        "displayName": "",
        "parentId": null,
        "minOccurance": 0,
        "maxOccurance": 1
      },
      "editMode": true
    };
  }

  /* Next Button click to navigate Header, Detail, Trailer */
  nextStep() {
    this.activeIndex++;
    if (this.activeIndex === 1) {
      this.selSection = "D";
    } else if (this.activeIndex === 2) {
      this.selSection = "T";
    }
    if (this.activeIndex <= 2) {
      this.getDynamicSchemaGeneration();
    }
    else {
      this.pageNavigation.emit("attrMaping");
    }
  }



  /* Cancel Row */
  cancel() {
    this.selRowData.node.editMode = false;
    this.selRowData.node.data = JSON.parse(this.selRowData.node["oldData"]);
    this.selRowData.node["oldData"] = null;
    this.rowEditFlag = false;
  }
  /* Save Row */
  regex = new RegExp("^[0-9]*$");
  saveRow() {
    this.actionItems.hide();
    let _data = this.selRowData.node.data;
    _data["validCT"] = _data.category === "" ? true : false;
    _data["validDT"] = _data.dataType === null ? true : false;
    _data["validDN"] = _data.displayName === "" ? true : false;
    _data["validMO"] = this.regex.test(_data.minOccurance) === false ? true : false;
    _data["validMX"] = this.regex.test(_data.maxOccurance) === false ? true : false;
    if (_data["validDT"] === false) {
      if (_data.dataType === "NODE" && _data.maxOccurance === ">1") {
        _data["validMX"] = false;
      } else if (_data.dataType !== "NODE") {
        if (_data.minOccurance > 1) {
          _data["validMO"] = true;
          this.toastr.error("Min Occurrence should not be greater than 1", "Oops!", TOAST_SETTING);
          return false;
        }
        if (_data.maxOccurance > 1) {
          _data["validMX"] = true;
          this.toastr.error("Max Occurrence should not be greater than 1", "Oops!", TOAST_SETTING);
          return false;
        }
      }
    }

    if (Number(_data.minOccurance) > Number(_data.maxOccurance)) {
      _data["validMO"] = true;
      _data["validMX"] = true;
      this.toastr.error("Min Occurrence number can not greater than Max. Occurrence", "Oops!", TOAST_SETTING);
      return false;
    }

    if (_data.validCT || _data.validDT || _data.validDN || _data.validMO || _data.validMX) {
      this.toastr.error("Please enter valid value !", "Oops!", TOAST_SETTING);
      return false;
    }
    let _getDtype = this.dataTypes.filter((obj) => obj.attributeDataTypeName === _data.dataType);
    let _dataTypeId = _getDtype[0].attributeDataTypeId;
    let nodeIsMandatory = this.selRowData.node.data.minOccurance > 0 ? 1 : 0;
    let data = {
      "nodeRefNum": this.selRowData.node.data.referenceId,
      "nodeDisplayName": this.selRowData.node.data.displayName,
      "nodeCategory": this.selRowData.node.data.category,
      "isActive": true,
      "nodeDataType": _dataTypeId,
      "nodeMinCount": this.selRowData.node.data.minOccurance,
      "nodeMaxCount": this.selRowData.node.data.maxOccurance === ">1" ? null : this.selRowData.node.data.maxOccurance,
      "recordId": this.metaInfo.masterFileTemplateRecordId,
      "mappedColumnType": null,
      "nodeCondDescription": null,
      "nodeIsMandatory": nodeIsMandatory,
      "nodeSectionShortName": this.selSection,
      "mtlsniId": this.selRowData.node.data.id,
      "siblingId": this.selSiblingId,
      "parentId": this.selRowData.parent === null ? null : this.selRowData.parent.data.id,
    };

    if (this.selRowData.node.data.id === null) {
      data["masterTemplateLayoutSchemaNodeAssoc"] = {
        "parentMtlsniId": this.selRowData.parent !== null ? this.selRowData.parent.data.id : null,
      };
      this.saveRowData(data);
    } else {
      data["nodeRowPosition"] = this.selRowData.node.data.rowPosition;
      this.updateRowData(data);
    }

  }

  /* While Saving new row */
  saveRowData(data) {
    this.masterTplService.saveAttrRow(data).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.btnClicked = false;
        this.selRowData.node.data.id = res.data.id;
        this.selRowData.node.data.referenceId = res.data.referenceId;
        this.selRowData.node.data.rowPosition = res.data.rowPosition;
        this.selRowData.node.editMode = false;
        this.rowEditFlag = false;
        this.toastr.success("Successfully saved the row!.", "Success!");
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  /* While updating new row */
  updateRowData(data) {
    this.masterTplService.updateAttrRow(data).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.btnClicked = false;
        this.selRowData.node.editMode = false;
        this.rowEditFlag = false;
        this.toastr.success("Successfully saved the row!.", "Success!");
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  /* Confirmation for removing row */
  acceptLabel: string = "Yes";
  rejectLabel: string = "No";
  removeRow() {
    this.actionItems.hide();
    if (this.selRowData.node.data.id === null) {
      this.deleteAttrRow(false);
    } else {
      this.confirmationService.confirm({
        message: " Removing Row from Dynamic Schema, if any EnumeratedValues/Data Element associated, will also be deleted !",
        accept: () => {
          this.deleteAttrRow(true);
        }
      });
    }
  }

  /* Get row which is going to be deleted */
  deleteAttrRow(flag) {
    let data = {
      "mtlsniId": this.selRowData.node.data.id,
      "nodeSectionShortName": this.selSection,
      "recordId": this.metaInfo.masterFileTemplateRecordId,
      "masterTemplateLayoutSchemaNodeAssoc": {
        "parentMtlsniId": this.selRowData.parent === null ? null : this.selRowData.parent.data.id
      }
    };
    if (flag) {
      this.masterTplService.deleteAttrRow(data).subscribe((res) => {
        if (!res.error) {
          this.removeNodeFromTree();
        }
      }, /* istanbul ignore next */ error => {
        this.toastr.error("Server error in removing attribute row.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.removeNodeFromTree();
    }
  }

  /* Delete Row from TreeTable */
  removeNodeFromTree() {
    let _delIndex;
    if (this.selRowData.level === 0) {
      this.treeTableData.filter((_del, index) => {
        if (_del.data.id === this.selRowData.node.data.id) {
          _delIndex = index;
        }
      });
      this.treeTableData.splice(_delIndex, 1);
    } else {
      this.selRowData.parent.children.filter((_del, index) => {
        if (_del.data.id === this.selRowData.node.data.id) {
          _delIndex = index;
        }
      });
      this.selRowData.parent.children.splice(_delIndex, 1);
    }
    this.treeTableData = [...this.treeTableData];
    this.rowEditFlag = false;
    this.toastr.success("Successfully Deleted the row " + this.selRowData.node.data.displayName + "!", "Success!");
    if (this.treeTableData.length === 0) {
      this.pushNewRow(null);
    }
  }

  /* Recursive function to fetch child elements */
  findParent() {
    let pId = this.selRowData.parent === null ? null : this.selRowData.parent.data.id;
    if (pId === null) {
      this.selChildData = this.treeTableData;
      this.pushNewRow("s");
    } else {
      this.findChildData(this.treeTableData, pId);
    }
  }

  /* Get child element nodes based on selected row */
  selChildData: any = [];
  findChildData(mydata, pId) {
    if (mydata !== null) {
      for (let i = 0; i < mydata.length; i++) {
        if (mydata[i].data.id !== pId) {
          this.findChildData(mydata[i].children, pId);
        } else {
          this.selChildData = mydata[i].children;
          this.pushNewRow("s");
          return;
        }
      }
    }
  }

  /* Add new Row on Sibling or Child Level */
  pushNewRow(level) {
    this.rowEditFlag = true;
    let _newRow = [];
    if (level === null) {
      this.treeTableData = [..._newRow, this.newRowObj()];
    }
    else if (level === "s") {
      let _selIndex: number;
      let _childIndex = this.selChildData.filter((_child, index) => {
        if (_child.data.id === this.selRowData.node.data.id) {
          _selIndex = index + 1;
        }
      });
      this.selChildData.splice(_selIndex, 0, this.newRowObj());

    }
    else if (level === "c") {
      let _child = this.selRowData.node["children"];
      if (_child === null || _child === undefined) {
        this.selRowData.node["children"] = [this.newRowObj()];
      }
      else {
        this.selRowData.node.children.push(this.newRowObj());
      }
    }
    this.treeTableData = [...this.treeTableData];
  }

  /* ON/OFF Inline Row Edit */
  rowEditFlag: boolean = false;
  enableEditMode(rowNode) {
    if (this.rowEditFlag) {
      return false;
    }
    if (rowNode.node.editMode === undefined || rowNode.node.editMode === false) {
      if (rowNode.node.data.maxOccurance === null) {
        rowNode.node.data.maxOccurance = ">1";
      }
      rowNode.node["editMode"] = true;
      rowNode.node.data["validMO"] = false;
      rowNode.node.data["validMX"] = false;
      rowNode.node["oldData"] = JSON.stringify(rowNode.node.data);
      this.rowEditFlag = true;
    }
    return false;
  }

  checkValue(e, rowData, name) {
    if (name === "min") {
      if (e.currentTarget.value === "") {
        rowData.minOccurance = 0;
      }
    } else if (name === "max") {
      if (e.currentTarget.value === "" || e.currentTarget.value === 0) {
        rowData.maxOccurance = 1;
      }
    }
  }

  /* Tree Table Lazy Loading */
  /* Action Menu */

  selRowData: any = {};
  actionItems: OverlayPanel;
  selRowIndex: number;
  action(e, rowNode, rowIndex, actionItems) {
    this.selRowIndex = rowIndex;
    this.actionItems = actionItems;
    this.actionItems.toggle(e);
    this.selRowData = rowNode;
  }


  /* Adding sibling to treenode*/
  selSiblingId: number = null;
  selParentId: number = null;
  addSibling() {
    this.selSiblingId = this.selRowData.node.data.id;
    this.selParentId = this.selRowData.parent === null ? null : this.selRowData.parent.data.id;
    this.actionItems.hide();
    this.findParent();
  }

  /* Adding Children to treenode */
  addChild() {
    this.selSiblingId = null;
    this.selParentId = this.selRowData.node.data.id;
    this.actionItems.hide();
    if (this.selRowData.node.leaf && this.selRowData.node.children === undefined) {
      this.onNodeExpand(this.selRowData, true);
    } else {
      this.pushNewRow("c");
    }
    this.selRowData.node["expanded"] = true;
  }


  loadNodes(event) {
    this.btnClicked = true;
    this.tabLoader.emit(true);
    this.masterTplService.getSectionwiseDynamicSchema(this.metaInfo.masterFileTemplateId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.treeTableData = res.data;
        if (this.treeTableData !== null)
          for (let _node of this.treeTableData) {
            _node["oldData"] = JSON.stringify(_node.data);
          }
        this.btnClicked = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }
  onNodeExpand(event, addchild?) {
    let _nodeData = event.node;
    if (_nodeData.children !== undefined) {
      return false;
    }
    _nodeData["children"] = [];
    _nodeData["togglerLoader"] = true;
    this.masterTplService.getDynamicSchemaByParentId(this.metaInfo.masterFileTemplateId, this.selSection, _nodeData.data.id).subscribe(res => {
      if (!res.error) {
        for (let _node of res.data) {
          _node["oldData"] = JSON.stringify(_node.data);
        }
        _nodeData["children"] = res.data;
        this.treeTableData = [...this.treeTableData];
        _nodeData["togglerLoader"] = false;
        if (addchild) {
          this.pushNewRow("c");
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }


}
