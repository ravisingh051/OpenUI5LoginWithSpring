import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";

import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { TOKEN_NAME } from "../../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, Router, ActivatedRoute } from "@angular/router";
import { AlDynamicSchemaGenerationComponent } from "./al-dynamic-schema-generation.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { RouterDetailsService } from "../../../../services/common/router.details";
import { ConfirmationService } from "primeng/components/common/api";
import { HttpClientTestingModule } from "@angular/common/http/testing";


let metaInfo;
let $actionItems;

describe("AlDynamicSchemaGenerationComponent", () => {
  let component: AlDynamicSchemaGenerationComponent;
  let fixture: ComponentFixture<AlDynamicSchemaGenerationComponent>;
  let toastService;
  let ngxPermission;

  function populateData() {
    metaInfo = {
      "masterFileTemplateName": "Outbound Transaction 834 Master 5010",
      "masterFileTemplateId": 2,
      "masterFileTemplateVersion": 1,
      "fileTypeMetaInfo": {
        "fileTypeName": "Outbound Transaction 834",
        "direction": "Outbound"
      },
      "masterFileTemplateRecordId": 2,
      "currentApprovalStatus": null
    };
    return metaInfo;
  }

  beforeEach(async(() => {
    TestBed.overrideComponent(AlDynamicSchemaGenerationComponent, {
      set: {
        providers: [
          ConfirmationService,
          { provide: AlMasterTemplateService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        RouterTestingModule,
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlDynamicSchemaGenerationComponent, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        AppUtility,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        { provide: AlMasterTemplateService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: MockDataService },
        // { provide: ToastsManager, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: Observable, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService },
        { provide: Router, useClass: MockDataService },
        { provide: RouterDetailsService, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1 }) } }

      ]
    });
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(AlDynamicSchemaGenerationComponent);
      component = fixture.debugElement.componentInstance;

      ngxPermission = TestBed.get(NgxPermissionsService);
      ngxPermission.addPermission("Master File Setup-Edit Template");
      component.treeTableData = [
        {
          "data": {
            "id": 1,
            "referenceId": 2,
            "category": "Section",
            "dataType": "NODE",
            "displayName": "Header",
            "parentId": null,
            "description": null,
            "mandatory": true,
            "mappedColumn": null,
            "conditionalDescription": null,
            "selMappedColumnSource": null,
            "attributeName": null,
            "attributeAssocId": null,
            "mappedColumnId": null,
            "hasChildren": true,
            "recordId": null,
            "ftaaId": null,
            "mappedColumnDetailsList": null,
            "lookupTableFileAssociations": null,
            "fileAttrBrAssocs": null
          },
          "leaf": true
        }
      ];
      component.metaInfo = populateData();
      fixture.detectChanges();
    });


    toastService = TestBed.get(ToastsManager);
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should be logging user", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  }));
  it("should loadNodes() & onNodeExpand()", () => {
    let e = {
      "node": {
        "children": []
      }
    };
    component.loadNodes(e);
    component.onNodeExpand(e);
  });





  it("should onNodeExpand() Else, pushNewRow()", () => {
    let e = {
      "node": {
        "data": {
          "id": 1
        },
        "expanded": false,
        "leaf": true,
        "togglerLoader": false
      }
    };
    component.selRowData = {
      "node": {
        "data": {
          "id": 1,
          "referenceId": 2,
          "category": "Section",
          "dataType": "NODE",
          "displayName": "Header",
          "parentId": null,
          "minOccurance": 1,
          "maxOccurance": 1,
          "description": null,
          "mandatory": null,
          "hasChildren": true,
          "rowPosition": 2,
          "lstCtlsNodeBrAssoc": null,
          "lstFlsNodeBrAssoc": null
        },
        "leaf": true
      }
    };
    component.onNodeExpand(e, true);
    component.pushNewRow(null);
    component.pushNewRow("s");
  });

  it("should enableEditMode() IF", () => {
    let rowNode = {
      "node": {
        "editMode": true
      }
    };
    component.rowEditFlag = true;
    component.enableEditMode(rowNode);
  });


  it("should Working Flow", () => {
    let rowNode = {
      "level": 0,
      "node": {
        "data": {
          "id": 1,
          "referenceId": 2,
          "category": "Section",
          "dataType": "NODE",
          "displayName": "Header",
          "parentId": null,
          "minOccurance": 0,
          "maxOccurance": null,
          "description": null,
          "mandatory": null,
          "hasChildren": true,
          "rowPosition": 2,
          "lstCtlsNodeBrAssoc": null,
          "lstFlsNodeBrAssoc": null
        },
        "leaf": true,
      },
      "parent": null,
      "visible": true
    };
    component.enableEditMode(rowNode);
    let e = {};
    let rowIndex = 0;
    let actionItems = {
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    component.action(e, rowNode, rowIndex, actionItems);
    component.addSibling();
    component.addChild();

    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
    });
    component.removeRow();
    component.cancel();
    $actionItems = component.actionItems;
  });
  it("should nextStep()", () => {
    component.activeIndex = 0;
    component.nextStep();
    component.activeIndex = 1;
    component.nextStep();
    component.activeIndex = 2;
    component.nextStep();
  });
  it("should checkValue()", () => {
    let e = {
      "currentTarget": {
        "value": ""
      }
    };
    let rowData = {
      "minOccurance": 0,
      "maxOccurance": 0
    };
    component.checkValue(e, rowData, "min");
    component.checkValue(e, rowData, "max");
  });
  it("should saveRow()", () => {
    component.actionItems = $actionItems;
    component.selRowData = {
      "level": 0,
      "node": {
        "data": {
          "id": 1,
          "referenceId": 2,
          "category": "Section",
          "dataType": "NUMBER",
          "displayName": "Header",
          "parentId": null,
          "maxOccurance": 1,
          "minOccurance": 0,
          "description": "abc",
          "mandatory": null,
          "hasChildren": true,
          "rowPosition": 2,
          "lstCtlsNodeBrAssoc": null,
          "lstFlsNodeBrAssoc": null,
        },
        "leaf": true,
      },
      "parent": null,
      "visible": true
    };
    component.saveRow();
  });
  it("should saveRow() = 'NODE'", () => {
    component.actionItems = $actionItems;
    component.selRowData = {
      "level": 0,
      "node": {
        "data": {
          "id": null,
          "referenceId": 2,
          "category": "Section",
          "dataType": "NODE",
          "displayName": "Header",
          "parentId": null,
          "maxOccurance": ">1",
          "minOccurance": 0,
          "description": "abc",
          "mandatory": null,
          "hasChildren": true,
          "rowPosition": 2,
          "lstCtlsNodeBrAssoc": null,
          "lstFlsNodeBrAssoc": null,
        },
        "leaf": true,
      },
      "parent": null,
      "visible": true
    };
    component.saveRow();
  });
  it("should saveRow() = 'Number'", () => {
    component.actionItems = $actionItems;
    component.selRowData = {
      "level": 0,
      "node": {
        "data": {
          "category": "Section",
          "dataType": "Number",
          "displayName": "Header",
          "maxOccurance": 3,
          "minOccurance": 3
        }
      }
    };
    component.saveRow();
  });
  it("should saveRow() = 'Min'", () => {
    component.actionItems = $actionItems;
    component.selRowData = {
      "level": 0,
      "node": {
        "data": {
          "category": "Section",
          "dataType": "Number",
          "displayName": "Header",
          "maxOccurance": 0,
          "minOccurance": 1
        }
      }
    };
    component.saveRow();
  });
  it("should saveRow() = 'Max'", () => {
    component.actionItems = $actionItems;
    component.selRowData = {
      "level": 0,
      "node": {
        "data": {
          "category": "Section",
          "dataType": "NODE",
          "displayName": "Header",
          "maxOccurance": 3,
          "minOccurance": 5
        }
      }
    };
    component.saveRow();
  });

  it("should saveRow() = 'Max'", () => {
    let mydata = null;
    component.findChildData(mydata, 0);
  });

});


class MockDataService {
  getDataTypes() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-dynamic-schema-generation/getDataTypes.json");
    return (Observable.of(response));
  }
  getSectionwiseDynamicSchema() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-dynamic-schema-generation/loadNodes.json");
    return (Observable.of(response));
  }
  getDynamicSchemaByParentId() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-dynamic-schema-generation/getDynamicSchemaByParentId.json");
    return (Observable.of(response));
  }
  updateAttrRow() {
    let response = { "error": false, "data": true };
    return (Observable.of(response));
  }
  saveAttrRow() {
    let response = { "error": false, "data": { "id": 2542, "referenceId": 2066, "category": "abc", "dataType": null, "displayName": "test", "parentId": 1, "minOccurance": 0, "maxOccurance": 1, "description": null, "mandatory": null, "hasChildren": null, "rowPosition": 126, "lstCtlsNodeBrAssoc": null, "lstFlsNodeBrAssoc": null } };
    return (Observable.of(response));
  }
  deleteAttrRow() {
    let response = { "error": false, "data": true };
    return (Observable.of(response));
  }


  error() {
    return false;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}
class MockActivatedRoute extends ActivatedRoute {
  constructor() {
    super();
    this.params = Observable.of({ id: 555, version: 0 });
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }

}