import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { AlMasterTemplateService } from "./al-master-template-service/al-master-template-service";

@Component({
  selector: "al-master-template",
  templateUrl: "./al-master-template.component.html",
  styleUrls: ["./al-master-template.component.scss"],
  providers: [AlMasterTemplateService]
})
export class AlMasterTemplateComponent implements OnInit {

  constructor(
    private FileSetupRedirect: FileSetupRedirect
  ) { }

  basConfTab: boolean = false;
  attListTab: boolean = true;
  tabLoader_1: string = "";
  tabLoader_2: string = "";
  loaderIcon: string = "fa fa-circle-o-notch fa-spin fa-fw";
  selectedTab: number = 0;
  metaInfo: any = [];
  ngOnInit() {
    this.FileSetupRedirect.changeRoute("F");
    this.pageNavigation("basicConfiguration");
  }
  getmetaInfo(event) {
    this.metaInfo = event;
    this.selFileType = this.metaInfo.fileTypeMetaInfo.direction;
    this.showFileDetails = true;
    this.setTab();
  }
  // Enable All Tabs
  tabContLoader: boolean = false;
  showFileDetails: boolean = false;
  tabNav: Array<{}> = [
    { name: "Basic Configuration", id: "basicConfiguration", isActive: false, isVisible: true, render: "All", excludeId: [] },
    { name: "Attribute List", id: "attrInbound", isActive: false, isVisible: false, render: "Inbound", excludeId: [] },
    { name: "Attribute List", id: "attrOutbound", isActive: false, isVisible: false, render: "Outbound", excludeId: [] },
    { name: "Dynamic Schema Generation", id: "dynSchGen", isActive: false, isVisible: false, render: "Outbound", excludeId: [18] },
    { name: "Attribute Mapping", id: "attrMaping", isActive: false, isVisible: false, render: "Outbound", excludeId: [18] }
  ];
  selTabId: string;
  selTab: any = [];
  pageNavigation(e) {
    if (this.selTabId !== e) {
      this.tabContLoader = true;
      for (let tab of this.tabNav) {
        if (e === tab["id"]) {
          tab["isActive"] = true;
          this.selTabId = e;
          this.selTab = tab;
        } else {
          tab["isActive"] = false;
        }
      }
    }
  }
  selFileType: string;
  isVisible: boolean;
  setTab() {
    for (let tab of this.tabNav) {
      if (tab["render"] === this.selFileType || tab["render"] === "All") {
        let _id = tab["excludeId"].filter((obj) => obj === this.metaInfo.masterFileTemplateId);
        if (_id.length > 0) {
          tab["isVisible"] = false;
          this.isVisible = false;
        } else {
          tab["isVisible"] = true;
          this.isVisible = true;
        }
      } else {
        tab["isVisible"] = false;
        this.isVisible = false;
      }
    }
  }
  tabLoader(e) {
    this.tabContLoader = e;
  }
}
