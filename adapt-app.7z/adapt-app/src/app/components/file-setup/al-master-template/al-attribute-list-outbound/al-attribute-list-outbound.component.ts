import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-attribute-list-outbound",
  templateUrl: "./al-attribute-list-outbound.component.html",
  styleUrls: ["./al-attribute-list-outbound.component.scss"]
})
export class AlAttributeListOutboundComponent implements OnInit {

  @Input() metaInfo: any;
  @Output() tabLoader = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();
  @Input() isVisible: boolean;
  constructor(
    private masterTplService: AlMasterTemplateService,
    private toastr: ToastsManager
  ) { }

  attrData: any = [];
  ngOnInit() {
    this.masterTplService.getAttributeList(this.metaInfo.masterFileTemplateId, this.metaInfo.masterFileTemplateVersion).subscribe(res => {
      if (!res.error) {
        for (let _attr in res.data) {
          this.attrData.push({
            "sectionName": _attr,
            "attributeList": res.data[_attr]
          });
        }
        this.tabLoader.emit(false);
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }
  DynSchGen() {
    this.pageNavigation.emit("dynSchGen");
  }

}
