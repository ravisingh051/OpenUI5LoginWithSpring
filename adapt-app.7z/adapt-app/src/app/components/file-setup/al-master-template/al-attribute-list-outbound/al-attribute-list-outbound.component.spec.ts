import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlMasterTemplateService } from "../al-master-template-service/al-master-template-service";

import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, Router, ActivatedRoute } from "@angular/router";
import { AlAttributeListOutboundComponent } from "./al-attribute-list-outbound.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { RouterDetailsService } from "../../../../services/common/router.details";
import { HttpClientTestingModule } from "@angular/common/http/testing";


let metaInfo;

describe("AlAttributeListOutboundComponent", () => {
  let component: AlAttributeListOutboundComponent;
  let fixture: ComponentFixture<AlAttributeListOutboundComponent>;
  let toastService;

  function populateData() {
    metaInfo = {
      "masterFileTemplateName": "Outbound Transaction 834 Master 5010",
      "masterFileTemplateId": 2,
      "masterFileTemplateVersion": 1,
      "fileTypeMetaInfo": {
        "fileTypeName": "Outbound Transaction 834",
        "direction": "Outbound"
      },
      "masterFileTemplateRecordId": 2,
      "currentApprovalStatus": null
    };
    return metaInfo;
  }

  beforeEach(async(() => {
    TestBed.overrideComponent(AlAttributeListOutboundComponent, {
      set: {
        providers: [
          { provide: AlMasterTemplateService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        RouterTestingModule,
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlAttributeListOutboundComponent, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        AppUtility,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        { provide: AlMasterTemplateService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: MockDataService },
        // { provide: ToastsManager, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: Observable, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService },
        { provide: Router, useClass: MockDataService },
        { provide: RouterDetailsService, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1 }) } }

      ]
    });
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(AlAttributeListOutboundComponent);
      component = fixture.debugElement.componentInstance;
      component.metaInfo = populateData();
    });
    toastService = TestBed.get(ToastsManager);
  }));
  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should be logging user", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  }));
  it("should DynSchGen()", () => {
    component.DynSchGen();
  });


});


class MockDataService {
  getAttributeList() {
    let response;
    response = require("../../../../../assets/test-data/file-setup/al-master-template/al-attribute-list-outbound/getAttributeList.json");
    return (Observable.of(response));
  }

  error() {
    return false;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}
class MockActivatedRoute extends ActivatedRoute {
  constructor() {
    super();
    this.params = Observable.of({ id: 555, version: 0 });
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}