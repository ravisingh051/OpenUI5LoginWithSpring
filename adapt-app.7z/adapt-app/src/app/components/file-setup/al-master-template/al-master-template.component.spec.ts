import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { TOKEN_NAME } from "../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, RouterModule, Router, ActivatedRoute } from "@angular/router";
import { APP_BASE_HREF, Location, CommonModule } from "@angular/common";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";

import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { MasterFileTemplateService } from "../al-file-setup-services/master-file-template-service";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { RouterDetailsService } from "../../../services/common/router.details";
import { AlMasterTemplateComponent } from "./al-master-template.component";
import { HttpClientTestingModule } from "@angular/common/http/testing";




const routes: Routes = [
    {
        path: "file-setup",
        component: AlMasterTemplateComponent
    },
    {
        path: "create",
        component: AlMasterTemplateComponent
    }
];

describe("AlMasterTemplateComponent", () => {
    let component: AlMasterTemplateComponent;
    let fixture: ComponentFixture<AlMasterTemplateComponent>;
    let toastService, fileSetupService, masterFileService;
    let overlaypanel: OverlayPanel;
    let ngxPermission;
    let location: Location;
    const mockRouter = {
        navigate: jasmine.createSpy("navigate")
    };
    const fakeActivatedRoute = {
        snapshot: { data: {} }
    };
    let metaInfo = {
        "masterFileTemplateName": "Inbound Census Master",
        "masterFileTemplateId": 1,
        "masterFileTemplateVersion": 1,
        "fileTypeMetaInfo": {
            "fileTypeName": "Inbound Census",
            "direction": "Inbound"
        },
        "masterFileTemplateRecordId": 1,
        "currentApprovalStatus": null
    };

    beforeEach(() => {
        TestBed.overrideComponent(AlMasterTemplateComponent, {
            set: {
                providers: [
                    { provide: FileSetupService, useClass: MockDataService },
                    { provide: MasterFileTemplateService, useClass: MockDataService },
                    { provide: FileSetupRedirect, useClass: MockDataService },
                    { provide: RouterDetailsService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService },
                    { provide: Observable, useClass: MockDataService },
                    { provide: ToolTipUtilService, useClass: FakeToolTip }
                ]
            }
        });
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                CommonModule,
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule.withRoutes(routes),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlMasterTemplateComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                { provide: FileSetupService, useClass: MockDataService },
                { provide: MasterFileTemplateService, useClass: MockDataService },
                { provide: FileSetupRedirect, useClass: MockDataService },
                { provide: RouterDetailsService, useClass: MockDataService },
                { provide: ConfirmationService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: Observable, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService },
                {
                    provide: APP_BASE_HREF, useValue: "/"
                },
                { provide: ActivatedRoute, useValue: fakeActivatedRoute },
                // { provide: Router, useValue: mockRouter },

            ]
        }).compileComponents();

        fixture = TestBed.createComponent(AlMasterTemplateComponent);
        component = fixture.debugElement.componentInstance;
        toastService = TestBed.get(ToastsManager);

        ngxPermission = TestBed.get(NgxPermissionsService);
        ngxPermission.addPermission("Master File Setup-View All Master list");
        ngxPermission.addPermission("File Setup-View All File list");

        fileSetupService = fixture.debugElement.injector.get(FileSetupService);
        masterFileService = fixture.debugElement.injector.get(MasterFileTemplateService);
        component.metaInfo = metaInfo;
    });
    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should be logging user", async(() => {
        component.ngOnInit();
    }));
    it("getmetaInfo", () => {
        component.getmetaInfo(metaInfo);
    });
    it("tabLoader", () => {
        component.tabLoader(true);
    });
});

class MockDataService {
    changeRoute(id) {
        let response;
        response = require("../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }
    error() {
        return false;
    }
    success() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAngetToolTipTextDetailsdFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
