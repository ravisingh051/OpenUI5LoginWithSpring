import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { AlMasterTemplateService } from "./al-master-template-service";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlMasterTemplateService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                AlMasterTemplateService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getMasterTemplateById", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getMasterTemplateById({}).subscribe((res) => {
        });
    })));

    it("getAttributeList", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getAttributeList({}).subscribe((res) => {
        });
    })));

    it("getDynamicSchemaGeneration", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getDynamicSchemaGeneration({}).subscribe((res) => {
        });
    })));

    it("getAttrMappingData", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getAttrMappingData({}).subscribe((res) => {
        });
    })));

    it("getAttributeListOutbound", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getAttributeListOutbound({}).subscribe((res) => {
        });
    })));

    it("getMappedColumns", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getMappedColumns({}).subscribe((res) => {
        });
    })));

    it("saveMappedColumns", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.saveMappedColumns({}).subscribe((res) => {
        });
    })));

    it("getChildrenAttr", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getChildrenAttr({}).subscribe((res) => {
        });
    })));

    it("saveAttrRow", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.saveAttrRow({}).subscribe((res) => {
        });
    })));

    it("updateAttrRow", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.updateAttrRow({}).subscribe((res) => {
        });
    })));

    it("deleteAttrRow", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.deleteAttrRow({}).subscribe((res) => {
        });
    })));

    it("getDataTypes", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getDataTypes({}).subscribe((res) => {
        });
    })));

    it("saveAttrMappingRow", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.saveAttrMappingRow({}).subscribe((res) => {
        });
    })));

    it("getMapColDropDown", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getMapColDropDown({}).subscribe((res) => {
        });
    })));

    it("getSectionwiseDynamicSchema", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getSectionwiseDynamicSchema({}).subscribe((res) => {
        });
    })));

    it("getDynamicSchemaByParentId", async(inject([AlMasterTemplateService], (contactService) => {
        let response = require("../../../../../assets/test-data/blank.json");
        contactService.getDynamicSchemaByParentId({}).subscribe((res) => {
        });
    })));



});