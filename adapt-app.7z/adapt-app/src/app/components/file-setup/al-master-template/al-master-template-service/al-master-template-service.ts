import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../env.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlMasterTemplateService {

    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }
    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/MasterTemplate/";
    attrServiceMappingURL = this.apiEnvEndpoint + "/MasterAttributeMapping/";
    defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });

    getMasterTemplateById(id, version, viewOnly): Observable<any> {
        return this.http.get(this.serviceMappingURL + "getById?masterFileTemplateId=" + id + "&masterFileTemplateVersion=" + version);
    }

    getAttributeList(id, version): Observable<any> {
        return this.http.get(this.attrServiceMappingURL + "getAttributeList?masterFileTemplateId=" + id + "&masterFileTemplateVersion=" + version);
    }

    getDynamicSchemaGeneration(recordId, section): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/getSchema?recordId=" + recordId + "&sectionId=" + section);
    }

    getAttrMappingData(recordId, section): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/getSectionwiseAttributeMapping?recordId=" + recordId + "&sectionId=" + section);
    }

    getAttributeListOutbound(recordId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/getAttributeList?id=" + recordId);
    }

    getMappedColumns(id): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/getMappedColumns?id=" + id);
    }

    saveMappedColumns(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/MasterOutbound/updateMappedColumns", data);
    }

    getChildrenAttr(recordId, sectionId, parentId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/getAttributeMappingByParentId?recordId=" + recordId + "&sectionId=" + sectionId + "&parentId=" + parentId);
    }
    saveAttrRow(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/MasterOutbound/saveRow", data);
    }
    updateAttrRow(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/MasterOutbound/updateRow", data);
    }
    deleteAttrRow(data): Observable<any> {
        return this.http.post(this.apiEnvEndpoint + "/MasterOutbound/deleteRow", data);
    }

    getDataTypes(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/AttributeDataTypes/details");
    }

    saveAttrMappingRow(data, mappedColumnConfiguration): Observable<any> {
        return this.http.put(this.apiEnvEndpoint + "/MasterOutbound/NodeInfo?mappedColumnConfiguration=" + mappedColumnConfiguration, data);
    }

    getMapColDropDown(masterRecordId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "Sections?masterRecordId=" + masterRecordId + "&sectionShortName=D");
    }

    /* Lazy Loading */
    getSectionwiseDynamicSchema(recordId, sectionId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/Schemas?recordId=" + recordId + "&sectionId=" + sectionId);
    }
    getDynamicSchemaByParentId(recordId, sectionId, nodeId): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/MasterOutbound/Schemas?recordId=" + recordId + "&sectionId=" + sectionId + "&parentId=" + nodeId);
    }


}