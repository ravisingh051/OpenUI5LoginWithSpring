import { async, ComponentFixture, TestBed } from "@angular/core/testing";


// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, RouterModule, Router, ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { FormsModule, NgForm } from "@angular/forms";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService, ColorPicker } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";


// COMPONENT
// =========================
import { AlFileBasicConfiguration } from "./al-file-basic-configuration";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { ApiEnvService } from "../../../../env.service";

// SERVICE
// =========================
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { LobService } from "../../../commons/al-lob/al-lob-services/lob.service";
import { LoginService } from "../../../login/login.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";


// Mock data
// =========================
let metaInfo;
const routes: Routes = [];
let router: Router;
const mockRouter = {
    navigate: jasmine.createSpy("navigate")
};

describe("AlFileBasicConfiguration", () => {
    let component: AlFileBasicConfiguration;
    let fixture: ComponentFixture<AlFileBasicConfiguration>;
    let toastService, alNotificationsService;

    beforeEach(async(() => {
        TestBed.overrideComponent(AlFileBasicConfiguration, {
            set: {
                providers: [
                    { provide: FileSetupService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });

        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule.withRoutes([]),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlFileBasicConfiguration, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                ApiEnvService,
                LobService,
                LoginService,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: ConfirmationService, useClass: MockDataService },
                { provide: FileSetupService, useClass: MockDataService },
                { provide: LoginService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService }

            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlFileBasicConfiguration);
            component = fixture.debugElement.componentInstance;
            let response;
            response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/metaInfo.json");
            metaInfo = response.data;
            component.metaInfo = metaInfo;
            let _tpData = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/getTradingPartnerDetails.json");
            component.fileSetupTradingPartnerList = _tpData.data;
            component.employerList = [{
                "employerName": "abc",
                "employerId": 1
            }];
            component.lobArray = [{
                "lobId": 1,
                "lobDescription": "Employer Interface Files",
                "size": 0,
                "lobName": "Employer Interface Files1"
            },
            {
                "lobId": 23,
                "lobDescription": null,
                "lobName": "Outbound LOB"
            }];
        });
    }));

    it("should create", async(() => {
        expect(component).toBeTruthy();
    }));

    it("should getFileEmployerAssoc()", () => {
        component.getFileEmployerAssoc();
    });


    it("should populateEditFormData() getLOBList(), updateTradingType(), getAssignedTeam()", () => {
        component.populateEditFormData();
        component.getLOBList(23);
        let ev = {};
        component.tradingPartnerId = 411;
        toastService = TestBed.get(ToastsManager);
        component.updateTradingType(ev);
        component.assignedTeam = [{
            "createdBy": "A0752604",
            "createdDateTime": "28/06/2018 08:54:07.693 GMT",
            "updatedBy": "A0752604",
            "updatedDateTime": "28/06/2018 08:54:07.693 GMT",
            "idisTeamId": 27,
            "idisTeamName": "ACA ER Reporting",
            "idisTeamDescription": null,
            "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
        }];
        // component.getAssignedTeam(27);
        component.metaInfo.fileProcessingErrorThresholdFormat = "No Threshold";
        let obj = {
            value: "",
            name: "abc"
        };
        // component.validateNegativeValue(obj);
        component.metaInfo.fileProcessingErrorThresholdFormat = "Percentage of Records";
        let obj2 = {
            value: 1
        };
        // component.validateNegativeValue(obj2);

        component.viewOnly = true;
        component.metaInfo.isMultiEmployer = true;
        // component.populateEditFormData();

    });

    it("should Misc Functions", () => {
        component.lobModel = 23;
        component.setLobName();
        component.metaInfo.fileAssociatedWebsite = "http://www.google.com";
        component.checkValidWebsiteUrl();
        component.routeToNewFile();
        component.overwriteAnlst = true;
        component.setAnlstValue();
        component.btnCancel();
        component.updateEmpList();
        component.changeTradingPartnerPlatforms();
    });

    it("should saveTemplateFile()", () => {
        let form = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                email: "",
                firstName: ""
            }
        };
        component.dropDown = <any>{
            reset: () => null,
            toArray: () => [{ value: 1, filterValue: null }, { value: 2, filterValue: null }],
            value: [{ value: 1, filterValue: null }, { value: 2, filterValue: null }]
        };
        component.overwriteAnlst = true;
        component.metaInfo.empName = "Dharam Mali";
        component.metaInfo.fileAssociatedWebsite = "http://www.google.com";
        component.metaInfo.isMultiEmployer = true;
        component.clientIds = [{ "clientEmployerAssocId": 1 }];
        component.flowStatus = "save";
        component.metaInfo.assignedTeam = ["15"];
        component.saveTemplateFile(form);
        component.metaInfo.editMode = true;
        component.saveTemplateFile(form);
    });
    it("should saveForm(), validateNumber()", () => {
        component.saveForm("save");
        component.saveForm("Save & Continue");
        let event = {
            "keyCode": 8
        };
        component.validateNumber(event);
        let event2 = {
            "keyCode": 47
        };
        component.validateNumber(event2);
        let event3 = {
            "keyCode": 49
        };
        component.validateNumber(event2);

        component.overwriteAnlst = false;
        component.setAnlstValue();
        component.basicConfNextFn();

        let e = {};
        component.metaInfo.empName = 1;
        component.updateClientId(e);
        component.metaInfo.isMultiEmployer = true;
        component.updateClientId(e);
        component.checkIfEmployerIsUnassigned();
        component.metaInfo.isMultiEmployer = true;
        component.checkIfEmployerIsUnassigned();
    });


    it("should getToolTipTextDetails(), displayToolTipText()", () => {
        component.getToolTipTextDetails();
        component.toolTipFileBasic = {
            "Test": {
                "tooltipDesc": "Test Email Address description",
                "readMoreLink": "http://www.google.com"
            }
        };
        let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));


        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "Test", "bottom");
            component.hideToolTipText(event);
        });
        btnNextStep.click();
    });


    it("populateDropDownForSelectedId(), subscribeFormChanges()", () => {
        component.subscribeFormChanges();
    });

});


class MockDataService {

    // loginService methods
    // =============================

    getMail(): Observable<any> {

        return (Observable.of("test@test.com"));
    }

    isEmployerHaveAccess() {

        return (true);
    }

    // fileSetupService methods
    // =============================

    testAnalyst(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    createFile(): Observable<any> {
        let response;
        response = {
            "error": false,
            "data": {
                "recordId": 1,
                "fileVersion": 1
            }
        };
        return (Observable.of(response));
    }

    updateFiles(): Observable<any> {
        let response;
        response = {
            "error": false,
            "data": {
                "recordId": 1,
                "fileVersion": 1,
                "approvalStatus": 2
            }
        };
        return (Observable.of(response));
    }

    getAssignedTeam(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/getAssignedTeam.json");
        return (Observable.of(response));
    }


    getLOBList(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getTradingPartnerDetails(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getFileEmployerAssoc(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getTradingPartner(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getTradingPartnerPlatformsByTPId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/getTradingPartnerDetails.json");
        return (Observable.of(response));
    }

    // toolTipUtils methods
    // =============================

    getPageAndFieldsDetails(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getToolTipTextDetails.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }

    success() {
        return true;
    }

    changeRoute() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
