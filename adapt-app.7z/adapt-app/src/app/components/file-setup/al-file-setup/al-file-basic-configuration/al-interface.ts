export interface MetaInfoInterface {
    fileName: string;
    isTemplate: boolean;
    analystName: string;
    recordId: number;
    tradingPartnerPlatformInfo: {
        tradingPartnerPlatformId: any;
        tradingPartnerPlatformList?: any;
    };
    fileTypeMetaInfo: {
        fileTypeName: string;
        direction: string;
        fileTypeId: number;
    };
    fileIdGenerator: {
        fileId: number;
    };
    fileMinRecordCountAllowed: number;
    fileMaxRecordCountAllowed: number;
    fileAssociatedWebsite: string;
    assignedTeam: any;
    oldFileId: number;
    isMultiEmployer: boolean;
    fileFormatSupported: {
        fileFormatName: string;
        fileFormatFieldDelimiter: string;
        fileFormatRowDelimiter: string;
        fileFormatSupportedId: number;
    };
    fileStatus: string;
    fileVersion: number;
    fileProcessingErrorThresholdFormat: string;
    fileProcessingErrorThresholdCount: number;
    slaMapped: boolean;
    createdBy: any;
    idisTeamFileAssociation: any;
    analystEmail: string;
    fileEmployerAssoc: any;
    fileTradingPartnerLobAssoc: any;
    tradingPartnerType: any;
    fileDataExtractionMode: boolean;
    appendFileRunDate: boolean;
    fileLayout: string;
    masterFileTemplateRecordId: number;
    currentApprovalStatus: number;
    masterFileTemplateMetaInfo: {
        masterFileTemplateId: number;
        masterFileTemplateVersion: number;
        masterFileTemplateRecordId: number;
        masterFileTemplateName: string;
    };
    approvalStatusComment: string;
    approvalStatusUpdatedBy: string;
    approvalStatusUpdatedDate: any;
    editedBy: string;
    editorComment: string;
    dataTargetTypeId: number;
    dataSourceTypeId: number;
    isActive: boolean;
    approvalStatus: number;
    fileTplApprovalStatus: number;

    editMode?: boolean;
    empName?: any;
    lobName?: string;
    employers?: any;
    employerId?: number;
    clientFileType?: string;
    tradingPartner?: any;
    tradingPartnerName?: string;
    tradingPartnerPlatformName?: string;
    tradingPartnerPlatformList?: any;
    tradingPartnerPlatformId?: number;
};