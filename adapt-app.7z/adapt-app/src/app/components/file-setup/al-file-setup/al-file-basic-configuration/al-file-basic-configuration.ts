import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, Input, ViewChildren, QueryList } from "@angular/core";
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { ToastsManager } from "ng2-toastr";
import { NgForm } from "@angular/forms";
import { LobService } from "../../../commons/al-lob/al-lob-services/lob.service";
import { Router } from "@angular/router";
import { forEach } from "@angular/router/src/utils/collection";
import { CURRENT_USER } from "../../../login/login.constant";
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/observable/forkJoin";
import { ConfirmationService } from "primeng/components/common/api";
import { PickListModule } from "primeng/primeng";
import { LoginService } from "../../../login/login.service";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { TOAST_SETTING } from "../../../../global";
import { MetaInfoInterface } from "./al-interface";


@Component({
  selector: "al-file-basic-configuration",
  templateUrl: "./al-file-basic-configuration.html",
  styleUrls: ["./al-file-basic-configuration.scss"],
  providers: [FileSetupService, ConfirmationService, LobService]
})
export class AlFileBasicConfiguration implements OnInit {

  @Input() metaInfo: MetaInfoInterface;
  @Input() masterFileId: number;
  lobArray: any;
  assignedTeam: any;
  selAssignedTeam: any;
  lobModel: any;

  fileSetupTradingPartnerList: any = [];

  tradingPtnType: string;
  flowStatus: string;
  btnClicked: boolean = true;
  inputWebsiteListEdit: any = [];
  fileStatus: boolean;
  inputWebsiteValidation: boolean = false;

  overwriteAnlst: boolean = false;
  ovrtAnlstName: string = "";
  analystName: string = "";
  analystEmail: string = "";
  employerList: any = [];
  toolTipFileBasic: any = [];
  tooltipResult: any;
  pageID: number = 16;
  tradingPartnerDropDownList: any[];
  empClientIds: Array<string> = [];
  empName: any = [];


  // View Only
  @Input() viewOnly;
  @ViewChild("fileTypeName") fileTypeName: ElementRef;
  @Output("saveCountinueBtn") saveCountinueBtn = new EventEmitter();
  @Output("tabLoader") tabLoader = new EventEmitter();
  editFormRecordId: any;
  actionName: string;
  newFile: boolean = true;

  tradingPartnerId: number;
  tradingPartnerName: any;
  lineOfBusinessId: number;
  tradingPtnr: any = []; // Trading Partners Data
  tradingPartnerPlatformList: any = [];
  // Unassinged Employer Name ID in database is 772
  unassingedEmployerId: number = 772;
  @Output() pageNavigation = new EventEmitter();
  @ViewChildren("dropdown") dropDown: QueryList<Dropdown>;

  constructor(
    private lobService: LobService,
    private fileSetupService: FileSetupService,
    public toastr: ToastsManager,
    private router: Router,
    private confirmationService: ConfirmationService,
    private loginService: LoginService,
    private toolTipUtils: ToolTipUtilService
  ) {
  }
  lookuptable: any = [];


  /* istanbul ignore next */
  ngOnInit() {
    if (this.metaInfo.recordId === undefined) {
      this.blankMetaInfo();
      this.fileCreateMode();
      this.loginService.getMail.subscribe((value) => {
        this.analystEmail = value;
      });
    } else {
      this.fileEditMode();
      this.newFile = false;
    }
    this.getEmployer();
    this.getToolTipTextDetails();
  }
  /* istanbul ignore next */
  fileCreateMode() {
    this.metaInfo.editMode = false;
    this.btnClicked = true;
    Observable.forkJoin(
      this.fileSetupService.getAssignedTeam(),
      this.lobService.getLOBList(),
      this.fileSetupService.getTradingPartnerDetails(),
      this.fileSetupService.getFileEmployerAssoc(),
      this.fileSetupService.getMasterFileDetails(),
    ).subscribe(data => {
      this.getAssignedTeam(null, data[0].data);
      this.lobArray = data[1].data;
      this.fileSetupTradingPartnerList = data[2].data;
      this.employerList = data[3].data;
      this.tabLoader.emit(false);
      this.getFileEmployerAssoc();
      this.populateTPDropDown();
      this.populateMasterFileDetails(data[4].data);
      this.metaInfo.fileFormatSupported.fileFormatRowDelimiter = String.fromCharCode(10);
    });
    this.metaInfo.fileStatus = "Active";
    let currentUser = JSON.parse(localStorage.getItem(CURRENT_USER));
    this.metaInfo.createdBy = currentUser.profileName;
    this.metaInfo.analystName = currentUser.profileName;
    this.btnClicked = false;
  }

  fileTrainingMode: boolean = false;
  /* istanbul ignore next */
  fileEditMode() {
    this.metaInfo.editMode = true;
    this.fileSetupTradingPartnerList = [];
    this.assignedTeam = [];
    Observable.forkJoin(
      this.fileSetupService.getAssignedTeam(),
      this.lobService.getLOBList(),
      this.fileSetupService.getTradingPartnerDetails(),
      this.fileSetupService.getFileEmployerAssoc(),
    ).subscribe(data => {
      this.getAssignedTeam(this.metaInfo.idisTeamFileAssociation, data[0].data);
      this.lobArray = data[1].data;
      this.fileSetupTradingPartnerList = data[2].data;
      this.employerList = data[3].data;
      this.populateTPDropDown();
      this.populateEditFormData();
      this.tabLoader.emit(false);
      this.getFileEmployerAssoc();
    });
  }


  getFileEmployerAssoc() {
    for (let emplyr of this.employerList) {
      emplyr["label"] = emplyr.employerName;
      emplyr["value"] = emplyr.employerId;
    }
  }


  /* istanbul ignore next */
  populateEditFormData() {
    this.analystEmail = this.metaInfo.analystEmail;
    this.empName = [];
    if (!this.viewOnly) {
      if (this.metaInfo.isMultiEmployer) {
        for (let ids of this.metaInfo.fileEmployerAssoc) {
          this.employerList.filter((obj) => {
            if (obj.clientEmployerAssocId === ids.clientEmployerAssocId) {
              this.clientIds.push(obj);
              this.empName.push(obj.employerId);
              this.empClientIds.push(obj.clientId);
            }
          });
        }
      }
      else {
        this.employerList.filter((obj) => {
          if (obj.clientEmployerAssocId === this.metaInfo.fileEmployerAssoc[0].clientEmployerAssocId) {
            this.clientIds.push(obj);
            this.empName.push(obj.employerId);
            this.empClientIds.push(obj.clientId);
          }
        });
      }
    }
    if (this.metaInfo.fileTradingPartnerLobAssoc.length !== 0) {
      this.fileSetupTradingPartnerList.push(this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo);
      this.metaInfo.tradingPartnerType = this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerType;
      // Getting all Trading Partner Infor
      this.tradingPartnerId = this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerId;
      this.getTradingPartner(this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerId);
      this.getTradingPartnerPlatform(this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerId);
      // Getting LOB List and set selected one
      this.lineOfBusinessId = this.metaInfo.fileTradingPartnerLobAssoc[0].lob.lobId;
      this.getLOBList(this.metaInfo.fileTradingPartnerLobAssoc[0].lob.lobId);
      // Set Trading Partner Type
      this.tradingPtnType = this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo.tradingPartnerType;
    }


    if (this.metaInfo.fileAssociatedWebsite !== null) {
      this.inputWebsiteListEdit = this.metaInfo.fileAssociatedWebsite.split(",");
    }
    if (this.metaInfo.fileVersion > 1 && this.metaInfo.fileStatus === "Training") {
      this.fileTrainingMode = true;
    }
    if (this.viewOnly) {
      let _tepmList = [];
      if (this.metaInfo.isMultiEmployer) {
        for (let ids of this.metaInfo.fileEmployerAssoc) {
          this.employerList.filter((obj) => {
            if (obj.clientEmployerAssocId === ids.clientEmployerAssocId) {
              this.clientIds.push(obj);
              this.empName.push(obj.employerId);
              _tepmList.push(obj);
              this.empClientIds.push(obj.clientId);
            }
          });
        }
      }
      else {
        this.employerList.filter((obj) => {
          if (obj.clientEmployerAssocId === this.metaInfo.fileEmployerAssoc[0].clientEmployerAssocId) {
            this.clientIds.push(obj);
            this.empName.push(obj.employerId);
            _tepmList.push(obj);
            this.empClientIds.push(obj.clientId);
          }
        });
      }
      let _tempTeam = [];
      for (let _team of this.selAssignedTeam) {
        let _filter = this.assignedTeam.filter((obj) => obj.idisTeamId === Number(_team));
        _tempTeam.push(_filter[0]);
      }
      this.employerList = _tepmList;
      this.assignedTeam = _tempTeam;
    }
    this.tabLoader.emit(false);
    this.btnClicked = false;
  }

  /* istanbul ignore next */
  validateNegativeValue(obj) {
    if (this.metaInfo.fileProcessingErrorThresholdFormat === "No Threshold") {
      this.metaInfo.fileProcessingErrorThresholdCount = 0;
    }
    if (obj.value < 0 || obj.value === "") {
      obj.value = 0;
      if (obj.name.indexOf("error") !== -1) {
        this.metaInfo.fileProcessingErrorThresholdCount = 0;
      }
    }
    if (this.metaInfo.fileProcessingErrorThresholdFormat === "Percentage of Records") {
      let _checkErros = obj.value.toString().split(".");
      if (_checkErros.length > 1) {
        this.thresholdEFError = true;
      }
      else {
        this.thresholdEFError = false;
      }
    } else {
      this.thresholdEFError = false;
    }
  }
  getLOBList(obj) {
    if (obj != null) {
      this.lobModel = obj;
      let lobList = this.lobArray;
      for (let i = 0; i < lobList.length; i++) {
        if (lobList[i].lobId === obj) {
          this.metaInfo.lobName = lobList[i].lobName;
        }
      }
    }
  }

  getTradingPartner(obj) {
    this.metaInfo.tradingPartnerType = "";
    this.metaInfo.tradingPartner = "";
    if (obj != null) {
      this.metaInfo.tradingPartner = obj;
      this.metaInfo.tradingPartnerType = obj;
      let tradingParnerList = this.fileSetupTradingPartnerList;
      for (let i = 0; i < tradingParnerList.length; i++) {
        if (tradingParnerList[i].tradingPartnerId === obj) {
          this.metaInfo.tradingPartnerName = tradingParnerList[i].tradingPartnerName;
          this.metaInfo.tradingPartner = tradingParnerList[i].tradingPartnerId;
        }
      }
    }
  }

  updateTradingType(ev) {
    let selected = this.fileSetupTradingPartnerList.filter(obj => {
      if (obj.tradingPartnerId === this.metaInfo.tradingPartner) {
        this.metaInfo.tradingPartnerName = obj.tradingPartnerName;
        return obj;
      }
    });
    this.tradingPtnType = selected[0].tradingPartnerType;
  }

  /* istanbul ignore next */
  getAssignedTeam(obj, resData?) {
    if (resData != null) {
      this.assignedTeam = resData;
    }
    if (obj != null) {
      let selectedTeamArray = [];
      for (let i = 0; i < obj.length; i++) {
        selectedTeamArray.push(obj[i].idisTeam.idisTeamId.toString());
      }
      this.selAssignedTeam = selectedTeamArray;
    }
  }


  /* istanbul ignore next */
  getEmployer() {
    let currentUser = JSON.parse(localStorage.getItem(CURRENT_USER));
    this.metaInfo.employers = currentUser.employeeList;
    this.subscribeFormChanges();
  }

  setLobName() {
    this.metaInfo.lobName = "";
    this.lobArray.filter(obj => {
      if (obj.lobId === this.lobModel) {
        this.metaInfo.lobName = obj.lobName;
      }
    });
  }


  checkValidWebsiteUrl() {
    if (this.metaInfo.fileAssociatedWebsite !== null && this.metaInfo.fileAssociatedWebsite !== undefined) {
      let webUrl = this.metaInfo.fileAssociatedWebsite.split(",");
      for (let value of webUrl) {
        if (value.length > 250) {
          return true;
        }
      }
    }
    return false;
  }

  saveTemplateFile(form: NgForm) {
    if (!this.metaInfo.isTemplate && this.checkIfEmployerIsUnassigned()) {
      return this.toastr.error("Please select a valid employer to continue file configuration.", "Oops!", TOAST_SETTING);
    }
    if (!this.metaInfo.isTemplate && !this.loginService.isEmployerHaveAccess(this.empClientIds)) {
      return this.toastr.error("You do not have permission to create a file for the employer selected.", "Oops!", TOAST_SETTING);
    }
    let dropArr = this.dropDown.toArray();
    dropArr.forEach((ele) => {
      ele.filterValue = null;
    });
    if (this.overwriteAnlst === true) {
      this.fileSetupService.testAnalyst(this.ovrtAnlstName).subscribe(res => {
        if (!res.error) {
          if (res.data != null) {
            this.analystName = res.data.name;
            this.analystEmail = res.data.email;
            this.saveNewFileSetup(form);
          } /* istanbul ignore next */  else {
            this.toastr.error("Please enter valid Analyst/File Owner Details.", "Oops!", TOAST_SETTING);
            this.tabLoader.emit(false);
          }
        } /* istanbul ignore next */  else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, /* istanbul ignore next */ error => {
        this.toastr.error("Server Error in getting Analyst/File Owner Details.", "Oops!", TOAST_SETTING);
      });
    }
    else {
      this.saveNewFileSetup(form);
    }
  }

  thresholdEFError: boolean = false;
  /* istanbul ignore next */
  saveNewFileSetup(form: NgForm) {
    if (this.checkValidWebsiteUrl() === true) {
      this.inputWebsiteValidation = true;
      return true;
    }
    if (this.thresholdEFError) {
      return true;
    }
    this.btnClicked = true;
    this.inputWebsiteValidation = false;
    if (this.metaInfo.fileFormatSupported.fileFormatName === "FIXED_WIDTH") {
      if (this.metaInfo.fileTypeMetaInfo.direction === "Inbound") {
        this.metaInfo.dataSourceTypeId = 3;
        this.metaInfo.dataTargetTypeId = 2;
      } else if (this.metaInfo.fileTypeMetaInfo.direction === "Outbound") {
        this.metaInfo.dataSourceTypeId = 2;
        this.metaInfo.dataTargetTypeId = 3;
      }
    } else {
      if (this.metaInfo.fileTypeMetaInfo.direction === "Inbound") {
        this.metaInfo.dataSourceTypeId = 1;
        this.metaInfo.dataTargetTypeId = 2;
      } else if (this.metaInfo.fileTypeMetaInfo.direction === "Outbound") {
        this.metaInfo.dataSourceTypeId = 2;
        this.metaInfo.dataTargetTypeId = 1;
      }
    }
    this.tabLoader.emit(true);
    let data: any = {
      "fileDataExtractionMode": this.metaInfo.fileDataExtractionMode,
      "appendFileRunDate": this.metaInfo.appendFileRunDate,
      "fileName": this.metaInfo.fileName,
      "fileIdisBAId": this.metaInfo.analystName,
      "fileProcessingErrorThresholdCount": form.value.error,
      "fileMinRecordCountAllowed": this.metaInfo.fileMinRecordCountAllowed,
      "fileMaxRecordCountAllowed": this.metaInfo.fileMaxRecordCountAllowed,
      "employerId": this.metaInfo.employerId,
      "clientFileType": this.metaInfo.clientFileType,
      "tradingPartnerName": this.metaInfo.tradingPartnerName,
      "lobName": this.metaInfo.lobName,
      "fileAssociatedWebsite": this.metaInfo.fileAssociatedWebsite,
      "oldFileId": this.metaInfo.oldFileId,
      "fileStatus": this.metaInfo.fileStatus,
      "fileVersion": 1,
      "isActive": false,
      "isTemplate": this.metaInfo.isTemplate,
      "approvalStatus": 1,
      "masterFileTemplateMetaInfo": {
        "masterFileTemplateId": this.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateId,
        "masterFileTemplateVersion": this.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateVersion
      },
      "fileTypeMetaInfo": {
        "fileTypeName": this.metaInfo.fileTypeMetaInfo.fileTypeName,
        "direction": this.metaInfo.fileTypeMetaInfo.direction,
        "fileTypeId": this.metaInfo.fileTypeMetaInfo.fileTypeId
      },
      "fileIdGenerator": {
        "fileId": this.metaInfo.fileIdGenerator.fileId,
      },
      "fileTradingPartnerLobAssoc": [],
      "idisTeamFileAssociation": [],
      "fileEmployerAssoc": [],
      "fileFormatSupported": {
        "fileFormatName": this.metaInfo.fileFormatSupported.fileFormatName,
        "fileFormatRowDelimiter": this.metaInfo.fileFormatSupported.fileFormatRowDelimiter,
        "fileFormatSupportedId": this.metaInfo.fileFormatSupported.fileFormatSupportedId,
        "fileFormatFieldDelimiter": this.metaInfo.fileFormatSupported.fileFormatFieldDelimiter,
        "fileHasFooter": false,
        "fileHasHeader": false
      },
      "tradingPartnerPlatformInfo": null,
      "approvalStatusComment": this.metaInfo == null ? null : this.metaInfo.approvalStatusComment,
      "approvalStatusUpdatedBy": this.metaInfo == null ? null : this.metaInfo.approvalStatusUpdatedBy,
      "approvalStatusUpdatedDate": this.metaInfo == null ? null : this.metaInfo.approvalStatusUpdatedDate,
      "editedBy": this.metaInfo == null ? null : this.metaInfo.editedBy,
      "editorComment": this.metaInfo == null ? null : this.metaInfo.editorComment,
      "isMultiEmployer": this.metaInfo.isMultiEmployer,
      "fileProcessingErrorThresholdFormat": this.metaInfo.fileProcessingErrorThresholdFormat,
      "masterFileTemplateRecordId": this.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateRecordId,
      "slaMapped": this.metaInfo.slaMapped,
      "dataTargetTypeId": this.metaInfo.dataTargetTypeId,
      "dataSourceTypeId": this.metaInfo.dataSourceTypeId
    };

    if (this.empName === undefined || this.empName.length === 0) {
      this.tabLoader.emit(false);
      this.btnClicked = false;
      return false;
    }
    if (this.metaInfo.isMultiEmployer) {
      for (let ids of this.clientIds) {
        data["fileEmployerAssoc"].push({
          "fileMetaInfo": this.metaInfo,
          "clientEmployerAssocId": ids.clientEmployerAssocId
        });
      }
    }
    else {
      data["fileEmployerAssoc"].push({
        "fileMetaInfo": this.metaInfo,
        "clientEmployerAssocId": this.clientIds[0].clientEmployerAssocId
      });
    }
    if (this.metaInfo.tradingPartnerPlatformInfo.tradingPartnerPlatformId !== undefined) {
      data["tradingPartnerPlatformInfo"] = { "tradingPartnerPlatformId": this.metaInfo.tradingPartnerPlatformInfo.tradingPartnerPlatformId };
    }
    if (this.overwriteAnlst === true) {
      data.createdBy = this.analystName;
      data.analystName = this.analystName;
    }
    else {
      data.createdBy = this.metaInfo.createdBy;
      data.analystName = this.metaInfo.analystName;
    }
    data.analystEmail = this.analystEmail;
    let fileLobTradingData = data.fileTradingPartnerLobAssoc;
    let fileTeamData = data.idisTeamFileAssociation;
    fileLobTradingData.push({
      fileMetaInfo: this.metaInfo,
      tradingPartnerInfo: {
        tradingPartnerId: this.tradingPartnerId,
      }, lob: { lobId: this.lineOfBusinessId }
    });
    if (this.metaInfo.recordId !== undefined) {
      // Versioning
      data.fileVersion = this.metaInfo.fileVersion;
      data.isActive = this.metaInfo.isActive;
      data.approvalStatus = this.metaInfo.approvalStatus;

      data.recordId = this.metaInfo.fileTplApprovalStatus === 3 ? null : this.metaInfo.recordId;
      let filterTeam = [];

      for (let i = 0; i < this.selAssignedTeam.length; i++) {
        if (this.metaInfo.idisTeamFileAssociation.length > i &&
          Number(this.selAssignedTeam[i]) === this.metaInfo.idisTeamFileAssociation[i].idisTeam.idisTeamId) {
          filterTeam.push(this.metaInfo.idisTeamFileAssociation[i]);
        } else {
          this.assignedTeam.filter(obj => {
            if (Number(this.selAssignedTeam[i]) === obj.idisTeamId) {
              filterTeam.push({
                "fileMetaInfo": this.metaInfo,
                "idisTeam": obj
              });
            }
          });
        }
      }
      data.idisTeamFileAssociation = filterTeam;
    } else {
      if (this.selAssignedTeam.length > 0) {
        for (let key of this.selAssignedTeam) {
          let _email = this.assignedTeam.filter((obj) => obj.idisTeamId === Number(key));
          fileTeamData.push({
            metaInfo: this.metaInfo, idisTeam: {
              idisTeamId: Number(key),
              idisTeamCommonEmailId: _email[0].idisTeamCommonEmailId
            }
          });
        }
      }
    }
    this.redirectFlag = false;
    this.pushRedirectFlag.emit(false);
    this.pageForm.unsubscribe();
    if (this.metaInfo.recordId === undefined) {
      this.createFileTemplate(data, form);
    }
    else {
      this.updateFileTemplateData(data);
    }
  }

  createFileTemplate(data, form) {
    this.fileSetupService.createFile(data).subscribe(res => {
      if (!res.error) {
        this.toastr.success("File configuration saved successfully.", "Success!");
        if (this.flowStatus === "save") {
          this.router.navigate(["/create", res.data.recordId, res.data.fileVersion, 0]);
        } else {
          this.router.navigate(["/create", res.data.recordId, res.data.fileVersion, 1]);
        }
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      let errorMsg = error.error.message;
      let duplicateNameErrorMsg = "DUPLICATE_FILE_TEMPLATE_NAME";
      let duplicateTransmissionName = "DUPLICATE_FILE_TRANSMISSION_NAME";
      if (errorMsg.indexOf(duplicateNameErrorMsg) !== -1) {
        this.toastr.error("File Template with the same file description already exists.", "Oops!", TOAST_SETTING);
      } else if (errorMsg.indexOf(duplicateTransmissionName) !== -1) {
        this.toastr.error("File Template with the same transmission name already exists.", "Oops!", TOAST_SETTING);
      } else {
        this.toastr.error("Server Error in creating File Template.", "Oops!", TOAST_SETTING);
      }
      this.tabLoader.emit(false);
      this.btnClicked = false;
    });

  }
  updateFileTemplateData(data) {
    data.recordId = this.metaInfo.recordId;
    this.fileSetupService.updateFiles(data, data.recordId).subscribe(res => {
      if (!res.error) {
        this.metaInfo.approvalStatus = res.data.approvalStatus;
        if (this.overwriteAnlst === true) {
          this.metaInfo.analystName = this.analystName;
          this.overwriteAnlst = false;
          this.ovrtAnlstName = "";
          this.analystName = "";
        };
        this.changeTradingPartnerPlatforms();
        this.saveCountinueBtn.emit(
          {
            action: this.flowStatus,
            metaInfo: res.data
          }
        );
        this.tabLoader.emit(false);
        this.btnClicked = false;
        this.toastr.success("File configuration saved successfully.", "Success!");
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      let errorMsg = error.error.message;
      let duplicateNameErrorMsg = "DUPLICATE_FILE_TEMPLATE_NAME";
      let duplicateTransmissionName = "DUPLICATE_FILE_TRANSMISSION_NAME";
      if (errorMsg.indexOf(duplicateNameErrorMsg) !== -1) {
        this.toastr.error("File Template with the same name already exists.", "Oops!", TOAST_SETTING);
      } else if (errorMsg.indexOf(duplicateTransmissionName) !== -1) {
        this.toastr.error("File Template with the same transmission name already exists.", "Oops!", TOAST_SETTING);
      } else {
        this.toastr.error("Server Error in updating File Template.", "Oops!", TOAST_SETTING);
      }
      this.tabLoader.emit(false);
      this.btnClicked = false;
    });
  }

  saveForm(status) {
    this.flowStatus = status;
    if (status === "save") {
      this.actionName = "Save";
    }
    else {
      this.actionName = "Save & Continue";
    }
  }

  validateNumber(event) {
    let key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
      return true;
    } else if (key < 48 || key > 57) {
      return false;
    } else {
      return true;
    }
  };

  routeToNewFile() {
    this.fileStatus = false;
    this.router.navigate(["/file-setup/create"]);
  }

  setAnlstValue() {
    if (this.overwriteAnlst === false) {
      this.ovrtAnlstName = "";
      this.analystName = "";
    }
  }

  btnCancel() {
    this.router.navigate(["/file-setup"]);
  }

  /* Basic Configuration Tab On Next Button Click */
  basicConfNextFn() {
    if (!this.metaInfo.isTemplate && this.checkIfEmployerIsUnassigned()) {
      return this.toastr.error("Please select a valid employer to continue file configuration.", "Oops!", TOAST_SETTING);
    }
    if (this.metaInfo.fileTypeMetaInfo.direction === "Outbound") {
      this.pageNavigation.emit("extParam");
    } else {
      this.pageNavigation.emit("lookupTable");
    }

  }

  getTradingPartnerPlatform(tradingPartnerId) {
    this.tradingPartnerPlatformList = [];
    this.fileSetupService.getTradingPartnerPlatformsByTPId(tradingPartnerId).subscribe(res => {
      this.tradingPartnerPlatformList = res.data;
      let _checkSelected = [];
      if (this.metaInfo.tradingPartnerPlatformInfo !== null) {
        _checkSelected = this.tradingPartnerPlatformList.filter((obj) => obj.tradingPartnerPlatformId === Number(this.metaInfo.tradingPartnerPlatformInfo.tradingPartnerPlatformId));
      }
      if (_checkSelected.length === 0) {
        this.metaInfo["tradingPartnerPlatformInfo"] = {
          tradingPartnerPlatformId: undefined
        };
      }

    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Trading Partner Platform", "Oops!", TOAST_SETTING);
    });
  }

  clientIds: any = [];
  /* istanbul ignore next */
  updateClientId(e) {
    this.clientIds = [];
    this.empClientIds = [];
    if (this.metaInfo.isMultiEmployer) {
      for (let ids of this.empName) {
        this.employerList.filter((obj) => {
          if (obj.employerId === ids) {
            this.clientIds.push(obj);
            this.empClientIds.push(obj.clientId);
          }
        });
      }
    }
    else {
      this.employerList.filter((obj) => {
        if (obj.employerId === this.empName) {
          this.clientIds.push(obj);
          this.empClientIds.push(obj.clientId);
        }
      });
    }
  }
  updateEmpList() {
    this.clientIds = [];
    this.empName = [];
    this.empClientIds = [];
  }


  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipFileBasic = res.data;
    });
  }
  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipFileBasic[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  /* istanbul ignore next */
  populateTPDropDown() {
    let _tpDropDownList = [];
    if (this.fileSetupTradingPartnerList.length !== 0) {
      for (let obj of this.fileSetupTradingPartnerList) {
        _tpDropDownList.push({
          "label": obj.tradingPartnerName,
          "value": obj.tradingPartnerId
        });
      }
      this.tradingPartnerDropDownList = _tpDropDownList;
      this.tradingPartnerDropDownList.unshift({ label: "Choose One", valule: null });
    }


  }


  changeTradingPartnerPlatforms() {
    if (this.tradingPartnerId) {
      this.getTradingPartnerPlatform(this.tradingPartnerId);
    } else {
      this.tradingPartnerPlatformList = [];
      this.metaInfo.tradingPartnerPlatformInfo.tradingPartnerPlatformId = undefined;

    }
  }

  /* istanbul ignore next */
  populateMasterFileDetails(data) {
    let selMasterTemplate = data.filter((obj) => obj.masterFileTemplateId === Number(this.masterFileId));
    this.metaInfo["masterFileTemplateRecordId"] = selMasterTemplate[0].masterFileTemplateRecordId;
    this.metaInfo["masterFileTemplateMetaInfo"] = {
      "masterFileTemplateId": selMasterTemplate[0].masterFileTemplateId,
      "masterFileTemplateVersion": selMasterTemplate[0].masterFileTemplateVersion,
      "masterFileTemplateName": selMasterTemplate[0].masterFileTemplateName,
      "masterFileTemplateRecordId": selMasterTemplate[0].masterFileTemplateRecordId
    };
    this.metaInfo["fileTypeMetaInfo"] = {
      "fileTypeName": selMasterTemplate[0].fileTypeMetaInfo.fileTypeName,
      "direction": selMasterTemplate[0].fileTypeMetaInfo.direction,
      "fileTypeId": selMasterTemplate[0].fileTypeMetaInfo.fileTypeId
    };
  }
  setFileLayoutValue() {
    this.metaInfo.fileFormatSupported.fileFormatFieldDelimiter = undefined;
  }




  blankMetaInfo() {
    this.metaInfo = {
      fileName: "",
      isTemplate: false,
      analystName: "",
      recordId: undefined,
      tradingPartnerPlatformInfo: {
        tradingPartnerPlatformId: undefined
      },
      fileTypeMetaInfo: {
        fileTypeName: "",
        direction: "",
        fileTypeId: undefined
      },
      fileIdGenerator: {
        fileId: undefined
      },
      fileMinRecordCountAllowed: undefined,
      fileMaxRecordCountAllowed: undefined,
      fileAssociatedWebsite: "",
      assignedTeam: [],
      oldFileId: undefined,
      isMultiEmployer: false,
      fileFormatSupported: {
        fileFormatName: undefined,
        fileFormatFieldDelimiter: "",
        fileFormatRowDelimiter: "",
        fileFormatSupportedId: undefined,
      },
      fileStatus: "",
      fileVersion: undefined,
      fileProcessingErrorThresholdFormat: undefined,
      fileProcessingErrorThresholdCount: undefined,
      slaMapped: false,
      createdBy: [],
      idisTeamFileAssociation: [],
      analystEmail: "",
      fileEmployerAssoc: [],
      fileTradingPartnerLobAssoc: [],
      tradingPartnerType: [],
      fileDataExtractionMode: false,
      appendFileRunDate: false,
      fileLayout: "",
      masterFileTemplateRecordId: undefined,
      currentApprovalStatus: undefined,
      masterFileTemplateMetaInfo: {
        masterFileTemplateId: undefined,
        masterFileTemplateVersion: undefined,
        masterFileTemplateRecordId: undefined,
        masterFileTemplateName: "",
      },
      approvalStatusComment: "",
      approvalStatusUpdatedBy: "",
      approvalStatusUpdatedDate: "",
      editedBy: "",
      editorComment: "",
      dataTargetTypeId: undefined,
      dataSourceTypeId: undefined,
      isActive: false,
      approvalStatus: undefined,
      fileTplApprovalStatus: undefined
    };
  }

  // ___End___

  // subscribe for user changes
  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @ViewChild("fileSetupForm") fileSetupForm: NgForm;
  pageForm: any;
  @Output() pushRedirectFlag = new EventEmitter();
  subscribeFormChanges() {
    this.pageForm = this.fileSetupForm.valueChanges.subscribe(
      result => {
        if (this.fileSetupForm.form.dirty) {
          this.redirectFlag = true;
          this.pushRedirectFlag.emit(true);
          this.pageForm.unsubscribe();
        }
      }
    );
  }

  // checks if employer set Unassigned won't allow to do Save,Next,Save&Continue file
   checkIfEmployerIsUnassigned() {
    if (this.clientIds) {
        for (let fileEmployer of this.clientIds) {
          if (fileEmployer.clientEmployerAssocId === this.unassingedEmployerId) {
            return true;
          } else {
            return false;
          }
        }
      }
  }
}