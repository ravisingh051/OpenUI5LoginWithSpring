import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { MenuItem } from "primeng/components/common/api";
import { TreeTableModule } from "../../al-treetable/treetable";
import { TreeNode } from "primeng/primeng";
import { ConfirmationService } from "primeng/components/common/api";
import { AlRuleEditorComponent } from "../../al-rule-editor/al-rule-editor.component";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING, confAcceptLabel, confRejectLabel, confMessage } from "../../../../global";


@Component({
  selector: "al-dynamic-schema-generation-file",
  templateUrl: "./al-dynamic-schema-generation-file.component.html",
  styleUrls: ["./al-dynamic-schema-generation-file.component.scss"],
  providers: [AlRuleEditorService, ConfirmationService]
})
export class AlDynamicSchemaGenerationFileComponent implements OnInit {

  constructor(
    private toastr: ToastsManager,
    private fileService: FileSetupService,
    private _ruleEditorService: AlRuleEditorService,
    private confirmationService: ConfirmationService,
    private toolTipUtils: ToolTipUtilService
  ) { }

  @Input() viewOnly;
  @Input() metaInfo: any;
  @Output("tabLoader") tabLoader = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();
  fileIdentifier: number = 0;
  activeIndex: number = 0;
  items: MenuItem[];
  treeTableData: any = {};
  filesCol: any[];
  selSection: string = "H";
  btnClicked: boolean;
  @Output() updateDateAndUpdateBy = new EventEmitter;
  getRuleHistoryDataAttributeList: any = [];

  /* ToolTip display OnMouse Over */
  dynamicGenerationToolTip: any = [];
  tooltipResult: any;
  pageID: number = 29;

  ngOnInit() {
    this.items = [{
      label: "Header",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: "Detail Row",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: "Trailer",
      command: /* istanbul ignore next */ (event: any) => {
        this.activeIndex = 2;
      }
    }];

    this.fileIdentifier = this.metaInfo.recordId;
    this.getFileAttributeList();
    this.getAttributeList();
    this.getDataTypes();
    this.getToolTipTextDetails();
    this.getHistoryDataAtrributes();
  }

  getDynamicSchemaGeneration() {
    this.tabLoader.emit(true);
    this.fileService.getSectionwiseDynamicSchema(this.metaInfo.recordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        if (res.data !== null) {
          this.treeTableData = res.data;
          for (let _node of this.treeTableData) {
            _node.data["oldData"] = JSON.stringify(_node.data);
          }
        } /* istanbul ignore next */ else {
          if (!this.viewOnly) {
            this.treeTableData = this.blankNodeRow();
            this.rowEditFlag = true;
          } else {
            this.treeTableData = [];
          }
        }
        this.btnClicked = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  nextStep() {
    if (this.redirectFlag) {
      this.confirmationService.confirm({
        message: confMessage,
        accept: () => {
          this.nextStepS();
        }
      });
    } else {
      this.nextStepS();
    }
  }

  nextStepS() {
    this.btnClicked = true;
    this.activeIndex++;
    this.rowEditFlag = false;
    this.updateRedirectFlag(false);
    if (this.activeIndex === 1) {
      this.selSection = "D";
    } else if (this.activeIndex === 2) {
      this.selSection = "T";
    }
    if (this.activeIndex <= 2) {
      this.getDynamicSchemaGeneration();
    } /* istanbul ignore next */ else {
      this.pageNavigation.emit();
    }
  }

  // _____Specify Delimiters | START___________
  specDelDialog: boolean = false;
  showSpecDel() {
    this.btnClicked = true;
    this.specDelDialog = true;
  }
  onSpecDelClose() {
    this.btnClicked = false;
    this.specDelDialog = false;
  }
  // _____Specify Delimiters | END___________



  // _____DataSet Writing Rule | START___________
  @ViewChild(AlRuleEditorComponent) ruleEditorComp;
  selRowData: any = {};
  rowIndex: number;
  actionItems: OverlayPanel;
  acceptLabel: string = "Yes";
  rejectLabel: string = "No";
  priDisNmFlag: boolean = false;
  selRowIndex: number;
  action(e, rowNode, rowIndex, actionItems) {
    this.priDisNmFlag = false;
    this.selRowIndex = rowIndex;
    this.actionItems = actionItems;
    this.actionItems.toggle(e);
    this.selRowData = rowNode;
    if (this.selRowData.node.data.lstFlsNodeBrAssoc !== undefined && this.selRowData.node.data.lstFlsNodeBrAssoc !== null) {
      let _checkData = this.selRowData.node.data.lstFlsNodeBrAssoc.filter(obj => obj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "PrintDisplayName");
      if (_checkData.length > 0) {
        this.priDisNmFlag = true;
      }
    }
    e.stopPropagation();
  }

  printDisplayName() {
    if (this.selRowData.node.data.spMpingRslt["printDisplayName"]) {
      this.confirmationService.confirm({
        message: "Are you sure you want to remove the Print Display Name?",
        accept: () => {
          this.selRowData.node.data.spMpingRslt["printDisplayName"] = false;
        }
      });
    } /* istanbul ignore next */ else {
      this.selRowData.node.data.spMpingRslt["printDisplayName"] = true;
    }
    this.actionItems.hide();
  }

  getRuleAttributeList: Array<any>;

  getFileAttributeList() {
    this.fileService.getOutboundFileAttributes(this.metaInfo.recordId).subscribe(res => {
      if (res.data.length !== 0) {
        this.getRuleAttributeList = [];
        this.getRuleAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          if (element.label !== "TransactionDataset") {
          this.getRuleAttributeList.push({
            label: element.label,
            items: element.items,
          });
        }
      }
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in fetching attribute list.", "Oops!", TOAST_SETTING);
    });
  }

  // Rule Editor Section
  DWRDialog: boolean = false;
  ruleSource = "fileOutboundDynamicSchema";
  selRuleType: string = "";

  /* removePDN() {
    this.actionItems.hide();
    this.confirmationService.confirm({
      message: "Are you sure you want to remove the Print Display Name?",
      accept: () => {
        let _checkData = this.selRowData.node.data.lstFlsNodeBrAssoc.filter(obj => obj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName !== "PrintDisplayName");
        this.selRowData.node.data.lstFlsNodeBrAssoc = [..._checkData];
      }
    });
  } */

  attrDrlRelativeNaming: any = {};
  packageByFileType: any;

  attributeMapping: any = {};
  getAttributeList() {
    this.fileService.getAttributeStandarizedNameListByFileTypeId(this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
      if (!res.error) {
        this.attrDrlRelativeNaming = res.data;
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in fetching attribute Standardized Name list.", "Oops!", TOAST_SETTING);
    });

    // this.fileService.getPackageInfoByFileTypeId(this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
    //   if (!res.error) {
    //     this.packageByFileType = res.data;

    //   } /* istanbul ignore next */ else {
    //     this.toastr.error("Server Error in fetching FileType Pojo Package details.", "Oops!", TOAST_SETTING);
    //   }
    // }, /* istanbul ignore next */ error => {
    //   this.toastr.error("Server Error in fetching  FileType Pojo Package details.", "Oops!", TOAST_SETTING);
    // });

    this.fileService.getDSGPackageInfo().subscribe(res => {
      if (!res.error) {
        this.packageByFileType = res.data;

      } /* istanbul ignore next */ else {
        this.toastr.error("Server Error in fetching FileType Pojo Package details.", "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in fetching  FileType Pojo Package details.", "Oops!", TOAST_SETTING);
    });
  }

  pushRuleToAttribute(resultMap) {
    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    let ruleObj = resultMap.get("rule");

    if (ruleObj !== null) {
      if (this.selRowData.node.data.lstFlsNodeBrAssoc !== null && this.selRowData.node.data.lstFlsNodeBrAssoc !== undefined) {
        if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "DataSetWritingRule") {
          this.selRowData.node.data.lstFlsNodeBrAssoc = this.selRowData.node.data.lstFlsNodeBrAssoc.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName !== "DataSetWritingRule");
        } else {
          this.selRowData.node.data.lstFlsNodeBrAssoc = this.selRowData.node.data.lstFlsNodeBrAssoc.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "DataSetWritingRule");
        }
        this.selRowData.node.data.lstFlsNodeBrAssoc.push(ruleObj);
      } else {
        this.selRowData.node.data.lstFlsNodeBrAssoc = [ruleObj];
      }
    }
    this.DWRDialog = false;
    this.selRowData.node.data["PDNLoder"] = false;
  }

  onNodeExpand(event) {
    let _nodeData = event.node;
    if (_nodeData.children !== undefined) {
      return false;
    }
    _nodeData["children"] = [];
    _nodeData["togglerLoader"] = true;
    this.fileService.getDynamicSchemaByParentId(this.metaInfo.recordId, this.selSection, _nodeData.data.id).subscribe(res => {
      if (!res.error) {
        for (let _node of res.data) {
          _node.data["oldData"] = JSON.stringify(_node.data);
        }
        _nodeData["children"] = res.data;
        this.treeTableData = [...this.treeTableData];
        _nodeData["togglerLoader"] = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  loadNodes(event) {
    this.btnClicked = true;
    this.tabLoader.emit(true);
    this.fileService.getSectionwiseDynamicSchema(this.metaInfo.recordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        if (res.data !== null) {
          this.treeTableData = res.data;
          for (let _node of this.treeTableData) {
            _node.data["oldData"] = JSON.stringify(_node.data);
          }
        } else {
          if (!this.viewOnly) {
            this.treeTableData = this.blankNodeRow();
            this.rowEditFlag = true;
          }
        }
        this.btnClicked = false;
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  regex = new RegExp("^[0-9]*$");
  saveDSGRow(rowNode, rowIndex, actionItems) {
    this.selRowIndex = rowIndex;
    this.selRowData = rowNode;
    this.actionItems = actionItems;
    this.actionItems.hide();
    this.btnClicked = true;
    this.selRowData.node["oldData"] = [];
    let _data = this.selRowData.node.data;
    _data["validCT"] = _data.category === "" ? true : false;
    _data["validDT"] = _data.dataType === null ? true : false;
    _data["validDN"] = _data.displayName === "" ? true : false;
    _data["validMO"] = this.regex.test(_data.minOccurance) === false ? true : false;
    _data["validMX"] = this.regex.test(_data.maxOccurance) === false ? true : false;

    if (_data["validDT"] === false) {
      if (_data.dataType === "NODE" && _data.maxOccurance === ">1") {
        _data["validMX"] = false;
      } /* istanbul ignore next */ else if (_data.dataType !== "NODE") {
        if (_data.minOccurance > 1) {
          _data["validMO"] = true;
          this.toastr.error("Min Occurrence should not be greater than 1", "Oops!", TOAST_SETTING);
          this.btnClicked = false;
          return false;
        }
        if (_data.maxOccurance > 1) {
          _data["validMX"] = true;
          this.toastr.error("Max Occurrence should not be greater than 1", "Oops!", TOAST_SETTING);
          this.btnClicked = false;
          return false;
        }
      }
    }

    /* istanbul ignore next */
    if (Number(_data.minOccurance) > Number(_data.maxOccurance)) {
      _data["validMO"] = true;
      _data["validMX"] = true;
      this.toastr.error("Min Occurrence number can not greater than Max. Occurrence", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
      return false;
    }

    if (_data.validCT || _data.validDT || _data.validDN || _data.validMO || _data.validMX) {
      this.toastr.error("Please enter valid value !", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
      return false;
    }
    let _getDtype = this.dataTypes.filter((obj) => obj.attributeDataTypeName === _data.dataType);
    let _dataTypeId = _getDtype[0].attributeDataTypeId;

    let nodeIsMandatory = this.selRowData.node.data.minOccurance > 0 ? true : false;
    let data = {
      "id": this.selRowData.node.data.id,
      // "nodeRefNum": this.selRowIndex + 1,
      "nodeRefNum": this.selRowData.node.data.referenceId,
      "displayName": this.selRowData.node.data.displayName,
      "category": this.selRowData.node.data.category,
      "isActive": true,
      "dataType": this.selRowData.node.data.dataType,
      "nodeRowPosition": this.selRowIndex + 1,
      "minOccurance": this.selRowData.node.data.minOccurance,
      "maxOccurance": this.selRowData.node.data.maxOccurance === ">1" ? null : this.selRowData.node.data.maxOccurance,
      "recordId": this.metaInfo.recordId,
      //  "mappedColumnType": null,
      // "nodeCondDescription": null,
      "nodeIsMandatory": nodeIsMandatory,
      "sectionShortName": this.selSection,
      "lstCtlsNodeBrAssoc": null,
      "lstFlsNodeBrAssoc": this.selRowData.node.data.lstFlsNodeBrAssoc,
      "siblingId": this.selSiblingId,
      "parentId": this.selRowData.parent === null ? null : this.selRowData.parent.data.id,
      "parentNodeRefNum": this.selRowData.parent === null ? null : this.selRowData.parent.data.referenceId,
    };


    if (this.selRowData.node.data.id === null) {
      data["masterTemplateLayoutSchemaNodeAssoc"] = {
        "parentMtlsniId": this.selRowData.parent !== null ? this.selRowData.parent.data.id : null,
      };
      this.saveRowData(data);
    } else {
      this.updateRowData(data);
    }
  }

  /* While Saving new row */
  saveRowData(data) {
    this.fileService.saveMappedDynamicSchemaColumns(data).subscribe(res => {
      if (!res.error) {
        this.btnClicked = false;
        this.selRowData.node.data.id = res.data.id;
        this.selRowData.node.data.referenceId = res.data.referenceId;
        this.selRowData.node.data.nodeRefNum = res.data.nodeRefNum;
        this.selRowData.node.editMode = false;
        this.rowEditFlag = false;
        this.selRowData.node["oldData"] = JSON.stringify(data);
        this.tabLoader.emit(false);
        this.toastr.success(this.selRowData.node.data.category + " - " + this.selRowData.node.data.displayName + " data saved successfully", "Success");
        this.updateRedirectFlag(false);
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in saving Dynamic Shema Row.", "Oops!", TOAST_SETTING);
    });
  }

  /* While updating new row */
  updateRowData(data) {
    this.fileService.updateMappedDynamicSchemaColumns(data).subscribe(res => {
      if (!res.error) {
        this.btnClicked = false;
        this.selRowData.node.data.id = res.data.dynamicSchemaMappingRow.id;
        this.selRowData.node.data.referenceId = res.data.dynamicSchemaMappingRow.nodeRefNum;
        this.selRowData.node.data.nodeRefNum = res.data.dynamicSchemaMappingRow.nodeRefNum;
        this.selRowData.node.editMode = false;
        this.rowEditFlag = false;
        this.selRowData.node["oldData"] = JSON.stringify(data);
        this.tabLoader.emit(false);
        this.toastr.success(this.selRowData.node.data.category + " - " + this.selRowData.node.data.displayName + " data updated successfully", "Success");
        this.updateRedirectFlag(false);
      } /* istanbul ignore next */ else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in updating Dynamic Shema Row.", "Oops!", TOAST_SETTING);
    });
  }

  ruleIndex: number = -1;
  isFormatAvail: boolean = true;
  identifyRowAndopenRuleEditor(row, index, linkIndex, overlaypanel: OverlayPanel, RuleGroupName, RuleGroupId, viewOnly) {
    this.ruleIndex = linkIndex;
    if (row.dataType !== null && row.dataType !== undefined && row.dataType.toUpperCase() === "BIT") {
      this.isFormatAvail = false;
    } else {
      this.isFormatAvail = true;
    }

    this.selRowData = row;
    this.attributeMapping.selected = [];
    this.attributeMapping.selected.push(row);
    this.attributeMapping.selectedIndex = index;
    this.openRuleEditor(overlaypanel, RuleGroupName, viewOnly);
  }


  selectedAttributeForRule: any = "";
  selAttrDataType: any = "";
  openRuleEditor(overlaypanel: OverlayPanel, ruleType, viewOnly) {
    this.selRuleType = ruleType;
    if (ruleType === "PrintDisplayName") {
      return false;
    }
    if (overlaypanel !== null) {
      overlaypanel.hide();
    }
    let selRuleBrAssc = [];
    let isGroupDropDownReq = true;
    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    this.selectedAttributeForRule = null;
    this.selAttrDataType = this.selRowData.node.data.dataType;
    let savedRules = this.selRowData.node.data.lstFlsNodeBrAssoc !== null ? this.selRowData.node.data.lstFlsNodeBrAssoc : [];
    if (savedRules !== null || savedRules !== undefined || savedRules !== "") {
      if (ruleType === "DataSetWritingRule") {
        let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "DataSetWritingRule");
        let selBrAssc = selRuleBrAssc;
        if (filteredArr.length > 0) {
          selBrAssc = filteredArr[0];
        }
        this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selAttrDataType, this.selectedAttributeForRule, this.selRowData.node.data, viewOnly, this.selAttrDataType, selBrAssc, this.ruleSource, isGroupDropDownReq, this.selSection);
        this.DWRDialog = true;
        return;
      }
      else {
        let filteredArr = savedRules.filter(el => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName !== "DataSetWritingRule");
        if (filteredArr.length > 0) {
          this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selAttrDataType, this.selectedAttributeForRule, this.selRowData.node.data, viewOnly, this.selAttrDataType, filteredArr[0], this.ruleSource, isGroupDropDownReq, this.selSection);
          this.DWRDialog = true;
        }
        else {
          this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selAttrDataType, this.selectedAttributeForRule, this.selRowData.node.data, viewOnly, this.selAttrDataType, selRuleBrAssc, this.ruleSource, isGroupDropDownReq, this.selSection);
          this.DWRDialog = true;
        }
      }
    }
  }

  resetRowData(rowNode, rowIndex) {
    this.selRowIndex = rowIndex;
    this.selRowData = rowNode;
    this.actionItems.hide();
    this.selRowData.node.editMode = false;
    this.selRowData.node.data = JSON.parse(this.selRowData.node["oldData"]);
    this.selRowData.node["oldData"] = null;
    this.rowEditFlag = false;
    this.updateRedirectFlag(false);
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.dynamicGenerationToolTip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.dynamicGenerationToolTip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }


  // _____DataSet Writing Rule | END___________

  /* Get DataType List */
  dataTypeList: any = [{ "label": "Please Select", "value": null }];
  dataTypes: any;
  getDataTypes() {
    this.fileService.getDataTypes().subscribe(res => {
      if (!res.error) {
        this.dataTypes = [...res.data];
        for (let _list of res.data) {
          this.dataTypeList.push({
            "label": _list.attributeDataTypeName,
            "value": _list.attributeDataTypeName
          });
        }
      } /* istanbul ignore next */  else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, /* istanbul ignore next */ error => {
      this.toastr.error("Server Error in getting Data Types.", "Oops!", TOAST_SETTING);
    });
  }

  /* ON/OFF Inline Row Edit */
  rowEditFlag: boolean = false;
  enableEditMode(rowNode, rowIndex, actionItems) {
    if (this.rowEditFlag || this.viewOnly) {
      return false;
    }
    this.selRowIndex = rowIndex;
    this.selRowData = rowNode;
    this.actionItems = actionItems;
    this.actionItems.hide();
    if (rowNode.node.editMode === undefined || rowNode.node.editMode === false) {
      if (rowNode.node.data.maxOccurance === null) {
        rowNode.node.data.maxOccurance = ">1";
      }
      rowNode.node["editMode"] = true;
      rowNode.node.data["validMO"] = false;
      rowNode.node.data["validMX"] = false;
      rowNode.node["oldData"] = JSON.stringify(rowNode.node.data);
      this.rowEditFlag = true;
      this.updateRedirectFlag(true);
    }
    return false;
  }
  checkValue(e, rowData, name) {
    if (name === "min") {
      if (e.currentTarget.value === "") {
        rowData.minOccurance = 0;
      }
    } else if (name === "max") {
      if (e.currentTarget.value === "" || e.currentTarget.value === 0) {
        rowData.maxOccurance = 1;
      }
    }
  }

  /* Adding sibling to treenode*/
  selSiblingId: number = null;
  selParentId: number = null;
  addSibling() {
    this.selSiblingId = this.selRowData.node.data.id;
    this.selParentId = this.selRowData.parent === null ? null : this.selRowData.parent.data.id;
    this.actionItems.hide();
    this.findParent();
    this.updateRedirectFlag(true);
  }

  /* Adding Children to treenode */
  addChild() {
    this.selSiblingId = null;
    this.selParentId = this.selRowData.node.data.id;
    this.actionItems.hide();
    if (this.selRowData.node.leaf && this.selRowData.node.children === undefined) {
      this.onNodeExpand(this.selRowData);
    } else {
      this.pushNewRow("c");
    }
    this.selRowData.node["expanded"] = true;
    this.updateRedirectFlag(true);
  }

  /* Confirmation for removing row */
  removeRow(rowNode, rowIndex, actionItems, flag) {
    if (flag) {
      this.selRowIndex = rowIndex;
      this.selRowData = rowNode;
      this.actionItems = actionItems;
    }
    this.actionItems.hide();
    if (this.selRowData.node.data.id === null) {
      this.deleteAttrRow(false);
      this.updateRedirectFlag(false);
    } else {
      this.confirmationService.confirm({
        message: " You are about to remove schema definition which may be a parent row or it may have associated  attribute / rules on attribute mapping screen. This removal of row will remove all the children rows and attributes/rules from attribute mapping as well. Do you wish to continue with removal? Click yes to remove, click No to cancel action",
        accept: () => {
          this.deleteAttrRow(true);
          this.updateRedirectFlag(false);
        }
      });
    }
  }

  /* Get row which is going to be deleted */
  deleteAttrRow(flag) {
    this.btnClicked = true;
    if (flag) {
      this.fileService.deleteAttrRow(this.selRowData.node.data.id, this.metaInfo.recordId, this.selSection).subscribe((res) => {
        if (!res.error) {
          this.removeNodeFromTree();
        }
      }, /* istanbul ignore next */ error => {
        this.toastr.error("Server error in removing attribute row.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.removeNodeFromTree();
    }
  }

  /* Delete Row from TreeTable */
  removeNodeFromTree() {
    let _delIndex;
    if (this.selRowData.level === 0) {
      this.treeTableData.filter((_del, index) => {
        if (_del.data.id === this.selRowData.node.data.id) {
          _delIndex = index;
        }
      });
      this.treeTableData.splice(_delIndex, 1);
    } else {
      this.selRowData.parent.children.filter((_del, index) => {
        if (_del.data.id === this.selRowData.node.data.id) {
          _delIndex = index;
        }
      });
      this.selRowData.parent.children.splice(_delIndex, 1);
    }
    this.treeTableData = [...this.treeTableData];
    this.rowEditFlag = false;
    this.toastr.success("Successfully Deleted the row " + this.selRowData.node.data.displayName + "!", "Success!");
    if (this.treeTableData.length === 0) {
      this.pushNewRow(null);
    }
    this.btnClicked = false;
  }
  /* Recursive function to fetch child elements */
  findParent() {
    let pId = this.selRowData.parent === null ? null : this.selRowData.parent.data.id;
    if (pId === null) {
      this.selChildData = this.treeTableData;
      this.pushNewRow("s");
    } else {
      this.findChildData(this.treeTableData, pId);
    }
  }

  /* Get child element nodes based on selected row */
  selChildData: any = [];
  findChildData(mydata, pId) {
    if (mydata !== null && mydata !== undefined) {
      for (let i = 0; i < mydata.length; i++) {
        if (mydata[i].data.id !== pId) {
          this.findChildData(mydata[i].children, pId);
        } else {
          this.selChildData = mydata[i].children;
          this.pushNewRow("s");
          return;
        }
      }
    }
  }

  /* Add new Row on Sibling or Child Level */
  pushNewRow(level) {
    this.rowEditFlag = true;
    let _newRow = [];
    if (level === null) {
      this.treeTableData = [..._newRow, this.newRowObj()];
    }
    else if (level === "s") {
      let _selIndex: number;
      let _childIndex = this.selChildData.filter((_child, index) => {
        if (_child.data.id === this.selRowData.node.data.id) {
          _selIndex = index + 1;
        }
      });
      this.selChildData.splice(_selIndex, 0, this.newRowObj());

    }
    else if (level === "c") {
      let _child = this.selRowData.node["children"];
      if (_child === null || _child === undefined) {
        this.selRowData.node["children"] = [this.newRowObj()];
      }
      else {
        this.selRowData.node.children.push(this.newRowObj());
      }
    }
    this.treeTableData = [...this.treeTableData];
  }
  /* Blank row new Object */
  newRowObj() {
    return {
      "data": {
        "id": null,
        "referenceId": null,
        "category": "",
        "dataType": null,
        "displayName": "",
        "parentId": null,
        "minOccurance": 0,
        "maxOccurance": 1,
        "lstCtlsNodeBrAssoc": null,
        "lstFlsNodeBrAssoc": null
      },
      "editMode": true
    };
  }

  blankNodeRow() {
    return [
      {
        "data": {
          "id": null,
          "category": "",
          "dataType": null,
          "displayName": "",
          "parentId": null,
          "minOccurance": 0,
          "maxOccurance": 1,
          "description": null,
          "mandatory": null,
          "hasChildren": false,
          "rowPosition": 1,
          "lstCtlsNodeBrAssoc": null,
          "lstFlsNodeBrAssoc": null
        },
        "leaf": false,
        "editMode": true
      }
    ];
  }

  // subscribe for user changes
  redirectFlag: boolean = false;
  @Output() pushRedirectFlag = new EventEmitter();
  updateRedirectFlag(flag) {
    this.redirectFlag = flag;
    this.pushRedirectFlag.emit(flag);
  };
  // subscribe for user changes

  getHistoryDataAtrributes() {
    this._ruleEditorService.getHistoryDataAtrributes(this.metaInfo.recordId).subscribe(res => {
      if (!res.error) {
        this.getRuleHistoryDataAttributeList = [];
        this.getRuleHistoryDataAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          this.getRuleHistoryDataAttributeList.push({
            label: element.label,
            items: element.items,
          });
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting History Data Attribute.", "Oops!", TOAST_SETTING);
    });
  }

}
