// al-dynamic-schema-generation-file.component.spec.ts

import { async, ComponentFixture, TestBed } from "@angular/core/testing";


// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService, OverlayPanel } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";


// COMPONENT
// =========================
import { AlDynamicSchemaGenerationFileComponent } from "./al-dynamic-schema-generation-file.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";


// SERVICE
// =========================
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { HttpClientTestingModule } from "@angular/common/http/testing";

// Mock data
// =========================
let metaInfo;
const routes: Routes = [];
let selRowData = {
    "node": {
        "data": {
            "id": 291829,
            "referenceId": 1,
            "category": "Section",
            "dataType": "NODE",
            "displayName": "Header",
            "parentId": null,
            "minOccurance": 1,
            "maxOccurance": 1,
            "description": "Section",
            "mandatory": true,
            "hasChildren": true,
            "rowPosition": null,
            "spMpingRslt": {
                "printDisplayName": true
            },
            "dynamicSchemaMappingRow": {
                id: 123
            },
            "lstCtlsNodeBrAssoc": null,
            "lstFlsNodeBrAssoc": [
                {
                    "ruleExecutionSequence": 1,
                    "isActive": true,
                    "ruleExecutionComment": "",
                    "droolsBusinessRulesDecisionTable": {
                        "droolsBusinessRuleId": null,
                        "isCurrent": true,
                        "droolsBusinessRuleVersion": 1,
                        "droolsBusinessRuleName": "Mix_Template",
                        "droolsBusinessRuleDrlFileContent": "package com.alight.idis;\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\n\n\nrule \" PrintDisplayName 705243218336486 0\" salience 0\nwhen\n\t$transactionDatasetView : TransactionDatasetView()\n\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\n\n\tif(705243218336486l > 0 ) break [GOTO_THEN_1]\nthen\n\t /** NOTHING TO DO -- DEFAULT CASE */ \nthen [GOTO_THEN_1] \n\t$outBoundDataSetWritingRule.setHardCodeValue(\"Section-Header-291829\",\"Header\");\nend\n\n",
                        "droolsBusinessRuleUiJsonText": "[{\"dataIndex\":\"dataIndex_0\",\"droolsBusinessRuleTemplateId\":20,\"droolsBusinessRuleTemplateName\":\"PrintDisplayName\",\"droolsBusinessRuleTemplateGroup\":{\"createdBy\":\"Divya Jain\",\"createdDateTime\":\"30/12/2018 06:00:00.000 GMT\",\"updatedBy\":null,\"updatedDateTime\":null,\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\",\"parentGroupId\":null,\"droolsBusinessRuleGroupPriority\":1},\"droolsBusinessRuleTemplateVersion\":1,\"droolsBusinessRuleTemplateContent\":\"template header\\r\\n\\r\\nobjName1\\r\\n\\r\\npackage com.alight.idis;\\r\\n\\r\\n/*\\r\\n{\\r\\n\\t\\\"ruleType\\\": \\\"PrintDisplayName\\\",\\r\\n\\t\\\"ruleConditionValue\\\": [{\\r\\n\\t\\t\\\"attributeName\\\": \\\"attrname1\\\",\\r\\n\\t\\t\\\"conditions\\\": [{\\r\\n\\t\\t\\t\\\"id\\\": \\\"1\\\",\\r\\n\\t\\t\\t\\\"label\\\": \\\"Set PrintDisplayName Static Display Value\\\",\\r\\n\\t\\t\\t\\\"helpText\\\": \\\"Text box for setting fixed value\\\",\\r\\n\\t\\t\\t\\\"type\\\": \\\"textarea\\\",\\r\\n\\t\\t\\t\\\"userInput\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"endpoint\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"columns\\\":\\\"12\\\"\\r\\n\\t\\t}]\\r\\n\\t}\\r\\n\\t]\\r\\n}\\r\\n*/\\r\\n\\r\\n\\r\\ntemplate \\\"PrintDisplayName\\\"\\r\\n\\r\\n\\r\\nend template\",\"isActive\":1,\"approvalStatusId\":1,\"approvalStatusUpdatedBy\":\"Divya Jain\",\"approvalStatusUpdatedDate\":1546236000000,\"approvalStatusComment\":\"approved\",\"createdBy\":\"Divya Jain\",\"createdDateTime\":1546236000000,\"uiElements\":[{\"id\":\"1\",\"label\":\"Set PrintDisplayName Static Display Value\",\"helpText\":\"Text box for setting fixed value\",\"type\":\"textarea\",\"userInput\":null,\"endpoint\":\"\",\"separator\":null,\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":12,\"options\":[]}],\"label\":\"PrintDisplayName\",\"value\":12,\"ruleOrder\":1}]",
                        "droolsBusinessRulePreDrlText": "Print Display Name",
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupId": 10,
                            "droolsBusinessRuleGroupName": "PrintDisplayName"
                        },
                        "standardizedAttrLst": null
                    },
                    "flsbaId": null,
                    "fileLayoutSchemaNodeInfo": {
                        "flsniId": 291829
                    }
                },
                {
                    "ruleExecutionSequence": 1,
                    "isActive": true,
                    "ruleExecutionComment": "",
                    "droolsBusinessRulesDecisionTable": {
                        "droolsBusinessRuleId": null,
                        "isCurrent": true,
                        "droolsBusinessRuleVersion": 1,
                        "droolsBusinessRuleName": "Mix_Template",
                        "droolsBusinessRuleDrlFileContent": "package com.alight.idis;\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\n\n\nrule \" Dataset Writing Rule 705279002937519 0\" salience 0\nwhen\n\t$transactionDatasetView : TransactionDatasetView()\n\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\n\n\tif(705279002937519l > 0 && ( $transactionDatasetView.getEmployee().getAdjustedSalary() != null  ) ) break [GOTO_THEN_1]\nthen\n\t /** NOTHING TO DO -- DEFAULT CASE */ \nthen [GOTO_THEN_1] \n\t$outBoundDataSetWritingRule.excludeNode(\"Section\",\"Header\",291829);\nend\n\n",
                        "droolsBusinessRuleUiJsonText": "[{\"dataIndex\":\"dataIndex_0\",\"droolsBusinessRuleTemplateId\":19,\"droolsBusinessRuleTemplateName\":\"Dataset Writing Rule\",\"droolsBusinessRuleTemplateGroup\":{\"createdBy\":\"Divya Jain\",\"createdDateTime\":\"30/12/2018 06:00:00.000 GMT\",\"updatedBy\":null,\"updatedDateTime\":null,\"droolsBusinessRuleGroupId\":9,\"droolsBusinessRuleGroupName\":\"DataSetWritingRule\",\"parentGroupId\":null,\"droolsBusinessRuleGroupPriority\":1},\"droolsBusinessRuleTemplateVersion\":1,\"droolsBusinessRuleTemplateContent\":\"template header objName1\\r\\n\\r\\npackage com.alight.idis;\\r\\n\\r\\n/*\\r\\n{\\r\\n \\\"ruleType\\\": \\\"DataSetWritingRule\\\",\\r\\n \\\"ruleConditionValue\\\": [\\r\\n   {\\r\\n     \\\"attributeName\\\": \\\"attrname1\\\",\\r\\n     \\\"conditions\\\": [\\r\\n       {\\r\\n         \\\"id\\\": \\\"1\\\",\\r\\n         \\\"label\\\": \\\"Conditional Statements\\\",\\r\\n         \\\"helpText\\\": \\\"Text area for creating rules\\\",\\r\\n         \\\"type\\\": \\\"textarea\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"6\\\",\\r\\n         \\\"separator\\\": \\\"false\\\"\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"2\\\",\\r\\n         \\\"label\\\": \\\"Action Statements\\\",\\r\\n         \\\"helpText\\\": \\\"Text area for creating Action Statements\\\",\\r\\n         \\\"type\\\": \\\"textarea\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"6\\\",\\r\\n         \\\"separator\\\": \\\"true\\\"\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"3\\\",\\r\\n         \\\"label\\\": \\\"Attributes\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"4\\\",\\r\\n         \\\"label\\\": \\\"Operators\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/operators\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"5\\\",\\r\\n         \\\"label\\\": \\\"Functions\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/functions/outbound/all\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"6\\\",\\r\\n         \\\"label\\\": \\\"Select Function\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/functions/conditional/action/outbound/all\\\",\\r\\n         \\\"columns\\\": \\\"3\\\",\\r\\n         \\\"separator\\\": \\\"true\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       }\\r\\n     ]\\r\\n   }\\r\\n ]\\r\\n}\\r\\n*/\\r\\n\\r\\n\\r\\ntemplate \\\"DataSetWritingRule\\\"\\r\\n\\r\\n\\r\\nend template\",\"isActive\":1,\"approvalStatusId\":1,\"approvalStatusUpdatedBy\":\"Divya Jain\",\"approvalStatusUpdatedDate\":1546236000000,\"approvalStatusComment\":\"approved\",\"createdBy\":\"Divya Jain\",\"createdDateTime\":1546236000000,\"uiElements\":[{\"id\":\"1\",\"label\":\"Conditional Statements\",\"helpText\":\"Text area for creating rules\",\"type\":\"textarea\",\"userInput\":\"EXCLUDE()\",\"endpoint\":\"\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":6,\"options\":[]},{\"id\":\"2\",\"label\":\"Action Statements\",\"helpText\":\"Text area for creating Action Statements\",\"type\":\"textarea\",\"userInput\":\"EXCLUDE()\",\"endpoint\":\"\",\"separator\":\"true\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":6,\"options\":[]},{\"id\":\"3\",\"label\":\"Attributes\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[],\"selectedValue\":\"@TransactionDatasetView::[Employee].[Adjusted Salary]\"},{\"id\":\"4\",\"label\":\"Operators\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/operators\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[],\"selectedValue\":\"!= null\"},{\"id\":\"5\",\"label\":\"Functions\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/functions/outbound/all\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[]},{\"id\":\"6\",\"label\":\"Select Function\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/functions/conditional/action/outbound/all\",\"separator\":\"true\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":3,\"options\":[],\"selectedValue\":\"EXCLUDE()\",\"drlText\":\"()\"}],\"label\":\"Dataset Writing Rule\",\"value\":11,\"ruleOrder\":1,\"selectionStartC\":\"\",\"functionOutputC\":\"\\\"@TransactionDatasetView::[Employee].[Adjusted Salary]\\\"!= null\",\"DWRAttr\":\"@TransactionDatasetView::[Employee].[Adjusted Salary]\",\"DWROper\":\"!= null\",\"DWRFuncB\":\"EXCLUDE()\",\"helpTextDropDown\":\"This function will not print the data. EXCLUDE() is applied on Node/Element level, then all the data inside this will not be printed in the file.\",\"functionOutput\":\"EXCLUDE()\"}]",
                        "droolsBusinessRulePreDrlText": "DataSet Writing Rule",
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupId": 9,
                            "droolsBusinessRuleGroupName": "DataSetWritingRule"
                        },
                        "standardizedAttrLst": [
                            "employee.adjustedSalary"
                        ]
                    },
                    "flsbaId": null,
                    "fileLayoutSchemaNodeInfo": {
                        "flsniId": 291829
                    }
                }
            ],
            "oldData": "{\"id\":291829,\"referenceId\":1,\"category\":\"Section\",\"dataType\":\"NODE\",\"displayName\":\"Header\",\"parentId\":null,\"minOccurance\":1,\"maxOccurance\":1,\"description\":\"Section\",\"mandatory\":true,\"hasChildren\":true,\"rowPosition\":null,\"lstCtlsNodeBrAssoc\":null,\"lstFlsNodeBrAssoc\":null}",
            "PDNLoder": false
        },
        "leaf": true
    },
    "parent": null,
    "level": 0,
    "visible": true
};
let rowIndex = 1;
let actionItems = {
    toggle: (e) => {
    },
    hide: () => {
    }
};
let _actionItems;

describe("AlDynamicSchemaGenerationFileComponent", () => {
    let component: AlDynamicSchemaGenerationFileComponent;
    let fixture: ComponentFixture<AlDynamicSchemaGenerationFileComponent>;
    let toastService, alNotificationsService;

    function populateData() {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/metaInfo.json");
        metaInfo = response.data;
        return metaInfo;
    }

    beforeEach(async(() => {
        TestBed.overrideComponent(AlDynamicSchemaGenerationFileComponent, {
            set: {
                providers: [
                    { provide: FileSetupService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });

        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlDynamicSchemaGenerationFileComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                { provide: FileSetupService, useClass: MockDataService },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                // { provide: ConfirmationService, useClass: MockDataService },
                { provide: AlRuleEditorService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService }
            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlDynamicSchemaGenerationFileComponent);
            component = fixture.debugElement.componentInstance;
            component.metaInfo = populateData();
            component.selRowData = selRowData;
            // component.actionItems = actionItems;
            fixture.detectChanges();
        });

        toastService = TestBed.get(ToastsManager);
    }));

    afterEach(() => {
        fixture.destroy();
        component = null;
    });

    it("should create", async(() => {
        expect(component).toBeTruthy();
    }));

    it("should call getDynamicSchemaGeneration()", () => {
        component.getDynamicSchemaGeneration();
    });

    it("should call nextStep()", () => {
        component.nextStep();
    });

    it("should call showSpecDel()", () => {
        component.showSpecDel();
    });

    it("should call onSpecDelClose()", () => {
        component.onSpecDelClose();
    });
    it("should call action(), printDisplayName(), saveDSGRow(), checkAssigned()", () => {
        const e = {
            stopPropagation: (e) => {
            }
        };
        component.selRowData = selRowData;
        component.action(e, selRowData, rowIndex, actionItems);
        let confirmService = fixture.debugElement.injector.get(ConfirmationService);
        spyOn(confirmService, "confirm").and.callFake((params: any) => {
            params.accept();
        });
        component.printDisplayName();
        component.saveDSGRow(selRowData, rowIndex, actionItems);


        component.ruleEditorComp = {
            printDisplayName: function () { return false; },
            reGenerateUI: function () { return false; }
        };
        component.identifyRowAndopenRuleEditor(selRowData, 0, 0, component.actionItems, "RuleGroupName", 123, true);
        component.resetRowData(selRowData, rowIndex);
        _actionItems = component.actionItems;
    });


    it("should call pushRuleToAttribute()", () => {
        let resultMap = new Map();
        resultMap.set("rule", {
            "ruleExecutionSequence": 1,
            "isActive": true,
            "ruleExecutionComment": "",
            "droolsBusinessRulesDecisionTable": {
                "droolsBusinessRuleId": null,
                "isCurrent": true,
                "droolsBusinessRuleVersion": 1,
                "droolsBusinessRuleName": "Mix_Template",
                "droolsBusinessRuleDrlFileContent": "package com.alight.idis;\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\n\n\nrule \" Dataset Writing Rule 707132651100883 0\" salience 0\nwhen\n\t$transactionDatasetView : TransactionDatasetView()\n\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\n\n\tif(707132651100883l > 0 && ( $transactionDatasetView.getEmployee().getAdjustedSalary() != null  ) ) break [GOTO_THEN_1]\nthen\n\t /** NOTHING TO DO -- DEFAULT CASE */ \nthen [GOTO_THEN_1] \n\t$outBoundDataSetWritingRule.excludeNode(\"Section\",\"Header\",291829);\nend\n\n",
                "droolsBusinessRuleUiJsonText": "[{\"dataIndex\":\"dataIndex_0\",\"droolsBusinessRuleTemplateId\":19,\"droolsBusinessRuleTemplateName\":\"Dataset Writing Rule\",\"droolsBusinessRuleTemplateGroup\":{\"createdBy\":\"Divya Jain\",\"createdDateTime\":\"30/12/2018 06:00:00.000 GMT\",\"updatedBy\":null,\"updatedDateTime\":null,\"droolsBusinessRuleGroupId\":9,\"droolsBusinessRuleGroupName\":\"DataSetWritingRule\",\"parentGroupId\":null,\"droolsBusinessRuleGroupPriority\":1},\"droolsBusinessRuleTemplateVersion\":1,\"droolsBusinessRuleTemplateContent\":\"template header objName1\\r\\n\\r\\npackage com.alight.idis;\\r\\n\\r\\n/*\\r\\n{\\r\\n \\\"ruleType\\\": \\\"DataSetWritingRule\\\",\\r\\n \\\"ruleConditionValue\\\": [\\r\\n   {\\r\\n     \\\"attributeName\\\": \\\"attrname1\\\",\\r\\n     \\\"conditions\\\": [\\r\\n       {\\r\\n         \\\"id\\\": \\\"1\\\",\\r\\n         \\\"label\\\": \\\"Conditional Statements\\\",\\r\\n         \\\"helpText\\\": \\\"Text area for creating rules\\\",\\r\\n         \\\"type\\\": \\\"textarea\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"6\\\",\\r\\n         \\\"separator\\\": \\\"false\\\"\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"2\\\",\\r\\n         \\\"label\\\": \\\"Action Statements\\\",\\r\\n         \\\"helpText\\\": \\\"Text area for creating Action Statements\\\",\\r\\n         \\\"type\\\": \\\"textarea\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"6\\\",\\r\\n         \\\"separator\\\": \\\"true\\\"\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"3\\\",\\r\\n         \\\"label\\\": \\\"Attributes\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"4\\\",\\r\\n         \\\"label\\\": \\\"Operators\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/operators\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"5\\\",\\r\\n         \\\"label\\\": \\\"Functions\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/functions/outbound/all\\\",\\r\\n         \\\"columns\\\": \\\"2\\\",\\r\\n         \\\"separator\\\": \\\"false\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       },\\r\\n       {\\r\\n         \\\"id\\\": \\\"6\\\",\\r\\n         \\\"label\\\": \\\"Select Function\\\",\\r\\n         \\\"helpText\\\": \\\"\\\",\\r\\n         \\\"type\\\": \\\"dropdown\\\",\\r\\n         \\\"userInput\\\": \\\"\\\",\\r\\n         \\\"endpoint\\\": \\\"/functions/conditional/action/outbound/all\\\",\\r\\n         \\\"columns\\\": \\\"3\\\",\\r\\n         \\\"separator\\\": \\\"true\\\",\\r\\n         \\\"options\\\": [\\r\\n           {\\r\\n             \\\"label\\\": \\\"-Please Select-\\\",\\r\\n             \\\"value\\\": \\\"-Please Select-\\\"\\r\\n           }\\r\\n         ]\\r\\n       }\\r\\n     ]\\r\\n   }\\r\\n ]\\r\\n}\\r\\n*/\\r\\n\\r\\n\\r\\ntemplate \\\"DataSetWritingRule\\\"\\r\\n\\r\\n\\r\\nend template\",\"isActive\":1,\"approvalStatusId\":1,\"approvalStatusUpdatedBy\":\"Divya Jain\",\"approvalStatusUpdatedDate\":1546236000000,\"approvalStatusComment\":\"approved\",\"createdBy\":\"Divya Jain\",\"createdDateTime\":1546236000000,\"uiElements\":[{\"id\":\"1\",\"label\":\"Conditional Statements\",\"helpText\":\"Text area for creating rules\",\"type\":\"textarea\",\"userInput\":\"EXCLUDE()\",\"endpoint\":\"\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":6,\"options\":[]},{\"id\":\"2\",\"label\":\"Action Statements\",\"helpText\":\"Text area for creating Action Statements\",\"type\":\"textarea\",\"userInput\":\"EXCLUDE()\",\"endpoint\":\"\",\"separator\":\"true\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":6,\"options\":[]},{\"id\":\"3\",\"label\":\"Attributes\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[],\"selectedValue\":\"@TransactionDatasetView::[Employee].[Adjusted Salary]\"},{\"id\":\"4\",\"label\":\"Operators\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/operators\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[],\"selectedValue\":\"!= null\"},{\"id\":\"5\",\"label\":\"Functions\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/functions/outbound/all\",\"separator\":\"false\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":2,\"options\":[]},{\"id\":\"6\",\"label\":\"Select Function\",\"helpText\":\"\",\"type\":\"dropdown\",\"userInput\":null,\"endpoint\":\"/functions/conditional/action/outbound/all\",\"separator\":\"true\",\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":3,\"options\":[],\"selectedValue\":\"EXCLUDE()\",\"drlText\":\"EXCLUDE()\"}],\"label\":\"Dataset Writing Rule\",\"value\":11,\"ruleOrder\":1,\"DWRAttr\":\"@TransactionDatasetView::[Employee].[Adjusted Salary]\",\"functionOutputC\":\"\\\"@TransactionDatasetView::[Employee].[Adjusted Salary]\\\" != null\",\"DWROper\":\"!= null\",\"selectionStart\":0,\"functionOutput\":\"EXCLUDE()\",\"DWRFuncB\":\"EXCLUDE()\",\"helpTextDropDown\":\"This function will not print the data. EXCLUDE() is applied on Node/Element level, then all the data inside this will not be printed in the file.\"}]",
                "droolsBusinessRulePreDrlText": "DataSet Writing Rule",
                "droolsBusinessRuleGroup": {
                    "droolsBusinessRuleGroupId": 9,
                    "droolsBusinessRuleGroupName": "DataSetWritingRule"
                },
                "standardizedAttrLst": [
                    "employee.adjustedSalary"
                ]
            },
            "flsbaId": null,
            "fileLayoutSchemaNodeInfo": {
                "flsniId": 291829
            }
        });
        component.pushRuleToAttribute(resultMap);
    });

    it("should call loadNodes()", () => {
        component.loadNodes(selRowData.node);
        component.onNodeExpand(selRowData);
    });

    it("should and displayToolTipText()", () => {
        component.dynamicGenerationToolTip = {
            "Test": {
                "tooltipDesc": "Data Type",
                "readMoreLink": "http://www.google.com"
            }
        };
        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "Test", "bottom");
            component.hideToolTipText(event);
        });
        btnNextStep.click();
    });

    it("should and checkAssigned()", () => {
        const e = {
            stopPropagation: (e) => {
            }
        };
        component.selRowData = selRowData;
        component.action(e, selRowData, rowIndex, actionItems);
        component.ruleEditorComp = {
            printDisplayName: function () { return false; },
            reGenerateUI: function () { return false; }
        };

        component.selRowData = {
            "node": {
                "data": {
                    "lstFlsNodeBrAssoc": null
                }
            }
        };

        component.activeIndex = 0;
        component.nextStep();

        component.activeIndex = 1;
        component.nextStep();

        let event = {
            "node": {
                "data": [],
                "children": []
            }
        };
        component.onNodeExpand(event);
    });

    it("should add New Row Flow", () => {
        component.getDynamicSchemaGeneration();
        component.actionItems = <OverlayPanel>{
            toggle: (e) => {
            },
            hide: () => {
            }
        };
        component.selRowData.node["children"] = [];
        component.addSibling();
        component.addChild();
        let rowNode = {
            "node": {
                "data": {
                    "referenceId": 2,
                    "category": "Section",
                    "dataType": "NODE",
                    "displayName": "Header",
                    "parentId": null,
                    "minOccurance": 1,
                    "maxOccurance": 1,
                    "description": null,
                    "mandatory": true,
                    "hasChildren": true,
                    "rowPosition": null,
                    "lstCtlsNodeBrAssoc": [
                        {
                            "ruleExecutionSequence": 1,
                            "isActive": true,
                            "ruleExecutionComment": "",
                            "droolsBusinessRulesDecisionTable": {
                                "droolsBusinessRuleId": null,
                                "isCurrent": true,
                                "droolsBusinessRuleVersion": 1,
                                "droolsBusinessRuleName": "Mix_Template",
                                "droolsBusinessRuleDrlFileContent": "package com.alight.idis;\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\n\n\nrule \" PrintDisplayName 1021709943525186 0\" salience 0\nwhen\n\t$transactionDatasetView : TransactionDatasetView()\n\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\n\n\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\nthen\n\t /** NOTHING TO DO -- DEFAULT CASE */ \nthen [GOTO_THEN_1] \n\t$outBoundDataSetWritingRule.setHardCodeValue(\"Section-Header-270239\",\"Header\");\nend\n\n",
                                "droolsBusinessRuleUiJsonText": "[{\"dataIndex\":\"dataIndex_0\",\"droolsBusinessRuleTemplateId\":20,\"droolsBusinessRuleTemplateName\":\"PrintDisplayName\",\"droolsBusinessRuleTemplateGroup\":{\"createdBy\":\"Divya Jain\",\"createdDateTime\":\"30/12/2018 06:00:00.000 GMT\",\"updatedBy\":null,\"updatedDateTime\":null,\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\",\"parentGroupId\":null,\"droolsBusinessRuleGroupPriority\":1},\"droolsBusinessRuleTemplateVersion\":1,\"droolsBusinessRuleTemplateContent\":\"template header\\r\\n\\r\\nobjName1\\r\\n\\r\\npackage com.alight.idis;\\r\\n\\r\\n/*\\r\\n{\\r\\n\\t\\\"ruleType\\\": \\\"PrintDisplayName\\\",\\r\\n\\t\\\"ruleConditionValue\\\": [{\\r\\n\\t\\t\\\"attributeName\\\": \\\"attrname1\\\",\\r\\n\\t\\t\\\"conditions\\\": [{\\r\\n\\t\\t\\t\\\"id\\\": \\\"1\\\",\\r\\n\\t\\t\\t\\\"label\\\": \\\"Set PrintDisplayName Static Display Value\\\",\\r\\n\\t\\t\\t\\\"helpText\\\": \\\"Text box for setting fixed value\\\",\\r\\n\\t\\t\\t\\\"type\\\": \\\"textarea\\\",\\r\\n\\t\\t\\t\\\"userInput\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"endpoint\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"columns\\\":\\\"12\\\"\\r\\n\\t\\t}]\\r\\n\\t}\\r\\n\\t]\\r\\n}\\r\\n*/\\r\\n\\r\\n\\r\\ntemplate \\\"PrintDisplayName\\\"\\r\\n\\r\\n\\r\\nend template\",\"isActive\":1,\"approvalStatusId\":1,\"approvalStatusUpdatedBy\":\"Divya Jain\",\"approvalStatusUpdatedDate\":1546236000000,\"approvalStatusComment\":\"approved\",\"createdBy\":\"Divya Jain\",\"createdDateTime\":1546236000000,\"uiElements\":[{\"id\":\"1\",\"label\":\"Set PrintDisplayName Static Display Value\",\"helpText\":\"Text box for setting fixed value\",\"type\":\"textarea\",\"userInput\":null,\"endpoint\":\"\",\"separator\":null,\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":12,\"options\":[]}],\"label\":\"PrintDisplayName\",\"value\":12,\"ruleOrder\":1}]",
                                "droolsBusinessRulePreDrlText": "Print Display Name",
                                "droolsBusinessRuleGroup": {
                                    "droolsBusinessRuleGroupId": 10,
                                    "droolsBusinessRuleGroupName": "PrintDisplayName"
                                },
                                "standardizedAttrLst": null
                            },
                            "ctlsnbaId": null,
                        }
                    ],
                    "lstFlsNodeBrAssoc": null,
                    "validMO": false,
                    "validMX": false,
                    "PDNLoder": false,
                    "validCT": false,
                    "validDT": false,
                    "validDN": false
                },
                "leaf": true,
                "oldData": "{\"referenceId\":2,\"category\":\"Section\",\"dataType\":\"NODE\",\"displayName\":\"Header\",\"parentId\":null,\"minOccurance\":1,\"maxOccurance\":1,\"description\":null,\"mandatory\":true,\"hasChildren\":true,\"rowPosition\":null,\"lstCtlsNodeBrAssoc\":[{\"ruleExecutionSequence\":1,\"isActive\":true,\"ruleExecutionComment\":\"\",\"droolsBusinessRulesDecisionTable\":{\"droolsBusinessRuleId\":null,\"isCurrent\":true,\"droolsBusinessRuleVersion\":1,\"droolsBusinessRuleName\":\"Mix_Template\",\"droolsBusinessRuleDrlFileContent\":\"package com.alight.idis;\\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\\n\\n\\nrule \\\" PrintDisplayName 1021709943525186 0\\\" salience 0\\nwhen\\n\\t$transactionDatasetView : TransactionDatasetView()\\n\\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\\n\\n\\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\\nthen\\n\\t /** NOTHING TO DO -- DEFAULT CASE */ \\nthen [GOTO_THEN_1] \\n\\t$outBoundDataSetWritingRule.setHardCodeValue(\\\"Section-Header-270239\\\",\\\"Header\\\");\\nend\\n\\n\",\"droolsBusinessRuleUiJsonText\":\"[{\\\"dataIndex\\\":\\\"dataIndex_0\\\",\\\"droolsBusinessRuleTemplateId\\\":20,\\\"droolsBusinessRuleTemplateName\\\":\\\"PrintDisplayName\\\",\\\"droolsBusinessRuleTemplateGroup\\\":{\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":\\\"30/12/2018 06:00:00.000 GMT\\\",\\\"updatedBy\\\":null,\\\"updatedDateTime\\\":null,\\\"droolsBusinessRuleGroupId\\\":10,\\\"droolsBusinessRuleGroupName\\\":\\\"PrintDisplayName\\\",\\\"parentGroupId\\\":null,\\\"droolsBusinessRuleGroupPriority\\\":1},\\\"droolsBusinessRuleTemplateVersion\\\":1,\\\"droolsBusinessRuleTempalteContent\\\":\\\"template header\\\\r\\\\n\\\\r\\\\nobjName1\\\\r\\\\n\\\\r\\\\npackage com.alight.idis;\\\\r\\\\n\\\\r\\\\n/*\\\\r\\\\n{\\\\r\\\\n\\\\t\\\\\\\"ruleType\\\\\\\": \\\\\\\"PrintDisplayName\\\\\\\",\\\\r\\\\n\\\\t\\\\\\\"ruleConditionValue\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\\\\"attributeName\\\\\\\": \\\\\\\"attrname1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\\\\"conditions\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"id\\\\\\\": \\\\\\\"1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"label\\\\\\\": \\\\\\\"Set PrintDisplayName Static Display Value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"helpText\\\\\\\": \\\\\\\"Text box for setting fixed value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"type\\\\\\\": \\\\\\\"textarea\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"userInput\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"endpoint\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"columns\\\\\\\":\\\\\\\"12\\\\\\\"\\\\r\\\\n\\\\t\\\\t}]\\\\r\\\\n\\\\t}\\\\r\\\\n\\\\t]\\\\r\\\\n}\\\\r\\\\n*/\\\\r\\\\n\\\\r\\\\n\\\\r\\\\ntemplate \\\\\\\"PrintDisplayName\\\\\\\"\\\\r\\\\n\\\\r\\\\n\\\\r\\\\nend template\\\",\\\"isActive\\\":1,\\\"approvalStatusId\\\":1,\\\"approvalStatusUpdatedBy\\\":\\\"Divya Jain\\\",\\\"approvalStatusUpdatedDate\\\":1546236000000,\\\"approvalStatusComment\\\":\\\"approved\\\",\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":1546236000000,\\\"uiElements\\\":[{\\\"id\\\":\\\"1\\\",\\\"label\\\":\\\"Set PrintDisplayName Static Display Value\\\",\\\"helpText\\\":\\\"Text box for setting fixed value\\\",\\\"type\\\":\\\"textarea\\\",\\\"userInput\\\":null,\\\"endpoint\\\":\\\"\\\",\\\"separator\\\":null,\\\"invisible\\\":false,\\\"onChangeNoAddButton\\\":false,\\\"columns\\\":12,\\\"options\\\":[]}],\\\"label\\\":\\\"PrintDisplayName\\\",\\\"value\\\":12,\\\"ruleOrder\\\":1}]\",\"droolsBusinessRulePreDrlText\":\"Print Display Name\",\"droolsBusinessRuleGroup\":{\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\"},\"standardizedAttrLst\":null},\"ctlsnbaId\":null}],\"lstFlsNodeBrAssoc\":null,\"validMO\":false,\"validMX\":false,\"PDNLoder\":false,\"validCT\":false,\"validDT\":false,\"validDN\":false}",
                "editMode": false
            },
            "parent": null,
            "level": 0,
            "visible": true
        };
        component.removeRow(rowNode, rowIndex, actionItems, true);
        component.deleteAttrRow(false);
        component.deleteAttrRow(true);
    });

    it("should call enableEditMode() & checkValue()", () => {
        let rowNode = {
            "node": {
                "data": {
                    "referenceId": 2,
                    "category": "Section",
                    "dataType": "NODE",
                    "displayName": "Header",
                    "parentId": null,
                    "minOccurance": 1,
                    "maxOccurance": 1,
                    "description": null,
                    "mandatory": true,
                    "hasChildren": true,
                    "rowPosition": null,
                    "lstCtlsNodeBrAssoc": [
                        {
                            "ruleExecutionSequence": 1,
                            "isActive": true,
                            "ruleExecutionComment": "",
                            "droolsBusinessRulesDecisionTable": {
                                "droolsBusinessRuleId": null,
                                "isCurrent": true,
                                "droolsBusinessRuleVersion": 1,
                                "droolsBusinessRuleName": "Mix_Template",
                                "droolsBusinessRuleDrlFileContent": "package com.alight.idis;\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\n\n\nrule \" PrintDisplayName 1021709943525186 0\" salience 0\nwhen\n\t$transactionDatasetView : TransactionDatasetView()\n\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\n\n\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\nthen\n\t /** NOTHING TO DO -- DEFAULT CASE */ \nthen [GOTO_THEN_1] \n\t$outBoundDataSetWritingRule.setHardCodeValue(\"Section-Header-270239\",\"Header\");\nend\n\n",
                                "droolsBusinessRuleUiJsonText": "[{\"dataIndex\":\"dataIndex_0\",\"droolsBusinessRuleTemplateId\":20,\"droolsBusinessRuleTemplateName\":\"PrintDisplayName\",\"droolsBusinessRuleTemplateGroup\":{\"createdBy\":\"Divya Jain\",\"createdDateTime\":\"30/12/2018 06:00:00.000 GMT\",\"updatedBy\":null,\"updatedDateTime\":null,\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\",\"parentGroupId\":null,\"droolsBusinessRuleGroupPriority\":1},\"droolsBusinessRuleTemplateVersion\":1,\"droolsBusinessRuleTemplateContent\":\"template header\\r\\n\\r\\nobjName1\\r\\n\\r\\npackage com.alight.idis;\\r\\n\\r\\n/*\\r\\n{\\r\\n\\t\\\"ruleType\\\": \\\"PrintDisplayName\\\",\\r\\n\\t\\\"ruleConditionValue\\\": [{\\r\\n\\t\\t\\\"attributeName\\\": \\\"attrname1\\\",\\r\\n\\t\\t\\\"conditions\\\": [{\\r\\n\\t\\t\\t\\\"id\\\": \\\"1\\\",\\r\\n\\t\\t\\t\\\"label\\\": \\\"Set PrintDisplayName Static Display Value\\\",\\r\\n\\t\\t\\t\\\"helpText\\\": \\\"Text box for setting fixed value\\\",\\r\\n\\t\\t\\t\\\"type\\\": \\\"textarea\\\",\\r\\n\\t\\t\\t\\\"userInput\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"endpoint\\\":\\\"\\\",\\r\\n\\t\\t\\t\\\"columns\\\":\\\"12\\\"\\r\\n\\t\\t}]\\r\\n\\t}\\r\\n\\t]\\r\\n}\\r\\n*/\\r\\n\\r\\n\\r\\ntemplate \\\"PrintDisplayName\\\"\\r\\n\\r\\n\\r\\nend template\",\"isActive\":1,\"approvalStatusId\":1,\"approvalStatusUpdatedBy\":\"Divya Jain\",\"approvalStatusUpdatedDate\":1546236000000,\"approvalStatusComment\":\"approved\",\"createdBy\":\"Divya Jain\",\"createdDateTime\":1546236000000,\"uiElements\":[{\"id\":\"1\",\"label\":\"Set PrintDisplayName Static Display Value\",\"helpText\":\"Text box for setting fixed value\",\"type\":\"textarea\",\"userInput\":null,\"endpoint\":\"\",\"separator\":null,\"invisible\":false,\"onChangeNoAddButton\":false,\"columns\":12,\"options\":[]}],\"label\":\"PrintDisplayName\",\"value\":12,\"ruleOrder\":1}]",
                                "droolsBusinessRulePreDrlText": "Print Display Name",
                                "droolsBusinessRuleGroup": {
                                    "droolsBusinessRuleGroupId": 10,
                                    "droolsBusinessRuleGroupName": "PrintDisplayName"
                                },
                                "standardizedAttrLst": null
                            },
                            "ctlsnbaId": null,
                        }
                    ],
                    "lstFlsNodeBrAssoc": null,
                    "validMO": false,
                    "validMX": false,
                    "PDNLoder": false,
                    "validCT": false,
                    "validDT": false,
                    "validDN": false
                },
                "leaf": true,
                "oldData": "{\"referenceId\":2,\"category\":\"Section\",\"dataType\":\"NODE\",\"displayName\":\"Header\",\"parentId\":null,\"minOccurance\":1,\"maxOccurance\":1,\"description\":null,\"mandatory\":true,\"hasChildren\":true,\"rowPosition\":null,\"lstCtlsNodeBrAssoc\":[{\"ruleExecutionSequence\":1,\"isActive\":true,\"ruleExecutionComment\":\"\",\"droolsBusinessRulesDecisionTable\":{\"droolsBusinessRuleId\":null,\"isCurrent\":true,\"droolsBusinessRuleVersion\":1,\"droolsBusinessRuleName\":\"Mix_Template\",\"droolsBusinessRuleDrlFileContent\":\"package com.alight.idis;\\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\\n\\n\\nrule \\\" PrintDisplayName 1021709943525186 0\\\" salience 0\\nwhen\\n\\t$transactionDatasetView : TransactionDatasetView()\\n\\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\\n\\n\\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\\nthen\\n\\t /** NOTHING TO DO -- DEFAULT CASE */ \\nthen [GOTO_THEN_1] \\n\\t$outBoundDataSetWritingRule.setHardCodeValue(\\\"Section-Header-270239\\\",\\\"Header\\\");\\nend\\n\\n\",\"droolsBusinessRuleUiJsonText\":\"[{\\\"dataIndex\\\":\\\"dataIndex_0\\\",\\\"droolsBusinessRuleTemplateId\\\":20,\\\"droolsBusinessRuleTemplateName\\\":\\\"PrintDisplayName\\\",\\\"droolsBusinessRuleTemplateGroup\\\":{\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":\\\"30/12/2018 06:00:00.000 GMT\\\",\\\"updatedBy\\\":null,\\\"updatedDateTime\\\":null,\\\"droolsBusinessRuleGroupId\\\":10,\\\"droolsBusinessRuleGroupName\\\":\\\"PrintDisplayName\\\",\\\"parentGroupId\\\":null,\\\"droolsBusinessRuleGroupPriority\\\":1},\\\"droolsBusinessRuleTemplateVersion\\\":1,\\\"droolsBusinessRuleTempalteContent\\\":\\\"template header\\\\r\\\\n\\\\r\\\\nobjName1\\\\r\\\\n\\\\r\\\\npackage com.alight.idis;\\\\r\\\\n\\\\r\\\\n/*\\\\r\\\\n{\\\\r\\\\n\\\\t\\\\\\\"ruleType\\\\\\\": \\\\\\\"PrintDisplayName\\\\\\\",\\\\r\\\\n\\\\t\\\\\\\"ruleConditionValue\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\\\\"attributeName\\\\\\\": \\\\\\\"attrname1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\\\\"conditions\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"id\\\\\\\": \\\\\\\"1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"label\\\\\\\": \\\\\\\"Set PrintDisplayName Static Display Value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"helpText\\\\\\\": \\\\\\\"Text box for setting fixed value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"type\\\\\\\": \\\\\\\"textarea\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"userInput\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"endpoint\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"columns\\\\\\\":\\\\\\\"12\\\\\\\"\\\\r\\\\n\\\\t\\\\t}]\\\\r\\\\n\\\\t}\\\\r\\\\n\\\\t]\\\\r\\\\n}\\\\r\\\\n*/\\\\r\\\\n\\\\r\\\\n\\\\r\\\\ntemplate \\\\\\\"PrintDisplayName\\\\\\\"\\\\r\\\\n\\\\r\\\\n\\\\r\\\\nend template\\\",\\\"isActive\\\":1,\\\"approvalStatusId\\\":1,\\\"approvalStatusUpdatedBy\\\":\\\"Divya Jain\\\",\\\"approvalStatusUpdatedDate\\\":1546236000000,\\\"approvalStatusComment\\\":\\\"approved\\\",\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":1546236000000,\\\"uiElements\\\":[{\\\"id\\\":\\\"1\\\",\\\"label\\\":\\\"Set PrintDisplayName Static Display Value\\\",\\\"helpText\\\":\\\"Text box for setting fixed value\\\",\\\"type\\\":\\\"textarea\\\",\\\"userInput\\\":null,\\\"endpoint\\\":\\\"\\\",\\\"separator\\\":null,\\\"invisible\\\":false,\\\"onChangeNoAddButton\\\":false,\\\"columns\\\":12,\\\"options\\\":[]}],\\\"label\\\":\\\"PrintDisplayName\\\",\\\"value\\\":12,\\\"ruleOrder\\\":1}]\",\"droolsBusinessRulePreDrlText\":\"Print Display Name\",\"droolsBusinessRuleGroup\":{\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\"},\"standardizedAttrLst\":null},\"ctlsnbaId\":null}],\"lstFlsNodeBrAssoc\":null,\"validMO\":false,\"validMX\":false,\"PDNLoder\":false,\"validCT\":false,\"validDT\":false,\"validDN\":false}",
                "editMode": false
            },
            "parent": null,
            "level": 0,
            "visible": true
        };
        component.enableEditMode(rowNode, rowIndex, actionItems);
        component.rowEditFlag = true;
        component.enableEditMode(rowNode, rowIndex, actionItems);
        let e = {
            currentTarget: {
                value: "",
                focus: function () { }
            }
        };
        let rowData = {};
        component.checkValue(e, rowData, "min");
        component.checkValue(e, rowData, "max");
        component.blankNodeRow();
    });

    it("should call saveRowData()", () => {
        let data = {};
        component.selRowData = {
            "node": {
                "data": {
                    "referenceId": 2,
                    "category": "Section",
                    "dataType": "NODE",
                    "displayName": "Header",
                    "parentId": null,
                    "minOccurance": 1,
                    "maxOccurance": 1,
                    "description": null,
                    "mandatory": true,
                    "hasChildren": true,
                    "rowPosition": null,
                    "lstCtlsNodeBrAssoc": null,
                    "lstFlsNodeBrAssoc": null,
                    "validMO": false,
                    "validMX": false,
                    "PDNLoder": false,
                    "validCT": false,
                    "validDT": false,
                    "validDN": false
                },
                "leaf": true,
                "oldData": "{\"referenceId\":2,\"category\":\"Section\",\"dataType\":\"NODE\",\"displayName\":\"Header\",\"parentId\":null,\"minOccurance\":1,\"maxOccurance\":1,\"description\":null,\"mandatory\":true,\"hasChildren\":true,\"rowPosition\":null,\"lstCtlsNodeBrAssoc\":[{\"ruleExecutionSequence\":1,\"isActive\":true,\"ruleExecutionComment\":\"\",\"droolsBusinessRulesDecisionTable\":{\"droolsBusinessRuleId\":null,\"isCurrent\":true,\"droolsBusinessRuleVersion\":1,\"droolsBusinessRuleName\":\"Mix_Template\",\"droolsBusinessRuleDrlFileContent\":\"package com.alight.idis;\\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\\n\\n\\nrule \\\" PrintDisplayName 1021709943525186 0\\\" salience 0\\nwhen\\n\\t$transactionDatasetView : TransactionDatasetView()\\n\\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\\n\\n\\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\\nthen\\n\\t /** NOTHING TO DO -- DEFAULT CASE */ \\nthen [GOTO_THEN_1] \\n\\t$outBoundDataSetWritingRule.setHardCodeValue(\\\"Section-Header-270239\\\",\\\"Header\\\");\\nend\\n\\n\",\"droolsBusinessRuleUiJsonText\":\"[{\\\"dataIndex\\\":\\\"dataIndex_0\\\",\\\"droolsBusinessRuleTemplateId\\\":20,\\\"droolsBusinessRuleTemplateName\\\":\\\"PrintDisplayName\\\",\\\"droolsBusinessRuleTemplateGroup\\\":{\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":\\\"30/12/2018 06:00:00.000 GMT\\\",\\\"updatedBy\\\":null,\\\"updatedDateTime\\\":null,\\\"droolsBusinessRuleGroupId\\\":10,\\\"droolsBusinessRuleGroupName\\\":\\\"PrintDisplayName\\\",\\\"parentGroupId\\\":null,\\\"droolsBusinessRuleGroupPriority\\\":1},\\\"droolsBusinessRuleTemplateVersion\\\":1,\\\"droolsBusinessRuleTempalteContent\\\":\\\"template header\\\\r\\\\n\\\\r\\\\nobjName1\\\\r\\\\n\\\\r\\\\npackage com.alight.idis;\\\\r\\\\n\\\\r\\\\n/*\\\\r\\\\n{\\\\r\\\\n\\\\t\\\\\\\"ruleType\\\\\\\": \\\\\\\"PrintDisplayName\\\\\\\",\\\\r\\\\n\\\\t\\\\\\\"ruleConditionValue\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\\\\"attributeName\\\\\\\": \\\\\\\"attrname1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\\\\"conditions\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"id\\\\\\\": \\\\\\\"1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"label\\\\\\\": \\\\\\\"Set PrintDisplayName Static Display Value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"helpText\\\\\\\": \\\\\\\"Text box for setting fixed value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"type\\\\\\\": \\\\\\\"textarea\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"userInput\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"endpoint\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"columns\\\\\\\":\\\\\\\"12\\\\\\\"\\\\r\\\\n\\\\t\\\\t}]\\\\r\\\\n\\\\t}\\\\r\\\\n\\\\t]\\\\r\\\\n}\\\\r\\\\n*/\\\\r\\\\n\\\\r\\\\n\\\\r\\\\ntemplate \\\\\\\"PrintDisplayName\\\\\\\"\\\\r\\\\n\\\\r\\\\n\\\\r\\\\nend template\\\",\\\"isActive\\\":1,\\\"approvalStatusId\\\":1,\\\"approvalStatusUpdatedBy\\\":\\\"Divya Jain\\\",\\\"approvalStatusUpdatedDate\\\":1546236000000,\\\"approvalStatusComment\\\":\\\"approved\\\",\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":1546236000000,\\\"uiElements\\\":[{\\\"id\\\":\\\"1\\\",\\\"label\\\":\\\"Set PrintDisplayName Static Display Value\\\",\\\"helpText\\\":\\\"Text box for setting fixed value\\\",\\\"type\\\":\\\"textarea\\\",\\\"userInput\\\":null,\\\"endpoint\\\":\\\"\\\",\\\"separator\\\":null,\\\"invisible\\\":false,\\\"onChangeNoAddButton\\\":false,\\\"columns\\\":12,\\\"options\\\":[]}],\\\"label\\\":\\\"PrintDisplayName\\\",\\\"value\\\":12,\\\"ruleOrder\\\":1}]\",\"droolsBusinessRulePreDrlText\":\"Print Display Name\",\"droolsBusinessRuleGroup\":{\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\"},\"standardizedAttrLst\":null},\"ctlsnbaId\":null}],\"lstFlsNodeBrAssoc\":null,\"validMO\":false,\"validMX\":false,\"PDNLoder\":false,\"validCT\":false,\"validDT\":false,\"validDN\":false}",
                "editMode": true
            },
            "parent": null,
            "level": 0,
            "visible": true
        };
        component.saveRowData(data);
    });

    it("should call findChildData()", () => {
        let mydata = [
            { data: { id: 0 }, children: [] },
            { data: { id: 1 }, children: [] }
        ];
        let pId = 1;
        component.selRowData = {
            "node": {
                "data": {
                    "referenceId": 2,
                    "category": "Section",
                    "dataType": "NODE",
                    "displayName": "Header",
                    "parentId": null,
                    "minOccurance": 1,
                    "maxOccurance": 1,
                    "description": null,
                    "mandatory": true,
                    "hasChildren": true,
                    "rowPosition": null,
                    "lstCtlsNodeBrAssoc": null,
                    "lstFlsNodeBrAssoc": null,
                    "validMO": false,
                    "validMX": false,
                    "PDNLoder": false,
                    "validCT": false,
                    "validDT": false,
                    "validDN": false
                },
                "leaf": true,
                "oldData": "{\"referenceId\":2,\"category\":\"Section\",\"dataType\":\"NODE\",\"displayName\":\"Header\",\"parentId\":null,\"minOccurance\":1,\"maxOccurance\":1,\"description\":null,\"mandatory\":true,\"hasChildren\":true,\"rowPosition\":null,\"lstCtlsNodeBrAssoc\":[{\"ruleExecutionSequence\":1,\"isActive\":true,\"ruleExecutionComment\":\"\",\"droolsBusinessRulesDecisionTable\":{\"droolsBusinessRuleId\":null,\"isCurrent\":true,\"droolsBusinessRuleVersion\":1,\"droolsBusinessRuleName\":\"Mix_Template\",\"droolsBusinessRuleDrlFileContent\":\"package com.alight.idis;\\nimport com.alight.adapt.dataextraction.transaction.v1.models.view.TransactionDatasetView;\\nimport com.alight.idis.rules.dataset.OutBoundDataSetWritingRule;\\n\\n\\nrule \\\" PrintDisplayName 1021709943525186 0\\\" salience 0\\nwhen\\n\\t$transactionDatasetView : TransactionDatasetView()\\n\\t$outBoundDataSetWritingRule : OutBoundDataSetWritingRule()\\n\\n\\tif(1021709943525186l > 0 ) break [GOTO_THEN_1]\\nthen\\n\\t /** NOTHING TO DO -- DEFAULT CASE */ \\nthen [GOTO_THEN_1] \\n\\t$outBoundDataSetWritingRule.setHardCodeValue(\\\"Section-Header-270239\\\",\\\"Header\\\");\\nend\\n\\n\",\"droolsBusinessRuleUiJsonText\":\"[{\\\"dataIndex\\\":\\\"dataIndex_0\\\",\\\"droolsBusinessRuleTemplateId\\\":20,\\\"droolsBusinessRuleTemplateName\\\":\\\"PrintDisplayName\\\",\\\"droolsBusinessRuleTemplateGroup\\\":{\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":\\\"30/12/2018 06:00:00.000 GMT\\\",\\\"updatedBy\\\":null,\\\"updatedDateTime\\\":null,\\\"droolsBusinessRuleGroupId\\\":10,\\\"droolsBusinessRuleGroupName\\\":\\\"PrintDisplayName\\\",\\\"parentGroupId\\\":null,\\\"droolsBusinessRuleGroupPriority\\\":1},\\\"droolsBusinessRuleTemplateVersion\\\":1,\\\"droolsBusinessRuleTempalteContent\\\":\\\"template header\\\\r\\\\n\\\\r\\\\nobjName1\\\\r\\\\n\\\\r\\\\npackage com.alight.idis;\\\\r\\\\n\\\\r\\\\n/*\\\\r\\\\n{\\\\r\\\\n\\\\t\\\\\\\"ruleType\\\\\\\": \\\\\\\"PrintDisplayName\\\\\\\",\\\\r\\\\n\\\\t\\\\\\\"ruleConditionValue\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\\\\"attributeName\\\\\\\": \\\\\\\"attrname1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\\\\"conditions\\\\\\\": [{\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"id\\\\\\\": \\\\\\\"1\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"label\\\\\\\": \\\\\\\"Set PrintDisplayName Static Display Value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"helpText\\\\\\\": \\\\\\\"Text box for setting fixed value\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"type\\\\\\\": \\\\\\\"textarea\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"userInput\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"endpoint\\\\\\\":\\\\\\\"\\\\\\\",\\\\r\\\\n\\\\t\\\\t\\\\t\\\\\\\"columns\\\\\\\":\\\\\\\"12\\\\\\\"\\\\r\\\\n\\\\t\\\\t}]\\\\r\\\\n\\\\t}\\\\r\\\\n\\\\t]\\\\r\\\\n}\\\\r\\\\n*/\\\\r\\\\n\\\\r\\\\n\\\\r\\\\ntemplate \\\\\\\"PrintDisplayName\\\\\\\"\\\\r\\\\n\\\\r\\\\n\\\\r\\\\nend template\\\",\\\"isActive\\\":1,\\\"approvalStatusId\\\":1,\\\"approvalStatusUpdatedBy\\\":\\\"Divya Jain\\\",\\\"approvalStatusUpdatedDate\\\":1546236000000,\\\"approvalStatusComment\\\":\\\"approved\\\",\\\"createdBy\\\":\\\"Divya Jain\\\",\\\"createdDateTime\\\":1546236000000,\\\"uiElements\\\":[{\\\"id\\\":\\\"1\\\",\\\"label\\\":\\\"Set PrintDisplayName Static Display Value\\\",\\\"helpText\\\":\\\"Text box for setting fixed value\\\",\\\"type\\\":\\\"textarea\\\",\\\"userInput\\\":null,\\\"endpoint\\\":\\\"\\\",\\\"separator\\\":null,\\\"invisible\\\":false,\\\"onChangeNoAddButton\\\":false,\\\"columns\\\":12,\\\"options\\\":[]}],\\\"label\\\":\\\"PrintDisplayName\\\",\\\"value\\\":12,\\\"ruleOrder\\\":1}]\",\"droolsBusinessRulePreDrlText\":\"Print Display Name\",\"droolsBusinessRuleGroup\":{\"droolsBusinessRuleGroupId\":10,\"droolsBusinessRuleGroupName\":\"PrintDisplayName\"},\"standardizedAttrLst\":null},\"ctlsnbaId\":null}],\"lstFlsNodeBrAssoc\":null,\"validMO\":false,\"validMX\":false,\"PDNLoder\":false,\"validCT\":false,\"validDT\":false,\"validDN\":false}",
                "editMode": true
            },
            "parent": null,
            "level": 0,
            "visible": true
        };
        component.selChildData = [];
        component.treeTableData = [];
        component.findChildData(mydata, pId);
    });

});


class MockDataService {

    // childService methods
    // =============================

    getAllOutboundFileAttributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-dynamic-schema-generation-file/getFileAttributeList.json");
        return (Observable.of(response));
    }

    getSectionwiseDynamicSchema(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-dynamic-schema-generation-file/getDynamicSchemaGeneration.json");
        return (Observable.of(response));
    }

    getAttributeStandarizedNameListByFileTypeId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }
    getPackageInfoByFileTypeId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }
    updateMappedDynamicSchemaColumns(): Observable<any> {
        let response = {
            "data": {
                "fileMetaInfo": [],
                "dynamicSchemaMappingRow": {
                    id: 123
                }
            },
            "error": false
        };
        return (Observable.of(response));
    }
    getDynamicSchemaByParentId(): Observable<any> {
        let response = {
            "data": {
                "node": {
                    "data": {
                        "id": 123
                    }
                }
            },
            "error": false
        };
        return (Observable.of(response));
    }
    getDataTypes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-dynamic-schema-generation-file/getDataTypes.json");
        return (Observable.of(response));
    }

    // toolTipUtils methods
    // =============================

    getPageAndFieldsDetails(childFileTemplateId, childFileTemplateVersion, fileTypeId): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    saveMappedDynamicSchemaColumns(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    deleteAttrRow(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }
    getOutboundFileAttributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }
    getDSGPackageInfo(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }
    getHistoryDataAtrributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }
    error() {
        return false;
    }

    success() {
        return true;
    }

    changeRoute() {
        return true;
    }

    confirm() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}

