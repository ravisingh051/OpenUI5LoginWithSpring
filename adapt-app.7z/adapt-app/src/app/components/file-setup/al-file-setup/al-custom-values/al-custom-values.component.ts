/*
import { Component, OnInit, Input } from '@angular/core';
import { OverlayPanel } from 'primeng/components/overlaypanel/overlaypanel';
import { DataTableModule } from 'primeng/components/datatable/datatable';
import { PickListModule } from 'primeng/primeng';
import { PanelModule } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ToastsManager } from 'ng2-toastr';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import { MultiSelectModule } from 'primeng/components/multiselect/multiselect';
import { AlCustomValuesService } from './al-custom-values-service/al-custom-values-service';
import { ConfirmationService } from 'primeng/components/common/api';
import { FileSetupService } from '../../al-file-setup-services/file-setup.service';


@Component({
  selector: 'al-custom-values',
  templateUrl: './al-custom-values.component.html',
  styleUrls: ['./al-custom-values.component.scss'],
  providers: [AlCustomValuesService, ConfirmationService, FileSetupService]
})


export class AlCustomValuesComponent implements OnInit {
  @Input() fileId: number;
  @Input() fileVersion: number;
  @Input() employerIds: any;
  @Input() fileDataExtractionMode: string;
  @Input() viewOnly: boolean;
  @Input() fileMetainfo: any;
  //  Delete after getting APIs
  dummyObj: any = [];

  fromProfileData: any = [];
  fromProfile;
  toProfileData: any = [];
  toProfile;
  FCIndicator = "";
  saveCESForm: any = [];
  validForm:boolean;
  activeValue:boolean = false;

  // Edit Data
  editRes: any = [];
  isEditMode: boolean = false;

  // Selection Criteria Settings
  scnName; scnNameData: any = []; ACVListData: any = []; ACVList: any = []; ACVTableData: any = []; ACVTableStatus: any = [];
  benPlanYear:boolean = false; benPlanYearModel:string; scnExistValue:any = []; validPlanYear:boolean;

  // Business Criteria Settings
  BCSName: any = []; BCSNameData: any = []; BCSValue: any = []; BCSValueData: any = []; BCSObject:any = []; BCSTableData: any = []; BCSTableStatus: any = [];
  validBCSName:boolean; validBCSValue:boolean; BCSTableDataExist:boolean;

  // Change Criteria Settings
  CCSSection: any = []; CCSSectionData: any = []; CCSListData: any = []; CCSList: any = []; CCSTableData: any = []; CCSTableStatus: any = [];
  ccsExistValue:any = [];
  constructor(
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private alCustValSer: AlCustomValuesService,
    private fileSetupService: FileSetupService
  ) {}

  ngOnInit() {
    // -------------------------| Edit Mode |----------------------------------//
    this.fileVersion = this.fileVersion == undefined ? 1 : this.fileVersion;
    this.alCustValSer.getfileExtractionParameters(this.fileId, this.fileVersion).subscribe(res =>{
      if(!res.error){
        this.editRes = res.data;
        if(this.editRes !== null){
          // Edit for Selection Criteria Settings
          this.isEditMode=this.editRes.isEditMode;
          for(let ACVTData of this.editRes.selectionCriteriaSettings.selectedCriteria){
            this.ACVTableData.push(ACVTData);
          }
          for (let i = 0; i < this.ACVTableData.length; i++) {
            if(this.ACVTableData[i].isActive == true){
              this.ACVTableStatus[i] = i.toString();
            }
          }
          let _benPanYear = this.editRes.selectionCriteriaSettings.selectedCriteria.filter(obj => obj.paramId == 27);
          this.benPlanYearModel = _benPanYear[0].key;
          // Edit for Business Criteria Settings
          for(let BCSData of this.editRes.businessCriteriaSettings.criteriaValue){
            this.BCSTableData.push(BCSData);
          }
          for (let i = 0; i < this.BCSTableData.length; i++) {
            if(this.BCSTableData[i].isActive == true){
              this.BCSTableStatus[i] = i.toString();
            }
          }
          // Edit for Change Criteria Settings
          for(let CCSData of this.editRes.changeCriteriaSettings.selectedParameter){
            this.CCSTableData.push(CCSData);
          }
          for (let i = 0; i < this.CCSTableData.length; i++) {
            if(this.CCSTableData[i].isActive == true){
              this.CCSTableStatus[i] = i.toString();
            }
          }
        }
      }
      else{
        this.toastr.error(res.message,'Oops!')
        }
      },error => {
        this.toastr.error("Server Error in getting Extraction Parameters.",'Oops!');
    })
    // -------------------------| Edit Mode |----------------------------------//

    // From Profile DropDown Value populate
    this.FCIndicator = this.fileDataExtractionMode;
    this.alCustValSer.getFromProfile().subscribe(res => {
      if (!res.error) {
        this.fromProfileData = res.data;
        this.fromProfile = '';
        // console.log(JSON.stringify(this.fromProfileData));
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting From Profile Data.", 'Oops!');
    })

    // To Profile DropDown Value populate
    this.alCustValSer.getToProfile().subscribe(res => {
      if (!res.error) {
        this.toProfileData = res.data;
        this.toProfile = '';
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting From Profile Data.", 'Oops!');
    })

    // -------------------------| Selection Criteria Settings : Section 01 |----------------------------------//
    // Criteria Name
    this.alCustValSer.getCriteriaName().subscribe(res => {
      if (!res.error) {
        this.scnNameData = res.data;
        this.scnName = '';
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting Selected Criteria Parameters Data.", 'Oops!');
    })

    // -------------------------| Business Criteria Settings : Section 02 |----------------------------------//
    // Business Criteria Settings - Criteria Name
    this.alCustValSer.getBCSName().subscribe(res => {
      if (!res.error) {
        this.BCSNameData = res.data;
        this.BCSName = '';
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting Business Criteria Parameters Data.", 'Oops!');
    })

    // -------------------------| Change Criteria Settings : Section 03 |----------------------------------//
    // Change Criteria Settings - Section Name
    this.alCustValSer.getCCSSection(this.fileId,this.fileVersion).subscribe(res => {
      if (!res.error) {
        this.CCSSectionData = res.data;
        this.CCSSection = '';
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting Change Criteria Parameters Data.", 'Oops!');
    })
  }

  // -------------------------| Selection Criteria Settings : Section 01 |----------------------------------//
  // Exicutes on Selection Criteria Settings > Criteria Name
  updateSCVList() {
    this.ACVListData = [];
    this.scnExistValue = [];
    this.benPlanYear = false;
    if(this.scnName == '27'){
      this.benPlanYear = true;
    }
    this.ACVList = [];
    let scnName = Number(this.scnName);
    this.alCustValSer.getCriteriaValues(scnName,this.employerIds).subscribe(res => {
      if (!res.error) {
        // console.log(res.data)
        if (res.data !== null) {
          for (let i = 0; i < res.data.length; i++) {
            this.ACVListData.push(res.data[i]);
            this.ACVListData[i].isActive = true;
          }
        }
        // console.log(this.ACVListData);
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
    }, error => {
      this.toastr.error("Server Error in Getting Selected Criteria Parameters Data.", 'Oops!');
    })
  }
  ACVTable() {
    let _ACVObj = [];
    this.scnExistValue = [];
    for(let ACVObj of this.ACVList){
      let selected = this.ACVTableData.filter(ACVTObj => ACVTObj.paramId == ACVObj.paramId && ACVTObj.key == ACVObj.key);
      if(selected.length > 0){
        this.scnExistValue.push(selected[0].value);
      }
      else{
        _ACVObj.push(ACVObj);
      }
    }
    this.ACVTableData = this.ACVTableData.concat(_ACVObj);
    for (let i = 0; i < this.ACVTableData.length; i++) {
      this.ACVTableStatus[i] = i.toString();
    }
  }
  addBenefitPlanYear(){
    let reg =/^\d+$/;
    if(reg.test(this.benPlanYearModel)){
      this.validPlanYear = false;
    }
    else {
      this.validPlanYear = true;
      return false;
    }
    // console.log('this.benPlanYearModel :: '+this.benPlanYearModel);
    for(let AcvtData of this.ACVTableData){
      if(AcvtData.paramId == this.scnName){
        AcvtData.key = this.benPlanYearModel;
        AcvtData.value = this.benPlanYearModel;
        AcvtData.fileExtparamDisplayValue = this.benPlanYearModel;
        return false;
      }
    }
    let _bnftPlanData = this.scnNameData.filter( obj => obj.extparamId == this.scnName);
    let _data = {
      "id": null,
      "paramId": _bnftPlanData[0].extparamId,
      "paramName": _bnftPlanData[0].extparamName,
      "typeId": _bnftPlanData[0].extractionParamType.extractionParamTypeId,
      "type": _bnftPlanData[0].extractionParamType.extractionParamTypeName,
      "key": this.benPlanYearModel,
      "value": this.benPlanYearModel,
      "description": null,
      "sectionId": null,
      "sectionName": null,
      "sectionDescription": null,
      "isActive": true,
      "valueId": null,
      "fileVersion": null,
      "fileExtparamDisplayValue": this.benPlanYearModel
    }
    this.ACVTableData = this.ACVTableData.concat(_data);
    for (let i = 0; i < this.ACVTableData.length; i++) {
      this.ACVTableStatus[i] = i.toString();
    }
  }
  updateStatusACV(e, indx) {
    this.ACVTableData[indx].isActive = e;
  }

  // -------------------------| Business Criteria Settings : Section 02 |----------------------------------//
  getBCSValue() {
    let _BCSName = Number(this.BCSName);
    this.alCustValSer.getBCSValue(_BCSName,this.employerIds).subscribe(res => {
      if (!res.error) {
        this.BCSValueData = res.data;
        this.BCSValue = '';

      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
    }, error => {
      this.toastr.error("Server Error in Getting Business Criteria Parameters Data.", 'Oops!');
    })
  }
  getBCSObject(){
	  // console.log(this.BCSValue);
	  this.BCSObject = this.BCSValueData.filter((obj) => obj.key == this.BCSValue);
    this.BCSObject = this.BCSObject[0];
    this.BCSObject.isActive = true;
	  // console.log(this.BCSObject);
  }
  AddBCSTable(){
    this.validBCSName = false;
    this.validBCSValue = false;
    this.BCSTableDataExist = false;
    if(this.BCSName == ''){
      this.validBCSName = true;
      return false;
    }
    if(this.BCSValue.length == 0){
      this.validBCSValue = true;
      return false;
    }
    let selected = this.BCSTableData.filter(obj => obj.paramId == this.BCSObject.paramId && obj.key == this.BCSObject.key);
    if(selected.length > 0){
      this.BCSTableDataExist = true;
      return false;
    }
    else{
      let _data = this.BCSTableData.filter(obj => obj.paramId == this.BCSObject.paramId);
      if(_data.length > 0){
        for(let _BCSData of this.BCSTableData){
          if(_BCSData.paramId == this.BCSObject.paramId){
            _BCSData.key = this.BCSObject.key;
            _BCSData.value = this.BCSObject.value;
            _BCSData.description = this.BCSObject.description;
            _BCSData.valueId = this.BCSObject.valueId;
          }
        }
      }
      else {
        this.BCSTableData = this.BCSTableData.concat(this.BCSObject);
      }
      for (let i = 0; i < this.BCSTableData.length; i++) {
        this.BCSTableStatus[i] = i.toString();
      }
    }
  }
  updateStatusBCS(e, indx) {
    this.BCSTableData[indx].isActive = e;
  }

  // -------------------------| Change Criteria Settings : Section 03 |----------------------------------//
  // Change Criteria Settings - Available Parameters
  getCCSValue(){
    this.CCSListData = [];
    this.CCSList = [];
    this.alCustValSer.getCCSListData(this.fileId, this.fileVersion, this.CCSSection).subscribe(res => {
      if (!res.error) {
        if(res.data !== null){
          for (let i = 0; i < res.data.length; i++) {
            this.CCSListData.push(res.data[i]);
            this.CCSListData[i].isActive = true;
          }
          // console.log(this.CCSListData);
        }
      }
      else {
        this.toastr.error(res.message, 'Oops!')
      }
      }, error => {
      this.toastr.error("Server Error in Getting Change Criteria Parameters Data.", 'Oops!');
    })
  }
  CCSTable() {

    let _ACVObj = [];
    this.ccsExistValue = [];
    for(let ACVObj of this.CCSList){
      let selected = this.CCSTableData.filter(ACVTObj => ACVTObj.paramId == ACVObj.paramId && ACVTObj.key == ACVObj.key);
      if(selected.length > 0){
        this.ccsExistValue.push(selected[0].value);
      }
      else{
        _ACVObj.push(ACVObj);
      }
    }
    this.CCSTableData = this.CCSTableData.concat(_ACVObj);
    for (let i = 0; i < this.CCSTableData.length; i++) {
      this.CCSTableStatus[i] = i.toString();
    }
  }
  updateStatusCCS(e, indx) {
    this.CCSTableData[indx].isActive = e;
  }

  // Save Customize Extraction Criteria Form
  saveCECForm(CECForm: NgForm) {
    this.activeValue = false;
    let _bnftPlan = this.ACVTableData.filter( obj => obj.paramId == '27');
    let _empId = this.ACVTableData.filter( obj => obj.paramId == '10');
    this.validForm = false;
    if(_bnftPlan.length == 0 || _empId.length == 0){
      this.validForm = true;
      return false;
    }
    else {
      if(_bnftPlan[0].isActive == false){
        this.activeValue = true;
        return true;
      }
      let _activeFlag = false;
      for(let _empData of _empId){
        if(_empData.isActive == true){
          _activeFlag = _empData.isActive;
        }
      }
      if(_activeFlag == false){
        this.activeValue = true;
        return false;
      }
    }
   if(this.ACVTableData.length !== 0){
      for(let i = 0; i<this.ACVTableData.length ;i++){
        this.ACVTableStatus[i] = i.toString();
      }
    }
      this.saveCESForm = {
        "fileId" : this.fileId,
        "fileVersion": this.fileVersion,
        "isEditMode": this.isEditMode,
        "customizeExtractionCriteria" : this.FCIndicator,
        "selectionCriteriaSettings" : {
          "criteriaName" : this.scnName,
          "selectedCriteria": this.ACVTableData
        },
        "businessCriteriaSettings" :{
          "criteriaName" : this.BCSName,
          "criteriaValue" : this.BCSTableData
        },
        "changeCriteriaSettings" : {
          "selectedParameter" : this.CCSTableData
        }
      }

      this.fileSetupService.updateFiles(this.fileMetainfo, this.fileMetainfo.recordId).subscribe(res => {
          if (!res.error) {
        	  this.saveCESForm.fileVersion = res.data.fileVersion;
        	  this.alCustValSer.saveCVFormData(this.saveCESForm).subscribe(res => {
        	        if (!res.error) {
        	          this.toastr.success("Custom Value Added Successfully.", "Success!");
        	          this.router.navigate(['/file-setup']);
        	        }
        	        else {
        	          this.toastr.error(res.message, 'Oops!')
        	        }
        	      }, error => {
        	        this.toastr.error("Server Error in adding Custom Value.", 'Oops!');
        	      });
          }
          else {
            this.toastr.error(res.message, 'Oops!')
          }
        }, error => {
          console.log(error);
          this.toastr.error("Server Error in updating file configuration.", 'Oops!');
        })


  }
  btnCancel() {
    this.router.navigate(['/file-setup']);
  }

}
*/