/*
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { extractData, handleError } from '../../../../../shared_functions/services.function';
import {AuthHttp} from 'angular2-jwt';
import { ApiEnvService } from '../../../../../env.service';


@Injectable()
export class AlCustomValuesService {
  serviceMappingURL = this.apiEnvEndpoint + '/ExtractionParameters/';
  defaultHeaders: Headers =  new Headers({ "Content-Type": "application/json"});

  constructor(private http: Http) { }


  getFromProfile() {
    return this.http.get(this.serviceMappingURL + 'getExtractionParameterTypes')
      .map(extractData).catch(handleError);
  }
  getToProfile() {
    return this.http.get(this.serviceMappingURL + 'getExtractionParameterTypes')
      .map(extractData).catch(handleError);
  }
  getCriteriaName() {
    return this.http.get(this.serviceMappingURL + 'getActivedSelectionCriteriaExtractionParameters')
      .map(extractData).catch(handleError);
  }
  getCriteriaValues(extractionParamId,employerIds){
    return this.http.get(this.serviceMappingURL + 'getExtractionParameterValuesByParamId?extractionParamId='+extractionParamId+'&employerIds='+employerIds)
    .map(extractData).catch(handleError);
  }
  getBCSName(){
    return this.http.get(this.serviceMappingURL + 'getActivedBusinessRuleCriteriaExtractionParameters')
    .map(extractData).catch(handleError);
  }
  getCCSSection(fileId,fileVersion){
    return this.http.get(this.serviceMappingURL + 'getActivatedChangeCriteriaTemplateSections?fileId='+fileId+'&fileVersion='+fileVersion)
    .map(extractData).catch(handleError);
  }

  getBCSValue(extractionParamId,employerIds){
    return this.http.get(this.serviceMappingURL + 'getExtractionParameterValuesByParamId?extractionParamId='+extractionParamId+'&employerIds='+employerIds)
    .map(extractData).catch(handleError);
  }
  getCCSListData(fileId,fileVersion,sectionId){
    return this.http.get(this.serviceMappingURL + 'getActivedChangeCriteriaParametersByTempSectionId?fileId='+fileId+'&fileVersion='+fileVersion+'&templateSectionId='+sectionId)
    .map(extractData).catch(handleError);
  }
  saveCVFormData(data) {
    return this.http.post(this.apiEnvEndpoint + '/FileExtractionParameter/create', data)
       .map(res => res.json());
  }
  // -------------------------| Edit Mode |----------------------------------//
  getfileExtractionParameters(fileId,fileVersion) {
    let data = null;
    return this.http.get(this.apiEnvEndpoint + '/FileExtractionParameter/update/fileExtractionParameters?fileId='+fileId+'&fileVersion='+fileVersion)
      .map(extractData).catch(handleError);
  }

   checkExtractionParametersExistsByFileIdAndVersion(fileId,fileVersion) {
    return this.http.get(this.apiEnvEndpoint + '/FileExtractionParameter/checkExtractionParametersExistsByFileIdAndVersion?fileId='+fileId+'&fileVersion='+fileVersion)
      .map(extractData).catch(handleError);
  }
}
*/