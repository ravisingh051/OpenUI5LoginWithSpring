import { async, ComponentFixture, TestBed } from "@angular/core/testing";


// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, RouterModule, ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlLookupTableService } from "../al-file-setup-services/al-lookup-table.service";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";


// COMPONENT
// =========================
import { AlFileSetupComponent } from "./al-file-setup.component";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";


// SERVICE
// =========================
import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [];

describe("AlFileSetupComponent", () => {
    let component: AlFileSetupComponent;
    let fixture: ComponentFixture<AlFileSetupComponent>;
    let toastService, alNotificationsService;
    let ngxPermission;

    beforeEach(async(() => {
        TestBed.overrideComponent(AlFileSetupComponent, {
            set: {
                providers: [
                    { provide: FileSetupService, useClass: MockDataService },
                    { provide: FileSetupRedirect, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlFileSetupComponent, AlSidebarComponent, AlSidebarComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: ConfirmationService, useClass: MockDataService },
                { provide: FileSetupService, useClass: MockDataService },
                { provide: FileSetupRedirect, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService },
                { provide: ActivatedRoute, useValue: { params: Observable.of({ id: 1, version: 1 }) } }
            ]
        });



        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlFileSetupComponent);
            ngxPermission = TestBed.get(NgxPermissionsService);
            ngxPermission.addPermission("File Setup-Add New file");
            component = fixture.debugElement.componentInstance;
            fixture.detectChanges();
        });

        toastService = TestBed.get(ToastsManager);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AlFileSetupComponent);
        component = fixture.componentInstance;
    });


    it("should create", async(() => {
        expect(component).toBeTruthy();
    }));

    it("should be logging user", async(() => {
        component.ngOnInit();
        fixture.detectChanges();
    }));

    it("should goToFileSetup(), tabLoader()", () => {
        component.goToFileSetup();
        component.tabLoader("true");
    });

    it("should updateDateAndUpdateBy(), activeNextTab(), lookUpNext()", () => {
        let event = {
            "updatedDateTime": 1,
            "updatedBy": 2,
            "metaInfo": {
                "fileTradingPartnerLobAssoc": [
                    {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileTradingPartnerLobAssocId": 4500,
                        "tradingPartnerInfo": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "tradingPartnerId": 337,
                            "tradingPartnerDescription": null,
                            "tradingPartnerName": "123Kamal",
                            "tradingPartnerType": null,
                            "active": false,
                            "lastUpdatedDateTime": null,
                            "uniqueIdentifier": null
                        },
                        "lob": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "lobId": 13,
                            "lobDescription": null,
                            "uniqueIdentifier": null,
                            "lastUpdatedDateTime": null,
                            "size": 0,
                            "lobName": "Drexel Universityqqq",
                            "active": null
                        }
                    }
                ],
                "fileTypeMetaInfo": {
                    "direction": "Inbound"
                }
            },
            "action": "continue"
        };
        component.updateDateAndUpdateBy(event);
        component.activeNextTab(event);
        component.selFileType = "Inbound";
        component.lookUpNext();
        component.selFileType = "Outbound";
        component.lookUpNext();
        component.metaInfo = {
            "fileTypeMetaInfo": {
                "direction": "Outbound"
            }
        };

        component.transmissionNext();
        component.metaInfo = {
            "fileTypeMetaInfo": {
                "direction": "Inbound"
            }
        };
        component.transmissionNext();
        let event2 = {
            "updatedDateTime": 1,
            "updatedBy": 2,
            "metaInfo": {
                "fileTradingPartnerLobAssoc": [
                    {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileTradingPartnerLobAssocId": 4500,
                        "tradingPartnerInfo": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "tradingPartnerId": 337,
                            "tradingPartnerDescription": null,
                            "tradingPartnerName": "123Kamal",
                            "tradingPartnerType": null,
                            "active": false,
                            "lastUpdatedDateTime": null,
                            "uniqueIdentifier": null
                        },
                        "lob": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "lobId": 13,
                            "lobDescription": null,
                            "uniqueIdentifier": null,
                            "lastUpdatedDateTime": null,
                            "size": 0,
                            "lobName": "Drexel Universityqqq",
                            "active": null
                        }
                    }
                ],
                "fileTypeMetaInfo": {
                    "direction": "Outbound"
                }
            },
            "action": "continue"
        };
        component.metaInfo = {
            "fileTypeMetaInfo": {
                "direction": "Outbound"
            }
        };
        component.activeNextTab(event2);
    });

    it("should be logging user", async(() => {
        component.viewOnly = false;
        fixture.detectChanges();
        component.ngOnInit();
    }));
});


class MockDataService {
    editFiles(): Observable<any> {
        let response;
        response = require("../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/editFilesData.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }

    success() {
        return true;
    }
    changeRoute() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
