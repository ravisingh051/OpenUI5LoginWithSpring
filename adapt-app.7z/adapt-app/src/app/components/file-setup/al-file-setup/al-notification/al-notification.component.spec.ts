import { async, ComponentFixture, TestBed } from "@angular/core/testing";


// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { FormsModule, NgForm } from "@angular/forms";
import { By } from "@angular/platform-browser";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";


// COMPONENT
// =========================
import { AlNotificationComponent } from "./al-notification.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";


// SERVICE
// =========================
import { AlNotificationService } from "./al-notification-service/al-notification-service";
import { HttpClientTestingModule } from "@angular/common/http/testing";


const routes: Routes = [];

describe("AlNotificationComponent", () => {
    let component: AlNotificationComponent;
    let fixture: ComponentFixture<AlNotificationComponent>;
    let toastService, alNotificationsService;

    beforeEach(async(() => {
        TestBed.overrideComponent(AlNotificationComponent, {
            set: {
                providers: [
                    { provide: AlNotificationService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });

        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlNotificationComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: ConfirmationService, useClass: MockDataService },
                { provide: AlNotificationService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService },

            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlNotificationComponent);
            component = fixture.debugElement.componentInstance;
            component.recipientList = [
                {
                    "typeId": 3,
                    "fileAnalyst": true,
                    "email": "kamal.chhabra.2@alight.com",
                    "checked": true
                },
                {
                    "typeId": 4,
                    "teamId": 15,
                    "email": "adapt_qa@yahoo.com",
                    "checked": true
                }
            ];
            component.idisTeamFileAssociation = [
                {
                    "createdBy": null,
                    "createdDateTime": null,
                    "idisTeamFileAssociationId": 3323,
                    "idisTeam": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "idisTeamId": 15,
                        "idisTeamName": "CBA Implementation Team",
                        "idisTeamDescription": null,
                        "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                    }
                }
            ];
            component.ntfcData = [
                {
                    "templateName": "Inbound file received notification",
                    "templateId": 112,
                    "always": false,
                    "eventName": "Inbound File Received",
                    "timeToWait": null,
                    "recipients": [
                        {
                            "email": "XYZ@alight.com",
                            "typeId": 1,
                            "fileAnalyst": false,
                            "teamId": null,
                            "contactId": 303
                        },
                        {
                            "email": null,
                            "typeId": 3,
                            "fileAnalyst": true,
                            "teamId": null,
                            "contactId": null
                        },
                        {
                            "email": null,
                            "typeId": 4,
                            "fileAnalyst": false,
                            "teamId": 3,
                            "contactId": null
                        }
                    ]
                },
                {
                    "templateName": "Template - Maximum Records Exceed Occurred",
                    "templateId": 86,
                    "always": false,
                    "eventName": "Maximum Records Exceed Occurred",
                    "timeToWait": null,
                    "recipients": []
                },
                {
                    "templateName": "Notification template for minimum number of records succeeded",
                    "templateId": 98,
                    "always": false,
                    "eventName": "Minimum Records Subceed Occurred",
                    "timeToWait": null,
                    "recipients": [
                        {
                            "email": null,
                            "typeId": 3,
                            "fileAnalyst": true,
                            "teamId": null,
                            "contactId": null
                        },
                        {
                            "email": null,
                            "typeId": 4,
                            "fileAnalyst": false,
                            "teamId": 3,
                            "contactId": null
                        },
                        {
                            "email": null,
                            "typeId": 4,
                            "fileAnalyst": false,
                            "teamId": 19,
                            "contactId": null
                        },
                        {
                            "email": null,
                            "typeId": 4,
                            "fileAnalyst": false,
                            "teamId": 4,
                            "contactId": null
                        }
                    ]
                },
                {
                    "templateName": "test notification12321",
                    "templateId": 131,
                    "always": false,
                    "eventName": "Threshold Occurred",
                    "timeToWait": "14:26:00.0000000",
                    "recipients": []
                }
            ];
            component.tradingPartnerPlatform = {
                "tradingPartnerPlatformId": null
            };
            fixture.detectChanges();
        });
        toastService = TestBed.get(ToastsManager);
    }));
    it("should create", async(() => {
        expect(component).toBeTruthy();
    }));

    it("should call showRecipients()", () => {
        component.showRecipients();
        component.addRecipients();
        component.addToRCTable();
        component.ntfcData = [
            {
                "templateName": "Inbound file received notification",
                "templateId": 112,
                "always": false,
                "checked": true,
                "eventName": "Inbound File Received",
                "timeToWait": null,
                "recipients": [
                    {
                        "email": "XYZ@alight.com",
                        "typeId": 1,
                        "fileAnalyst": false,
                        "teamId": null,
                        "contactId": 303
                    },
                    {
                        "email": null,
                        "typeId": 3,
                        "fileAnalyst": true,
                        "teamId": null,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 3,
                        "contactId": null
                    }
                ]
            },
            {
                "templateName": "Template - Maximum Records Exceed Occurred",
                "templateId": 86,
                "always": false,
                "eventName": "Maximum Records Exceed Occurred",
                "timeToWait": null,
                "recipients": []
            },
            {
                "templateName": "Notification template for minimum number of records succeeded",
                "templateId": 98,
                "always": false,
                "eventName": "Minimum Records Subceed Occurred",
                "timeToWait": null,
                "recipients": [
                    {
                        "email": null,
                        "typeId": 3,
                        "fileAnalyst": true,
                        "teamId": null,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 3,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 19,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 4,
                        "contactId": null
                    }
                ]
            },
            {
                "templateName": "test notification12321",
                "templateId": 131,
                "always": false,
                "eventName": "Threshold Occurred",
                "timeToWait": "14:26:00.0000000",
                "recipients": []
            }
        ];
        component.addRcTableData = [
            {
                "contactId": 20,
                "firstName": "qa2",
                "lastName": "qa1",
                "email": "user@aug06.com",
                "phone": null,
                "title": null,
                "tradingPartner": "Test TP July25,Test TP July19,CC-35455-MD",
                "tradingPartnerPlatform": "Test Platform July19,Test Platform,CC-35455-MD",
                "label": "qa2 qa1",
                "value": 20,
                "typeId": 1,
                "checked": true
            }
        ];
        component.addRecDataFn();
    });

    it("should call addRecipients(), saveNotification()", () => {
        component.ntfcData = [
            {
                "templateName": "Inbound file received notification",
                "templateId": 112,
                "always": false,
                "checked": true,
                "eventName": "Inbound File Received",
                "timeToWait": null,
                "recipients": [
                    {
                        "email": "XYZ@alight.com",
                        "typeId": 1,
                        "fileAnalyst": false,
                        "teamId": null,
                        "contactId": 303
                    },
                    {
                        "email": null,
                        "typeId": 3,
                        "fileAnalyst": true,
                        "teamId": null,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 3,
                        "contactId": null
                    }
                ]
            },
            {
                "templateName": "Template - Maximum Records Exceed Occurred",
                "templateId": 86,
                "always": false,
                "eventName": "Maximum Records Exceed Occurred",
                "timeToWait": null,
                "recipients": []
            },
            {
                "templateName": "Notification template for minimum number of records succeeded",
                "templateId": 98,
                "always": false,
                "eventName": "Minimum Records Subceed Occurred",
                "timeToWait": null,
                "recipients": [
                    {
                        "email": null,
                        "typeId": 3,
                        "fileAnalyst": true,
                        "teamId": null,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 3,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 19,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 4,
                        "contactId": null
                    }
                ]
            },
            {
                "templateName": "test notification12321",
                "templateId": 131,
                "always": false,
                "eventName": "Threshold Occurred",
                "timeToWait": "14:26:00.0000000",
                "recipients": []
            }
        ];
        component.addRecipients();
        let notificationForm = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                email: "",
                firstName: ""
            }
        };
        component.recipientList = [
            {
                "typeId": 3,
                "fileAnalyst": true,
                "email": "kamal.chhabra.2@alight.com",
                "checked": true
            },
            {
                "typeId": 4,
                "teamId": 15,
                "email": "adapt_qa@yahoo.com",
                "checked": true
            }
        ];
        component.btnAction = "save";
        component.showTemplates();
        component.saveNotification(notificationForm);

        component.btnAction = "continue";
        component.saveNotification(notificationForm);

        let saveObj = [{
            "templateId": 1,
            "contactTypeId": 1,
            "contactId": 1,
            "fileIdentifier": 1,
            "fileTypeId": 1,
            "active": true,
            "teamId": 1,
            "fileAnalyst": "Dharam Mali",
        }];
        component.updateTplRec(saveObj);

    });

    it("should call nextBtnFn(), btnCancel()", () => {
        component.nextBtnFn();
        component.btnCancel();
        component.validatTemplate();
    });

    it("should and displayToolTipText()", () => {
        component.toolTipFileNotification = {
            "Test": {
                "tooltipDesc": "Test Email Address description",
                "readMoreLink": "http://www.google.com"
            }
        };
        fixture.detectChanges();
        let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));
        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "Test", "bottom");
            component.hideToolTipText(event);
        });
        btnNextStep.click();
    });

    it("should and addToRCTable() Else Part", () => {
        component.addRcTableData = [];
        component.addToRCTable();
        component.selRcDropdown = null;
        component.addToRCTable();
    });

    it("should and updateRCList()", () => {
        component.intCntcList = [];
        component.extCntcList = [];
        component.updateRCList(1);
        component.updateRCList(0);
    });

    it("should and showRecipients()", () => {
        component.ntfcData = [
            {
                "templateName": "Inbound file received notification",
                "templateId": 112,
                "always": false,
                "checked": true,
                "eventName": "Inbound File Received",
                "timeToWait": null,
                "recipients": [
                    {
                        "email": "XYZ@alight.com",
                        "typeId": 1,
                        "fileAnalyst": false,
                        "teamId": null,
                        "contactId": 303
                    },
                    {
                        "email": null,
                        "typeId": 3,
                        "fileAnalyst": true,
                        "teamId": null,
                        "contactId": null
                    },
                    {
                        "email": null,
                        "typeId": 4,
                        "fileAnalyst": false,
                        "teamId": 3,
                        "contactId": null
                    }
                ]
            }
        ];

        component.showRecipients();

    });



});


class MockDataService {

    // AlNotificationService methods
    // =============================
    getTemplates(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getTemplates.json");
        return (Observable.of(response));
    }

    TradingPartnerContactType(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getContacts_1.json");
        return (Observable.of(response));
    }

    getContacts(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getContacts_2.json");
        return (Observable.of(response));
    }

    // toolTipUtils methods
    // =============================

    getPageAndFieldsDetails(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getToolTipTextDetails.json");
        return (Observable.of(response));
    }

    addRecToTpl(): Observable<any> {
        let response = {
            "error": false,
            "data": {
                "result": [
                    {
                        "templateName": "Notification template for minimum number of records succeeded",
                        "templateId": 98,
                        "always": false,
                        "eventName": "Minimum Records Subceed Occurred",
                        "timeToWait": null,
                        "recipients": []
                    },
                    {
                        "templateName": "Notification template for threshold occurred",
                        "templateId": 103,
                        "always": false,
                        "eventName": "Threshold Occurred",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            }
                        ]
                    },
                    {
                        "templateName": "Job removed for Census",
                        "templateId": 189,
                        "always": false,
                        "eventName": "Job Removed",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            }
                        ]
                    },
                    {
                        "templateName": "Inbound file received for census",
                        "templateId": 175,
                        "always": false,
                        "eventName": "Inbound File Received",
                        "timeToWait": null,
                        "recipients": []
                    },
                    {
                        "templateName": "Test name41 V2",
                        "templateId": 12,
                        "always": false,
                        "eventName": "Inbound File Received",
                        "timeToWait": null,
                        "recipients": []
                    },
                    {
                        "templateName": "Maximum Records Exceed notification",
                        "templateId": 162,
                        "always": true,
                        "eventName": "Maximum Records Exceed Occurred",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            }
                        ]
                    }
                ],
                "fileMetaInfo": {
                    "createdBy": "Jay Avatani",
                    "createdDateTime": "14/11/2018 13:31:23.800 GMT",
                    "updatedBy": "Dharam Mali",
                    "updatedDateTime": "03/22/19 08:52 CT",
                    "recordId": 866,
                    "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//CC-35455-MD/null/Test LOB test1/24",
                    "fileName": "CC-35455-MD",
                    "fileProcessingErrorThresholdCount": 10,
                    "fileStatus": "Active",
                    "fileTransmissionName": "CC-35455.csv",
                    "fileVersion": 2,
                    "oldFileId": null,
                    "isActive": false,
                    "tradingPartnerName": null,
                    "lobName": null,
                    "employerName": null,
                    "employerIds": [
                        25
                    ],
                    "fileAssociatedWebsite": null,
                    "isMultiEmployer": false,
                    "fileIdGenerator": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "fileId": 24
                    },
                    "fileTypeMetaInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileTypeId": 1,
                        "direction": "Inbound",
                        "fileTypeName": "Inbound Census",
                        "cloneAllowed": false
                    },
                    "masterFileTemplateRecordId": 1,
                    "masterFileTemplateMetaInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "masterFileTemplateRecordId": 1,
                        "masterFileTemplateId": 1,
                        "masterFileTemplateDescription": null,
                        "masterFileTemplateName": "Inbound Census Master",
                        "masterFileTemplateVersion": 1,
                        "approvalStatusUpdatedBy": null,
                        "approvalStatusComment": null,
                        "approvalStatusUpdatedDate": null,
                        "approvalStatus": null,
                        "editedBy": null,
                        "editorComment": null,
                        "fileTypeMetaInfo": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileTypeId": 1,
                            "direction": "Inbound",
                            "fileTypeName": "Inbound Census",
                            "cloneAllowed": false
                        },
                        "currentApprovalStatus": null,
                        "active": false
                    },
                    "fileFormatSupported": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileFormatSupportedId": 471,
                        "fileFooterLineCount": null,
                        "fileFormatEscapeChar": null,
                        "fileFormatFieldDelimiter": "|",
                        "fileFormatName": "DELIMITED",
                        "fileFormatRowDelimiter": "EOL",
                        "fileFormatSegmentDelimiter": null,
                        "fileHasFooter": true,
                        "fileHasHeader": true,
                        "fileHeaderLineCount": null,
                        "fileLinesSkipCount": null
                    },
                    "appendFileRunDate": false,
                    "approvalStatusUpdatedBy": null,
                    "approvalStatusComment": null,
                    "approvalStatusUpdatedDate": null,
                    "approvalStatus": 1,
                    "editedBy": null,
                    "editorComment": null,
                    "currentApprovalStatus": 1,
                    "tradingPartnerPlatformInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "tradingPartnerPlatformId": 13,
                        "tradingPartnerPlatformName": "CC-35455-MD",
                        "tradingPartnerPlatformDesc": "CC-35455",
                        "tradingPartnerInfo": null,
                        "lastUpdatedDateTime": null,
                        "uniqueIdentifier": null,
                        "active": false
                    },
                    "fileMinRecordCountAllowed": 0,
                    "fileMaxRecordCountAllowed": null,
                    "fileProcessingErrorThresholdFormat": "No Threshold",
                    "analystEmail": null,
                    "analystName": null,
                    "slaMapped": false,
                    "dataSourceTypeId": 1,
                    "dataTargetTypeId": 2,
                    "fileEmployerAssoc": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileEmployerAssocId": 1268,
                            "clientEmployerAssocId": 5
                        }
                    ],
                    "idisTeamFileAssociation": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1544,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 3,
                                "idisTeamName": "Blue",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        },
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1545,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 4,
                                "idisTeamName": "Green",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        },
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1546,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 19,
                                "idisTeamName": "Chocolate",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        }
                    ],
                    "fileTradingPartnerLobAssoc": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileTradingPartnerLobAssocId": 1331,
                            "tradingPartnerInfo": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "tradingPartnerId": 6,
                                "tradingPartnerDescription": null,
                                "tradingPartnerEmployerId": null,
                                "tradingPartnerIsConsenting": null,
                                "tradingPartnerName": "CC-35455-MD",
                                "tradingPartnerType": null,
                                "active": false,
                                "lastUpdatedDateTime": null,
                                "uniqueIdentifier": null
                            },
                            "lob": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "lobId": 4,
                                "lobDescription": null,
                                "uniqueIdentifier": null,
                                "lastUpdatedDateTime": null,
                                "size": 0,
                                "lobName": "Test LOB test1,",
                                "active": null
                            }
                        }
                    ]
                }
            }
        };
        return (Observable.of(response));
    }
    createRecToTpl(): Observable<any> {
        let response = {
            "error": false,
            "data": {
                "result": [
                    {
                        "templateName": "Notification template for minimum number of records succeeded",
                        "templateId": 98,
                        "always": false,
                        "eventName": "Minimum Records Subceed Occurred",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": "user@aug06.com",
                                "fileAnalyst": false,
                                "teamId": null,
                                "contactId": 20,
                                "typeId": 1
                            }
                        ]
                    },
                    {
                        "templateName": "Notification template for threshold occurred",
                        "templateId": 103,
                        "always": false,
                        "eventName": "Threshold Occurred",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": "user@aug06.com",
                                "fileAnalyst": false,
                                "teamId": null,
                                "contactId": 20,
                                "typeId": 1
                            },
                            {
                                "email": "user@aug06.com",
                                "fileAnalyst": false,
                                "teamId": null,
                                "contactId": 20,
                                "typeId": 1
                            }
                        ]
                    },
                    {
                        "templateName": "Job removed for Census",
                        "templateId": 189,
                        "always": false,
                        "eventName": "Job Removed",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": "user@aug06.com",
                                "fileAnalyst": false,
                                "teamId": null,
                                "contactId": 20,
                                "typeId": 1
                            }
                        ]
                    },
                    {
                        "templateName": "Inbound file received for census",
                        "templateId": 175,
                        "always": false,
                        "eventName": "Inbound File Received",
                        "timeToWait": null,
                        "recipients": []
                    },
                    {
                        "templateName": "Test name41 V2",
                        "templateId": 12,
                        "always": false,
                        "eventName": "Inbound File Received",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": "user@aug06.com",
                                "fileAnalyst": false,
                                "teamId": null,
                                "contactId": 20,
                                "typeId": 1
                            }
                        ]
                    },
                    {
                        "templateName": "Maximum Records Exceed notification",
                        "templateId": 162,
                        "always": true,
                        "eventName": "Maximum Records Exceed Occurred",
                        "timeToWait": null,
                        "recipients": [
                            {
                                "email": null,
                                "fileAnalyst": true,
                                "teamId": null,
                                "contactId": null,
                                "typeId": 3
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 3,
                                "contactId": null,
                                "typeId": 4
                            },
                            {
                                "email": null,
                                "fileAnalyst": false,
                                "teamId": 4,
                                "contactId": null,
                                "typeId": 4
                            }
                        ]
                    }
                ],
                "fileMetaInfo": {
                    "createdBy": "Jay Avatani",
                    "createdDateTime": "14/11/2018 13:31:23.800 GMT",
                    "updatedBy": "Dharam Mali",
                    "updatedDateTime": "03/22/19 10:11 CT",
                    "recordId": 866,
                    "archivalLocation": "/apps/Benefits/iDIS/qa/webApp/archive//CC-35455-MD/null/Test LOB test1/24",
                    "fileName": "CC-35455-MD",
                    "fileProcessingErrorThresholdCount": 10,
                    "fileStatus": "Active",
                    "fileTransmissionName": "CC-35455.csv",
                    "fileVersion": 2,
                    "oldFileId": null,
                    "isActive": false,
                    "tradingPartnerName": null,
                    "lobName": null,
                    "employerName": null,
                    "employerIds": [
                        25
                    ],
                    "fileAssociatedWebsite": null,
                    "isMultiEmployer": false,
                    "fileIdGenerator": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "fileId": 24
                    },
                    "fileTypeMetaInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileTypeId": 1,
                        "direction": "Inbound",
                        "fileTypeName": "Inbound Census",
                        "cloneAllowed": false
                    },
                    "masterFileTemplateRecordId": 1,
                    "masterFileTemplateMetaInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "masterFileTemplateRecordId": 1,
                        "masterFileTemplateId": 1,
                        "masterFileTemplateDescription": null,
                        "masterFileTemplateName": "Inbound Census Master",
                        "masterFileTemplateVersion": 1,
                        "approvalStatusUpdatedBy": null,
                        "approvalStatusComment": null,
                        "approvalStatusUpdatedDate": null,
                        "approvalStatus": null,
                        "editedBy": null,
                        "editorComment": null,
                        "fileTypeMetaInfo": {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileTypeId": 1,
                            "direction": "Inbound",
                            "fileTypeName": "Inbound Census",
                            "cloneAllowed": false
                        },
                        "currentApprovalStatus": null,
                        "active": false
                    },
                    "fileFormatSupported": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "fileFormatSupportedId": 471,
                        "fileFooterLineCount": null,
                        "fileFormatEscapeChar": null,
                        "fileFormatFieldDelimiter": "|",
                        "fileFormatName": "DELIMITED",
                        "fileFormatRowDelimiter": "EOL",
                        "fileFormatSegmentDelimiter": null,
                        "fileHasFooter": true,
                        "fileHasHeader": true,
                        "fileHeaderLineCount": null,
                        "fileLinesSkipCount": null
                    },
                    "appendFileRunDate": false,
                    "approvalStatusUpdatedBy": null,
                    "approvalStatusComment": null,
                    "approvalStatusUpdatedDate": null,
                    "approvalStatus": 1,
                    "editedBy": null,
                    "editorComment": null,
                    "currentApprovalStatus": 1,
                    "tradingPartnerPlatformInfo": {
                        "createdBy": null,
                        "createdDateTime": null,
                        "updatedBy": null,
                        "updatedDateTime": null,
                        "tradingPartnerPlatformId": 13,
                        "tradingPartnerPlatformName": "CC-35455-MD",
                        "tradingPartnerPlatformDesc": "CC-35455",
                        "tradingPartnerInfo": null,
                        "lastUpdatedDateTime": null,
                        "uniqueIdentifier": null,
                        "active": false
                    },
                    "fileMinRecordCountAllowed": 0,
                    "fileMaxRecordCountAllowed": null,
                    "fileProcessingErrorThresholdFormat": "No Threshold",
                    "analystEmail": null,
                    "analystName": null,
                    "slaMapped": false,
                    "dataSourceTypeId": 1,
                    "dataTargetTypeId": 2,
                    "fileEmployerAssoc": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileEmployerAssocId": 1268,
                            "clientEmployerAssocId": 5
                        }
                    ],
                    "idisTeamFileAssociation": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1544,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 3,
                                "idisTeamName": "Blue",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        },
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1545,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 4,
                                "idisTeamName": "Green",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        },
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "idisTeamFileAssociationId": 1546,
                            "idisTeam": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "idisTeamId": 19,
                                "idisTeamName": "Chocolate",
                                "idisTeamDescription": null,
                                "idisTeamCommonEmailId": "adapt_qa@yahoo.com"
                            }
                        }
                    ],
                    "fileTradingPartnerLobAssoc": [
                        {
                            "createdBy": null,
                            "createdDateTime": null,
                            "updatedBy": null,
                            "updatedDateTime": null,
                            "fileTradingPartnerLobAssocId": 1331,
                            "tradingPartnerInfo": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "tradingPartnerId": 6,
                                "tradingPartnerDescription": null,
                                "tradingPartnerEmployerId": null,
                                "tradingPartnerIsConsenting": null,
                                "tradingPartnerName": "CC-35455-MD",
                                "tradingPartnerType": null,
                                "active": false,
                                "lastUpdatedDateTime": null,
                                "uniqueIdentifier": null
                            },
                            "lob": {
                                "createdBy": null,
                                "createdDateTime": null,
                                "updatedBy": null,
                                "updatedDateTime": null,
                                "lobId": 4,
                                "lobDescription": null,
                                "uniqueIdentifier": null,
                                "lastUpdatedDateTime": null,
                                "size": 0,
                                "lobName": "Test LOB test1,",
                                "active": null
                            }
                        }
                    ]
                }
            }
        };
        return (Observable.of(response));
    }

    error() {
        return false;
    }

    success() {
        return true;
    }

    changeRoute() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
