import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../../env.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlNotificationService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/fileNotificationContactAssoc/";
  defaultHeaders: HttpHeaders = new HttpHeaders({ "Content-Type": "application/json" });

  // Get Templates
  /*
    getTemplates(fileTypeId,fileId,version) {
    return this.http.get(this.serviceMappingURL + 'getByFile?fileTypeId='+fileTypeId+'&fileId='+fileId+'&fileVersion='+version)
      .map(res => res.json());
  }
    */

  getTemplates(fileTypeId, recordId): Observable<any> {
    return this.http.get(this.serviceMappingURL + "getByFile?fileTypeId=" + fileTypeId + "&fileIdentifier=" + recordId);
  }

  // Get Contact Type
  TradingPartnerContactType(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/TradingPartnerContactType/details");
  }

  // Get Contact
  getContacts(fileId, fileVersion, contactType, byPlatform): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/TradingPartnerContact/getByType?fileId=" + fileId + "&fileVersion=" + fileVersion + "&contactType=" + contactType + "&byPlatform=" + byPlatform);
  }

  // Add Contact To Template
  addRecToTpl(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "update", data)
      .map(extractData).catch(handleError);
  }

  // create contact
  createRecToTpl(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "create", data)
      .map(extractData).catch(handleError);
  }

}
