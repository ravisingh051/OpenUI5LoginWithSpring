import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastsManager } from "ng2-toastr";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { AlNotificationService } from "./al-notification-service/al-notification-service";
import { ConfirmationService } from "primeng/components/common/api";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../../global";

@Component({
    selector: "al-notification",
    templateUrl: "./al-notification.component.html",
    styleUrls: ["./al-notification.component.scss"],
    providers: [AlNotificationService, ConfirmationService]
})

export class AlNotificationComponent implements OnInit {
    @Input() fileId: number;
    @Input() fileTypeId: number;
    @Input() recordId: number;
    @Input() fileVersion: number;
    @Input() fileApprovalStatus: number;
    @Input() fileDirection: string;
    @Output() pageNavigation = new EventEmitter();
    @Input() viewOnly: boolean;
    @Input() idisTeamFileAssociation;
    @Input() analystEmail: string;
    @Input() analystName: string;
    @Input() tradingPartnerPlatform: any;

    nfgcFormObj: any = {};
    TradingPartnerContactType: any;
    btnAction: string;

    ntfcData: any = [];
    ntfcDataOld: any = [];

    /* ToolTip Text display */
    toolTipFileNotification: any = [];
    tooltipResult: any;
    pageID: number = 19;
    @Output() updateDateAndUpdateBy = new EventEmitter;
    @Output("tabLoader") tabLoader = new EventEmitter();
    constructor(
        public toastr: ToastsManager,
        private router: Router,
        private ntfService: AlNotificationService,
        private confirmationService: ConfirmationService,
        private toolTipUtils: ToolTipUtilService
    ) { }
    ngOnInit() {
        if (this.tradingPartnerPlatform && this.tradingPartnerPlatform["tradingPartnerPlatformId"] !== null && this.tradingPartnerPlatform["tradingPartnerPlatformId"] === undefined) {
            this.tradingPartnerPlatform = null;
        }
        this.ntfService.getTemplates(this.fileTypeId, this.recordId).subscribe(res => {
            this.ntfcData = res.data;
            this.ntfcDataOld = res.data;
            for (let _data of this.ntfcData) {
                if (_data.timeToWait !== null) {
                    let _time = _data.timeToWait.split(":");
                    _data.timeToWait = _time[0] + ":" + _time[1];
                }
            }
            this.prepareRecipientList();
        });
        this.ntfService.TradingPartnerContactType().subscribe(res => {
            this.TradingPartnerContactType = res.data;
        });
        this.populatecontact();
        this.getToolTipTextDetails();
    }

    // Save Notification Template Form
    saveNotification(notificationForm: NgForm) {
        let _selTpl = this.ntfcData.filter((tpl) => tpl.checked === true);
        /* if (_selTpl.length <= 0) {
             this.toastr.error("Please select Template.", "Oops!");
             return false;
         } */
        let _selRec = this.recipientList.filter((rec) => rec.checked === true);
        if (_selRec.length <= 0) {
            this.toastr.error("Please select Recipient.", "Oops!", TOAST_SETTING);
            return false;
        }

        let editMode = false;
        let saveObj = [];

        if (_selTpl.length <= 0) {
            outerLabel:
            for (let tP of this.ntfcDataOld) {
                for (let rC of _selRec) {
                    if (rC.contactId !== undefined && rC.contactId !== null) {
                        let check = tP.recipients.filter((t) => t.contactId === rC.contactId);
                        if (check.length > 0) {
                            editMode = true;
                            break outerLabel;
                        }
                    } else if (rC.teamId !== undefined && rC.teamId !== null) {
                        let check = tP.recipients.filter((t) => t.teamId === rC.teamId);
                        if (check.length > 0) {
                            editMode = true;
                            break outerLabel;
                        }
                    } else if (rC.fileAnalyst !== undefined && rC.fileAnalyst === true) {
                        let check = tP.recipients.filter((t) => t.fileAnalyst === rC.fileAnalyst);
                        if (check.length > 0) {
                            editMode = true;
                            break outerLabel;
                        }
                    }
                }
            }

            if (!editMode) {
                this.toastr.error("Please select Template.", "Oops!", TOAST_SETTING);
                return false;
            } else {
                for (let rec of _selRec) {
                    saveObj.push({
                        "templateId": null,
                        "contactTypeId": rec.typeId,
                        "contactId": rec.contactId === undefined ? null : rec.contactId,
                        //           "fileId": this.fileId,
                        //           "fileVersion": this.fileVersion,
                        "fileIdentifier": this.recordId,
                        "fileTypeId": this.fileTypeId,
                        "active": true,
                        "teamId": rec.teamId === undefined ? null : rec.teamId,
                        "fileAnalyst": rec.fileAnalyst,
                    });
                }
            }
        }

        if (!editMode) {
            for (let rec of _selRec) {
                for (let tpl of _selTpl) {
                    saveObj.push({
                        "templateId": tpl.templateId,
                        "contactTypeId": rec.typeId,
                        "contactId": rec.contactId === undefined ? null : rec.contactId,
                        //           "fileId": this.fileId,
                        //           "fileVersion": this.fileVersion,
                        "fileIdentifier": this.recordId,
                        "fileTypeId": this.fileTypeId,
                        "active": true,
                        "teamId": rec.teamId === undefined ? null : rec.teamId,
                        "fileAnalyst": rec.fileAnalyst,
                    });

                }
            }
        }
        this.updateTplRec(saveObj);
    }

    // Go to Next Tab
    nextBtnFn() {
        this.pageNavigation.emit();
    }

    // Redirect for File Setup Listing page
    btnCancel() {
        this.router.navigate(["/file-setup"]);
    }

    // Prepare Contact List
    recipientList: any;
    prepareRecipientList() {
        this.recipientList = [];
        this.recipientList.push({
            "typeId": 3,
            "fileAnalyst": true,
            "email": this.analystEmail
        });
        /*for (let _team of this.idisTeamFileAssociation) {
            this.recipientList = [...this.recipientList, {
                "typeId": 4,
                "teamId": _team.idisTeam.idisTeamId,
                "email": _team.idisTeam.idisTeamCommonEmailId
            }];
        }*/
        for (let _recipent of this.ntfcData) {
            if (_recipent.recipients.length > 0) {
                for (let _rec of _recipent.recipients) {
                    let _checkRc = this.recipientList.filter((obj) => obj.typeId !== 3 && obj.contactId === _rec.contactId);
                    if (_checkRc.length === 0 && _rec.typeId !== 3) {
                        this.recipientList.push(_rec);
                    }
                }
            }
        }
        this.tabLoader.emit(false);
    }

    // Show recipient for selected template
    selRecipientsId: any = [];
    selTplLength: number;
    showRecipients() {
        this.selRecipientsId = [];
        this.selTplLength = 0;
        for (let _recipent of this.ntfcData) {
            if (_recipent["checked"] === true) {
                for (let _rec of _recipent.recipients) {
                    if (_rec.contactId !== null) {
                        this.selRecipientsId.push(_rec.contactId);
                    } else if (_rec.teamId !== null) {
                        this.selRecipientsId.push(_rec.teamId);
                    } else if (_rec.fileAnalyst === true) {
                        this.selRecipientsId.push(_rec.fileAnalyst);
                    }
                }
                this.selTplLength++;
            }
        }
        if (this.selTplLength === 0) {
            this.toastr.error("No Template Selected", "Oops!", TOAST_SETTING);
            return false;
        }
        for (let recp of this.recipientList) {
            if (recp.contactId) {
                let _check = this.selRecipientsId.filter((obj) => obj === recp.contactId);
                if (_check.length === this.selTplLength) {
                    recp.checked = true;
                }
                else {
                    recp.checked = false;
                }
            }
            else if (recp.teamId) {
                let _check = this.selRecipientsId.filter((obj) => obj === recp.teamId);
                if (_check.length === this.selTplLength) {
                    recp.checked = true;
                }
                else {
                    recp.checked = false;
                }
            }
            else if (recp.fileAnalyst) {
                let _check = this.selRecipientsId.filter((obj) => obj === recp.fileAnalyst);
                if (_check.length === this.selTplLength) {
                    recp.checked = true;
                }
                else {
                    recp.checked = false;
                }
            }
        }
    }

    // Add new recipient for selected template
    addRecDialog: boolean;
    addRecData: any = {};
    addRecList: any = [];
    selTpType: string;
    addRecipients() {
        this.selTpType = "1";
        let _selTpl = this.ntfcData.filter((obj) => obj["checked"] === true);
        if (_selTpl.length === 0) {
            this.toastr.error("Please select the template first to add recipient!", "Oops!", TOAST_SETTING);
            return false;
        }
        else {
            this.addRecDialog = true;
            this.addRecList = this.intCntcList;
            this.addRcTableData = [];
            this.selRcDropdown = null;
        }
    }

    // Show template for selected recipients
    showTemplates() {
        let _selRec = this.recipientList.filter((obj) => obj.checked === true);
        if (_selRec.length === 0) {
            this.toastr.error("No Recipient Selected", "Oops!", TOAST_SETTING);
            return false;
        }
        for (let tP of this.ntfcData) {
            let flag = true;
            for (let rC of _selRec) {
                if (rC.contactId !== undefined && rC.contactId !== null) {
                    let check = tP.recipients.filter((t) => t.contactId === rC.contactId);
                    if (check.length === 0) {
                        flag = false;
                    }
                } else if (rC.teamId !== undefined && rC.teamId !== null) {
                    let check = tP.recipients.filter((t) => t.teamId === rC.teamId);
                    if (check.length === 0) {
                        flag = false;
                    }
                } else if (rC.fileAnalyst !== undefined && rC.fileAnalyst === true) {
                    let check = tP.recipients.filter((t) => t.fileAnalyst === rC.fileAnalyst);
                    if (check.length === 0) {
                        flag = false;
                    }
                }
            }
            tP["checked"] = flag;
        }
    }


    // Recipient List Change
    updateRCList(recipient) {
        this.selRcDropdown = null;
        if (recipient === 1) {
            this.addRecList = this.intCntcList;
        }
        else {
            this.addRecList = this.extCntcList;
        }
    }

    // Populate Contact list
    intCntcList: any = [];
    extCntcList: any = [];

    populatecontact() {
        let byPlatform = this.tradingPartnerPlatform === null ? false : true;
        this.ntfService.getContacts(this.fileId, this.fileVersion, 1, byPlatform).subscribe(res => {
            for (let list of res.data) {
                list["label"] = list.firstName + " " + list.lastName;
                list["value"] = list.contactId;
                list["typeId"] = 1;
            }
            this.intCntcList = res.data;
            this.intCntcList.unshift({ "label": "Please Select", "value": null });
        });
        this.ntfService.getContacts(this.fileId, this.fileVersion, 2, byPlatform).subscribe(res => {
            for (let list of res.data) {
                list["label"] = list.firstName + " " + list.lastName;
                list["value"] = list.contactId;
                list["typeId"] = 2;
            }
            this.extCntcList = res.data;
            this.extCntcList.unshift({ "label": "Please Select", "value": null });
        });
    }

    addRcTableData: any = [];
    selRcDropdown: any;
    addToRCTable() {
        if (this.selRcDropdown === null) {
            this.toastr.error("Please select contact to add in the contact list", "Oops!", TOAST_SETTING);
            return false;
        }
        let _checkA = this.addRcTableData.filter((obj) => obj.value === this.selRcDropdown);
        if (_checkA.length > 0) {
            this.toastr.error("Contact is already available in contact list", "Oops!", TOAST_SETTING);
            return false;
        }
        let _addRc = this.addRecList.filter((obj) => obj.value === this.selRcDropdown);
        let _newRcTableData = this.addRcTableData.concat(_addRc[0]);
        this.addRcTableData = _newRcTableData;
    }

    // Save Recepient Data
    addRecDataFn() {
        let _selTpl = [];
        let _selRes = [];
        for (let _tpl of this.ntfcData) {
            if (_tpl["checked"] === true) {
                _selTpl.push(_tpl.templateId);
            }
        }
        if (this.addRcTableData.length === 0) {
            this.toastr.error("Please select contact.", "Oops!", TOAST_SETTING);
            return false;
        } else {
            _selRes = this.addRcTableData.filter((obj) => obj.checked === true);
            if (_selRes.length <= 0) {
                this.toastr.error("Please select contact.", "Oops!", TOAST_SETTING);
                return false;
            } else {
                let _flag = false;
                for (let _sR of _selRes) {
                    let checkExist = this.recipientList.filter((rec) => rec.contactId === _sR.contactId);
                    if (checkExist.length > 0) {
                        _flag = true;
                    }
                }
                if (_flag === true) {
                    this.toastr.error("Contact is aleady available recipients list.", "Oops!", TOAST_SETTING);
                    return false;
                }
            }
        }
        let saveRecData = [];
        for (let obj of this.addRcTableData) {
            if (obj.checked === true) {
                for (let tpl of _selTpl) {
                    saveRecData.push({
                        "templateId": tpl,
                        "contactTypeId": obj.typeId,
                        "contactId": obj.contactId,
                        //             "fileId": this.fileId,
                        //             "fileVersion": this.fileVersion,
                        "fileIdentifier": this.recordId,
                        "fileTypeId": this.fileTypeId,
                        "active": true,
                        "teamId": null,
                        "fileAnalyst": false
                    });
                }
            }
        }


        this.ntfService.createRecToTpl(saveRecData).subscribe(res => {
            if (!res.error) {
                this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
                this.toastr.success("Notification saved successfully!.", "Success");
                this.ntfcData = res.data.result;
                for (let _data of this.ntfcData) {
                    if (_data.timeToWait !== null) {
                        let _time = _data.timeToWait.split(":");
                        _data.timeToWait = _time[0] + ":" + _time[1];
                    }
                }
                this.prepareRecipientList();
                this.addRecDialog = false;
            } /* istanbul ignore next */ else {
                this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            }
        }, /* istanbul ignore next */ error => {
            this.toastr.error("Server Error in adding Recipients.", "Oops!", TOAST_SETTING);
        });
    }

    updateTplRec(data) {
        this.ntfService.addRecToTpl(data).subscribe(res => {
            if (!res.error) {
                this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
                this.ntfcData = res.data.result;
                this.ntfcDataOld = res.data.result;
                for (let _data of this.ntfcData) {
                    if (_data.timeToWait !== null) {
                        let _time = _data.timeToWait.split(":");
                        _data.timeToWait = _time[0] + ":" + _time[1];
                    }
                }
                this.prepareRecipientList();
                this.addRecDialog = false;
                if (this.btnAction === "save") {
                    this.toastr.success("Notification saved successfully!", "Success");
                }
                if (this.btnAction === "continue") {
                    this.validatTemplate();
                }
            } /* istanbul ignore next */ else {
                this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            }
        }, /* istanbul ignore next */ error => {
            this.toastr.error("Server Error in adding Recipients.", "Oops!", TOAST_SETTING);
        });
    }

    // "Check if "Always send Internal Notification", or "Always Send External Notification"
    // If system finds no recipients for those templates, then show error message
    validatTemplate() {
        let _returnFlag = false;
        for (let tp of this.ntfcData) {
            if (tp.always === true && tp.recipients.length === 0) {
                _returnFlag = true;
            }
        }
        if (_returnFlag === true) {
            this.toastr.error("Recipients are not associated to the required templates.", "Oops!", TOAST_SETTING);
        }
        else {
            this.toastr.success("Notification saved successfully!", "Success");
            this.pageNavigation.emit();
        }
    }

    getToolTipTextDetails() {
        this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
            this.toolTipFileNotification = res.data;
        });
    }

    @ViewChild("dynamicPopover") dynamicPopover;
    popOverContent: any = {};
    displayToolTipText(event, value, pos) {
        this.tooltipResult = this.toolTipFileNotification[value];
        if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
            this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
        } else {
            this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
        }
        this.dynamicPopover.position = pos;
        this.dynamicPopover.showPopOver(event);
    }
    hideToolTipText(event) {
        this.dynamicPopover.hidePopOver(event);
    }

}
