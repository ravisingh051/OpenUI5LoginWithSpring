import { TestBed, inject } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { AlNotificationService } from "./al-notification-service";
import { ApiEnvService } from "../../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";


describe("AlNotificationService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({

      providers: [
        AlNotificationService,
        ApiEnvService,
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },

      ],

      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([
        ]),
      ],
    });
  });

  it("should be created", inject([AlNotificationService], (service: AlNotificationService) => {
    expect(service).toBeTruthy();
    service.getTemplates(1, 1);
    service.TradingPartnerContactType();
    service.getContacts(1, 2, 3, 4);
    service.addRecToTpl(1);
    service.createRecToTpl(1);
  }));
});
