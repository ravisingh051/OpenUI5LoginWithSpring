import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { AlExtractionParametersService } from "../../al-file-setup-services/al-extraction-parameters.service";
import { ToastsManager } from "ng2-toastr";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-extraction-parameters",
  templateUrl: "./al-extraction-parameters.component.html",
  styleUrls: ["./al-extraction-parameters.component.scss"],
  providers: [AlExtractionParametersService]
})
export class AlExtractionParametersComponent implements OnInit {

  constructor(
    private extParameService: AlExtractionParametersService,
    public toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService
  ) { }


  @Input() metaInfo;
  @Input() viewOnly;
  @Output("tabLoader") tabLoader = new EventEmitter();
  @Output() updateDateAndUpdateBy = new EventEmitter;

  planSubtypeDetails: any = null;
  profileList: any = [{ "label": "Select One", "value": null }];
  profile: any = null;
  extractionProfileTooltip: any = [];
  tooltipResult: any;
  pageID: number = 31;

  ngOnInit() {
    this.tabLoader.emit(true);
    this.getPlanSubtypeDetails();
    this.getToolTipTextDetails();
  }


  getPlanSubtypeDetails() {
    this.extParameService.getSelectionCriteriaDatasetByRecordId(this.metaInfo.recordId).subscribe((res) => {
      if (!res.error) {
        this.planSubtypeDetails = res.data;
        this.getActivatedOutboundProfiles();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting activated Outbound Profiles.", "Oops!", TOAST_SETTING);
    });
  }
  getActivatedOutboundProfiles() {
    this.extParameService.getActivatedOutboundProfiles().subscribe((res) => {
      if (!res.error) {
        for (let _pro of res.data) {
          this.profileList.push({
            "label": _pro.profileName,
            "value": _pro
          });
        }
        this.tabLoader.emit(false);
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting activated Outbound Profiles.", "Oops!", TOAST_SETTING);
    });
  }

  profileData: any = [];
  profileLoader: boolean;
  onProfileChange() {
    this.profileLoader = true;
    if (this.profile !== null) {
      this.extParameService.getProfileData(this.metaInfo.recordId, this.profile.profileId).subscribe((res) => {
        if (!res.error) {
          this.profileLoader = false;
          if (res.data == null) {
            this.profileData = [];
          } else {
            this.profileData = res.data;
          }
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in getting profile details.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.profileData = [];
      this.profileLoader = false;
    }

  }

  @Output() pageNavigation = new EventEmitter();
  extParamNextFn() {
    this.extParameService.checkProfile(this.metaInfo.recordId).subscribe((res) => {
      if (!res.error) {
        if (res.data) {
          this.pageNavigation.emit();
        } else {
          this.toastr.error("File must have atleast one profile with basic selection criteria", "Oops!", TOAST_SETTING);
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting profile details.", "Oops!", TOAST_SETTING);
    });
  }

  updateDateAndBy(event) {
    this.updateDateAndUpdateBy.emit(event);
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.extractionProfileTooltip = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.extractionProfileTooltip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @Output() pushRedirectFlag = new EventEmitter();
  pushRedirectFlagC(flag) {
    if (!this.viewOnly) {
      this.redirectFlag = flag;
      this.pushRedirectFlag.emit(flag);
    }
  }
  // Get confirmation for navigate without savig data
}
