// al-extraction-parameters.component.spec.ts

import { async, ComponentFixture, TestBed } from "@angular/core/testing";


// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService, OverlayPanel } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";


// COMPONENT
// =========================
import { AlExtractionParametersComponent } from "./al-extraction-parameters.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";


// SERVICE
// =========================
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { AlExtractionParametersService } from "../../al-file-setup-services/al-extraction-parameters.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";


// Mock data
// =========================
let metaInfo;
const routes: Routes = [];
let rowData, selRowData = {
    attributeAssocId: null,
    attributeName: null,
    category: "Section",
    conditionalDescription: null,
    dataType: "NODE",
    description: null,
    displayName: "Header",
    fileAttrBrAssocs: null,
    ftaaId: null,
    hasChildren: true,
    id: 270239,
    lookupTableFileAssociations: null,
    mandatory: true,
    mappedColumn: null,
    mappedColumnDetailsList: [{
        isActive: true
    }],
    mappedColumnId: null,
    parentId: null,
    recordId: null,
    referenceId: 2,
    selMappedColumnSource: null,
    selMapColVal: null,
    node: {
        data: {
            lstFlsNodeBrAssoc: []
        }
    }
};
let rowIndex = 1;
let actionItems = {
    toggle: (e) => {
    },
    hide: () => {
    }
};

describe("AlExtractionParametersComponent", () => {
    let component: AlExtractionParametersComponent;
    let fixture: ComponentFixture<AlExtractionParametersComponent>;
    let toastService, alNotificationsService;

    function populateData() {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/metaInfo.json");
        metaInfo = response.data;
        return metaInfo;
    }

    beforeEach(async(() => {
        TestBed.overrideComponent(AlExtractionParametersComponent, {
            set: {
                providers: [
                    { provide: AlExtractionParametersService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });

        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlExtractionParametersComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                { provide: AlExtractionParametersService, useClass: MockDataService },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                // { provide: ConfirmationService, useClass: MockDataService },
                { provide: AlRuleEditorService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService }
            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlExtractionParametersComponent);
            component = fixture.debugElement.componentInstance;
            component.metaInfo = populateData();
            fixture.detectChanges();
        });

        toastService = TestBed.get(ToastsManager);
    }));

    afterEach(() => {
        fixture.destroy();
        component = null;
    });

    it("should create", async(() => {
        expect(component).toBeTruthy();
    }));

    it("should call getActivatedOutboundProfiles()", async(() => {
        component.getActivatedOutboundProfiles();
    }));

    it("should call onProfileChange()", async(() => {
        component.profile = {
            profileId: 125
        };
        component.onProfileChange();
        fixture.detectChanges();
    }));

    it("should call onProfileChange()", async(() => {
        component.profile = null;
        component.onProfileChange();
        fixture.detectChanges();
    }));

    it("should call extParamNextFn()", async(() => {
        component.extParamNextFn();
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "checkProfile").and.returnValue(Observable.throw("error"));
        component.extParamNextFn();
    }));
    it("extParamNextFn(res.error)", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "checkProfile").and.returnValue(Observable.of({ "error": true }));
        component.extParamNextFn();
    }));
    it("extParamNextFn(error False)", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "checkProfile").and.returnValue(Observable.of({ "error": false }));
        component.extParamNextFn();
    }));



    it("onProfileChange() - Error", async(() => {
        component.profile = {
            profileId: 125
        };
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getProfileData").and.returnValue(Observable.throw("error"));
        component.onProfileChange();
    }));
    it("onProfileChange() - Res Error", async(() => {
        component.profile = {
            profileId: 125
        };
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getProfileData").and.returnValue(Observable.of({ "error": true }));
        component.onProfileChange();
    }));
    it("onProfileChange() - Data Null", async(() => {
        component.profile = {
            profileId: 125
        };
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getProfileData").and.returnValue(Observable.of({ "error": false, "data": null }));
        component.onProfileChange();
    }));



    it("should and displayToolTipText()", () => {
        component.extractionProfileTooltip = {
            "File status": {
                "tooltipDesc": "Test Email Address description",
                "readMoreLink": "http://www.google.com"
            }
        };
        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "File status", "bottom");
        });
        btnNextStep.click();
    });
    it("should and displayToolTipText() Else", () => {
        component.extractionProfileTooltip = {
            "File status": {
                "tooltipDesc": "Test Email Address description",
                "readMoreLink": null
            }
        };
        const btnNextStep = document.createElement("a");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "File status", "bottom");
        });
        btnNextStep.click();
    });


    it("getPlanSubtypeDetails(error)", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getSelectionCriteriaDatasetByRecordId").and.returnValue(Observable.throw("error"));
        component.getPlanSubtypeDetails();
    }));
    it("getPlanSubtypeDetails(!res.error) ", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getSelectionCriteriaDatasetByRecordId").and.returnValue(Observable.of({ "error": true }));
        component.getPlanSubtypeDetails();
    }));

    it("getActivatedOutboundProfiles(error)", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getActivatedOutboundProfiles").and.returnValue(Observable.throw("error"));
        component.getActivatedOutboundProfiles();
    }));
    it("getActivatedOutboundProfiles(!res.error) ", async(() => {
        let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
        spyOn(extractionParametersService, "getActivatedOutboundProfiles").and.returnValue(Observable.of({ "error": true }));
        component.getActivatedOutboundProfiles();
    }));

    it("updateDateAndBy(), pushRedirectFlagC(), hideToolTipText() ", async(() => {
        component.updateDateAndBy(true);
        component.viewOnly = false;
        component.pushRedirectFlagC(true);
        component.hideToolTipText(true);
    }));



});


class MockDataService {

    // childService methods
    // =============================

    getSelectionCriteriaDatasetByRecordId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-extraction-parameters/getPlanSubtypeDetails.json");
        return (Observable.of(response));
    }

    getActivatedOutboundProfiles(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getProfileData(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    checkProfile(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    // toolTipUtils methods
    // =============================

    getPageAndFieldsDetails(childFileTemplateId, childFileTemplateVersion, fileTypeId): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }

    success() {
        return true;
    }

    changeRoute() {
        return true;
    }

    confirm() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}

