import { Component, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter, ViewChild } from "@angular/core";
import { PickListModule } from "primeng/primeng";
import { NgForm } from "@angular/forms";
import { CalendarModule } from "primeng/primeng";
import { AlExtractionParametersService } from "../../../al-file-setup-services/al-extraction-parameters.service";
import { ToastsManager } from "ng2-toastr";
import { ToolTipUtilService } from "../../../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../../../global";
import * as moment from "moment-timezone";

@Component({
  selector: "al-basic-selection-criteria",
  templateUrl: "./al-basic-selection-criteria.component.html",
  styleUrls: ["./al-basic-selection-criteria.component.scss"]
})
export class AlBasicSelectionCriteriaComponent implements OnInit {

  basicSel: any = {};
  @Input() profile;
  @Input() profileData;
  @Input() metaInfo;
  @Input() viewOnly;
  @Input() planSubtypeDetails;
  selProfile: any;
  @Output() updateDateAndBy = new EventEmitter;

  basicSelectionTooltip: any = [];
  tooltipResult: any;
  pageID: number = 32;
  currentYear = moment(new Date()).format("YYYY");
  todaysDate: Date = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY"));
  systemDate: any;
  constructor(
    private extParameService: AlExtractionParametersService,
    public toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService
  ) {
  }

  ngOnInit() {
    this.getEmployerDetails();
    this.getPlanSubtypeDetails();
    this.getToolTipTextDetails();
  }

  getEmployerDetails() {
    this.extParameService.getEmployerDetails(this.metaInfo.recordId).subscribe((res) => {
      if (!res.error) {
        this.basicSel["employerNameList"] = [];
        for (let obj of res.data) {
          obj.label = obj.value;
          obj.value = obj.key;
          this.basicSel["employerNameList"].push(obj);
        };
        this.subscribeFormChanges();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting employer details.", "Oops!", TOAST_SETTING);
    });
  }

  getPlanSubtypeDetails() {
    this.basicSel["planSubType"] = [];
    this.basicSel["planSubTypeList"] = [];
    this.basicSel["planSTListUnedited"] = [];
    let _benPlanSubType = this.planSubtypeDetails.filter((obj) => obj.criteriaName === "benefitPlanSubType");
    if (_benPlanSubType.length === 0) {
      return false;
    }
    for (let _planType of _benPlanSubType[0].values) {
      this.basicSel["planSubTypeList"].push({
        "label": _planType,
        "key": _planType,
        "value": _planType,
        "active": true
      });
      this.basicSel["planSTListUnedited"].push({
        "label": _planType,
        "key": _planType,
        "value": _planType,
        "active": true
      });
    }
  }


  editData: any = [];
  ngOnChanges(changes: SimpleChanges) {
    if (changes["profileData"] !== undefined && changes["profileData"].currentValue.length !== 0) {
      let _editData = this.profileData.filter((obj) => obj.fepiIsAdvSelectionCriteria === false && obj.fepiIsChangeCriteria === false);
      this.editData = _editData[0];
      if (this.editData) {
        this.populateEditData(this.editData);
      }

    } else if (changes["profileData"] !== undefined && changes["profileData"].currentValue.length === 0) {
      this.populateEditData(null);
    }

  }


  populateEditData(data?) {
    if (this.basicSel.planSTListUnedited) {
      this.basicSel.planSubTypeList = [...this.basicSel.planSTListUnedited];
    }
    this.systemDate = "";
    this.basicSel.isDefaultDate = false;
    this.basicSel.employerNameCheck = false;
    this.basicSel.planSubTypeCheck = false;
    this.basicSel["employerName"] = [];
    this.basicSel.systemDate = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY"));
    if (data === null) {
      if (this.basicSel.planSTListUnedited === undefined) {
        return false;
      }
      this.basicSel.planSubType = [];
      this.basicSel.planSubTypeList = [...this.basicSel.planSTListUnedited];
      this.basicSel["editDataId"] = null;
      this.basicSel.planAdditionFactor = null;
      this.basicSel.lookBackPeriod = null;
      this.basicSel.lookAheadPeriod = null;
      return false;
    }
    this.basicSel["editDataId"] = this.editData.id;

    let _employerData = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "employerId");
    if (_employerData.length > 0) {
      let _employer = _employerData[0].extractionParameterDTOs;
      for (let _emp of _employer) {
        this.basicSel["employerName"].push(_emp.key);
      }
    }

    let _planSubData = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "benefitPlanSubType");
    if (_planSubData.length > 0) {
      let _planSub = _planSubData[0].extractionParameterDTOs;
      this.basicSel.planSubType = _planSub;
      let _getPSTIndex = [];
      for (let _psType of _planSub) {
        let getIndex = this.basicSel.planSubTypeList.filter((_pst, i) => {
          if (_psType.key === _pst.key) {
            this.basicSel.planSubTypeList.splice(i, 1);
          }
        });
      }
    }

    const planAdditionFactor = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "planAdditionFactor");
    if (planAdditionFactor && planAdditionFactor[0] && planAdditionFactor[0].extractionParameterDTOs) {
      this.basicSel.planAdditionFactor = planAdditionFactor[0].extractionParameterDTOs[0].value;
    }

    const lookBackPeriod = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "lookBackPeriod");
    if (lookBackPeriod && lookBackPeriod[0] && lookBackPeriod[0].extractionParameterDTOs) {
      this.basicSel.lookBackPeriod = lookBackPeriod[0].extractionParameterDTOs[0].value;
    }

    const lookAheadPeriod = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "lookAheadPeriod");
    if (lookBackPeriod && lookAheadPeriod[0] && lookAheadPeriod[0].extractionParameterDTOs) {
      this.basicSel.lookAheadPeriod = lookAheadPeriod[0].extractionParameterDTOs[0].value;
    }

    let sysDate = "";

    const systemDate = this.editData.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "systemDate");
    if (systemDate && systemDate[0] && systemDate[0].extractionParameterDTOs) {
      sysDate = systemDate[0].extractionParameterDTOs[0].value;
    }
    if (sysDate !== "") {
      this.basicSel.systemDate = this.convertMMDDYYYY(sysDate);
      this.systemDate = this.basicSel.systemDate;
    } else if (sysDate === "") {
      this.basicSel.isDefaultDate = true;
      this.basicSel.systemDate = "";
    }
    this.subscribeFormChanges();
  }

  convertMMDDYYYY(inputFormat) {
    let date;
    let d = new Date(inputFormat);
    date = [this.pad(d.getMonth() + 1), this.pad(d.getDate()), d.getFullYear()].join("/");
    return date;
  }

  basicSelForm: NgForm;
  saveBasicSelection(form: NgForm) {
    if (this.profile === null) {
      this.toastr.error("Please select any profile.", "Oops!", TOAST_SETTING);
      return false;
    }
    this.basicSel.lookBackPeriodV = false;
    if (this.basicSel.lookBackPeriod) {
      this.basicSel.lookBackPeriod <= 0 ? this.basicSel.lookBackPeriodV = true : this.basicSel.lookBackPeriodV = false;
      let _lookB = isNaN(this.basicSel.lookBackPeriod);
      if (_lookB) {
        this.basicSel.lookBackPeriodV = true;
      }
    }
    this.basicSel.lookAheadPeriodV = false;
    if (this.basicSel.lookAheadPeriod) {
      this.basicSel.lookAheadPeriod <= 0 ? this.basicSel.lookAheadPeriodV = true : this.basicSel.lookAheadPeriodV = false;
      let _lookH = isNaN(this.basicSel.lookAheadPeriod);
      if (_lookH) {
        this.basicSel.lookAheadPeriodV = true;
      }
    }

    this.basicSel.planAdditionFactorV = false;
    if (this.basicSel.planAdditionFactor) {
      let _lookA = isNaN(this.basicSel.planAdditionFactor);
      if (_lookA) {
        this.basicSel.planAdditionFactorV = true;
      } else {
        if (Number(this.basicSel.planAdditionFactor) === 0) {
          this.basicSel.planAdditionFactorV = true;
        }
      }
    }


    this.basicSelForm = form;
    let _employer = [];
    if (this.basicSel.employerName.length === 0) {
      this.basicSel.employerNameCheck = true;
    } else {
      this.basicSel.employerNameCheck = false;
      for (let _emp of this.basicSel.employerName) {
        let _selEmp = this.basicSel.employerNameList.filter((em) => em.key === _emp);
        _employer.push(_selEmp[0]);
      }
    }
    if (this.basicSel.planSubType.length === 0) {
      this.basicSel.planSubTypeCheck = true;
    } else {
      this.basicSel.planSubTypeCheck = false;
    }

    if (this.basicSel.employerNameCheck || this.basicSel.planSubTypeCheck || this.basicSel.planAdditionFactorV || this.basicSel.lookBackPeriodV || this.basicSel.lookAheadPeriodV) {
      return false;
    }

    let saveObj = {
      "id": this.basicSel.editDataId,
      "recordId": this.metaInfo.recordId,
      "profile": {
        "profileId": this.profile.profileId,
      },
      "fepiIsAdvSelectionCriteria": false,
      "fepiIsChangeCriteria": false,
      "active": true,
      "basicSelectionCriteriaDTOs": [
        {
          "selectionType": "employerId",
          "extractionParameterDTOs": _employer
        },
        {
          "selectionType": "benefitPlanSubType",
          "extractionParameterDTOs": this.basicSel.planSubType
        }
      ]
    };

    if (this.basicSel.planAdditionFactor) {
      saveObj.basicSelectionCriteriaDTOs.push({
        "selectionType": "planAdditionFactor",
        "extractionParameterDTOs": [{
          "key": this.basicSel.planAdditionFactor,
          "value": this.basicSel.planAdditionFactor,
          "active": true
        }]
      });
    };
    if (this.basicSel.lookBackPeriod) {
      saveObj.basicSelectionCriteriaDTOs.push({
        "selectionType": "lookBackPeriod",
        "extractionParameterDTOs": [{
          "key": this.basicSel.lookBackPeriod,
          "value": this.basicSel.lookBackPeriod,
          "active": true
        }]
      });
    };
    if (this.basicSel.lookAheadPeriod) {
      saveObj.basicSelectionCriteriaDTOs.push({
        "selectionType": "lookAheadPeriod",
        "extractionParameterDTOs": [{
          "key": this.basicSel.lookAheadPeriod,
          "value": this.basicSel.lookAheadPeriod,
          "active": true
        }]
      });
    };

    saveObj.basicSelectionCriteriaDTOs.push({
      "selectionType": "systemDate",
      "extractionParameterDTOs": [{
        "key": this.formatRunDate(this.basicSel.systemDate),
        "value": this.formatRunDate(this.basicSel.systemDate),
        "active": true
      }]
    });

    this.extParameService.create(saveObj).subscribe((res) => {
      if (!res.error) {
        this.basicSel.editDataId = res.data.fileExtractionParameterDto.id;
        this.updateDateAndBy.emit(res.data.metaInfo);

        let sysDate = "";
        const systemDate = res.data.fileExtractionParameterDto.basicSelectionCriteriaDTOs.filter((obj) => obj.selectionType === "systemDate");
        if (systemDate && systemDate[0] && systemDate[0].extractionParameterDTOs) {
          sysDate = systemDate[0].extractionParameterDTOs[0].value;
        }
        this.systemDate = sysDate;
        this.toastr.success("Basic Selection Criteria Saved Successfully for Profile " + this.profile.profileName, "Success");
        this.deActiveFlag();
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting employer details.", "Oops!", TOAST_SETTING);
    });
  }

  formatRunDate(inputFormat) {
    let formattedDate = "";

    if (this.basicSel.isDefaultDate === false) {
      let d = new Date(inputFormat);
      formattedDate = [d.getFullYear(), this.pad(d.getMonth() + 1), this.pad(d.getDate())].join("-");
    };
    return formattedDate;
  }

  pad(s) { return (s < 10) ? "0" + s : s; }

  setSystemDateValue() {
    if (this.basicSel.isDefaultDate === true) {
      this.basicSel.systemDate = "";
    } else if (this.systemDate !== "") {
      this.basicSel.systemDate = this.convertMMDDYYYY(this.systemDate);
    } else {
      this.basicSel.systemDate = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY"));
    }
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.basicSelectionTooltip = res.data;
    });
  }


  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.basicSelectionTooltip[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }

  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // subscribe for user changes
  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @ViewChild("basicSelection") basicSelection: NgForm;
  pageForm: any;
  @Output() pushRedirectFlagC = new EventEmitter();
  subscribeFormChanges() {
    this.pageForm = this.basicSelection.valueChanges.subscribe(
      result => {
        if (this.basicSelection.form.dirty) {
          this.activeRedirectFlag();
        }
      }
    );
  }
  activeRedirectFlag() {
    if (!this.redirectFlag) {
      this.redirectFlag = true;
      this.pushRedirectFlagC.emit(true);
      this.pageForm.unsubscribe();
    }
  };
  deActiveFlag() {
    this.redirectFlag = false;
    this.pushRedirectFlagC.emit(false);
  }
  // subscribe for user changes

}
