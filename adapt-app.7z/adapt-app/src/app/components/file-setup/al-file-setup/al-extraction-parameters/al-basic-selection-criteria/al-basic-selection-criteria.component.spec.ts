import { async, ComponentFixture, TestBed } from "@angular/core/testing";

// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, SimpleChange } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";

// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DialogModule, PickListModule, ListboxModule, DropdownModule, OverlayPanelModule, ConfirmationService, OverlayPanel } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

// SERVICE
// =========================
import { FileSetupService } from "../../../al-file-setup-services/file-setup.service";
import { AlRuleEditorService } from "../../../al-file-setup-services/al-rule-editor.service";
import { ToolTipUtilService } from "../../../../../services/common/toolTipUtil";
import { AlExtractionParametersService } from "../../../al-file-setup-services/al-extraction-parameters.service";

// COMPONENT
// =========================
import { AlBasicSelectionCriteriaComponent } from "./al-basic-selection-criteria.component";
import { AlPopOverModule } from "../../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [];

describe("AlBasicSelectionCriteriaComponent", () => {
  let component: AlBasicSelectionCriteriaComponent;
  let fixture: ComponentFixture<AlBasicSelectionCriteriaComponent>;
  let metaInfo;

  function populateData() {
    let response;
    response = require("../../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
    metaInfo = response.data.metaInfo;
    return metaInfo;
  }

  beforeEach(async(() => {
    TestBed.overrideComponent(AlBasicSelectionCriteriaComponent, {
      set: {
        providers: [
          { provide: AlExtractionParametersService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        RouterTestingModule,
        ListboxModule,
        PickListModule,
        RouterTestingModule.withRoutes(routes),
        RouterModule.forRoot(routes, { useHash: true }),
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlBasicSelectionCriteriaComponent],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        AppUtility,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        { provide: AlExtractionParametersService, useClass: MockDataService },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        // { provide: ConfirmationService, useClass: MockDataService },
        { provide: AlRuleEditorService, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: FakeToolTip }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlBasicSelectionCriteriaComponent);
    component = fixture.componentInstance;
    component.metaInfo = populateData();
    component.planSubtypeDetails = [{
      "criteriaName": "benefitPlanSubType",
      "values": [{
        "label": "label",
        "key": "Ket",
        "value": "Value",
        "active": true
      }]
    },
    {
      "criteriaName": "benefitPlanSubType"
    }];
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should error handle", () => {
    let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
    spyOn(extractionParametersService, "getEmployerDetails").and.returnValue(Observable.throw("No Data"));
    component.getEmployerDetails();
  });

  it("should ngchange", () => {
    component.profileData = [{
      "fepiIsChangeCriteria": false,
      "fepiIsAdvSelectionCriteria": false,
      "id": 1235,
      "basicSelectionCriteriaDTOs": [{
        "selectionType": "employerId",
        "extractionParameterDTOs": [{
          "key": "key1",
          "value": "value1"
        }, {
          "key": "key2",
          "value": "value2"
        }]
      }, {
        "selectionType": "benefitPlanSubType",
        "extractionParameterDTOs": [{
          "key": "key1",
          "value": "value1"
        }, {
          "key": "key2",
          "value": "value2"
        }]
      },
      {
        "selectionType": "coverageStartDate",
        "extractionParameterDTOs": [{
          "key": "key1",
          "value": "value1"
        }, {
          "key": "key2",
          "value": "value2"
        }]
      }, {
        "selectionType": "coverageEndDate",
        "extractionParameterDTOs": [{
          "key": "key1",
          "value": "value1"
        }, {
          "key": "key2",
          "value": "value2"
        }]
      }]
    }];
    component.ngOnChanges({
      profileData: new SimpleChange(null, component.profileData, null)
    });
    component.profileData = [];
    component.ngOnChanges({
      profileData: new SimpleChange(null, component.profileData, null)
    });
  });

  it("should saveBasicSelection form Fun", () => {
    let validForm = <NgForm>{
      resetForm: function () { },
      value: {

      }
    };
    component.profile = {
      "profileId": 12345
    };
    component.basicSel = {
      "employerName": "",
      "planSubType": "",
      "endDate": "",
      "startDate": ""
    };
    component.todaysDate = new Date();
    component.saveBasicSelection(validForm);
    component.basicSel = {
      "employerName": "employer test 1",
      "employerNameList": [{
        "key": "employer test 1"
      }],
      "planSubType": "subtype",
      "endDate": new Date("06/12/2018 08:41:26.847 GMT"),
      "startDate": new Date("03/10/2018 08:41:26.847 GMT")
    };
    component.saveBasicSelection(validForm);
    let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
    spyOn(extractionParametersService, "create").and.returnValue(Observable.throw("No Data"));
    component.profile = null;
    component.saveBasicSelection(validForm);
  });

  it("should saveBasicSelection form Fun with case", () => {
    let validForm = <NgForm>{
      resetForm: function () { },
      value: {
        "planYear": 2019
      }
    };
    component.profile = {
      "profileId": 12345
    };
    component.basicSel = {
      "employerName": "",
      "planSubType": "",
      "endDate": "",
      "startDate": ""
    };
    component.saveBasicSelection(validForm);
    component.basicSel = {
      "employerName": "employer test 1",
      "employerNameList": [{
        "key": "employer test 1"
      }],
      "planSubType": "subtype",
      "endDate": new Date("06/12/2018 08:41:26.847 GMT"),
      "startDate": new Date("03/10/2018 08:41:26.847 GMT")
    };
    component.saveBasicSelection(validForm);
    let extractionParametersService = fixture.debugElement.injector.get(AlExtractionParametersService);
    spyOn(extractionParametersService, "create").and.returnValue(Observable.throw("No Data"));
    component.profile = null;
    component.saveBasicSelection(validForm);
  });

  it("should and displayToolTipText()", () => {
    component.basicSelectionTooltip = {
      "Plan End Date": {
        "tooltipDesc": "Plan End Date description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Plan End Date", "bottom");
    });
    component.hideToolTipText(event);
    btnNextStep.click();
  });

  it("activeRedirectFlag()", () => {
    component.deActiveFlag();
    component.activeRedirectFlag();
  });

  it("convertMMDDYYYY()", () => {
    let sysDate = "2019-10-17";
    component.convertMMDDYYYY(sysDate);
  });

  it("setSystemDateValue()", () => {
    component.setSystemDateValue();
  });
});


class MockDataService {

  // childService methods
  // =============================
  getEmployerDetails(): Observable<any> {
    let response;
    response = require("../../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getAttributeList.json");
    return (Observable.of(response));
  }

  create(): Observable<any> {
    let response;
    response = require("../../../../../../assets/test-data/file-setup/al-file-setup/al-extraction-parameters/al-basic-selection-criteria/create.json");
    return (Observable.of(response));
  }
  error() {
    return false;
  }
  success() {
    return true;
  }

  changeRoute() {
    return true;
  }

  confirm() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
