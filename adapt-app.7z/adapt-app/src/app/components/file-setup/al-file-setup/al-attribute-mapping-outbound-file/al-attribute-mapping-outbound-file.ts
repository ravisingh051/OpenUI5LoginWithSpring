import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { ToastsManager } from "ng2-toastr";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { MenuItem } from "primeng/components/common/api";
import { TreeTableModule } from "../../al-treetable/treetable";
import { TreeNode } from "primeng/primeng";
import { AlRuleEditorComponent } from "../../al-rule-editor/al-rule-editor.component";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { ConfirmationService } from "primeng/components/common/api";
import { NgForm } from "@angular/forms";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING, confAcceptLabel, confRejectLabel, confMessage } from "../../../../global";

@Component({
  selector: "al-attribute-mapping-outbound-file",
  templateUrl: "./al-attribute-mapping-outbound-file.html",
  styleUrls: ["./al-attribute-mapping-outbound-file.scss"],
  providers: [ConfirmationService, AlRuleEditorService]
})
export class AlAttributeMappingOutboundFile implements OnInit {

  // Rule Editor Section
  specialMappingDialog: boolean = false;
  selectedAttributeForRule: any = "";
  selAttrDataType: any = "";
  ruleTemplatesGroupMapping: any = {};
  getRuleAttributeList: any = [];
  ruleAttributeArray: any = [];
  getRuleSecondaryDataAttributeList: any = [];
  attrDrlRelativeNaming: any = {};
  packageByFileType: any;
  fixedWidth: boolean = false;
  @ViewChild(AlRuleEditorComponent) ruleEditorComp;

  constructor(
    private toastr: ToastsManager,
    private fileService: FileSetupService,
    private _ruleEditorService: AlRuleEditorService,
    private confirmationService: ConfirmationService,
    private toolTipUtils: ToolTipUtilService,
    private fileSetupService: FileSetupService
  ) { }

  @Input() viewOnly: boolean;
  @Input() metaInfo: any;
  @Output() tabLoader = new EventEmitter();
  @Output() pageNavigation = new EventEmitter();
  @Output() updateDateAndUpdateBy = new EventEmitter;

  activeIndex: number = 0;
  items: MenuItem[];
  treeTableData: any = [];
  filesCol: any[];
  btnClicked: boolean;
  ruleApplicableRow: boolean = false;

  /* ToolTip Text display */
  toolTipAttribute: any = [];
  tooltipResult: any;
  pageID: number = 18;

  ngOnInit() {
    this.items = [{
      label: "Header",
      command: (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: "Detail Row",
      command: (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: "Trailer",
      command: (event: any) => {
        this.activeIndex = 2;
      }
    }];
    // rule
    this.getFileAttributeList();
    this.getAttributeListOutbound();
    this.getAttributeList();
    this.getMapColDropDown();
    this.getSecondaryDataAtrributes();
    this.getToolTipTextDetails();
    this.getAllIdisRulePrioritySequence();

    this._ruleEditorService.getAllRuleTemplates().subscribe(res => {
      if (!res.error) {
        let i = 1;
        for (let obj of res.data) {
          obj.label = obj.droolsBusinessRuleTemplateName;
          obj.value = i;
          this.ruleTemplatesGroupMapping[obj.droolsBusinessRuleTemplateGroup.droolsBusinessRuleGroupName.toLowerCase()] = obj.droolsBusinessRuleTemplateGroup.droolsBusinessRuleGroupId;
          i++;
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting all rule templates.", "Oops!", TOAST_SETTING);
    });
    this.getLookupTables();


    // this.loadRules();
  }

  getAttrMappingData() {
    this.btnClicked = true;
    this.tabLoader.emit(true);
    this.fileService.getAttrMappingData(this.metaInfo.recordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.treeTableData = res.data;
        this.btnClicked = false;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  nextStep() {
    if (this.redirectFlag) {
      this.confirmationService.confirm({
        message: confMessage,
        accept: () => {
          this.nextSteps();
          this.setRedirectFlag(false);
        }
      });
    } else {
      this.nextSteps();
    }
  }

  selSection: string = "H";
  nextSteps() {
    this.btnClicked = true;
    this.activeIndex++;
    if (this.activeIndex === 1) {
      this.selSection = "D";
      this.getMapColDropDown();
    } /* istanbul ignore next */ else if (this.activeIndex === 2) {
      this.selSection = "T";
      this.getMapColDropDown();
    }
    if (this.activeIndex <= 2) {
      this.getAttrMappingData();
    } else {
      this.pageNavigation.emit(true);
    }

  }

  mandatoryDialog: boolean = false;
  $conditionalDescription: string;
  showMandatoryDialog(event, rowNode) {
    this.mandatoryDialog = true;
    this.mapColData = rowNode;
    this.$conditionalDescription = rowNode.node.data.conditionalDescription;
    event.stopPropagation();
  }

  selRowData: any;
  actionOverly;

  isFormatAvail: boolean = true;
  isInherited: boolean;
  attachRuleAndLookup(e, rowData, rowIndex) {
    if (rowData.selMappedColumnSource !== null && rowData.selMappedColumnSource !== undefined && rowData.selMappedColumnSource === "Data Element") {
      this.ruleApplicableRow = true;
    } else {
      this.ruleApplicableRow = false;
    }
    this.selRowData = rowData;
    this.actionOverly.toggle(e);

    if (rowData.dataType !== null && rowData.dataType !== undefined && rowData.dataType.toUpperCase() === "BIT") {
      this.isFormatAvail = false;
    } else {
      this.isFormatAvail = true;
    }
    this.attributeMapping.selected = [];
    this.attributeMapping.selected.push(rowData);
    this.attributeMapping.selectedIndex = rowIndex;

    this.isRuleOrderAvail = false;
    if (rowData && rowData.fileAttrBrAssocs) {
      rowData.fileAttrBrAssocs.forEach((fileBrAssoc, index) => {
        if (fileBrAssoc.droolsBusinessRulesDecisionTable) {
          this.isRuleOrderAvail = true;
        }
      });
    }
  }

  /*mapColDialog:boolean = false;
  mapColTableData: any;
  dialogDataLoader:boolean;
  showMapColDialog(rowData){
    this.dialogDataLoader = true;
    this.mapColDialog = true;
    this.selRowData = rowData;
    if(this.selRowData['mappedColumnDetailsList'] === undefined){
      this.fileService.getMappedColumns(this.selRowData.id).subscribe(res => {
        if(!res.error){
          this.selRowData['mappedColFlag'] = true;
          this.selRowData['mappedColumnDetailsList'] = res.data;
          this.mapColTableData = res.data;
          let _selMapCol = this.mapColTableData.filter((obj) => obj.isActive === true);
          if(_selMapCol.length > 0){
            this.selMapColVal = _selMapCol[0];
          } else {
            this.selMapColVal = null;
          }
          this.dialogDataLoader = false;
        } else {
          this.toastr.error(res.message,'Oops!')
        }
      },error => {
        this.toastr.error("Server Error in getting Mapped Column Data.",'Oops!');
      });
    } else {
      this.mapColTableData = this.selRowData['mappedColumnDetailsList'];
      if(this.selRowData['selMappedColumn'] !== undefined){
        let _selMapCol = this.mapColTableData.filter((obj) => obj.id === this.selRowData.selMappedColumn.id);
        this.selMapColVal = _selMapCol[0];
      } else {
        if(this.selRowData.mappedColumn === "Select"){
          this.selMapColVal = null;
        } else {
          let _selMapCol = this.mapColTableData.filter((obj) => obj.isActive === true);
          if(_selMapCol.length > 0){
            this.selMapColVal = _selMapCol[0];
          } else {
            this.selMapColVal = null;
          }
        }
      }
      this.dialogDataLoader = false;
    }
  }*/

  validValues: any = {};
  addSelDataEle() {
    if (this.validValues.selDataEle === undefined || this.validValues.selDataEle.length === 0) {
      this.toastr.error("Please select Attribute.", "Oops!", TOAST_SETTING);
      return false;
    }
    let _mapColTableData = [];
    for (let i = 0; i < this.validValues.selDataEle.length; i++) {
      let _selElId = this.validValues.selDataEle[i];
      let _selEl = this.validValues.dataEleList.filter((obj) => obj.value === _selElId);
      _mapColTableData.push({
        "nodeId": this.mapColData.node.data.id,
        "name": _selEl[0].label,
        "description": _selEl[0].description,
        "source": "Data Element",
        "attributeAssocId": _selEl[0].value,
        "parentIdIfInheritedEnum": null,
        "isActive": false
      });
    }

    if (_mapColTableData.length > 0) {
      this.mapColTableData = [...this.mapColTableData, ..._mapColTableData];
      this.populateDataElement();
    }
  }

  mapColDialog: boolean = false;
  mapColTableData: any;
  selSourceTab: boolean;
  selMapColTab: boolean;
  showMapColDialog(event, rowNode) {
    this.selSourceTab = true;
    this.selMapColTab = false;
    this.mapColData = rowNode;
    this.validValues.selSource = "1";
    this.mapColTableData = [];
    if (this.mapColData.node.data["mappedColFlag"] === undefined || this.mapColData.node.data["mappedColFlag"] === false) {
      this.mapColData.node.data["mappedColFlag"] = true;
      this.fileService.getMappedColumns(this.mapColData.node.data.id).subscribe(res => {
        if (!res.error) {
          this.mapColData.node.data["mappedColumnDetailsList"] = res.data;
          this.mapColTableData = this.mapColData.node.data["mappedColumnDetailsList"];
          this.selMapColTableData = this.mapColData.node.data["mappedColumnDetailsList"];
          if (this.selMapColTableData !== undefined && this.selMapColTableData !== null) {
            let _selVal = this.selMapColTableData.filter((obj) => obj.isActive === true);
            if (_selVal.length > 0) {
              this.selMapColVal = _selVal[0];
            }
          }
          this.populateDataElement();
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in getting Mapped Column Data.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.mapColTableData = this.mapColData.node.data.mappedColumnDetailsList;
      this.selMapColTableData = this.mapColData.node.data.mappedColumnDetailsList;
      if (this.selMapColTableData !== undefined && this.selMapColTableData !== null) {
        let _selVal = this.selMapColTableData.filter((obj) => obj.isActive === true);
        if (_selVal.length > 0) {
          this.selMapColVal = _selVal[0];
        }
      }
      this.populateDataElement();
    }

    this.mapColDialog = true;
    event.stopPropagation();
  }
  populateDataElement() {
    let _tempDataList = [];
    for (let elm of this.rowAttrList) {
      let _check = this.mapColTableData.filter((_elm) => _elm.attributeAssocId === elm.value);
      if (_check.length === 0 && elm.sectionShortName === this.selSection) {
        _tempDataList.push(elm);
      }
    }
    this.validValues.dataEleList = _tempDataList;
    this.validValues.selDataEle = [];
  }

  rowAttrList: any;
  getAttributeListOutbound() {
    this.fileService.getAttributeListOutbound(this.metaInfo.recordId).subscribe(res => {
      if (!res.error) {
        let _dataList = [];
        for (let dList of res.data) {
          _dataList.push({
            "label": dList.attributeName,
            "value": dList.faaId,
            "description": dList.description,
            "sectionShortName": dList.fileCompliantSectionShortName
          });
        }
        this.rowAttrList = _dataList;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  selMapColVal: any;
  pushMapColData() {
    let attrAssocId = this.selRowData.attributeAssocId;
    this.selRowData.mappedColumn = this.selMapColVal === null ? "Select" : this.selMapColVal.source + " - " + this.selMapColVal.name;
    this.selRowData.selMappedColumnSource = this.selMapColVal === null ? null : this.selMapColVal.source;
    this.selRowData.attributeName = this.selMapColVal === null ? null : this.selMapColVal.name;
    this.selRowData.attributeAssocId = this.selMapColVal === null ? null : this.selMapColVal.attributeAssocId;
    if (attrAssocId !== null) {
      this.selRowData.oldAttributeAssocId = attrAssocId;
    }
    if (this.selMapColVal !== null) {
      this.selMapColVal.oldAttributeAssocId = attrAssocId;
      this.selRowData.recordId = this.selMapColVal.recordId;
      this.selRowData.ftaaId = this.selMapColVal.ftaaId;
      this.selRowData["selMappedColumn"] = this.selMapColVal === null ? null : this.selMapColVal;
    } else {
      this.selRowData.mappedColumnId = null;
      this.selRowData["selMappedColumn"] = null;
    }
    this.mapColDialog = false;
  }

  resetRowData() {
    this.mapColData.node["editMode"] = false;
    this.setRedirectFlag(false);
    this.rowEditFlag = false;
    this.mapColData.node.data = JSON.parse(this.mapColData.node.data["oldData"]);
    this.mapColData.node.data["oldData"] = null;
    if (this.selRowData.mappedColumn !== "Not Applicable" && this.selRowData["mappedColumnDetailsList"] !== null && this.selRowData["mappedColumnDetailsList"].length > 0) {
      let _selMapCol = this.selRowData.mappedColumnDetailsList.filter((obj) => obj.isActive === true);
      this.selRowData["mappedColFlag"] = false;
      if (_selMapCol.length > 0) {
        this.selMapColVal = _selMapCol[0];
        this.selRowData["selMappedColumn"] = this.selMapColVal;
        this.selRowData.mappedColumn = this.selMapColVal.source + " - " + this.selMapColVal.name;
      } else {
        this.selRowData.mappedColumn = "Select";
        this.selMapColVal = null;
        this.selRowData["selMappedColumn"] = null;
      }
    }
    this.actionOverly.hide();
  }

  acceptLabel: string = "Yes";
  rejectLabel: string = "No";
  isElementAssoUpdated: boolean = true;
  /* istanbul ignore next */
  regex = new RegExp("^[0-9]*$");
  saveAttrMapping() {
    let _data = this.selRowData;
    _data["nodeValidate"] = _data.nodeMaxSize === null ? false : this.regex.test(_data.nodeMaxSize) === false ? true : false;
    if (_data["nodeValidate"]) {
      this.toastr.error("Invalid Max Length on " + _data.displayName + " !", "Oops!", TOAST_SETTING);
      this.actionOverly.hide();
      return false;
    }
    this.prepareSaveObject();
  }

  prepareSaveObject() {
    this.actionOverly.hide();
    let saveObj = {
      "id": this.selRowData.id,
      "conditionalDescription": this.selRowData.conditionalDescription,
      "description": this.selRowData.description,
      "fileAttrBrAssocs": this.selRowData.fileAttrBrAssocs,
      "lookupTableFileAssociations": this.selRowData.lookupTableFileAssociations,
      "recordId": this.metaInfo.recordId,
      "mappedColumn": this.selRowData.mappedColumn,
      "mappedColumnId": this.selRowData.mappedColumnId,
      "ftaaId": this.selRowData.ftaaId,
      "mappedColumnType": this.mapColData.node.data.mappedColumn,
      "nodeMaxSize": this.selRowData.nodeMaxSize,
      "displayName": this.selRowData.displayName,
      "category": this.selRowData.category,
      "nodeRefNum": this.selRowData.referenceId,
      "oldAttributeAssocId": this.selRowData.oldAttributeAssocId
    };
    saveObj["mappedColumnDetailsList"] = [];
    if (this.mapColData.node.data.dataType.toLowerCase() === "node" && this.mapColData.node.data.mappedColumn && this.mapColData.node.data.mappedColumn !== "Not Applicable") {
      let _mpCData = this.mapColAllOption.filter((obj) => this.mapColData.node.data.mappedColumn === obj.sectionDisplayName);
      if (_mpCData.length !== 0) {
        saveObj["mappedColumnType"] = _mpCData[0].sectionDisplayName;
        saveObj["mappedTemplateSectionId"] = _mpCData[0].templateSectionId;
      }
    } else if (this.mapColData.node.data.dataType.toLowerCase() !== "node" && this.mapColData.node.data.mappedColumn && this.mapColData.node.data.mappedColumn !== "Not Applicable") {
      if (!this.mapColData.node.data.selMappedColumn && this.mapColData.node.data.mappedColumnDetailsList && this.mapColData.node.data.mappedColumnDetailsList.length) {
        let _selMapColVal = this.mapColData.node.data.mappedColumnDetailsList.filter((obj) => obj.isActive);
        this.mapColData.node.data["selMappedColumn"] = _selMapColVal[0];
      }
      if (this.mapColData.node.data.selMappedColumn) {
        saveObj["mappedColumnType"] = "Data Element";
        saveObj["mappedColumnDetailsList"].push(this.mapColData.node.data["selMappedColumn"]);
        this.isElementAssoUpdated = true;
      }
    }
    if (this.selRowData.selMappedColumnSource !== null && this.mapColData.node.data.dataType.toLowerCase() !== "node" && (this.mapColData.node.data.mappedColumn === "Not Applicable" || this.mapColData.node.data.mappedColumn === null)) {
      this.isElementAssoUpdated = true;
    }
    this.fileService.saveMappedColumns(this.metaInfo.recordId, saveObj, null, this.isElementAssoUpdated).subscribe(res => {
      if (!res.error) {
        this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
        this.toastr.success(this.selRowData.displayName + " Data Saved successfully.", "Success!");
        this.mapColData.node["editMode"] = false;
        this.rowEditFlag = false;
        this.setRedirectFlag(false);
        this.mapColData.node.data["oldData"] = null;
        this.selRowData.oldAttributeAssocId = this.selRowData.attributeAssocId;
        if (res.data.list) {
          this.mapColData.node.data["mappedColumnDetailsList"] = res.data.list;
          let _selMapColVal = this.mapColData.node.data.mappedColumnDetailsList.filter((obj) => obj.isActive);
          if (_selMapColVal) {
            this.mapColData.node.data["selMappedColumn"] = _selMapColVal[0];
          }
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.setRedirectFlag(false);
      }
    }, error => {
      this.toastr.error("Server Error in getting Mapped Column Data.", "Oops!", TOAST_SETTING);
      this.setRedirectFlag(false);
    });
  }

  /* istanbul ignore next */
  identifyRowAndopenRuleEditor(row, index, linkIndex, overlaypanel: OverlayPanel, RuleGroupName, RuleGroupId, viewOnly, e) {
    this.ruleIndex = linkIndex;
    if (row.dataType !== null && row.dataType !== undefined && row.dataType.toUpperCase() === "BIT") {
      this.isFormatAvail = false;
    } else {
      this.isFormatAvail = true;
    }

    this.selRowData = row;
    this.attributeMapping.selected = [];
    this.attributeMapping.selected.push(row);
    this.attributeMapping.selectedIndex = index;
    // this.selIndex = index;
    this.openRuleEditor(overlaypanel, RuleGroupName, viewOnly);
    if (viewOnly) {
      e.stopPropagation();
    }
  }

  /* istanbul ignore next */
  openRuleEditor(overlaypanel: OverlayPanel, ruleType, viewOnly) {
    if (overlaypanel !== null) {
      overlaypanel.hide();
    }
    let selRuleBrAssc = {
      "faaId": this.selRowData.attributeAssocId
    };

    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    this.selectedAttributeForRule = this.selRowData.attributeName;
    this.selAttrDataType = this.selRowData.dataType;
    let savedRules = this.selRowData.fileAttrBrAssocs !== null ? this.selRowData.fileAttrBrAssocs : [];
    this.selRowData.fileMetaInfo = this.metaInfo;
    let source = "outbound";
    let isGroupDropDownReq = true;

    if (savedRules !== null || savedRules !== undefined || savedRules !== "") {
      if (ruleType.toLowerCase() === "format") {
        let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format");
        let selBrAssc = selRuleBrAssc;
        if (filteredArr.length > 0) {
          selBrAssc = filteredArr[0];
        }
        this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selRowData.dataType, this.selRowData.attributeName, this.selRowData, viewOnly, this.selRowData.dataType, selBrAssc, source, isGroupDropDownReq, this.selSection);
        this.specialMappingDialog = true;
        return;
      }
      else {
        let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format");
        if (filteredArr.length > 0) {
          if (filteredArr[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName !== ruleType) {
            this.confirmationService.confirm({
              message: "This attribute has been assigned with " + filteredArr[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName + ". If you choose different option that already selected, it will overwrite your earlier configuration. Are you sure you want to continue?",
              accept: () => {
                savedRules = [];
                this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selRowData.dataType, this.selRowData.attributeName, this.selRowData, viewOnly, this.selRowData.dataType, filteredArr[0], source, isGroupDropDownReq, this.selSection);
                this.specialMappingDialog = true;
              },
              reject: () => {
                return false;
              }
            });
          } else {
            this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selRowData.dataType, this.selRowData.attributeName, this.selRowData, viewOnly, this.selRowData.dataType, filteredArr[0], source, isGroupDropDownReq, this.selSection);
            this.specialMappingDialog = true;
          }
        }
        else {
          this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.selRowData.dataType, this.selRowData.attributeName, this.selRowData, viewOnly, this.selRowData.dataType, selRuleBrAssc, source, isGroupDropDownReq, this.selSection);
          this.specialMappingDialog = true;
        }
      }
    }
  }

  getFileAttributeList() {
    this.fileService.getAllOutboundFileAttributes(this.metaInfo.recordId, this.metaInfo.fileVersion, this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
      if (res.data.length !== 0) {
        this.getRuleAttributeList = [];
        this.getRuleAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          if (element.label !== "TransactionDataset") {
          this.getRuleAttributeList.push({
            label: element.label,
            items: element.items,
          });
        }
      }
      }
    }, error => {
      this.toastr.error("Server Error in fetching attribute list.", "Oops!", TOAST_SETTING);
    });
  }

  getSecondaryDataAtrributes() {
    this._ruleEditorService.getSecondaryDataAtrributes().subscribe(res => {
      if (!res.error) {
        this.getRuleSecondaryDataAttributeList = [];
        this.getRuleSecondaryDataAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          this.getRuleSecondaryDataAttributeList.push({
            label: element.label,
            items: element.items,
          });
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Secondary Data Attribute.", "Oops!", TOAST_SETTING);
    });
  }

  attributeMapping: any = {};
  getAttributeList() {
    // this.attrTabLoaderFn.emit(true);
    if (this.attributeMapping.selectedDatatype !== "") {
      const dataType = this.attributeMapping.selectedDatatype;
      this.fileService.getAllAttributes(this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
        if (res.data.length !== 0) {
          this.attributeMapping.validDatatype = true;
          this.attributeMapping.attributeList = [];
          this.attributeMapping.attributeList.push({ label: "Select Data Element", value: "" });
          for (let index = 0; index < res.data.length; index++) {
            let element = res.data[index];
            if (element.isCustom) {
              this.attributeMapping.attributeList.push({ label: element.attributeName, value: element.attributeId, size: element.attributeSize, dataType: element.defaultDataType, isNullAllowed: element.isNullAllowed, isMandatory: !element.isNullAllowed });
              this.ruleAttributeArray.push(element);
            }
          }
        }
      }, error => {

        this.toastr.error("Server Error in fetching attribute list.", "Oops!", TOAST_SETTING);
      });

      this.fileService.getAttributeStandarizedNameListByFileTypeId(this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
        if (!res.error) {
          this.attrDrlRelativeNaming = res.data;
        }
      }, error => {
        this.toastr.error("Server Error in fetching attribute Standardized Name list.", "Oops!", TOAST_SETTING);
      });

      this.fileService.getPackageInfoByFileTypeId(this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
        if (!res.error) {
          this.packageByFileType = res.data;
        } else {

          this.toastr.error("Server Error in fetching FileType Pojo Package details.", "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in fetching  FileType Pojo Package details.", "Oops!", TOAST_SETTING);
      });
    }
  }

  ruleIndex: number = -1;
  /* istanbul ignore next */
  pushRuleToAttribute(resultMap) {
    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    let ruleObj = resultMap.get("rule");
    let lookupObj = resultMap.get("lookup");
    this.ruleIndex = -1;
    if (ruleObj !== null) {
      if (this.ruleIndex === -1) {
        let arr = ["Format", "Hardcode", "Rule"];
        if (this.selRowData.fileAttrBrAssocs !== null && this.selRowData.fileAttrBrAssocs !== undefined) {
          if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format") {
            this.selRowData.fileAttrBrAssocs = this.selRowData.fileAttrBrAssocs.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format");
          } else {
            this.selRowData.fileAttrBrAssocs = this.selRowData.fileAttrBrAssocs.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format");
            this.selRowData.lookupTableFileAssociations = lookupObj;
          }
          this.selRowData.fileAttrBrAssocs.push(ruleObj);
        } else {
          this.selRowData.fileAttrBrAssocs = [ruleObj];
          if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format") {
            this.selRowData.lookupTableFileAssociations = lookupObj;
          }
        }
      } else {
        this.selRowData.fileAttrBrAssocs[this.ruleIndex] = [ruleObj];
        if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format") {
          this.selRowData.lookupTableFileAssociations = lookupObj;
        }
      }
    }
    this.specialMappingDialog = false;
  }

  lookuptableList: any = [];
  getLookupTables() {
    this.lookuptableList.push({ label: "Please Select", value: null });
    this.fileService.getLookupTables(this.metaInfo.recordId, "F", this.metaInfo.masterFileTemplateMetaInfo.fileTypeMetaInfo.fileTypeId, this.metaInfo.fileVersion).subscribe(res => {
      if (!res.error) {
        for (let index = 0; index < res.data.length; index++) {
          let el = res.data[index];
          this.lookuptableList.push({
            label: el.lookupTableName,
            value: {
              name: el.lookupTableName,
              composite: el.composite, lookupKeyDescription: el.lookupKeyDescription
            }
            , id: el.lookupTableId
            , code: el.lookupTableVersion
          });
        }
      }
    }, error => {
      this.toastr.error("Server Error in fetching Lookup tables list.", "Oops!", TOAST_SETTING);
    });
  }

  onNodeExpand(event) {
    let _nodeData = event.node;
    if (_nodeData.children !== undefined) {
      return false;
    }
    _nodeData["children"] = [];
    _nodeData["togglerLoader"] = true;
    this.fileService.getChildrenAttr(this.metaInfo.recordId, this.selSection, _nodeData.data.id).subscribe(res => {
      if (!res.error) {
        _nodeData["children"] = res.data;
        this.treeTableData = [...this.treeTableData];
        _nodeData["togglerLoader"] = false;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  loadNodes(event) {
    this.btnClicked = true;
    this.tabLoader.emit(true);
    this.fileService.getAttrMappingData(this.metaInfo.recordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.tabLoader.emit(false);
        this.treeTableData = res.data;
        this.btnClicked = false;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Attribute List.", "Oops!", TOAST_SETTING);
    });
  }

  mapColDropDown: any = {};
  mapColAllOption: any = {};
  mapColData: any = {};
  getMapColDropDown() {
    this.mapColDropDown["node"] = [
      { "label": "Please Select", "value": null },
      { "value": "Not Applicable", "label": "Not Applicable" }
    ];
    this.fileService.getMapColDropDown(this.metaInfo.recordId, this.selSection).subscribe(res => {
      if (!res.error) {
        this.mapColAllOption = res.data;
        for (let _mValue of res.data) {
          this.mapColDropDown.node.push({
            "label": _mValue.sectionDisplayName,
            "value": _mValue.sectionDisplayName
          });
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting mapped column.", "Oops!", TOAST_SETTING);
    });
  }


  rowEditFlag: boolean = false;
  enableEditMode(rowNode, actionItems) {
    if (this.rowEditFlag === true || this.viewOnly) {
      return false;
    }
    this.actionOverly = actionItems;
    this.mapColData = rowNode;
    this.selRowData = this.mapColData.node.data;
    this.mapColData.node["editMode"] = true;
    this.rowEditFlag = true;
    this.setRedirectFlag(true);
    this.mapColData.node.data["oldData"] = JSON.stringify(this.mapColData.node.data);
    if (this.mapColData.node.data.description === "NULL") {
      this.mapColData.node.data.description = "";
    }
    if (this.mapColData.node.data.dataType.toLowerCase() !== "node") {
      let _dEVal = "Data Element";
      if (this.mapColData.node.data.mappedColumn !== null && this.mapColData.node.data.mappedColumn !== "Not Applicable") {
        _dEVal = this.mapColData.node.data.mappedColumn;
      }
      this.mapColDropDown["other"] = [
        { "label": "Please Select", "value": null },
        { "label": "Not Applicable", "value": "Not Applicable" },
        { "label": "Data Element", "value": _dEVal }
      ];
    }
  }

  addCondDes() {
    this.mandatoryDialog = false;
  }

  cancelCondDes() {
    this.mapColData.node.data.conditionalDescription = this.$conditionalDescription;
    this.mandatoryDialog = false;
  }

  selMapColTableData: any;
  isBtnClicked: boolean = false;
  addMapColData(flow) {
    this.isBtnClicked = true;
    if (this.mapColTableData.length === 0) {
      this.toastr.error("Please select atleast one source element to save.", "Oops!", TOAST_SETTING);
      this.mapColData.node.data["mappedColumnDetailsList"] = [];
      this.isBtnClicked = false;
      return false;
    }
    this.fileService.saveMappedColumnAttr(this.mapColData.node.data.id, this.mapColTableData).subscribe(res => {
      if (!res.error) {
        this.toastr.success(this.mapColData.node.data.displayName + " Data Saved successfully.", "Success!");
        this.isBtnClicked = false;
        if (flow === "save") {
          this.mapColDialog = false;
        } else {
          this.selMapColTab = true;
          this.selSourceTab = false;
        }
        this.selMapColTableData = res.data;
        this.mapColData.node.data["mappedColumnDetailsList"] = res.data;
        let _selMapColVal = res.data.filter((obj) => obj.isActive);
        this.selMapColVal = _selMapColVal[0];
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Mapped Column Data.", "Oops!", TOAST_SETTING);
    });
  }

  removeEle(rowData, rowIndex) {
    this.mapColTableData.splice(rowIndex, 1);
    this.mapColTableData = [...this.mapColTableData];
    this.populateDataElement();
  }

  addMapCol() {
    let oldAttrAssocId = this.selRowData.attributeAssocId;
    this.isElementAssoUpdated = false;
    if (oldAttrAssocId && this.selMapColVal && this.selMapColVal.attributeAssocId !== oldAttrAssocId) {
      this.isElementAssoUpdated = true;
      this.confirmationService.confirm({
        message: "Previously Selected Attribute has been changed. Old rule associated with that attribute will be removed. Are you sure you want to continue?",
        accept: () => {
          this.selRowData.fileAttrBrAssocs = null;
          this.selRowData.lookupTableFileAssociations = null;
          this.successAddMapCol(oldAttrAssocId);
        },
        reject: () => {
          return false;
        }
      });
    } else {
      this.successAddMapCol(oldAttrAssocId);
    }
  }

  successAddMapCol(oldAttrAssocId) {
    if (this.selMapColVal !== undefined) {
      this.selRowData.mappedColumn = this.selMapColVal === null ? "Data Element" : this.selMapColVal.source + " - " + this.selMapColVal.name;
      this.selRowData.selMappedColumnSource = this.selMapColVal === null ? null : this.selMapColVal.source;
      this.selRowData.attributeName = this.selMapColVal === null ? null : this.selMapColVal.name;
      this.selRowData.attributeAssocId = this.selMapColVal === null ? null : this.selMapColVal.attributeAssocId;
    }
    if (oldAttrAssocId !== null) {
      this.selRowData.oldAttributeAssocId = oldAttrAssocId;
    }
    if (this.selMapColVal !== null && this.selMapColVal !== undefined) {
      this.selMapColVal.isActive = true;
      this.selMapColVal.oldAttributeAssocId = oldAttrAssocId;
      this.selRowData.recordId = this.selMapColVal.recordId;
      this.selRowData.ftaaId = this.selMapColVal.ftaaId;
      this.selRowData["selMappedColumn"] = this.selMapColVal;
      this.selRowData.mappedColumnId = this.selMapColVal.id;
    } /* istanbul ignore next */ else {
      this.selRowData.mappedColumnId = null;
      this.selRowData["selMappedColumn"] = null;
      this.selRowData.mappedColumnDetailsList.forEach((obj) => {
        obj.isActive = false;
      });
    }
    this.mapColDialog = false;
    this.selMapColTab = false;
    this.selSourceTab = true;
    this.mapColDropDown["other"] = [
      { "label": "Please Select", "value": null },
      { "label": "Not Applicable", "value": "Not Applicable" },
      { "label": "Data Element", "value": this.mapColData.node.data.mappedColumn }
    ];
  }
  removeRule(rowData) {
    if (rowData.mappedColumn === null || rowData.mappedColumn === "Not Applicable") {
      this.selRowData.mappedColumnId = null;
      this.selRowData["selMappedColumn"] = null;
      this.selRowData.attributeAssocId = null;
      this.selRowData.fileAttrBrAssocs = null;
    }
  }




  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipAttribute = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipAttribute[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // Change Rule Reorder
  outBoundRuleReorderModel: boolean;
  isRuleOrderAvail: boolean = false;
  selReOrderValModel = 1;
  selReOrderNotesModel;
  orderViewOnly: boolean = true;

  ruleReorderdata: any;
  getAllIdisRulePrioritySequence() {
    this.fileSetupService.getAllIdisRulePrioritySequence().subscribe(res => {
      if (!res.error) {
        this.ruleReorderdata = res.data;
      }
    }, error => {
      this.toastr.error("Server Error in fetching Rule Priority list.", "Oops!", TOAST_SETTING);
    });
  }

  openRuleReorderModel(row, overlaypanel, viewOnly, e) {
    this.orderViewOnly = viewOnly;
    this.outBoundRuleReorderModel = true;
    let savedBrAssoc;
    let reOrdVal = 1;
    let reOrdRes = "";

    if (!row) {
      row = this.selRowData;
    }
    this.selectedAttributeForRule = row.attributeName;
    savedBrAssoc = row.fileAttrBrAssocs;

    savedBrAssoc.forEach((fileBrAssoc, index) => {
      if (fileBrAssoc.ruleExecutionSequence !== undefined) {
        reOrdVal = fileBrAssoc.ruleExecutionSequence;
      }
      if (fileBrAssoc.ruleExecutionComment !== undefined) {
        reOrdRes = fileBrAssoc.ruleExecutionComment;
      }
    });
    this.selReOrderValModel = reOrdVal;
    this.selReOrderNotesModel = reOrdRes;
    this.selRowData = row;
    if (viewOnly) {
      e.stopPropagation();
    }
  }

  saveruleReorder(ruleReorderForm: NgForm) {
    this.outBoundRuleReorderModel = false;
    let selRow;
    if (this.selRowData && this.selRowData.fileAttrBrAssocs && this.selRowData.fileAttrBrAssocs.length) {
      this.selRowData.fileAttrBrAssocs.forEach((fileBrAssoc: any) => {
        fileBrAssoc.ruleExecutionSequence = ruleReorderForm.value.selReOrderVal;
        fileBrAssoc.ruleExecutionComment = ruleReorderForm.value.selReOrderNotes;
      });
    }
    ruleReorderForm.resetForm();
  };

  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @Output() pushRedirectFlag = new EventEmitter();

  // Set Modified Data Flag
  setRedirectFlag(flag) {
    this.redirectFlag = flag;
    this.pushRedirectFlag.emit(flag);
  }
  // Get confirmation for navigate without savig data

}
