import { Component, OnInit, OnChanges, SimpleChanges, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DataTableModule } from "primeng/components/datatable/datatable";
import { PickListModule } from "primeng/primeng";
import { PanelModule } from "primeng/primeng";
import { SelectItem } from "primeng/primeng";
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { ToastsManager } from "ng2-toastr";
import { NgForm } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { forEach } from "@angular/router/src/utils/collection";
import { MultiSelectModule } from "primeng/components/multiselect/multiselect";
import { MenuItem } from "primeng/components/common/api";
import { Message } from "primeng/components/common/message";
import { ConfirmationService } from "primeng/components/common/api";
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/observable/forkJoin";
import { AlRuleEditorComponent } from "../../al-rule-editor/al-rule-editor.component";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING, confAcceptLabel, confRejectLabel, confMessage } from "../../../../global";

@Component({
  selector: "al-file-attribute-mapping",
  templateUrl: "./al-file-attribute-mapping.component.html",
  styleUrls: ["./al-file-attribute-mapping.component.scss"],
  providers: [ConfirmationService, AlRuleEditorService]
})
export class AlFileAttributeMappingComponent implements OnInit {

  constructor(
    private fileSetupService: FileSetupService,
    public toastr: ToastsManager,
    private router: Router,
    private confirmationService: ConfirmationService,
    private _ruleEditorService: AlRuleEditorService,
    private toolTipUtils: ToolTipUtilService
  ) {

  }

  @Input() metaInfo;
  @Input() viewOnly;
  @Input() templateType;
  activeIndex: number = 0;
  selSection: string = "H";
  items: MenuItem[];
  msgs: Message[] = [];
  @Output("tabLoader") tabLoader = new EventEmitter();
  btnClicked: boolean = false;

  editFormData: any;
  fileSetupObj: any = {};
  fileSetup: any = {};
  headerAttributeMappingData: any = [];
  detailAttributeLevel0: any = [];
  trailerAttributeMappingData: any = [];
  headerSectionMappingData: any = [];
  detailSectionLevel0: any = [];
  trailerSectionMappingData: any = [];
  currentAttributeMappingData: any = [];
  currentSectionMappingData: any = [];
  masterHeaderSectionMappingInfo: any = [];
  masterDetailSectionMappingInfo: any = [];
  masterTrailerSectionMappingInfo: any = [];
  masterHeaderAttrMappingInfo: any = [];
  masterDetailAttrMappingInfo: any = [];
  masterTrailerAttrMappingInfo: any = [];
  childHeaderSectionMappingInfo: any = [];
  childDetailSectionMappingInfo: any = [];
  childTrailerSectionMappingInfo: any = [];
  childHeaderAttrMappingInfo: any = [];
  childDetailAttrMappingInfo: any = [];
  childTrailerAttrMappingInfo: any = [];
  fileTypeId: any;
  fixedWidth: boolean = false;

  // Rule Editor
  specialMappingDialog: boolean = false;
  selectedAttributeForRule: any = "";
  ruleTemplatesGroupMapping: any = {};
  isFormatAvail: boolean = true;
  getRuleAttributeList: any = [];
  getRuleSecondaryDataAttributeList: any = [];
  ruleAttributeArray: any = [];
  isDoNotMapAvail: boolean = true;
  selAttrDataType: any = "";
  selectedRow: any;
  /* ToolTip Text display */
  toolTipFileAttribute: any = [];
  tooltipResult: any;
  pageID: number = 18;
  // Cloning
  cloneAllowed: boolean = false;
  @Output() updateDateAndUpdateBy = new EventEmitter;
  @ViewChild(AlRuleEditorComponent) ruleEditorComp;
  @Output() pageNavigation = new EventEmitter();

  attributeValueMap = new Map();
  primaryDataSet = {};
  secondaryDataModel: any = {};

  ngOnInit() {
    this.btnClicked = true;
    this.items = [{
      label: "Header",
      command: (event: any) => {
        this.activeIndex = 0;
        this.msgs.length = 0;
        this.msgs.push({ severity: "info", summary: "First Step", detail: event.item.label });
      }
    },
    {
      label: "Detail Row",
      command: (event: any) => {
        this.activeIndex = 1;
        this.msgs.length = 0;
        this.msgs.push({ severity: "info", summary: "Seat Selection", detail: event.item.label });
      }
    },
    {
      label: "Trailer",
      command: (event: any) => {
        this.activeIndex = 2;
        this.msgs.length = 0;
        this.msgs.push({ severity: "info", summary: "Pay with CC", detail: event.item.label });
      }
    }];
    this.populateChildAttr(this.metaInfo.recordId, this.metaInfo.fileVersion);

    for (let i = 1; i <= 50; i++) {
      this.cloneDropDown.push({ label: i, value: i });
    }
    this.getLookupTables();
    this.getToolTipTextDetails();
  }


  attributeMapping: any = {};
  ruleCustomDefinedAttributeArray: any = [];
  attrDrlRelativeNaming: any = {};
  packageByFileType: any;
  getAttributeList() {
    this.fileSetupService.getAllAttributes(this.metaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
      this.attributeMapping.attributeList = [];
      this.ruleCustomDefinedAttributeArray = [];
      this.attributeMapping.attributeList.push({ label: "Select Data Element", value: "" });
      if (res.data.length !== 0) {
        this.attributeMapping.validDatatype = true;
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          if (element.isCustom) {
            this.attributeMapping.attributeList.push({ label: element.attributeName, value: element.attributeId, size: element.attributeSize, dataType: element.defaultDataType, isNullAllowed: element.isNullAllowed, isMandatory: !element.isNullAllowed });
            this.ruleCustomDefinedAttributeArray.push(element);
          }
        }
      }
      this.tabLoader.emit(false);
      this.btnClicked = false;
    }, error => {
      this.toastr.error("Server Error in fetching attribute list.", "Oops!", TOAST_SETTING);
    });
    this.fileSetupService.getAttributeStandarizedNameListByFileTypeId(this.metaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
      if (!res.error) {
        this.attrDrlRelativeNaming = res.data;
      }
    }, error => {
      this.toastr.error("Server Error in fetching attribute Standardized Name list.", "Oops!", TOAST_SETTING);
    });
    this.fileSetupService.getPackageInfoByFileTypeId(this.metaInfo.fileTypeMetaInfo.fileTypeId).subscribe(res => {
      if (!res.error) {
        this.packageByFileType = res.data;
      } else {
        this.toastr.error("Server Error in fetching FileType Pojo Package details.", "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in fetching  FileType Pojo Package details.", "Oops!", TOAST_SETTING);
    });
  }

  lookupTables: any = [];
  selectedLookupTable: any;
  getLookupTables() {
    this.fileSetupService.getLookupTables(this.metaInfo.recordId, this.templateType, this.metaInfo.fileTypeMetaInfo.fileTypeId, this.metaInfo.fileVersion).subscribe(res => {
      if (!res.error) {
        this.lookupTables = res.data;
        this.attributeMapping.lookuptable = [];
        this.attributeMapping.lookuptable.push({ label: "Please Select", valule: null });
        for (let index = 0; index < this.lookupTables.length; index++) {
          let el = this.lookupTables[index];
          this.attributeMapping.lookuptable.push({
            label: el.lookupTableName,
            value: {
              name: el.lookupTableName,
              composite: el.composite, lookupKeyDescription: el.lookupKeyDescription
            },
            id: el.lookupTableId,
            code: el.lookupTableVersion
          });
        }
        this.selectedLookupTable = [];
      }
    }, error => {
      this.toastr.error("Server Error in fetching Lookup tables list.", "Oops!", TOAST_SETTING);
    });



    this.attributeMapping.lookuptable = [];
    this.attributeMapping.lookuptable.push({ label: "Please Select", valule: null });
    for (let index = 0; index < this.lookupTables.length; index++) {
      let el = this.lookupTables[index];
      this.attributeMapping.lookuptable.push({
        label: el.lookupTableName,
        value: {
          name: el.lookupTableName,
          composite: el.composite, lookupKeyDescription: el.lookupKeyDescription
        }
        , id: el.lookupTableId
        , code: el.lookupTableVersion
      });
    }
    this.selectedLookupTable = [];


  }

  // Attribute
  masterTplData: any;
  masterAttrMappingInfo: any = [];
  selMstrTplId: number;
  childTplData: any;
  childAttrMappingInfo: any = [];
  initFTAttrBrAssocs: any = [];
  attributeLoader = true;

  populateChildAttr(id, version, updateVersion?, index?) {
    this.fileSetupService.editFiles(id, version, true, true, this.selCloneId).subscribe(res => {
      this.ruleAttributeArray = [];
      this.editFormData = res.data;
      this.fileSetupObj = res.data.metaInfo;
      this.getAllRuleTemplates();
      this.getAllIdisRulePrioritySequence();
      this.getAttributeList();
      this.fileSetup.fileVersion = this.editFormData.metaInfo.fileVersion;
      this.fileSetup.fileTplApprovalStatus = this.editFormData.metaInfo.approvalStatus;
      this.fileTypeId = this.editFormData.metaInfo.fileTypeMetaInfo.fileTypeId;
      this.fileSetup.isActive = this.editFormData.metaInfo.isActive;
      this.fileSetup.fileTplApprovalComment = "";
      this.getSecondaryDataAtrributes();
      this.getMasterAttributeList(this.editFormData.metaInfo.fileIdGenerator.fileId);
      if (this.editFormData.metaInfo.approvalStatus === 2) {
        this.fileSetup.fileTplEditorComment = this.editFormData.metaInfo.editorComment;
      } else {
        this.fileSetup.fileTplEditorComment = "";
      }
      this.fileSetup.recordId = this.editFormData.metaInfo.recordId;
      this.fileSetup.employerId = this.fileSetupObj.employerId;
      this.attributeMapping.fileId = this.editFormData.metaInfo.fileIdGenerator.fileId;
      this.selMstrTplId = this.editFormData.metaInfo.masterFileTemplateMetaInfo.masterFileTemplateId;
      if (this.editFormData.metaInfo.fileFormatSupported.fileFormatName === "FIXED_WIDTH") {
        this.fixedWidth = true;
      } else {
        this.fixedWidth = false;
      }
      this.fileSetup.fileTypeMetaInfo = this.fileSetupObj.fileTypeMetaInfo;
      this.headerSectionMappingData = this.editFormData.headerSectionMappingInfo;
      this.headerSectionMappingData.forEach((element, index) => {
        this.headerAttributeMappingData = element.fileAttributeAssociations;
        this.headerAttributeMappingData.forEach((childElement, childIndex) => {
          this.headerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
          this.pushRuleAttributeList(childElement.attributeDictionary);
        });
      });
      this.detailSectionLevel0 = this.editFormData.detailSectionMappingInfo;
      this.detailSectionLevel0.forEach((element, index) => {
        this.detailAttributeLevel0 = element.fileAttributeAssociations;
        this.detailAttributeLevel0.forEach((childElement, childIndex) => {
          this.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
          this.pushRuleAttributeList(childElement.attributeDictionary);
        });
      });
      this.trailerSectionMappingData = this.editFormData.trailerSectionMappingInfo;
      this.trailerSectionMappingData.forEach((element, index) => {
        this.trailerAttributeMappingData = element.fileAttributeAssociations;
        this.trailerAttributeMappingData.forEach((childElement, childIndex) => {
          this.trailerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
          this.pushRuleAttributeList(childElement.attributeDictionary);
        });
      });
      this.cloneAllowed = this.fileSetupObj.fileTypeMetaInfo.cloneAllowed;
      this.addAngular2AccordionGroup(0);
      this.addAngular2AccordionGroup(1);
      this.addAngular2AccordionGroup(2);

      this.cloneIdList = [
        { label: this.detailSectionLevel0[0].sectionDisplayName, value: 0 }
      ];
      let cloneNumbers = res.data.cloneInfo;
      for (let _cn of cloneNumbers) {
        this.cloneIdList.push({
          label: _cn.cloneName,
          value: _cn.cloneNum
        });
      }



    }, error => {
      this.toastr.error("Server Error in fetching attributes.", "Oops!", TOAST_SETTING);
    });




  }

  pushRuleAttributeList(fileElementAttribute) {
    if (!fileElementAttribute.isCustom) {
      this.ruleAttributeArray.push(fileElementAttribute);
    }
  }

  groups: Array<any> = [];
  addAngular2AccordionGroup(index) {
    let sectionIdentifierVal = "H";
    let sectionNameVal = "Header";
    if (index === 0) {
      this.currentSectionMappingData = this.headerSectionMappingData;
      this.currentAttributeMappingData = this.headerAttributeMappingData;
      sectionIdentifierVal = "H";
      sectionNameVal = "Header";
    } else if (index === 1) {
      this.currentSectionMappingData = this.detailSectionLevel0;
      this.currentAttributeMappingData = this.detailAttributeLevel0;
      sectionIdentifierVal = "D";
      sectionNameVal = "Detail";
    } else {
      this.currentSectionMappingData = this.trailerSectionMappingData;
      this.currentAttributeMappingData = this.trailerAttributeMappingData;
      sectionIdentifierVal = "T";
      sectionNameVal = "Trailer";
    }
    if (this.currentSectionMappingData.length === 0) {
      let countNo = this.groups.length + 1;
      this.currentSectionMappingData.push({
        fileIdGenerator: {
          fileId: this.attributeMapping.fileId
        },
        templateSections: {
          sectionName: sectionNameVal
        },
        fileCompliantSectionShortName: sectionIdentifierVal,
        parentFsaId: 0,
        fileVersion: this.metaInfo.recordId === undefined ? 1 : this.fileSetup.fileVersion, // change dynamically
        sequence: 0,
        isRepeatable: false,
        isMandatory: false,
        maxRepeatCount: 0,
        fileAttributeAssociations: [this.getDefaultAttribute()],
        assocChildSectionList: []
      });
    }
    let _count = this.currentAttributeMappingData.filter((_atrObj) => _atrObj.attributeDictionary.isCustom === true);
    if (_count.length === 0) {
      this.addAttributeRow();
    }
  }

  fileSectionAttribute: string = "H";
  getDefaultAttribute() {
    return {
      fileId: this.metaInfo.recordId === undefined ? this.attributeMapping.fileId : this.editFormData.metaInfo.fileIdGenerator.fileId,
      fileIdentifier: this.metaInfo.recordId,
      isMandatory: false,
      associatedToRepositoryDb: null,
      needsLookupTable: false,
      associatedToRepositoryTable: null,
      attributeRowPosition: null,
      attributeStartPosition: null,
      attributeEndPosition: null,
      attributeSize: null,
      masterFileTemplateVersion: 1,
      attributeDictionary: {
        attributeId: null,
        attributeName: null,
        isCustom: true
      },
      fileFormatCompliantAttributeName: null,
      // fileVersion: 1,
      fileVersion: this.metaInfo.recordId === undefined ? 1 : this.fileSetup.fileVersion,
      fileSectionIdentifier: this.fileSectionAttribute,
      dataType: null,
      fileAttrBrAssocs: [],
      lookupTableFileAssociations: [],
      isUniqueForFile: true,
      isHardcoded: false,
      isSpecialRulesOnly: false,
      selectedAttribute: "",
      isInherited: false
    };
  }

  selIndex: number;
  addAttributeRow(position?) {
    if (position === undefined) {
      this.currentAttributeMappingData.push(this.getDefaultAttribute());
    } else {
      let addRowPosition = this.selIndex;
      if (position === true) {
        addRowPosition = addRowPosition + 1;
      }
      this.currentAttributeMappingData.splice(addRowPosition, 0, this.getDefaultAttribute());
    }
  }

  isCustomDefined: boolean = false;
  isInherited: boolean;
  selSectionIndex: number;
  selTabIndex: number;
  isRuleOrderAvail: boolean = false;

  attachRuleAndLookup(event, row, index, overlaypanel, tabIndex, sectionIndex, id) {
    this.isCustomDefined = row.attributeDictionary.isCustom;
    overlaypanel.toggle(event);
    if (row.dataType !== null && row.dataType !== undefined && row.dataType.toUpperCase() === "BIT") {
      this.isFormatAvail = false;
    }
    else {
      this.isFormatAvail = true;
    }

    if (row.isMandatory !== null && row.isMandatory === true) {
      this.isDoNotMapAvail = false;
    } else {
      this.isDoNotMapAvail = true;
    }

    if (tabIndex === 0) {
      this.currentAttributeMappingData = this.headerSectionMappingData[sectionIndex].fileAttributeAssociations;
    } else if (tabIndex === 1) {
      this.getObjectName(id);
    } else if (tabIndex === 2) {
      this.currentAttributeMappingData = this.trailerSectionMappingData[sectionIndex].fileAttributeAssociations;
    }
    this.isInherited = row.isInherited;
    this.isTodo = row.toDo;

    this.attributeMapping.selected = [];
    this.attributeMapping.selected.push(row);
    this.selectedRow = row;
    this.attributeMapping.selectedIndex = index;
    this.selSectionIndex = sectionIndex;
    this.selIndex = index;
    this.selTabIndex = tabIndex;
    this.isRuleOrderAvail = false;
    if (row !== "undefined" && row.fileAttrBrAssocs !== "undefined" && row.fileAttrBrAssocs.length > 0) {
      row.fileAttrBrAssocs.forEach((fileBrAssoc, index) => {
        if (fileBrAssoc.droolsBusinessRulesDecisionTable !== null && fileBrAssoc.droolsBusinessRulesDecisionTable !== "undefined") {
          this.isRuleOrderAvail = true;
        }
      });
    }
  }
  getObjectName(id) {
    this.currentSectionMappingData = this.detailSectionLevel0;
    let splittedIndexArray: any = [];
    if (id !== null && id !== undefined) {
      splittedIndexArray = id.split("_");
      if (splittedIndexArray !== null && splittedIndexArray.length > 1) {
        splittedIndexArray.forEach((element, index) => {
          if (index > 0) {
            this.currentAttributeMappingData = this.currentSectionMappingData[splittedIndexArray[index]].fileAttributeAssociations;
            this.currentSectionMappingData = this.currentSectionMappingData[splittedIndexArray[index]].assocChildSectionList;
          }
        });
      }
    }
  }

  /*Rule editor*/
  openRuleEditor(overlaypanel: OverlayPanel, ruleType, viewOnly) {
    this.preparePrimaryDataSet();
    this.getMasterAttributeList(this.editFormData.metaInfo.fileIdGenerator.fileId);
    if (overlaypanel !== null) {
      overlaypanel.hide();
    }

    if (this.activeIndex === 0) {
      this.selSection = "H";
    } else if (this.activeIndex === 1) {
      this.selSection = "D";
    } else if (this.activeIndex === 2) {
      this.selSection = "T";
    }

    let source = "inbound";
    let isGroupDropDownReq = false;
    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    this.selectedAttributeForRule = this.currentAttributeMappingData[applyRuleAttributeIndex].attributeDictionary.attributeName;
    let savedRules = this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs;
    this.selAttrDataType = this.currentAttributeMappingData[applyRuleAttributeIndex].dataType;
    if ((savedRules !== null || savedRules !== undefined || savedRules !== "") && savedRules.length) {
      if (savedRules.length === 1 && savedRules[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "DoNotMap") {
        this.confirmationService.confirm({
          message: "This attribute has been assigned with " + savedRules[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName + ". If you choose different option that already selected, it will overwrite your earlier configuration. Are you sure you want to continue?",
          accept: () => {
            savedRules = [];
            let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "DoNotMap");
            let selBrAssc = null;
            if (filteredArr.length > 0) {
              selBrAssc = filteredArr[0];
            }
            if (!this.viewOnly) {
              this.setRedirectFlag(true);
            }
            this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.splice(0, this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.length);
            this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, selBrAssc, source, isGroupDropDownReq, this.selSection);
            this.specialMappingDialog = true;
          },
          reject: () => {
            return false;
          }
        });
      } else {
        if (ruleType.toLowerCase() === "format") {
          let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format");
          let selBrAssc = null;
          if (filteredArr.length > 0) {
            selBrAssc = filteredArr[0];
          }
          if (!this.viewOnly) {
            this.setRedirectFlag(true);
          }
          this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, selBrAssc, source, isGroupDropDownReq, this.selSection);
          this.specialMappingDialog = true;
          return;
        }
        else {
          let filteredArr = savedRules.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format" && el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "markastodo");
          if (filteredArr.length > 0) {
            if (filteredArr[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName !== ruleType) {
              this.confirmationService.confirm({
                message: "This attribute has been assigned with " + filteredArr[0].droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName + ". If you choose different option that already selected, it will overwrite your earlier configuration. Are you sure you want to continue?",
                accept: () => {
                  savedRules = [];
                  if (!this.viewOnly) {
                    this.setRedirectFlag(true);
                  }
                  this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, filteredArr[0], source, isGroupDropDownReq, this.selSection);
                  this.specialMappingDialog = true;
                },
                reject: () => {
                  return false;
                }
              });
            } else {
              if (!this.viewOnly) {
                this.setRedirectFlag(true);
              }
              this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, filteredArr[0], source, isGroupDropDownReq, this.selSection);
              this.specialMappingDialog = true;
            }
          }
          else {
            if (!this.viewOnly) {
              this.setRedirectFlag(true);
            }
            this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, null, source, isGroupDropDownReq, this.selSection);
            this.specialMappingDialog = true;
          }
        }
      }
    }
    else {
      if (!this.viewOnly) {
        this.setRedirectFlag(true);
      }
      this.ruleEditorComp.reGenerateUI(savedRules, ruleType, this.currentAttributeMappingData[applyRuleAttributeIndex].dataType, this.selectedAttributeForRule, this.currentAttributeMappingData[applyRuleAttributeIndex], viewOnly, this.selAttrDataType, null, source, isGroupDropDownReq, this.selSection);
      this.specialMappingDialog = true;
    }
  };

  preparePrimaryDataSet() {
    // clear the map for refelcting latest changes on attribute.
    this.attributeValueMap.clear();
    this.headerAttributeMappingData.forEach((childElement, childIndex) => {
      this.attributeValueMap.set(childElement.attributeDictionary.attributeName, childElement.attributeTestData);
    });
    this.detailAttributeLevel0.forEach((childElement, childIndex) => {
      this.attributeValueMap.set(childElement.attributeDictionary.attributeName, childElement.attributeTestData);
    });
    this.trailerAttributeMappingData.forEach((childElement, childIndex) => {
      this.attributeValueMap.set(childElement.attributeDictionary.attributeName, childElement.attributeTestData);
    });

    this.attributeValueMap.forEach((value, key) => {
      if (value === undefined || value === null) {
        value = ""; // Replace null with empty string.
      } else {
        value = value.replace(/<blank>/gi, ""); // Replace <blank> with "".
      }
      this.primaryDataSet[this.attrDrlRelativeNaming[key]] = value;
    });

    let primaryDataAttr = this.packageByFileType.filter(packageInfo =>
      packageInfo.packageType === "PRIMARY_DATA_ATTRIBUTE"
    )[0];
    this.primaryDataSet["@class"] = primaryDataAttr.packageName + "." + primaryDataAttr.className;
  }

  getMasterAttributeList(fileId) {
    this.fileSetupService.getAllMasterAttributes(this.metaInfo.recordId, this.metaInfo.fileVersion, this.fileTypeId).subscribe(res => {
      if (res.data.length !== 0) {
        this.getRuleAttributeList = [];
        this.getRuleAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          this.getRuleAttributeList.push({
            label: element.label,
            value: element.value,
            drlValue: element.drlValue
          });
        }
      }
    }, error => {
      this.toastr.error("Server Error in fetching attribute list.", "Oops!", TOAST_SETTING);
    });
  }

  addNewAttributeRow(overlaypanel, position) {
    this.addAttributeRow(position);
    overlaypanel.hide();
  }

  setSelectedAttrDetails(selectedAttr, currentObj) {
    if (!this.viewOnly) {
      this.setRedirectFlag(true);
    }
    let result = this.checkAttributePresence(selectedAttr, currentObj, this.currentAttributeMappingData);
    if (!result) {
      return result;
    }

    if (this.activeIndex === 0) {  // header
      let dtlResult = this.checkAttributePresence(selectedAttr, currentObj, this.detailAttributeLevel0);
      if (!dtlResult) {
        return dtlResult;
      }

      let trailerResult = this.checkAttributePresence(selectedAttr, currentObj, this.trailerAttributeMappingData);
      if (!trailerResult) {
        return trailerResult;
      }
    } else if (this.activeIndex === 1) { // details section
      let headerResult = this.checkAttributePresence(selectedAttr, currentObj, this.headerAttributeMappingData);
      if (!headerResult) {
        return headerResult;
      }

      let trailerResult = this.checkAttributePresence(selectedAttr, currentObj, this.trailerAttributeMappingData);
      if (!trailerResult) {
        return trailerResult;
      }
    } else if (this.activeIndex === 2) { // trailer section
      let headerResult = this.checkAttributePresence(selectedAttr, currentObj, this.headerAttributeMappingData);
      if (!headerResult) {
        return headerResult;
      }

      let dtlResult = this.checkAttributePresence(selectedAttr, currentObj, this.detailAttributeLevel0);
      if (!dtlResult) {
        return dtlResult;
      }

    }

    let selAttrDictObj = this.attributeMapping.attributeList.filter(obj => obj.value === selectedAttr);
    if (selAttrDictObj.length > 0) {
      currentObj.attributeDictionary.attributeId = selAttrDictObj[0].value;
      currentObj.attributeDictionary.attributeName = selAttrDictObj[0].label;
      currentObj.attributeSize = selAttrDictObj[0].size;
      currentObj.dataType = selAttrDictObj[0].dataType;
      currentObj.isMandatory = selAttrDictObj[0].isMandatory;
    }
  }

  checkAttributePresence(selectedAttr, currentObj, attributeMappingList) {
    let selectedObj = attributeMappingList.filter(obj => obj.attributeDictionary.attributeId === selectedAttr);
    if (selectedObj.length > 0 && currentObj.selectedAttr !== selectedAttr) {
      this.toastr.error("The selected data element is already in use!", "Oops!", TOAST_SETTING);
      currentObj.attributeDictionary = {
        attributeId: null,
        attributeName: null,
        isCustom: true
      };
      setTimeout(() => {
        currentObj.attributeSize = null;
        currentObj.dataType = null;
        currentObj.isMandatory = false;
        currentObj.selectedAttribute = null;
      }, 50);
      return false;
    } else {
      return true;
    }
  }

  removeAttribute(overlaypanel, id?) {
    overlaypanel.hide();
    if (this.activeIndex === 0) {
      this.fileSectionAttribute = "H";
      this.currentAttributeMappingData = this.headerSectionMappingData[this.selSectionIndex].fileAttributeAssociations;
    } else if (this.activeIndex === 1) {
      this.fileSectionAttribute = "D";
      this.getObjectName(id);
    } else if (this.activeIndex === 2) {
      this.fileSectionAttribute = "T";
      this.currentAttributeMappingData = this.trailerSectionMappingData[this.selSectionIndex].fileAttributeAssociations;
    }
    let _count = this.currentAttributeMappingData.filter((_atrObj) => _atrObj.attributeDictionary.isCustom === true);
    if (_count.length === 1) {
      if (_count[0].selectedAttribute === "") {
        this.toastr.error("Default row from list cannot be removed ", "Oops!", TOAST_SETTING);
        return false;
      }
    }
    let faaId = this.currentAttributeMappingData[this.selIndex].faaId;
    if (faaId !== null && faaId !== undefined) {
      this.confirmationService.confirm({
        message: " Remove attribute action will remove the entry of this attribute association with this template permanently. This attribute may be associated with lookup table or rule, that association will also be removed.Are you sure that you want to delete this attribute?",
        accept: () => {
          this.fileSetupService.removeAttribute(faaId, this.metaInfo.recordId).subscribe(res => {
            if (!res.error) {
              this.updateDateAndUpdateBy.emit(res.data);
              this.currentAttributeMappingData.splice(this.selIndex, 1);
              if (_count.length === 1) {
                this.currentAttributeMappingData[this.selIndex] = this.getDefaultAttribute();
              }
              this.toastr.success("File attribute mapping deleted successfully.", "Success!");
            } else {
              this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            }
          }, error => {
            this.toastr.error("Server Error in removing attribute.", "Oops!", TOAST_SETTING);
          });
        }
      });
    } else {
      this.currentAttributeMappingData.splice(this.selIndex, 1);
      if (_count.length === 1) {
        this.currentAttributeMappingData[this.selIndex] = this.getDefaultAttribute();
      }
    }
  }

  isTodo: boolean = false;
  markAsTodo(overlaypanel, isTodo) {
    overlaypanel.hide();
    this.tabLoader.emit(true);
    this.selectedRow["toDo"] = isTodo;

    const attributeAssociation = {
      faaId: this.selectedRow.faaId,
      toDo: isTodo
    };

    this.fileSetupService.markAsTodo(attributeAssociation).subscribe(res => {
      this.tabLoader.emit(false);
      if (!res.error) {
        this.toastr.success((isTodo ? "Marked " : "Removed mark ") + "as todo successfully.", "Success!");
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error while" + (isTodo ? " remove" : "") + " mark as todo.", "Oops!", TOAST_SETTING);
      this.tabLoader.emit(false);
    });
  }

  getFileAttrBrAssocs(flag) {
    let secondarayDataFinalAttr: any = {};
    let standardizedFinalAttr: any = [];
    return {
      "businessRuleVersion": 1,
      "isCurrent": true,
      "ruleExecutionComment": "",
      "ruleExecutionSequence": 1,
      "droolsBusinessRulesDecisionTable": {
        "isCurrent": true,
        "droolsBusinessRuleVersion": 1,
        "droolsBusinessRuleName": "Mix_Template",
        "droolsBusinessRuleDrlFileContent": null,
        "droolsBusinessRuleUiJsonText": null,
        "droolsBusinessRulePreDrlText": "MarkAsToDo",
        "isDraft": flag,
        "droolsBusinessRuleGroup": {
          "droolsBusinessRuleGroupId": 12,
          "droolsBusinessRuleGroupName": "MarkAsToDo"
        },
        "standardizedAttrLst": standardizedFinalAttr,
        "secondaryDataAttrLst": secondarayDataFinalAttr
      }
    };
  }

  allowCloning: boolean = false;
  next(index) {
    this.restrictAttr = false;
    if (index === 3) {
      if (this.editFormData.metaInfo.approvalStatus === 1) {
        this.fileSetup.fileTplEditorComment = "";
      }
      this.pageNavigation.emit();
    }
    else {
      if (this.redirectFlag) {
        this.confirmationService.confirm({
          message: this.confMessage,
          accept: () => {
            this.activeIndex++;
            this.onChange(index);
            this.setCloneOptions();
            this.setRedirectFlag(false);
          }
        });
      } else {
        this.activeIndex++;
        this.onChange(index);
        this.setCloneOptions();
      }
    }
  }
  onChange(index) {
    let ele = document.querySelectorAll(".steps-custom ul li");
    if (this.activeIndex >= 0) {
      ele[this.activeIndex - 1].classList.add("stepsCompleted");
    }
  }
  dropDownValue(value, obj) {
    this.setRedirectFlag(true);
    obj.sectionDisplayName = value.currentTarget.value;
  }

  hasNegativeNumbers: boolean = false;
  checkNegativeValue(event, mappedObj, validateWidth) {
    this.hasNegativeNumbers = false;
    if (event.target.value !== null && event.target.value !== "") {
      if (event.target.value <= 0) {
        this.toastr.error("Accepts values greater than 0", "Oops!", TOAST_SETTING);
        this.hasNegativeNumbers = true;
        event.target.value = "";
        event.target.focus();
      }
    }
    if (validateWidth === true && mappedObj !== null) {
      if (mappedObj.attributeEndPosition < mappedObj.attributeStartPosition) {
        mappedObj.attributeEndPosition = mappedObj.attributeStartPosition;
      }
    }
    if (!this.viewOnly) {
      this.setRedirectFlag(true);
    }
  }
  warningMsg: string;
  getConfirmation(event, selectedAttr) {
    if (!this.viewOnly) {
      this.setRedirectFlag(true);
    }
    let isNullAllowed = selectedAttr.attributeDictionary.isNullAllowed;
    if (isNullAllowed === undefined) {
      let selectedObj = this.attributeMapping.attributeList.filter(obj => obj.value === selectedAttr.selectedAttribute);
      isNullAllowed = selectedObj[0].isNullAllowed;
    }
    if (isNullAllowed && (event.target.checked === true)) {
      this.warningMsg = "You are changing a null field to not-null (mandatory) field. This may have potential impact during processing of the file. Please verify all rules associated with this attribute with consideration that field may have no data.";
    } else if (!isNullAllowed && (event.target.checked === false)) {
      this.warningMsg = "You are changing a not-null (mandatory) field to null field. This may have potential impact during processing of the file. Please verify all rules associated with this attribute with consideration that field may have no data.";
    }
    if (isNullAllowed === (event.target.checked === true)) {
      this.acceptLabel = "Ok";
      this.rejectLabel = "Cancel";
      this.confirmationService.confirm({
        header: "Warning",
        message: this.warningMsg,
        accept: () => {
          this.acceptLabel = "Yes";
          this.rejectLabel = "No";
          this.handleDoNotMapRule(selectedAttr, event.target.checked);
          selectedAttr.isMandatory = true;
        },
        reject: () => {
          selectedAttr.isMandatory = false;
          event.target.checked = false;
          this.acceptLabel = "Yes";
          this.rejectLabel = "No";
        }

      });
    }
    else {
      selectedAttr.isMandatory = false;
    }
  }

  saveAttributeMapping(index, saveOnly) {
    this.btnClicked = true;
    this.redirectFlag = false;
    this.pushRedirectFlag.emit(false);
    this.tabLoader.emit(true);
    let tab;
    if (index === 0) {
      this.currentSectionMappingData = this.headerSectionMappingData;
      this.currentAttributeMappingData = this.headerAttributeMappingData;
      tab = "Header";
    } else if (index === 1) {
      this.currentSectionMappingData = this.detailSectionLevel0;
      this.currentAttributeMappingData = this.detailAttributeLevel0;
      tab = "Details";
    } else {
      this.currentSectionMappingData = this.trailerSectionMappingData;
      this.currentAttributeMappingData = this.trailerAttributeMappingData;
      tab = "Trailer";
    }
    if (index !== 1) {
      let headerInput = document.querySelectorAll("#disabled-input");
      [].forEach.call(headerInput, (item, i) => {
        this.currentSectionMappingData[i].sectionDisplayName = item.value;
      });
    }
    let isCustom = this.currentSectionMappingData[0].fileAttributeAssociations.filter((_atrObj) => _atrObj.attributeDictionary.isCustom === true);
    let checkSelected = isCustom.filter((_iscustomObj) => _iscustomObj.selectedAttribute === "" || _iscustomObj.selectedAttribute === null);
    if (checkSelected.length > 1) {
      this.toastr.error(tab + " cannot be saved with unselected attributes. Please remove blank attribute row if unwanted.", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
      this.tabLoader.emit(false);
      return false;
    }
    let _attrData = [];
    let _tempAttr = JSON.parse(JSON.stringify(this.currentSectionMappingData));
    for (let elm of _tempAttr[0].fileAttributeAssociations) {
      if (elm.selectedAttribute !== "" && elm.selectedAttribute !== null) {
        if (elm.attributeStartPosition === 0) {
          elm.attributeStartPosition = null;
        }
        if (elm.attributeEndPosition === 0) {
          elm.attributeEndPosition = null;
        }
        _attrData.push(elm);
      }
    }
    _tempAttr[0].fileAttributeAssociations = [];
    _tempAttr[0].fileAttributeAssociations = _attrData;
    _tempAttr[0].recordId = this.metaInfo.recordId;

    if (_attrData.length > 0) {
      if (this.allowCloning === false && this.cloneAllowed && index === 1) {
        this.fileSetupService.saveCloneRecords(_tempAttr, this.selCloneId).subscribe(res => {
          if (!res.error) {
            this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
            // this.toastr.success("Successfully saved the cloned " + _tempAttr[0].sectionDisplayName + "!", "Success!");
            this.onSuccess(index, saveOnly, res.data.attributeSectionAssociationList);
            this.updateCloneList(this.selCloneId, res.data.attributeSectionAssociationList);
          } else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            this.onSuccess(index, saveOnly, null);
          }
        }, error => {
          this.toastr.error("Server Error while saving File attribute mapping.", "Oops!", TOAST_SETTING);
          this.onSuccess(index, saveOnly, null);
        });
      } else {
        this.fileSetupService.updateFileAttribute(_tempAttr, this.metaInfo.recordId).subscribe(res => {
          if (!res.error) {
            this.updateDateAndUpdateBy.emit(res.data.fileMetaInfo);
            this.toastr.success("File attribute mapping saved successfully.", "Success!");
            this.onSuccess(index, saveOnly, res.data.attributeSectionAssociationList);
            if (index === 1) {
              this.updateCloneList(this.selCloneId, res.data.attributeSectionAssociationList);
            }
          } else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            this.onSuccess(index, saveOnly, null);
          }
        }, error => {
          this.toastr.error("Server Error while saving File attribute mapping.", "Oops!", TOAST_SETTING);
          this.onSuccess(index, saveOnly, null);
        });
      }
    }
    else {
      this.fileSetupService.updateFileSection(this.currentSectionMappingData[0].sectionDisplayName, this.currentSectionMappingData[0].fsaId, this.metaInfo.recordId).subscribe(res => {
        if (!res.error) {
          this.toastr.success("File attribute mapping saved successfully.", "Success!");
          this.onSuccess(index, saveOnly, null);
        } else {
          this.toastr.error("Failed To Section Display Name .", "Failure!", TOAST_SETTING);
        }
      });

    }
  }

  onSuccess(index, saveOnly, data) {
    this.tabLoader.emit(false);
    if (saveOnly !== "save") {
      this.btnClicked = false;
      if (index === 2) {
        this.pageNavigation.emit();
      }
      else {
        this.next(index + 1);
      }
    } else {
      if (data !== null) {
        this.updateFAAId(data);
      } else {
        this.btnClicked = false;
      }
    }
  }

  cftResData: any = {};
  updateFAAId(data) {
    this.cftResData = data[0];
    this.currentSectionMappingData[0].fsaId = this.cftResData.fsaId;
    for (let i = 0; i < this.cftResData.fileAttributeAssociations.length; i++) {
      this.currentSectionMappingData[0].fileAttributeAssociations[i].faaId = this.cftResData.fileAttributeAssociations[i].faaId;
      if (this.cftResData.fileAttributeAssociations[i].lookupTableFileAssociations && this.currentSectionMappingData[0].fileAttributeAssociations[i].lookupTableFileAssociations
        && this.currentSectionMappingData[0].fileAttributeAssociations[i].lookupTableFileAssociations.length) {
        for (let j = 0; j < this.cftResData.fileAttributeAssociations[i].lookupTableFileAssociations.length; j++) {
          this.currentSectionMappingData[0].fileAttributeAssociations[i].lookupTableFileAssociations[j].recordId =
            this.cftResData.fileAttributeAssociations[i].lookupTableFileAssociations[j].recordId;
        }
      }
      this.currentSectionMappingData[0].fileAttributeAssociations[i].fileFormatAttributeAssociation = this.cftResData.fileAttributeAssociations[i].fileFormatAttributeAssociation;
      if (this.currentSectionMappingData[0].fileAttributeAssociations[i].fileAttrBrAssocs && this.cftResData.fileAttributeAssociations[i].fileAttrBrAssocs
        && this.cftResData.fileAttributeAssociations[i].fileAttrBrAssocs.length) {
        for (let j = 0; j < this.currentSectionMappingData[0].fileAttributeAssociations[i].fileAttrBrAssocs.length; j++) {
          this.currentSectionMappingData[0].fileAttributeAssociations[i].fileAttrBrAssocs[j].fileAttrBrAssocId = this.cftResData.fileAttributeAssociations[i].fileAttrBrAssocs[j].fileAttrBrAssocId;
          this.currentSectionMappingData[0].fileAttributeAssociations[i].fileAttrBrAssocs[j].droolsBusinessRulesDecisionTable.droolsBusinessRuleId = this.cftResData.fileAttributeAssociations[i].fileAttrBrAssocs[j].droolsBusinessRulesDecisionTable.droolsBusinessRuleId;
        }
      }
    }
    this.btnClicked = false;
  }

  //   Rule Editor Section  : START /////////
  handleDoNotMapRule(selectedAttr, isMandatory) {
    if (selectedAttr.fileAttrBrAssocs !== undefined) {
      selectedAttr.fileAttrBrAssocs.forEach((rule, index) => {
        if (rule.droolsBusinessRulesDecisionTable.droolsBusinessRulePreDrlText === "Do Not Map") {
          selectedAttr.fileAttrBrAssocs = [];
        }
      });
    }
  }
  getAllRuleTemplates() {
    this._ruleEditorService.getAllRuleTemplates().subscribe(res => {
      if (!res.error) {
        let i = 1;
        for (let obj of res.data) {
          obj.label = obj.droolsBusinessRuleTemplateName;
          obj.value = i;
          this.ruleTemplatesGroupMapping[obj.droolsBusinessRuleTemplateGroup.droolsBusinessRuleGroupName.toLowerCase()] = obj.droolsBusinessRuleTemplateGroup.droolsBusinessRuleGroupId;
          i++;
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting all rule templates.", "Oops!", TOAST_SETTING);
    });
  }

  getSecondaryDataAtrributes() {
    this._ruleEditorService.getSecondaryDataAtrributes().subscribe(res => {
      if (!res.error) {
        this.getRuleSecondaryDataAttributeList = [];
        this.getRuleSecondaryDataAttributeList.push({ label: "Select Attribute", value: "" });
        for (let index = 0; index < res.data.length; index++) {
          let element = res.data[index];
          this.getRuleSecondaryDataAttributeList.push({
            label: element.label,
            items: element.items,
          });
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Secondary Data Attribute.", "Oops!", TOAST_SETTING);
    });
  }
  // Change Rule Reorder
  ruleReorderdata: any;
  getAllIdisRulePrioritySequence() {
    this.fileSetupService.getAllIdisRulePrioritySequence().subscribe(res => {
      if (!res.error) {
        this.ruleReorderdata = res.data;
      }
    }, error => {
      this.toastr.error("Server Error in fetching Rule Priority list.", "Oops!", TOAST_SETTING);
    });
  }

  ruleIndex: number = -1;
  pushRuleToAttribute(resultMap) {
    let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
    this.ruleIndex = -1;
    let ruleObj = resultMap.get("rule");
    let lookupObj = resultMap.get("lookup");
    let flag = true;

    if (ruleObj !== null) {
      if (this.ruleIndex === -1) {
        let arr = ["Format", "Hardcode", "Rule"];
        if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format") {
          flag = false;
          this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs = this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() !== "format");
        }
        else if (ruleObj.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName === "DoNotMap") {
          this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.splice(0, this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.length);
          this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.push(ruleObj);
          return;
        }
        else {
          this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs = this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.filter((el, i) => el.droolsBusinessRulesDecisionTable.droolsBusinessRuleGroup.droolsBusinessRuleGroupName.toLowerCase() === "format");
        }
        this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.push(ruleObj);
      }
      else
        this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs[this.ruleIndex] = ruleObj;
    }
    if (lookupObj !== null && lookupObj !== "undefined" && lookupObj.length > 0) {
      this.currentAttributeMappingData[applyRuleAttributeIndex].lookupTableFileAssociations = lookupObj;
    }
    if (this.currentAttributeMappingData[applyRuleAttributeIndex].isTodo && flag) {
      this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs.push(this.getFileAttrBrAssocs(true));
    }
    this.specialMappingDialog = false;
    if (this.selectedRow.faaId) {
      this.saveSingleRow();
    }
  };

  ruleReorderModel: boolean;
  selReOrderVal = 1;
  selReOrderNotes;

  openRuleReorderModel(row, index, overlaypanel) {
    if (!this.viewOnly) {
      this.setRedirectFlag(true);
    }
    this.ruleReorderModel = true;
    let applyRuleAttributeIndex;
    let savedBrAssoc;
    let reOrdVal = 1;
    let reOrdRes = "";

    if (index !== null && index >= 0) {
      this.selectedAttributeForRule = row.attributeDictionary.attributeName;
      savedBrAssoc = row.fileAttrBrAssocs;
    } else {
      applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
      this.selectedAttributeForRule = this.currentAttributeMappingData[applyRuleAttributeIndex].attributeDictionary.attributeName;
      savedBrAssoc = this.currentAttributeMappingData[applyRuleAttributeIndex].fileAttrBrAssocs;
    }
    savedBrAssoc.forEach((fileBrAssoc, index) => {
      if (fileBrAssoc.ruleExecutionSequence !== undefined && fileBrAssoc.ruleExecutionSequence > 1) {
        reOrdVal = fileBrAssoc.ruleExecutionSequence;
      }
      if (fileBrAssoc.ruleExecutionComment !== undefined && fileBrAssoc.ruleExecutionSequence > 1) {
        reOrdRes = fileBrAssoc.ruleExecutionComment;
      }
    });
    this.selReOrderVal = reOrdVal;
    this.selReOrderNotes = reOrdRes;
    this.selectedRow = row;
  }

  identifyRowAndopenRuleEditor(event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly) {
    this.ruleIndex = linkIndex;
    if (row.dataType !== null && row.dataType !== undefined && row.dataType.toUpperCase() === "BIT") {
      this.isFormatAvail = false;
    }
    else {
      this.isFormatAvail = true;
    }
    if (tabIndex === 0) {
      this.currentAttributeMappingData = this.headerSectionMappingData[sectionIndex].fileAttributeAssociations;
    } else if (tabIndex === 1) {
      this.getObjectName(id);
    } else if (tabIndex === 2) {
      this.currentAttributeMappingData = this.trailerSectionMappingData[sectionIndex].fileAttributeAssociations;
    }
    this.attributeMapping.selected = [];
    this.attributeMapping.selected.push(row);
    this.attributeMapping.selectedIndex = index;
    this.selectedRow = row;
    this.openRuleEditor(overlaypanel, RuleGroupName, viewOnly);
  }
  saveruleReorder(ruleReorderForm: NgForm) {
    this.ruleReorderModel = false;
    let selRow;
    if (this.selectedRow !== null && this.selectedRow !== undefined) {
      selRow = this.selectedRow;
    } else {
      let applyRuleAttributeIndex = this.attributeMapping.selectedIndex;
      selRow = this.currentAttributeMappingData[applyRuleAttributeIndex];
    }

    selRow.fileAttrBrAssocs.forEach((fileBrAssoc, index) => {
      fileBrAssoc.ruleExecutionSequence = ruleReorderForm.value.reOrderVal;
      fileBrAssoc.ruleExecutionComment = ruleReorderForm.value.reOrderNotes;
    });
    ruleReorderForm.resetForm();
  };
  //  Rule Editor Section  : END /////////


  // valid value popup
  validValuesData: any = [];
  showValidValueDialog: boolean = false;
  dataElement: string = "";
  first: number = 0;
  validationType: number = 1;

  showValidValue(masterDTO) {
    this.validValuesData = [];
    this.showValidValueDialog = true;
    this.dataElement = masterDTO.dataElement;
    this.first = 0;
    this.validationType = masterDTO.validationType;

    if (masterDTO.validationType === 1) {

      let _validVal = masterDTO.validationValues.split(",");
      for (let i = 0; i < _validVal.length; i++) {
        this.validValuesData.push(_validVal[i]);
      }
    } else if (masterDTO.validationType === 2) {
      let _validVal = masterDTO.validationValues.split(" OR ");
      for (let i = 0; i < _validVal.length; i++) {
        if (masterDTO.dataType === "DATE") {
          this.validValuesData.push("DateFormat(\"" + _validVal[i] + "\")");
          if (i !== _validVal.length - 1) {
            this.validValuesData.push(" OR ");
          }
        }
        if (masterDTO.dataType !== "DATE") {
          this.validValuesData.push("Format(\"" + _validVal[i] + "\")");
          if (i !== _validVal.length - 1) {
            this.validValuesData.push(" OR ");
          }
        }
      }
    }
  }

  /*
    CC-37799 - Ability to configure multiple records at File Level
    Cloning Detail Section in "Attribute Mappnig" Section
  */
  loderText: string;
  selCloneId: number = 0;
  cloneIdList: any = [];

  cloneOverlay: boolean = false;
  cloneDropDown: any = [];
  restrictAttr: boolean = false;
  getCloneDetails() {
    this.loderText = "Loading Details";
    this.cloneOverlay = true;
    if (this.selCloneId === 0) {
      this.restrictAttr = false;
      this.allowCloning = true;
      this.detailSectionLevel0 = this.editFormData.detailSectionMappingInfo;
      this.detailSectionLevel0.forEach((element, index) => {
        this.detailAttributeLevel0 = element.fileAttributeAssociations;
        this.detailAttributeLevel0.forEach((childElement, childIndex) => {
          this.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
          this.pushRuleAttributeList(childElement.attributeDictionary);
        });
      });
      this.cloneOverlay = false;
    } else {
      this.restrictAttr = true;
      this.allowCloning = false;
      this.fileSetupService.editFiles(this.metaInfo.recordId, this.metaInfo.fileVersion, true, true, this.selCloneId).subscribe(res => {
        if (!res.error) {
          this.cloneOverlay = false;
          this.populateCloneAttr(res.data);
        }
      });
    }
  }

  populateCloneAttr(data) {
    this.detailSectionLevel0 = data.detailSectionMappingInfo;
    this.detailSectionLevel0.forEach((element, index) => {
      this.detailAttributeLevel0 = element.fileAttributeAssociations;
      this.detailAttributeLevel0.forEach((childElement, childIndex) => {
        this.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
        this.pushRuleAttributeList(childElement.attributeDictionary);
      });
    });
    this.currentSectionMappingData = this.detailSectionLevel0;
    this.currentAttributeMappingData = this.detailAttributeLevel0;
  }


  cloneRecords: number;
  cloneRecordFn() {
    this.loderText = "Clonning Records";
    this.cloneOverlay = true;
    this.restrictAttr = true;
    this.allowCloning = false;
    this.fileSetupService.cloneRecords(this.metaInfo.recordId, this.cloneRecords).subscribe(res => {
      if (!res.error) {
        this.cloneOverlay = false;
        let cloneNumbers = res.data.cloneInfo;
        for (let _cn of cloneNumbers) {
          this.cloneIdList.push({
            label: _cn.cloneName,
            value: _cn.cloneNum
          });
        }
        this.populateCloneAttr(res.data);
        this.cloneRecords = 1;
        this.selCloneId = cloneNumbers[0].cloneNum;
        this.toastr.success("Successfully Added Clone Record !", "Success");
      }
    }, error => {
      this.toastr.error("Server Error in fetching Clone Detail.", "Oops!", TOAST_SETTING);
    });


  }

  cloningOption: boolean = false;
  setCloneOptions() {
    if (this.activeIndex === 1) {
      this.allowCloning = true;
      this.selCloneId = 0;
      this.cloneRecords = 1;
    } else {
      this.allowCloning = false;
    }
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipFileAttribute = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipFileAttribute[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  deleteClone() {
    let _delSectionName = this.detailSectionLevel0[0].sectionDisplayName;
    this.confirmationService.confirm({
      message: " Are you sure you want to remove the cloned section " + _delSectionName + " from the configuration ?",
      accept: () => {
        this.loderText = "Loading Details";
        this.cloneOverlay = true;
        this.fileSetupService.deleteClone(this.metaInfo.recordId, this.selCloneId).subscribe(res => {
          if (!res.error) {
            this.restrictAttr = false;
            this.allowCloning = true;
            this.toastr.success("Successfully deleted the cloned section " + _delSectionName + "!", "Success");
            this.detailSectionLevel0 = this.editFormData.detailSectionMappingInfo;
            this.detailSectionLevel0.forEach((element, index) => {
              this.detailAttributeLevel0 = element.fileAttributeAssociations;
              this.detailAttributeLevel0.forEach((childElement, childIndex) => {
                this.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
                this.pushRuleAttributeList(childElement.attributeDictionary);
              });
            });
            this.removeDeltedFromList(this.selCloneId);
            this.setCloneOptions();
            this.cloneOverlay = false;
            window.scrollTo(0, 0);
          }
        }, error => {
          this.toastr.error("Server Error in deleting clone section.", "Oops!", TOAST_SETTING);
        });
      }
    });
  }

  removeDeltedFromList(cloneId) {
    let _rmIndex;
    this.cloneIdList.filter((obj, index) => {
      if (obj.value === cloneId) {
        _rmIndex = index;
      }
    });
    this.cloneIdList.splice(_rmIndex, 1);
  }

  updateCloneList(cloneId, data) {
    this.cloneIdList.filter((obj, index) => {
      if (obj.value === cloneId) {
        obj.label = data[0].sectionDisplayName;
      }
    });
  }

  // Get confirmation for navigate without savig data
  redirectFlag: boolean = false;
  @Output() pushRedirectFlag = new EventEmitter();

  // Save data before navigate to other page
  acceptLabel = confAcceptLabel;
  rejectLabel = confRejectLabel;
  confMessage = confMessage;

  // Set Modified Data Flag
  setRedirectFlag(flag) {
    this.redirectFlag = flag;
    this.pushRedirectFlag.emit(flag);
  }

  cleanTestValues(index) {
    if (index === 0) {
      this.headerAttributeMappingData.forEach((childElement, childIndex) => {
        childElement.attributeTestData = "";
      });
    } else if (index === 1) {
      this.detailAttributeLevel0.forEach((childElement, childIndex) => {
        childElement.attributeTestData = "";
      });
    } else {
      this.trailerAttributeMappingData.forEach((childElement, childIndex) => {
        childElement.attributeTestData = "";
      });
    }
  }
  saveSingleRow() {
    let obj = [];
    if (this.activeIndex === 0) {
      obj = JSON.parse(JSON.stringify(this.headerSectionMappingData));
    } else if (this.activeIndex === 1) {
      obj = JSON.parse(JSON.stringify(this.detailSectionLevel0));
    } else {
      obj = JSON.parse(JSON.stringify(this.trailerSectionMappingData));
    }
    obj[0].fileAttributeAssociations = [this.selectedRow];
    obj[0].recordId = this.metaInfo.recordId;

    if (this.allowCloning === false && this.cloneAllowed && this.activeIndex === 1) {
      this.fileSetupService.saveCloneRecords(obj, this.selCloneId).subscribe(res => {
        if (!res.error) {
          this.redirectFlag = false;
          this.pushRedirectFlag.emit(false);
          this.toastr.success("File attribute mapping saved successfully.", "Success!");
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error while saving File attribute mapping.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.fileSetupService.updateFileAttribute(obj, this.metaInfo.recordId).subscribe(res => {
        if (!res.error) {
          this.redirectFlag = false;
          this.pushRedirectFlag.emit(false);
          this.toastr.success("File attribute mapping saved successfully.", "Success!");
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        };
      }, error => {
        this.toastr.error("Server Error while saving File attribute mapping.", "Oops!", TOAST_SETTING);

      });
    }






  }
  // End___________
}
