import { async, ComponentFixture, TestBed } from "@angular/core/testing";

// ANGULAR
// =========================
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";


// VENDOR IMPORTS
// =========================
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, ConfirmationService } from "primeng/primeng";
import { DataTableModule, DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";

import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";


// COMPONENT
// =========================
import { AlFileAttributeMappingComponent } from "./al-file-attribute-mapping.component";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";


// SERVICE
// =========================
import { FileSetupService } from "../../al-file-setup-services/file-setup.service";
import { AlRuleEditorService } from "../../al-file-setup-services/al-rule-editor.service";
import { LobService } from "../../../commons/al-lob/al-lob-services/lob.service";
import { LoginService } from "../../../login/login.service";
import { CommentStmt } from "@angular/compiler";
import { By } from "@angular/platform-browser";
import { HttpClientTestingModule } from "@angular/common/http/testing";

// Mock data
// =========================
let metaInfo;
const routes: Routes = [];

describe("AlFileAttributeMappingComponent", () => {
    let component: AlFileAttributeMappingComponent;
    let fixture: ComponentFixture<AlFileAttributeMappingComponent>;
    let toastService, fileSetupService;
    let _selRow;
    let _actionItems = {
        toggle: (e) => { },
        hide: () => { }
    };

    function populateData() {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        metaInfo = response.data.metaInfo;
        return metaInfo;
    }

    beforeEach(async(() => {
        TestBed.overrideComponent(AlFileAttributeMappingComponent, {
            set: {
                providers: [
                    { provide: FileSetupService, useClass: MockDataService },
                    { provide: ConfirmationService, useClass: MockDataService },
                    { provide: ToastsManager, useClass: MockDataService },
                    { provide: ToastOptions, useClass: MockDataService }
                ]
            }
        });

        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                DropdownModule,
                AutoCompleteModule,
                OverlayPanelModule,
                DataTableModule,
                NgxPermissionsModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                ToastModule,
                AlPopOverModule,
                HttpClientTestingModule
            ],
            declarations: [AlFileAttributeMappingComponent, NgxPermissionsAllowStubDirective],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                AppUtility,
                LobService,
                LoginService,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
                { provide: ConfirmationService, useClass: MockDataService },
                { provide: FileSetupService, useClass: MockDataService },
                { provide: AlRuleEditorService, useClass: MockDataService },
                { provide: NgxPermissionsService, useClass: FakeNgxPermission },
                { provide: ToastOptions, useClass: MockDataService },
                { provide: ToolTipUtilService, useClass: MockDataService }
            ]
        });

        TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(AlFileAttributeMappingComponent);
            component = fixture.debugElement.componentInstance;
            fileSetupService = fixture.debugElement.injector.get(FileSetupService);
            component.metaInfo = populateData();
        });
        toastService = TestBed.get(ToastsManager);
    }));

    // it("should create", async(() => {
    //     expect(component).toBeTruthy();
    // }));
    it("should ngonInit", () => {
        component.metaInfo = populateData();
        component.ngOnInit();
    });
    it("should ngonInit error handle", () => {
        spyOn(fileSetupService, "getAllAttributes").and.returnValue(Observable.throw("No Data"));
        spyOn(fileSetupService, "getAttributeStandarizedNameListByFileTypeId").and.returnValue(Observable.throw("No Data"));
        spyOn(fileSetupService, "getPackageInfoByFileTypeId").and.returnValue(Observable.throw("error"));
        spyOn(fileSetupService, "getLookupTables").and.returnValue(Observable.throw("No Data"));
        component.ngOnInit();
        spyOn(fileSetupService, "getAllMasterAttributes").and.returnValue(Observable.throw("No Data"));
        component.getMasterAttributeList(1);
    });
    it("should saveAttributeMapping", () => {
        let index, saveOnly;
        index = 0;
        saveOnly = "unsave";
        let response;
        let _div = document.createElement("div");
        _div.className = "steps-custom";
        let _ul = document.createElement("ul");
        _div.appendChild(_ul);
        let _li = document.createElement("li");
        _ul.appendChild(_li);
        let _li2 = document.createElement("li");
        _ul.appendChild(_li2);
        document.body.appendChild(_div);
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        component.cloneAllowed = true;
        component.allowCloning = false;
        component.headerSectionMappingData = response.data.headerSectionMappingInfo;
        component.currentSectionMappingData = response.data.headerSectionMappingInfo;
        component.saveAttributeMapping(index, saveOnly);
        index = 1;
        component.detailSectionLevel0 = response.data.detailSectionMappingInfo;
        component.cloneAllowed = true;
        component.allowCloning = false;
        component.saveAttributeMapping(index, saveOnly);
        _div = document.createElement("div");
        _div.className = "steps-custom";
        _ul = document.createElement("ul");
        _div.appendChild(_ul);
        _li = document.createElement("li");
        _ul.appendChild(_li);
        _li2 = document.createElement("li");
        _ul.appendChild(_li2);
        document.body.appendChild(_div);
        spyOn(fileSetupService, "saveCloneRecords").and.returnValue(Observable.throw("No Data"));
        component.saveAttributeMapping(index, saveOnly);
        index = 2;
        component.trailerSectionMappingData = response.data.trailerSectionMappingInfo;
        component.saveAttributeMapping(index, saveOnly);
        spyOn(fileSetupService, "updateFileAttribute").and.returnValue(Observable.throw("No Data"));
        component.saveAttributeMapping(index, saveOnly);
    });
    it("should setSelectedAttrDetails", () => {
        let selectedAttr;
        let currentObj = {
            "attributeDictionary": {
                "attributeId": 618,
                "attributeName": "Custom Defined3"
            },
            "applicationCompliantAttributeName": null,
            "attributeRowPosition": null,
            "attributeStartPosition": null,
            "attributeEndPosition": null,
            "attributeSize": 100,
            "childFileTemplateVersion": 1,
            "isMandatory": false,
            "isHardcoded": false,
            "isInherited": false,
            "fileSectionIdentifier": "H",
            "dataType": "VARCHAR",
            "needsLookupTable": false,
            "lookupTableFileAssociations": [],
            "selectedAttribute": 618,
            "isNullAllowed": true
        };
        component.attributeMapping.attributeList = [{
            label: "Select Attribute", value: 523
        }, {
            label: "Select test", value: 245
        }, {
            label: "Select Attribute", value: 123
        }];
        selectedAttr = 523;
        component.setSelectedAttrDetails(selectedAttr, currentObj);
        component.activeIndex = 1;
        component.setSelectedAttrDetails(selectedAttr, currentObj);
        component.activeIndex = 2;
        component.setSelectedAttrDetails(selectedAttr, currentObj);
        let attributeMappingList = [{
            "attributeDictionary": {
                "attributeId": 618,
                "attributeName": "Custom Defined3"
            },
            "applicationCompliantAttributeName": null,
            "attributeRowPosition": null,
            "attributeStartPosition": null,
            "attributeEndPosition": null,
            "attributeSize": 100,
            "childFileTemplateVersion": 1,
            "isMandatory": false,
            "isHardcoded": false,
            "isInherited": false,
            "fileSectionIdentifier": "H",
            "dataType": "VARCHAR",
            "needsLookupTable": false,
            "lookupTableFileAssociations": [],
            "selectedAttribute": 618,
            "isNullAllowed": true
        }];
        selectedAttr = 618;
        component.checkAttributePresence(selectedAttr, currentObj, attributeMappingList);
    });
    it("should call attachRuleAndLookup() & removeAttribute()", () => {
        let event = {};
        let row = {
            "attributeDictionary": {
                "attributeId": 618,
                "attributeName": "Custom Defined3"
            },
            "fileAttrBrAssocs": [{
                "droolsBusinessRulesDecisionTable": {
                    "droolsBusinessRuleGroup": {
                        "droolsBusinessRuleGroupName": "DoNotMap"
                    }
                }
            }],
            "applicationCompliantAttributeName": null,
            "attributeRowPosition": null,
            "attributeStartPosition": null,
            "attributeEndPosition": null,
            "attributeSize": 100,
            "childFileTemplateVersion": 1,
            "isMandatory": false,
            "isHardcoded": false,
            "isInherited": false,
            "fileSectionIdentifier": "H",
            "dataType": "VARCHAR",
            "needsLookupTable": false,
            "lookupTableFileAssociations": [],
            "selectedAttribute": 618,
            "isNullAllowed": true
        };
        let index = 0;
        let overlaypanel = {
            toggle: (e) => {
            },
            hide: () => {
            }
        };
        let tabIndex = 0;
        let sectionIndex = 0;
        let id = "";
        component.headerSectionMappingData = [
            {
                "createdBy": "Nirmal Desai",
                "createdDateTime": "01/03/2019 13:01:16.493 GMT",
                "updatedBy": "Nirmal Desai",
                "updatedDateTime": "01/03/2019 13:01:16.493 GMT",
                "cftsaId": 8202,
                "templateCompliantSectionShortName": "H",
                "sequence": 1,
                "templateSections": {
                    "createdBy": "A0745106",
                    "createdDateTime": "29/05/2018 05:00:00.000 GMT",
                    "updatedBy": "Nirmal Desai",
                    "updatedDateTime": "01/03/2019 13:38:33.283 GMT",
                    "templateSectionId": 1,
                    "sectionName": "Header",
                    "sectionDescription": "Header"
                },
                "childFileTemplateRecordId": 988,
                "sectionDisplayName": "Header",
                "assocChildSectionList": null,
                "childFileTemplateAttributeAssociations": [
                    {
                        "attributeDictionary": {
                            "attributeId": 618,
                            "attributeName": "Custom Defined3"
                        },
                        "applicationCompliantAttributeName": null,
                        "attributeRowPosition": null,
                        "attributeStartPosition": null,
                        "attributeEndPosition": null,
                        "attributeSize": 100,
                        "childFileTemplateVersion": 1,
                        "isMandatory": false,
                        "isHardcoded": false,
                        "isInherited": false,
                        "fileSectionIdentifier": "H",
                        "dataType": "VARCHAR",
                        "needsLookupTable": false,
                        "lookupTableFileAssociations": [],
                        "selectedAttribute": 618,
                        "isNullAllowed": true
                    }
                ],
                "mandatory": true
            }
        ];
        component.attachRuleAndLookup(event, row, index, overlaypanel, tabIndex, sectionIndex, id);
        component.openRuleReorderModel(row, index, overlaypanel);
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        component.editFormData = response.data;
        component.headerSectionMappingData = response.data.headerSectionMappingInfo;
        component.detailSectionLevel0 = response.data.detailSectionMappingInfo;
        component.trailerSectionMappingData = response.data.trailerSectionMappingInfo;

        component.headerSectionMappingData.forEach((element, index) => {
            component.headerAttributeMappingData = element.fileAttributeAssociations;
            component.headerAttributeMappingData.forEach((childElement, childIndex) => {
                component.headerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });
        component.detailSectionLevel0.forEach((element, index) => {
            component.detailAttributeLevel0 = element.fileAttributeAssociations;
            component.detailAttributeLevel0.forEach((childElement, childIndex) => {
                component.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });
        component.trailerSectionMappingData.forEach((element, index) => {
            component.trailerAttributeMappingData = element.fileAttributeAssociations;
            component.trailerAttributeMappingData.forEach((childElement, childIndex) => {
                component.trailerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });

        component.activeIndex = 0;
        component.removeAttribute(overlaypanel);

        let confirmService = fixture.debugElement.injector.get(ConfirmationService);
        spyOn(confirmService, "confirm").and.callFake((params: any) => {
            params.accept();
        });
        component.activeIndex = 1;
        component.removeAttribute(overlaypanel);

        component.activeIndex = 2;
        component.trailerSectionMappingData = response.data.trailerSectionMappingInfo;
        component.selIndex = 0;
        // component.trailerSectionMappingData = [{
        //     "childFileTemplateAttributeAssociations": [{
        //         "cftaaId": 0
        //     }]
        // }];
        component.removeAttribute(overlaypanel, 0);
        component.attachRuleAndLookup(event, row, index, overlaypanel, 1, sectionIndex, id);
        component.attachRuleAndLookup(event, row, index, overlaypanel, 2, sectionIndex, id);

        component.currentAttributeMappingData = [
            {
                "cftaaId": 0,
                "attributeDictionary": {
                    "attributeId": 618,
                    "attributeName": "Custom Defined3"
                },
                "fileAttrBrAssocs": [{
                    "droolsBusinessRulesDecisionTable": {
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupName": "DoNotMap"
                        }
                    },
                    "ruleExecutionSequence": 1,
                    "ruleExecutionComment": "test"
                }],
                "dataType": "VARCHAR",
            }
        ];
        component.openRuleReorderModel(row, null, overlaypanel);

        let linkIndex = 0;
        let RuleGroupName = "DoNotMap";
        let RuleGroupId = 0;
        let viewOnly = true;
        component.ruleEditorComp = {
            reGenerateUI: function () { return false; }
        };
        component.packageByFileType = [
            {
                "packageId": 1,
                "packageVersion": 1,
                "packageName": "com.alight.adapt.secondarydata.person.v1.models",
                "className": "PersonSecondaryDataset",
                "fileTypeId": 10,
                "alias": "PersonSecondaryDataset",
                "packageType": "SECONDARY_DATA_ATTRIBUTE",
                "clazz": null
            },
            {
                "packageId": 9,
                "packageVersion": 1,
                "packageName": "com.alight.adapt.datasets.employermandate.v1",
                "className": "ProcessorEmployerMandateDataset",
                "fileTypeId": 10,
                "alias": "ProcessorEmployerMandateDataset",
                "packageType": "PRIMARY_DATA_ATTRIBUTE",
                "clazz": null
            }
        ];
        component.identifyRowAndopenRuleEditor(event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly);


        // spyOn(confirmService, "confirm").and.callFake((params: any) => {
        //     params.accept();
        // });
        component.deleteClone();
    });
    it("should pushRuleToAttribute", () => {
        component.selectedRow = [
            {
                "fsaId": 12120,
                "fileIdentifier": 2001,
                "fileCompliantSectionShortName": "H",
                "sequence": 0,
                "sectionDisplayName": "",
                "assocChildSectionList": null,
                "fileAttributeAssociations": [
                    {
                        "faaId": 241746,
                        "dataType": "VARCHAR",
                        "fileIdentifier": 2001,
                        "isMandatory": false,
                        "fileAttrBrAssocs": [],
                        "lookupTableFileAssociations": [],
                        "selectedAttribute": 528,
                    }
                ]
            }
        ];
        _selRow = component.selectedRow;
        let resultMap = {
            get: () => {
                let res = {
                    "droolsBusinessRulesDecisionTable": {
                        "isCurrent": true,
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupName": "format"
                        }
                    }
                };
                return res;
            }
        };
        component.attributeMapping.selectedIndex = 0;
        component.currentAttributeMappingData = [{
            fileAttrBrAssocs: [{
                "droolsBusinessRulesDecisionTable": {
                    "droolsBusinessRuleGroup": {
                        "droolsBusinessRuleGroupName": "DoNotMap"
                    }
                }
            }]
        }];
        component.pushRuleToAttribute(resultMap);
        resultMap = {
            get: () => {
                let res = {
                    "droolsBusinessRulesDecisionTable": {
                        "isCurrent": true,
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupName": "DoNotMap"
                        }
                    }
                };
                return res;
            }
        };
        component.pushRuleToAttribute(resultMap);
        resultMap = {
            get: () => {
                let res = {
                    "droolsBusinessRulesDecisionTable": {
                        "isCurrent": true,
                        "droolsBusinessRuleGroup": {
                            "droolsBusinessRuleGroupName": "Rule"
                        }
                    }
                };
                return res;
            }
        };
        component.pushRuleToAttribute(resultMap);
        component.ruleIndex = 0;
        component.pushRuleToAttribute(resultMap);
    });
    it("should openRuleReorderModel", () => {
        let row = {
            "attributeDictionary": {
                "attributeId": 618,
                "attributeName": "Custom Defined3"
            },
            fileAttrBrAssocs: [{
                "ruleExecutionSequence": "custom",
                "ruleExecutionComment": "yes its",
                "droolsBusinessRulesDecisionTable": {
                    "isCurrent": true,
                    "droolsBusinessRuleVersion": 2,
                    "droolsBusinessRuleName": "Mix_Template"
                }
            }],
        };
        let index = 0;
        let overlaypanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        component.openRuleReorderModel(row, index, overlaypanel);
        index = null;
        component.attributeMapping.selectedIndex = 0;
        component.currentAttributeMappingData = [{
            "attributeDictionary": {
                "attributeId": 618,
                "attributeName": "Custom Defined3"
            },
            "fileAttrBrAssocs": [{
                "ruleExecutionSequence": "custom",
                "ruleExecutionComment": "yes its",
                "droolsBusinessRulesDecisionTable": {
                    "isCurrent": true,
                    "droolsBusinessRuleVersion": 2,
                    "droolsBusinessRuleName": "Mix_Template"
                }
            }]
        }];
        component.openRuleReorderModel(row, index, overlaypanel);
    });
    it("should ruleEditorService error handle", () => {
        let ruleEditorService = fixture.debugElement.injector.get(AlRuleEditorService);
        spyOn(ruleEditorService, "getAllRuleTemplates").and.returnValue(Observable.throw("{error:true}"));
        component.getAllRuleTemplates();
        spyOn(ruleEditorService, "getSecondaryDataAtrributes").and.returnValue(Observable.throw("{error:true}"));
        component.getSecondaryDataAtrributes();
        spyOn(fileSetupService, "getAllIdisRulePrioritySequence").and.returnValue(Observable.throw("No Data"));
        component.getAllIdisRulePrioritySequence();
        spyOn(fileSetupService, "editFiles").and.returnValue(Observable.throw("No Data"));
        component.populateChildAttr(1, 2);
    });
    it("should onSuccess", () => {
        let data = [{
            "fsaId": 11427,
            "fileAttributeAssociations": [
                {
                    "createdBy": "Dharam Mali",
                    "createdDateTime": "25/02/2019 10:17:23.050 GMT",
                    "updatedBy": "Dharam Mali",
                    "updatedDateTime": "25/02/2019 10:17:23.050 GMT",
                    "faaId": 221653,
                    "attributeRowPosition": 3,
                    "dataType": "VARCHAR",
                    "fileIdentifier": 1851,
                    "isMandatory": false,
                    "lookupTableFileAssociations": [{
                        "recordId": 0
                    }],
                    "fileFormatAttributeAssociation": [
                        {
                            "updatedBy": "Dharam Mali"
                        }
                    ],
                    "fileAttrBrAssocs": [{
                        "fileAttrBrAssocId": 12323,
                        "droolsBusinessRulesDecisionTable": {
                            "droolsBusinessRuleGroup": {
                                "droolsBusinessRuleGroupName": "DoNotMap",
                                "droolsBusinessRulePreDrlText": "Do Not Map"
                            }
                        }
                    }]
                }
            ]
        }];
        component.currentSectionMappingData = [{
            "fsaId": 11427,
            "fileAttributeAssociations": [
                {
                    "createdBy": "Dharam Mali",
                    "createdDateTime": "25/02/2019 10:17:23.050 GMT",
                    "updatedBy": "Dharam Mali",
                    "updatedDateTime": "25/02/2019 10:17:23.050 GMT",
                    "faaId": 221653,
                    "attributeRowPosition": 3,
                    "dataType": "VARCHAR",
                    "fileIdentifier": 1851,
                    "isMandatory": false,
                    "lookupTableFileAssociations": [{
                        "recordId": 0
                    }],
                    "fileFormatAttributeAssociation": [
                        {
                            "updatedBy": "Dharam Mali"
                        }
                    ],
                    "fileAttrBrAssocs": [{
                        "fileAttrBrAssocId": 12323,
                        "droolsBusinessRulesDecisionTable": {
                            "droolsBusinessRuleGroup": {
                                "droolsBusinessRuleGroupName": "DoNotMap"
                            }
                        }
                    }]
                }
            ]
        }];
        component.onSuccess(0, "save", data);
        component.onSuccess(0, "save", null);
        component.handleDoNotMapRule(data[0].fileAttributeAssociations[0], {});
    });
    it("should openRuleReorderModel", () => {
        let event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly;
        linkIndex = 0;
        overlaypanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        row = {
            dataType: "BIT"
        };
        tabIndex = 0;
        index = 0;
        sectionIndex = 0;
        RuleGroupName = "format";
        component.ruleEditorComp = {
            reGenerateUI: () => {

            }
        };
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        component.editFormData = response.data;
        component.headerSectionMappingData = response.data.headerSectionMappingInfo;
        component.currentAttributeMappingData = response.data.headerSectionMappingInfo[0].fileAttributeAssociations;
        component.packageByFileType = [
            {
                "packageId": 1,
                "packageVersion": 1,
                "packageName": "com.alight.adapt.secondarydata.person.v1.models",
                "className": "PersonSecondaryDataset",
                "fileTypeId": 10,
                "alias": "PersonSecondaryDataset",
                "packageType": "SECONDARY_DATA_ATTRIBUTE",
                "clazz": null
            },
            {
                "packageId": 9,
                "packageVersion": 1,
                "packageName": "com.alight.adapt.datasets.employermandate.v1",
                "className": "ProcessorEmployerMandateDataset",
                "fileTypeId": 10,
                "alias": "ProcessorEmployerMandateDataset",
                "packageType": "PRIMARY_DATA_ATTRIBUTE",
                "clazz": null
            }
        ];
        component.identifyRowAndopenRuleEditor(event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly);
        tabIndex = 1;
        component.identifyRowAndopenRuleEditor(event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly);
        tabIndex = 2;
        component.trailerSectionMappingData = response.data.trailerSectionMappingInfo;
        component.identifyRowAndopenRuleEditor(event, row, index, linkIndex, overlaypanel, tabIndex, sectionIndex, id, RuleGroupName, RuleGroupId, viewOnly);

        component.saveSingleRow();
    });
    it("should openRuleReorderModel", () => {
        component.attributeMapping.selectedIndex = 0;
        let validForm = <NgForm>{
            reset: () => null,
            resetForm: () => null,
            value: {
                reOrderVal: "",
                reOrderNotes: "",
                active: false
            }
        };
        component.currentAttributeMappingData = [{
            fileAttrBrAssocs: [{
                ruleExecutionSequence: "",
                ruleExecutionComment: ""
            }]
        }, {
            fileAttrBrAssocs: [{
                ruleExecutionSequence: "",
                ruleExecutionComment: ""
            }]
        }];
        component.saveruleReorder(validForm);
        component.selectedRow = [{
            fileAttrBrAssocs: [{
                ruleExecutionSequence: "",
                ruleExecutionComment: ""
            }]
        }, {
            fileAttrBrAssocs: [{
                ruleExecutionSequence: "",
                ruleExecutionComment: ""
            }]
        }];
        // component.saveruleReorder(validForm);
    });
    it("should openRuleReorderModel", () => {
        let overlaypanel = {
            toggle: (e) => {

            },
            hide: () => {

            }
        };
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        component.metaInfo = response.data;
        component.addNewAttributeRow(overlaypanel, true);
        component.addNewAttributeRow(overlaypanel, undefined);
        let masterDTO = {
            dataElement: "",
            validationType: 1,
            validationValues: "check OR value OR inprogress ",
            dataType: ""
        };
        component.showValidValue(masterDTO);
        masterDTO.validationType = 2;
        component.showValidValue(masterDTO);
        masterDTO.dataType = "DATE";
        component.showValidValue(masterDTO);
        component.editFormData = response.data;
        component.getCloneDetails();
        component.selCloneId = 1;
        component.getCloneDetails();
        component.cloneRecordFn();
        spyOn(fileSetupService, "cloneRecords").and.returnValue(Observable.throw("No Data"));
        component.cloneRecordFn();
        let value = {
            currentTarget: {
                value: "value test"
            }
        };
        let obj = {};
        component.dropDownValue(value, obj);
        let event = { target: { value: "", checked: true } };
        let mappedObj = {
            attributeEndPosition: "1535518400000",
            attributeStartPosition: "1535518800000"
        };
        let validateWidth = true;
        component.checkNegativeValue(event, mappedObj, validateWidth);
        let event1 = { target: { value: 0, checked: true, focus: () => { } } };
        component.checkNegativeValue(event1, mappedObj, validateWidth);
        let selectedAttr = {
            attributeDictionary: {
                isNullAllowed: true
            }
        };
        component.attributeMapping.attributeList = [{
            label: "Select Attribute", value: 523
        }, {
            label: "Select test", value: 245
        }, {
            label: "Select Attribute", value: 123
        }];
        component.getConfirmation(event, selectedAttr);
        selectedAttr = {
            attributeDictionary: {
                isNullAllowed: false
            }
        };
        event = { target: { value: "value", checked: false } };
        component.getConfirmation(event, selectedAttr);
        selectedAttr = {
            attributeDictionary: {
                isNullAllowed: false
            }
        };
        component.getConfirmation(event, selectedAttr);
        component.cloneIdList = [{
            "value": 1
        },
        {
            "value": 2
        }];
        component.removeDeltedFromList(1);
        let data = [{
            "sectionDisplayName": "Header"
        }];
        component.cloneIdList = [{
            "value": 1
        },
        {
            "value": 2
        }];
        component.updateCloneList(1, data);
    });



    it("markAsTodo()", () => {
        component.selectedRow = _selRow;
        component.markAsTodo(_actionItems, true);
    });
    it("markAsTodo() : res error", () => {
        component.selectedRow = _selRow;
        let fileSetupService = fixture.debugElement.injector.get(FileSetupService);
        spyOn(fileSetupService, "markAsTodo").and.returnValue(Observable.of({ "error": true }));
        component.markAsTodo(_actionItems, true);
    });
    it("markAsTodo() : error", () => {
        component.selectedRow = _selRow;
        let fileSetupService = fixture.debugElement.injector.get(FileSetupService);
        spyOn(fileSetupService, "markAsTodo").and.returnValue(Observable.throw("error"));
        component.markAsTodo(_actionItems, true);
    });




    it("should and displayToolTipText()", () => {
        component.toolTipFileAttribute = {
            "Data elements": {
                "tooltipDesc": "Data elements description",
                "readMoreLink": "http://www.google.com"
            }
        };
        const btnNextStep = document.createElement("th");
        document.body.appendChild(btnNextStep);
        btnNextStep.addEventListener("click", (event) => {
            component.displayToolTipText(event, "Data elements", "bottom");
        });
        component.hideToolTipText(event);
        btnNextStep.click();
    });

    it("should call cleanTestValues()", () => {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        component.editFormData = response.data;
        component.headerSectionMappingData = response.data.headerSectionMappingInfo;
        component.detailSectionLevel0 = response.data.detailSectionMappingInfo;
        component.trailerSectionMappingData = response.data.trailerSectionMappingInfo;

        component.headerSectionMappingData.forEach((element, index) => {
            component.headerAttributeMappingData = element.fileAttributeAssociations;
            component.headerAttributeMappingData.forEach((childElement, childIndex) => {
                component.headerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });
        component.detailSectionLevel0.forEach((element, index) => {
            component.detailAttributeLevel0 = element.fileAttributeAssociations;
            component.detailAttributeLevel0.forEach((childElement, childIndex) => {
                component.detailAttributeLevel0[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });
        component.trailerSectionMappingData.forEach((element, index) => {
            component.trailerAttributeMappingData = element.fileAttributeAssociations;
            component.trailerAttributeMappingData.forEach((childElement, childIndex) => {
                component.trailerAttributeMappingData[childIndex].selectedAttribute = childElement.attributeDictionary.attributeId;
            });
        });
        let index = 0;
        component.cleanTestValues(index);
        index = 1;
        component.cleanTestValues(index);
        index = 2;
        component.cleanTestValues(index);
    });
});


class MockDataService {

    // loginService methods
    // =============================

    getMail(): Observable<any> {

        return (Observable.of("test@test.com"));
    }

    // fileSetupService methods
    // =============================

    getAllAttributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getAttributeList.json");
        return (Observable.of(response));
    }

    getLookupTables(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }

    deleteClone(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }
    saveCloneRecords(): Observable<any> {
        let response = {
            "data": {
                "attributeSectionAssociationList": [{
                    "fsaId": 11427,
                    "fileAttributeAssociations": [
                        {
                            "createdBy": "Dharam Mali",
                            "createdDateTime": "25/02/2019 10:17:23.050 GMT",
                            "updatedBy": "Dharam Mali",
                            "updatedDateTime": "25/02/2019 10:17:23.050 GMT",
                            "faaId": 221653,
                            "attributeRowPosition": 3,
                            "dataType": "VARCHAR",
                            "fileIdentifier": 1851,
                            "isMandatory": false,
                            "lookupTableFileAssociations": [{
                                "recordId": 0
                            }],
                            "fileFormatAttributeAssociation": [
                                {
                                    "updatedBy": "Dharam Mali"
                                }
                            ]
                        }
                    ]
                }]
            }
        };
        // response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }
    cloneRecords(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        return (Observable.of(response));
    }

    getAttributeStandarizedNameListByFileTypeId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }

    getPackageInfoByFileTypeId(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-attribute-mapping-834-file/getLookupTables.json");
        return (Observable.of(response));
    }

    editFiles(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-file-attribute-mapping/populateChildAttr.json");
        return (Observable.of(response));
    }

    getAllIdisRulePrioritySequence(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    removeAttribute(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    markAsTodo(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getAllMasterAttributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    // _ruleEditorService methods
    // =============================

    getSecondaryDataAtrributes(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    getAllRuleTemplates(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/blank.json");
        return (Observable.of(response));
    }

    // toolTipUtils methods
    // =============================

    getPageAndFieldsDetails(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getToolTipTextDetails.json");
        return (Observable.of(response));
    }
    updateFileAttribute(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getToolTipTextDetails.json");
        return (Observable.of(response));
    }
    updateFileSection(): Observable<any> {
        let response;
        response = require("../../../../../assets/test-data/file-setup/al-file-setup/al-notification/getToolTipTextDetails.json");
        return (Observable.of(response));
    }

    error() {
        return false;
    }

    success() {
        return true;
    }
    confirm() {
        return true;
    }

    changeRoute() {
        return true;
    }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
    getPageAndFieldsDetails(adaptWebPageID) {
        let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
        return Observable.of(response);
    }
}
