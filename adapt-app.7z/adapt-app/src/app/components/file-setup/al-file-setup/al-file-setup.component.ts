import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { DATA_TYPES } from "../../../global";
import { FileSetupService } from "../al-file-setup-services/file-setup.service";
import { ToastsManager } from "ng2-toastr";
import { Router, ActivatedRoute } from "@angular/router";
import { FileSetupRedirect } from "../al-file-setup-services/al-file-setup-redirect";
import { NgxPermissionsService } from "ngx-permissions";
import { ConfirmationService } from "primeng/components/common/api";
import { TOAST_SETTING, confAcceptLabel, confRejectLabel, confMessage } from "../../../global";

@Component({
  selector: "al-file-setup",
  templateUrl: "./al-file-setup.component.html",
  styleUrls: ["./al-file-setup.component.scss"]
})
export class AlFileSetupComponent implements OnInit {

  constructor(
    private fileSetupService: FileSetupService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private FileSetupRedirect: FileSetupRedirect,
    private permissionsService: NgxPermissionsService,
    private confirmationService: ConfirmationService
  ) {
  }

  // Common
  metaInfo: any = [];
  editFormRecordId: any;
  editFormRecordVersion: any;
  viewOnly: boolean = false;
  templateType: string = "F";
  showFileDetails: boolean = false;
  tradingPartnerInfo: any;
  isAllowed: boolean = true;
  validationMsg: string;
  MTFileTemplateId: any;
  isClickedOnApproveLink: boolean = false;

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.editFormRecordId = params["id"];
      this.editFormRecordVersion = params["version"];
      this.viewOnly = params["view"] ? true : false;
      this.MTFileTemplateId = params["MTFileTemplateId"];
      let editAndAddTab = this.permissionsService.getPermission("File Setup-Add New file");
      if (this.viewOnly) {
        this.isAllowed = true;
      } else if (editAndAddTab === undefined && this.editFormRecordId !== undefined) {
        this.isAllowed = false;
      } else if (editAndAddTab === undefined && this.editFormRecordId === undefined) {
        this.isAllowed = false;
      } else if (editAndAddTab !== undefined && this.editFormRecordId === undefined) {
        this.isAllowed = true;
      } else if (editAndAddTab !== undefined && this.editFormRecordId !== undefined) {
        this.isAllowed = true;
      }

      if (this.editFormRecordId !== undefined) {
        this.fileSetupService.editFiles(this.editFormRecordId, this.editFormRecordVersion, this.viewOnly, false, 0).subscribe(res => {
          if (!res.error) {
            this.metaInfo = res.data.metaInfo;
            this.tradingPartnerInfo = this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo;
            this.selFileType = this.metaInfo.fileTypeMetaInfo.direction;
            this.showFileDetails = true;
            this.setTab();
            /* istanbul ignore next */
            if (Number(params["tab"]) === 1) {
              if (this.selFileType === "Outbound") {
                this.pageNavigation("extParam");
              } else {
                this.pageNavigation("lookupTable");
              }
            } /* istanbul ignore next */ else if (Number(params["tab"]) === 10) {
              this.viewOnly = true;
              this.pageNavigation("migrations");
            } else if (Number(params["tab"]) === 9) {
              this.isClickedOnApproveLink = true;
              this.viewOnly = true;
              this.pageNavigation("approval");
            } else {
              this.pageNavigation("basicConfiguration");
            }
          } /* istanbul ignore next */  else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        }, /* istanbul ignore next */ error => {
          this.toastr.error("Server Error in getting file data.", "Oops!", TOAST_SETTING);
        });
      } /* istanbul ignore next */ else {
        this.selFileType = "Inbound";
        this.setTab();
        this.pageNavigation("basicConfiguration");
      }
    });
    this.FileSetupRedirect.changeRoute("F");
    this.validationMsg = window["validationMsg"];
  }

  goToFileSetup() {
    this.FileSetupRedirect.changeRoute("F");
    this.router.navigate(["/file-setup"]);
  }

  updateDateAndUpdateBy(event) {
    this.metaInfo.updatedDateTime = event.updatedDateTime;
    this.metaInfo.updatedBy = event.updatedBy;
  }

  // Enable Tab Click

  // Content Loader
  tabContLoader: boolean = false;
  tabNav: Array<{}> = [
    { name: "Basic Configuration", id: "basicConfiguration", isActive: false, isVisible: false, render: "All" },
    { name: "Extraction", id: "extParam", isActive: false, isVisible: false, render: "Outbound" },
    { name: "Lookup Tables", id: "lookupTable", isActive: false, isVisible: false, render: "All" },
    { name: "Attribute Mapping", id: "attrInbound", isActive: false, isVisible: false, render: "Inbound" },
    { name: "Schema Generation", id: "dynSchGen", isActive: false, isVisible: false, render: "Outbound" },
    { name: "Attribute Mapping", id: "attrOutbound", isActive: false, isVisible: false, render: "Outbound" },
    { name: "Notifications", id: "notifications", isActive: false, isVisible: false, render: "All" },
    { name: "Transmission", id: "transmission", isActive: false, isVisible: false, render: "All" },
    { name: "Approval", id: "approval", isActive: false, isVisible: false, render: "All" },
    { name: "Migrations", id: "migrations", isActive: false, isVisible: false, render: "All" },
  ];
  selTabId: string;
  selTab: any = [];
  pageNavigation(e) {
    if (this.redirectFlag) {
      this.confirmationService.confirm({
        message: confMessage,
        accept: () => {
          this.confirmBeforeNavigate(e);
          this.redirectFlag = false;
        }
      });
    } else {
      this.confirmBeforeNavigate(e);
    }
  }
  confirmBeforeNavigate(e) {
    if (this.selTabId !== e) {
      this.tabContLoader = true;
      for (let tab of this.tabNav) {
        if (e === tab["id"]) {
          tab["isActive"] = true;
          this.selTabId = e;
          this.selTab = tab;
        } else {
          tab["isActive"] = false;
        }
      }
    }
  }

  selFileType: string;
  setTab() {
    for (let tab of this.tabNav) {
      if (this.selFileType === tab["render"] || tab["render"] === "All") {
        tab["isVisible"] = true;
      } else {
        tab["isVisible"] = false;
      }
    }
  }
  tabLoader(e) {
    this.tabContLoader = e;
  }

  activeNextTab(event) {
    this.metaInfo = event.metaInfo;
    this.tradingPartnerInfo = this.metaInfo.fileTradingPartnerLobAssoc[0].tradingPartnerInfo;

    this.showFileDetails = true;
    if (event.action === "continue") {
      if (this.metaInfo.fileTypeMetaInfo.direction === "Inbound") {
        this.pageNavigation("lookupTable");
      } else {
        this.pageNavigation("extParam");
      }
    }
  }

  lookUpNext() {
    if (this.selFileType === "Inbound") {
      this.pageNavigation("attrInbound");
    } else {
      this.pageNavigation("dynSchGen");
    }
  }

  // Notification Tab
  transmissionNext() {
    this.pageNavigation("approval");
  }

  // Save data before navigate to other page
  redirectFlag: boolean = false;
  acceptLabel = confAcceptLabel;
  rejectLabel = confRejectLabel;
  confMessage = confMessage;
  pushRedirectFlag(flag) {
    this.redirectFlag = flag;
  }

}