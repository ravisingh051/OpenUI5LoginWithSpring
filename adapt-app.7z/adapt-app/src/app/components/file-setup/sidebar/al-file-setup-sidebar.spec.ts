// ANGULAR
// =========================
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { FilesSetupSidebarComponent } from "./al-file-setup-sidebar";
import { TOKEN_NAME } from "../../login/login.constant";
import { RouterDetailsService } from "../../../services/common/router.details";
import { LoginService } from "../../login/login.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [];

describe("FilesSetupSidebarComponent", () => {
    let component: FilesSetupSidebarComponent;
    let fixture: ComponentFixture<FilesSetupSidebarComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                RouterTestingModule.withRoutes(routes),
                RouterModule.forRoot(routes, { useHash: true }),
                NgxPermissionsModule,
                ToastModule,
                HttpClientTestingModule
            ],
            declarations: [FilesSetupSidebarComponent],
            providers: [
                NgxPermissionsService,
                NgxPermissionsStore,
                NgxRolesService,
                NgxRolesStore,
                ToastsManager,
                RouterDetailsService,
                LoginService,
                { provide: USE_PERMISSIONS_STORE, useValue: {} },
                { provide: USE_ROLES_STORE, useValue: {} },
                { provide: ToastOptions, useClass: MockDataService },
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FilesSetupSidebarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});

class MockDataService {

}