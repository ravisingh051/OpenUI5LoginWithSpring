import { Component, OnInit } from "@angular/core";

@Component({
  selector: "al-file-setup-sidebar",
  templateUrl: "./al-file-setup-sidebar.html"
})
export class FilesSetupSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
