import { Component, Input, OnDestroy, EventEmitter, Output } from "@angular/core";

@Component({
  selector: "accordion",
  template: `
  <ng-content></ng-content>
          `,
  host: {
    "class": "panel-group"
  }
})
export class Accordion {
  groups: Array<AccordionGroup> = [];

  addGroup(group: AccordionGroup): void {
    // this.groups.push(group);
  }

  closeOthers(openGroup: AccordionGroup): void {
    this.groups.forEach((group: AccordionGroup) => {
      if (group !== openGroup) {
        group.isOpen = false;
      }
    });
  }

  removeGroup(group: AccordionGroup): void {
    const index = this.groups.indexOf(group);
    if (index !== -1) {
      this.groups.splice(index, 1);
    }
  }
}

@Component({
  selector: "accordion-group",
  template: `
                <div class="panel panel-default" [ngClass]="{'panel-open': isOpen}">
                  <div class="panel-heading acCustom-noBackground">
                    <h4 class="panel-title acCustom-title">
                    <span class="acCustom-headingLbl">
                      
                     <input (change)="valueChanged($event, this)" id="disabled-input" type="text" size="150" style="width:15%" value="{{heading}}" pInputText [disabled]="disabled" /><i class="fa fa-pencil" aria-hidden="true" (click)="toggleDisabled()">&nbsp;</i>
                      <i class="fa fa-angle-right pull-right toggleBtn" aria-hidden="true" [ngClass]="{'fa-angle-down': isOpen}" (click)="toggleOpen($event)"></i>
                      </span>
                    </h4>
                  </div>
                  <div class="panel-collapse" [hidden]="!isOpen">
                    <div class="panel-body">
                        <ng-content></ng-content>
                    </div>
                  </div>
                </div>
          `,

})
export class AccordionGroup implements OnDestroy {
  private _isOpen: boolean = false;

  disabled: boolean = true;

  toggleDisabled() {
    this.disabled = !this.disabled;
  }

  @Input() heading: string;

  @Input()
  set isOpen(value: boolean) {
    this._isOpen = value;
    if (value) {
      this.accordion.closeOthers(this);
    }
  }

@Output() valueChange: EventEmitter<any> = new EventEmitter();

 valueChanged(ddpvalue, elm) { // You can give any function name

    this.valueChange.emit(ddpvalue);
  }


  get isOpen() {
    return this._isOpen;
  }

  constructor(private accordion: Accordion) {
    this.accordion.addGroup(this);
  }

  ngOnDestroy() {
    this.accordion.removeGroup(this);
  }

  toggleOpen(event: MouseEvent): void {
    event.preventDefault();
    this.isOpen = !this.isOpen;
  }

}
