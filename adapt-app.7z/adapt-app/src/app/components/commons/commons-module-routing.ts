import { ModuleWithProviders, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AlTradingPartnerComponent } from "./al-trading-partner/al-trading-partner.component";
import { AlContactListComponent } from "./al-trading-partner/al-contact-list/al-contact-list.component";
import { AlLobComponent } from "./al-lob/al-lob.component";
import { AlFileTypeListComponent } from "./al-file-type-list/al-file-type-list.component";
import { AlOutputSystemFileComponent } from "./al-output-system-file/al-output-system-file.component";
import { CommonsComponent } from "./commons.component";
import { AlNotificationsComponent } from "./al-notifications/al-notifications.component";
import { AlBlackoutWindowComponent } from "./al-blackout-window/al-blackout-window.component";
import { AlProfileComponent } from "./al-profile/al-profile.component";
import { AlTooltipComponent } from "./al-tooltip/al-tooltip.component";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { AlHeldFilesComponent } from "./al-held-files/al-held-files.component";
import { AlPriorityOrderComponent } from "./al-priority-order/al-priority-order.component";
import { AlApprovePromotionsComponent } from "./al-approve-promotions/al-approve-promotions.component";

const appRoutes: Routes = [
    {
        path: "commons",
        component: CommonsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "contacts",
        component: AlContactListComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "trading-partner",
        component: AlTradingPartnerComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "lob",
        component: AlLobComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "file-type-list",
        component: AlFileTypeListComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "output-system-file-type",
        component: AlOutputSystemFileComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "notifications",
        component: AlNotificationsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "blackout-window",
        component: AlBlackoutWindowComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "profile",
        component: AlProfileComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "tooltip",
        component: AlTooltipComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "priority-order",
        component: AlPriorityOrderComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "held-files",
        component: AlHeldFilesComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "approve-migrations",
        component: AlApprovePromotionsComponent,
        canActivate: [AuthGuard]
    }

];

export const routing: ModuleWithProviders = RouterModule.forChild(appRoutes);