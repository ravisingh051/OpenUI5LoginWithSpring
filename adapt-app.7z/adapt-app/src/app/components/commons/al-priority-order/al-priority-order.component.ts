import { Component, OnInit, ViewChild } from "@angular/core";
import { AlPriorityOrderService } from "./al-priority-order/al-priority-order.service";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { NgForm } from "@angular/forms/src/directives/ng_form";
import { FileSetupService } from "../../file-setup/al-file-setup-services/file-setup.service";
import { NgxPermissionsService } from "ngx-permissions";
import { TOAST_SETTING } from "../../../global";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";

@Component({
  selector: "app-al-priority-order",
  templateUrl: "./al-priority-order.component.html",
  styleUrls: ["./al-priority-order.component.css"],
  providers: [AlPriorityOrderService, FileSetupService]
})
export class AlPriorityOrderComponent implements OnInit {

  priorityOrder: PriorityOrder;
  priorityOrders = [];
  classificationTypes = [];
  selection;
  classTypeObj;
  selectionList = [];
  enableSaveButton: boolean = false;
  yesNoArr = [{ label: "Yes", value: "Yes" }, { label: "No", value: "No" }];
  inOutBoundArr = [{ label: "Inbound", value: "Inbound" }, { label: "Outbound", value: "Outbound" }];
  filterClassificationTypes = [];
  classificationTypesModel;
  filterSelections = [];
  selectionModel;
  showFirstBlock: boolean = true;
  validationMsg: string;
  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  tooltipResult: any;
  pageID: number = 36;

  constructor(private priorityOrderService: AlPriorityOrderService,
    private fileSetupService: FileSetupService,
    public toastr: ToastsManager,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService) {
    this.priorityOrder = new PriorityOrder();
  }

  ngOnInit() {
    this.getPriorityOrder();
    this.validationMsg = window["validationMsg"];
    this.getToolTipTextDetails();
  }

  /**
   * To get list of saved Priority Orders and also getting list of Classification, Trading Partners, File types.
   */
  getPriorityOrder() {
    this.priorityOrderService.getPriorityOrder().subscribe(res => {
      if (!res.error) {
        for (const po of res.data.priorityOrders) {
          po["classificationType"] = { priorityClassTypeId: po.priorityClassTypeId, priorityClassTypeName: po.priorityClassTypeName };
        }
        this.classificationTypes = res.data.classificationTypes;
        this.priorityOrders = res.data.priorityOrders;
        this.updateTableList();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Priority Order.", "Oops!", TOAST_SETTING);
    });
  }

  /**
   * To shift or up and down priority or changing a sequence.
   *
   * @param i index
   * @param position Clicked label either is UP or DOWN
   */
  shiftRows(i, position) {
    let pushObj = Object.assign({}, this.priorityOrders[i]);
    let j = i + 1;
    if (position === "up") {
      if (i !== 0) {
        this.priorityOrders.splice(i, 1);
        this.priorityOrders.splice(i - 1, 0, pushObj);
      }
    }
    if (position === "down") {
      if (i !== this.priorityOrders.length) {
        this.priorityOrders.splice(i, 1);
        this.priorityOrders.splice(i + 1, 0, pushObj);
      }
    }
    this.updateTableList();
    this.enableSaveButton = true;
  }

  /**
   * To display 'List of Classification selection' based on selected 'Classification'.
   *
   * @param event Get clicked classification name
   */
  onSelectClassification(event) {
    this.showFirstBlock = !this.showFirstBlock;
    this.selection = null;
    this.selectionList = [];
    let classificationName = event.originalEvent.target.innerText;
    this.classTypeObj = { priorityClassTypeId: this.priorityOrder.classificationType, priorityClassTypeName: classificationName };
    classificationName = classificationName.toLowerCase().trim();
    switch (classificationName) {
      case "sla":
        this.selectionList = this.yesNoArr;
        break;
      case "file direction":
        this.setDataIntoSelectionList(this.priorityOrderService.getFileDirection());
        break;
      case "file type":
        this.setDataIntoSelectionList(this.priorityOrderService.getFileTypes());
        break;
      case "trading partner":
        this.setDataIntoSelectionList(this.priorityOrderService.getTradingPartners());
        break;
      case "previous day's unfinished jobs":
        this.selectionList = [{ label: "Yes", value: "Yes" }];
        break;
      case "employer":
        this.getFileEmployer();
        break;
      case "file id":
        this.setDataIntoSelectionList(this.priorityOrderService.getFileIds());
        break;
    }
  }

  getFileEmployer() {
    this.fileSetupService.getFileEmployerAssoc().subscribe(res => {
      if (!res.error) {
        for (let emplyr of res.data) {
          this.selectionList.push({ label: emplyr.employerName, value: emplyr.employerId });
        }
      }
    });
  }

  /**
   * This is a generic method.
   * It will just subscribe the response and set the data.
   *
   * @param observer Get data by calling end point
   */
  setDataIntoSelectionList(observer) {
    observer.subscribe(res => {
      if (!res.error) {
        this.selectionList = res.data;
      }
    });
  }

  onSelectSelection(event) {
    this.priorityOrder.selection = event.originalEvent.target.innerText;
  }

  /**
   * To adding Priority Order.
   *
   * @param form Reference object of form
   */
  addPriorityOrder(form: NgForm) {
    this.selectionList = [];
    let isDuplicate = false;
    for (const po of this.priorityOrders) {
      this.priorityOrder.selection = String(this.priorityOrder.selection).trim();
      po.selection = String(po.selection).trim();
      if (String(po.classificationType.priorityClassTypeId) === String(this.classTypeObj.priorityClassTypeId) && po.selection === this.priorityOrder.selection) {
        form.resetForm();
        isDuplicate = true;
        break;
      }
    }

    if (!isDuplicate) {
      const obj: PriorityOrder = {
        classificationType: this.classTypeObj,
        selection: this.priorityOrder.selection,
        selectionId: this.selection,
        notes: this.priorityOrder.notes,
        sequenceNumber: this.priorityOrders.length + 1,
        active: true
      };
      this.priorityOrders.push(obj);
      form.resetForm();
      this.updateTableList();
      this.enableSaveButton = true;
    } else {
      this.toastr.error("This parameter has already been added to the priority queue", "Oops!", TOAST_SETTING);
    }
  }

  /**
   * To remove row.
   *
   * @param index Clicked row index
   */
  removePriorityOrder(index) {
    this.priorityOrders.splice(index, 1);
    this.updateTableList();
    this.enableSaveButton = true;
  }

  /**
   * To save Priority Orders.
   */
  savePriorityOrder() {
    this.enableSaveButton = false;
    for (let i = 0; i < this.priorityOrders.length; i++) {
      this.priorityOrders[i].sequenceNumber = i + 1;
      this.priorityOrders[i].selection = String(this.priorityOrders[i].selection).trim();
    }
    this.priorityOrderService.savePriorityOrder(this.priorityOrders).subscribe(res => {
      if (!res.error) {
        for (const po of res.data) {
          po["classificationType"] = { priorityClassTypeId: po.priorityClassTypeId, priorityClassTypeName: po.priorityClassTypeName };
        }
        this.priorityOrders = res.data;
        this.updateTableList();
        this.toastr.success("Priority order saved successfully.", "Success!");
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in save priority order.", "Oops!", TOAST_SETTING);
    });
  }

  /**
   * To updating a data table after doing changes in 'priorityOrders' array.
   */
  updateTableList() {
    this.priorityOrders = [...this.priorityOrders];
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }
}

export class PriorityOrder {
  classificationType;
  selection: string;
  selectionId: string;
  notes: string;
  sequenceNumber: number;
  active: boolean = true;
}