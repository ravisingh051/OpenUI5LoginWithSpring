import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AppUtility } from "../../../sharedModules/al-popover/utility";

import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, DialogModule, ListboxModule, OverlayPanelModule, DropdownModule, OverlayPanel, AutoCompleteModule, AutoComplete } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { TOKEN_NAME } from "../../login/login.constant";
import { LoginService } from "../../login/login.service";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { DatePipe } from "@angular/common";
import { By } from "@angular/platform-browser";
import { TemplateRef, DebugElement } from "@angular/core";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { AlPriorityOrderService } from "./al-priority-order/al-priority-order.service";
import { FileSetupService } from "../../file-setup/al-file-setup-services/file-setup.service";

import { AlPriorityOrderComponent } from "./al-priority-order.component";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlPriorityOrderComponent", () => {
  let component: AlPriorityOrderComponent;
  let fixture: ComponentFixture<AlPriorityOrderComponent>;
  let toastService, alPriorityOrderService;
  let ngxPermission;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlPriorityOrderComponent, {
      set: {
        providers: [
          { provide: AlPriorityOrderService, useClass: MockDataService },
          { provide: FileSetupService, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        ListboxModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlPriorityOrderComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        AutoComplete,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        { provide: FileSetupService, useClass: MockDataService },
        { provide: AlPriorityOrderService, useClass: MockDataService },
        { provide: ToastsManager, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: LoginService, useClass: FakeLoginService },
        { provide: Observable, useClass: "MockDataService" },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlPriorityOrderComponent);
    component = fixture.componentInstance;
    toastService = TestBed.get(ToastsManager);
    ngxPermission = TestBed.get(NgxPermissionsService);
    ngxPermission.addPermission("Job Prioritization-View All Prioritization");
    ngxPermission.addPermission("Job Prioritization-Add Prioritization");
    ngxPermission.addPermission("Job Prioritization-Remove Prioritization");
    ngxPermission.addPermission("accessDenied");
    alPriorityOrderService = fixture.debugElement.injector.get(AlPriorityOrderService);
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should on init", () => {
    component.ngOnInit();
  });
  it("should be oninit error handle", async(() => {
    spyOn(alPriorityOrderService, "getPriorityOrder").and.returnValue(Observable.throw("No Data"));
    component.ngOnInit();
  }));
  it("should on shiftRows up Down", () => {
    let i = 1;
    component.shiftRows(i, "up");
    component.priorityOrders = [{
      "active": true,
      "notes": "sla",
      "selectionId": "Yes",
      "priorityClassTypeId": "1",
      "priorityClassTypeName": "SLA",
      "selection": "Yes"
    },
    {
      "active": true,
      "notes": "238",
      "selectionId": "238",
      "priorityClassTypeId": "2",
      "priorityClassTypeName": "File ID",
      "selection": "238"
    }];
    component.shiftRows(i, "down");
  });

  it("should on onSelectClassification sla", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "sla" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e
    };
    component.onSelectClassification(e);
  });

  it("should on onSelectClassification file direction", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "file direction" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });
  it("should on onSelectClassification file type", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "file type" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });
  it("should on onSelectClassification trading partner", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "trading partner" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });
  it("should on onSelectClassification previous day's unfinished jobs", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "previous day's unfinished jobs" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });
  it("should on onSelectClassification employer", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "employer" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });
  it("should on onSelectClassification file id", () => {
    component.priorityOrder.classificationType = 123;
    let e = { originalEvent: { target: { innerText: "file id" } } };
    component.classTypeObj = {
      "priorityClassTypeId": component.priorityOrder.classificationType,
      "priorityClassTypeName": e,
    };
    component.onSelectClassification(e);
  });

  it("should on onSelectSelection", () => {
    let e = { originalEvent: { target: { innerText: "employer" } } };
    component.onSelectSelection(e);
  });

  it("should addPriorityOrder function", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        createdBy: "",
        valueOf: 123
      }
    };
    component.priorityOrder.selection = "238";
    component.addPriorityOrder(validForm);
  });
  it("should addPriorityOrder function type check", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        createdBy: "",
        valueOf: 123
      }
    };
    // component.priorityOrders = [{
    //   "active": true,
    //   "notes": "sla",
    //   "selectionId": "Yes",
    //   "priorityClassTypeName": "SLA",
    //   "selection": "yes"
    // },
    // {
    //   "active": true,
    //   "notes": "238",
    //   "selectionId": "238",
    //   "priorityClassTypeName": "File ID",
    //   "selection": "238"
    // }];
    // component.classTypeObj.priorityClassTypeId='1';
    component.addPriorityOrder(validForm);
  });
  it("should on removePriorityOrder", () => {
    let index = 2;
    component.removePriorityOrder(index);
  });

  it("should on savePriorityOrder", () => {
    component.priorityOrders = [{
      "active": true,
      "notes": "sla",
      "selectionId": "Yes",
      "priorityClassTypeId": "1",
      "priorityClassTypeName": "SLA",
      "selection": ""
    },
    {
      "active": true,
      "notes": "238",
      "selectionId": "238",
      "priorityClassTypeId": "2",
      "priorityClassTypeName": "File ID",
      "selection": ""
    }];
    component.savePriorityOrder();
  });

  it("should on savePriorityOrder error handle", () => {
    component.priorityOrders = [{
      "active": true,
      "notes": "sla",
      "selectionId": "Yes",
      "priorityClassTypeId": "1",
      "priorityClassTypeName": "SLA",
      "selection": ""
    },
    {
      "active": true,
      "notes": "238",
      "selectionId": "238",
      "priorityClassTypeId": "2",
      "priorityClassTypeName": "File ID",
      "selection": ""
    }];
    spyOn(alPriorityOrderService, "savePriorityOrder").and.returnValue(Observable.throw("No Data"));
    component.savePriorityOrder();
  });

  it("should and displayToolTipText()", () => {
    component.toolTipPageFieldsData = {
      "File status": {
        "tooltipDesc": "Test Email Address description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
    });
    component.hideToolTipText(event);
    btnNextStep.click();
  });

});


export class FakeNgxPermission extends NgxPermissionsService {
}

class MockDataService {
  getPriorityOrder() {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/priorityGet.json");
    return (Observable.of(response));
  }
  savePriorityOrder(Data) {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/savePriorityOrder.json");
    return (Observable.of(response));
  }
  getFileTypes() {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/priorityGet.json");
    return (Observable.of(response));
  }
  getFileDirection() {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/priorityGet.json");
    return (Observable.of(response));
  }
  getFileIds() {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/priorityGet.json");
    return (Observable.of(response));
  }
  getTradingPartners() {
    let response;
    response = require("../../../../assets/test-data/commons/PriorityOrder/priorityGet.json");
    return (Observable.of(response));
  }
  getFileEmployerAssoc() {
    let response;
    response = require("../../../../assets/test-data/file-setup/al-file-setup/al-file-basic-configuration/getFileEmployerAssoc.json");
    return (Observable.of(response));
  }
  error() {
    return true;
  }
  success() {
    return true;
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
export class FakeLoginService {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>("User");
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>("User");

  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }

  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }
}

