import { Injectable } from "@angular/core";
import { ApiEnvService } from "../../../../env.service";
import { AuthHttp } from "angular2-jwt";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlPriorityOrderService {
  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/PriorityOrder";
  masterMappingURL = this.apiEnvEndpoint + "/master";

  getPriorityOrder(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/get");
  }

  savePriorityOrder(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/save", data);
  }

  getFileTypes(): Observable<any> {
    return this.http.get(this.masterMappingURL + "/fileTypes");
  }

  getFileDirection(): Observable<any> {
    return this.http.get(this.masterMappingURL + "/fileDirection");
  }

  getFileIds(): Observable<any> {
    return this.http.get(this.masterMappingURL + "/fileIds");
  }

  getTradingPartners(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/tradingPartners");
  }
}
