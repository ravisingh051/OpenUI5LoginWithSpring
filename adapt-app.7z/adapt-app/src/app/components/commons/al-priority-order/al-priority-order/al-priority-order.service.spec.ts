import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { AlPriorityOrderService } from "./al-priority-order.service";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlPriorityOrderService", () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AlPriorityOrderService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  }));

  it("getPriorityOrder", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

    contactService.getPriorityOrder({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));

  it("savePriorityOrder", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

    contactService.savePriorityOrder({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));

  it("getFileTypes", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

    contactService.getFileTypes({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));
  it("getFileDirection", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

    contactService.getFileDirection({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));

  it("getFileIds", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

    contactService.getFileIds({}).subscribe((res) => {
      expect(res.data.length).toBe(16);
    });
  })));
  it("getTradingPartners", async(inject([AlPriorityOrderService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

    contactService.getTradingPartners({}).subscribe((res) => {
      expect(res.data.length).toBe(16);
    });
  })));
});