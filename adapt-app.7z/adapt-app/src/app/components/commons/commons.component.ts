import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-commons",
  templateUrl: "./commons.component.html",
  styleUrls: ["./commons.component.scss"]
})
export class CommonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
