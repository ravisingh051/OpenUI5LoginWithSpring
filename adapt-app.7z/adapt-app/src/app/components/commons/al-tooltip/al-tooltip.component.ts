import { logger } from "codelyzer/util/logger";
import { Component, OnInit, Input, ViewChild, ViewChildren, QueryList } from "@angular/core";

import { NgForm, FormControl, FormGroup, Validators, FormArray } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { TooltipConfig } from "./al-tooltip-model/tooltip-config.model";
import { TooltipService } from "./al-tooltip-service/tooltip.service";
import { CustomValidators } from "ng2-validation";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { Observable } from "rxjs/Observable";
import { TOAST_SETTING } from "../../../global";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { ApiEnvService } from "../../../env.service";
import { AlDashboardService } from "../../al-dashboard/al-dashboard.services";

@Component({
    selector: "app-al-tooltip",
    templateUrl: "./al-tooltip.component.html",
    styleUrls: ["./al-tooltip.component.scss"],
    providers: [TooltipService, ConfirmationService]
})

export class AlTooltipComponent implements OnInit {

    // pageList:any = [];
    filterForTooltipIdModel: any[];
    tooltip: any;
    detailsId: any;
    fieldList: any = [];
    fieldId: any;
    responseData: any;
    pageDetails: any = [];
    pageFieldsDetails: any = [];
    filterForStatus: any;
    filterForStatusModel: any;
    filterFileDescription: any;
    filterFieldName: any;
    filterFieldNameModel: any;
    filterFileDescriptionModel: any;
    filterForTooltipId: any;
    filterForTooltipPage: any;
    filterForTooltipFieldIdModel: any;
    tooltipReadMoreLink: any;
    tooltipReadMoreLinkModel: any;
    filterLastUpdate: any;
    filterLastUpdateModel: any;
    filterLastUpdatedBy: any;
    filterLastUpdatedByModel: any;
    selectedPanel: any;
    selectedToolTipData: TooltipConfig;
    @Input() filtersAdaptPage;
    // @ViewChild('tooltipFieldId') tooltipField: Dropdown;
    filtersAdaptPageFields: any = [];
    isEdit: boolean = false;
    isDisabled: boolean = false;
    tableDataLoading: boolean = true;
    isActive: boolean = false;
    fieldResponseFlag: boolean = false;
    tooltipModel: TooltipConfig;
    validationMsg: string;
    @ViewChildren("dropdown") dropDown: QueryList<Dropdown>;
    @ViewChild("dt") dataTable: DataTable;
    /* ToolTip display OnMouse Click */
    toolTipPageFieldsData: any = [];
    tooltipResult: any;
    pageID: number = 42;
    // serviceMappingURL = this.apiEnvEndpoint + "/ToolTip";

    constructor(
        private tooltipService: TooltipService,
        public toastr: ToastsManager,
        private router: Router,
        private route: ActivatedRoute,
        private confirmationService: ConfirmationService,
        private permissionsService: NgxPermissionsService,
        private toolTipUtils: ToolTipUtilService
    ) {

    }

    ngOnInit() {
        this.tooltipModel = new TooltipConfig();
        this.tooltipModel.tooltipDisplay = false;
        this.getAdaptPage();
        this.viewTooltipData();
        this.validationMsg = window["validationMsg"];
        this.getToolTipTextDetails();
    }

    getAdaptPage() {
        this.detailsId = null;
        this.tooltipService.getPageDetails().subscribe(res => {
            this.pageDetails = res.data;
            this.populatePageList();
        }, error => {
            this.toastr.error("Server Error in fetching LOB list.", "Oops!", TOAST_SETTING);
        });
    }
    populatePageList() {
        let _tpList = [];
        if (this.pageDetails.length !== 0) {
            for (let obj of this.pageDetails) {
                _tpList.push({
                    "label": obj.adaptWebPageName,
                    "value": obj.adaptWebPageId
                });
            }
            this.filtersAdaptPage = _tpList;
            this.filtersAdaptPage.unshift({ label: "Please Choose One", valule: null });
        }
    }

    // method called on Fields Changes..
    getWebPageFields(event) {
        if (event !== undefined) {
            if (event !== null || event !== "") {
                this.tooltipService.getWebPageFields(parseInt(event)).subscribe(res => {
                    this.pageFieldsDetails = res.data;
                    if (this.pageFieldsDetails.length > 0) {
                        this.populatePageFieldsList();
                    } else {
                        this.filtersAdaptPageFields = [];
                    }
                });
            }
        } else {
            this.filtersAdaptPageFields = [];
            this.resetForm();
        }
    }

    populatePageFieldsList() {
        let _tpList = [];
        if (this.pageFieldsDetails.length !== 0) {
            for (let obj of this.pageFieldsDetails) {
                _tpList.push({
                    "label": obj.adaptWebPageFieldName,
                    "value": obj.adaptWebPageFieldId
                });
            }
            this.filtersAdaptPageFields = _tpList;
            this.filtersAdaptPageFields.unshift({ label: "Please Choose One", valule: null });
        }
    }

    // code to populate disbaled dropdown data while clicking on edit.(Start)
    populateDropDownList() {
        let tmp;
        for (let obj of this.tooltip) {
            if (obj.tooltipId === this.selectedToolTipData.tooltipId) {
                tmp = obj;
            }
        }
        let fieldData = tmp.tooltipFieldId;
        let adaptData = tmp.tooltipFieldId.adaptWebPageId;
        this.pupulatePageDropDown(adaptData);
        this.pupulatePageFieldsDropDown(fieldData);
    }
    pupulatePageDropDown(adaptData) {
        let _tpList = [];
        _tpList.push({
            "label": adaptData.adaptWebPageName,
            "value": adaptData.adaptWebPageId
        });
        this.filtersAdaptPage = _tpList;
    }
    pupulatePageFieldsDropDown(fieldData) {
        let _tpList = [];
        _tpList.push({
            "label": fieldData.adaptWebPageFieldName,
            "value": fieldData.adaptWebPageFieldId
        });
        this.filtersAdaptPageFields = _tpList;
    }

    // (sets field desc in model explicitly on the basis of fields changes)
    autoPopulateTooltip(event) {
        this.getTooltipDetailsById(event);
    }
    // set data in tooltip if already saved for fields
    getTooltipDetailsById(event) {
        if (event.value !== undefined) {
            this.tooltipService.getTooltipById(parseInt(event.value)).subscribe(res => {
                if (res.data !== null && res.data.length !== 0) {
                    this.responseData = res.data;
                    this.tooltipModel.tooltipDesc = this.responseData.tooltipDesc;
                    this.tooltipModel.readMoreLink = this.responseData.readMoreLink;
                    this.tooltipModel.tooltipDisplay = this.responseData.tooltipDisplay;
                    this.tooltipModel.tooltipFieldDesc = this.responseData.tooltipFieldDesc;
                    this.tooltipModel.tooltipId = this.responseData.tooltipId;
                    this.isEdit = true;
                    this.fieldResponseFlag = true;
                } else {
                    this.resetForm();
                    this.fieldResponseFlag = false;
                }
            });
        } else {
            this.resetForm();
            this.fieldResponseFlag = false;
        }
    }
    resetForm() {
        this.tooltipModel.tooltipDesc = null;
        this.tooltipModel.readMoreLink = null;
        this.tooltipModel.tooltipDisplay = false;
        this.tooltipModel.tooltipFieldDesc = null;
        this.isEdit = false;
    }
    addToolTipData(tooltipForm: NgForm) {
        let dropArr = this.dropDown.toArray();
        dropArr.forEach((ele) => {
            ele.filterValue = null;
            ele.value = null;
            ele.resetFilter();
        });

        if (this.tooltipModel.tooltipFieldId === undefined || this.tooltipModel.tooltipFieldId === 0) {
            this.toastr.error("Page is required.", "Oops!", TOAST_SETTING);
            return false;
        }
        if (this.tooltipModel.tooltipDesc === null || this.tooltipModel.tooltipDesc === "") {
            this.toastr.error("Text is required.", "Oops!", TOAST_SETTING);
            return false;
        }
        if (!this.isEdit) {
            this.updateFieldDesc(this.tooltipModel.tooltipFieldId);
            this.tooltipService.addToolTipData(this.tooltipModel).subscribe(res => {
                if (!res.error) {
                    this.toastr.success("Tool Tip added successfully.", "Success!");
                    this.dataTable.reset();
                    this.getAdaptPage();
                    this.viewTooltipData();
                    tooltipForm.resetForm();
                    this.tooltipModel.tooltipDisplay = false;
                    this.filtersAdaptPageFields = [];
                }
                else {
                    this.toastr.error(res.message, "Oops!", TOAST_SETTING);
                }
            }, error => {
                this.toastr.error("Server Error in adding Tooltip.", "Oops!", TOAST_SETTING);
            });
        } else {
            if (this.fieldResponseFlag) {
                this.tooltipModel.tooltipFieldId = this.responseData.tooltipFieldId;
            }
            this.tooltipService.updateTooltip(this.tooltipModel).subscribe(res => {
                if (!res.error) {
                    this.toastr.success("Tool Tip updated successfully.", "Success!");
                    this.dataTable.reset();
                    this.getAdaptPage();
                    this.viewTooltipData();
                    tooltipForm.resetForm();
                    this.tooltipModel.tooltipDisplay = false;
                    this.isEdit = false;
                    this.isDisabled = false;
                    this.fieldResponseFlag = false;
                    this.filtersAdaptPageFields = [];
                }
                else {
                    this.toastr.error(res.message, "Oops!", TOAST_SETTING);
                }
            }, error => {
                this.toastr.error("Server Error in editing Tooltip.", "Oops!", TOAST_SETTING);
            });

        }
    }

    viewTooltipData() {
        this.tableDataLoading = true;
        this.tooltipService.getTooltip().subscribe(res => {
            this.tooltip = res.data;
            this.populateFilterDropDown();
            this.tableDataLoading = false;
        });
    }
    populateFilterDropDown() {
        this.populateFilterForFieldName();
        this.populateFilterForPage();
        this.populateFilterForDescription();
        this.populateFilterStatus();
        this.populateFilterLastUpdate();
        this.populateFilterLastUpdatedBy();
        this.populateTooltipReadMoreLink();
    }

    populateFilterForPage() {
        this.filterForTooltipPage = [];
        this.filterForTooltipPage = [{ label: "All", value: null }];
        let _filterForTooltipFieldId: any = [];
        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {
                if (this.tooltip[i].tooltipFieldId !== null && this.tooltip[i].tooltipFieldId.adaptWebPageId !== null) {
                    let tmpId = this.tooltip[i].updatedBy !== null ? this.tooltip[i].tooltipFieldId.adaptWebPageId.adaptWebPageName : this.tooltip[i].tooltipFieldId.adaptWebPageId.adaptWebPageName;
                    if (_filterForTooltipFieldId.indexOf(tmpId) === -1) {
                        _filterForTooltipFieldId.push(tmpId);
                    }
                }
            };
        }
        for (let value of _filterForTooltipFieldId) {
            this.filterForTooltipPage.push({ label: value, value: value });
        }
        this.filterForTooltipFieldIdModel = null;
    }

    populateFilterForFieldName() {
        this.filterFieldName = [];
        this.filterFieldName = [{ label: "All", value: null }];
        let _filterFieldName: any = [];

        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {

                if (_filterFieldName.indexOf(this.tooltip[i].tooltipFieldId.adaptWebPageFieldName) === -1) {
                    _filterFieldName.push(this.tooltip[i].tooltipFieldId.adaptWebPageFieldName);
                }
            };
        }
        for (let value of _filterFieldName) {
            this.filterFieldName.push({ label: value, value: value });
        }
        this.filterFieldNameModel = null;
    }

    populateFilterForDescription() {
        this.filterFileDescription = [];
        this.filterFileDescription = [{ label: "All", value: null }];
        let _filterFileDescription: any = [];

        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {

                if (_filterFileDescription.indexOf(this.tooltip[i].tooltipDesc) === -1) {
                    _filterFileDescription.push(this.tooltip[i].tooltipDesc);
                }
            };
        }
        for (let value of _filterFileDescription) {
            this.filterFileDescription.push({ label: value, value: value });
        }
        this.filterFileDescriptionModel = null;
    }
    populateFilterLastUpdate() {
        this.filterLastUpdate = [];
        this.filterLastUpdate = [{ label: "All", value: null }];
        let _filterLastUpdate: any = [];

        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {
                if (this.tooltip[i].updatedDateTime != null) {
                    if (_filterLastUpdate.indexOf(this.tooltip[i].updatedDateTime) === -1) {
                        let temp = this.tooltip[i].updatedDateTime.replace(/\s*[a-z]+/ig, "");
                        this.tooltip[i].lastUpdatedDateTime = new Date(temp).getTime();
                        _filterLastUpdate.push(this.tooltip[i].lastUpdatedDateTime);
                        this.filterLastUpdate.push({ label: this.tooltip[i].updatedDateTime, value: this.tooltip[i].lastUpdatedDateTime });
                    }
                }
            }
        }
        this.filterLastUpdateModel = null;
    }

    populateFilterLastUpdatedBy() {
        this.filterLastUpdatedBy = [];
        this.filterLastUpdatedBy = [{ label: "All", value: null }];
        let _filterLastUpdatedBy: any = [];


        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {
                let tmpName = this.tooltip[i].updatedBy !== null ? this.tooltip[i].updatedBy : this.tooltip[i].createdBy;
                if (_filterLastUpdatedBy.indexOf(tmpName) === -1) {
                    _filterLastUpdatedBy.push(tmpName);
                }
            };
        }
        for (let value of _filterLastUpdatedBy) {
            this.filterLastUpdatedBy.push({ label: value, value: value });
        }
        this.filterLastUpdatedByModel = null;
    }

    populateFilterStatus() {
        this.filterForStatus = [
            { label: "All", value: null },
            { label: "Active", value: true },
            { label: "Inactive", value: false }
        ];
        this.filterForStatusModel = null;
    }

    populateTooltipReadMoreLink() {
        this.tooltipReadMoreLink = [];
        this.tooltipReadMoreLink = [{ label: "All", value: null }];
        let _tooltipReadMoreLink: any = [];
        if (this.tooltip !== null) {
            for (let i = 0; i < this.tooltip.length; i++) {

                if (_tooltipReadMoreLink.indexOf(this.tooltip[i].readMoreLink) === -1) {
                    _tooltipReadMoreLink.push(this.tooltip[i].readMoreLink);
                }
            };
        }
        for (let value of _tooltipReadMoreLink) {
            this.tooltipReadMoreLink.push({ label: value, value: value });
        }
        this.tooltipReadMoreLinkModel = null;
    }

    btnCancel() {
        this.router.navigate(["/commons"]);
    }

    rowAction(event, rowData, index, overlaypanel: OverlayPanel) {
        overlaypanel.toggle(event);
        this.selectedPanel = overlaypanel;
        this.selectedToolTipData = rowData;
        if (rowData.tooltipDisplay) {
            this.isActive = false;
        } else {
            this.isActive = true;
        }
    }

    updateStatus(overlaypanel: OverlayPanel, condition) {
        this.tooltipModel = new TooltipConfig();
        this.tooltipModel.readMoreLink = this.selectedToolTipData.readMoreLink;
        this.tooltipModel.tooltipDisplay = condition;
        this.tooltipModel.tooltipDesc = this.selectedToolTipData.tooltipDesc;
        this.tooltipModel.tooltipFieldId = this.selectedToolTipData.tooltipFieldId;
        this.tooltipModel.tooltipId = this.selectedToolTipData.tooltipId;
        this.tooltipModel.uniqueIdentifier = this.selectedToolTipData.uniqueIdentifier;
        // this.tooltipModel.tooltipFieldDesc = this.selectedToolTipData.tooltipFieldDesc;
        this.tooltipService.updateTooltip(this.tooltipModel).subscribe(res => {
            if (!res.error) {
                this.toastr.success("Tool Tip status updated successfully.", "Success!");
                this.getAdaptPage();
                this.viewTooltipData();
                this.tooltipModel = new TooltipConfig();
                this.tooltipModel.tooltipDisplay = false;
                this.isEdit = false;
                this.isDisabled = false;
                this.filtersAdaptPageFields = [];
                overlaypanel.hide();
            }
            else {
                this.toastr.error(res.message, "Oops!", TOAST_SETTING);
            }
        }, error => {
            this.toastr.error("Server Error in updation status for Tooltip.", "Oops!", TOAST_SETTING);
        });
    }
    editProfile(overlaypanel: OverlayPanel) {
        this.tooltipModel = new TooltipConfig();
        this.tooltipModel.readMoreLink = this.selectedToolTipData.readMoreLink;
        this.tooltipModel.tooltipDisplay = this.selectedToolTipData.tooltipDisplay;
        this.tooltipModel.tooltipDesc = this.selectedToolTipData.tooltipDesc;
        this.tooltipModel.tooltipFieldId = this.selectedToolTipData.tooltipFieldId;
        this.tooltipModel.tooltipId = this.selectedToolTipData.tooltipId;
        this.tooltipModel.uniqueIdentifier = this.selectedToolTipData.uniqueIdentifier;
        // this.tooltipModel.tooltipFieldDesc = this.selectedToolTipData.tooltipFieldDesc;
        this.populateDropDownList();
        this.isEdit = true;
        this.isDisabled = true;
        overlaypanel.hide();
        window.scrollTo(0, 0);
    }
    updateFieldDesc(model) {
        this.filtersAdaptPageFields.forEach(element => {
            if (element.value === model) {
                this.tooltipModel.tooltipFieldDesc = element.label;
            }
        });
    }
    getToolTipTextDetails() {
        this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
            this.toolTipPageFieldsData = res.data;
        });
    }

    @ViewChild("dynamicPopover") dynamicPopover;
    popOverContent: any = {};
    displayToolTipText(event, value, pos) {
        this.tooltipResult = this.toolTipPageFieldsData[value];
        if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
            this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
        } else {
            this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
        }
        this.dynamicPopover.position = pos;
        this.dynamicPopover.showPopOver(event);
    }
    hideToolTipText(event) {
        this.dynamicPopover.hidePopOver(event);
    }

    exportAll() {
        this.tooltipService.exportAllTooltips();
    }
    uploadFileModel: boolean = false;
    importAll(event) {
        this.uploadFileModel = true;
        this.isFileUploaded = false;
    }

    uploadFileNameModel: any;
    isFileValid: any = true;
    transNameModel: any;
    isFileUploaded: boolean = false;
    saveFile(form: NgForm) {

        if (this.isFileValid) {
            let formData = new FormData();
            let file;
            if (this.uploadFileNameModel === undefined) {
                this.toastr.error("Please select file to import!", "Oops!", TOAST_SETTING);
                return false;
            } else {
                file = this.uploadFileNameModel;
            }
            formData.append("file", file);
            this.tooltipService.importAllTooltips(formData).subscribe(res => {
                if (!res.error) {
                    this.uploadFileModel = false;
                    this.isFileUploaded = true;
                    this.toastr.success("File Imported Successfully!");
                    form.resetForm();
                }
                else {
                    this.toastr.error("Error while importing a file!", "Oops!", TOAST_SETTING);
                }
            }, error => {
                let errorMsg = error.error.message;
                if (errorMsg === "FILE_UPLOAD_ERROR") {
                    this.toastr.error("Invalid File Upload!", "Oops!", TOAST_SETTING);
                } else {
                    this.toastr.error("Error while importing a file!", "Oops!", TOAST_SETTING);
                }
            });
        }
    }

    cancelFileUpload(form: NgForm) {

        this.uploadFileModel = false;
        form.resetForm();
    }

    uploadFile(event) {

        let file = this.getFile(event);
        if (file != null) {
            this.uploadFileNameModel = this.getFile(event);
        }
    }

    getFile(event) {

        event.preventDefault();
        let fileList = event.target.files;
        if (fileList.length > 0) {
            let file = fileList[0];
            let validFormats = ["json", "JSON"];
            let value = file.name, ext = value.substring(value.lastIndexOf(".") + 1).toLowerCase();
            if (validFormats.indexOf(ext) === -1) {
                this.toastr.error("Please upload the valid file format", "Error!", TOAST_SETTING);
                event.target.value = "";
                this.isFileValid = false;
            } else {
                this.isFileValid = true;
                return file;
            }
        }
    }

}