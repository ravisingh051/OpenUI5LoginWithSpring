import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, DataTableModule, ConfirmationService } from "primeng/primeng";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { tick } from "@angular/core/testing";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService } from "ngx-permissions";
import { TooltipService } from "./al-tooltip-service/tooltip.service";
import { LoginService } from "../../login/login.service";

import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlTooltipComponent } from "./al-tooltip.component";
import { TOKEN_NAME } from "../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button, element, by, promise } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { create } from "domain";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlTooltipComponent", () => {
  let component: AlTooltipComponent;
  let ngxPermission;
  let fixture: ComponentFixture<AlTooltipComponent>;
  let overlaypanel: OverlayPanel;
  let toastService, tooltipService;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlTooltipComponent, {
      set: {
        providers: [
          { provide: TooltipService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes([
        ]),
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        ToastModule,
        HttpClientTestingModule
      ],
      declarations: [AlTooltipComponent, AlSidebarComponent, AlCommonsModuleSidebar, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        LoginService,
        ToastOptions,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        { provide: TooltipService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: "MockDataService" },
        { provide: Observable, useClass: "MockDataService" },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToolTipUtilService, useClass: "MockDataService" },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    ngxPermission = TestBed.get(NgxPermissionsService);
    fixture = TestBed.createComponent(AlTooltipComponent);
    component = fixture.componentInstance;
    ngxPermission.addPermission("EditContact", () => { return true; });
    ngxPermission.addPermission("AddContact", () => { return true; });
    ngxPermission.addPermission("DeleteContact", () => { return true; });
    toastService = TestBed.get(ToastsManager);
    tooltipService = fixture.debugElement.injector.get(TooltipService);
    fixture.detectChanges();
  });

  it("should create", () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it("should be logging user", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  }));

  it("should be getPageDetails", async(() => {
    spyOn(tooltipService, "getPageDetails").and.returnValue(Observable.throw("No Data"));
    fixture.detectChanges();
    component.ngOnInit();
  }));
  it("should be getWebPageFields", async(() => {
    let event = {
      test: 124
    };
    component.getWebPageFields(event);
  }));

  it("should be getWebPageFields else", async(() => {

    component.pageFieldsDetails = [];
    let event = undefined;
    component.getWebPageFields(event);
  }));

  it("should call overlaypanel popup fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    let formButton = fixture.debugElement.query(By.css("form")).queryAll(By.css("button"));
    formButton[0].nativeElement.click();
  });

  it("should call overlaypanel popup fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).queryAll(By.css("a"));
    editContactButton[0].nativeElement.click();
    editContactButton[1].nativeElement.click();
    let formButton = fixture.debugElement.query(By.css("form")).queryAll(By.css("button"));
    formButton[0].nativeElement.click();
  });

  it("should be autoPopulateTooltip", async(() => {
    let event = {
      value: 124
    };
    component.autoPopulateTooltip(event);
  }));
  it("should be autoPopulateTooltip else", async(() => {
    let event = {
      test: "test"
    };
    component.autoPopulateTooltip(event);
  }));

  it("should be call addToolTipData valid else", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();

    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        tooltippage: "",
        field: "",
        status: "",
        upadte: false
      }
    };
    component.addToolTipData(validForm);
    component.tooltipModel.tooltipFieldId = null;
    component.tooltipModel.tooltipFieldId = undefined;

    fixture.detectChanges();
    component.addToolTipData(validForm);
  });

  it("should be call addToolTipData valid", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());

    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();

    let InvalidForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        tooltippage: "",
        field: "",
        status: "",
        upadte: false
      }
    };
    let tooltipService = fixture.debugElement.injector.get(TooltipService);
    component.addToolTipData(InvalidForm);
    component.tooltipModel.tooltipFieldId = undefined;
    component.tooltipModel.tooltipFieldId = 0;
    spyOn(tooltipService, "updateTooltip").and.returnValue(Observable.throw("No Data"));
    fixture.detectChanges();
    component.addToolTipData(InvalidForm);
  });

  it("should be call addToolTipData valid for isEdit", () => {
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        tooltipName: "CVT Profile Test1",
        tooltipFieldId: "",
        updatedBy: "",
        fileDirection: "",
        prodProfileType: ""
      }
    };
    component.isEdit = false;
    component.addToolTipData(validForm);
  });

  it("should be call addToolTipData valid for addToolTipData error", () => {
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        tooltipName: "CVT Profile Test1",
        tooltipFieldId: "",
        updatedBy: "",
        fileDirection: "",
        prodProfileType: ""
      }
    };
    component.isEdit = false;
    spyOn(tooltipService, "addToolTipData").and.returnValue(Observable.throw("No Data"));
    component.addToolTipData(validForm);
  });

  it("should be call updateTooltip valid for error", () => {
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        tooltipName: "CVT Profile Test1",
        tooltipFieldId: "",
        updatedBy: "",
        fileDirection: "",
        prodProfileType: ""
      }
    };
    spyOn(tooltipService, "updateTooltip").and.returnValue(Observable.throw("No Data"));
    component.addToolTipData(validForm);
  });
  it("should and displayToolTipText()", () => {
    component.toolTipPageFieldsData = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };

    component.dynamicPopover = {
      showPopOver: () => {
      },
      hidePopOver: () => {
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });

  it("displayToolTipText", () => {
    let e = {
      preventDefault: (event) => {
      }
    };
    component.exportAll();
    component.importAll(e);
    let formNew = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        firstName: ""
      }
    };
    component.saveFile(formNew);
    component.cancelFileUpload(formNew);

    let fileData = {
      "target": {
      },
      preventDefault: (event) => {
      }
    };
    fileData.target["files"] = [
      {
        "name": "tooltips.json",
        "tooltipFieldDesc": "TradingPartner_name",
        "tooltipDesc": "TradingPartner_name",
        "tooltipDisplay": false,
        "readMoreLink": "http://www.google.com",
        "tooltipFieldId": 1,
        "uniqueIdentifier": "1845c194-4bd5-46df-b382-7c214e40a1a0"
      },

    ];
    fileData.target["value"] = [{
      "tooltipFieldDesc": "DESC",
      "tooltipDesc": "DESC",
      "tooltipDisplay": true,
      "readMoreLink": null,
      "tooltipFieldId": 5,
      "uniqueIdentifier": "e3823375-c1f9-4607-925b-393815f3b4e8"
    }];
    component.uploadFile(fileData);

    component.getFile(fileData);
  });

});

class MockDataService {

  addToolTipData() {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  updateTooltip(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  getPageDetails(): Observable<any> {
    let response = require("../../../../assets/test-data/tooltip-get-Page-Details.json");
    return (Observable.of(response));
  }
  getWebPageFields(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  getTooltip(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  getTooltipById(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  exportAllTooltips(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/tooltip-get-Tooltip-Details.json");
    return (Observable.of(response));
  }
  error() {
    return false;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
