export class TooltipConfig {
    tooltipId: number;
    tooltipFeatureName: string;
    tooltipFieldId: number;
    tooltipFieldDesc: string;
    tooltipDesc: string;
    tooltipDisplay: boolean;
    readMoreLink: string;
    uniqueIdentifier: string;
    // pageName:String;
}

