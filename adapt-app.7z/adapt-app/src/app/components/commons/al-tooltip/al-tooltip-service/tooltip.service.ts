import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { NgForm } from "@angular/forms/src/directives/ng_form";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../env.service";
import { Observable } from "rxjs/Observable";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class TooltipService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/ToolTip";

  addToolTipData(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/create", data);
  }
  updateTooltip(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/update", data);
  }
  getPageDetails(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/getPageDetails");
  }

  getWebPageFields(adaptWebPageId): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/getByPageID?pageId=" + adaptWebPageId);
  }
  getTooltip(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/getTooltipDetails");
  }

  getTooltipById(tooltipFieldID): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/details/getTooltipByID?id=" + tooltipFieldID);
  }

  // Due to not possible to get Mock _Headers, ignoring this function in test case
  /*istanbul ignore next*/
  exportAllTooltips() {
    return this.http.get(this.serviceMappingURL + "/all/export", {observe: "response", responseType: "blob"}).toPromise()
      .then(res => {
        let _headers = res.headers;
        let contentDisposition = _headers.get("content-disposition");
        this.fileName = contentDisposition.split(";")[1].split("filename")[1].split("=")[1].trim();
        if (res && res["body"]) {
          this.downloadFile(res["body"]);
        }
      })
      .catch(this.handleError);
  }

  handleError(error) {
    console.log("error--  " + error);
  }

  fileName;
  downloadFile(data) {
    if (navigator.msSaveBlob) { // IE 10+
      let blob = new Blob([data], {
        "type": "application/json;charset=utf8;"
      });
      navigator.msSaveBlob(blob, this.fileName);
    }
    else {
      let blob = new Blob([data], { type: "application/json;charset=utf-8;" });
      let dwldLink = document.createElement("a");
      let url = URL.createObjectURL(blob);
      let isSafariBrowser = navigator.userAgent.indexOf("Safari") !== -1 && navigator.userAgent.indexOf("Chrome") === -1;
      if (isSafariBrowser) {  // if Safari open in new window to save file with random filename.
        dwldLink.setAttribute("target", "_blank");
      }
      dwldLink.setAttribute("href", url);
      dwldLink.setAttribute("download", this.fileName);
      dwldLink.style.visibility = "hidden";
      document.body.appendChild(dwldLink);
      dwldLink.click();
      document.body.removeChild(dwldLink);
    }
  }

  importAllTooltips(data): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders();
    return this.http.post(this.serviceMappingURL + "/all/import", data, { headers: headers });
  }
}
