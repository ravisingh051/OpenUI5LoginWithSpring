import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { TooltipService } from "./tooltip.service";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: TooltipService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                TooltipService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("addToolTipData", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Tooltip-Details.json");

        contactService.addToolTipData({}).subscribe((res) => {
            expect(res.data.length).toBe(101);
        });
    })));

    it("updateTooltip", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Tooltip-Details.json");

        contactService.updateTooltip().subscribe((res) => {
            expect(res.data.length).toBe(101);
        });
    })));

    it("getPageDetails", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Page-Details.json");

        contactService.getPageDetails().subscribe((res) => {
            expect(res.data.length).toBe(24);
        });
    })));

    it("getWebPageFields", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Tooltip-Details.json");

        contactService.getWebPageFields().subscribe((res) => {
            expect(res.data.length).toBe(101);
        });
    })));

    it("getTooltip", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Tooltip-Details.json");

        contactService.getTooltip({}, 10).subscribe((res) => {
            expect(res.data.length).toBe(101);
        });
    })));

    it("getTooltipById", async(inject([TooltipService], (contactService) => {
        let response = require("../../../../../assets/test-data/tooltip-get-Tooltip-Details.json");

        contactService.getTooltipById([]).subscribe((res) => {
            expect(res.data.length).toBe(101);
        });
    })));

    it("handleError", async(inject([TooltipService], (contactService) => {
        contactService.handleError();
    })));

    it("downloadFile", async(inject([TooltipService], (contactService) => {
        let data = {};
        contactService.downloadFile(data);
        contactService.importAllTooltips(data);
    })));


});