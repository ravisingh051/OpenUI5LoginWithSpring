import { Component, OnInit } from "@angular/core";

@Component({
  selector: "al-commons-sidebar",
  templateUrl: "./al-sidebar.component.html"
 })
export class AlCommonsModuleSidebar implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
