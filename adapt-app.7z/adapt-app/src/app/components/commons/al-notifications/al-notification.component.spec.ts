import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, DataTableModule, ConfirmationService } from "primeng/primeng";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { tick } from "@angular/core/testing";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { AlNotificationsService } from "./al-notifications-service/al-notifications-service";
import { LoginService } from "../../login/login.service";

import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlNotificationsComponent } from "./al-notifications.component";
import { TOKEN_NAME } from "../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button, element, by, promise } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { create } from "domain";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlNotificationsComponent", () => {
  let component: AlNotificationsComponent;
  let ngxPermission;
  let fixture: ComponentFixture<AlNotificationsComponent>;
  let overlaypanel: OverlayPanel;
  let toastService, alNotificationsService;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlNotificationsComponent, {
      set: {
        providers: [
          { provide: AlNotificationsService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes([
        ]),
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        ToastModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlNotificationsComponent, AlSidebarComponent, AlCommonsModuleSidebar, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        LoginService,
        ToastOptions,
        AppUtility,
        ApiEnvService,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        { provide: AlNotificationsService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: "MockDataService" },
        { provide: Observable, useClass: "MockDataService" },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToolTipUtilService, useClass: "MockDataService" },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    ngxPermission = TestBed.get(NgxPermissionsService);
    fixture = TestBed.createComponent(AlNotificationsComponent);
    component = fixture.componentInstance;
    ngxPermission.addPermission(" Notification-View All templates ");
    ngxPermission.addPermission("accessDenied");
    toastService = TestBed.get(ToastsManager);
    alNotificationsService = fixture.debugElement.injector.get(AlNotificationsService);
    fixture.detectChanges();
  });

  it("should create", () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it("should be logging user", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  }));

  it("should be populateSysEvents user", async(() => {
    spyOn(alNotificationsService, "getSystemEvents").and.returnValue(Observable.throw("No Data"));
    spyOn(alNotificationsService, "getfiletypeData").and.returnValue(Observable.throw("No Data"));
    spyOn(alNotificationsService, "getMetaInfoData").and.returnValue(Observable.throw("No Data"));
    spyOn(alNotificationsService, "getNotificationList").and.returnValue(Observable.throw("No Data"));
    fixture.detectChanges();
    component.ngOnInit();
  }));

  it("should click rowdata fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    // ellipseButton.nativeElement.click();
  });

  it("add notification value check", () => {
    component.isTimeboundModel = true;
    component.addNotification();
  });

  it("edit notification value check", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    component.isTimeboundModel = true;
    component.editNotification();
  });
  it("edit notification value check", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    component.isTimeboundModel = false;
    component.editNotification();
  });


  it("edit notification check", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
  });

  it("should close the edit popup fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    let formButton = fixture.debugElement.query(By.css("form")).queryAll(By.css("button"));
    formButton[0].nativeElement.click();
  });

  it("should close the edit popup fn else", () => {
    let formButton = fixture.debugElement.query(By.css("form")).queryAll(By.css("button"));
    formButton[0].nativeElement.click();
    component.isTimeboundModel = true;
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
  });

  it("save Notification updateNotification form", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        fileTypeAssocMappingData: [{
          fileTypeId: " addNotificationData"
        }, {
          fileTypeId: " addNotificationData"
        }],
        fileTypeAssocMapping: "Multiple",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    component.saveNotifications(validForm);
    spyOn(alNotificationsService, "updateNotification").and.returnValue(Observable.throw("No Data"));
    component.saveNotifications(validForm);
  });

  it("save Notification updateNotification form else error", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        fileTypeAssocMappingData: [{
          fileTypeId: " addNotificationData"
        }, {
          fileTypeId: " addNotificationData"
        }],
        fileTypeAssocMapping: "Multiple",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    spyOn(alNotificationsService, "updateNotification").and.returnValue(Promise.resolve({ error: true }));
    fixture.detectChanges();
    component.saveNotifications(validForm);
  });

  it("save Notification updateNotification form error", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        fileTypeAssocMappingData: [{
          fileTypeId: " addNotificationData"
        }, {
          fileTypeId: " addNotificationData"
        }],
        fileTypeAssocMapping: "Multiple",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    component.saveNotifications(validForm);
    component.isEditMode = true;
    component.isTimeboundModel = true;
    spyOn(alNotificationsService, "updateNotification").and.returnValue(Observable.throw("No Data"));
    component.saveNotifications(validForm);
  });

  it("save Notification addNotification form", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        fileTypeAssocMappingData: [{
          fileTypeId: " addNotificationData"
        }, {
          fileTypeId: " addNotificationData"
        }],
        fileTypeAssocMapping: "Multiple",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    component.saveNotifications(validForm);
    spyOn(alNotificationsService, "addNotification").and.returnValue(Observable.throw("No Data"));
    component.saveNotifications(validForm);
  });

  it("save Notification valid form with response error", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        fileTypeAssocMappingData: [{
          "fileTypeId": " addNotificationData"
        }],
        fileTypeAssocMapping: "Multiple",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    component.isEditMode = true;
    component.isTimeboundModel = true;
    spyOn(alNotificationsService, "addNotification").and.returnValue(Observable.throw("No Data"));
    component.saveNotifications(validForm);
  });

  it("test Mail valid form", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    component.selectedValues = [{
      value: "1",
      name: "test"
    }];
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        templateIds: "",
        timeToWait: "",
        templateId: "",
        active: false,
      }
    };
    expect(component.addEditNotificationForm.templateId).toBe(component.selectedRowId);
    // spyOn(alNotificationsService, 'sendTestMailNotification').and.returnValue(Observable.throw('No Data'));
    component.testMail(validForm);
    fixture.detectChanges();
  });

  it("test Mail Invalid form", () => {
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let InvalidForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        templateIds: "",
        timeToWait: "",
        templateId: "",
      }
    };
    spyOn(alNotificationsService, "sendTestMailNotification").and.returnValue(Observable.throw("No Data"));
    component.testMail(InvalidForm);
  });

  it("should create profile data get and set", () => {
    component.btnCancel();
  });

  it("select internal text", () => {
    component.internalDataElementModel = "1";
    component.internalNotificationTmplDescModel = "text";
    const linkElem = document.createElement("div");
    linkElem.classList.add("internalEditor");
    const linkElem2 = document.createElement("div");
    linkElem2.classList.add("ql-editor");
    linkElem.appendChild(linkElem2);
    document.body.appendChild(linkElem);
    component.addToInternalText();
    fixture.detectChanges();
  });
  it("select internal text else", () => {
    component.internalNotificationTmplDescModel = "text";
    const linkElem = document.createElement("div");
    linkElem.classList.add("internalEditor");
    const linkElem2 = document.createElement("div");
    linkElem2.classList.add("ql-editor");
    linkElem.appendChild(linkElem2);
    document.body.appendChild(linkElem);
    component.addToInternalText();
  });

  it("select external text", () => {
    component.internalNotificationTmplDescModel = "text";
    const linkElem = document.createElement("div");
    linkElem.classList.add("internalEditor");
    const linkElem2 = document.createElement("div");
    linkElem2.classList.add("ql-editor");
    linkElem.appendChild(linkElem2);
    document.body.appendChild(linkElem);
    component.addToExternalText();
  });

  it("select external text else", () => {
    component.externalDataElementModel = "1";
    component.internalNotificationTmplDescModel = "text";
    const linkElem = document.createElement("div");
    linkElem.classList.add("externalEditor");
    const linkElem2 = document.createElement("div");
    linkElem2.classList.add("ql-editor");
    linkElem.appendChild(linkElem2);
    document.body.appendChild(linkElem);
    component.addToExternalText();
    fixture.detectChanges();
  });

  let Test = function () { };

  Test.prototype.test = function () {
    if (window.getSelection) {
      let sel = window.getSelection();
      let range = sel.getRangeAt(0);
      // then some code;
    } else if (document.onselect) {
      // range = document.selection.createRange();
      // then some code;
      return "haha";
    }
  };

  it("should create range object", function () {
    let html = "<p>test</p>";
    component.getCursorPosition(html);
  });

  it("should create range object if", function () {
    let myTest, result;
    myTest = new Test();
    // mock the select function so that it will return "haha" when getRangeAt is called
    let range = 123;
    let rangeObject = {
      getRangeAt: function () { return range; },
      rangeCount: ""
    };
    spyOn(window, "getSelection").and.returnValue(rangeObject);
    spyOn(myTest, "test").and.returnValue("haha");
    let html = "<p>test</p>";
    component.getCursorPosition(html);
    result = myTest.test();
    expect(result).toEqual("haha");
  });

  it("select time value", () => {
    component.isTimeboundModel = true;
    component.setCurretTime();
  });

  it("select time value else", () => {
    component.setCurretTime();
  });
  it("select onChangeSystemEvents", () => {
    let id = 6;
    component.onChangeSystemEvents(id);
  });
  it("select onChangeSystemEvents else part", () => {
    let id = 6;
    spyOn(alNotificationsService, "getInboundFiletypeData").and.returnValue(Observable.throw("No Data"));
    component.onChangeSystemEvents(id);
  });

  it("on select", () => {
    const event = {};
    fixture.detectChanges();
    component.onSelect(event);
  });

  it("check editer to value", () => {
    const event = {
      textValue: "tewst value"
    };
    event.textValue.replace(/(?:\r\n|\r|\n)/g, "").trim().replace(" ", "");
    component.checkEditorValue(event);
  });

  it("check editer to value else", () => {
    const event = {
      textValue: ""
    };
    event.textValue.replace(/(?:\r\n|\r|\n)/g, "").trim().replace(" ", "");
    component.checkEditorValue(event);
  });

  it("should and displayToolTipText()", () => {
    component.isToolTipText = true;
    component.toolTipTextAddEdit = {
      "Test Email Address": {
        "tooltipDesc": "Test Email Address description",
        "readMoreLink": "http://www.google.com"
      }
    };
    fixture.detectChanges();
    let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));


    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Test Email Address", "bottom");
      fixture.detectChanges();
      component.hideToolTipText(event);
      fixture.detectChanges();
      component.hideToolTipText(event);
    });
    btnNextStep.click();
    fixture.detectChanges();
  });

  it("search fn", () => {
    let event = {
      query: "jay.avatani@alight.com"
    };
    component.search(event);
  });

});

class MockDataService {
  getSystemEvents() {
    let response;
    response = require("../../../../assets/test-data/notification-get-all-templete.json");
    return (Observable.of(response));
  }
  getfiletypeData(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-fileType-detail.json");
    return (Observable.of(response));
  }
  getMetaInfoData(): Observable<any> {
    let response = require("../../../../assets/test-data/notification-get-all-element.json");
    return (Observable.of(response));
  }
  getNotificationList(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }
  addNotification(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }
  updateNotification(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }
  getFiletypeDataById(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }
  editFileType(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }

  sendTestMailNotification(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }
  getInboundFiletypeData(): Observable<any> {
    let response;
    response = require("../../../../assets/test-data/notification-detail.json");
    return (Observable.of(response));
  }

  error() {
    return true;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
