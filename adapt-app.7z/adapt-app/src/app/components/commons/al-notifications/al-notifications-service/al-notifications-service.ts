import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../env.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlNotificationsService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/notification/";

  getSystemEvents(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/systemEvents/getAllTemplates");
  }

  getfiletypeData(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/FileType/details/");
  }

  getFiletypeDataById(id): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/FileType/" + id + "/details");
  }

  getMetaInfoData(): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/notificationTemplateMetainfo/getAllElements");
  }

  getNotificationList(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "details");
  }

  addNotification(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "create", data);
  }
  updateNotification(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "update", data);
  }

  editFileType(templateId): Observable<any> {
    return this.http.get(this.apiEnvEndpoint + "/notificationFileTypeAssoc/getByTemplateId?templateId=" + templateId);
  }

  sendTestMailNotification(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "sendTestNotification", data);
  }
}
