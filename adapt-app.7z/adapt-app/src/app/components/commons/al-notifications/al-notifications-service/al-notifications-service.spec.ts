import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { AlNotificationsService } from "./al-notifications-service";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlNotificationsService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                AlNotificationsService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getSystemEvents", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

        contactService.getSystemEvents({}).subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("getfiletypeData", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

        contactService.getfiletypeData().subscribe((res) => {
            expect(res.data.length).toBe(16);
        });
    })));
    // it("getInboundFiletypeData", async(inject([AlNotificationsService], (contactService) => {
    //     let response = require("../../../../../assets/test-data/notification-fileType-detail.json");
    //     getServiceData(response);

    //     contactService.getInboundFiletypeData().subscribe((res) => {
    //         expect(res.data.length).toBe(16);
    //     });
    // })));

    it("getMetaInfoData", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-element.json");

        contactService.getMetaInfoData().subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("getNotificationList", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getNotificationList().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("addNotification", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.addNotification({}, 10).subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("updateNotification", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.updateNotification([]).subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("editFileType", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.editFileType().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("sendTestMailNotification", async(inject([AlNotificationsService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.sendTestMailNotification().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
});