import { Component, OnInit, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { NgForm } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { CalendarModule, OverlayPanel, SelectItem } from "primeng/primeng";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { Form } from "@angular/forms/src/directives/form_interface";
import { InputSwitchModule } from "primeng/primeng";
import { AlNotificationsService } from "./al-notifications-service/al-notifications-service";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { isUndefined } from "util";
import { LoginService } from "../../login/login.service";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { TOAST_SETTING } from "../../../global";

@Component({
  selector: "app-al-notifications",
  templateUrl: "./al-notifications.component.html",
  styleUrls: ["./al-notifications.component.scss"],
  providers: [AlNotificationsService, ToolTipUtilService]
})
export class AlNotificationsComponent implements OnInit {
  selectedRowId: any;
  selectedPanel: any;
  notifList: any = {};
  showHide: boolean = false;
  isEditMode: boolean = false;
  notificationData: any;
  selectedsystemEvents: any;
  systemEventsData: any;
  templateNameData: any;
  date8: Date;
  isTimeboundModel: boolean = false;
  isActiveNotification: boolean = true;
  addEditNotification: any = {};
  systemEventsModel;
  templateNameModel;
  fileTypeSelected;
  addEditNotificationForm: any = {};
  timeModel: any;
  isAlwaysSendInternal: boolean = false;
  isAlwaysSendExternal: boolean = false;
  internalDataElementModel: any;
  externalDataElementModel: any;
  internalNotificationTmplDescModel: any;
  externalNotificationTmplDescModel: any;
  fileTypeData: any;
  metaInfoData: any = [];
  timeValue: string;
  chkBoxNotficationModel: boolean = false;
  currentEditor;
  editData: any;
  fromAddressModel;
  uniqueIdentifier;
  editFileTypeData: any = [];
  selectedValues;
  internalEditorRequired: boolean = false;
  fromEmailAddress: string;
  /* ToolTip display OnMouse Click */
  toolTipNotification: any = [];
  toolTipTextAddEdit: any = [];
  tooltipResult: any;
  pageID: number = 7;
  isToolTipText: boolean = false;
  validationMsg: string;
  sysEventDropDownList: any = [];
  processingSystemEvents: any;
  @ViewChildren("dropdown") dropDown: QueryList<Dropdown>;
  constructor(
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private ntfcService: AlNotificationsService,
    private permissionsService: NgxPermissionsService,
    private loginService: LoginService,
    private toolTipUtils: ToolTipUtilService
  ) { }

  ngOnInit() {
    this.loginService.getMail.subscribe((value) => {
      this.fromEmailAddress = value;
    });
    this.fromAddressModel = this.fromEmailAddress;
    this.populateSysEvents();
    this.populateFileType();
    this.populateMetaInfo();
    this.populateNotificationList();
    this.getToolTipTextDetails();
    this.validationMsg = window["validationMsg"];
  }

  rowNotificationActions(event, rowData, index, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.selectedPanel = overlaypanel;
    this.selectedRowId = rowData.templateId;
    this.editData = rowData;
    /*this.ftpList.SelectedRowData = rowData; */
  }

  populateSysEvents() {
    this.ntfcService.getSystemEvents().subscribe(res => {
      if (!res.error) {
        this.systemEventsData = res.data;
        this.populateSystemEventDropDown();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Getting System Events List.", "Oops!", TOAST_SETTING);
    });
  }

  populateSystemEventDropDown() {
    let _sysEventDropDownList = [];
    if (this.systemEventsData.length !== 0) {
      for (let obj of this.systemEventsData) {
        _sysEventDropDownList.push({
          "label": obj.eventDescription,
          "value": obj.eventId
        });
      }
      this.sysEventDropDownList = _sysEventDropDownList;
      this.sysEventDropDownList.unshift({ label: "Select a System Event", valule: null });
    }
  }

  populateFileType() {
    this.ntfcService.getfiletypeData().subscribe(res => {
      if (!res.error) {
        this.fileTypeData = res.data;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Getting File Type List.", "Oops!", TOAST_SETTING);
    });
  }
  populateMetaInfo() {
    this.ntfcService.getMetaInfoData().subscribe(res => {
      if (!res.error) {
        let optList = [];
        optList.push(new Object({ label: "Please Select Meta info", value: "" }));
        res.data.forEach(function (obj) {
          optList.push(new Object({ label: obj.elementName, value: obj.templatizedName }));
        });
        this.metaInfoData = optList;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Meta Info List.", "Oops!", TOAST_SETTING);
    });
  }

  populateNotificationList() {
    this.ntfcService.getNotificationList().subscribe(res => {
      if (!res.error) {
        this.notificationData = res.data;
        this.setTableFilter();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Notification List.", "Oops!", TOAST_SETTING);
    });
  }

  getEditFileType() {
    this.ntfcService.editFileType(this.selectedRowId).subscribe(res => {
      if (!res.error) {
        let editFileType = res.data;
        this.editFileTypeData = [];
        for (let _obj of editFileType) {
          this.editFileTypeData.push(_obj.fileTypeId);
        }
        this.fileTypeSelected = this.editFileTypeData;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in Notification List.", "Oops!", TOAST_SETTING);
    });
  }

  addNotification() {
    this.showHide = true;
    this.isEditMode = false;
    this.processingSystemEvents = null;
    this.templateNameModel = null;
    this.isTimeboundModel = false;
    this.isActiveNotification = true;
    this.isAlwaysSendExternal = false;
    this.isAlwaysSendInternal = false;
    this.internalNotificationTmplDescModel = null;
    this.externalNotificationTmplDescModel = null;
    this.isToolTipText = true;
    this.getToolTipTextDetails();
  }

  editNotification() {
    this.selectedPanel.hide();
    this.getEditFileType();
    this.showHide = true;
    this.isEditMode = true;
    this.isToolTipText = true;
    this.processingSystemEvents = this.editData.eventId;
    this.templateNameModel = this.editData.templateName;
    this.fromAddressModel = this.editData.fromAddress;
    this.isTimeboundModel = this.editData.timeBound;
    this.uniqueIdentifier = this.editData.uniqueIdentifier;
    if (this.isTimeboundModel) {
      this.timeModel = null;
      if (this.editData.timeToWait !== null) {
        this.timeModel = new Date();
        let hrs = this.editData.timeToWait.split(":");
        this.timeModel.setHours(hrs[0]);
        this.timeModel.setMinutes(hrs[1]);
        this.timeValue = hrs[0] + ":" + hrs[1];
      }
    } else {
      this.timeModel = null;
    }

    this.isTimeboundModel = this.editData.timeBound;
    this.isActiveNotification = this.editData.active;
    this.isAlwaysSendExternal = this.editData.alwaysSendExternal;
    this.isAlwaysSendInternal = this.editData.alwaysSendInternal;
    this.internalNotificationTmplDescModel = this.editData.internalNotificationText;
    this.externalNotificationTmplDescModel = this.editData.externalNotificationText;
    this.getToolTipTextDetails();
  }


  btnClicked: boolean = false;
  saveNotifications(addEditNotificationForm: NgForm) {
    let dropArr = this.dropDown.toArray();
    dropArr.forEach((ele) => {
      ele.filterValue = null;
    });

    this.btnClicked = true;
    let addNotificationData = addEditNotificationForm.value;

    addNotificationData.notificationTemplateFileTypeAssoc = [];

    addNotificationData.processingSystemEvents = {
      "eventId": parseInt(addNotificationData.processingSystemEvents)
    };
    if (addNotificationData.fileTypeAssocMappingData !== null && addNotificationData.fileTypeAssocMappingData !== undefined) {
      for (let i = 0; i < addNotificationData.fileTypeAssocMappingData.length; i++) {
        addNotificationData["notificationTemplateFileTypeAssoc"].push({
          "fileTypeMetaInfo": {
            "fileTypeId": addNotificationData.fileTypeAssocMappingData[i]
          }
        });
      }
      // delete addNotificationData.fileTypeAssocMappingData;
      if (addNotificationData.fileTypeAssocMappingData.length > 1)
        addNotificationData.fileTypeAssocMapping = "Multiple";
      else
        addNotificationData.fileTypeAssocMapping = "Single";
    }
    addNotificationData.fileTypeAssocMapping = "Email";
    if (this.isTimeboundModel) {
      addNotificationData.timeToWait = this.timeValue;
    }
    else {
      addNotificationData.timeToWait = null;
    }
    if (this.isEditMode) {
      addNotificationData.uniqueIdentifier = this.uniqueIdentifier;
      addNotificationData.templateId = this.selectedRowId;

      this.ntfcService.updateNotification(addNotificationData).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Notification Updated Successfully", "Success!");
          addEditNotificationForm.resetForm();
          this.fromAddressModel = this.fromEmailAddress;
          this.showHide = false;
          this.btnClicked = false;
          this.populateNotificationList();
          this.isToolTipText = false;
          this.router.navigate(["/notifications"]);
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          this.btnClicked = false;
        }
      }, error => {
        this.toastr.error(error.message, "Oops!", TOAST_SETTING);
        this.btnClicked = false;
      });
    }
    else {
      this.ntfcService.addNotification(addNotificationData).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Notification Added Successfully", "Success!");
          addEditNotificationForm.resetForm();
          this.fromAddressModel = this.fromEmailAddress;
          this.showHide = false;
          this.btnClicked = false;
          this.populateNotificationList();
          this.isToolTipText = false;
          this.router.navigate(["/notifications"]);
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          this.btnClicked = false;
        }
      }, error => {
        this.toastr.error(error.message, "Oops!", TOAST_SETTING);
        this.btnClicked = false;
      });
    }
  }

  testMail(sendTestMailForm: NgForm) {
    if (this.selectedValues !== undefined && this.selectedValues.length !== 0) {
      let testMailRequest = sendTestMailForm.value;
      let tmpId = [];
      for (let _obj of this.selectedValues) {
        tmpId.push(_obj.templateId);
      }
      testMailRequest.templateIds = tmpId;
      this.ntfcService.sendTestMailNotification(testMailRequest).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Test Mail Notification Sent Successfully", "Success!");
          sendTestMailForm.resetForm();
          this.selectedValues = [];
          this.router.navigate(["/notifications"]);
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error(error.message, "Oops!", TOAST_SETTING);
      });
    } else {
      this.toastr.error("Please select at least one template.", "Oops!", TOAST_SETTING);
    }

  }

  btnCancel() {
    this.showHide = false;
    this.isToolTipText = false;
    // this.router.navigate(['/commons']);
  }

  addToInternalText() {
    if (this.internalDataElementModel === undefined || this.internalDataElementModel === "") {
      this.toastr.error("Please select the Meta Info to add in the description !", "Oops!", TOAST_SETTING);
      return false;
    }
    let oldValue = this.internalNotificationTmplDescModel;
    /* if (oldValue.con) */
    /* let newValue = this.internalNotificationTmplDescModel + "{"+this.internalDataElementModel+"}";
    this.internalNotificationTmplDescModel = newValue; */
    this.insertTextAtPositionInternal();
  }

  addToExternalText() {
    if (this.externalDataElementModel === undefined || this.externalDataElementModel === "") {
      this.toastr.error("Please select the Meta Info to add in the description !", "Oops!", TOAST_SETTING);
      return false;
    }
    let oldValue = this.internalNotificationTmplDescModel;
    this.insertTextAtPositionExternal();
  }

  onSelect($event) {
    let hour = new Date($event).getHours();
    let min = new Date($event).getMinutes();
    this.timeValue = `${hour}:${min}`;
  }
  /*istanbul ignore next*/
  getCursorPosition(html) {
    let sel, range;
    if (window.getSelection) {
      // IE9 and non-IE
      sel = window.getSelection();
      if (sel.getRangeAt && sel.rangeCount) {
        range = sel.getRangeAt(0);
        range.deleteContents();

        // Range.createContextualFragment() would be useful here but is
        // non-standard and not supported in all browsers (IE9, for one)
        let el = document.createElement("div");
        el.innerHTML = html;
        let frag = document.createDocumentFragment(), node, lastNode;
        while ((node = el.firstChild)) {
          lastNode = frag.appendChild(node);
        }
        range.insertNode(frag);

        // Preserve the selection
        if (lastNode) {
          range = range.cloneRange();
          range.setStartAfter(lastNode);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
        }
      }
    }
  }

  insertTextAtPositionInternal() {
    /*range.insertNode(document.createTextNode(text));
       this.currentEditor = range.endContainer.parentNode.offsetParent.offsetParent.className
      console.log('current Editor',this.currentEditor); */
    let internalEditor = (document.querySelector(".internalEditor .ql-editor") as HTMLElement).focus();
    this.getCursorPosition(this.internalDataElementModel);
    // return false;
  }

  insertTextAtPositionExternal() {
    /*  let sel, range;
     sel = window.getSelection();
     if (sel.getRangeAt && sel.rangeCount) {
       // this.insertTextAtPosition("{" + this.externalDataElementModel + "}", sel.getRangeAt(0));
       return sel.getRangeAt(0);
     } */
    let externalEditor = (document.querySelector(".externalEditor .ql-editor") as HTMLElement).focus();
    this.getCursorPosition(this.externalDataElementModel);

    // return false;
  }

  setCurretTime() {
    if (this.isTimeboundModel) {
      this.timeModel = new Date();
      let hour = new Date(this.timeModel).getHours();
      let min = new Date(this.timeModel).getMinutes();
      this.timeModel.setHours(hour);
      this.timeModel.setMinutes(min);
      this.timeValue = hour + ":" + min;
    } else {
      this.timeModel = null;
    }
  }

  intNtfcDesModel: string;
  checkEditorValue(event) {
    let checkVal = event.textValue.replace(/(?:\r\n|\r|\n)/g, "").trim().replace(" ", "");
    if (checkVal !== "") {
      this.intNtfcDesModel = event.textValue;
    }
    else {
      this.intNtfcDesModel = "";
    }
  }


  // Filter Function : START
  ntfcFilter: any = {};
  setTableFilter() {
    this.tpNames = [];
    let _fileFilter = {};
    if (this.notificationData !== null) {
      _fileFilter["name"] = [];
      _fileFilter["systemEvents"] = [];
      _fileFilter["fileType"] = [];
      _fileFilter["fromAddress"] = [];
      _fileFilter["lastUpdate"] = [];
      _fileFilter["lastUpdatedBy"] = [];
      this.ntfcFilter.status = [
        { label: "All", value: null },
        { label: "Active", value: true },
        { label: "Inactive", value: false }
      ];

      for (let i = 0; i < this.notificationData.length; i++) {
        if (_fileFilter["name"].indexOf(this.notificationData[i].templateName) === -1) {
          _fileFilter["name"].push(this.notificationData[i].templateName);
        }
        if (_fileFilter["systemEvents"].indexOf(this.notificationData[i].eventName) === -1) {
          _fileFilter["systemEvents"].push(this.notificationData[i].eventName);
        }

        if (this.notificationData[i].fileTypeAssocNames === null) {
          this.notificationData[i].fileTypeAssocNames = [];
        }
        // if (files !== null) {
        for (let value of this.notificationData[i].fileTypeAssocNames) {
          if (_fileFilter["fileType"].indexOf(value) === -1) {
            _fileFilter["fileType"].push(value);
          }
        }
        // }
        if (_fileFilter["fromAddress"].indexOf(this.notificationData[i].fromAddress) === -1) {
          _fileFilter["fromAddress"].push(this.notificationData[i].fromAddress);
        }
        if (_fileFilter["lastUpdate"].indexOf(this.notificationData[i].updatedDateTime) === -1) {
          let temp: any;
          if (this.notificationData[i].updatedDateTime != null) {
            temp = this.notificationData[i].updatedDateTime.replace(/\s*[a-z]+/ig, "");
            this.notificationData[i].lastUpdatedDateTime = new Date(temp).getTime();
            _fileFilter["lastUpdate"].push({ "date": this.notificationData[i].updatedDateTime, "time": this.notificationData[i].lastUpdatedDateTime });
          } else if (this.notificationData[i].createdDateTime != null) {
            temp = this.notificationData[i].createdDateTime.replace(/\s*[a-z]+/ig, "");
            this.notificationData[i].lastUpdatedDateTime = new Date(temp).getTime();
            _fileFilter["lastUpdate"].push({ "date": this.notificationData[i].createdDateTime, "time": this.notificationData[i].lastUpdatedDateTime });
          }
        }
        if (_fileFilter["lastUpdatedBy"].indexOf(this.notificationData[i].updatedBy) === -1) {
          _fileFilter["lastUpdatedBy"].push(this.notificationData[i].updatedBy);
        }
      }
    }
    this.ntfcFilter.name = [{ label: "All", value: null }];
    for (let value of _fileFilter["name"].sort((a, b) => a - b)) {
      this.ntfcFilter.name.push({ label: value, value: value });
      this.tpNames.push(value);
    }

    this.ntfcFilter.systemEvents = [{ label: "All", value: null }];
    for (let value of _fileFilter["systemEvents"].sort((a, b) => a - b)) {
      this.ntfcFilter.systemEvents.push({ label: value, value: value });
    }

    this.ntfcFilter.fileType = [{ label: "All", value: null }];
    for (let value of _fileFilter["fileType"].sort((a, b) => a - b)) {
      this.ntfcFilter.fileType.push({ label: value, value: value });
    }

    this.ntfcFilter.fromAddress = [{ label: "All", value: null }];
    for (let value of _fileFilter["fromAddress"].sort((a, b) => a - b)) {
      this.ntfcFilter.fromAddress.push({ label: value, value: value });
    }

    this.ntfcFilter.lastUpdate = [{ label: "All", value: null }];
    for (let value of _fileFilter["lastUpdate"].sort((a, b) => a - b)) {
      this.ntfcFilter.lastUpdate.push({ label: value.date, value: value.time });
    }

    this.ntfcFilter.lastUpdatedBy = [{ label: "All", value: null }];
    for (let value of _fileFilter["lastUpdatedBy"].sort((a, b) => a - b)) {
      this.ntfcFilter.lastUpdatedBy.push({ label: value, value: value });
    }
  }
  // Filter Function : END

  getToolTipTextDetails() {
    if (this.isToolTipText) {
      this.pageID = 8;
      this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
        this.toolTipTextAddEdit = res.data;
      });
    } else {
      this.pageID = 7;
      this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
        this.toolTipNotification = res.data;
      });
    }

  }


  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    if (this.isToolTipText) {
      this.tooltipResult = this.toolTipTextAddEdit[value];
    } else {
      this.tooltipResult = this.toolTipNotification[value];
    }
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // CC-38451
  results: any = [];
  tpNames: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.tpNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

  onChangeSystemEvents(id) {
    if (id) {
      this.ntfcService.getFiletypeDataById(id).subscribe(res => {
        if (!res.error) {
          this.fileTypeData = res.data;
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in Getting inbound File Type List.", "Oops!", TOAST_SETTING);
      });
    }
  }
}