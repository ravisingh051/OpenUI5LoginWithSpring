import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlApprovePromotionsComponent } from "./al-approve-promotions.component";

import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel, AutoCompleteModule, AutoComplete } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { TOKEN_NAME } from "../../login/login.constant";
import { LoginService } from "../../login/login.service";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { DatePipe } from "@angular/common";
import { By } from "@angular/platform-browser";
import { TemplateRef, DebugElement } from "@angular/core";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { AlApprovePromotionService } from "./al-approve-promotion/al-approve-promotion.service";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlApprovePromotionsComponent", () => {
  let component: AlApprovePromotionsComponent;
  let fixture: ComponentFixture<AlApprovePromotionsComponent>;
  let toastService, alApprovePromotionService;

  beforeEach(async(() => {

    TestBed.overrideComponent(AlApprovePromotionsComponent, {
      set: {
        providers: [
          { provide: AlApprovePromotionService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlApprovePromotionsComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        AutoComplete,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        { provide: AlApprovePromotionService, useClass: MockDataService },
        { provide: ToastsManager, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: LoginService, useClass: FakeLoginService },
        { provide: Observable, useClass: "MockDataService" },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlApprovePromotionsComponent);
    component = fixture.componentInstance;
    toastService = TestBed.get(ToastsManager);
    alApprovePromotionService = fixture.debugElement.injector.get(AlApprovePromotionService);
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should oninit", () => {
    fixture.detectChanges();
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    component.ngOnInit();
  });
  it("should be populateSysEvents user", async(() => {
    spyOn(alApprovePromotionService, "getAllApprovePromotions").and.returnValue(Observable.throw("No Data"));
    fixture.detectChanges();
    component.ngOnInit();
  }));
  it("should changeStatus fn", () => {
    // let ellipseButton = fixture.debugElement.query(By.css('[icon="fa-ellipsis-v"]'));
    // ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).queryAll(By.css("a"));
    editContactButton[0].nativeElement.click();
  });

  it("should changeStatus fn", () => {
    // let ellipseButton = fixture.debugElement.query(By.css('[icon="fa-ellipsis-v"]'));
    // ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).queryAll(By.css("a"));
    editContactButton[1].nativeElement.click();
  });


  it("should rowAction()", () => {

    const event = {
      stopPropagation: (e) => {
      },
    };
    let overlaypanel = <OverlayPanel>{
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    let rowData = {
      approvedBy: null,
      approvedDateTime: null,
      clientIds: "16560",
      configPromotionAuditId: 20,
      configPromotionStatusId: 1,
      configPromotionStatusName: "Pending Approval",
      createdBy: "idisUserQALevel3",
      createdDateTime: "01/22/2019",
      fileId: 62,
      fileIdentifier: 141,
      fileVersion: 1,
      hasApproveRejectPermissions: true,
      isEmpHaveAccess: true,
      lobName: "Test LOB July19",
      promotionNotes: "aaa",
      sourceEnvName: "0",
      targetEnvId: 2,
      targetEnvName: "0",
      tradingPartnerName: "Test TP July19"
    };
    component.rowAction(event, overlaypanel, rowData);
  });
  it("should and displayToolTipText()", () => {
    component.toolTipPageFieldsData = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });
});

export class FakeNgxPermission extends NgxPermissionsService {
}

class MockDataService {
  getAllApprovePromotions() {
    let response;
    response = require("../../../../assets/test-data/approve_promotion.json");
    return (Observable.of(response));
  }
  changePromotionStatus(Data) {
    let response;
    response = require("../../../../assets/test-data/approve_promotion.json");
    return (Observable.of(response));
  }
  error() {
    return true;
  }
  success() {
    return true;
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
export class FakeLoginService {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>("User");
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>("User");

  isMigrationAccess(empId: any): Observable<any> {
    let response = require("../../../../assets/test-data/commons/HeldFiles/get.json");
    return Observable.of(response);
  }

  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }

  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }

}