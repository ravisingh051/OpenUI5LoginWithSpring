import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { AlApprovePromotionService } from "./al-approve-promotion/al-approve-promotion.service";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DatePipe } from "@angular/common";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { LoginService } from "../../login/login.service";
import { Subscription } from "rxjs";
import { NgxPermissionsService } from "ngx-permissions";
import { TOAST_SETTING } from "../../../global";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";

@Component({
  selector: "app-al-approve-promotions",
  templateUrl: "./al-approve-promotions.component.html",
  styleUrls: ["./al-approve-promotions.component.scss"],
  providers: [AlApprovePromotionService, DatePipe]
})
export class AlApprovePromotionsComponent implements OnInit, OnDestroy {

  approvePromotionList = [];
  approvePromotionFilterList1 = [];
  approvePromotionFilterList2 = [];
  filterFileIds = [];
  filterFileVersion = [];
  filterTargetEnv = [];
  filterRequestBy = [];
  filterRequestedOn = [];
  filterApprovedBy = [];
  filterStatus = [];
  filterComments = [];
  filterTradingPartner = [];
  filterLob = [];
  filterFileIdsModel;
  filterFileVersionModel;
  filterTargetEnvModel;
  filterRequestByModel;
  filterRequestedOnModel;
  filterfilterApprovedBy;
  filterStatusModel;
  filterCommentsModel;
  filterTradingPartnerModel;
  filterLobModel = [];
  tableDataLoading: boolean;
  profileName: string;
  profileNameSubscriber: Subscription;
  filterfilterApprovedOn;
  filterApprovedOn = [];
  isEmpHaveAccess: boolean = false;
  isUserHavePermission: boolean = false;
  validationMsg: string;
  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  tooltipResult: any;
  pageID: number = 38;

  /* loader for file promotion flow */
  waitingLoader: boolean = false;
  fileDescriptionModel;
  filterFileDescription = [];
  clientIdsModel;
  filterclientIds = [];
  migrationDetailsModel: boolean = false;

  constructor(private approvePromotionService: AlApprovePromotionService,
    private toastr: ToastsManager,
    private datePipe: DatePipe,
    private loginService: LoginService,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService) { }

  ngOnInit() {
    this.tableDataLoading = true;
    this.getAllApprovePromotions();

    this.profileNameSubscriber = this.loginService.getProfileName.subscribe((value) => {
      this.profileName = value;
    });
    this.validationMsg = window["validationMsg"];
    this.getToolTipTextDetails();
  }

  ngOnDestroy() {
    if (this.profileNameSubscriber) {
      this.profileNameSubscriber.unsubscribe();
    }
  }

  getAllApprovePromotions() {
    this.approvePromotionService.getAllApprovePromotions().subscribe(res => {
      if (!res.error) {
        this.approvePromotionList = res.data;
        this.tableDataLoading = false;
        this.populateFilters(this.approvePromotionList);
        this.approvePromotionFilterList1 = this.approvePromotionList.filter(approvePromotion => approvePromotion.configPromotionStatusName === "Pending Approval");
        this.approvePromotionFilterList1.sort((a, b) => { return a.fileId - b.fileId; });
        this.approvePromotionFilterList2 = this.approvePromotionList.filter(approvePromotion => approvePromotion.configPromotionStatusName !== "Pending Approval");
        this.approvePromotionList = this.approvePromotionFilterList1.concat(this.approvePromotionFilterList2);
        this.approvePromotionList.forEach((approvePromotion) => {
          let isEmpHaveAccess = this.loginService.isMigrationAccess([approvePromotion.clientIds]);
          let obj = { isEmpHaveAccess: isEmpHaveAccess };
          Object.assign(approvePromotion, obj);
        });
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server error getting approve promotions.", "Oops!", TOAST_SETTING);
    });
  }

  populateFilters(list) {
    this.filterFileIds = [];
    this.filterFileVersion = [];
    this.filterTargetEnv = [];
    this.filterRequestBy = [];
    this.filterRequestedOn = [];
    this.filterApprovedBy = [];
    this.filterStatus = [];
    this.filterComments = [];
    this.filterLob = [];
    this.filterTradingPartner = [];
    this.filterApprovedOn = [];
    this.filterFileDescription = [];
    this.filterclientIds = [];

    this.filterFileIds.unshift({ label: "All", value: null });
    this.filterFileVersion.unshift({ label: "All", value: null });
    this.filterTargetEnv.unshift({ label: "All", value: null });
    this.filterRequestBy.unshift({ label: "All", value: null });
    this.filterRequestedOn.unshift({ label: "All", value: null });
    this.filterApprovedBy.unshift({ label: "All", value: null });
    this.filterStatus.unshift({ label: "All", value: null });
    this.filterComments.unshift({ label: "All", value: null });
    this.filterLob.unshift({ label: "All", value: null });
    this.filterTradingPartner.unshift({ label: "All", value: null });
    this.filterApprovedOn.unshift({ label: "All", value: null });
    this.filterFileDescription.unshift({ label: "All", value: null });
    this.filterclientIds.unshift({ label: "All", value: null });
    this.setDateInFilter(list);
  }

  setDateInFilter(list) {
    const _filterFileIds = [];
    const _filterFileVersion = [];
    const _filterTargetEnv = [];
    const _filterRequestBy = [];
    const _filterRequestedOn = [];
    const _filterApprovedBy = [];
    const _filterStatus = [];
    const _filterComments = [];
    const _filterLob = [];
    const _filterTradingPartner = [];
    const _filterApprovedOn = [];
    const _filterFileDescription = [];
    const _filterClientIds = [];

    for (const l of list) {
      if (l["fileId"] && _filterFileIds.indexOf(l["fileId"]) === -1) {
        _filterFileIds.push(l["fileId"]);
        this.filterFileIds.push({ label: l["fileId"], value: l["fileId"] });
      }

      if (l["fileVersion"] && _filterFileVersion.indexOf(l["fileVersion"]) === -1) {
        _filterFileVersion.push(l["fileVersion"]);
        this.filterFileVersion.push({ label: l["fileVersion"], value: l["fileVersion"] });
      }

      if (l["targetEnvName"] && _filterTargetEnv.indexOf(l["targetEnvName"]) === -1) {
        _filterTargetEnv.push(l["targetEnvName"]);
        this.filterTargetEnv.push({ label: l["targetEnvName"], value: l["targetEnvName"] });
      }

      if (l["createdBy"] && _filterRequestBy.indexOf(l["createdBy"]) === -1) {
        _filterRequestBy.push(l["createdBy"]);
        this.filterRequestBy.push({ label: l["createdBy"], value: l["createdBy"] });
      }

      l["createdDateTime"] = this.datePipe.transform(l["createdDateTime"], "MM/dd/yyyy");
      if (l["createdDateTime"] && _filterRequestedOn.indexOf(l["createdDateTime"]) === -1) {
        _filterRequestedOn.push(l["createdDateTime"]);
        this.filterRequestedOn.push({ label: l["createdDateTime"], value: l["createdDateTime"] });
      }

      if (l["approvedBy"] && _filterApprovedBy.indexOf(l["approvedBy"]) === -1) {
        _filterApprovedBy.push(l["approvedBy"]);
        this.filterApprovedBy.push({ label: l["approvedBy"], value: l["approvedBy"] });
      }

      if (l["configPromotionStatusName"] && _filterStatus.indexOf(l["configPromotionStatusName"]) === -1) {
        _filterStatus.push(l["configPromotionStatusName"]);
        this.filterStatus.push({ label: l["configPromotionStatusName"], value: l["configPromotionStatusName"] });
      }

      if (l["promotionNotes"] && _filterComments.indexOf(l["promotionNotes"]) === -1) {
        _filterComments.push(l["promotionNotes"]);
        this.filterComments.push({ label: l["promotionNotes"], value: l["promotionNotes"] });
      }

      if (l["lobName"] && _filterLob.indexOf(l["lobName"]) === -1) {
        _filterLob.push(l["lobName"]);
        this.filterLob.push({ label: l["lobName"], value: l["lobName"] });
      }

      if (l["tradingPartnerName"] && _filterTradingPartner.indexOf(l["tradingPartnerName"]) === -1) {
        _filterTradingPartner.push(l["tradingPartnerName"]);
        this.filterTradingPartner.push({ label: l["tradingPartnerName"], value: l["tradingPartnerName"] });
      }

      l["approvedDateTime"] = this.datePipe.transform(l["approvedDateTime"], "MM/dd/yyyy");
      if (l["approvedDateTime"] && _filterApprovedOn.indexOf(l["approvedDateTime"]) === -1) {
        _filterApprovedOn.push(l["approvedDateTime"]);
        this.filterApprovedOn.push({ label: l["approvedDateTime"], value: l["approvedDateTime"] });
      }

      if (l["fileDescription"] && _filterFileDescription.indexOf(l["fileDescription"]) === -1) {
        _filterFileDescription.push(l["fileDescription"]);
        this.filterFileDescription.push({ label: l["fileDescription"], value: l["fileDescription"] });

      }
      if (l["employerName"] && _filterClientIds.indexOf(l["employerName"]) === -1) {
        _filterClientIds.push(l["employerName"]);
        this.filterclientIds.push({ label: l["employerName"], value: l["employerName"] });
      }
    }
  }

  changeStatus(statusName: string) {
    this.actionPannel.hide();
    this.waitingLoader = true;
    const promotionObj = {
      promotionStatus: {
        configPromotionStatusName: statusName
      },
      configPromotionAuditId: this.selectedRowData.configPromotionAuditId,
      fileIdentifier: this.selectedRowData.fileIdentifier,
      targetEnv: { name: this.selectedRowData.targetEnvName },
      sourceEnv: { name: this.selectedRowData.sourceEnvName }
    };

    this.approvePromotionService.changePromotionStatus(promotionObj).subscribe(res => {
      this.waitingLoader = false;
      if (!res.error) {
        this.approvePromotionList = res.data;
        this.populateFilters(this.approvePromotionList);
        this.toastr.success("Status changed successfully.", "Success!");
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.waitingLoader = false;
      this.toastr.error("Server error while changing status.", "Oops!", TOAST_SETTING);
    });
  }

  actionPannel: OverlayPanel;
  selectedRowData: any;
  rowAction(event, overlaypanel: OverlayPanel, rowData) {
    this.actionPannel = overlaypanel;
    const cids = rowData.clientIds.split(",");
    this.isEmpHaveAccess = this.loginService.isMigrationAccess(cids);
    this.isUserHavePermission = rowData.hasApproveRejectPermissions;
    this.actionPannel.toggle(event);
    this.selectedRowData = rowData;
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  showMigrationDetails(rowData: any) {
    this.selectedRowData = rowData;
    this.migrationDetailsModel = true;
  }

}