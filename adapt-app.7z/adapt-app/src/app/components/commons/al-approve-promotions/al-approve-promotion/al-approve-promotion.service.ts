import { Injectable } from "@angular/core";
import { ApiEnvService } from "../../../../env.service";
import { AuthHttp } from "angular2-jwt";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlApprovePromotionService {
  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/approvePromotion";
  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }



  getAllApprovePromotions(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/get");
  }

  changePromotionStatus(promotionObj): Observable<any> {
    return this.http.post(this.apiEnvEndpoint + "/api/adapt/files/" + promotionObj.fileIdentifier + "/promotion/", promotionObj);
  }

}
