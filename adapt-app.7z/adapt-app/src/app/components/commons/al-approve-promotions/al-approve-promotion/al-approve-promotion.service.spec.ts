import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { AlApprovePromotionService } from "./al-approve-promotion.service";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlApprovePromotionService", () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AlApprovePromotionService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  }));

  it("getAllApprovePromotions", async(inject([AlApprovePromotionService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

    contactService.getAllApprovePromotions({}).subscribe((res) => {
      expect(res.data.length).toBe(10);
    });
  })));

  it("changePromotionStatus", async(inject([AlApprovePromotionService], (contactService) => {
    let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

    contactService.changePromotionStatus({}).subscribe((res) => {
      expect(res.data.length).toBe(16);
    });
  })));
});