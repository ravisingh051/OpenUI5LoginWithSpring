import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-al-file-type-list",
  templateUrl: "./al-file-type-list.component.html",
  styleUrls: ["./al-file-type-list.component.scss"]
})
export class AlFileTypeListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
