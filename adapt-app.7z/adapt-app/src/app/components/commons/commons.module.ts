import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { routing } from "./commons-module-routing";
import { DataTableModule } from "primeng/components/datatable/datatable";
import { DropdownModule } from "primeng/components/dropdown/dropdown";
import { TabViewModule } from "primeng/components/tabview/tabview";
import { CheckboxModule } from "primeng/components/checkbox/checkbox";
import { AutoCompleteModule } from "primeng/components/autocomplete/autocomplete";

import { AlTradingPartnerComponent } from "./al-trading-partner/al-trading-partner.component";
import { AlContactListComponent } from "./al-trading-partner/al-contact-list/al-contact-list.component";
import { AlLobComponent } from "./al-lob/al-lob.component";
import { AlFileTypeListComponent } from "./al-file-type-list/al-file-type-list.component";
import { AlOutputSystemFileComponent } from "./al-output-system-file/al-output-system-file.component";
import { AlCommonsModuleSidebar } from "./al-sidebar/al-sidebar.component";
import { CommonsComponent } from "./commons.component";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DialogModule } from "primeng/components/dialog/dialog";
import { ButtonModule } from "primeng/components/button/button";
import { CalendarModule } from "primeng/primeng";
import { PaginatorModule } from "primeng/components/paginator/paginator";

import { PickListModule } from "primeng/components/picklist/picklist";
import { PanelModule } from "primeng/components/panel/panel";

import { ConfirmDialogModule } from "primeng/components/confirmdialog/confirmdialog";
import { AlNotificationsComponent } from "./al-notifications/al-notifications.component";

import { AlBlackoutWindowComponent } from "./al-blackout-window/al-blackout-window.component";
import { InputSwitchModule } from "primeng/primeng";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { NgxPermissionsModule } from "ngx-permissions";
import { EditorModule } from "primeng/components/editor/editor";
import { AlTradingPartnerPlatformComponent } from "./al-trading-partner/al-trading-partner-platform/al-trading-partner-platform.component";
import { AlProfileComponent } from "./al-profile/al-profile.component";
import { AlTooltipComponent } from "./al-tooltip/al-tooltip.component";
import { AlPriorityOrderComponent } from "./al-priority-order/al-priority-order.component";
import { ListboxModule } from "primeng/components/listbox/listbox";
import { AlKeyManagementComponent } from "./al-trading-partner/al-key-management/al-key-management.component";
import { TradingPartnerService } from "./al-trading-partner/al-tranding-partner-service/tranding-partner.service";
import { AlHeldFilesComponent } from "./al-held-files/al-held-files.component";
import { AlApprovePromotionsComponent } from "./al-approve-promotions/al-approve-promotions.component";
import { AlPopOverModule } from "../../sharedModules/al-popover/al-popover.module";
import { ShowLinkBasedOnEmpAccessModule } from "../../show-link-based-on-emp-access/show-link-based-on-emp-access.module";
import { FileUploadModule } from "primeng/components/fileupload/fileupload";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    routing,
    DataTableModule,
    TabViewModule,
    DropdownModule,
    ReactiveFormsModule,
    CheckboxModule,
    AutoCompleteModule,
    OverlayPanelModule,
    DialogModule,
    ButtonModule,
    PickListModule,
    PanelModule,
    ConfirmDialogModule,
    CalendarModule,
    InputSwitchModule,
    PaginatorModule,
    EditorModule,
    ListboxModule,
    AlPopOverModule,
    FileUploadModule,
    NgxPermissionsModule.forRoot(),
    ShowLinkBasedOnEmpAccessModule
  ],
  declarations: [
    AlCommonsModuleSidebar,
    CommonsComponent,
    AlTradingPartnerComponent,
    AlContactListComponent,
    AlLobComponent,
    AlFileTypeListComponent,
    AlOutputSystemFileComponent,
    AlNotificationsComponent,
    AlBlackoutWindowComponent,
    AlTradingPartnerPlatformComponent,
    AlProfileComponent,
    AlTooltipComponent,
    AlKeyManagementComponent,
    AlHeldFilesComponent,
    AlPriorityOrderComponent,
    AlKeyManagementComponent,
    AlApprovePromotionsComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [
    AuthGuard,
    TradingPartnerService
  ]
})
export class CommonsComponentModule { }
