import { Injectable } from "@angular/core";
import { ApiEnvService } from "../../../../env.service";
import { AuthHttp } from "angular2-jwt";
import { TradingPartnerService } from "../../al-trading-partner/al-tranding-partner-service/tranding-partner.service";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { TOAST_SETTING } from "../../../../global";
import { HttpClient, HttpHeaders, HttpResponse } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlHeldFilesService {
  constructor(private http: HttpClient,
    private tradingPartnerService: TradingPartnerService,
    private toastr: ToastsManager,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/api/adapt/files";

  getHeldFiles(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/get");
  }

  archiveHeldFile(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/archive", data);
  }

  downloadInboundFile(fileStateId, fileName, fromDashboard) {
    let _serviceMappingURL = fromDashboard ? "/download/inbound/" : "/download/held/";
    const targetUrl = this.serviceMappingURL + _serviceMappingURL + "file?fileStateId=" + fileStateId;

    fileName = fileName ? fileName : "inbould_file.asc";

    let headers = new HttpHeaders({
      "Content-Type": "text/plain"
    });
    /* istanbul ignore next*/
    return this.http.get(targetUrl, { headers: headers, responseType: "blob" })
      .subscribe(
        res => {
          if (res.type.indexOf("application/json") !== -1) {
            const reader = new FileReader();
            reader.addEventListener("loadend", (e) => {
              let result = JSON.parse(e.srcElement["result"]);
              if (result.error) {
                this.toastr.error(result.message, "Oops!", TOAST_SETTING);
              }
            });
            reader.readAsText(res);
          } else {
            this.tradingPartnerService.downloadFile(res, fileName);
          }
        }, error => {
          console.log("Error into the downloading file...  " + error);
        });
  }

  mapFutureJob(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/mapFutureJob", data);
  }

  /* istanbul ignore next*/
  downloadOutboundFile(fileStateId, fileName) {
    let _serviceMappingURL = "/download/outbound/";
    const targetUrl = this.serviceMappingURL + _serviceMappingURL + "file?fileStateId=" + fileStateId;

    fileName = fileName ? fileName : "outbound_file.asc";

    let headers = new HttpHeaders({
      "Content-Type": "text/plain"
    });
    return this.http.get(targetUrl, { headers: headers, responseType : "blob"})
      .subscribe(
        res => {
          if (res.type.indexOf("application/json") !== -1) {
            const reader = new FileReader();
            reader.addEventListener("loadend", (e) => {
              let result = JSON.parse(e.srcElement["result"]);
              if (result.error) {
                this.toastr.error(result.message, "Oops!", TOAST_SETTING);
              }
            });
            reader.readAsText(res);
          }
          else {
            this.tradingPartnerService.downloadFile(res, fileName);
          }
        }, error => {
          console.log("Error into the downloading file...  " + error);
        });
  }

}
