import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { AlHeldFilesService } from "./al-held-files.service";
import { TradingPartnerService } from "../../al-trading-partner/al-tranding-partner-service/tranding-partner.service";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { ToastModule, ToastOptions } from "ng2-toastr";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: AlHeldFilesService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                AlHeldFilesService,
                TradingPartnerService,
                ToastsManager,
                ToastOptions,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("getHeldFiles", async(inject([AlHeldFilesService], (contactService) => {
        let response = require("../../../../../assets/test-data/commons/HeldFiles/get.json");

        contactService.getHeldFiles({}).subscribe((res) => {
        });
    })));

    it("archiveHeldFile", async(inject([AlHeldFilesService], (contactService) => {
        let response = require("../../../../../assets/test-data/commons/HeldFiles/get.json");

        contactService.archiveHeldFile({}).subscribe((res) => {
        });
    })));
    it("mapFutureJob", async(inject([AlHeldFilesService], (contactService) => {
        let response = require("../../../../../assets/test-data/commons/HeldFiles/get.json");

        contactService.mapFutureJob({}).subscribe((res) => {
        });
    })));
    it("downloadInboundFile", async(inject([AlHeldFilesService], (contactService) => {
        let response = require("../../../../../assets/test-data/commons/HeldFiles/get.json");
        let fileStateId, fileName;
        fileStateId = 301;
        fileName = "inbould_file.asc";
        contactService.downloadInboundFile(fileStateId, fileName);
    })));
});