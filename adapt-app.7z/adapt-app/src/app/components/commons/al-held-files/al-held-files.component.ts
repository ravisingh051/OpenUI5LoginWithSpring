import { Component, OnInit, ViewChild } from "@angular/core";
import { AlHeldFilesService } from "./al-held-files/al-held-files.service";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastsManager } from "ng2-toastr";
import { DatePipe } from "@angular/common";
import { Router, NavigationExtras } from "@angular/router";
import { ConfirmationService } from "primeng/components/common/api";
import { RescheduleService } from "../../../services/common/reschedule";
import { DataTable } from "primeng/components/datatable/datatable";
import { NgxPermissionsService } from "ngx-permissions";
import { TOAST_SETTING } from "../../../global";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import * as moment from "moment-timezone";
import { LoginService } from "../../login/login.service";

@Component({
  selector: "app-al-held-files",
  templateUrl: "./al-held-files.component.html",
  providers: [AlHeldFilesService, DatePipe, ConfirmationService]
})
export class AlHeldFilesComponent implements OnInit {
  heldFileList = [];
  filterTradingPartners = [];
  filterTradingPartnerModel: any;

  filterAdaptIds = [];
  filterAdaptIdModel: any;

  filterJobIds = [];
  filterJobIdModel: any;

  filterFileNames = [];
  filterFileNameModel: any;

  filterFileStatus = [];
  filterFileStatusModel: any;

  filterHeldOnDates = [];
  filterHeldOnDatesModel: any;

  filterFutureDates = [];
  filterFutureDatesModel: any;

  tableDataLoading: boolean;
  validationMsg: string;
  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  tooltipResult: any;
  pageID: number = 37;

  isEmpHaveAccess: boolean;

  constructor(private helfFileService: AlHeldFilesService,
    private toastr: ToastsManager,
    private datePipe: DatePipe,
    private router: Router,
    private confirmationService: ConfirmationService,
    private rescheduleService: RescheduleService,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService,
    private loginService: LoginService) { }

  ngOnInit() {
    this.tableDataLoading = true;
    this.getHeldFiles();
    this.validationMsg = window["validationMsg"];
    this.getToolTipTextDetails();
  }

  /**
   * To all helf files.
   */
  getHeldFiles() {
    this.helfFileService.getHeldFiles().subscribe(res => {
      if (!res.error) {
        this.setHeldFileData(res);
      }
    });
  }

  /**
   * It's set responce in respective fields.
   * @param res Object
   */
  setHeldFileData(res) {
    if (this.table) {
      this.resetTable();
    }
    this.heldFileList = res.data.heldFiles;
    this.tableDataLoading = false;
    this.heldFileList = [...this.heldFileList];
    this.heldFileList.sort((a, b) => { return b.createdDateTime - a.createdDateTime; });
    this.filterFutureDates = [];
    let _filterFutureDates = [];
    this.filterHeldOnDates = [];
    let _filterHeldOnDates = [];
    let _heldFilter = {};
    this.filterFutureDates.unshift({ label: "All", value: null });
    this.filterHeldOnDates.unshift({ label: "All", value: null });
    _heldFilter["createdDateTime"] = [];
    _heldFilter["jobExpectedStartDatetime"] = [];
    for (let i = 0; i < this.heldFileList.length; i++) {
      if (this.heldFileList[i].jobExpectedStartDatetime != null) {
        if (_heldFilter["jobExpectedStartDatetime"].indexOf(this.heldFileList[i].jobExpectedStartDatetime) === -1) {
          const jobExpectedStartDatetime = this.datePipe.transform(this.heldFileList[i].jobExpectedStartDatetime, "MM/dd/yyyy EEE");
          let temp = jobExpectedStartDatetime.replace(/\s*[a-z]+/ig, "");
          this.heldFileList[i].jobExpectedStartDate = new Date(temp).getTime();
          _heldFilter["jobExpectedStartDatetime"].push({
            "date": jobExpectedStartDatetime,
            "time": this.heldFileList[i].jobExpectedStartDate
          });
        }
      }
      if (this.heldFileList[i].createdDateTime != null) {
        if (_heldFilter["createdDateTime"].indexOf(this.heldFileList[i].createdDateTime) === -1) {
          const createdDateTime = this.datePipe.transform(this.heldFileList[i].createdDateTime, "MM/dd/yyyy EEE");
          let temp = createdDateTime.replace(/\s*[a-z]+/ig, "");
          this.heldFileList[i].createdDate = new Date(temp).getTime();
          _heldFilter["createdDateTime"].push({
            "date": createdDateTime,
            "time": this.heldFileList[i].createdDate
          });
        }
        this.heldFileList[i].createdDateTime = moment.tz(this.heldFileList[i].createdDateTime, "America/Chicago").format("MM/DD/YYYY ddd");
      }
    }
    for (let value of _heldFilter["jobExpectedStartDatetime"].sort((a, b) => a - b)) {
      if (_filterFutureDates.indexOf(value.date) === -1) {
        _filterFutureDates.push(value.date);
        this.filterFutureDates.push({ label: value.date, value: value.time });
      }
    }
    for (let value of _heldFilter["createdDateTime"].sort((a, b) => a - b)) {
      if (_filterHeldOnDates.indexOf(value.date) === -1) {
        _filterHeldOnDates.push(value.date);
        this.filterHeldOnDates.push({ label: value.date, value: value.time });
      }
    }
    this.setFilterDropdownData(res);
  }

  resetTable() {
    this.table.reset();
    this.filterTradingPartnerModel = null;
    this.filterAdaptIdModel = null;
    this.filterJobIdModel = null;
    this.filterFileNameModel = null;
    this.filterFileStatusModel = null;
    this.filterHeldOnDatesModel = null;
    this.filterFutureDatesModel = null;
  }

  setFilterDropdownData(res) {
    this.filterTradingPartners = res.data.uniqTradingPartners;
    this.filterTradingPartners.unshift({ label: "All", value: null });

    this.filterAdaptIds = res.data.uniqAdaptIds;
    this.filterAdaptIds.unshift({ label: "All", value: null });

    this.filterJobIds = res.data.uniqJobIds;
    this.filterJobIds.unshift({ label: "All", value: null });

    this.filterFileNames = res.data.uniqFileName;
    this.filterFileNames.unshift({ label: "All", value: null });

    this.filterFileStatus = res.data.uniqFileStatus;
    this.filterFileStatus.unshift({ label: "All", value: null });
  }

  /**
   * When click on any action then this method will call.
   */
  actionPannel: OverlayPanel;
  selectedHeldFile: any;
  table: DataTable;
  rowAction(event, overlaypanel, rowData, table) {
    this.actionPannel = overlaypanel;
    this.isEmpHaveAccess = this.loginService.isEmployerHaveAccess([rowData.clientIds]);
    this.actionPannel.toggle(event);
    this.selectedHeldFile = rowData;
    this.table = table;
  }

  /**
   * To Map first future job.
   */
  /* istanbul ignore next */
  mapFutureJob() {
    this.confirmationService.confirm({
      message: "Are you sure you want to map it to the first future scheduled job ?",
      accept: () => {
        this.actionPannel.hide();
        const obj = {
          fileStateId: this.selectedHeldFile.fileStateId,
          jobDetails: { jobId: this.selectedHeldFile.jobId },
          fileMetaInfo: { fileId: this.selectedHeldFile.fileId }
        };
        this.helfFileService.mapFutureJob(obj).subscribe(res => {
          if (!res.error) {
            this.setHeldFileData(res);
            this.toastr.success("Future job mapped successfully.", "Success!");
          } else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        });
      }, reject: () => {
      }
    });
  }

  /**
   * To Attach adhoc job.
   */
  /* istanbul ignore next */
  addAdhocJob() {
    this.actionPannel.hide();

    const fileStateObj = {
      "fileStateId": this.selectedHeldFile.fileStateId,
      "fileId": this.selectedHeldFile.fileId,
      "jobId": this.selectedHeldFile.jobId,
      "futureDate": this.selectedHeldFile.jobExpectedStartDatetime
    };

    this.rescheduleService.setFileStateObj(fileStateObj);
    this.router.navigate(["/new-job-schedule"]);
  }

  /**
   * To Archive the file.
   */
  /* istanbul ignore next */
  archiveOnly() {
    this.actionPannel.hide();
    const heldFileObj = {
      fileStateId: this.selectedHeldFile.fileStateId,
      jobDetails: { jobId: this.selectedHeldFile.jobId },
      fileMetaInfo: { fileId: this.selectedHeldFile.fileId },
      newFileName: this.selectedHeldFile.newFileName,
      filePath: this.selectedHeldFile.filePath,
      fileArchivalPath: this.selectedHeldFile.fileArchivalPath
    };

    this.helfFileService.archiveHeldFile(heldFileObj).subscribe(res => {
      if (!res.error) {
        this.setHeldFileData(res);
        this.toastr.success("File archived successfully.", "Success!");
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    });
  }

  /**
   * To Download inbound file.
   */
  downloadInboundFile() {
    this.actionPannel.hide();
    this.helfFileService.downloadInboundFile(this.selectedHeldFile.fileStateId, this.selectedHeldFile.fileName, false);
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }
}

export class HeldFiles {
  fileStateId: number;
  fileName: string;
  tradingPartner: Object;
  filePath: string;
  fileArchivalPath: string;
  fileIdentifier: Object;
  jobId: Object;
  encryptedPrivateKey: string;
  publicKey: string;
  isEmpty: boolean;
  isDuplicate: boolean;
  fileStatus: string;
  newFileName: string;
}