import { async, ComponentFixture, TestBed, tick, fakeAsync } from "@angular/core/testing";

import { AlHeldFilesComponent } from "./al-held-files.component";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, ConfirmDialogModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlHeldFilesService } from "./al-held-files/al-held-files.service";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { ConfirmationService } from "primeng/components/common/api";
import { DatePipe } from "@angular/common";
import { TemplateRef, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { RescheduleService } from "../../../services/common/reschedule";
import { TradingPartnerService } from "../al-trading-partner/al-tranding-partner-service/tranding-partner.service";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { LoginService } from "../../login/login.service";
import { ApiEnvService } from "../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlHeldFilesComponent", () => {
  let component: AlHeldFilesComponent;
  let fixture: ComponentFixture<AlHeldFilesComponent>;
  let ngxPermission;
  let heldFileService, toastService;


  beforeEach(async(() => {
    TestBed.overrideComponent(AlHeldFilesComponent, {
      set: {
        providers: [
          { provide: AlHeldFilesService, useClass: FakeHeldFilesService },
          { provide: LoginService, useClass: FakeHeldFilesService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        ConfirmDialogModule,
        DialogModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlHeldFilesComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        ApiEnvService,
        ConfirmationService,
        TradingPartnerService,
        RescheduleService,
        { provide: ToolTipUtilService, useClass: FakeToolTip },
        { provide: AlHeldFilesService, useClass: FakeHeldFilesService },
        { provide: LoginService, useClass: FakeHeldFilesService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(AlHeldFilesComponent);
      component = fixture.componentInstance;
      ngxPermission = TestBed.get(NgxPermissionsService);
      ngxPermission.addPermission(" Notification-View All templates ");
      ngxPermission.addPermission("accessDenied");
      component = fixture.componentInstance;
      toastService = TestBed.get(ToastsManager);
    });
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should ngOnInit", () => {
    component.ngOnInit();
  });

  it("should rowAction()", () => {
    const event = {
      stopPropagation: (e) => {
      },
    };
    let actionItems = {
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    let rowData = {
      "fileIdentifier": 2076,
      "fileVersion": 9,
      "jobId": 5860,
      "fileId": 729,
      "newFileName": "dardensecondary.txt_1559881421282",
      "filePath": "/apps/Benefits/adapt/qa/files/ready",
      "fileArchivalPath": "/apps/Benefits/adapt/qa/files/archive",
      "tradingPartnerId": null,
      "tradingPartnerName": null,
      "fileStateId": 973,
      "createdDateTime": "06/06/2019 Thu",
      "jobExpectedStartDatetime": "2019-06-28",
      "fileStatus": "UNEXPECTED",
      "isEmpty": false,
      "isDuplicate": true,
      "clientIds": "07471",
      "fileName": "dardensecondary.txt",
      "jobExpectedStartDate": 1561660200000,
      "createdDate": 1559845800000
    };
    let table = {
      reset: () => {
      },
    };
    component.rowAction(event, actionItems, rowData, table);
    component.downloadInboundFile();
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.reject();
    });
    component.mapFutureJob();
    component.resetTable();
  });

  it("should and displayToolTipText()", () => {
    component.getToolTipTextDetails();
    component.toolTipPageFieldsData = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });

});

class FakeHeldFilesService extends AlHeldFilesService {
  errorFlag: boolean = false;
  getHeldFiles(): Observable<any> {
    let response = require("../../../../assets/test-data/commons/HeldFiles/get.json");
    return Observable.of(response);
  }
  archiveHeldFile(): Observable<any> {
    let response = require("../../../../assets/test-data/commons/HeldFiles/get.json");
    return Observable.of(response);
  }
  mapFutureJob(): Observable<any> {
    let response = require("../../../../assets/test-data/commons/HeldFiles/get.json");
    return Observable.of(response);
  }
  isEmployerHaveAccess(empId: any): Observable<any> {
    let response = require("../../../../assets/test-data/commons/HeldFiles/get.json");
    return Observable.of(response);
  }
}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
