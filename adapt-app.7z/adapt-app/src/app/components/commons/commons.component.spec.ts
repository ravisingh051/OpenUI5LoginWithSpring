import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { Routes } from "@angular/router";

import { CommonsComponent } from "./commons.component";
import { AlSidebarComponent } from "../al-sidebar/al-sidebar.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

const routes: Routes = [
  {
    path: "dashboard",
    component: CommonsComponent
  },
  {
    path: "commons",
    component: CommonsComponent
  }
];

describe("CommonsComponent", () => {
  let component: CommonsComponent;
  let fixture: ComponentFixture<CommonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes(routes)],
      declarations: [ CommonsComponent, AlSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
