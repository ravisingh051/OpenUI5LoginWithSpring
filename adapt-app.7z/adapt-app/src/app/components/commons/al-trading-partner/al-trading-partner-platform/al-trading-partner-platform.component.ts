import { Component, OnInit, Input, SimpleChange, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { NgForm } from "@angular/forms";
import { TradingPartnerService } from "../al-tranding-partner-service/tranding-partner.service";
import { ConfirmationService } from "primeng/components/common/api";
import { OverlayPanel } from "primeng/primeng";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { TOAST_SETTING } from "../../../../global";

@Component({
  selector: "al-trading-partner-platform",
  templateUrl: "./al-trading-partner-platform.component.html",
  styleUrls: ["./al-trading-partner-platform.component.scss"],
  providers: [ConfirmationService, ToolTipUtilService]
  // providers:[TradingPartnerService, ConfirmationService, ToolTipUtilService]
})
export class AlTradingPartnerPlatformComponent implements OnInit {

  constructor(
    private confirmationService: ConfirmationService,
    private tpService: TradingPartnerService,
    public toastr: ToastsManager,
    private toolTipUtils: ToolTipUtilService
  ) { }

  tableDataLoading: boolean;
  isActive: boolean = false;
  isEdit: boolean = false;

  /* ToolTip display OnMouse Click */
  toolTipTradingPP: any = [];
  tooltipResult: any;
  pageID: number = 2;
  validationMsg: string;

  @Input() tradingParterList;

  /* Filters */
  filterPlatformName;
  filterPlatformNameModel;
  filterPlatformTradingpatner;
  filterPlatformTradingpatnerModel;
  filterPlatformStatus;
  filterPlatformStatusModel;
  @ViewChildren("dropDown") dropDown: QueryList<Dropdown>;
  ngOnInit() {
    this.tableDataLoading = true;
    this.populatetrPtnrPlfrm();
    this.getToolTipTextDetails();
    this.validationMsg = window["validationMsg"];
  }
  ngOnChanges(change: SimpleChange) {
    if (change["tradingParterList"].currentValue !== undefined) {
      this.populateTPList();
    }
  }
  populateTPList() {
    let _tpList = [];
    if (this.tradingParterList.length !== 0) {
      for (let obj of this.tradingParterList) {
        if (obj.active) {
          _tpList.push({
            "label": obj.tradingPartnerName,
            "value": obj.tradingPartnerId
          });
        }
      }
      this.tradingParterList = _tpList;
      this.tradingParterList.unshift({ label: "Select a Partner", valule: null });
      // I thought it's called unnecessarily, It is already called from ngOnInit()
      // this.populatetrPtnrPlfrm();
    }
  }

  tradingPartnerId: number;
  tradingPartnerPlatformName: string;
  tradingPartnerPlatformDesc: string;
  btnClicked: boolean;
  addTPartPlt(tPartPltForm: NgForm) {
    this.btnClicked = true;

    let validValue = true;
    if (this.tradingPartnerPlatformName.trim() === "") {
      validValue = false;
      this.tradingPartnerPlatformName = "";
      this.btnClicked = false;
    }
    if (validValue === false) {
      return false;
    }

    let tradingPartnerPlatformData = {
      "tradingPartnerPlatformName": this.tradingPartnerPlatformName.trim(),
      "tradingPartnerPlatformDesc": this.tradingPartnerPlatformDesc,
      "tradingPartnerInfo": {
        "tradingPartnerId": this.tradingPartnerId
      },
      "active": this.isActive,
    };
    if (this.isEdit) {
      tradingPartnerPlatformData["uniqueIdentifier"] = this.selTrndgPtnrPltfrmData.uniqueIdentifier;
      tradingPartnerPlatformData["tradingPartnerPlatformId"] = this.selTrndgPtnrPltfrmData.tradingPartnerPlatformId;
      this.updateTradingPartnerPlatform(tPartPltForm, tradingPartnerPlatformData);
    }
    else {
      this.addTradingPartnerPlatform(tPartPltForm, tradingPartnerPlatformData);
    }
    let ddArray = this.dropDown.toArray();
    ddArray.forEach((ele) => {
      ele.filterValue = null;
    });
  }

  addTradingPartnerPlatform(form, data) {
    this.tpService.addTradingPartnerPlatform(data).subscribe(res => {
      if (!res.error) {
        this.trPtnrPlfrmList = res.data;
        this.btnClicked = false;
        form.resetForm({ isActiveModel: false });
        this.populateFilterDropDown();
        this.toastr.success("Trading Partner Platform added successfully.", "Success!");
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.btnClicked = false;
      }
    }, error => {
      this.toastr.error("Server Error in adding Trading Partner Platform.", "Oops!", TOAST_SETTING);
    });
  }

  updateTradingPartnerPlatform(form, data) {
    this.tpService.updateTradingPartnerPlatform(data).subscribe(res => {
      if (!res.error) {
        this.trPtnrPlfrmList = res.data;
        this.btnClicked = false;
        form.resetForm({ isActiveModel: false });
        this.isEdit = false;
        this.selTrndgPtnrPltfrmData = [];
        this.populateFilterDropDown();
        this.toastr.success("Trading Partner Platform updated successfully.", "Success!");
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.btnClicked = false;
      }
    }, error => {
      this.toastr.error("Server Error in updating Trading Partner Platform.", "Oops!", TOAST_SETTING);
    });
  }


  trPtnrPlfrmList: any = [];
  populatetrPtnrPlfrm() {
    this.tpService.viewTradingPartnerPlatform().subscribe(res => {
      if (!res.error) {
        this.trPtnrPlfrmList = res.data;
        this.tableDataLoading = false;
        this.populateFilterDropDown();

        /**
         * ALIGHT - 291
         * To sent this trading partner platform list into key management component
        */
        this.tpService.tradingPartnerPlatformListSubject.next({ tpList: this.trPtnrPlfrmList });
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in getting Trading Partner Platform.", "Oops!", TOAST_SETTING);
    });

  }

  actionPannel: OverlayPanel;
  selTrndgPtnrPltfrmData: any;
  rowAction(event, overlaypanel: OverlayPanel, rowData) {
    this.actionPannel = overlaypanel;
    this.actionPannel.toggle(event);
    this.selTrndgPtnrPltfrmData = rowData;
  }

  editPlatform() {
    this.actionPannel.hide();
    this.isEdit = true;
    this.tradingPartnerPlatformName = this.selTrndgPtnrPltfrmData.tradingPartnerPlatformName;
    this.tradingPartnerPlatformDesc = this.selTrndgPtnrPltfrmData.tradingPartnerPlatformDesc;
    this.tradingPartnerId = this.selTrndgPtnrPltfrmData.tradingPartnerInfo.tradingPartnerId;
    this.isActive = this.selTrndgPtnrPltfrmData.active;
    window.scrollTo(0, 0);
  }

  populateFilterDropDown() {
    /**
     * ALIGHT - 291
     * To sent this trading partner platform list into key management component
    */
    this.tpService.tradingPartnerPlatformListSubject.next({ tpList: this.trPtnrPlfrmList });
    this.tpfNames = [];
    this.filterPlatformName = [{ label: "All", value: null }];
    let _filterPlatformName: any = [];
    this.filterPlatformTradingpatner = [{ label: "All", value: null }];
    let _filterPlatformTradingpatner: any = [];
    this.filterPlatformStatus = [
      { label: "All", value: null },
      { label: "Active", value: true },
      { label: "Inactive", value: false }
    ];


    if (this.trPtnrPlfrmList !== null) {
      for (let i = 0; i < this.trPtnrPlfrmList.length; i++) {

        if (_filterPlatformName.indexOf(this.trPtnrPlfrmList[i].tradingPartnerPlatformName) === -1) {
          _filterPlatformName.push(this.trPtnrPlfrmList[i].tradingPartnerPlatformName);
        }
        if (_filterPlatformTradingpatner.indexOf(this.trPtnrPlfrmList[i].tradingPartnerInfo.tradingPartnerName) === -1) {
          _filterPlatformTradingpatner.push(this.trPtnrPlfrmList[i].tradingPartnerInfo.tradingPartnerName);
        }

      };
    }
    for (let value of _filterPlatformName) {
      this.filterPlatformName.push({ label: value, value: value });
      this.tpfNames.push(value);
    }
    for (let value of _filterPlatformTradingpatner) {
      this.filterPlatformTradingpatner.push({ label: value, value: value });
    }
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipTradingPP = res.data;
    });
  }


  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipTradingPP[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // CC-38451
  results: any = [];
  tpfNames: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.tpfNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

}
