import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { TradingPartnerService } from "./tranding-partner.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: TradingPartnerService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                TradingPartnerService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("addTP", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-templete.json");

        contactService.addTP({}).subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("viewTP", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

        contactService.viewTP().subscribe((res) => {
            expect(res.data.length).toBe(16);
        });
    })));
    it("viewActiveTP", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-fileType-detail.json");

        contactService.viewActiveTP().subscribe((res) => {
            expect(res.data.length).toBe(16);
        });
    })));

    it("updateTP", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-element.json");

        contactService.updateTP().subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("deleteTradingPartner", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.deleteTradingPartner().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("addFTPConfiguration", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.addFTPConfiguration().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("updateFTPConfiguration", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.updateFTPConfiguration().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("deleteFTPConfiguration", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.deleteFTPConfiguration().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("viewFTPDetails", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.viewFTPDetails().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("isFTPExists", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.isFTPExists().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("addTradingPartnerPlatform", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.addTradingPartnerPlatform().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("updateTradingPartnerPlatform", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.updateTradingPartnerPlatform().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("viewTradingPartnerPlatform", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.viewTradingPartnerPlatform().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getPageAndFieldsDetails", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getPageAndFieldsDetails().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("addKeyManagement", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.addKeyManagement().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("viewKeyManagement", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.viewKeyManagement().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getAllDeliveryMechanismType", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllDeliveryMechanismType().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getAllTransferProtocolInfo", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllTransferProtocolInfo().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getAllEnvironmentInfo", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllEnvironmentInfo().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getAllTradingPartnerPlatformByPartnerId", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllTradingPartnerPlatformByPartnerId().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getTradingPartnerConnectionInfoById", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getTradingPartnerConnectionInfoById().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
    it("getAllTradingPartnerContactsByPartnerId", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllTradingPartnerContactsByPartnerId().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("downloadPublicKey", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");
        let keymrn = {
            "createdBy": "Ankur Aggarwal",
            "createdDateTime": "11/01/2019 12:35:49.787 GMT",
            "updatedBy": "Ankur Aggarwal",
            "updatedDateTime": "11/01/2019 12:35:49.787 GMT",
            "tradingPartnerAuthKeyId": 56,
            "tradingPartner": {
                "createdBy": "Ankur Aggarwal",
                "tradingPartnerId": 263,
                "tradingPartnerName": "722TP",
                "tradingPartnerType": "Dev",
                "active": true,
                "lastUpdatedDateTime": "01/11/19 06:24 CT",
                "uniqueIdentifier": "D24E8381-98FE-4BED-AC8A-A0A2CAA68284"
            },
            "tradingPartnerPlatform": {
                "createdBy": "Ankur Aggarwal",
                "createdDateTime": "11/01/2019 12:24:59.467 GMT",
                "updatedBy": "Ankur Aggarwal",
                "updatedDateTime": "11/01/2019 12:24:59.467 GMT",
                "tradingPartnerPlatformId": 214,
                "tradingPartnerPlatformName": "722TPP",
                "tradingPartnerPlatformDesc": null,
                "tradingPartnerInfo": {
                    "createdBy": "Ankur Aggarwal",
                    "createdDateTime": "11/01/2019 12:24:45.717 GMT",
                    "updatedBy": "Ankur Aggarwal",
                    "updatedDateTime": "11/01/2019 12:24:45.717 GMT",
                    "tradingPartnerId": 263,
                    "tradingPartnerName": "722TP",
                    "tradingPartnerType": "Dev",
                    "active": true,
                    "lastUpdatedDateTime": "01/11/19 06:24 CT",
                    "uniqueIdentifier": "D24E8381-98FE-4BED-AC8A-A0A2CAA68284"
                },
                "lastUpdatedDateTime": "01/11/19 06:24 CT",
                "uniqueIdentifier": "A14AC78E-F2C1-42E1-954A-1C977237773D",
                "active": true
            },
            "direction": "I",
            "lastUpdatedDateTime": "01/11/19 06:35 CT",
            "uniqueIdentifier": "976DED3B-B695-466A-894A-A32F548ACC4E"
        };
        contactService.downloadPublicKey({ keymrn });
        // contactService.downloadPublicKey({keymrn}).subscribe((res) => {
        //     expect(res.data.length).toBe(136);
        // });
    })));


    it("getAllNotificationTemplates", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");

        contactService.getAllNotificationTemplates().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("getKeyId", async(inject([TradingPartnerService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");
        let file = {};
        contactService.getKeyId(file).subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));


});