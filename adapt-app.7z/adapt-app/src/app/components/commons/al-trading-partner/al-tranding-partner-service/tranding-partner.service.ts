import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { Subject } from "rxjs";
import { ApiEnvService } from "../../../../env.service";
import { Observable } from "rxjs/Observable";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class TradingPartnerService {

    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }

    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/TradingPartner";
    masterMappingURL = this.apiEnvEndpoint + "/master";
    contactMappingURL = this.apiEnvEndpoint + "/TradingPartnerContact";
    notificationTemplatesMappingURL = this.apiEnvEndpoint + "/notification";
    public tradingPartnerPlatformListSubject = new Subject();
    tradingPartnerPlatformListObserver$ = this.tradingPartnerPlatformListSubject.asObservable();

    addTP(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/add", data);
    }

    viewTP(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/details");
    }

    viewActiveTP(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/activeTp");
    }

    updateTP(data, id): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/update?tradingPartnerContactId=" + id, data);
    }


    deleteTradingPartner(tradingPartnerId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/delete?tradingPartnerId=" + tradingPartnerId)
            .map(extractData).catch(handleError);
    }

    /* Add trading partner connection information*/
    addFTPConfiguration(ftpConfigModel): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/add/ftp", ftpConfigModel);
    }

    /* Update trading partner connection information*/
    updateFTPConfiguration(ftpConfigModel): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/update/ftp", ftpConfigModel);
    }

    /* Delete trading partner connection information*/
    deleteFTPConfiguration(tradingPartnerFTPId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/delete/ftp?tradingPartnerFTPId=" + tradingPartnerFTPId);
    }

    /* Get all trading partner connection information*/
    viewFTPDetails(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/view/connections");
    }

    /* Check any trading partner connection information with same name */
    isFTPExists(tpId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/isFTPExists?tradingPartnerId=" + tpId)
            .map(extractData).catch(handleError);
    }

    /* Trading Partner Platform */
    addTradingPartnerPlatform(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/add/tradingPartnerPlatform", data);
    }

    updateTradingPartnerPlatform(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/update/tradingPartnerPlatform", data);
    }

    viewTradingPartnerPlatform(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/view/tradingPartnerPlatform");
    }
    getPageAndFieldsDetails(adaptWebPageID): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TooDetails/toolTipPageDetails?adaptWebPageID=" + adaptWebPageID);
    }

    /** Key Management */
    addKeyManagement(data): Observable<any> {
        let headers: HttpHeaders = new HttpHeaders();
        return this.http.post(this.serviceMappingURL + "/save/keyMgmt", data, { headers: headers });
    }

    viewKeyManagement(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/get/keyMgmt");
    }

    /** To call API and get responce with download file data */
    downloadPublicKey(keyMgmtObj) {
        const targetUrl = this.serviceMappingURL + "/download/keyMgmt/file?tradingPartnerAuthKeyId=" + keyMgmtObj.tradingPartnerAuthKeyId;
        const fileName = keyMgmtObj.keyName + "_public_key.asc";

        let headers = new HttpHeaders({
            "Content-Type": "text/plain"
        });
        return this.http.get(targetUrl, { headers: headers, responseType: "blob" })
            .subscribe(
                res => {
                    if (res) {
                        this.downloadFile(res, keyMgmtObj.fileName ? keyMgmtObj.fileName : fileName);
                    }
                }, error => {
                    console.log("Error into the downloading file...  " + error);
                });
    }

    /** To downloading a file */
    downloadFile(data, fileName) {
        if (navigator.msSaveBlob) { // IE 10+
            let blob = new Blob([data], {
                "type": "text/plain;charset=utf8;"
            });
            navigator.msSaveBlob(blob, fileName);
        }
        else {
            let blob = new Blob([data], { type: "text/plain;charset=utf-8;" });
            let dwldLink = document.createElement("a");
            let url = URL.createObjectURL(blob);
            let isSafariBrowser = navigator.userAgent.indexOf("Safari") !== -1 && navigator.userAgent.indexOf("Chrome") === -1;
            if (isSafariBrowser) {  // if Safari open in new window to save file with random filename.
                dwldLink.setAttribute("target", "_blank");
            }
            dwldLink.setAttribute("href", url);
            dwldLink.setAttribute("download", fileName);
            dwldLink.style.visibility = "hidden";
            document.body.appendChild(dwldLink);
            dwldLink.click();
            document.body.removeChild(dwldLink);
        }
    }

    getAllDeliveryMechanismType(): Observable<any> {
        return this.http.get(this.masterMappingURL + "/delivery/getall");
    }

    getAllTransferProtocolInfo(): Observable<any> {
        return this.http.get(this.masterMappingURL + "/protocol/getall");
    }


    getAllEnvironmentInfo(): Observable<any> {
        return this.http.get(this.masterMappingURL + "/environment/getall");
    }

    getAllTradingPartnerPlatformByPartnerId(partnerId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getPlatformsByTPId?tradingPartnerId=" + partnerId);
    }


    getTradingPartnerConnectionInfoById(connectionId: number): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/view/ftp/" + connectionId);
    }

    getAllTradingPartnerContactsByPartnerId(partnerId): Observable<any> {
        return this.http.get(this.contactMappingURL + "/getcontacts" + "/" + "tradingpartner" + "/" + partnerId);
    }

    /**
     * API to get notification templates associated with event - MoveIT User Creation
     */
    getAllNotificationTemplates(): Observable<any> {
        return this.http.get(this.notificationTemplatesMappingURL);
    }

    getKeyId(file): Observable<any> {
        let formData = new FormData();
        formData.append("file", file);

        let headers: HttpHeaders = new HttpHeaders();

        return this.http.post(this.serviceMappingURL + "/key", formData, { headers: headers })
            .catch(handleError);
    }

}
