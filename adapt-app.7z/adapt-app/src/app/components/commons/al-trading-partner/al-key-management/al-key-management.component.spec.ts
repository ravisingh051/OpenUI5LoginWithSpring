import { async, ComponentFixture, TestBed } from "@angular/core/testing";


import { AlKeyManagementComponent } from "./al-key-management.component";
import { fakeActivatedRoute, randomString } from "../../../../common-test/common";
import { NgxPermissionsService, NgxPermissionsStore, NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { TradingPartnerService } from "../al-tranding-partner-service/tranding-partner.service";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { DataTableModule, DialogModule, OverlayPanelModule, DropdownModule, AutoCompleteModule, ConfirmDialogModule, ConfirmationService, OverlayPanel } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { DatePipe } from "@angular/common";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AlCommonsModuleSidebar } from "../../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { CUSTOM_ELEMENTS_SCHEMA, TemplateRef, SimpleChange } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Observer } from "rxjs/Observer";
import { Observable } from "rxjs/Observable";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TradingPartnerConnectionInfo } from "../al-trading-partner-model/trading-partner-ftp-config.model";
import { By } from "@angular/platform-browser";
import { Subject } from "rxjs";
import { AlPopOverModule } from "../../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlKeyManagementComponent", () => {
  let component: AlKeyManagementComponent;
  let fixture: ComponentFixture<AlKeyManagementComponent>; let ngxPermission: NgxPermissionsService;
  let tradingService: TradingPartnerService, toastService: ToastsManager;


  beforeEach(async(() => {
    TestBed.overrideComponent(AlKeyManagementComponent, {
      set: {
        providers: [
          { provide: TradingPartnerService, useClass: FakeTradingPartnerService },
          { provide: ToolTipUtilService, useClass: FakeToolTipUtilService }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        OverlayPanelModule,
        DropdownModule,
        AutoCompleteModule,
        BrowserAnimationsModule,
        ConfirmDialogModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlKeyManagementComponent, AlCommonsModuleSidebar, AlSidebarComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        ToastOptions,
        NgxPermissionsService,
        NgxPermissionsStore,
        OverlayPanel,
        TemplateRef,
        DatePipe,
        AppUtility,
        { provide: TradingPartnerService, useClass: FakeTradingPartnerService },
        { provide: ToolTipUtilService, useClass: FakeToolTipUtilService },
        { provide: ConfirmationService, useClass: FakeConfirmationservice },
        // { provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http, RequestOptions] },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlKeyManagementComponent);
    component = fixture.componentInstance;
    ngxPermission = TestBed.get(NgxPermissionsService);
    ngxPermission.addPermission("Key Management-View All Key");
    ngxPermission.addPermission("Key Management-Add Key");
    ngxPermission.addPermission("Key Management-Edit Key");
    ngxPermission.addPermission("Key Management-Download Key");
    ngxPermission.addPermission("Key Management-Edit Key");
    ngxPermission.addPermission("Key Management-Download Key");
    tradingService = fixture.debugElement.injector.get(TradingPartnerService);
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should on init", () => {
    component.ngOnInit();
  });

  it("should on init error", () => {
    spyOn(tradingService, "viewKeyManagement").and.returnValue(Observable.throw("No Data"));
    component.ngOnInit();
  });
  it("should on createTPDropDown", () => {
    component.tradingParterList = [{
      active: false,
      createdBy: "Ankur Aggarwal",
      createdDateTime: "27/09/2018 01:48:14.107 GMT",
      lastUpdatedDateTime: "12/06/18 00:06 CT",
      tradingPartnerDescription: "fh testing",
      tradingPartnerEmployerId: null,
      tradingPartnerId: 91,
      tradingPartnerIsConsenting: true,
      tradingPartnerName: "0 - Orac_1",
      tradingPartnerType: "Dev",
      uniqueIdentifier: "14049084-9C5B-4391-946D-A81A64B5745C",
      updatedBy: "Shivang Modi",
      updatedDateTime: "05/12/2018 18:36:28.763 GMT"
    }, { "tradingPartnerConnectionId": 127, "tradingPartnerInfoId": 215, "tradingPartnerInfoName": "D_TP_11Dec_1", "tradingPartnerPlatformInfoId": null, "tradingPartnerPlatformInfoName": null, "environmentId": 1, "environmentName": "QA", "deliveryMechanismTypeId": 1, "deliveryMechanismTypeName": "Client to upload files to Alight SFTP", "transferProtocolInfoId": 1, "transferProtocolInfoName": "SFTP", "tpciServerHost": null, "tpciServerPort": null, "tpciUsername": "user1", "tpciPassword": null, "tpciStoragePath": null, "tpciIsActive": false, "tradingPartnerContactInfoId": 177, "tradingPartnerContactInfoTitle": "Mr", "tradingPartnerContactInfoEmail": "external_12@yahoo.com", "message": null, "lastUpdatedDateTime": 1545295454790, "createdBy": "Ankur Aggarwal", "updatedBy": "Ankur Aggarwal", "lastUpdatedDate": "12/20/18 02:44 CT" }, { "tradingPartnerConnectionId": 128, "tradingPartnerInfoId": 214, "tradingPartnerInfoName": "CTP11Dec_2", "tradingPartnerPlatformInfoId": null, "tradingPartnerPlatformInfoName": null, "environmentId": 1, "environmentName": "QA", "deliveryMechanismTypeId": 1, "deliveryMechanismTypeName": "Client to upload files to Alight SFTP", "transferProtocolInfoId": 1, "transferProtocolInfoName": "SFTP", "tpciServerHost": null, "tpciServerPort": null, "tpciUsername": "user2", "tpciPassword": null, "tpciStoragePath": null, "tpciIsActive": true, "tradingPartnerContactInfoId": 178, "tradingPartnerContactInfoTitle": "Mr", "tradingPartnerContactInfoEmail": "external_12@yahoo.com", "message": null, "lastUpdatedDateTime": 1545295472893, "createdBy": "Ankur Aggarwal", "updatedBy": "Ankur Aggarwal", "lastUpdatedDate": "12/20/18 02:44 CT" }];
    component.createTPDropDown();
  });
  it("should on findRelativeKeyNames", () => {
    let e = { query: "employer" };
    component.findRelativeKeyNames(e);
  });

  it("should on createKeyMgmtlist", () => {
    component.tppList = [
      { "createdBy": "Jay Avatani", "createdDateTime": "28/12/2018 10:10:11.280 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "28/12/2018 10:10:11.280 GMT", "tradingPartnerPlatformId": 172, "tradingPartnerPlatformName": "111qa", "tradingPartnerPlatformDesc": "aa", "tradingPartnerInfo": { "createdBy": "Ankur Aggarwal", "createdDateTime": "18/10/2018 06:32:55.747 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "11/01/2019 08:32:11.047 GMT", "tradingPartnerId": 125, "tradingPartnerDescription": null, "tradingPartnerEmployerId": null, "tradingPartnerIsConsenting": true, "tradingPartnerName": "123test1", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "01/11/19 02:32 CT", "uniqueIdentifier": "A0398122-55CC-4C07-84DE-E982D50DCB66" }, "lastUpdatedDateTime": "12/28/18 04:10 CT", "uniqueIdentifier": "88A7F5C7-B338-406A-B611-A506D1D53A98", "active": true }, { "createdBy": "Nirmal Desai", "createdDateTime": "20/02/2019 06:38:44.570 GMT", "updatedBy": "Nirmal Desai", "updatedDateTime": "20/02/2019 06:39:18.943 GMT", "tradingPartnerPlatformId": 239, "tradingPartnerPlatformName": "123", "tradingPartnerPlatformDesc": null, "tradingPartnerInfo": { "createdBy": "Ankur Aggarwal", "createdDateTime": "18/10/2018 06:32:55.747 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "11/01/2019 08:32:11.047 GMT", "tradingPartnerId": 125, "tradingPartnerDescription": null, "tradingPartnerEmployerId": null, "tradingPartnerIsConsenting": true, "tradingPartnerName": "123test1", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "01/11/19 02:32 CT", "uniqueIdentifier": "A0398122-55CC-4C07-84DE-E982D50DCB66" }, "lastUpdatedDateTime": "02/20/19 00:39 CT", "uniqueIdentifier": "5345a915-f503-43f2-8806-3a21067cd554", "active": false }, { "createdBy": "Jay Avatani", "createdDateTime": "16/07/2018 07:31:56.177 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "16/10/2018 06:12:02.900 GMT", "tradingPartnerPlatformId": 20, "tradingPartnerPlatformName": "123test", "tradingPartnerPlatformDesc": "qa", "tradingPartnerInfo": { "createdBy": "Jay Avatani", "createdDateTime": "19/09/2018 11:03:33.643 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "19/09/2018 12:14:47.660 GMT", "tradingPartnerId": 72, "tradingPartnerDescription": "test123", "tradingPartnerEmployerId": null, "tradingPartnerIsConsenting": true, "tradingPartnerName": "ab", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "09/19/18 07:14 CT", "uniqueIdentifier": "31C8B5E0-984A-4B92-AA0B-D1E3851C1649" }, "lastUpdatedDateTime": "10/16/18 01:12 CT", "uniqueIdentifier": "9BAFCCF7-4140-42AB-B4B1-BBE203365F4A", "active": true }, { "createdBy": "Ankur Aggarwal", "createdDateTime": "18/01/2019 05:56:16.460 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "18/01/2019 05:56:16.460 GMT", "tradingPartnerPlatformId": 217, "tradingPartnerPlatformName": "18Jan_Trading partner platform", "tradingPartnerPlatformDesc": "18Jan_Trading partner platform for test", "tradingPartnerInfo": { "createdBy": "Ankur Aggarwal", "createdDateTime": "18/01/2019 05:55:46.113 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "21/01/2019 05:30:10.937 GMT", "tradingPartnerId": 267, "tradingPartnerDescription": "18Jan_Trading Partner for testc", "tradingPartnerEmployerId": null, "tradingPartnerIsConsenting": true, "tradingPartnerName": "18Jan_Trading Partner", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "01/20/19 23:30 CT", "uniqueIdentifier": "A052DC59-3865-4749-A991-14BB3249E6D4" }, "lastUpdatedDateTime": "01/17/19 23:56 CT", "uniqueIdentifier": "DFEA7874-2BD7-4853-92E5-0BF32547E23B", "active": true }, { "createdBy": "Ankur Aggarwal", "createdDateTime": "23/10/2018 10:07:41.077 GMT", "updatedBy": "Ankur Aggarwal", "updatedDateTime": "23/10/2018 10:07:41.077 GMT", "tradingPartnerPlatformId": 109, "tradingPartnerPlatformName": "23Oct_3", "tradingPartnerPlatformDesc": null, "tradingPartnerInfo": { "createdBy": "Jay Avatani", "createdDateTime": "17/10/2018 07:11:07.487 GMT", "updatedBy": "Jay Avatani", "updatedDateTime": "17/10/2018 07:11:07.487 GMT", "tradingPartnerId": 122, "tradingPartnerDescription": null, "tradingPartnerEmployerId": null, "tradingPartnerIsConsenting": true, "tradingPartnerName": "ACA EIN Trading Partner", "tradingPartnerType": "Dev", "active": true, "lastUpdatedDateTime": "10/17/18 02:11 CT", "uniqueIdentifier": "EED18623-0F79-49C1-8048-4152FAA47D7A" }, "lastUpdatedDateTime": "10/23/18 05:07 CT", "uniqueIdentifier": "9202435E-E745-4BD6-88D5-DC1D1A1776BA", "active": false }
    ];
    component.selectedKeyMgmtData = {
      "tradingPartnerAuthKeyId": 123,
      "direction": "inbound",
      "isActive": true,
      "keyName": "abc",
      "description": "abc",
      "tradingPartner": {
        "tradingPartnerId": 123
      },
      "uniqueIdentifier": 123,
      "tradingPartnerPlatform": null,
      "fileName": "abcd"
    };
    component.actionPannel = <OverlayPanel>{
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    component.editPlatform();
    // component.createKeyMgmtlist();
  });
  it("should on findRelativeKeyNames keyNames", () => {
    let e = { query: "537629" };
    component.keyNames = ["537629", "12QA"];
    component.findRelativeKeyNames(e);
  });
  it("should call addKeyMgmt() function", () => {
    component.dropDown = <any>{
      reset: () => null,
      toArray: () => [{ value: 1, filterValue: null }, { value: 2, filterValue: null }],
      value: [{ value: 1, filterValue: null }, { value: 2, filterValue: null }]
    };
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.keyValueFile = { nativeElement: { value: "" } };
    component.addKeyMgmt(validForm);

  });
  it("should call addKeyMgmt() res error", () => {
    component.dropDown = <any>{
      reset: () => null,
      toArray: () => [{ value: 1, filterValue: null }, { value: 2, filterValue: null }],
      value: [{ value: 1, filterValue: null }, { value: 2, filterValue: null }]
    };
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.keyValueFile = { nativeElement: { value: "" } };
    let addKeyMgment = fixture.debugElement.injector.get(TradingPartnerService);
    spyOn(addKeyMgment, "addKeyManagement").and.returnValue(Observable.of({ "error": true }));
    component.addKeyMgmt(validForm);
  });

  it("should call addKeyMgmt() error ", () => {
    component.dropDown = <any>{
      reset: () => null,
      toArray: () => [{ value: 1, filterValue: null }, { value: 2, filterValue: null }],
      value: [{ value: 1, filterValue: null }, { value: 2, filterValue: null }]
    };
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };

    let addKeyMgment = fixture.debugElement.injector.get(TradingPartnerService);
    spyOn(addKeyMgment, "addKeyManagement").and.returnValue(Observable.throw({"error" : {"error": true , "message": "error message"} }));
    component.addKeyMgmt(validForm);
  });


  it("should on setKeyId", () => {
    let _file = {};
    component.setKeyId(_file);
  });
  it("should on setKeyId() res error", () => {
    let _file = {};
    let getKeyId = fixture.debugElement.injector.get(TradingPartnerService);
    spyOn(getKeyId, "getKeyId").and.returnValue(Observable.of({ "error": true }));
    component.setKeyId(_file);
  });
  it("should on setKeyId() error", () => {
    let _file = {};
    let getKeyId = fixture.debugElement.injector.get(TradingPartnerService);
    spyOn(getKeyId, "getKeyId").and.returnValue(Observable.throw("error"));
    component.setKeyId(_file);
  });

  it("Should rowAction method", () => {
    const e = {};
    let overlayPanel = {
      toggle: (e) => {

      },
      hide: (el) => {

      }
    };
    let rowData = {};
    let selRowIndex = 0;
    const btnNextStep = document.createElement("button");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      // fixture.componentInstance.onClickNextStep(event);
      component.rowAction(event, overlayPanel, rowData);
    });
    btnNextStep.click();
    fixture.detectChanges();
    component.updateKeyName();
    component.keyMgmt.direction = "O";
    component.updateKeyName();
  });

  it("should on uploadKeyFile", () => {
    let e = {
      preventDefault: () => {

      },
      target: {
        files: [{ name: "test.text" }, { name: "test21.png" }]
      }
    };
    component.uploadKeyFile(e);
  });
  it("should on uploadKeyFile", () => {
    let e = {
      preventDefault: () => {

      },
      target: {
        files: []
      }
    };
    component.getFile(e);
  });
  it("should on downloadFile", () => {
    let overlayPanel = {
      toggle: (e) => {

      },
      hide: (el) => {

      }
    };
    component.downloadFile(overlayPanel);
  });
  it("should on actionName", () => {
    component.actionName();
  });

  it("should and displayToolTipText()", () => {
    component.toolTipPageFieldsData = {
      "File status": {
        "tooltipDesc": "File status description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "File status", "bottom");
      component.hideToolTipText(event);
      component.hideToolTipText(event);
    });
    btnNextStep.click();
  });

});

export class FakeToolTipUtilService {
  getPageAndFieldsDetails(adaptWebPageID): Observable<any> {
    let response = require("../../../../../assets/test-data/tooltip.json");
    return Observable.of(response);
  }
}

export class FakeConfirmationservice {
  accept() {
    return true;
  }
}

export class FakeTradingPartnerService {
  addTP(data): Observable<any> {
    let response = require("../../../../../assets/test-data/trading-partner-add.json");
    return Observable.of(response);
  }
  tradingPartnerPlatformListObserver(list): Observable<any> {
    let response = true;
    return Observable.of(response);
  }
  viewKeyManagement(): Observable<any> {
    let response = require("../../../../../assets/test-data/commons/TredingParner/keymngmt.json");
    return Observable.of(response);
  }
  addKeyManagement(): Observable<any> {
    let response = require("../../../../../assets/test-data/commons/TredingParner/keymngmt.json");
    return Observable.of(response);
  }
  downloadPublicKey(): Observable<any> {
    let response = true;
    return Observable.of(response);
  }
  getKeyId(): Observable<any> {
    let response = require("../../../../../assets/test-data/commons/TredingParner/keymngmt.json");
    return Observable.of(response);
  }
  tradingPartnerPlatformListObserver$: Observable<string> = new Subject<string>().asObservable();

  // tradingPartnerPlatformListObserver(currentRouter: string) {
  //   return Observable.of(['LR']);
  // }
}