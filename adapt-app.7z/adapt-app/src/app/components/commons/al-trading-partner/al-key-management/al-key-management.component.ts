import { Component, Input, OnInit, SimpleChange, OnDestroy, ViewChildren, QueryList, ViewChild } from "@angular/core";
import { TradingPartnerService } from "../al-tranding-partner-service/tranding-partner.service";
import { ToastsManager } from "ng2-toastr/src/toast-manager";
import { NgForm } from "@angular/forms";
import { Subscription } from "rxjs";
import { OverlayPanel } from "primeng/primeng";
import { NgxPermissionsService } from "ngx-permissions";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { TOAST_SETTING } from "../../../../global";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";

/**
 * ADAPT-219
 * Save, Update and View Auth Key Management
 *
 */

@Component({
  selector: "al-key-management",
  templateUrl: "./al-key-management.component.html"
})
export class AlKeyManagementComponent implements OnInit, OnDestroy {

  @Input() tradingParterList;
  isEdit: boolean = false;
  btnClicked: boolean = false;
  fileUploaded: boolean = false;
  keyMgmtList = [];
  tableDataLoading: boolean;
  tradingPartnerListSubscription: Subscription;

  /** Filters array or list */
  keyNameFilterArr: any = [{ label: "All", value: null }];
  trdPartnerFilterArr: any = [{ label: "All", value: null }];
  trdPartnerPlatformFilterArr: any = [{ label: "All", value: null }];
  directionFilterArr: any = [{ label: "All", value: null }, { label: "Inbound", value: "I" }, { label: "Outbound", value: "O" }];
  statusFilterArr: any = [{ label: "All", value: null },
  { label: "Active", value: true },
  { label: "Inactive", value: false }];

  /** Filters model */
  keyNameFilterArrModel;
  trdPartnerFilterArrModel;
  trdPartnerPlatformFilterArrModel;
  directionFilterArrModel;
  statusFilterArrModel;
  @ViewChild("keyValueFile") keyValueFile: any;

  /** Key management object / bean */
  keyMgmt = {
    tradingPartner: null,
    tradingPartnerPlatform: null,
    direction: "I",
    keyName: null,
    isActive: false,
    description: null,
    tradingPartnerAuthKeyId: null,
    uniqueIdentifier: null,
    fileName: null
  };

  keyMgmtTPPList: any = [];
  tppList: any = [];
  validationMsg: string;
  @ViewChildren("dropDown") dropDown: QueryList<Dropdown>;
  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  tooltipResult: any;
  pageID: number = 40;
  isUploadedFileIsValid = true;

  constructor(
    private tpService: TradingPartnerService,
    private toastr: ToastsManager,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService) {

    /**
     * Subscribed tradingPartnerListObserver to get list of trading partner platforms for trading partner platform component
     */

    this.tradingPartnerListSubscription = this.tpService.tradingPartnerPlatformListObserver$.subscribe((list) => {
      this.tppList = list["tpList"];
      this.createKeyMgmtlist();
    });
  }

  ngOnChanges(change: SimpleChange) {
    if (change["tradingParterList"].currentValue !== undefined) {
      this.createTPDropDown();
    }
    this.validationMsg = window["validationMsg"];
  }

  ngOnInit() {
    this.tableDataLoading = true;
    this.tppDefaultValue();
    this.viewKeyMgmt();
    this.getToolTipTextDetails();
  }

  ngOnDestroy() {
    this.tradingPartnerListSubscription.unsubscribe();
  }

  /**
   * To displaying data in **Trading Partner** drop down
   */
  createTPDropDown() {
    let _tpList = [];
    if (this.tradingParterList.length !== 0) {
      for (let obj of this.tradingParterList) {
        if (obj.active) {
          _tpList.push({
            "label": obj.tradingPartnerName,
            "value": obj.tradingPartnerId
          });
        }
      }
      this.tradingParterList = _tpList;
      this.tradingParterList.unshift({ label: "Select a Partner", valule: null });
    }
  }

  /**
   * Used type ahed feature for **Key Name** field
   * Once user start typing in **key Name** field then we are showing relative names if already save.
   * We are start searching after user entered minimum 3(three) characters
   */
  addedKeyNames: any = [];
  keyNames: any = [];
  findRelativeKeyNames(event) {
    if (event.query.length >= 3) {
      this.addedKeyNames = this.keyNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

  /** To save key management */
  addKeyMgmt(form: NgForm) {
    let ddArray = this.dropDown.toArray();
    ddArray.forEach((ele) => {
      ele.filterValue = null;
    });

    let keyMgmtObj = {
      tradingPartner: {
        tradingPartnerId: this.keyMgmt.tradingPartner
      },

      direction: this.keyMgmt.direction,
      keyName: this.keyMgmt.keyName,
      isActive: this.keyMgmt.isActive ? this.keyMgmt.isActive : false,
      description: this.keyMgmt.description,
      tradingPartnerAuthKeyId: this.keyMgmt.tradingPartnerAuthKeyId
    };

    if (this.keyMgmt.tradingPartnerPlatform) {
      keyMgmtObj["tradingPartnerPlatform"] = {
        tradingPartnerPlatformId: this.keyMgmt.tradingPartnerPlatform
      };
    }

    if (this.actionName() === "updated") {
      keyMgmtObj["uniqueIdentifier"] = this.keyMgmt.uniqueIdentifier;
    }

    keyMgmtObj["fileName"] = this.keyMgmt.fileName;
    const file = this.publicKeyFile;
    if (file) {
      keyMgmtObj["fileName"] = file.name;
    }

    let formData = new FormData();
    formData.append("file", file);
    formData.append("tradingPartnerAuthKeyInfo", JSON.stringify(keyMgmtObj));

    this.btnClicked = true;
    this.tpService.addKeyManagement(formData).subscribe(res => {
      this.btnClicked = false;
      if (!res.error) {
        form.resetForm({ directionGroup: "I" });
        this.keyValueFile.nativeElement.value = "";
        this.tppDefaultValue();
        this.keyMgmtList = res.data;
        this.isEdit = false;
        this.populateFilterDropDown();
        this.toastr.success("Key management " + this.actionName() + " successfully.", "Success!");
        this.keyMgmt.tradingPartnerAuthKeyId = null;
        this.keyMgmt.fileName = null;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      let errorMsg = error.error.message;
      if (errorMsg === "FILE_UPLOAD_ERROR") {
        this.toastr.error("Invalid File Upload!", "Oops!", TOAST_SETTING);
      } else {
        this.toastr.error("Server Error in adding key management.", "Oops!", TOAST_SETTING);
      }
      this.btnClicked = false;
    });
  }

  /** To fill values in view key management filters */
  populateFilterDropDown() {
    this.keyNames = [];
    this.keyNameFilterArr = [{ label: "All", value: null }];
    this.trdPartnerFilterArr = [{ label: "All", value: null }];
    this.trdPartnerPlatformFilterArr = [{ label: "All", value: null }];

    const _trdPartnerFilterArr: any = [];
    const _trdPartnerPlatformFilterArr: any = [];

    this.keyMgmtList.forEach((l) => {
      if (this.keyNameFilterArr.indexOf(l.keyName) === -1) {
        this.keyNameFilterArr.push({ label: l.keyName, value: l.keyName });
        this.keyNames.push(l.keyName);
      }

      if (_trdPartnerFilterArr.indexOf(l.tradingPartner.tradingPartnerName) === -1) {
        _trdPartnerFilterArr.push(l.tradingPartner.tradingPartnerName);
        this.trdPartnerFilterArr.push({ label: l.tradingPartner.tradingPartnerName, value: l.tradingPartner.tradingPartnerName });
      }

      if (l.tradingPartnerPlatform && _trdPartnerPlatformFilterArr.indexOf(l.tradingPartnerPlatform.tradingPartnerPlatformName) === -1) {
        _trdPartnerPlatformFilterArr.push(l.tradingPartnerPlatform.tradingPartnerPlatformName);
        this.trdPartnerPlatformFilterArr.push({ label: l.tradingPartnerPlatform.tradingPartnerPlatformName, value: l.tradingPartnerPlatform.tradingPartnerPlatformName });
      }
    });
  }

  actionPannel: OverlayPanel;
  selectedKeyMgmtData: any;
  rowAction(event, overlaypanel, rowData) {
    this.actionPannel = overlaypanel;
    this.actionPannel.toggle(event);
    this.selectedKeyMgmtData = rowData;
  }

  editPlatform() {
    this.actionPannel.hide();
    this.isEdit = true;
    this.keyMgmt.tradingPartnerAuthKeyId = this.selectedKeyMgmtData.tradingPartnerAuthKeyId;
    this.keyMgmt.direction = this.selectedKeyMgmtData.direction;
    this.keyMgmt.isActive = this.selectedKeyMgmtData.isActive;
    this.keyMgmt.keyName = this.selectedKeyMgmtData.keyName;
    this.keyMgmt.description = this.selectedKeyMgmtData.description;
    this.keyMgmt.tradingPartner = this.selectedKeyMgmtData.tradingPartner.tradingPartnerId;
    this.keyMgmt.uniqueIdentifier = this.selectedKeyMgmtData.uniqueIdentifier;
    this.keyMgmt.tradingPartnerPlatform = this.selectedKeyMgmtData.tradingPartnerPlatform ? this.selectedKeyMgmtData.tradingPartnerPlatform.tradingPartnerPlatformId : null;
    this.keyMgmt.fileName = this.selectedKeyMgmtData.fileName;
    this.createKeyMgmtlist();
    window.scrollTo(0, 0);
    this.fileUploaded = true;
    if (this.keyMgmt.direction === "O") {
      this.keyNameClass = "readOnlyField";
      this.keyNameStatus = true;
    } else {
      this.keyNameClass = "";
      this.keyNameStatus = false;
    }
  }

  viewKeyMgmt() {
    this.tpService.viewKeyManagement().subscribe(res => {
      if (!res.error) {
        this.keyMgmtList = res.data;
        this.tableDataLoading = false;
        this.populateFilterDropDown();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in adding key management.", "Oops!", TOAST_SETTING);
    });
  }

  /** To get action name based on primary key */
  actionName() {
    return this.keyMgmt.tradingPartnerAuthKeyId ? "updated" : "added";
  }

  /**
   * After selecting a Trading Partner we are displaying appropriate Trading partner platform
   * Trading Partner Platform should 'Active'
   */
  createKeyMgmtlist() {
    this.tppDefaultValue();
    for (const tpf of this.tppList) {
      if (tpf.tradingPartnerInfo.tradingPartnerId === this.keyMgmt.tradingPartner && tpf.active) {
        this.keyMgmtTPPList.push({ label: tpf.tradingPartnerPlatformName, value: tpf.tradingPartnerPlatformId });
      }
    }
  }

  /** Default value of **Trading Partner Platform** dropdown */
  tppDefaultValue() {
    this.keyMgmtTPPList = [];
    this.keyMgmtTPPList.unshift({ label: "Select a Partner Platform", value: null });
  }

  /** Downloading a public key file */
  downloadFile(actionItems) {
    actionItems.hide();
    this.tpService.downloadPublicKey(this.selectedKeyMgmtData);
  }

  publicKeyFile: any;
  uploadKeyFile(event) {
    let file = this.getFile(event);
    if ((file !== null) && (file !== undefined)) {
      this.publicKeyFile = file;
      this.setKeyId(file);
    }
  }

  setKeyId(file) {
    this.fileUploaded = false;
    this.keyMgmt.keyName = "";
    this.tpService.getKeyId(file).subscribe(res => {
      if (!res.error) {
        this.keyMgmt.keyName = res.data;
        this.fileUploaded = true;
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.keyMgmt.keyName = "";
        this.fileUploaded = false;
      }
    }, error => {
      this.toastr.error("Server Error in getting key id.", "Oops!", TOAST_SETTING);
      this.keyMgmt.keyName = "";
      this.fileUploaded = false;
    });
  }

  getFile(event) {
    event.preventDefault();
    let fileList = event.target.files;
    if (fileList.length > 0) {
      let file = fileList[0];
      let validFormats = ["asc"];
      let value = file.name, ext = value.substring(value.lastIndexOf(".") + 1).toLowerCase();
      if (validFormats.indexOf(ext) === -1) {
        this.toastr.error("Please upload the valid file format", "Error!", TOAST_SETTING);
        this.isUploadedFileIsValid = false;
        event.target.value = "";
      } else {
        this.isUploadedFileIsValid = true;
        return file;
      }
    }
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  keyNameClass: string;
  keyNameStatus: boolean;
  updateKeyName() {
    this.keyMgmt.keyName = "";
    if (this.keyMgmt.direction === "I") {
      this.keyNameClass = "";
      this.keyNameStatus = false;
    } else {
      this.keyNameClass = "readOnlyField";
      this.keyNameStatus = true;
    }
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }
}