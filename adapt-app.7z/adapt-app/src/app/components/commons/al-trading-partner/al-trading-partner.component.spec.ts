import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlTradingPartnerComponent } from "./al-trading-partner.component";
import { fakeActivatedRoute, randomString } from "../../../common-test/common";
import { NgxPermissionsService, NgxPermissionsStore, NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { TradingPartnerService } from "./al-tranding-partner-service/tranding-partner.service";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { DataTableModule, DialogModule, OverlayPanelModule, DropdownModule, ConfirmDialogModule, OverlayPanel } from "primeng/primeng";
import { ConfirmationService } from "primeng/components/common/api";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { DatePipe } from "@angular/common";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { CUSTOM_ELEMENTS_SCHEMA, TemplateRef } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Observer } from "rxjs/Observer";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { TradingPartnerConnectionInfo } from "./al-trading-partner-model/trading-partner-ftp-config.model";
import { By } from "@angular/platform-browser";
import { AlPopOverModule } from "../../../sharedModules/al-popover/al-popover.module";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlTradingPartnerComponent", () => {
  let component: AlTradingPartnerComponent;
  let fixture: ComponentFixture<AlTradingPartnerComponent>;
  let ngxPermission: NgxPermissionsService;
  let tradingService: TradingPartnerService, toastService: ToastsManager;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlTradingPartnerComponent, {
      set: {
        providers: [
          ConfirmationService,
          { provide: TradingPartnerService, useClass: FakeTradingPartnerService },
          { provide: ToolTipUtilService, useClass: FakeToolTipUtilService }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        ConfirmDialogModule,
        AlPopOverModule,
        HttpClientTestingModule
      ],
      declarations: [AlTradingPartnerComponent, AlCommonsModuleSidebar, AlSidebarComponent, NgxPermissionsAllowStubDirective],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        ToastsManager,
        ToastOptions,
        NgxPermissionsService,
        NgxPermissionsStore,
        OverlayPanel,
        TemplateRef,
        DatePipe,
        AppUtility,
        { provide: ConfirmationService, useClass: FakeTradingPartnerService },
        { provide: TradingPartnerService, useClass: FakeTradingPartnerService },
        { provide: ToolTipUtilService, useClass: FakeToolTipUtilService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    toastService = TestBed.get(ToastsManager);
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    ngxPermission = TestBed.get(NgxPermissionsService);
    ngxPermission.addPermission("Trading Partner-View All trading partners");
    ngxPermission.addPermission("accessDenied");
    ngxPermission.addPermission("Trading Partner-Add Trading Partner");
    ngxPermission.addPermission("Trading Partner-Edit Trading Partner");
    ngxPermission.addPermission("Connection-View All Connection");
    ngxPermission.addPermission("Connection-Add Connection");
    ngxPermission.addPermission("DeleteTradingPartner");
    ngxPermission.addPermission("ViewTradingPartners");
    fixture = TestBed.createComponent(AlTradingPartnerComponent);
    tradingService = fixture.debugElement.injector.get(TradingPartnerService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should onInit create", () => {
    component.ngOnInit();
  });


  it("should check permission error", () => {
    spyOn(ngxPermission, "hasPermission").and.returnValue(Observable.throw("false"));
    component.ngOnInit();
  });

  it("Should add trading partner", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = false;
    component.tpModel.tpName = "New_1";
    component.addTPData(formData);
  });

  it("Should not add trading partner with empty name", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = false;
    component.tpModel.tpName = " ";
    component.addTPData(formData);
  });

  it("Should not add trading partner witrh error", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = false;
    component.tpModel.tpName = "New_1";
    spyOn(tradingService, "addTP").and.returnValue(Observable.of({ error: "true" }));
    component.addTPData(formData);
  });

  it("Should not add trading partner", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = false;
    component.tpModel.tpName = "New_1";
    spyOn(tradingService, "addTP").and.returnValue(Observable.throw("No Data"));
    component.addTPData(formData);
  });

  it("Should edit trading partner", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tradingPartnerId: 0,
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = true;
    component.selectedTpData = {
      tradingPartnerId: 1
    };
    component.tpModel.tpName = "New_1";
    component.addTPData(formData);
  });

  it("Should not edit trading partner", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tradingPartnerId: 0,
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = true;
    component.selectedTpData = {
      tradingPartnerId: 1
    };
    component.tpModel.tpName = "New_1";
    spyOn(tradingService, "updateTP").and.returnValue(Observable.of({ error: "true" }));
    component.addTPData(formData);
  });

  it("Should not edit trading partner with error", () => {
    let formData = <NgForm>{
      value: {
        active: true,
        tradingPartnerDescription: "zxczxc",
        tradingPartnerName: "New_1",
        tradingPartnerId: 0,
        tpName: "Trading Partner"
      },
      resetForm: function (reset) {
      }
    };

    component.isEdit = true;
    component.selectedTpData = {
      tradingPartnerId: 1
    };
    component.tpModel.tpName = "New_1";
    spyOn(tradingService, "updateTP").and.returnValue(Observable.throw("No Data"));
    component.addTPData(formData);
  });
  it("Should Change active", () => {
    let $event = 1;
    component.ngOnInit();
    // component.changeActive($event);
  });

  it("should click rowdata fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
  });

  it("Should Change Delivery", () => {
    let mode = 1;
    component.ngOnInit();
    component.tpciFormGrp.addControl("tpciServerHost", component.tpciServerHost);
    component.tpciFormGrp.addControl("tpciServerPort", component.tpciServerPort);
    component.tpciFormGrp.addControl("tpciPassword", component.tpciPassword);
    component.changeDelivery(mode);
  });
  it("Should Change Delivery for FTP", () => {
    let mode = 3;
    component.ngOnInit();
    component.changeDelivery(mode);
  });
  it("Should Add Connection label", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: {
          "tradingPartnerContactEmail": "ajit.singh.8@alight.com"
        },
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.addFTPDetails(validFormData);
    fixture.detectChanges();
  });
  it("Should Add Connection", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: null,
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = true;
    component.addFTPDetails(validFormData);
    fixture.detectChanges();
  });
  it("Should Add Connection with platform", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: { "tradingPartnerPlatformId": 1 },
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = true;
    component.tpciModel.tradingPartnerPlatformInfo = {
      "tradingPartnerPlatformId": 1
    };
    component.addFTPDetails(validFormData);
  });
  it("Should Not Add Connection Response Error", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: null,
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = false;
    spyOn(tradingService, "addFTPConfiguration").and.returnValue(Observable.of({ error: "true" }));
    component.addFTPDetails(validFormData);
  });
  it("Should Not Add Connection Error", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: null,
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = false;
    spyOn(tradingService, "addFTPConfiguration").and.returnValue(Observable.throw("No Data"));
    component.addFTPDetails(validFormData);
  });
  it("Should edit Connection", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: null,
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = true;
    component.selectedRowId = 1;
    component.addFTPDetails(validFormData);
  });
  it("Should edit Connection on Error", () => {
    component.ngOnInit();
    component.d_value = 1;
    let validFormData = <NgForm>{
      value: {
        deliveryMechanismType: 1,
        tpciEmail: "ajit.singh.8@alight.com",
        tpciIsActive: true,
        tpciPassword: null,
        tpciServerHost: null,
        tpciServerPort: null,
        tpciUsername: "safsdfsdfs",
        tradingPartnerInfo: 1,
        tradingPartnerPlatformInfo: null,
        transferProtocolInfo: 1
      },
      resetForm: function (reset) {
      }
    };
    component.contacts = [{
      label: "value",
      value: "test"
    }];
    component._selected_contact = "test";
    component.isEditMode = true;
    component.selectedRowId = 1;
    spyOn(tradingService, "updateFTPConfiguration").and.returnValue(Observable.throw("No Data"));
    component.addFTPDetails(validFormData);
  });

  it("Should RowAtionFTP method", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
  });

  it("Should fill platform data with null", () => {
    component.ngOnInit();
    component.d_value = 1;
    component.fillPlatform(null, null, "view");
  });

  it("Should viewFTPInfo method 1", () => {
    const e = {};
    let overlayPanel = {
      toggle: (e) => {

      },
      hide: (el) => {

      }
    };
    let rowData = {};
    let selRowIndex = 0;
    const btnNextStep = document.createElement("button");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      // fixture.componentInstance.onClickNextStep(event);
      component.rowActionFTP(event, rowData, selRowIndex, overlayPanel);
    });
    btnNextStep.click();
    fixture.detectChanges();
    fixture.detectChanges();
  });

  it("Should fill platform data", () => {
    let tradingPartnerConnect = 1;
    let contactid = 12;
    component.ngOnInit();
    component.d_value = 1;
    component.fillPlatform(tradingPartnerConnect, contactid, "view");
  });

  it("should and displayToolTipText()", () => {
    component.toolTipPageFieldsData = {
      "Description": {
        "tooltipDesc": "Look up table name description",
        "readMoreLink": "http://www.google.com"
      }
    };
    fixture.detectChanges();

    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Description", "bottom");
      fixture.detectChanges();
      component.hideToolTipText(event);
      fixture.detectChanges();
      component.hideToolTipText(event);
    });
    btnNextStep.click();
    fixture.detectChanges();
  });
  it("should click editTradingPartner fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    component.editTradingPartner();
  });
  it("should and editFTPInfo()", () => {
    component.selectedPanel = {
      toggle: (e) => {
      },
      hide: (el) => {
      }
    };
    component.ftpList.SelectedRowData = {
      "tradingPartnerConnectionId": 127,
      "tradingPartnerInfo": {
        "createdBy": "Ankur Aggarwal",
        "createdDateTime": "11/12/2018 11:38:19.397 GMT",
        "updatedBy": "Ankur Aggarwal",
        "updatedDateTime": "11/12/2018 11:38:19.397 GMT",
        "tradingPartnerId": 215,
        "tradingPartnerDescription": null,
        "tradingPartnerEmployerId": null,
        "tradingPartnerIsConsenting": true,
        "tradingPartnerName": "D_TP_11Dec_1",
        "tradingPartnerType": "Dev",
        "active": true,
        "lastUpdatedDateTime": "12/11/18 05:38 CT"
      },
    };
    component.ftpList.SelectedRowData.tradingPartnerConnectionId = 127;
    component.tpciModel.deliveryMechanismType = 3;
    component.editFTPInfo("view");
  });
  it("should and editFTPInfo()", () => {
    component.selectedPanel = {
      toggle: (e) => {
      },
      hide: (el) => {
      }
    };
    component.ftpList.SelectedRowData = {
      "tradingPartnerConnectionId": 127,
      "tradingPartnerInfo": {
        "createdBy": "Ankur Aggarwal",
        "createdDateTime": "11/12/2018 11:38:19.397 GMT",
        "updatedBy": "Ankur Aggarwal",
        "updatedDateTime": "11/12/2018 11:38:19.397 GMT",
        "tradingPartnerId": 215,
        "tradingPartnerDescription": null,
        "tradingPartnerEmployerId": null,
        "tradingPartnerIsConsenting": true,
        "tradingPartnerName": "D_TP_11Dec_1",
        "tradingPartnerType": "Dev",
        "active": true,
        "lastUpdatedDateTime": "12/11/18 05:38 CT"
      },
    };
    component.ftpList.SelectedRowData.tradingPartnerConnectionId = 127;
    component.tpciModel.deliveryMechanismType = 3;
    component.editFTPInfo("view");
  });
  it("should and getDefaultValue() index 2", () => {
    const e = {
      index: 2
    };
    component.getDefaultValue(e);
  });
  it("should and handleChange() index 0", () => {
    const e = {
      index: 0
    };
    component.handleChange(e);
  });
  it("should and handleChange() index 2", () => {
    const e = {
      index: 2
    };
    component.handleChange(e);
  });
  it("search fn", () => {
    let event = {
      query: "jay.avatani@alight.com"
    };
    component.search(event);
  });

});

export class FakeToolTipUtilService {
  getPageAndFieldsDetails(adaptWebPageID): Observable<any> {
    let response = require("../../../../assets/test-data/tooltip.json");
    return Observable.of(response);
  }
}


export class FakeTradingPartnerService {
  addTP(data): Observable<any> {
    let response = require("../../../../assets/test-data/trading-partner-add.json");
    return Observable.of(response);
  }

  viewTP(): Observable<any> {
    let response = require("../../../../assets/test-data/trading-partner-details.json");
    return Observable.of(response);
  }

  getAllTradingPartnerPlatformByPartnerId(objPartner): Observable<any> {
    let response = require("../../../../assets/test-data/tradingpartnerplatforminfo.json");
    return Observable.of(response);
  }

  viewActiveTP(): Observable<any> {
    let response = require("../../../../assets/test-data/active_tp.json");
    return Observable.of(response);
  }
  getAllDeliveryMechanismType(): Observable<any> {
    let response = require("../../../../assets/test-data/delivery_mechanism_list.json");
    return Observable.of(response);
  }

  getAllEnvironmentInfo(): Observable<any> {
    let response = require("../../../../assets/test-data/environment_list.json");
    return Observable.of(response);
  }

  updateTP(data, id): Observable<any> {
    let response = require("../../../../assets/test-data/trading-partner-update.json");
    return Observable.of(response);
  }

  addFTPConfiguration(ftpConfigModel): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  // Change json path from here.
  deleteTradingPartner(tradingPartnerId): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  updateFTPConfiguration(ftpConfigModel): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  deleteFTPConfiguration(tradingPartnerFTPId): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  viewFTPDetails(): Observable<any> {
    let response = require("../../../../assets/test-data/alltradingpartnerconnectioninfo.json");
    return Observable.of(response);
  }

  isFTPExists(tpId): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  /* Trading Partner Platform */
  addTradingPartnerPlatform(data): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  updateTradingPartnerPlatform(data): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  viewTradingPartnerPlatform(): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  getPageAndFieldsDetails(adaptWebPageID): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  getAllTradingPartnerContactsByPartnerId(adaptWebPageID): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  getTradingPartnerConnectionInfoById(adaptWebPageID): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }

  getAllTransferProtocolInfo(): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  viewKeyManagement(): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  addKeyManagement(data): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
  getAllNotificationTemplates(): Observable<any> {
    let response = require("../../../../assets/test-data/ftp-add.json");
    return Observable.of(response);
  }
}