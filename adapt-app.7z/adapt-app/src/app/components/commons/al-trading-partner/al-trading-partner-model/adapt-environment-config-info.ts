export class AdaptEnvironmentConfigInfo {
    id: number;
    name: string;
    abbreviation: string;
    description: string;
}