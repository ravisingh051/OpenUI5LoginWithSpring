/**
 * This class is used fo create trading partner connection information.
 */

export class TradingPartnerConnectionInfo { tradingPartnerConnectionId: any = ""; tradingPartnerInfo: any = ""; tradingPartnerPlatformInfo: any = ""; tradingPartnerContactInfo: any = ""; deliveryMechanismType: any; environment: any; tpciServerHost: string = ""; tpciServerPort: number; tpciUsername: string = ""; tpciPassword: string = ""; tpciEmail: string; tpciIsActive: boolean = true; }