/**
 * This class is used for Trading partner connection information delivery mechanism type. It contains predefined values.
 */
export class DeliveryMechanismType {

    /**
     * Delivery mechanism type id
     */
    deliveryMechanismTypeId: number;
    /**
     * Delivery mechanism type name
     */
    fileDeliveryMechanismName: string;
    /**
     * Delivery mechanism type description
     */
    deliveryMechanismTypeDesc: string;

}