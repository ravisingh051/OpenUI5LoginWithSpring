/**
 * This class is used for transfer protocol type. Its used in trading partner connection information.
 */
export class TransferProtocolInfo {
    /**
     * Transfer protocol id
     */
    transferProtocolId: number;
    /**
     * Transfer protocol name
     */
    tranferProtocolName: string;
    /**
     * Transfer protocol description
     */
    transferProtocolDescription: string;

}