import { Component, OnInit, ViewChild, Input, ViewChildren, QueryList } from "@angular/core";
import { TradingPartnerService } from "./al-tranding-partner-service/tranding-partner.service";

import { NgForm, FormControl, FormGroup, Validators, FormArray } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { TradingPartnerConnectionInfo } from "./al-trading-partner-model/trading-partner-ftp-config.model";
import { CustomValidators } from "ng2-validation";
import { OverlayPanelModule, OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { IfObservable } from "rxjs/observable/IfObservable";
import { DatePipe } from "@angular/common";
import { Dropdown } from "primeng/components/dropdown/dropdown";
import { TOAST_SETTING } from "../../../global";


@Component({
  selector: "app-al-trading-partner",
  templateUrl: "./al-trading-partner.component.html",
  styleUrls: ["./al-trading-partner.component.scss"],
  providers: [TradingPartnerService, ConfirmationService, DatePipe]
})

export class AlTradingPartnerComponent implements OnInit {

  acceptLabel: string = "Yes";
  rejectLabel: string = "No";
  tpciModel: TradingPartnerConnectionInfo;
  tpciFormGrp: FormGroup;
  tradingPartnerInfo: FormControl;
  tradingPartnerPlatformInfo: FormControl;
  environment: FormControl;
  deliveryMechanismType: FormControl;
  tpciServerHost: FormControl;
  tpciServerPort: FormControl;
  tpciUsername: FormControl;
  tpciPassword: FormControl;
  tradingPartnerContactInfo: FormControl;
  tpciIsActive: FormControl;


  partners: any = [];
  partnerPlatforms: any = [];
  deliveryMechanismTypeList: any = [];
  contacts: any = [];
  environmentList: any = [];
  connectionTypes: any = [];

  // moveITCheckedOnly: boolean = true;

  ftpConfigList: any;
  selectedRowId: any;
  ftpList: any = {};

  isEditMode: boolean = false;
  isViewMode: boolean = false;

  tradingPartners: any;
  tpModel: any = {};
  tableDataLoading: boolean = true;
  ftpTableDataLoading: boolean = true;
  btnClicked: boolean = false;
  selectedPanel: any;
  selectedTPId: any;
  selectedTpData: any;
  selectedTPName: any;
  selectedTradingPartnerFTPId: any;
  tpList: any = {};
  msg: any;
  hasEditTPPermission: boolean = false;
  isTPActive: boolean = false;
  isEdit: boolean = false;
  selectedTab: number;

  p_value = 1;
  d_value = null;
  _selected_contact = "";

  /* Filter */
  filterTpName;
  filterTpNameModel;
  filterTpStatus;
  filterTpStatusModel;

  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  notificationTemplatesList: any = [];

  tooltipResult: any;
  pageID: number = 1;
  connections;
  types;
  protocols;
  validationMsg: string;
  @Input() filterTradingPartner;
  @Input() filterTradingPartnerPlatform;
  @ViewChildren("dropDown") dropDown: QueryList<Dropdown>;
  @ViewChild("dtTraPartnerBasic") dataTable: DataTable;

  // Filter trading partner connection table
  filterTPCName;
  filterTPCNameModel;

  filterTPCEnvironment;
  filterTPCEnvironmentModel;

  filterTPCDelivery;
  filterTPCDeliveryModel;

  filterTPCUsername;
  filterTPCUsernameModel;

  filterTPCEmail;
  filterTPCEmailModel;

  filterTPCLastUpdated;
  filterTPCLastUpdatedModel;

  filterTPCLastUpdatedBy;
  filterTPCLastUpdatedByModel;
  filterTPCStoragePath;
  filterTPCStoragePathModel;

  CENTRAL_TIMEZONE_ALIAS = " CT";

  constructor(
    private tpService: TradingPartnerService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService,
    private datePipe: DatePipe
  ) {
  }

  ngOnInit() {
    this.createTradingPartnerConnectionIfoControls();
    this.connections = [
      { name: "Inbound", code: "I" },
      { name: "Outbound", code: "O" },
      { name: "Both", code: "B" }
    ];

    this.protocols = ["FTP", "SFTP"];
    this.types = ["PGP", "SSH"];

    this.loadAllTradingPartners();
    this.loadAllDeliverMechanism();
    this.loadAllEnvironment();
    // this.connectionTypes = [
    //   { name: 'Production', value: 'P' },
    //   { name: 'Test', value: 'T' }
    // ];
    this.viewTPData();
    this.viewFTPDetails();
    this.getToolTipTextDetails();
    Promise.all([this.permissionsService.hasPermission("Trading Partner-Edit Trading Partner")])
      .then(([permission]) => {
        this.hasEditTPPermission = permission;
      }).catch(() => {
        this.hasEditTPPermission = false;
      });
    this.validationMsg = window["validationMsg"];
  }

  createTradingPartnerConnectionIfoControls() {
    this.contacts = [
      { label: "Select Contact Email", value: null }
    ];
    this.tpciModel = new TradingPartnerConnectionInfo();
    this.p_value = 1;
    this.d_value = null;

    this.tradingPartnerInfo = new FormControl("", Validators.required);
    this.tradingPartnerPlatformInfo = new FormControl("", Validators.nullValidator);
    this.environment = new FormControl("", Validators.required);
    this.deliveryMechanismType = new FormControl("", Validators.required);

    this.tpciServerHost = new FormControl("", Validators.required);
    this.tpciServerPort = new FormControl("", [Validators.required, CustomValidators.number, CustomValidators.min(2)]);
    this.tpciUsername = new FormControl("", Validators.required);
    this.tpciPassword = new FormControl("", [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/)]);

    this.tradingPartnerContactInfo = new FormControl("", Validators.required);

    this.tpciIsActive = new FormControl(true, Validators.nullValidator);

    this.tpciFormGrp = new FormGroup({
      tradingPartnerInfo: this.tradingPartnerInfo,
      tradingPartnerPlatformInfo: this.tradingPartnerPlatformInfo,
      environment: this.environment,
      deliveryMechanismType: this.deliveryMechanismType,
      tpciUsername: this.tpciUsername,
      // tpciPassword: this.tpciPassword,
      tradingPartnerContactInfo: this.tradingPartnerContactInfo,
      tpciIsActive: this.tpciIsActive
    });
  }

  newTpciModel: TradingPartnerConnectionInfo;

  addFTPDetails(ftpConfigForm) {
    let contact = this.contacts.find(cont => cont.value === this._selected_contact);
    let email = contact.label;

    let deliveryMechanismTypeName = this.deliveryMechanismTypeList[this.d_value - 1].fileDeliveryMechanismName;

    if (deliveryMechanismTypeName !== "Upload to Trading partner SFTP server") {
      this.confirmAddConnection(ftpConfigForm, email, contact);
    } else {
      this.addConnection(ftpConfigForm, contact);
    }
  }

  // show warning message
  confirmAddConnection(ftpConfigForm: NgForm, email: string, contact: any) {

    // get template names
    this.tpService.getAllNotificationTemplates().subscribe(res => {
      if (!res.error) {
        this.notificationTemplatesList = res.data;

        if (this.notificationTemplatesList.length > 0) {
          let templateNames = "";
          this.notificationTemplatesList.forEach((element) => {
            templateNames = templateNames.concat(element.templateName).concat(",");
          });
          templateNames = templateNames.replace(/,*$/, "");

          // show confirmation dialogue
          this.showDialogue(ftpConfigForm, email, templateNames, contact);
        } else {
          this.addConnection(ftpConfigForm, contact);
        }
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    });

  }


  showDialogue(ftpConfigForm: NgForm, email: string, templateNames: string, contact: any) {

    let cnfMessage = "A notification email will be sent to " + email + " using the " + templateNames + " informing the contact to setup a SFTP account. Do you want to proceed?";

    this.confirmationService.confirm({
      message: cnfMessage,
      accept: () => {
        this.addConnection(ftpConfigForm, contact);
      },
      reject: () => {
        return false;
      }
    });

  }
  addConnection(ftpConfigForm: NgForm, contact: any) {
    this.newTpciModel = null;

    this.btnClicked = true;

    this.tpciModel = ftpConfigForm.value;

    this.newTpciModel = this.tpciModel;

    this.newTpciModel.tradingPartnerInfo = {
      "tradingPartnerId": this.tpciModel.tradingPartnerInfo
    };

    if (this.newTpciModel.tradingPartnerPlatformInfo !== null) {
      this.newTpciModel.tradingPartnerPlatformInfo = {
        "tradingPartnerPlatformId": this.tpciModel.tradingPartnerPlatformInfo
      };
    } else {
      this.newTpciModel.tradingPartnerPlatformInfo = {};
    }

    this.newTpciModel.deliveryMechanismType = null;
    this.newTpciModel.deliveryMechanismType = {
      "deliveryMechanismTypeId": this.d_value
    };

    this.newTpciModel.environment = {
      "id": this.tpciModel.environment
    };

    this.newTpciModel.tradingPartnerContactInfo = {
      "tradingPartnerContactId": this._selected_contact,
      "tradingPartnerContactEmail": contact.label
    };

    let ddArray = this.dropDown.toArray();
    ddArray.forEach((ele) => {
      ele.filterValue = null;
    });

    if (this.isEditMode) {
      this.newTpciModel.tradingPartnerConnectionId = this.selectedRowId;

      this.tpService.updateFTPConfiguration(this.newTpciModel).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Trading Partner FTP Configuration Updated Successfully.", "Success!");
          this.isEditMode = false;

          this.tpciFormGrp.controls["tradingPartnerInfo"].enable();
          this.tpciFormGrp.controls["tradingPartnerPlatformInfo"].enable();

          this.createTradingPartnerConnectionIfoControls();
          ftpConfigForm.resetForm();
        } else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
        this.btnClicked = false;
        this.ftpConfigList = [];
        this.viewFTPDetails();
        document.body.scrollIntoView(true);

      }, error => {
        this.btnClicked = false;
        this.toastr.error("Server Error in adding Trading Partner FTP Configuration Details.", "Oops!", TOAST_SETTING);
      });
    }
    else {
      this.tpService.addFTPConfiguration(this.newTpciModel).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Trading Partner Connection Added Successfully.", "Success!");
          this.createTradingPartnerConnectionIfoControls();
          ftpConfigForm.resetForm();
          this.ftpConfigList = [];
          this.viewFTPDetails();
        } else {
          this.tpciModel.tradingPartnerInfo = this.tpciModel.tradingPartnerInfo.tradingPartnerId;
          if (this.tpciModel.tradingPartnerPlatformInfo !== {})
            this.tpciModel.tradingPartnerPlatformInfo = this.tpciModel.tradingPartnerPlatformInfo.tradingPartnerPlatformId;
          this.tpciModel.deliveryMechanismType = this.tpciModel.deliveryMechanismType.deliveryMechanismTypeId;
          this.tpciModel.environment = this.tpciModel.environment.id;
          this.tpciModel.tradingPartnerContactInfo = this.tpciModel.tradingPartnerContactInfo.tradingPartnerContactInfoId;
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
        this.btnClicked = false;
      }, error => {
        this.tpciModel.tradingPartnerInfo = this.tpciModel.tradingPartnerInfo.tradingPartnerId;
        if (this.tpciModel.tradingPartnerPlatformInfo !== {})
          this.tpciModel.tradingPartnerPlatformInfo = this.tpciModel.tradingPartnerPlatformInfo.tradingPartnerPlatformId;
        this.tpciModel.deliveryMechanismType = this.tpciModel.deliveryMechanismType.deliveryMechanismTypeId;
        this.tpciModel.environment = this.tpciModel.environment.id;
        this.tpciModel.tradingPartnerContactInfo = this.tpciModel.tradingPartnerContactInfo.tradingPartnerContactInfoId;
        this.toastr.error(error, "Oops!", TOAST_SETTING);
        this.btnClicked = false;
      });
    }
  }
  rowActionFTP(event, rowData, index, overlaypanel) {
    overlaypanel.toggle(event);
    this.ftpList.selectedRowEvent = event;
    this.selectedPanel = overlaypanel;
    this.selectedRowId = rowData.tradingPartnerFTPId;
    this.ftpList.SelectedRowData = rowData;
  }


  editFTPInfo(mode: string) {
    this.selectedPanel.toggle(this.ftpList.selectedRowEvent);
    let data = this.ftpList.SelectedRowData;
    this.isEditMode = true;
    this.tpService.getTradingPartnerConnectionInfoById(data.tradingPartnerConnectionId).subscribe(resp => {
      this.tpciModel = resp.data;
      this.d_value = data.deliveryMechanismTypeId;
      this.tpciModel.tradingPartnerInfo = data.tradingPartnerInfoId;

      if (data.tradingPartnerPlatformInfoId !== null) {
        this.filterTradingPartnerPlatform = [{ label: data.tradingPartnerPlatformInfoName, valule: data.tradingPartnerPlatformInfoId }];
        this.tpciModel.tradingPartnerPlatformInfo = data.tradingPartnerPlatformInfoId;
        this.getTPPEmail(this.tpciModel.tradingPartnerInfo, data.tradingPartnerContactInfoId, mode);
      } else {
        this.filterTradingPartnerPlatform = [];
        this.filterTradingPartnerPlatform.push({ label: "Select Trading Partner Platform", valule: null });
        this.getTPPEmail(this.tpciModel.tradingPartnerInfo, data.tradingPartnerContactInfoId, mode);
      }
      this.tpciModel.environment = data.environmentId;
      this.tpciModel.deliveryMechanismType = data.deliveryMechanismTypeId;

      if (this.tpciModel.deliveryMechanismType === 3) {
        this.tpciFormGrp.addControl("tpciServerHost", this.tpciServerHost);
        this.tpciFormGrp.addControl("tpciServerPort", this.tpciServerPort);
        this.tpciFormGrp.addControl("tpciPassword", this.tpciPassword);
      } else {
        if (this.tpciFormGrp.get("tpciServerHost") !== null)
          this.tpciFormGrp.removeControl("tpciServerHost");
        if (this.tpciFormGrp.get("tpciServerPort") !== null)
          this.tpciFormGrp.removeControl("tpciServerPort");
        if (this.tpciFormGrp.get("tpciPassword") !== null)
          this.tpciFormGrp.removeControl("tpciPassword");
      }
      this.tpciFormGrp.controls["tradingPartnerInfo"].disable();
      this.tpciFormGrp.controls["tradingPartnerPlatformInfo"].disable();
      if (this.tpciFormGrp.controls["tpciServerHost"] !== undefined) {
        this.tpciFormGrp.controls["tpciServerHost"].disable();
      }
      if (this.tpciFormGrp.controls["tpciServerPort"] !== undefined) {
        this.tpciFormGrp.controls["tpciServerPort"].disable();
      }
      if (this.tpciFormGrp.controls["tpciPassword"] !== undefined) {
        this.tpciFormGrp.controls["tpciPassword"].disable();
      }
      this.selectedPanel.hide();
      this.pupulateTPDropDown(data);
      window.scrollTo(0, 0);

    });
  }

  pupulateTPDropDown(tradingPartner) {
    let _tpDropDownList = [];
    _tpDropDownList.push({
      "label": tradingPartner.tradingPartnerInfoName,
      "value": tradingPartner.tradingPartnerInfoId
    });
    this.filterTradingPartner = _tpDropDownList;
  }

  deleteFTPInfo() {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this ftp configuration?",
      accept: () => {
        this.tpService.deleteFTPConfiguration(this.selectedRowId).subscribe(res => {
          if (!res.error) {
            this.toastr.success("Trading Partner FTP Configuration Deleted Successfully.", "Success!");
            this.ftpConfigList = [];
            this.viewFTPDetails();
          } else {
            this.toastr.error(res.message, "Oops!", TOAST_SETTING);
          }
        }, error => {
          this.toastr.error("Server Error in removing ftp configuration", "Oops!", TOAST_SETTING);
        });
      }
    });

  }

  viewFTPInfo() {
    this.editFTPInfo("view");
    this.isViewMode = true;
    this.tpciFormGrp.disable();
  }

  viewFTPDetails() {
    this.ftpTableDataLoading = true;
    this.tpService.viewFTPDetails().subscribe(res => {
      this.ftpConfigList = res.data;
      this.populateFilterDropDownForTPCInfoList();
      this.ftpTableDataLoading = false;
    });
  }

  populateFilterDropDownForTPCInfoList() {
    /**
     * Filter for trading partner name
     */
    this.filterTPCName = [{ label: "All", value: null }];
    let _filterTPCName: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCName.indexOf(this.ftpConfigList[i].tradingPartnerInfoName) === -1) {
          _filterTPCName.push(this.ftpConfigList[i].tradingPartnerInfoName);
        }
      };
    }
    for (let value of _filterTPCName) {
      this.filterTPCName.push({ label: value, value: value });
    }

    /**
     * Filter for Environment
     */
    this.filterTPCEnvironment = [{ label: "All", value: null }];
    let _filterTPCEnvironment: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCEnvironment.indexOf(this.ftpConfigList[i].environmentName) === -1) {
          _filterTPCEnvironment.push(this.ftpConfigList[i].environmentName);
        }
      };
    }
    for (let value of _filterTPCEnvironment) {
      this.filterTPCEnvironment.push({ label: value, value: value });
    }

    /**
    * Filter for Environment
    */
    this.filterTPCDelivery = [{ label: "All", value: null }];
    let _filterTPCDelivery: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCDelivery.indexOf(this.ftpConfigList[i].deliveryMechanismTypeName) === -1) {
          _filterTPCDelivery.push(this.ftpConfigList[i].deliveryMechanismTypeName);
        }
      };
    }
    for (let value of _filterTPCDelivery) {
      this.filterTPCDelivery.push({ label: value, value: value });
    }

    /**
    * Filter for Username
    */
    this.filterTPCUsername = [{ label: "All", value: null }];
    let _filterTPCUsername: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCUsername.indexOf(this.ftpConfigList[i].tpciUsername) === -1) {
          _filterTPCUsername.push(this.ftpConfigList[i].tpciUsername);
        }
      };
    }
    for (let value of _filterTPCUsername) {
      this.filterTPCUsername.push({ label: value, value: value });
    }

    /**
     * Filter for Email
     */
    this.filterTPCEmail = [{ label: "All", value: null }];
    let _filterTPCEmail: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCEmail.indexOf(this.ftpConfigList[i].tradingPartnerContactInfoEmail) === -1) {
          _filterTPCEmail.push(this.ftpConfigList[i].tradingPartnerContactInfoEmail);
        }
      };
    }
    for (let value of _filterTPCEmail) {
      this.filterTPCEmail.push({ label: value, value: value });
    }

    /**
     * Filter for Last Updated
     */
    this.filterTPCLastUpdated = [{ label: "All", value: null }];
    let _filterTPCLastUpdated: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCLastUpdated.indexOf(this.ftpConfigList[i].lastUpdatedDateTime) === -1) {
          _filterTPCLastUpdated.push(this.ftpConfigList[i].lastUpdatedDateTime);
          this.filterTPCLastUpdated.push({ label: this.ftpConfigList[i].lastUpdatedDate, value: this.ftpConfigList[i].lastUpdatedDateTime });
        }
      };
    }

    /**
     * Filter for Last Updated By
     */
    this.filterTPCLastUpdatedBy = [{ label: "All", value: null }];
    let _filterTPCLastUpdatedBy: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCLastUpdatedBy.indexOf(this.ftpConfigList[i].updatedBy) === -1) {
          _filterTPCLastUpdatedBy.push(this.ftpConfigList[i].updatedBy);
        }
      };
    }
    for (let value of _filterTPCLastUpdatedBy) {
      this.filterTPCLastUpdatedBy.push({ label: value, value: value });
    }

    /**
     * Filter for StoragePath
     */
    this.filterTPCStoragePath = [{ label: "All", value: null }];
    let _filterTPCStoragePath: any = [];
    if (this.ftpConfigList !== null) {
      for (let i = 0; i < this.ftpConfigList.length; i++) {
        if (_filterTPCStoragePath.indexOf(this.ftpConfigList[i].tpciStoragePath) === -1) {
          _filterTPCStoragePath.push(this.ftpConfigList[i].tpciStoragePath);
        }
      };
    }
    for (let value of _filterTPCStoragePath) {
      this.filterTPCStoragePath.push({ label: value, value: value });
    }
  }


  activeTPList: any = [];
  viewTPData() {
    this.tpNames = [];
    this.tableDataLoading = true;
    this.tpService.viewTP().subscribe(res => {
      this.tradingPartners = res.data;
      this.activeTPList = [];
      if (this.tradingPartners.length !== 0) {
        for (let obj of this.tradingPartners) {
          this.tpNames.push(obj.tradingPartnerName);
          if (obj.active) {
            this.activeTPList.push(obj);
          }
        }
      }
      this.populateFilterDropDown();
      this.tableDataLoading = false;
    });

  }


  rowAction(event, rowData, index, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.tpList.selectedRowEvent = event;
    this.selectedPanel = overlaypanel;
    this.selectedTpData = rowData;
    this.selectedTPId = rowData.tradingPartnerId;
    this.selectedTPName = rowData.tradingPartnerName;
  }
  addTPData(tpForm: NgForm) {
    this.btnClicked = true;
    let validValue = true;
    if (this.tpModel.tpName.trim(" ") === "") {
      validValue = false;
      this.tpModel.tpName = "";
    }
    if (validValue === false) {
      return false;
    }
    let tpData = {
      "tradingPartnerName": tpForm.value.tpName.trim(" "),
      "tradingPartnerDescription": tpForm.value.tpDesc,
      "tradingPartnerType": "Dev",
      "active": this.isTPActive,
      "tradingPartnerIsConsenting": true
    };
    if (this.isEdit) {
      tpData["tradingPartnerId"] = this.selectedTpData.tradingPartnerId;
      tpData["uniqueIdentifier"] = this.selectedTpData.uniqueIdentifier;
      this.updateTpData(tpData, tpForm, this.selectedTpData.tradingPartnerId);
      this.loadAllTradingPartners();
    }
    else {
      this.addTpData(tpData, tpForm);
      this.loadAllTradingPartners();
    }


  }

  addTpData(tpData, tpForm) {
    this.tpService.addTP(tpData).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Trading Partner Added Successfully.", "Success!");
        tpForm.resetForm();
        this.viewTPData();
        this.loadAllTradingPartners();
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.btnClicked = false;
    }, error => {
      this.toastr.error("Server Error in adding Trading Partner Details.", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
    });
  }

  updateTpData(tpData, tpForm, tpId) {
    this.tpService.updateTP(tpData, tpId).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Trading Partner Updated Successfully.", "Success!");
        tpForm.resetForm();
        this.dataTable.reset();
        this.viewTPData();
        this.loadAllTradingPartners();
        this.isEdit = false;
      }
      else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.btnClicked = false;
    }, error => {
      this.toastr.error("Server Error in adding Trading Partner Details.", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
    });
  }


  getDefaultValue(event) {
    this.tpModel.tpName = null;
    this.tpModel.tpDesc = null;
  }
  btnCancel() {
    this.router.navigate(["/commons"]);
  }

  editTradingPartner() {
    this.selectedPanel.hide();
    this.isEdit = true;
    this.tpModel.tpName = this.selectedTpData.tradingPartnerName;
    this.tpModel.tpDesc = this.selectedTpData.tradingPartnerDescription;
    this.isTPActive = this.selectedTpData.active;
    window.scrollTo(0, 0);
  }

  populateFilterDropDown() {
    this.filterTpName = [{ label: "All", value: null }];
    let _filterTpName: any = [];
    this.filterTpStatus = [
      { label: "All", value: null },
      { label: "Active", value: true },
      { label: "Inactive", value: false },
    ];

    if (this.tradingPartners !== null) {
      for (let i = 0; i < this.tradingPartners.length; i++) {

        if (_filterTpName.indexOf(this.tradingPartners[i].tradingPartnerName) === -1) {
          _filterTpName.push(this.tradingPartners[i].tradingPartnerName);
        }
      };
    }
    for (let value of _filterTpName) {
      this.filterTpName.push({ label: value, value: value });
    }
    this.filterTpNameModel = null;
    this.filterTpStatusModel = null;
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  loadContactList: boolean;
  handleChange(e) {
    let index = e.index;
    this.loadContactList = false;
    if (index === 0) {
      this.pageID = 1;
      this.getToolTipTextDetails();
    } else if (index === 2) {
      this.loadContactList = true;
    } else if (index === 3) {
      this.pageID = 39;
      this.getToolTipTextDetails();
    }
  }

  // CC-38451
  results: any = [];
  tpNames: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.tpNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

  loadAllTradingPartners() {
    this.tpService.viewActiveTP().subscribe(res => {
      this.partners = res.data;
      this.populateTPN();
    });
  }

  populateTPN() {
    let _tradingPartner = [];
    if (this.partners.length !== 0) {
      for (let obj of this.partners) {
        _tradingPartner.push({
          "label": obj.tradingPartnerName,
          "value": obj.tradingPartnerId
        });
      }
      this.filterTradingPartner = _tradingPartner;
      this.filterTradingPartner.unshift({ label: "Select a Partner", valule: null });
    }
  }

  loadAllDeliverMechanism() {
    this.tpService.getAllDeliveryMechanismType().subscribe(res => {
      this.deliveryMechanismTypeList = res.data;
    });
  }

  loadAllEnvironment() {
    this.tpService.getAllEnvironmentInfo().subscribe(res => {
      this.environmentList = res.data;
    });
  }

  fillPlatform(objPartner, contactid, mode: string) {
    // Loading all trading partner platform
    if (objPartner === undefined || objPartner === null || objPartner === "") {
      this.partnerPlatforms = [];
    } else {
      this.tpService.getAllTradingPartnerPlatformByPartnerId(objPartner).subscribe(res => {
        this.partnerPlatforms = res.data;
        this.filterTradingPartnerPlatform = [];
        if (this.partnerPlatforms.length > 0) {
          this.populateTPPlatform(mode);
        }
      });
    }

    // Loading all trading partner contacts

    this.getTPPEmail(objPartner, contactid, mode);
  }

  getTPPEmail(objPartner, contactid, mode: string) {

    if (objPartner === undefined || objPartner === null || objPartner === "") {
      this.contacts = [
        { label: "Select Contact Email", value: null }
      ];
    } else {
      this.tpService.getAllTradingPartnerContactsByPartnerId(objPartner).subscribe(res => {
        this.contacts = [
          { label: "Select Contact Email", value: null }
        ];
        let _cdata = res.data;
        for (let i = 0; i < _cdata.length; i++) {
          this.contacts.push(
            { label: _cdata[i].tradingPartnerContactEmail, value: _cdata[i].tradingPartnerContactId }
          );
        }

        if (contactid !== "") {
          this._selected_contact = contactid;
        }
      });
    }

  }

  populateTPPlatform(mode: string) {
    let _tradingPartnerPlatform = [];
    if (this.partnerPlatforms.length !== 0) {
      for (let obj of this.partnerPlatforms) {
        _tradingPartnerPlatform.push({
          "label": obj.tradingPartnerPlatformName,
          "value": obj.tradingPartnerPlatformId
        });
      }
      this.filterTradingPartnerPlatform = _tradingPartnerPlatform;
      if ("view" !== mode) {
        this.filterTradingPartnerPlatform.unshift({ label: "Select Trading Partner Platform", valule: null });
      }
    }
  }

  changeDelivery($event) {
    this.d_value = $event;
    this.tpciModel.deliveryMechanismType = $event;
    if ($event === 3) {
      this.tpciFormGrp.addControl("tpciServerHost", this.tpciServerHost);
      this.tpciFormGrp.addControl("tpciServerPort", this.tpciServerPort);
      this.tpciFormGrp.addControl("tpciPassword", this.tpciPassword);
    } else {
      if (this.tpciFormGrp.get("tpciServerHost") !== null)
        this.tpciFormGrp.removeControl("tpciServerHost");
      if (this.tpciFormGrp.get("tpciServerPort") !== null)
        this.tpciFormGrp.removeControl("tpciServerPort");
      if (this.tpciFormGrp.get("tpciPassword") !== null)
        this.tpciFormGrp.removeControl("tpciPassword");
    }
  }
}