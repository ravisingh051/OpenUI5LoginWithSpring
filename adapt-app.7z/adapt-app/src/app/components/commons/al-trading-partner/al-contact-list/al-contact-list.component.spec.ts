import { async, ComponentFixture, TestBed, tick, fakeAsync } from "@angular/core/testing";

import { AlContactListComponent } from "./al-contact-list.component";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, ConfirmDialogModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel, AutoCompleteModule, AutoComplete, ColorPicker } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { ContactListService } from "./al-contact-service/contact.service";
import { AlCommonsModuleSidebar } from "../../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../../sharedModules/al-popover/al-popover";
import { ConfirmationService } from "primeng/components/common/api";
import { TOKEN_NAME } from "../../../login/login.constant";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { By } from "@angular/platform-browser";
import { nextTick } from "q";
import { TemplateRef, DebugElement, ElementRef } from "@angular/core";
import { fakeActivatedRoute } from "../../../../common-test/common";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { AppUtility } from "../../../../sharedModules/al-popover/utility";
import { DataTable } from "primeng/components/datatable/datatable";
import { ApiEnvService } from "../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlContactListComponent", () => {
  let component: AlContactListComponent;
  let fixture: ComponentFixture<AlContactListComponent>;
  let ngxPermission;
  let toastService, _TrandingPartner, _tpcData, _rowData, _overlaypanel;
  let dt = <DataTable>{
    reset: () => null
  };
  beforeEach(async(() => {
    TestBed.overrideComponent(AlContactListComponent, {
      set: {
        providers: [
          { provide: ContactListService, useClass: FakeContactListService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        ConfirmDialogModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlContactListComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        AutoComplete,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        ApiEnvService,
        ConfirmationService,
        { provide: ToolTipUtilService, useClass: FakeToolTip },
        { provide: ContactListService, useClass: FakeContactListService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    });
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(AlContactListComponent);
      component = fixture.componentInstance;
      ngxPermission = TestBed.get(NgxPermissionsService);
      ngxPermission.addPermission("Contacts-View All Contacts");
      ngxPermission.addPermission("Contacts-Add new contact");
      ngxPermission.addPermission("Contacts-Edit contact");
      ngxPermission.addPermission("accessDenied");
      toastService = TestBed.get(ToastsManager);
      component.dataTable = dt;
      _TrandingPartner = [
        {
          "createdBy": "Ankur Aggarwal",
          "createdDateTime": "27/09/2018 12:18:14.107 GMT",
          "updatedBy": "Kamal Chhabra",
          "updatedDateTime": "18/01/2019 14:38:34.193 GMT",
          "tradingPartnerId": 91,
          "tradingPartnerDescription": "fh testings Testing",
          "tradingPartnerEmployerId": null,
          "tradingPartnerIsConsenting": true,
          "tradingPartnerName": "0 - Orac_1",
          "tradingPartnerType": "Dev",
          "active": true,
          "lastUpdatedDateTime": "01/18/19 08:38 CT",
          "uniqueIdentifier": "9F31509A-7C39-478B-B825-5091EC7E62C6"
        },
        {
          "createdBy": "Ankur Aggarwal",
          "createdDateTime": "18/01/2019 10:27:31.410 GMT",
          "updatedBy": "Karia Dipa",
          "updatedDateTime": "24/06/2019 06:43:36.330 GMT",
          "tradingPartnerId": 268,
          "tradingPartnerDescription": null,
          "tradingPartnerEmployerId": null,
          "tradingPartnerIsConsenting": true,
          "tradingPartnerName": "0 - Orac_1_testqa",
          "tradingPartnerType": "Dev",
          "active": true,
          "lastUpdatedDateTime": "06/24/19 01:43 CT",
          "uniqueIdentifier": "6755F29C-0B53-417E-B751-D804346042C8"
        }
      ];
      _tpcData = {
        contactType: "1",
        email: "dharam.mali@alight.com",
        ext: 17,
        firstName: "Dhara",
        isContactActiveModel: true,
        lastName: "Mali",
        phone: "8511712345",
        title: "SSE",
        trandingPartner: 91
      };
      _rowData = {
        "createdBy": "Jay Avatani",
        "createdDateTime": "09/07/2018 10:44:59.517 GMT",
        "updatedBy": "Shivang Modi",
        "updatedDateTime": "11/01/2019 13:37:23.857 GMT",
        "tradingPartnerContactId": 2,
        "tradingPartnerContactTitle": "J",
        "tradingPartnerContactFirstName": "auser",
        "tradingPartnerContactLastName": "buser",
        "tradingPartnerContactEmail": "user@july09.com",
        "tradingPartnerContactPhone": "+139482999200",
        "tradingPartnerContactPhoneExt": null,
        "active": true,
        "uniqueIdentifier": "6391B897-5EDD-4AD7-843F-343916285B5E",
        "tradingPartnerContactPlatformAssocs": [
          {
            "tradingPartnerContactTppAssocId": 406,
            "tradingPartnerPlatformId": {
              "createdBy": "Jay Avatani",
              "createdDateTime": "03/07/2018 05:58:17.830 GMT",
              "updatedBy": "Ankur Aggarwal",
              "updatedDateTime": "05/09/2018 06:59:11.157 GMT",
              "tradingPartnerPlatformId": 12,
              "tradingPartnerPlatformName": "vv",
              "tradingPartnerPlatformDesc": "vvf",
              "tradingPartnerInfo": {
                "createdBy": "Karia Dipa",
                "createdDateTime": "02/07/2018 10:18:39.527 GMT",
                "updatedBy": "Kamal Chhabra",
                "updatedDateTime": "13/02/2019 12:34:06.670 GMT",
                "tradingPartnerId": 1,
                "tradingPartnerDescription": "Brady Corp.",
                "tradingPartnerEmployerId": null,
                "tradingPartnerIsConsenting": true,
                "tradingPartnerName": "Brady Corp._Brad Corp.",
                "tradingPartnerType": "Dev",
                "active": true,
                "lastUpdatedDateTime": "02/13/19 06:34 CT",
                "uniqueIdentifier": "21737A07-335F-4832-8EFC-716683198B4D"
              },
              "lastUpdatedDateTime": "09/05/18 01:59 CT",
              "uniqueIdentifier": "3A7F2666-F796-4E51-B126-A5D776AE75BF",
              "active": true
            },
            "tradingPartnerId": {
              "createdBy": "Karia Dipa",
              "createdDateTime": "02/07/2018 10:18:39.527 GMT",
              "updatedBy": "Kamal Chhabra",
              "updatedDateTime": "13/02/2019 12:34:06.670 GMT",
              "tradingPartnerId": 1,
              "tradingPartnerDescription": "Brady Corp.",
              "tradingPartnerEmployerId": null,
              "tradingPartnerIsConsenting": true,
              "tradingPartnerName": "Brady Corp._Brad Corp.",
              "tradingPartnerType": "Dev",
              "active": true,
              "lastUpdatedDateTime": "02/13/19 06:34 CT",
              "uniqueIdentifier": "21737A07-335F-4832-8EFC-716683198B4D"
            },
            "active": true
          }
        ],
        "tradingPartnerContactTypeId": 1,
        "lastUpdatedDateTime": "01/11/19 07:37 CT",
        "tradingPartnerInfo": [
          {
            "tradingPartnerName": "Brady Corp._Brad Corp.",
            "tradingPartnerId": 1
          }
        ],
        "tradingPartnerContactTypeName": "Internal",
        "tradingPartner": [
          "Brady Corp._Brad Corp."
        ],
        "tpcontact": [
          "vv"
        ]
      };
      fixture.detectChanges();
    });
  }));

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("actionItem()", () => {
    let RowData = _rowData;
    let overlaypanel = {
      toggle: (e) => {
      },
      hide: () => {
      }
    };
    let e = {
      stopPropagation: (e) => {
      },
    };
    component.actionItem(e, RowData, 1, overlaypanel);
    _overlaypanel = component.overlaypanel;
  });

  it("updateTPList()", () => {
    component.updateTPList(2);
  });

  it("tradingPatnerChange()", () => {
    component.TrandingPartner = _TrandingPartner;
    component.tpcData = _tpcData;
    component.tradingPatnerChange();
  });

  it("tradingPatnerChange() error =>", () => {
    component.TrandingPartner = _TrandingPartner;
    component.tpcData = _tpcData;
    let populateTradingPartnerPlatform = fixture.debugElement.injector.get(ContactListService);
    spyOn(populateTradingPartnerPlatform, "populateTradingPartnerPlatform").and.returnValue(Observable.throw("error"));
    component.tradingPatnerChange();
  });

  it("search()", () => {
    let event = {
      query: "dharam.mali@alight.com"
    };
    component.search(event);
  });

  it("populateTradingPartnerByEmail() error =>", () => {
    let _email = "dharam.mali@alight.com";
    let populateTradingPartnerByEmail = fixture.debugElement.injector.get(ContactListService);
    spyOn(populateTradingPartnerByEmail, "populateTradingPartnerByEmail").and.returnValue(Observable.throw("error"));
    component.populateTPPEdit(_email);
  });



  it("Add Contact List", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcData = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    component.addContactList(contactListForm);
  });
  it("addTradingPartnerContact : Res Error", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcData = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    let addTradingPartnerContact = fixture.debugElement.injector.get(ContactListService);
    spyOn(addTradingPartnerContact, "addTradingPartnerContact").and.returnValue(Observable.of({ "error": true }));
    component.addContactList(contactListForm);
  });
  it("addTradingPartnerContact : Throw Error", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcData = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    let addTradingPartnerContact = fixture.debugElement.injector.get(ContactListService);
    spyOn(addTradingPartnerContact, "addTradingPartnerContact").and.returnValue(Observable.throw("error"));
    component.addContactList(contactListForm);
  });

  it("Change Edit()", () => {
    component.tpcDataEdit.trandingPartner = [{
      abc: "test"
    }];
    component.tpChangeEdit();
  });


  it("Edit Contact()", () => {
    component.overlaypanel = _overlaypanel;
    component.selTpcData = _rowData;
    component.editContact();
  });

  it("Edit Contact List", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcDataEdit = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    component.editContactList(contactListForm);
  });

  it("Edit Contact List : Validation Check", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    contactListForm.value.firstName = "";
    contactListForm.value.lastName = "";
    component.tpcDataEdit = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    component.editContactList(contactListForm);
  });


  it("Edit Contact List : updateTradingPartnerContact => res.error", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcDataEdit = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    let updateTradingPartnerContact = fixture.debugElement.injector.get(ContactListService);
    spyOn(updateTradingPartnerContact, "updateTradingPartnerContact").and.returnValue(Observable.of({ "error": true }));
    component.editContactList(contactListForm);
  });
  it("Edit Contact List : updateTradingPartnerContact => throw error", () => {
    let contactListForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.tpcDataEdit = contactListForm.value;
    component.TrandingPartner = _TrandingPartner;
    let updateTradingPartnerContact = fixture.debugElement.injector.get(ContactListService);
    spyOn(updateTradingPartnerContact, "updateTradingPartnerContact").and.returnValue(Observable.throw("error"));
    component.editContactList(contactListForm);
  });


  it("Close Edit Contact Dialog", () => {
    let editContactForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: _tpcData
    };
    component.editContactDialog = true;
    component.closeEditContactDialog(editContactForm);
  });

  it("should navigate", () => {
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.btnCancel();
    expect(navigateSpy).toHaveBeenCalledWith(["/commons"]);
  });

  it("should and displayToolTipText()", () => {
    component.toolTipContactText = {
      "Data elements": {
        "tooltipDesc": "Data elements description",
        "readMoreLink": "http://www.google.com"
      }
    };
    const btnNextStep = document.createElement("th");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "Data elements", "bottom");
    });
    component.hideToolTipText(event);
    btnNextStep.click();
  });



});

class FakeContactListService extends ContactListService {
  errorFlag: boolean = false;
  populateTradingPartner(): Observable<any> {
    let response = require("../../../../../assets/test-data/al-trading-partner-details.json");
    return Observable.of(response);
  }
  populateContactLob(): Observable<any> {
    let response = require("../../../../../assets/test-data/al-lob-details.json");
    return Observable.of(response);
  }
  TradingPartnerContactType(): Observable<any> {
    let response = require("../../../../../assets/test-data/al-trading-partner-contact-type.json");
    return Observable.of(response);
  }
  viewTradingPartnerContact(): Observable<any> {
    let response = require("../../../../../assets/test-data/al-trading-partner-contact.json");
    return Observable.of(response);
  }
  populateTradingPartnerPlatform(tradingPartnerIds) {
    let response = require("../../../../../assets/test-data/al-platform-tpid.json");
    return Observable.of(response);
  }
  updateTradingPartnerContact(data, id) {
    let response = require("../../../../../assets/test-data/al-update-trading-partner-contact.json");
    return Observable.of(response);
  }
  addTradingPartnerContact() {
    let response = require("../../../../../assets/test-data/al-add-contact.json");
    return Observable.of(response);
  }
  populateTradingPartnerByEmail() {
    let response = require("../../../../../assets/test-data/al-add-contact.json");
    return Observable.of(response);
  }
}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
