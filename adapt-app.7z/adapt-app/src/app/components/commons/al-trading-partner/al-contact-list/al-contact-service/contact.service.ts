import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../../shared_functions/services.function";
import { NgForm } from "@angular/forms/src/directives/ng_form";
import { ApiEnvService } from "../../../../../env.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class ContactListService {

    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }

    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/TradingPartnerContact";

    addTradingPartnerContact(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/add", data);
    }

    populateTradingPartner(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartner/details");
    }

    populateContactLob(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/Lob/details");
    }

    viewTradingPartnerContact(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/details");
    }

    updateTradingPartnerContact(data, id): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/update?tradingPartnerContactId=" + id, data);
    }
    populateTradingPartnerPlatform(tradingPartnerIds): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartner/getPlatformsByTPIds?tradingPartnerIds=" + tradingPartnerIds);
    }

    populateTradingPartnerByEmail(email): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/getTradingPartnerByEmail?email=" + email);
    }

    TradingPartnerContactType(): Observable<any> {
        return this.http.get(this.apiEnvEndpoint + "/TradingPartnerContactType/details");
    }

}
