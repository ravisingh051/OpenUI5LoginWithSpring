import { Component, OnInit, ViewEncapsulation, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { ContactListService } from "./al-contact-service/contact.service";
import { NgForm } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToolTipUtilService } from "../../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../../global";
import { Dropdown } from "primeng/components/dropdown/dropdown";

@Component({
  selector: "al-contact-list",
  templateUrl: "./al-contact-list.component.html",
  styleUrls: ["./al-contact-list.component.scss"],
  encapsulation: ViewEncapsulation.None,
  providers: [ContactListService, ToolTipUtilService]
})
export class AlContactListComponent implements OnInit {
  data: any;
  TrandingPartner: any[] = [];
  ContactLob: any[];
  tpcData: any = {};
  tableDataLoading: boolean = true;
  btnClicked: boolean = false;
  hasEditContactPermission: boolean = false;

  // For Data Table
  loading: boolean;
  cols: any[];
  tradingPartnerContact: any[];

  selectedContactType: any = "internal";
  isContactActiveModel: boolean = false;
  trandingPartnerPlatform: any[] = [];
  /* ToolTip display OnMouse Click */
  toolTipContactText: any = [];
  tooltipResult: any;
  pageID: number = 5;
  validationMsg: string;
  tPPlatformOnEdit: any[];
  /* Filters */
  filterContactType;
  filterContactTypeModel;
  filterFName;
  filterFNameModel;
  filterLName;
  filterLNameModel;
  filterTitle;
  filterTitleModel;
  filterEmail;
  filterEmailModel;
  filterConListTradingPartnerInfo;
  filterConListTradingPartnerInfoModel;
  filterTPContactPlatformAssocs;
  filterTPContactPlatformAssocsModel;
  filterStatus;
  filterStatusModel;
  @ViewChild("dt") dataTable: DataTable;
  constructor(
    private _contactList: ContactListService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService
  ) {
    this.loading = true;
    Promise.all([this.permissionsService.hasPermission("Contacts-Edit contact")])
      .then(([permission]) => {
        this.hasEditContactPermission = permission;
      }).catch(() => {
        this.hasEditContactPermission = false;
      });
  }

  TradingPartnerContactType: any = [];
  ngOnInit() {
    this._contactList.populateTradingPartner().subscribe(res => {
      for (let obj of res.data) {
        if (obj.active) {
          this.TrandingPartner.push(obj);
        }
      }
    });
    this._contactList.populateContactLob().subscribe(res => {
      this.ContactLob = res.data;
    });
    this._contactList.TradingPartnerContactType().subscribe(res => {
      this.TradingPartnerContactType = res.data;
    });
    this.viewTradingPartnerContact();
    this.getToolTipTextDetails();
    this.validationMsg = window["validationMsg"];
  }

  viewTradingPartnerContact() {
    this._contactList.viewTradingPartnerContact().subscribe(res => {
      this.tableDataLoading = true;
      for (let tpc of res.data) {
        tpc["tradingPartnerInfo"] = [];
        this.TradingPartnerContactType.filter((obj) => {
          if (obj.tradingPartnerContactTypeId === tpc["tradingPartnerContactTypeId"]) {
            tpc["tradingPartnerContactTypeName"] = obj.tradingPartnerContactTypeName;
          }
        });
        for (let tp of tpc.tradingPartnerContactPlatformAssocs) {
          let _check = tpc["tradingPartnerInfo"].filter((obj) => obj.tradingPartnerId === tp.tradingPartnerId.tradingPartnerId);
          if (_check.length === 0) {
            tpc["tradingPartnerInfo"].push({
              "tradingPartnerName": tp.tradingPartnerId.tradingPartnerName,
              "tradingPartnerId": tp.tradingPartnerId.tradingPartnerId
            });
          }
        }
      }
      for (let tpc of res.data) {
        tpc["tradingPartner"] = [];
        tpc["tpcontact"] = [];
        for (let tpData of tpc.tradingPartnerInfo) {
          tpc["tradingPartner"].push(tpData.tradingPartnerName);
        }
        for (let tpData of tpc.tradingPartnerContactPlatformAssocs) {
          if (tpData.tradingPartnerPlatformId) {
            tpc["tpcontact"].push(tpData.tradingPartnerPlatformId.tradingPartnerPlatformName);
          }
        }
      }
      this.tradingPartnerContact = res.data;
      // this.showContactsList = true;
      this.tableDataLoading = false;
      this.tpcData["contactType"] = "1";
      this.isContactType = 1;
      this.tpcData.trandingPartner = null;
      this.populateFilterDropDown();
    });

  }

  addContactList(contactListForm: NgForm) {
    this.btnClicked = true;
    let validValue = true;
    if (!this.isValidEmail(contactListForm.value.email)) {
      this.toastr.error("Email must have only alight.com domain", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
      return false;
    }
    if (this.tpcData.firstName.trim(" ") === "") {
      validValue = false;
      this.tpcData.firstName = "";
    }
    if (this.tpcData.lastName.trim(" ") === "") {
      validValue = false;
      this.tpcData.lastName = "";
    }
    if (validValue === false) {
      return false;
    }
    let tradingPartnerInfo = this.TrandingPartner.filter(tpInfo => tpInfo.tradingPartnerId === contactListForm.value.trandingPartner);
    let contactData = {
      "tradingPartnerContactTitle": contactListForm.value.title,
      "tradingPartnerContactFirstName": this.changeWordCase(contactListForm.value.firstName),
      "tradingPartnerContactLastName": this.changeWordCase(contactListForm.value.lastName),
      "tradingPartnerContactEmail": contactListForm.value.email,
      "tradingPartnerContactPhone": contactListForm.value.phone,
      "tradingPartnerContactPhoneExt": contactListForm.value.ext,
      "active": this.isContactActiveModel,
      "tradingPartnerContactTypeId": contactListForm.value.contactType,
      "tradingPartnerContactPlatformAssocs": []
    };
    // if(this.tpcData.tpPlatform){
    //   for (let i = 0; i < this.tpcData.tpPlatform.length; i++) {
    //     contactData["tradingPartnerContactPlatformAssocs"].push({
    //       "tradingPartnerPlatformId": {
    //         "tradingPartnerPlatformId": this.tpcData.tpPlatform[i]
    //       },
    //       "active": this.isContactActiveModel
    //     });
    //   }
    // }
    if (this.tpcData.trandingPartner) {
      for (let i = 0; i < this.tpcData.trandingPartner.length; i++) {
        contactData["tradingPartnerContactPlatformAssocs"].push({
          "tradingPartnerId": {
            "tradingPartnerId": this.tpcData.trandingPartner[i]
          },
          "tradingPartnerPlatformId": {
            "tradingPartnerPlatformId": this.tpcData.tpPlatform == null ? null : this.tpcData.tpPlatform[i] == null ? null : this.tpcData.tpPlatform[i]
          },
          "active": this.isContactActiveModel
        });
      }
    }
    this.tradingPartnerContact = [];
    this.tableDataLoading = true;
    this._contactList.addTradingPartnerContact(contactData).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Contact added successfully !", "Success!");
        contactListForm.resetForm({
          "contactType": "1"
        });
        this.trandingPartnerPlatform = [];
        this.tpcData.trandingPartner = null;
        this.viewTradingPartnerContact();
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
      this.btnClicked = false;
    }, error => {
      this.toastr.error("Server Error in adding Contact Details.", "Oops!", TOAST_SETTING);
      this.btnClicked = false;
    });
  }

  isValidEmail(email: string) {
    const beforeDomain = email.substring(0, email.toLowerCase().lastIndexOf("@alight.com"));
    return (email.length - 11) === beforeDomain.length ? true : false;
  }

  tradingPatnerChange() {
    this.trandingPartnerPlatform = [];
    if (this.tpcData.trandingPartner[0] !== null && this.tpcData.trandingPartner.length !== 0) {
      this._contactList.populateTradingPartnerPlatform(this.tpcData.trandingPartner).subscribe(res => {
        if (!res.error) {

          this.trandingPartnerPlatform = res.data;
        }
      }, error => {
        this.toastr.error("Server Error in getting data", "Oops!", TOAST_SETTING);
      });
    }
  }

  btnCancel() {
    this.router.navigate(["/commons"]);
  }

  isContactType: number;
  updateTPList(e) {
    this.isContactType = e;
    this.trandingPartnerPlatform = [];
    this.tpcData.trandingPartner = null;
    this.tpcData["contactType"] = e.toString();
  }

  overlaypanel: OverlayPanel;
  selIndex: number;
  actionItem(event, RowData, index, overlaypanel) {
    this.selIndex = index;
    this.overlaypanel = overlaypanel;
    this.overlaypanel.toggle(event);
    this.selTpcData = RowData;
  }

  tpChangeEdit() {
    this.tPPlatformOnEdit = [];
    if (this.tpcDataEdit.trandingPartner[0] !== null && this.tpcDataEdit.trandingPartner.length !== 0) {
      this._contactList.populateTradingPartnerPlatform(this.tpcDataEdit.trandingPartner).subscribe(res => {
        if (!res.error) {
          this.tPPlatformOnEdit = res.data;
        }
      }, error => {
        this.toastr.error("Server Error in getting data", "Oops!", TOAST_SETTING);
      });
    }
  }

  editContactDialog: boolean;
  tpcDataEdit: any = {};
  selTpcData: any = [];
  isContactActiveModelEdit: boolean;
  tPPlatformEdit: any = [];
  isContactTypeEdit: number;
  saveLoader: boolean = false;

  editContact() {
    this.overlaypanel.hide();
    this.editContactDialog = true;
    this.tpcDataEdit = {
      "contactType": this.selTpcData.tradingPartnerContactTypeId.toString(),
      "email": this.selTpcData.tradingPartnerContactEmail,
      "firstName": this.selTpcData.tradingPartnerContactFirstName,
      "lastName": this.selTpcData.tradingPartnerContactLastName,
      "title": this.selTpcData.tradingPartnerContactTitle,
      "phone": this.selTpcData.tradingPartnerContactPhone,
      "ext": this.selTpcData.tradingPartnerContactPhoneExt,
      "trandingPartner": []
    };
    this.isContactTypeEdit = this.selTpcData.tradingPartnerContactTypeId;
    for (let _tp of this.selTpcData.tradingPartnerInfo) {
      this.tpcDataEdit["trandingPartner"].push(_tp.tradingPartnerId.toString());
    }
    this.populateTPPEdit(this.tpcDataEdit["email"]);
    this.isContactActiveModelEdit = this.selTpcData.active;
  }

  populateTPPEdit(email) {
    this.tPPlatformEdit = [];
    this._contactList.populateTradingPartnerByEmail(email).subscribe(res => {
      if (!res.error) {
        this.tPPlatformEdit = res.data;
        this.tpChangeEdit();
        this.tpcDataEdit["tpPlatform"] = [];
        for (let tpPlatform of this.selTpcData.tradingPartnerContactPlatformAssocs) {
          if (tpPlatform.tradingPartnerPlatformId) {
            this.tpcDataEdit.tpPlatform.push(tpPlatform.tradingPartnerPlatformId.tradingPartnerPlatformId.toString());
          }
        }
        if (this.tpcDataEdit.tpPlatform.length === 0) {
          this.tpcDataEdit["tpPlatform"] == null;
        }
      }
    }, error => {
      this.toastr.error("Server Error in getting data", "Oops!", TOAST_SETTING);
    });
  }


  editContactList(editContactForm: NgForm) {
    let validValue = true;
    this.saveLoader = true;
    if (editContactForm.value.firstName.trim(" ") === "") {
      validValue = false;
      this.tpcData.firstName = "";
    }
    if (editContactForm.value.lastName.trim(" ") === "") {
      validValue = false;
      this.tpcData.lastName = "";
    }
    if (validValue === false) {
      this.saveLoader = false;
      return false;
    }
    let _tpcDataEdit = {
      "tradingPartnerContactId": this.selTpcData.tradingPartnerContactId,
      "tradingPartnerContactTitle": editContactForm.value.title,
      "tradingPartnerContactFirstName": this.changeWordCase(editContactForm.value.firstName),
      "tradingPartnerContactLastName": this.changeWordCase(editContactForm.value.lastName),
      "tradingPartnerContactEmail": editContactForm.value.email,
      "tradingPartnerContactPhone": editContactForm.value.phone,
      "tradingPartnerContactPhoneExt": editContactForm.value.ext,
      "active": this.isContactActiveModelEdit,
      "tradingPartnerContactTypeId": this.selTpcData.tradingPartnerContactTypeId,
      "uniqueIdentifier": this.selTpcData.uniqueIdentifier,
      "tradingPartnerContactPlatformAssocs": []
    };
    // if(this.tpcDataEdit.tpPlatform){
    //   for (let i = 0; i < this.tpcDataEdit.tpPlatform.length; i++) {
    //     _tpcDataEdit["tradingPartnerContactPlatformAssocs"].push({
    //       "tradingPartnerPlatformId": {
    //         "tradingPartnerPlatformId": this.tpcDataEdit.tpPlatform[i]
    //       },
    //       "active": this.isContactActiveModelEdit
    //     });
    //   }
    // }
    if (this.tpcDataEdit.trandingPartner) {
      for (let i = 0; i < this.tpcDataEdit.trandingPartner.length; i++) {
        _tpcDataEdit["tradingPartnerContactPlatformAssocs"].push({
          "tradingPartnerId": {
            "tradingPartnerId": this.tpcDataEdit.trandingPartner[i]
          },
          "tradingPartnerPlatformId": {
            "tradingPartnerPlatformId": this.tpcDataEdit.tpPlatform == null ? null : this.tpcDataEdit.tpPlatform[i] == null ? null : this.tpcDataEdit.tpPlatform[i]
          },
          "active": this.isContactActiveModel
        });
      }
    }

    this._contactList.updateTradingPartnerContact(_tpcDataEdit, this.selTpcData.tradingPartnerContactId).subscribe(res => {
      if (!res.error) {
        this.toastr.success("Contact Updated Successfully.", "Success!");
        this.editContactDialog = false;
        // this.showContactsList = false;
        for (let tpc of res.data) {
          tpc["tradingPartnerInfo"] = [];
          this.TradingPartnerContactType.filter((obj) => {
            if (obj.tradingPartnerContactTypeId === tpc["tradingPartnerContactTypeId"]) {
              tpc["tradingPartnerContactTypeName"] = obj.tradingPartnerContactTypeName;
            }
          });
          for (let tp of tpc.tradingPartnerContactPlatformAssocs) {
            let _check = tpc["tradingPartnerInfo"].filter((obj) => obj.tradingPartnerId === tp.tradingPartnerId.tradingPartnerId);
            if (_check.length === 0) {
              tpc["tradingPartnerInfo"].push({
                "tradingPartnerName": tp.tradingPartnerId.tradingPartnerName,
                "tradingPartnerId": tp.tradingPartnerId.tradingPartnerId
              });
            }
          }
        }
        for (let tpc of res.data) {
          tpc["tradingPartner"] = [];
          tpc["tpcontact"] = [];
          for (let tpData of tpc.tradingPartnerInfo) {
            tpc["tradingPartner"].push(tpData.tradingPartnerName);
          }
          for (let tpData of tpc.tradingPartnerContactPlatformAssocs) {
            if (tpData.tradingPartnerPlatformId) {
              tpc["tpcontact"].push(tpData.tradingPartnerPlatformId.tradingPartnerPlatformName);
            }
          }
        }
        this.tradingPartnerContact = res.data;
        // this.showContactsList = true;

        this.saveLoader = false;
        this.dataTable.reset();
        this.populateFilterDropDown();
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        this.saveLoader = false;
        this.editContactDialog = false;
      }
    }, error => {
      this.viewTradingPartnerContact();
      this.toastr.error("Server Error in Updating Contact Details.", "Oops!", TOAST_SETTING);
      this.saveLoader = false;
    });

  }

  closeEditContactDialog(editContactForm: NgForm) {
    editContactForm.resetForm();
    this.editContactDialog = false;
  }

  populateFilterDropDown() {
    this.tpcEmail = [];
    this.filterContactType = [{ label: "All", value: null }];
    let _filterContactType: any = [];
    this.filterFName = [{ label: "All", value: null }];
    let _filterFName: any = [];
    this.filterLName = [{ label: "All", value: null }];
    let _filterLName: any = [];
    this.filterTitle = [{ label: "All", value: null }];
    let _filterTitle: any = [];
    this.filterEmail = [{ label: "All", value: null }];
    let _filterEmail: any = [];
    this.filterConListTradingPartnerInfo = [{ label: "All", value: null }];
    let _filterConListTradingPartnerInfo: any = [];
    this.filterTPContactPlatformAssocs = [{ label: "All", value: null }];
    let _filterTPContactPlatformAssocs: any = [];
    this.filterStatus = [
      { label: "All", value: null },
      { label: "Active", value: true },
      { label: "Inactive", value: false },
    ];

    if (this.tradingPartnerContact !== null) {
      for (let i = 0; i < this.tradingPartnerContact.length; i++) {

        if (_filterContactType.indexOf(this.tradingPartnerContact[i].tradingPartnerContactTypeName) === -1) {
          _filterContactType.push(this.tradingPartnerContact[i].tradingPartnerContactTypeName);
        }
        if (_filterFName.indexOf(this.tradingPartnerContact[i].tradingPartnerContactFirstName) === -1) {
          _filterFName.push(this.tradingPartnerContact[i].tradingPartnerContactFirstName);
        }
        if (_filterLName.indexOf(this.tradingPartnerContact[i].tradingPartnerContactLastName) === -1) {
          _filterLName.push(this.tradingPartnerContact[i].tradingPartnerContactLastName);
        }
        if (this.tradingPartnerContact[i].tradingPartnerContactTitle !== null && _filterTitle.indexOf(this.tradingPartnerContact[i].tradingPartnerContactTitle) === -1) {
          _filterTitle.push(this.tradingPartnerContact[i].tradingPartnerContactTitle);
        }
        if (_filterEmail.indexOf(this.tradingPartnerContact[i].tradingPartnerContactEmail) === -1) {
          _filterEmail.push(this.tradingPartnerContact[i].tradingPartnerContactEmail);
        }
        for (let value of this.tradingPartnerContact[i].tradingPartnerInfo) {
          if (_filterConListTradingPartnerInfo.indexOf(value.tradingPartnerName) === -1) {
            _filterConListTradingPartnerInfo.push(value.tradingPartnerName);
          }
        }
        for (let value of this.tradingPartnerContact[i].tradingPartnerContactPlatformAssocs) {
          if (value.tradingPartnerPlatformId) {
            if (_filterTPContactPlatformAssocs.indexOf(value.tradingPartnerPlatformId.tradingPartnerPlatformName) === -1) {
              _filterTPContactPlatformAssocs.push(value.tradingPartnerPlatformId.tradingPartnerPlatformName);
            }
          }
        }
      };
    }
    for (let value of _filterContactType) {
      this.filterContactType.push({ label: value, value: value });
    }
    for (let value of _filterFName) {
      this.filterFName.push({ label: value, value: value });
    }
    for (let value of _filterLName) {
      this.filterLName.push({ label: value, value: value });
    }
    for (let value of _filterTitle) {
      this.filterTitle.push({ label: value, value: value });
    }
    for (let value of _filterEmail) {
      this.filterEmail.push({ label: value, value: value });
      this.tpcEmail.push(value);
    }
    for (let value of _filterConListTradingPartnerInfo) {
      this.filterConListTradingPartnerInfo.push({ label: value, value: value });
    }
    for (let value of _filterTPContactPlatformAssocs) {
      this.filterTPContactPlatformAssocs.push({ label: value, value: value });
    }
    this.resetFilters();
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipContactText = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};

  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipContactText[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // CC-38451
  results: any = [];
  tpcEmail: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.tpcEmail.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

  changeWordCase(word: string) {
    if (word) {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }
  }
  resetFilters() {
    this.filterContactTypeModel = null;
    this.filterFNameModel = null;
    this.filterLNameModel = null;
    this.filterTitleModel = null;
    this.filterEmailModel = null;
    this.filterConListTradingPartnerInfoModel = null;
    this.filterTPContactPlatformAssocsModel = null;
    this.filterStatusModel = null;
    this.dataTable.reset();
  }
}
