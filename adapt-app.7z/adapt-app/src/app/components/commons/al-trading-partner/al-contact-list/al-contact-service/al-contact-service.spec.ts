import {
    TestBed,
    getTestBed,
    async,
    inject
} from "@angular/core/testing";
import { ContactListService } from "./contact.service";
import { TOKEN_NAME } from "../../../../login/login.constant";
import { ApiEnvService } from "../../../../../env.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("Service: ContactListService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                ContactListService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });

    }));

    it("populateTradingPartner", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-get-all-templete.json");

        contactService.populateTradingPartner({}).subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("populateContactLob", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-fileType-detail.json");

        contactService.populateContactLob().subscribe((res) => {
            expect(res.data.length).toBe(16);
        });
    })));
    it("TradingPartnerContactType", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-fileType-detail.json");

        contactService.TradingPartnerContactType().subscribe((res) => {
            expect(res.data.length).toBe(16);
        });
    })));

    it("viewTradingPartnerContact", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-get-all-element.json");

        contactService.viewTradingPartnerContact().subscribe((res) => {
            expect(res.data.length).toBe(10);
        });
    })));

    it("populateTradingPartnerPlatform", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-detail.json");

        contactService.populateTradingPartnerPlatform().subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("updateTradingPartnerContact", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-detail.json");

        contactService.updateTradingPartnerContact({}, 10).subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));

    it("addTradingPartnerContact", async(inject([ContactListService], (contactService) => {
        let response = require("../../../../../../assets/test-data/notification-detail.json");

        contactService.addTradingPartnerContact([]).subscribe((res) => {
            expect(res.data.length).toBe(136);
        });
    })));
});