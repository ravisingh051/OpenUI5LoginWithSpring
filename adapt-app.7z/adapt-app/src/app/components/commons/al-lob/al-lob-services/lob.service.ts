import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../env.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class LobService {

  constructor(
    private http: HttpClient,
    private apiEnvService: ApiEnvService
  ) { }

  apiEnvEndpoint = this.apiEnvService.endpoint;
  serviceMappingURL = this.apiEnvEndpoint + "/Lob";

  addLOB(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/add", data);
  }
  viewLOB(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/details");
  }
  getLOBList(): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/details/list");
  }
  updateLOB(data): Observable<any> {
    return this.http.post(this.serviceMappingURL + "/update/lob", data);
  }

  deleteLOB(lobId): Observable<any> {
    return this.http.get(this.serviceMappingURL + "/delete?lobId=" + lobId)
      .map(extractData).catch(handleError);
  }

}
