import {
    TestBed,
    async,
    inject
} from "@angular/core/testing";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ApiEnvService } from "../../../../env.service";
import { LobService } from "./lob.service";

describe("Service: LobService", () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                LobService,
                ApiEnvService,
            ],
            imports: [
                HttpClientTestingModule
            ]
        });
    }));

    it("addLOB", async(inject([LobService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-templete.json");
        contactService.addLOB({}).subscribe((res) => {});
    })));

    it("viewLOB", async(inject([LobService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-fileType-detail.json");
        contactService.viewLOB().subscribe((res) => {});
    })));
    it("getLOBList", async(inject([LobService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-fileType-detail.json");
        contactService.getLOBList().subscribe((res) => {});
    })));

    it("updateLOB", async(inject([LobService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-get-all-element.json");
        contactService.updateLOB().subscribe((res) => {});
    })));

    it("deleteLOB", async(inject([LobService], (contactService) => {
        let response = require("../../../../../assets/test-data/notification-detail.json");
        contactService.deleteLOB().subscribe((res) => {});
    })));
});