import { Component, OnInit, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { LobService } from "./al-lob-services/lob.service";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { NgForm } from "@angular/forms";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../global";
import { Dropdown } from "primeng/components/dropdown/dropdown";

@Component({
  selector: "app-al-lob",
  templateUrl: "./al-lob.component.html",
  styleUrls: ["./al-lob.component.scss"],
  providers: [LobService, ConfirmationService, ToolTipUtilService]
})

export class AlLobComponent {
  model: any = {};
  selectedProfileData: any = {};
  tableDataLoading: boolean = true;
  btnClicked: boolean = false;
  selectedLobId: any;
  selectedLobName: any;
  selectedPanel: any;
  lobList: any = {};
  hasEditLOBPermission: boolean = false;
  isEdit: boolean = false;
  /* ToolTip display OnMouse Click */
  toolTipLOB: any = [];
  tooltipResult: any;
  pageID: number = 4;
  validationMsg: string;
  lobNameModel: any;
  statusModel: any;
  lastUpdatedDateTimeModel: any;
  updatedByModel: any;


  @ViewChild("dt") dataTable: DataTable;
  @ViewChildren("dropdown") dropDown: QueryList<Dropdown>;

  constructor(
    private lobservice: LobService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService
  ) {
    Promise.all([this.permissionsService.hasPermission("LOB-Edit LOB")])
      .then(([permission]) => {
        this.hasEditLOBPermission = permission;
      }).catch(() => {
        this.hasEditLOBPermission = false;
      });
  }

  ngOnInit() {
    this.getLOBList();
    this.getToolTipTextDetails();
    this.model.active = false;
    this.validationMsg = window["validationMsg"];
  }

  addLOB(lobForm: NgForm) {
    this.btnClicked = true;
    if (this.model.lobName.trim() === "") {
      this.toastr.error("Please enter valid value", "Oops!", TOAST_SETTING);
      this.model.lobName = "";
      return false;
    }
    if (this.model.lobName.length > 100) {
      this.toastr.error("LOB must not be greater than 100 characters!", "Oops!", TOAST_SETTING);
      return false;
    }

    if (this.model.lobDesc != null && this.model.lobDesc !== undefined && this.model.lobDesc.length > 200) {
      this.toastr.error("Description must not be greater than 200 characters!", "Oops!", TOAST_SETTING);
      return false;
    }
    let dropArr = this.dropDown.toArray();
    dropArr.forEach((ele) => {
      ele.filterValue = null;
      ele.value = null;
      ele.resetFilter();
    });
    if (!this.isEdit) {
      let data = {
        lobName: this.model.lobName.trim(),
        lobDescription: this.model.lobDesc,
        active: this.model.active
      };
      this.lobservice.addLOB(data).subscribe(res => {
        this.btnClicked = false;
        if (!res.error) {
          this.toastr.success("LOB Added Successfully.", "Success!");
          this.dataTable.reset();
          this.isEdit = false;
          lobForm.resetForm();
          this.getLOBList();
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
        this.btnClicked = false;
        this.model.active = false;
      }, error => {
        this.toastr.error("Server Error in adding LOB.", "Oops!", TOAST_SETTING);
        this.model.active = false;
      });
    } else {
      let data = {
        lobId: this.model.lobId,
        lobName: this.model.lobName,
        lobDescription: this.model.lobDesc,
        active: this.model.active,
        uniqueIdentifier: this.model.uniqueIdentifier
      };
      this.lobservice.updateLOB(data).subscribe(res => {
        this.btnClicked = false;
        if (!res.error) {
          this.dataTable.reset();
          this.model.updatedBy = res.data.updatedBy;
          this.model.lastUpdatedDateTime = res.data.lastUpdatedDateTime;
          this.isEdit = false;
          lobForm.resetForm();
          this.getLOBList();
          this.toastr.success("LOB Updated.", "Success!");
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in fetching LOB list.", "Oops!", TOAST_SETTING);
      });
    }
  }

  getLOBList() {
    this.tableDataLoading = true;
    this.lobservice.viewLOB().subscribe(res => {
      this.model.lobList = res.data;
      this.tableDataLoading = false;
      // this.populateFilterDropDown();
      this.populateFiltersDropDown();
    }, error => {
      this.toastr.error("Server Error in fetching LOB list.", "Oops!", TOAST_SETTING);
    });
  }

  // Filter Function : START
  filtersStatus: any = {};
  populateFiltersDropDown() {
    this.lobNames = [];
    let _lobFilter = {};
    if (this.model.lobList !== null) {
      _lobFilter["active"] = [];
      _lobFilter["lobName"] = [];
      _lobFilter["lastUpdatedDateTime"] = [];
      _lobFilter["updatedBy"] = [];
      this.filtersStatus.status = [
        { label: "All", value: null },
        { label: "Active", value: true },
        { label: "Inactive", value: false }
      ];
      for (let i = 0; i < this.model.lobList.length; i++) {
        if (_lobFilter["lobName"].indexOf(this.model.lobList[i].lobName) === -1) {
          _lobFilter["lobName"].push(this.model.lobList[i].lobName);
        }
        if (_lobFilter["lastUpdatedDateTime"].indexOf(this.model.lobList[i].lastUpdatedDateTime) === -1) {
          let temp = this.model.lobList[i].lastUpdatedDateTime.replace(/\s*[a-z]+/ig, "");
          this.model.lobList[i].updatedDateTime = new Date(temp).getTime();
          _lobFilter["lastUpdatedDateTime"].push({
            "date": this.model.lobList[i].lastUpdatedDateTime,
            "time": this.model.lobList[i].updatedDateTime
          });
        }
        if (_lobFilter["updatedBy"].indexOf(this.model.lobList[i].updatedBy) === -1) {
          _lobFilter["updatedBy"].push(this.model.lobList[i].updatedBy);
        }
      }
    }
    this.filtersStatus.lobName = [{ label: "All", value: null }];
    for (let value of _lobFilter["lobName"].sort((a, b) => a - b)) {
      this.filtersStatus.lobName.push({ label: value, value: value });
      this.lobNames.push(value);
    }

    this.filtersStatus.lastUpdatedDateTime = [{ label: "All", value: null }];
    for (let value of _lobFilter["lastUpdatedDateTime"].sort((a, b) => a - b)) {
      this.filtersStatus.lastUpdatedDateTime.push({ label: value.date, value: value.time });
    }

    this.filtersStatus.updatedBy = [{ label: "All", value: null }];
    for (let value of _lobFilter["updatedBy"].sort((a, b) => a - b)) {
      this.filtersStatus.updatedBy.push({ label: value, value: value });
    }
    this.resetFilters();
  }

  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipLOB = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipLOB[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink != null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // CC-38451
  results: any = [];
  lobNames: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.lobNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }

  rowAction(event, rowData, index, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.selectedPanel = overlaypanel;
    this.selectedProfileData = rowData;
  }

  editLob() {
    this.selectedPanel.hide();
    this.model.lobName = this.selectedProfileData.lobName;
    this.model.lobDesc = this.selectedProfileData.lobDescription;
    this.model.lobId = this.selectedProfileData.lobId;
    this.model.active = this.selectedProfileData.active;
    this.model.uniqueIdentifier = this.selectedProfileData.uniqueIdentifier;
    this.isEdit = true;
    window.scrollTo(0, 0);
  }
  btnCancel() {
    this.router.navigate(["/commons"]);
  }
  resetFilters() {
    this.lobNameModel = null;
    this.statusModel = null;
    this.lastUpdatedDateTimeModel = null;
    this.updatedByModel = null;
  }
}
