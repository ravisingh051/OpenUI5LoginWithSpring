import { async, ComponentFixture, TestBed, tick, fakeAsync } from "@angular/core/testing";

import { AlLobComponent } from "./al-lob.component";
import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { DataTableModule, ConfirmDialogModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel, AutoCompleteModule, AutoComplete } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { LobService } from "./al-lob-services/lob.service";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { ConfirmationService } from "primeng/components/common/api";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { By } from "@angular/platform-browser";
import { TemplateRef, DebugElement } from "@angular/core";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import { ApiEnvService } from "../../../env.service";
import {  HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlLobComponent", () => {
  let component: AlLobComponent;
  let fixture: ComponentFixture<AlLobComponent>;
  let ngxPermission;
  let heldFileService, toastService;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlLobComponent, {
      set: {
        providers: [
          { provide: LobService, useClass: FakeLobService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        ConfirmDialogModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DropdownModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlLobComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        AutoComplete,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        ApiEnvService,
        ConfirmationService,
        { provide: ToolTipUtilService, useClass: FakeToolTip },
        { provide: LobService, useClass: FakeLobService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlLobComponent);
    component = fixture.componentInstance;
    ngxPermission = TestBed.get(NgxPermissionsService);
    ngxPermission.addPermission(" Notification-View All templates ");
    ngxPermission.addPermission("accessDenied");
    component = fixture.componentInstance;
    toastService = TestBed.get(ToastsManager);
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should addLOB called", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "",
      "lobDesc": ""
    };
    component.addLOB(validForm);
  });
  it("should addLOB called length", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
      "lobDesc": ""
    };
    component.addLOB(validForm);
  });

  it("should addLOB called else", () => {
    // spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy"
    };
    component.isEdit = true;
    component.addLOB(validForm);
  });
  it("should addLOB called else error handle", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500sLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s"
    };
    component.isEdit = true;
    let lobService = fixture.debugElement.injector.get(LobService);
    spyOn(lobService, "updateLOB").and.returnValue(Observable.throw(" No Data"));
    component.addLOB(validForm);
  });
  it("updateLOB Res Error", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "Lorem Ipsum has been the industrys standard dummy text ever since the 1500s"
    };
    component.isEdit = true;
    let lobService = fixture.debugElement.injector.get(LobService);
    spyOn(lobService, "updateLOB").and.returnValue(Observable.of({ "error": true }));
    component.addLOB(validForm);
  });
  it("updateLOB Throw Error", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "Lorem Ipsum has been the industrys standard dummy text ever since the 1500s"
    };
    component.isEdit = true;
    let lobService = fixture.debugElement.injector.get(LobService);
    spyOn(lobService, "updateLOB").and.returnValue(Observable.throw("error"));
    component.addLOB(validForm);
  });

  it("should addLOB called if Cover & Res Error", async () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "The printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy"
    };
    component.isEdit = false;
    component.addLOB(validForm);
    let addLOB = fixture.debugElement.injector.get(LobService);
    spyOn(addLOB, "addLOB").and.returnValue(Observable.throw("error"));
    component.addLOB(validForm);
  });
  it("addLOB = 'error': true", async () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
      "lobDesc": "The printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy"
    };
    component.isEdit = false;
    let addLOB = fixture.debugElement.injector.get(LobService);
    spyOn(addLOB, "addLOB").and.returnValue(Observable.of({ "error": true }));
    component.addLOB(validForm);
  });

  it("should addLOB called if error handle", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        email: "",
        ext: null,
        firstName: "",
        isContactActiveModelEdit: false,
        lastName: "",
        phone: "+09283882992",
        title: null
      }
    };
    component.model = {
      "lobName": "",
      "lobDesc": ""
    };
    component.isEdit = false;
    let lobService = fixture.debugElement.injector.get(LobService);
    spyOn(lobService, "addLOB").and.returnValue(Observable.throw(" No Data"));
    component.addLOB(validForm);
  });

  it("should and displayToolTipText()", () => {
    let lobService = fixture.debugElement.injector.get(LobService);
    spyOn(lobService, "viewLOB").and.returnValue(Observable.throw(" No Data"));
    component.getLOBList();
  });

  it("should and displayToolTipText()", () => {
    component.toolTipLOB = {
      "LOB": {
        "tooltipDesc": "LOB description",
        "readMoreLink": "http://www.google.com"
      }
    };
    fixture.detectChanges();
    let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));


    const btnNextStep = document.createElement("a");
    document.body.appendChild(btnNextStep);
    btnNextStep.addEventListener("click", (event) => {
      component.displayToolTipText(event, "LOB", "bottom");
      fixture.detectChanges();
      component.hideToolTipText(event);
      fixture.detectChanges();
      component.hideToolTipText(event);
    });
    btnNextStep.click();
    fixture.detectChanges();
  });


  it("should click editLob fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    component.editLob();
  });

  it("should create btnCancel", () => {
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.btnCancel();
    expect(navigateSpy).toHaveBeenCalledWith(["/commons"]);
  });

  it("search fn", () => {
    let event = {
      query: "jay.avatani@alight.com"
    };
    component.search(event);
  });
  it("hideToolTipText fn", () => {
    let event = {
      query: "jay.avatani@alight.com"
    };
    component.hideToolTipText(event);
  });
});

class FakeLobService extends LobService {
  errorFlag: boolean = false;
  addLOB(data): Observable<any> {
    let response = require("../../../../assets/test-data/al-trading-partner-details.json");
    return Observable.of(response);
  }
  viewLOB(): Observable<any> {
    let response = require("../../../../assets/test-data/al-lob-details.json");
    return Observable.of(response);
  }
  getLOBList(): Observable<any> {
    let response = require("../../../../assets/test-data/al-trading-partner-contact-type.json");
    return Observable.of(response);
  }
  updateLOB(data): Observable<any> {
    let response = require("../../../../assets/test-data/al-trading-partner-contact.json");
    return Observable.of(response);
  }
  deleteLOB(tradingPartnerIds) {
    let response = require("../../../../assets/test-data/al-platform-tpid.json");
    return Observable.of(response);
  }
}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
