import { Component, OnInit, ViewChild } from "@angular/core";
import { DatePipe } from "@angular/common";
import { NgForm } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { CalendarModule } from "primeng/primeng";
import { InputSwitchModule } from "primeng/primeng";
import { Form } from "@angular/forms/src/directives/form_interface";
import { AlBlackoutWindowService } from "./al-blackout-window-service/al-blackout-window-service";
import { ConfirmationService } from "primeng/components/common/api";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { LoginService } from "../../login/login.service";
import { TOAST_SETTING } from "../../../global";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import * as moment from "moment-timezone";

@Component({
  selector: "app-al-blackout-window",
  templateUrl: "./al-blackout-window.component.html",
  styleUrls: ["./al-blackout-window.component.scss"],
  providers: [AlBlackoutWindowService, ConfirmationService]
})
export class AlBlackoutWindowComponent implements OnInit {
  blackoutCheck: boolean = true;
  fromDate: Date = new Date();
  toDate: Date = new Date();
  blackoutMessage: string;
  apbiId: number;
  formData: any = [];
  blackoutWindowList: any = [];
  blcMsgDays: number;

  advanceFilter: boolean = true;
  selectedPanel: any;
  selectedBlackoutWindow: any = {};
  isEdit: boolean = false;

  centralTimeZoneOffset: number = -6;
  aheadHours: number = 2;

  isValidStartDate: boolean = true;
  isValidEndDate: boolean = true;
  isConfigurable: boolean = true;

  oldStartDate: Date = null;
  oldEndDate: Date = null;
  oldActiveStatus: boolean = null;
  validationMsg: string;
  @ViewChild("dt") dataTable: DataTable;
  /* ToolTip display OnMouse Click */
  toolTipPageFieldsData: any = [];
  tooltipResult: any;
  pageID: number = 41;

  constructor(
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private blcWin: AlBlackoutWindowService,
    private confirmationService: ConfirmationService,
    private loginService: LoginService,
    private toolTipUtils: ToolTipUtilService
  ) { }

  ngOnInit() {

    this.fromDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, this.aheadHours, 5);
    this.toDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, this.aheadHours, 6);

    // Populate all blackout windows list
    this.getBlackoutWindowList();
    this.validationMsg = window["validationMsg"];
    this.getToolTipTextDetails();
  }

  // Populate list of all windows; active and inactive
  getBlackoutWindowList() {
    this.blcWin.getBlackoutWindowList().subscribe(res => {
      if (!res.error) {
        this.blackoutWindowList = res.data;
        this.populateFilterDropDown();
      } else {
        this.toastr.error(res.message, "Oops!", TOAST_SETTING);
      }
    }, error => {
      this.toastr.error("Server Error in fetching Blackout Window List.", "Oops!", TOAST_SETTING);
    });
  }

  // Add-Edit Blackout Window details
  addBlackoutWindow(fData: NgForm) {
    this.dataTable.reset();
    let isStartDateUpdated: boolean = null;
    let isEndDateUpdated: boolean = null;
    let isStatusUpdated: boolean = null;
    if (this.isEdit) {
      isStartDateUpdated = (this.fromDate.valueOf() / 1000 === this.oldStartDate.valueOf() / 1000) ? false : true;
      isEndDateUpdated = (this.toDate.valueOf() / 1000 === this.oldEndDate.valueOf() / 1000) ? false : true;
      isStatusUpdated = (this.blackoutCheck === this.oldActiveStatus) ? false : true;
    }




    // TODO - validate start date to be ahead of 2 hours from current date
    let validStartDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, this.aheadHours, 0);
    // let validEndDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset,this.aheadHours,1);
    let now = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, 0, 0);

    if (this.isConfigurable) {
      // if edit mode and start and end dates are not changed, don't perform validation
      // if edit mode and inactive window is activated, perform validation

      if (!this.isEdit || (this.isEdit && isStartDateUpdated || (now.valueOf() > this.oldEndDate.valueOf()) || (isStatusUpdated && this.blackoutCheck))) {
        if (this.fromDate.valueOf() < validStartDate.valueOf()) {
          this.isValidStartDate = false;
          this.isValidEndDate = true;
          return false;
        }
      }

      if (!this.isEdit || (this.isEdit && (isStartDateUpdated || isEndDateUpdated) || (now.valueOf() > this.oldEndDate.valueOf()) || (isStatusUpdated && this.blackoutCheck))) {
        if (this.toDate.valueOf() <= this.fromDate.valueOf()) {
          this.isValidEndDate = false;
          this.isValidStartDate = true;
          return false;
        }
      }
    }

    this.clearOldErrors();
    if (fData.value.isActiveModel === true) {
      this.confirmationService.confirm({
        message: "No files will be processed during Active blackout window. Are you sure you want to continue ?",
        accept: () => {
          this.saveBlackoutWindow(fData);
        }
      });
    } else {
      this.saveBlackoutWindow(fData);
    }
  }

  clearOldErrors() {
    this.isValidStartDate = true;
    this.isValidEndDate = true;
  }

  // On click of cancel navigate to commons page
  btnCancel() {
    this.router.navigate(["/commons"]);
  }

  saveBlackoutWindow(fData) {
    let userName = null;
    this.loginService.getProfileName.subscribe((value) => {
      userName = value;
    });

    if (!this.isEdit) {
      this.formData = {
        "startDateTime": this.convertDateFormat(this.fromDate),
        "endDateTime": this.convertDateFormat(this.toDate),
        "messagePriorDisplayDays": this.blcMsgDays,
        "description": this.blackoutMessage,
        "isEnabled": (this.blackoutCheck === null || this.blackoutCheck === undefined) ? false : this.blackoutCheck,
        "isUsedForDisplay": true,
        "createdBy": userName,
        "updatedBy": userName
      };


      this.blcWin.addBlackoutWindow(this.formData).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Blackout Window added successfully.", "Success!");
          this.resetForm(fData);
          this.getBlackoutWindowList();
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in adding Blackout Window.", "Oops!", TOAST_SETTING);
      });
    } else {
      this.formData = {
        "startDateTime": this.convertDateFormat(this.fromDate),
        "endDateTime": this.convertDateFormat(this.toDate),
        "messagePriorDisplayDays": this.blcMsgDays,
        "description": this.blackoutMessage,
        "isEnabled": (this.blackoutCheck === null || this.blackoutCheck === undefined) ? false : this.blackoutCheck,
        "apbiId": this.apbiId,
        "isUsedForDisplay": true,
        "updatedBy": userName
      };

      this.blcWin.updateBlackoutWindow(this.apbiId, this.formData).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Blackout Window updated successfully.", "Success!");
          this.resetForm(fData);
          this.getBlackoutWindowList();
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in updating Blackout Window.", "Oops!", TOAST_SETTING);
      });
    }

  }


  resetForm(fData) {
    // reset form
    fData.resetForm({ isActiveModel: true });

    // set date fields as initial
    this.fromDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, this.aheadHours, 5);
    this.toDate = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, this.aheadHours, 6);
    this.isEdit = false;
    this.isConfigurable = true;
  }

  // Filters
  filterBlackoutMessagePriorDays: any;
  filterStartDate: any;
  filterEndDate: any;
  filterLastUpdatedDate: any;
  filterLastUpdatedBy: any;


  // Filter models
  filterBlackoutMessagePriorDaysModel: any;
  filterStartDateModel: any;
  filterEndDateModel: any;
  filterLastUpdatedDateModel: any;
  filterLastUpdatedByModel: any;


  // populate filters
  populateFilterDropDown() {

    this.filterBlackoutMessagePriorDays = [{ label: "All", value: null }];
    this.filterStartDate = [{ label: "All", value: null }];
    this.filterEndDate = [{ label: "All", value: null }];
    this.filterLastUpdatedDate = [{ label: "All", value: null }];
    this.filterLastUpdatedBy = [{ label: "All", value: null }];

    let _filterBlackoutMessagePriorDays: any = [];
    let _filterStartDate = [];
    let _filterEndDate = [];
    let _filterLastUpdatedDate = [];
    let _filterLastUpdatedBy = [];

    if (this.blackoutWindowList !== null) {
      for (let i = 0; i < this.blackoutWindowList.length; i++) {

        let blackoutMessagePriorDays = this.blackoutWindowList[i].messagePriorDisplayDays;
        if ((blackoutMessagePriorDays != null) && (_filterBlackoutMessagePriorDays.indexOf(blackoutMessagePriorDays) === -1)) {
          _filterBlackoutMessagePriorDays.push(blackoutMessagePriorDays);
        }

        let fileBlackoutWindowStartDate = this.blackoutWindowList[i].startDateTime;
        if (_filterStartDate.indexOf(fileBlackoutWindowStartDate) === -1) {
          _filterStartDate.push(fileBlackoutWindowStartDate);
        }

        let fileBlackoutWindowEndDate = this.blackoutWindowList[i].endDateTime;
        if (_filterEndDate.indexOf(fileBlackoutWindowEndDate) === -1) {
          _filterEndDate.push(fileBlackoutWindowEndDate);
        }

        let lastUpdatedDateTime = this.blackoutWindowList[i].updatedDateTime;
        if (_filterLastUpdatedDate.indexOf(lastUpdatedDateTime) === -1) {
          _filterLastUpdatedDate.push(lastUpdatedDateTime);
        }

        let lastUpdatedBy = this.blackoutWindowList[i].updatedBy;
        if (_filterLastUpdatedBy.indexOf(lastUpdatedBy) === -1) {
          _filterLastUpdatedBy.push(lastUpdatedBy);
        }

      }

      for (let value of _filterStartDate) {
        this.filterStartDate.push({ label: value, value: value });
      }
      for (let value of _filterEndDate) {
        this.filterEndDate.push({ label: value, value: value });
      }
      for (let value of _filterBlackoutMessagePriorDays) {
        this.filterBlackoutMessagePriorDays.push({ label: value, value: value });
      }
      for (let value of _filterLastUpdatedDate) {
        this.filterLastUpdatedDate.push({ label: value + " CT", value: value });
      }
      for (let value of _filterLastUpdatedBy) {
        this.filterLastUpdatedBy.push({ label: value, value: value });
      }
    }
  }

  convertDateFormat(selectedDate) {
    let date = new Date(selectedDate);
    let formattedDate = [this.pad(date.getMonth() + 1), this.pad(date.getDate()), date.getFullYear()].join("/") + " " + [date.getHours(), date.getMinutes()].join(":") + " CT";
    return formattedDate;
  }

  pad(s) { return (s < 10) ? "0" + s : s; }


  rowAction(event, rowData, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.selectedPanel = overlaypanel;
    this.selectedBlackoutWindow = rowData;
  }

  editBlackoutWindow() {
    this.selectedPanel.hide();
    this.fromDate = new Date(this.selectedBlackoutWindow.startDateTime.replace("CST", "").replace("CDT", ""));
    this.toDate = new Date(this.selectedBlackoutWindow.endDateTime.replace("CST", "").replace("CDT", ""));
    this.blcMsgDays = this.selectedBlackoutWindow.messagePriorDisplayDays;
    this.blackoutMessage = this.selectedBlackoutWindow.description;
    this.blackoutCheck = this.selectedBlackoutWindow.isEnabled;
    this.apbiId = this.selectedBlackoutWindow.blackoutWindowId;

    // store dates and active status
    this.oldStartDate = new Date(this.fromDate);
    this.oldEndDate = new Date(this.toDate);
    this.oldActiveStatus = this.selectedBlackoutWindow.isEnabled;

    this.isEdit = true;
    window.scrollTo(0, 0);

    // check if window is editable - i.e. current time belongs to window configured duration
    let now = this.getValidCurrentDateForTimeZone(this.centralTimeZoneOffset, 0, 0);

    if ((now.valueOf() >= this.fromDate.valueOf()) && (now.valueOf() <= this.toDate.valueOf())) {
      this.isConfigurable = false;
    } else {
      this.isConfigurable = true;
    }
  }


  getCurrentDateForTimeZone(offset) {
    //  create Date object for current location
    let d = new Date();
    //  d.setSeconds(0);

    //  convert to msec
    //  add local time zone offset
    //  get UTC time in msec
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);

    //  create new Date object using supplied offset
    let convertedDate = new Date(utc + (3600000 * offset));

    //  return time
    return convertedDate;
  }

  getValidCurrentDateForTimeZone(offset, aheadHours, addMinutes) {
    let currentCentralDate = new Date(moment.tz("America/Chicago").format("MM/DD/YYYY HH:mm:ss"));
    currentCentralDate.setHours(currentCentralDate.getHours() + aheadHours);
    currentCentralDate.setMinutes(currentCentralDate.getMinutes() + addMinutes);
    return currentCentralDate;
  }
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipPageFieldsData = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipPageFieldsData[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }
}