import {
  TestBed,
  getTestBed,
  async,
  inject
} from "@angular/core/testing";
import { ApiEnvService } from "../../../../env.service";

import { AlBlackoutWindowService } from "./al-blackout-window-service";
import { HttpClientTestingModule } from "@angular/common/http/testing";


describe("AlBlackoutWindowService", () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AlBlackoutWindowService,
        ApiEnvService,
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

  });

  it("Component Service call Successfully Executed", inject([AlBlackoutWindowService], (service: AlBlackoutWindowService) => {
    expect(service).toBeTruthy();
  }));

  it("getBlackoutWindowList data in services", async(inject([AlBlackoutWindowService], (contactService) => {
    let response = require("../../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    // getServiceData(response);

    contactService.getBlackoutWindowList().subscribe((res) => {
      expect(res.data.length).toBe(136);
    });
  })));
  it("addBlackoutWindow data in services", async(inject([AlBlackoutWindowService], (contactService) => {
    let response = require("../../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    // getServiceData(response);

    contactService.addBlackoutWindow().subscribe((res) => {
      expect(res.data.length).toBe(136);
    });
  })));
  it("updateBlackoutWindow data in services", async(inject([AlBlackoutWindowService], (contactService) => {
    let response = require("../../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    // getServiceData(response);

    contactService.updateBlackoutWindow().subscribe((res) => {
      expect(res.data.length).toBe(136);
    });
  })));
});
