import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { NgForm } from "@angular/forms/src/directives/ng_form";
import { ApiEnvService } from "../../../../env.service";
import { AuthHttp } from "angular2-jwt";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlBlackoutWindowService {
    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }

    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/adapt/blackoutWindows";

    // To get list of all blackout windows
    getBlackoutWindowList(): Observable<any> {
        return this.http.get(this.serviceMappingURL)
            .map(extractData).catch(handleError);
    }

    // To configure blackout window
    addBlackoutWindow(data): Observable<any> {
        return this.http.post(this.serviceMappingURL, data)
            .map(extractData).catch(handleError);
    }

    // To update blackout window configuration
    updateBlackoutWindow(apbiId, data): Observable<any> {
        return this.http.put(this.serviceMappingURL + "/" + apbiId, data)
            .map(extractData).catch(handleError);
    }
}
