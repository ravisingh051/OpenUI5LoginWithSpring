import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlBlackoutWindowComponent } from "./al-blackout-window.component";

import { FormsModule, ReactiveFormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import { NgxPermissionsModule, NgxPermissionsService, USE_PERMISSIONS_STORE, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { CalendarModule, ConfirmDialogModule, DataTableModule, DialogModule, OverlayPanelModule, DropdownModule, OverlayPanel, AutoCompleteModule, AutoComplete } from "primeng/primeng";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";
import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlPopOverComponent } from "../../../sharedModules/al-popover/al-popover";
import { TOKEN_NAME } from "../../login/login.constant";
import { LoginService } from "../../login/login.service";
import { ConfirmationService } from "primeng/components/common/api";
import { ActivatedRoute } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { DatePipe } from "@angular/common";
import { By } from "@angular/platform-browser";
import { TemplateRef, DebugElement } from "@angular/core";
import { fakeActivatedRoute } from "../../../common-test/common";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { AlBlackoutWindowService } from "./al-blackout-window-service/al-blackout-window-service";
import { AppUtility } from "../../../sharedModules/al-popover/utility";
import * as moment from "moment-timezone";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("AlBlackoutWindowComponent", () => {
  let component: AlBlackoutWindowComponent;
  let fixture: ComponentFixture<AlBlackoutWindowComponent>;
  let toastService, alBlackoutWindowService;

  beforeEach(async(() => {

    TestBed.overrideComponent(AlBlackoutWindowComponent, {
      set: {
        providers: [
          { provide: AlBlackoutWindowService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxPermissionsModule.forRoot(),
        DataTableModule,
        ToastModule,
        DialogModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DropdownModule,
        CalendarModule,
        ConfirmDialogModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [AlBlackoutWindowComponent, AlCommonsModuleSidebar, AlSidebarComponent, AlPopOverComponent, NgxPermissionsAllowStubDirective],
      providers: [
        ToastsManager,
        AutoComplete,
        ToastOptions,
        OverlayPanel,
        TemplateRef,
        AppUtility,
        DatePipe,
        ConfirmationService,
        { provide: AlBlackoutWindowService, useClass: MockDataService },
        { provide: ToastsManager, useClass: MockDataService },
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        { provide: LoginService, useClass: FakeLoginService },
        { provide: Observable, useClass: "MockDataService" },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: USE_PERMISSIONS_STORE }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlBlackoutWindowComponent);
    component = fixture.componentInstance;
    toastService = TestBed.get(ToastsManager);
    alBlackoutWindowService = fixture.debugElement.injector.get(AlBlackoutWindowService);
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should oninit", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    moment.tz.setDefault("America/Chicago");
    component.ngOnInit();
  });
  it("should be oninit error handle", async(() => {
    spyOn(alBlackoutWindowService, "getBlackoutWindowList").and.returnValue(Observable.throw("No Data"));
    component.ngOnInit();
  }));

  it("should navigate", () => {
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.btnCancel();
    expect(navigateSpy).toHaveBeenCalledWith(["/commons"]);
  });

  it("should addBlackoutWindow", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: ""
      }
    };
    component.addBlackoutWindow(validForm);
  }));
  it("should isEdit true", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };

    component.isEdit = true;
    component.fromDate = new Date("02/15/2019 06:31 CST");
    component.oldStartDate = new Date("02/15/2019 06:31 CST");
    component.toDate = new Date("02/16/2019 08:46 CST");
    component.oldEndDate = new Date("02/16/2019 08:46 CST");
    component.addBlackoutWindow(validForm);
  }));
  it("should isEdit true if", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };

    component.isEdit = false;
    component.fromDate = new Date("02/15/2019 06:31 CST");
    component.oldStartDate = new Date("02/15/2019 06:31 CST");
    component.toDate = new Date("02/16/2019 08:46 CST");
    component.oldEndDate = new Date("02/16/2019 08:46 CST");
    component.addBlackoutWindow(validForm);
  }));
  it("should confirmationService Accept", async(() => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let confirmService = fixture.debugElement.injector.get(ConfirmationService);
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };
    spyOn(confirmService, "confirm").and.callFake((params: any) => {
      params.accept();
    });
    component.addBlackoutWindow(validForm);
  }));

  it("check Save of edited row valid form", () => {
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    fixture.detectChanges();
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
  });

  it("should saveBlackoutWindow function", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };
    component.isEdit = false;
    component.saveBlackoutWindow(validForm);
  });
  it("should saveBlackoutWindow function handle Error", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };
    spyOn(alBlackoutWindowService, "addBlackoutWindow").and.returnValue(Observable.throw("No Data"));
    component.saveBlackoutWindow(validForm);
  });

  it("should saveBlackoutWindow function Else edit true", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };
    component.isEdit = true;
    component.saveBlackoutWindow(validForm);
  });

  it("should saveBlackoutWindow function handle Error", () => {
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      valueOf: () => null,
      value: {
        startDateTime: "",
        endDateTime: "",
        messagePriorDisplayDays: null,
        description: false,
        isUsedForDisplay: "",
        isEnabled: false,
        prodProfileType: "",
        updatedBy: "",
        createdBy: "",
        valueOf: 123
      }
    };
    component.isEdit = true;
    spyOn(alBlackoutWindowService, "updateBlackoutWindow").and.returnValue(Observable.throw("No Data"));
    component.saveBlackoutWindow(validForm);
  });

});

export class FakeNgxPermission extends NgxPermissionsService {
}

class MockDataService {
  getBlackoutWindowList() {
    let response;
    response = require("../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    return (Observable.of(response));
  }
  addBlackoutWindow(Data) {
    let response;
    response = require("../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    return (Observable.of(response));
  }
  updateBlackoutWindow(id, Data) {
    let response;
    response = require("../../../../assets/test-data/commons/blackoutWindows/blackoutWindows.json");
    return (Observable.of(response));
  }
  error() {
    return true;
  }
  success() {
    return true;
  }
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
export class FakeLoginService {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  profileName: BehaviorSubject<string> = new BehaviorSubject<string>("User");
  displayName: BehaviorSubject<string> = new BehaviorSubject<string>("User");

  public get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  public get getProfileName(): Observable<string> {
    return this.profileName.asObservable();
  }

  public get getDisplayName(): Observable<string> {
    return this.displayName.asObservable();
  }
}
