import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-al-output-system-file",
  templateUrl: "./al-output-system-file.component.html",
  styleUrls: ["./al-output-system-file.component.scss"]
})
export class AlOutputSystemFileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
