import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { Routes } from "@angular/router";

import { AlOutputSystemFileComponent } from "./al-output-system-file.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

const routes: Routes = [
  {
    path: "dashboard",
    component: AlOutputSystemFileComponent
  },
  {
    path: "commons",
    component: AlOutputSystemFileComponent
  }
];

describe("AlOutputSystemFileComponent", () => {
  let component: AlOutputSystemFileComponent;
  let fixture: ComponentFixture<AlOutputSystemFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes(routes)],
      declarations: [ AlOutputSystemFileComponent, AlSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlOutputSystemFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
