import { TestBed, async, getTestBed, inject } from "@angular/core/testing";

import { TOKEN_NAME } from "../../../login/login.constant";
import { ApiEnvService } from "../../../../env.service";
import { ProfileService } from "./profile.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("ProfileService", () => {


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        ProfileService,
        ApiEnvService,
      ]
    });
  }));
  it("Component Service call Successfully Executed", inject([ProfileService], (service: ProfileService) => {
    expect(service).toBeTruthy();
  }));

  it("addProfile data in services", async(inject([ProfileService], (profileService) => {
    let response = require("../../../../../assets/test-data/al-add-contact.json");

    profileService.addProfile({}).subscribe((res) => {
      expect(res.data.length).toBe(158);
    });
  })));

  it("getPrfile data List from Services", async(inject([ProfileService], (profileService) => {
    let response = require("../../../../../assets/data/profileList.json");

    profileService.getProfiles({}).subscribe((res) => {
      expect(res.data.length).toBe(7);
    });
  })));

  it("update  Profile data Services", async(inject([ProfileService], (profileService) => {
    let response = require("../../../../../assets/data/profileList.json");

    profileService.updateProfile({}).subscribe((res) => {
      expect(res.data.length).toBe(7);
    });
  })));

  it("delete Profile data Services", async(inject([ProfileService], (profileService) => {
    let response = require("../../../../../assets/data/profileList.json");

    profileService.deleteProfile({}).subscribe((res) => {
      expect(res.data.length).toBe(7);
    });
  })));

});