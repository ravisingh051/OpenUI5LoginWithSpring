import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { extractData, handleError } from "../../../../shared_functions/services.function";
import { NgForm } from "@angular/forms/src/directives/ng_form";
import { AuthHttp } from "angular2-jwt";
import { ApiEnvService } from "../../../../env.service";
import { Observable } from "rxjs/Observable";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class ProfileService {
    constructor(
        private http: HttpClient,
        private apiEnvService: ApiEnvService
    ) { }

    apiEnvEndpoint = this.apiEnvService.endpoint;
    serviceMappingURL = this.apiEnvEndpoint + "/Profile";

    addProfile(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/add", data);
    }

    getProfiles(): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/details");
    }

    updateProfile(data): Observable<any> {
        return this.http.post(this.serviceMappingURL + "/update", data);
    }


    deleteProfile(ProfileId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/delete?profileId=" + ProfileId)
            .map(extractData).catch(handleError);
    }

    findAssociatedProfileWithJob(ProfileId): Observable<any> {
        return this.http.get(this.serviceMappingURL + "/associatedJob?profileId=" + ProfileId);
    }
}
