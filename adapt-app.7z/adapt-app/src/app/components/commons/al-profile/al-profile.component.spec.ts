import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { AutoCompleteModule, DropdownModule, OverlayPanelModule, DataTableModule, ConfirmationService } from "primeng/primeng";
import { NgxPermissionsModule, USE_PERMISSIONS_STORE, NgxPermissionsStore, NgxRolesService, USE_ROLES_STORE, NgxRolesStore } from "ngx-permissions";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ToastModule, ToastsManager, ToastOptions } from "ng2-toastr";

import { NgxPermissionsService, NgxPermissionsAllowStubDirective } from "ngx-permissions";
import { ProfileService } from "./al-profile-service/profile.service";

import { AlCommonsModuleSidebar } from "../al-sidebar/al-sidebar.component";
import { AlSidebarComponent } from "../../al-sidebar/al-sidebar.component";
import { AlProfileComponent } from "./al-profile.component";
import { TOKEN_NAME } from "../../login/login.constant";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { By } from "@angular/platform-browser";
import { Button } from "protractor";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { Routes } from "@angular/router";
import { HttpClientTestingModule } from "@angular/common/http/testing";

const routes: Routes = [
  {
    path: "dashboard",
    component: AlProfileComponent
  },
  {
    path: "commons",
    component: AlProfileComponent
  }
];

describe("AlProfileComponent", () => {
  let component: AlProfileComponent;
  let fixture: ComponentFixture<AlProfileComponent>;
  let overlaypanel: OverlayPanel;
  let ngxPermission;
  let toastService, profileService;

  beforeEach(async(() => {
    TestBed.overrideComponent(AlProfileComponent, {
      set: {
        providers: [
          { provide: ProfileService, useClass: MockDataService },
          { provide: ConfirmationService, useClass: MockDataService },
          { provide: ToastsManager, useClass: MockDataService },
          { provide: ToastOptions, useClass: MockDataService },
          { provide: Observable, useClass: MockDataService },
          { provide: ToolTipUtilService, useClass: FakeToolTip }
        ]
      }
    });
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes(routes),
        FormsModule,
        DropdownModule,
        AutoCompleteModule,
        OverlayPanelModule,
        DataTableModule,
        NgxPermissionsModule,
        ToastModule,
        HttpClientTestingModule
      ],
      declarations: [AlProfileComponent, AlSidebarComponent, AlCommonsModuleSidebar, NgxPermissionsAllowStubDirective],
      providers: [
        NgxPermissionsService,
        NgxPermissionsStore,
        NgxRolesService,
        NgxRolesStore,
        ToastsManager,
        { provide: USE_PERMISSIONS_STORE, useValue: {} },
        { provide: USE_ROLES_STORE, useValue: {} },
        { provide: ProfileService, useClass: MockDataService },
        { provide: ConfirmationService, useClass: MockDataService },
        { provide: NgxPermissionsService, useClass: FakeNgxPermission },
        { provide: ToastOptions, useClass: MockDataService },
        { provide: Observable, useClass: MockDataService },
        { provide: ToolTipUtilService, useClass: MockDataService },

      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    ngxPermission = TestBed.get(NgxPermissionsService);
    fixture = TestBed.createComponent(AlProfileComponent);
    component = fixture.componentInstance;
    ngxPermission.addPermission("Profiles-View All Profiles");
    ngxPermission.addPermission("Profiles-Add Profile");
    ngxPermission.addPermission("EditTradingPartner");
    ngxPermission.addPermission("accessDenied");
    ngxPermission.addPermission("Profiles-Edit Profile");
    toastService = TestBed.get(ToastsManager);
    profileService = fixture.debugElement.injector.get(ProfileService);
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
    fixture.detectChanges();
  });

  it("should be profile data Add", () => {
    component.addProfileData(void 0);
    component.profileModel.profileName = "";
    component.profileModel.profileName = null;
    component.profileModel.profileName = undefined;

    fixture.detectChanges();

    component.addProfileData(void 0);
  });

  it("should create profile data get and set", () => {
    component.viewProfileData();
    let navigateSpy = spyOn((<any>component).router, "navigate");
    component.btnCancel();
    expect(navigateSpy).toHaveBeenCalledWith(["/commons"]);
  });

  it("add contact invalid form", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let invalidForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        profileName: "",
        updatedBy: "",
        profileDesc: null,
        forProduction: false,
        fileDirection: "",
        active: false,
        prodProfileType: ""
      }
    };
    component.profileModel.profileName = "";
    // Error Block coverage
    let profileService = fixture.debugElement.injector.get(ProfileService);
    component.addProfileData(invalidForm);
    spyOn(profileService, "addProfile").and.returnValue(Observable.throw(" No Data"));
    component.addProfileData(invalidForm);
    fixture.detectChanges();
  });

  it("add contact invalid form if part", () => {
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        profileName: "CVT Profile Test1",
        updatedBy: "Ankur Aggarwal",
        profileDesc: null,
        forProduction: false,
        fileDirection: "I",
        active: false,
        prodProfileType: "Non-Production"
      }
    };
    component.profileModel.fileDirection = null;
    component.profileModel.fileDirection = undefined;
    component.profileModel.fileDirection = "";
    // Error Block coverage
    let profileService = fixture.debugElement.injector.get(ProfileService);
    spyOn(profileService, "addProfile").and.returnValue(Observable.throw(" No Data"));
    component.addProfileData(validForm);
    fixture.detectChanges();
  });

  it("check Save of edited row valid form", () => {
    spyOn(toastService, "success").and.returnValue(Promise.resolve());
    fixture.detectChanges();
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let validForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        profileName: "CVT Profile Test1",
        updatedBy: "Ankur Aggarwal",
        profileDesc: null,
        forProduction: false,
        fileDirection: "I",
        active: false,
        prodProfileType: "Non-Production"
      }
    };
    component.isEdit = false;
    component.addProfileData(validForm);
  });

  it("check Save of edited row invalid form", () => {
    fixture.detectChanges();
    spyOn(toastService, "error").and.returnValue(Promise.resolve());
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    expect(fixture.debugElement.query(By.css("form"))).toBeDefined();
    let invalidForm = <NgForm>{
      reset: () => null,
      resetForm: () => null,
      value: {
        profileName: "",
        updatedBy: "",
        profileDesc: "",
        forProduction: false,
        fileDirection: "",
        active: false,
        prodProfileType: ""
      }
    };
    component.addProfileData(invalidForm);
    component.isEdit = false;
    // Error block coverage
    spyOn(profileService, "updateProfile").and.returnValue(Observable.throw("No Data"));
    component.addProfileData(invalidForm);
    fixture.detectChanges();
  });

  it("should be get tooltip tex detail", async(() => {
    component.profiles;
    component.getToolTipTextDetails();
  }));

  it("should click rowdata fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
  });

  it("should close the edit popup fn", () => {
    let ellipseButton = fixture.debugElement.query(By.css("[icon=\"fa-ellipsis-v\"]"));
    ellipseButton.nativeElement.click();
    let editContactButton = fixture.debugElement.query(By.css("p-overlayPanel")).query(By.css("a"));
    editContactButton.nativeElement.click();
    let formButton = fixture.debugElement.query(By.css("form")).queryAll(By.css("button"));
    formButton[0].nativeElement.click();
  });


  it("should be edit profile method", async(() => {
    let rowData = {
      createdBy: "Chris Van Treese",
      createdDateTime: "30/10/2018 04:48:38.003 GMT", updatedBy: "Ankur Aggarwal",
      updatedDateTime: "27/11/2018 05:19:09.657 GMT", profileId: 85, profileName: "CVT Profile Test1",
      profileDesc: null, forProduction: false, fileDirection: "I", active: false, prodProfileType: "Non-Production", lastUpdatedDateTime: "11/26/18 23:19 CT"
    };
    component.profileModel = component.selectedProfileData;
    // component.selectedProfileData = rowData;
  }));

  // it('should be search method filter profile', async(() => {
  //   let autoComplete = fixture.debugElement.query(By.css('p-autoComplete')).componentInstance;
  // }));
  // xit("should and displayToolTipText()", () => {
  //   component.toolTipProfile = {
  //     "Profile name": {
  //       "tooltipDesc": "Profile name description",
  //       "readMoreLink": "http://www.google.com"
  //     }
  //   };
  //   fixture.detectChanges();
  //   let tooltip = fixture.debugElement.queryAll(By.css(".btn-link"));
  //   const btnNextStep = document.createElement("a");
  //   document.body.appendChild(btnNextStep);
  //   btnNextStep.addEventListener("click", (event) => {
  //     component.displayToolTipText(event, "Profile name", "bottom");
  //     fixture.detectChanges();
  //     component.hideToolTipText(event);
  //     fixture.detectChanges();
  //     component.hideToolTipText(event);
  //   });
  //   btnNextStep.click();
  //   fixture.detectChanges();
  // });

  it("search fn", () => {
    let event = {
      query: "jay.avatani@alight.com"
    };
    component.search(event);
  });

});

class MockDataService {
  getPageAndFieldsDetails() {
    let response;
    response = require("../../../../assets/data/tooltipPageDetails.json");
    return (Observable.of(response));
  }
  getProfiles(): Observable<any> {
    let response;
    response = require("../../../../assets/data/profileList.json");
    return (Observable.of(response));
  }
  addProfile(): Observable<any> {
    let response = require("../../../../assets/data/profileList.json");
    return (Observable.of(response));
  }
  updateProfile(): Observable<any> {
    let response;
    response = require("../../../../assets/data/profileList.json");
    return (Observable.of(response));
  }
  findAssociatedProfileWithJob(): Observable<any> {
    let response;
    response = require("../../../../assets/data/profileList.json");
    return (Observable.of(response));
  }
  error() {
    return false;
  }
  success() {
    return true;
  }

}

export class FakeNgxPermission extends NgxPermissionsService {
}

export class FakeToolTip {
  getPageAndFieldsDetails(adaptWebPageID) {
    let response = { "error": false, "data": { "Trading Partner": { "tooltipDesc": "This will load information about trading partner on selected contact page", "readMoreLink": null }, "Contact Type": { "tooltipDesc": "Contact type - tool tip123", "readMoreLink": "www.google.com" } } };
    return Observable.of(response);
  }
}
