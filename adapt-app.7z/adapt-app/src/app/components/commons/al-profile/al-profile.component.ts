import { Component, OnInit, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { ProfileService } from "./al-profile-service/profile.service";

import { NgForm, FormControl, FormGroup, Validators, FormArray } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { DataTable } from "primeng/components/datatable/datatable";
import { Router, ActivatedRoute } from "@angular/router";
import { ProfileConfig } from "./al-profile-model/profile-config.model";
import { CustomValidators } from "ng2-validation";
import { OverlayPanel } from "primeng/components/overlaypanel/overlaypanel";
import { ConfirmationService } from "primeng/components/common/api";
import { NgxPermissionsService } from "ngx-permissions";
import { Observable } from "rxjs/Observable";
import { ToolTipUtilService } from "../../../services/common/toolTipUtil";
import { TOAST_SETTING } from "../../../global";
import { Dropdown } from "primeng/components/dropdown/dropdown";

@Component({
  selector: "app-al-profile",
  templateUrl: "./al-profile.component.html",
  styleUrls: ["./al-profile.component.scss"],
  providers: [ProfileService, ConfirmationService, ToolTipUtilService]
})

export class AlProfileComponent implements OnInit {

  profileModel: ProfileConfig;
  fileDirections = [];
  group: string;
  // selectedValue: string;
  profiles: any;
  filterProfileName: any;
  filterProfileNameModel: any;
  filterFileDirectionName: any;
  filterFileDirectionModel: any;
  filterForProduction: any;
  filterForProductionModel: any;
  filterForStatus: any;
  filterForStatusModel: any;
  filterForNo: any;
  filterForNoModel: any;

  filterLastUpdate: any;
  filterLastUpdateModel: any;
  filterLastUpdatedBy: any;
  filterLastUpdatedByModel: any;

  tableDataLoading: boolean = true;
  selectedPanel: any;
  selectedProfileData: ProfileConfig;
  isEdit: boolean = false;
  disableFileDirection: boolean = false;

  /* ToolTip display OnMouse Click */
  toolTipProfile: any = [];
  tooltipResult: any;
  pageID: number = 6;
  validationMsg: string;
  @ViewChild("dt") dataTable: DataTable;
  @ViewChildren("dropdown") dropDown: QueryList<Dropdown>;
  // selectedProfileId:number;
  constructor(
    private profileService: ProfileService,
    public toastr: ToastsManager,
    private router: Router,
    private route: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private permissionsService: NgxPermissionsService,
    private toolTipUtils: ToolTipUtilService
  ) { }

  ngOnInit() {
    this.profileModel = new ProfileConfig();
    this.profileModel.forProduction = false;
    this.profileModel.active = false;
    this.profileModel.fileDirection = "I";
    // this.profileModel.fileDirection ="I";
    this.viewProfileData();
    this.getToolTipTextDetails();
    this.disableFileDirection = false;
    this.validationMsg = window["validationMsg"];
  }


  addProfileData(profileForm: NgForm) {
    if (this.profileModel.profileName === null || this.profileModel.profileName === undefined || this.profileModel.profileName.trim() === "") {
      this.toastr.error("Profile Name is required.", "Oops!", TOAST_SETTING);
      return false;
    }

    if (this.profileModel.fileDirection === null || this.profileModel.fileDirection === undefined || this.profileModel.fileDirection === "") {
      this.toastr.error("File Direction is required.", "Oops!", TOAST_SETTING);
      return false;
    }
    if (!this.isEdit) {
      this.profileService.addProfile(this.profileModel).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Profile added successfully.", "Success!");
          this.dataTable.reset();
          this.viewProfileData();
          profileForm.resetForm({ fileDirection: "I" });
          this.profileModel = new ProfileConfig();
          this.profileModel.forProduction = false;
          this.profileModel.fileDirection = "I";
          this.profileModel.active = false;
          this.disableFileDirection = false;
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in adding Profile.", "Oops!", TOAST_SETTING);
      });
    } else {
      //   this.tpModel.profileId =this.selectedProfileId;
      this.profileService.updateProfile(this.profileModel).subscribe(res => {
        if (!res.error) {
          this.toastr.success("Profile updated successfully.", "Success!");
          this.dataTable.reset();
          this.viewProfileData();
          profileForm.resetForm({ fileDirection: "I" });
          this.disableFileDirection = false;
          this.profileModel = new ProfileConfig();
          this.profileModel.forProduction = false;
          this.profileModel.fileDirection = "I";
          this.profileModel.active = false;
          this.isEdit = false;
        }
        else {
          this.toastr.error(res.message, "Oops!", TOAST_SETTING);
        }
      }, error => {
        this.toastr.error("Server Error in editing Profile.", "Oops!", TOAST_SETTING);
      });

    }
  }


  viewProfileData() {
    this.tableDataLoading = true;
    this.profileService.getProfiles().subscribe(res => {
      this.profiles = res.data;

      this.populateFilterDropDown();
      this.tableDataLoading = false;
    });

  }

  btnCancel() {
    this.router.navigate(["/commons"]);
  }

  populateFilterDropDown() {
    this.populateFilterProfileName();
    this.populateFilterFileDirectionName();
    this.populateFilterForProduction();
    this.populateFilterStatus();
    this.populateFilterLastUpdate();
    this.populateFilterLastUpdatedBy();
  }

  populateFilterProfileName() {
    this.profileNames = [];
    this.filterProfileName = [];
    this.filterProfileName = [{ label: "All", value: null }];
    let _filterProfileName: any = [];


    if (this.profiles !== null) {
      for (let i = 0; i < this.profiles.length; i++) {

        if (_filterProfileName.indexOf(this.profiles[i].profileName) === -1) {
          _filterProfileName.push(this.profiles[i].profileName);
        }
      };
    }
    for (let value of _filterProfileName) {
      this.filterProfileName.push({ label: value, value: value });
      this.profileNames.push(value);
    }
    this.filterProfileNameModel = null;
  }

  populateFilterFileDirectionName() {
    this.filterFileDirectionName = [];

    this.filterFileDirectionName = [{ label: "All", value: null }];


    let _filterFileDirectionName: any = [];


    if (this.profiles !== null) {
      for (let i = 0; i < this.profiles.length; i++) {

        if (_filterFileDirectionName.indexOf(this.profiles[i].fileDirection) === -1) {
          _filterFileDirectionName.push(this.profiles[i].fileDirection);
        }
      };
    }
    for (let value of _filterFileDirectionName) {
      let fileDirectionLabel;
      if (value === "I") {
        fileDirectionLabel = "Inbound";
      } else {
        fileDirectionLabel = "Outbound";
      }
      this.filterFileDirectionName.push({ label: fileDirectionLabel, value: value });
    }
    this.filterFileDirectionModel = null;
  }

  populateFilterForProduction() {
    this.filterForProduction = [
      { label: "All", value: null },
      { label: "Yes", value: true },
      { label: "No", value: false }
    ];
    this.filterForProductionModel = null;
  }
  populateFilterStatus() {
    this.filterForStatus = [
      { label: "All", value: null },
      { label: "Active", value: true },
      { label: "Inactive", value: false }
    ];
    this.filterForStatusModel = null;
  }
  populateFilterLastUpdate() {
    this.filterLastUpdate = [];
    this.filterLastUpdate = [{ label: "All", value: null }];
    let _filterLastUpdate: any = [];
    if (this.profiles !== null) {
      for (let i = 0; i < this.profiles.length; i++) {
        if (_filterLastUpdate.indexOf(this.profiles[i].updatedDateTime) === -1) {
          let temp = this.profiles[i].updatedDateTime.replace(/\s*[a-z]+/ig, "");
          this.profiles[i].lastUpdatedDateTime = new Date(temp).getTime();
          _filterLastUpdate.push(this.profiles[i].lastUpdatedDateTime);
          this.filterLastUpdate.push({ label: this.profiles[i].updatedDateTime, value: this.profiles[i].lastUpdatedDateTime });
        }
      };
    }
    this.filterLastUpdateModel = null;
  }
  populateFilterLastUpdatedBy() {
    this.filterLastUpdatedBy = [];
    this.filterLastUpdatedBy = [{ label: "All", value: null }];
    let _filterLastUpdatedBy: any = [];
    if (this.profiles !== null) {
      for (let i = 0; i < this.profiles.length; i++) {
        let tmpName = this.profiles[i].updatedBy !== null ? this.profiles[i].updatedBy : this.profiles[i].createdBy;
        if (_filterLastUpdatedBy.indexOf(tmpName) === -1) {
          _filterLastUpdatedBy.push(tmpName);
        }
      };
    }
    for (let value of _filterLastUpdatedBy) {
      this.filterLastUpdatedBy.push({ label: value, value: value });
    }
    this.filterLastUpdatedByModel = null;
  }

  rowAction(event, rowData, index, overlaypanel: OverlayPanel) {
    overlaypanel.toggle(event);
    this.selectedPanel = overlaypanel;
    this.selectedProfileData = rowData;
  }

  editProfile() {
    this.profileModel.fileDirection = null;
    this.profileService.findAssociatedProfileWithJob(this.selectedProfileData.profileId).subscribe(res => {
      let profileJobAsc = res.data;
      let countForProfileOutboutFileAss = profileJobAsc["countForProfileOutboutFileAss"];
      let countForJobScheduleInOutFile = profileJobAsc["countForJobScheduleInOutFile"];
      this.selectedPanel.hide();
      this.profileModel = new ProfileConfig();
      this.profileModel.profileName = this.selectedProfileData.profileName;
      this.profileModel.fileDirection = this.selectedProfileData.fileDirection;
      this.profileModel.forProduction = this.selectedProfileData.forProduction;
      this.profileModel.profileId = this.selectedProfileData.profileId;
      this.profileModel.active = this.selectedProfileData.active;
      this.profileModel.uniqueIdentifier = this.selectedProfileData.uniqueIdentifier;
      this.isEdit = true;
      window.scrollTo(0, 0);
      if (countForProfileOutboutFileAss > 0 || countForJobScheduleInOutFile > 0) {
        this.disableFileDirection = true;
      }
    });
  }

  /* deleteProfile(){
     this.profileService.deleteProfile(this.selectedProfileData.profileId).subscribe(res =>{
       if(!res.error){
         this.toastr.success("Profile deleted successfully.",'Success!');
         this.viewProfileData();
       }
       else{
       this.toastr.error(res.message,'Oops!');
       }
     },error => {
       this.toastr.error("Server Error in deleting Profile.",'Oops!');
     })
   }*/
  getToolTipTextDetails() {
    this.toolTipUtils.getPageAndFieldsDetails(this.pageID).subscribe(res => {
      this.toolTipProfile = res.data;
    });
  }

  @ViewChild("dynamicPopover") dynamicPopover;
  popOverContent: any = {};
  displayToolTipText(event, value, pos) {
    this.tooltipResult = this.toolTipProfile[value];
    if (this.tooltipResult.readMoreLink !== "" && this.tooltipResult.readMoreLink !== null) {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p><p><a href=\"" + this.tooltipResult.readMoreLink + "\" target=\"_blank\"><u>Read More</u></a>";
    } else {
      this.popOverContent = "<p>" + this.tooltipResult.tooltipDesc + "</p>";
    }
    this.dynamicPopover.position = pos;
    this.dynamicPopover.showPopOver(event);
  }
  hideToolTipText(event) {
    this.dynamicPopover.hidePopOver(event);
  }

  // CC-38451
  results: any = [];
  profileNames: any = [];
  search(event) {
    if (event.query.length >= 3) {
      this.results = this.profileNames.filter((obj) => {
        let _str = obj.toLowerCase();
        if (_str.includes(event.query.toLowerCase())) {
          return obj;
        }
      });
    }
  }
}
