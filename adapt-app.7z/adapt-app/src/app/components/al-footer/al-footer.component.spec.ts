import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AlFooterComponent } from "./al-footer.component";

describe("AlFooterComponent", () => {
  let component: AlFooterComponent;
  let fixture: ComponentFixture<AlFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
