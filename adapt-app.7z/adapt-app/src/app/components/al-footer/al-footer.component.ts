import { Component, OnInit } from "@angular/core";

@Component({
  selector: "al-footer",
  templateUrl: "./al-footer.component.html",
  styleUrls: ["./al-footer.component.scss"]
})
export class AlFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
